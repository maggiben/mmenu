// CustomTree.cpp : Defines the class behaviors for the application.
//

#include "stdafx.h"
#include "CustomTree.h"
#include "CustomTreeDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CCustomTreeApp

BEGIN_MESSAGE_MAP(CCustomTreeApp, CWinApp)
	//{{AFX_MSG_MAP(CCustomTreeApp)
	//}}AFX_MSG
	ON_COMMAND(ID_HELP, CWinApp::OnHelp)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CCustomTreeApp construction

CCustomTreeApp::CCustomTreeApp()
{
}

/////////////////////////////////////////////////////////////////////////////
// The one and only CCustomTreeApp object

CCustomTreeApp theApp;

/////////////////////////////////////////////////////////////////////////////
// CCustomTreeApp initialization

BOOL CCustomTreeApp::InitInstance()
{
	// Standard initialization

	CCustomTreeDlg dlg;
	m_pMainWnd = &dlg;
	int nResponse = dlg.DoModal();
	if (nResponse == IDOK)
	{
	}
	else if (nResponse == IDCANCEL)
	{
	}

	// Since the dialog has been closed, return FALSE so that we exit the
	//  application, rather than start the application's message pump.
	return FALSE;
}
