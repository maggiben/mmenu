#ifndef CUSTOM_TREE_TEST_APP_H_INCLUDED
#define CUSTOM_TREE_TEST_APP_H_INCLUDED

#if _MSC_VER > 1000
#pragma once
#endif

#ifndef __AFXWIN_H__
  #error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"

class CCustomTreeApp : public CWinApp
{
public:
  CCustomTreeApp();

  //{{AFX_VIRTUAL( CCustomTreeApp )
  public:
  virtual BOOL InitInstance();
  //}}AFX_VIRTUAL

  //{{AFX_MSG( CCustomTreeApp )
  //}}AFX_MSG

  DECLARE_MESSAGE_MAP()
};



#endif
