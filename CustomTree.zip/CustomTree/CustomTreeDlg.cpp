#include "stdafx.h"
#include "CustomTree.h"
#include "CustomTreeDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

CCustomTreeDlg::CCustomTreeDlg( CWnd* pParent ) : CDialog( CCustomTreeDlg::IDD, pParent )
{
  //{{AFX_DATA_INIT( CCustomTreeDlg )
  //}}AFX_DATA_INIT

  m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CCustomTreeDlg::DoDataExchange( CDataExchange* pDX )
{
  CDialog::DoDataExchange( pDX );
  //{{AFX_DATA_MAP( CCustomTreeDlg )
  //}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP( CCustomTreeDlg, CDialog )
  //{{AFX_MSG_MAP( CCustomTreeDlg )
  //}}AFX_MSG_MAP
END_MESSAGE_MAP()


BOOL CCustomTreeDlg::OnInitDialog()
{
  CDialog::OnInitDialog();

  // MJS: Here is where the tree control
  //      is initialized for this example
  //
  CreateTreeControl();
  FillTreeControl();

  return TRUE;
}



void CCustomTreeDlg::CreateTreeControl( void )
{
  // place the tree in the dialog frame that is the place
  // holder for the control
  //
  CRect oRect;

  GetDlgItem( IDC_TREE_FRAME )->GetWindowRect( oRect );

  m_oTreeControl.CreateEx( WS_EX_CLIENTEDGE,
                           "SysTreeView32",
                           "",
                           WS_CHILD | WS_VISIBLE | WS_BORDER | WS_TABSTOP |
                           TVS_HASBUTTONS | TVS_HASLINES | TVS_LINESATROOT | TVS_EDITLABELS |
                           TVS_SHOWSELALWAYS | TVS_TRACKSELECT, 
                           oRect, 
                           this,
                           15000 );  // MJS: Warn hard-coded ID

  m_oTreeControl.SetBackGroundColor( GetSysColor( COLOR_BTNFACE ) );
}


void CCustomTreeDlg::FillTreeControl( void )
{
  HTREEITEM hRoot;
  HTREEITEM hCheckNode;
  HTREEITEM hRadioNode;

  // first make the root node for the entire tree
  //
  hRoot = m_oTreeControl.AddNode( NULL, NULL, "Various Lists", 0 ); 

  // now make some check nodes
  //
  hCheckNode = m_oTreeControl.AddNode( hRoot, 
                                       NULL, 
                                       "Check Item #1", 
                                       ciCheckedNode ); 
  hCheckNode = m_oTreeControl.AddNode( hRoot, 
                                       hCheckNode, 
                                       "Check Item #2", 
                                       ciCheckedNode ); 

  // now make a check node that has one editable and selectable child
  //
  hCheckNode = m_oTreeControl.AddNode( hRoot, 
                                       hCheckNode, 
                                       "Check List #1", 
                                       ciCheckedNode ); 
  m_oTreeControl.AddNode( hCheckNode, NULL, "Add Items...", ciEditable | ciSelectable );
  
  // now make some radio groups of controls to show nested enable feature
  //
  hRadioNode = m_oTreeControl.AddNode( hRoot, hCheckNode, "Radio List #1", ciRadioNode ); 
  m_oTreeControl.AddNode( hRadioNode, NULL, "Nested Radio #1", ciRadioNode );  
  hRadioNode = m_oTreeControl.AddNode( hRadioNode, NULL, "Nested Radio #2", ciRadioNode ); 
  m_oTreeControl.AddNode( hRadioNode, NULL, "Check Button", ciCheckedNode );

  hRadioNode = m_oTreeControl.AddNode( hRoot, NULL, "Radio List #2", ciRadioNode ); 
  m_oTreeControl.AddNode( hRadioNode, NULL, "Nested Radio #3", ciRadioNode );  
  hRadioNode = m_oTreeControl.AddNode( hRadioNode, NULL, "Nested Radio #4", ciRadioNode ); 
  m_oTreeControl.AddNode( hRadioNode, NULL, "Check Button", ciCheckedNode );
}
