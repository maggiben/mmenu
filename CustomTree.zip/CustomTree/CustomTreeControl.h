#ifndef CUSTOM_TREE_CONTROL_H_INCLUDED
#define CUSTOM_TREE_CONTROL_H_INCLUDED


#include <afxext.h>
#include "resource.h"



///////////////////////////////////////////////////////////////////////////////
//
// Define the tree control for use in show/hide prefs page dialog
//
///////////////////////////////////////////////////////////////////////////////

// item state flag
//
const int ciExpanded    = 1;
const int ciChecked     = 2;
const int ciDisabled    = 4;


// item styles
//
const int ciEditable    = 1;
const int ciCheckedNode = 2;
const int ciRadioNode   = 4;
const int ciSelectable  = 8;


#include <map>
using namespace std;

typedef struct _tagItemRects
{
  CRect m_oLeftRect;
  CRect m_oExpandRect;
  CRect m_oCheckRect;
  CRect m_oTextRect;
}
ITEM_RECTS, *P_ITEM_RECTS;


typedef map< HTREEITEM, P_ITEM_RECTS > ITEM_RECT_MAP;
typedef ITEM_RECT_MAP::iterator        ITEM_RECTS_ITER;


class CCustomTreeCtrl : public CTreeCtrl
{
public:
  CCustomTreeCtrl();
  virtual ~CCustomTreeCtrl();

  HTREEITEM AddNode( HTREEITEM   hParent,
                     HTREEITEM   hInsertAfter, 
                     const char* pchLabelText, 
                     int         iStyle ); 

  COLORREF SetBackGroundColor( COLORREF xNewColor )
  {
    COLORREF xReturn   = m_xBackGroundColor;
    m_xBackGroundColor = xNewColor;
    SetBkColor( xNewColor );
    return xReturn;
  }

  //{{AFX_VIRTUAL( CCustomTreeCtrl )
  virtual BOOL PreTranslateMessage( MSG* pxMsg );
  //}}AFX_VIRTUAL

protected:
  void InvalidateItem( HTREEITEM hItem, BOOL bInvalidateSelf );
  void ChangeItemState( HTREEITEM hItem );	
  BOOL CanEdit( HTREEITEM hTreeItem );
  int  GetIndentLevel( HTREEITEM hTreeItem );
  BOOL IsItemChecked( HTREEITEM hItem );
  void EnableSubTree( HTREEITEM hTreeItem, bool bEnable );

  //{{AFX_MSG( CCustomTreeCtrl )
  afx_msg void OnLButtonDown( UINT iFlags, CPoint oPoint );
  afx_msg void OnKeyDown( UINT iChar, UINT iRepeatCount, UINT iFlags );
  afx_msg void OnLButtonDblClk(UINT nFlags, CPoint point);
  afx_msg void OnCustomDraw( NMHDR* pxNMHDR, LRESULT* plResult );
  //}}AFX_MSG
  afx_msg void OnBeginLabelEdit( NMHDR* pxNMHDR, LRESULT* plResult );
  afx_msg void OnEndLabelEdit( NMHDR* pxNMHDR, LRESULT* plResult );
  afx_msg void OnItemExpanding( NMHDR* pxNMHDR, LRESULT* plResult ); 

  DECLARE_MESSAGE_MAP()

private:
  HTREEITEM      m_hEditNode;
  ITEM_RECT_MAP  m_oItemRects;
  bool           m_bQuitEdits;
  COLORREF       m_xBackGroundColor;
};






#endif
