#ifndef CUSTOM_TREE_DIALOG_H_INCLUDED
#define CUSTOM_TREE_DIALOG_H_INCLUDED

#if _MSC_VER > 1000
#pragma once
#endif


#include "CustomTreeControl.h"


class CCustomTreeDlg : public CDialog
{
public:
  CCustomTreeDlg( CWnd* pParent = NULL );

  //{{AFX_DATA( CCustomTreeDlg )
  enum { IDD = IDD_CUSTOMTREE_DIALOG };
  //}}AFX_DATA

  //{{AFX_VIRTUAL( CCustomTreeDlg )
  protected:
  virtual void DoDataExchange( CDataExchange* pDX );
  //}}AFX_VIRTUAL

protected:
	HICON m_hIcon;

  //{{AFX_MSG( CCustomTreeDlg )
  virtual BOOL OnInitDialog( void );
  afx_msg void OnPaint( void );
  afx_msg HCURSOR OnQueryDragIcon( void );
  //}}AFX_MSG

  DECLARE_MESSAGE_MAP()

private:
  CCustomTreeCtrl  m_oTreeControl;

  void CreateTreeControl( void );
  void FillTreeControl( void );
};

#endif
