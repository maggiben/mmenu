#include "stdafx.h"
#include "CustomTreeControl.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


BEGIN_MESSAGE_MAP( CCustomTreeCtrl, CTreeCtrl )
  //{{AFX_MSG_MAP( CCustomTreeCtrl )
  ON_WM_LBUTTONDOWN()
  ON_WM_KEYDOWN()
  ON_WM_LBUTTONDBLCLK()
  ON_NOTIFY_REFLECT( NM_CUSTOMDRAW, OnCustomDraw )
  //}}AFX_MSG_MAP
  ON_NOTIFY_REFLECT( TVN_BEGINLABELEDIT, OnBeginLabelEdit )
  ON_NOTIFY_REFLECT( TVN_ENDLABELEDIT, OnEndLabelEdit )
  ON_NOTIFY_REFLECT_EX( TVN_ITEMEXPANDED, OnItemExpanding )
END_MESSAGE_MAP()


CCustomTreeCtrl::CCustomTreeCtrl( void )
: m_bQuitEdits( false ),
  m_xBackGroundColor( GetSysColor( COLOR_WINDOW ) )
{
}


CCustomTreeCtrl::~CCustomTreeCtrl( void )
{
  ITEM_RECTS_ITER oIter;
  for ( oIter  = m_oItemRects.begin();
        oIter != m_oItemRects.end();
        oIter++ )
  {
    delete (*oIter).second;
  }
}


HTREEITEM  CCustomTreeCtrl::AddNode( HTREEITEM   hParent, 
                                     HTREEITEM   hInsertAfter, 
                                     const char* pchLabelText, 
                                     int         iStyle )
{
  HTREEITEM       hResult;
  TV_INSERTSTRUCT xInsert;

  memset( &xInsert, 0, sizeof( xInsert ) );

  xInsert.hParent            = hParent;
  xInsert.hInsertAfter       = hInsertAfter;
  xInsert.item.mask          = TVIF_TEXT;
  xInsert.item.pszText       = const_cast<char*>( pchLabelText );
  xInsert.item.cchTextMax    = strlen( pchLabelText );
  
  hResult = InsertItem( &xInsert );
  SetItemData( hResult, MAKEWPARAM( 0, iStyle ) );

  return hResult;
}


void CCustomTreeCtrl::OnCustomDraw( NMHDR* pNMHDR, LRESULT* pResult ) 
{
  NMTVCUSTOMDRAW*     pxCustomDraw = (NMTVCUSTOMDRAW*)pNMHDR;

  switch ( pxCustomDraw->nmcd.dwDrawStage )
  {
    case CDDS_PREPAINT: 
    {
      // just to keep stupid compiler from complaining about variables
      //
      if ( true )
      {
        CRect oRect( pxCustomDraw->nmcd.rc );

        CDC oDC;
        oDC.Attach( pxCustomDraw->nmcd.hdc );
        oDC.FillRect( oRect, &CBrush( m_xBackGroundColor ) );
        oDC.Detach();
      }
      *pResult = CDRF_NOTIFYITEMDRAW; 	
      return;
    }
    break;

    case CDDS_ITEMPREPAINT: 
    {
      // just to keep stupid compiler from complaining about variables
      //
      if ( 1 )
      {
        HTREEITEM       hTreeItem = (HTREEITEM)pxCustomDraw->nmcd.dwItemSpec;

        // get/create the object that holds each items rectangles
        //
        ITEM_RECTS_ITER oIter     = m_oItemRects.find( hTreeItem );
        P_ITEM_RECTS    pxRects;

        if ( oIter == m_oItemRects.end() )
        {
          pxRects = new ITEM_RECTS;
          m_oItemRects.insert( ITEM_RECT_MAP::value_type( hTreeItem, pxRects ) );
        }
        else
        {
          pxRects = (*oIter).second;
        }

        // get some basic facts to help with the render that is about to happen
        //
        int   iIndent   = GetIndentLevel( hTreeItem );
        DWORD dwData    = GetItemData( hTreeItem );

        UINT  iStyle    = HIWORD( dwData );
        UINT  iState    = LOWORD( dwData );

        bool  bExpanded = iState & ciExpanded;
        HDC   hDC       = pxCustomDraw->nmcd.hdc;
        RECT  xRect     = pxCustomDraw->nmcd.rc;
        CDC*  poDC      = CDC::FromHandle( hDC );
        CRect oRect( xRect );

        COLORREF xBackColor;
        COLORREF xTextColor;

        // colors of this row are based on select state of the item
        //
        if ( GetSelectedItem() == hTreeItem && iStyle & ciSelectable )
        {
          xTextColor = GetSysColor( COLOR_HIGHLIGHTTEXT );
          xBackColor = GetSysColor( COLOR_HIGHLIGHT );
        }
        else
        {
          xTextColor = GetSysColor( COLOR_WINDOWTEXT );
          xBackColor = m_xBackGroundColor;
        }

        CBrush  oBackBrush;
        CBrush  oBrush;
        CBrush* poOldBrush;

        oBrush.CreateSolidBrush( xBackColor );
        oBackBrush.CreateSolidBrush( m_xBackGroundColor );

        // fill the whole rectangle with the background color
        //
        poOldBrush = poDC->SelectObject( &oBackBrush );
        poDC->FillSolidRect( oRect, m_xBackGroundColor );
        poDC->SelectObject( poOldBrush );
        oBackBrush.DeleteObject();

        // start rendering with the left side based on the 
        // indent level of this node
        //
        oRect.left += GetIndent() * iIndent;

        // tree control likes it better if kid node text is inset from parent text
        //
        HTREEITEM hParent = GetParentItem( hTreeItem );
        if (  NULL != hParent )
        {
          ITEM_RECTS_ITER oParentIter = m_oItemRects.find( hParent );
          P_ITEM_RECTS    pxParentRects;

          if ( oParentIter != m_oItemRects.end() )
          {
            pxParentRects = (*oParentIter).second;
            if ( pxParentRects->m_oTextRect.left > oRect.left )
            {
              oRect.left = pxParentRects->m_oTextRect.left + 4;
            }
          }
        }
        int iOriginalLeft = oRect.left;

        CRect oButton( oRect );
        oButton.right = oButton.left + ( oButton.bottom - oButton.top );

        // if this node has kids, then must put up an indicator for that
        //
        if ( ItemHasChildren( hTreeItem ) )
        {
          if ( !bExpanded )
          {
            poDC->DrawFrameControl( oButton, 
                                    DFC_SCROLL,
                                    DFCS_SCROLLRIGHT ); 
          }
          else
          {
            poDC->DrawFrameControl( oButton, 
                                    DFC_SCROLL,
                                    DFCS_SCROLLDOWN | DFCS_PUSHED ); 
          }
        }

        // save rect for hit testing later
        //
        oRect.left += oButton.Width() + 4;
        pxRects->m_oExpandRect = oButton;

        // now put in any check boxes and or radio buttons that may be needed
        //
        bool bNoStyle = false;

        if ( iStyle & ciCheckedNode || iStyle & ciRadioNode )
        {
          CRect oCtrlRect( oRect.left, oRect.top, oRect.left + oRect.Height(), oRect.bottom );
          bool  bChecked  = ( 0 != ( iState & ciChecked ) );

          DWORD dwButton   = ( iStyle & ciCheckedNode ) ? DFCS_BUTTONCHECK : DFCS_BUTTONRADIO;
          DWORD dwChecked  = ( bChecked )               ? DFCS_CHECKED     : 0;
          DWORD dwInactive = ( iState & ciDisabled )    ? DFCS_INACTIVE    : 0;
        
          poDC->DrawFrameControl( oCtrlRect, 
                                  DFC_BUTTON,
                                  dwButton | dwChecked | dwInactive ); 
          pxRects->m_oCheckRect = oCtrlRect;
          oRect.left += oCtrlRect.Width() + 4;
        }
        else
        {
          bNoStyle = true;
        }        

        // get the text
        //
        CString oText;
        oText += GetItemText( hTreeItem );

        // measure it and set the text rect accordinly
        // 
        CSize oSize = poDC->GetTextExtent( oText ); 
        oRect.right = oRect.left + oSize.cx;

        // save rect for hit testing later
        //
        pxRects->m_oTextRect = oRect;

        // fill the text rectangle background color
        //
        poOldBrush = poDC->SelectObject( &oBrush );
        poDC->FillSolidRect( oRect, xBackColor );

        poDC->SelectObject( poOldBrush );
        oBrush.DeleteObject();

        // display the text
        //
        poDC->SetBkColor( xBackColor );
        poDC->SetTextColor( xTextColor );
        poDC->TextOut( oRect.left, oRect.top, oText );

        *pResult = CDRF_SKIPDEFAULT;

        return;
      }
    }
    break;

    default:
      *pResult = CDRF_DODEFAULT;
    break;
  }
}


void CCustomTreeCtrl::OnLButtonDown( UINT iFlags, CPoint oPoint ) 
{
  UINT      iItemFlags = 0;
  HTREEITEM hItem      = HitTest( oPoint, &iItemFlags );

  if ( NULL == hItem )
    return;

  DWORD dwData = GetItemData( hItem );
  UINT  iStyle = HIWORD( dwData );
  UINT  iState = LOWORD( dwData );

  if ( iStyle & ciCheckedNode || iStyle & ciRadioNode  )
  {
    ITEM_RECTS_ITER oIter = m_oItemRects.find( hItem );
    if ( oIter != m_oItemRects.end() )
    {
      P_ITEM_RECTS pxRects = (*oIter).second;

      if ( pxRects->m_oCheckRect.PtInRect( oPoint ) ) 
      {
        ChangeItemState( hItem );
        return;
      }
    }
  }
  CTreeCtrl::OnLButtonDown( iFlags, oPoint );
}


void CCustomTreeCtrl::OnKeyDown( UINT iChar, UINT iRepeatCnt, UINT iFlags ) 
{
  if ( iChar == VK_SPACE )
  {
    HTREEITEM hItem = GetSelectedItem();
    
    if ( hItem )
    {
      CRect oRect;

      if ( GetItemRect( hItem, &oRect, TRUE ) )
      {
        UINT   iItemFlags = 0;
        CPoint oPoint( oRect.top, oRect.left );
      
        HTREEITEM hTest = HitTest( oPoint, &iItemFlags );
        if ( hTest == hItem )
        {
          if ( iItemFlags & TVHT_ONITEMSTATEICON )
          {
            ChangeItemState( hItem );
            return;
          }
        }
      }
    }
  }
  CTreeCtrl::OnKeyDown( iChar, iRepeatCnt, iFlags );
}


void CCustomTreeCtrl::ChangeItemState( HTREEITEM hItem )
{
  HTREEITEM hSelected;

  hSelected = GetSelectedItem();

  if ( hItem != NULL )
  {
    DWORD dwData     = GetItemData( hItem );
    UINT  iState     = LOWORD( dwData );
    UINT  iStyle     = HIWORD( dwData );
    bool  bOnNow     = false;
    bool  bDisabled  = 0 != ( iState & ciDisabled );

    if ( bDisabled )
      return;

    if ( ciCheckedNode & iStyle || ciRadioNode & iStyle )
    {
      if ( iState & ciChecked )
      {
        iState &= ~ciChecked;
      }
      else
      {
        iState |= ciChecked;
        bOnNow  = true;
      }
      SetItemData( hItem, MAKEWPARAM( iState, iStyle ) );

      // if the item just clicked is now checked and if it is
      // is a radio style button, then need to set all of its
      // radio button peer nodes off
      //
      if ( bOnNow )
      {
        // enable local sub-tree
        //
        if ( ItemHasChildren( hItem ) )
        {
           HTREEITEM hKid = GetChildItem( hItem );
           while ( NULL != hKid )
           {
             EnableSubTree( hKid, true );
             hKid = GetNextItem( hKid, TVGN_NEXT );
           }
        }

        if ( ciRadioNode & iStyle )
        {
          // go up one level so that iteration of all its kids
          // will visit all sibling nodes of the node just checked
          //
          HTREEITEM hParent = GetParentItem( hItem );
          if ( hParent != NULL )
          {
            // loop over all the siblings
            //
            HTREEITEM hToggle = GetChildItem( hParent );

            while ( hToggle != NULL )
            {
              // only mess with the node's state if it IS NOT
              // the one just checked
              //
              if ( hToggle != hItem )
              {
                DWORD dwToggle = GetItemData( hToggle );
                UINT  iToggleState = LOWORD( dwToggle );
                UINT  iToggleStyle = HIWORD( dwToggle );

                // is this peer is a radio button AND its checked,
                // then UNCHECK it
                //
                if ( ciRadioNode & iToggleStyle )
                {
                  iToggleState &= ~ciChecked;
                  SetItemData( hToggle, MAKEWPARAM( iToggleState, iToggleStyle ) );

                  InvalidateItem( hToggle, true );

                  // now need to loop over the kids of this element and disable
                  // their buttons
                  if ( ItemHasChildren( hToggle ) )
                  {
                    HTREEITEM hKid = GetChildItem( hToggle );
                    while ( NULL != hKid )
                    {
                      EnableSubTree( hKid, false );
                      hKid = GetNextItem( hKid, TVGN_NEXT );
                    }
                  }
                }
              }
              hToggle = GetNextItem( hToggle, TVGN_NEXT );
            }
          }
        }
      }
    }
  }
}


void CCustomTreeCtrl::InvalidateItem( HTREEITEM hItem, BOOL bInvalidateSelf )
{
  CRect oItemRect;

  if ( bInvalidateSelf )
  {
    GetItemRect( hItem, &oItemRect, false );
    InvalidateRect( &oItemRect, true );
  }

  for ( hItem = GetChildItem( hItem ) ; hItem != NULL ; )
  {
    if ( ItemHasChildren( hItem ) 
      && GetItemState( hItem, TVIS_EXPANDED ) )
    {
      InvalidateItem( hItem, true );
    }
    else
    {
      GetItemRect( hItem, &oItemRect, false );
      InvalidateRect( &oItemRect, true );
    }
    hItem = GetNextSiblingItem( hItem );
  }
}

void CCustomTreeCtrl::EnableSubTree( HTREEITEM hTreeItem, bool bEnable )
{
  DWORD dwData = GetItemData( hTreeItem );
  UINT  iState = LOWORD( dwData );
  UINT  iStyle = HIWORD( dwData );

  if ( bEnable )
  {
    iState &= ~ciDisabled;
  }
  else
  {
    iState |= ciDisabled;
  }
  SetItemData( hTreeItem, MAKEWPARAM( iState, iStyle ) );
  InvalidateItem( hTreeItem, true );

  if ( ItemHasChildren( hTreeItem ) )
  {
    HTREEITEM hKid = GetChildItem( hTreeItem );
    while ( NULL != hKid )
    {
      EnableSubTree( hKid, bEnable );
      hKid = GetNextItem( hKid, TVGN_NEXT );
    }
  }
}



BOOL CCustomTreeCtrl::CanEdit( HTREEITEM hTreeItem )
{
  UINT iStyle = HIWORD( GetItemData( hTreeItem ) );

  if ( iStyle & ciEditable )
  {
    m_hEditNode = hTreeItem;
    return TRUE;
  }
  else
  {
    return FALSE;
  }
}

BOOL CCustomTreeCtrl::IsItemChecked(HTREEITEM hItem)
{
  if ( hItem != NULL )
  {
    DWORD dwData = GetItemData( hItem );
    UINT iState = LOWORD( dwData );
    UINT iStyle = HIWORD( dwData );

    if ( ciCheckedNode & iStyle || ciRadioNode & iStyle )
    {
      if ( iState & ciChecked )
      {
        return TRUE;
      }
    }
  }
  return FALSE;
}


void CCustomTreeCtrl::OnBeginLabelEdit( NMHDR* pxNMHDR, LRESULT* plResult ) 
{
  TV_DISPINFO* pxTVDispInfo = (TV_DISPINFO*)pxNMHDR;
    
  // check to see if edits are allowed at this node
  //
  if ( CanEdit( pxTVDispInfo->item.hItem ) )
  {
    SetFocus();

    // Limit text to 6 characters
    //
    GetEditControl()->LimitText( 6 );

    // allow edit to proceed
    //
    *plResult = 0;  
  }
  else
  {
    // deny edit
    //
    *plResult = 1;
  }
}

void CCustomTreeCtrl::OnEndLabelEdit( NMHDR* pxNMHDR, LRESULT* plResult ) 
{
  TV_DISPINFO* pxDispInfo = (TV_DISPINFO*)pxNMHDR;

  // Get new label text and item number from struct 
  // passed to this handler
  //
  TVITEM pxItem = pxDispInfo->item;

  if ( pxItem.pszText == 0 )
  {
    // editing was cancelled
    //
    return;
  }
  else
  {
    // capture / process the new value for the node
    //
    CString oNewLabel = pxItem.pszText;

    TV_INSERTSTRUCT xAddNode;
    HTREEITEM       hNode;

    memset( &xAddNode, 0, sizeof( xAddNode ) );

    xAddNode.hParent         = GetParentItem( m_hEditNode );
    xAddNode.hInsertAfter    = m_hEditNode;
    xAddNode.item.mask       = TVIF_STATE | TVIF_TEXT;
    xAddNode.item.state      = INDEXTOSTATEIMAGEMASK( 0 );
    xAddNode.item.stateMask  = TVIS_STATEIMAGEMASK;
    xAddNode.item.pszText    = (char*)(LPCTSTR)oNewLabel;
    xAddNode.item.cchTextMax = oNewLabel.GetLength();
    
    hNode = InsertItem( &xAddNode );

    SetItemData( hNode, MAKEWPARAM( 0, 0 ) );

    if ( !m_bQuitEdits )
    {
      ::SendMessage( this->m_hWnd, TVM_EDITLABEL, 0, (LPARAM) m_hEditNode );
    }
  }
  // accept the change
  //
  *plResult = FALSE; //TRUE;
}

void CCustomTreeCtrl::OnLButtonDblClk(UINT nFlags, CPoint point) 
{
  UINT flags;
  HTREEITEM hTreeItem = HitTest(point, &flags);

  if ( CanEdit( hTreeItem ) )
  {
    m_bQuitEdits = false;
    ::SendMessage( this->m_hWnd, TVM_EDITLABEL, 0, (LPARAM) hTreeItem );
  }
  else
  {
    CTreeCtrl::OnLButtonDblClk( nFlags, point );
  }
}


int CCustomTreeCtrl::GetIndentLevel( HTREEITEM hTreeItem )
{
  int iIndent = 0;
  while ( ( hTreeItem = GetParentItem( hTreeItem ) ) != NULL )
  {
    iIndent++;
  }
  return iIndent;
}


void CCustomTreeCtrl::OnItemExpanding( NMHDR* pxNMHDR, LRESULT* plResult ) 
{
  NM_TREEVIEW* pxNMTV = (NM_TREEVIEW*)pxNMHDR;
  *plResult = 0;

  HTREEITEM hItem  = pxNMTV->itemNew.hItem;
  DWORD     dwData = GetItemData( hItem );
  UINT      iData  = LOWORD( dwData );
  UINT      iStyle = HIWORD( dwData );

  if ( TVE_COLLAPSE == pxNMTV->action ) 
  {
    iData &= ~ciExpanded;
  }
  else
  if ( TVE_EXPAND == pxNMTV->action ) 
  {
    iData |= ciExpanded;
  }
  SetItemData( hItem, MAKEWPARAM( iData, iStyle ) );
}


BOOL CCustomTreeCtrl::PreTranslateMessage( MSG* pxMsg ) 
{
  if ( pxMsg->message == WM_KEYDOWN )
  {
    // When an item is being edited make sure the edit control
    // receives certain important key strokes
    //
    if ( GetEditControl() 
      && ( pxMsg->wParam == VK_RETURN 
        || pxMsg->wParam == VK_DELETE 
        || pxMsg->wParam == VK_ESCAPE
        || GetKeyState( VK_CONTROL ) ) )
    {
      ::TranslateMessage( pxMsg );
      ::DispatchMessage( pxMsg );

      if ( pxMsg->wParam == VK_ESCAPE )
      {
        m_bQuitEdits = true;
      }

       return TRUE; // DO NOT process further
    }
  }
  return CTreeCtrl::PreTranslateMessage( pxMsg );
}


