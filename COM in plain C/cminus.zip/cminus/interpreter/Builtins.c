// Contains the interpreter's C builtin functions such as strlen,
// strcmp, etc.

#include <windows.h>
#include <objbase.h>
#include "../Guids.h"
#include "CLexer.h"
#include "../Active Engine/CInterpreter.h"
#include "BuiltIns.h"
#include "../English/Resource.h"
#include "../Active Engine/ErrorHandler.h"




static SCRIPTVARIANT * ensure_BSTR(CINTERPRETER *interpreter, HRESULT *hr)
{
	register SCRIPTVARIANT	*var;
	register SCRIPTVARIANT	*copy;

	// Pull the value off of the stack
	copy = var = interpreter->DataStack;
	interpreter->DataStack = var->Next;

	// Is it already the desired type?
	if (var->Value->vt != VT_BSTR)
	{
		// NOTE: If the VARIANT is borrowed from someone else, we must make a copy
		if (((unsigned char *)var + sizeof(SCRIPTVARIANT)) != (unsigned char *)var->Value && !(copy = getScriptVariant(0)))
		{
			*hr = E_OUTOFMEMORY;
			goto badmem;
		}

		if ((*hr = VariantChangeType(copy->Value, var->Value, 0, VT_BSTR)))
		{
			freeScriptVariant(copy);
			if (copy != var)
badmem:			freeScriptVariant(var);
			return(0);
		}

		if (copy != var) freeScriptVariant(var);
	}

	return(copy);
}



//=====================================================================
// Built-in functions that a script can call.
//=====================================================================

/************************** msgbox() ***************************
 * A run-time function that a script may call. It takes a
 * SCRIPTVARIANT and attempts to print a human-readable form
 * of it in a message box.
 *
 * msgbox(string, title)
 *
 * string =	A string for display in a message box.
 * title =	The title. If omitted, the currently executing
 *			function's name is used (while debugging), or the
 *			current script object name is used.
 */

static HRESULT C_msgbox(CINTERPRETER *interpreter, DWORD count)
{
	register SCRIPTVARIANT	*var;
	register SCRIPTVARIANT	*title;
	BSTR					titlestr;
	HRESULT					hr;

	if (count >= 1 && count <= 2)
	{
		// See if the title was supplied
		if (--count)
		{
			if (!(title = ensure_BSTR(interpreter, &hr))) goto out;
			titlestr = title->Value->bstrVal;
		}
		else
		{
			title = 0;

			if (interpreter->Parent->StackFrames)
				titlestr = (BSTR)((DEBUGSTACKFRAMEDESCRIPTOR *)interpreter->Parent->StackFrames->Value)->Name;
			else
				titlestr = interpreter->Name;
		}

		// Get the string representation of the SCRIPTVARIANT
		if ((var = ensure_BSTR(interpreter, &hr)))
		{
			MessageBoxW(0, var->Value->bstrVal, titlestr, MB_SETFOREGROUND);
			freeScriptVariant(var);
			hr = S_OK;
		}
		if (title) freeScriptVariant(title);
	}
	else
		// Note: Caller will pull args off the stack for an error
		hr = DISP_E_BADPARAMCOUNT;
out:
	return(hr);
}

/************************** cd() ***************************
 * A run-time function that a script may call. It changes
 * the dir or retrieves the current dir.
 *
 * cd(directory)
 * currentdir = cd()
 *
 * directory =	The new directory to set as the current.
 *				If omitted, returns the current directory.
 */

static HRESULT C_cd(CINTERPRETER *interpreter, DWORD count)
{
	register SCRIPTVARIANT	*var;
	register HRESULT		hr;

	if (count <= 1)
	{
		var = 0;
		hr = E_FAIL;

		if (count)
		{
			var = interpreter->DataStack;
			interpreter->DataStack = var->Next;
			if (var->Value->vt != VT_BSTR)
				hr = DISP_E_TYPEMISMATCH;
			else
			{
				if (!SetCurrentDirectoryW(var->Value->bstrVal))
err:				interpreter->Parent->LastSysError = GetLastError();
				else
					hr = S_OK;
			}
			if (var) freeScriptVariant(var);
		}
		else
		{
			WCHAR	buffer[MAX_PATH];

			if (!GetCurrentDirectoryW(MAX_PATH, &buffer[0])) goto err;

			if (!(var = getScriptVariant(0)))
badmem:			return(E_OUTOFMEMORY);

			var->Value->vt = VT_BSTR;
			if (!(var->Value->bstrVal = SysAllocString(&buffer[0])))
			{
				freeScriptVariant(var);
				goto badmem;
			}

			var->Next = interpreter->DataStack;
			interpreter->DataStack = var;

			hr = S_OK;
		}
	}
	else
		hr = DISP_E_BADPARAMCOUNT;

	return(hr);
}

/************************** open() ***************************
 * Opens a file.
 *
 * handle = open(name, type, attributes)
 *
 * name =	The name of the file.
 * type =	'r' = read, 'w' = write. If omitted, r is assumed.
 *			's' = shared read. 'S' = shared write.
 *			'n' = CREATE_NEW, 'e' = OPEN_EXISTING,
 *			'c' = CREATE_ALWAYS, 'o' = OPEN_ALWAYS,
 *			't' = TRUNCATE_EXISTING
 */

static HRESULT C_open(CINTERPRETER *interpreter, DWORD count)
{
	return(S_OK);
}

/************************** read() *************************
 * Reads bytes from a file opened with open().
 *
 * amountread = read(handle, variable, amount)
 *
 * handle =	The file handle gotten from open().
 * variable = Name of the variable to set to the bytes.
 * amount = Number of bytes to read. If omitted, 1 is assumed.
 */

static HRESULT C_read(CINTERPRETER *interpreter, DWORD count)
{
	return(S_OK);
}

/************************** write() *************************
 * Writes bytes to a file opened with open().
 *
 * amountwritten = write(handle, data, amount)
 *
 * handle =	The file handle gotten from open().
 * data = The data to write.
 * amount = Number of bytes to write. If omitted, 1 is assumed.
 */

static HRESULT C_write(CINTERPRETER *interpreter, DWORD count)
{
	return(S_OK);
}

/************************** seek() *************************
 * Seeks bytes within a file opened with open().
 *
 * newposition = seek(handle, amount, anchor)
 *
 * handle =	The file handle gotten from open().
 * amount = Number of bytes to seek. If omitted, 1 is assumed.
 * anchor = 1 = current, 0 = start, -1 = end. If omitted,
 *			1 is assumed.
 */

static HRESULT C_seek(CINTERPRETER *interpreter, DWORD count)
{
	return(S_OK);
}

/************************** close() *************************
 * Closes a file opened with open().
 *
 * close(handle)
 *
 * handle =	The file handle gotten from open(). If omitted,
 * all open files are closed.
 */

static HRESULT C_close(CINTERPRETER *interpreter, DWORD count)
{
	return(S_OK);
}

/************************** mkdir() *************************
 * Creates a directory.
 *
 * mkdir(name)
 *
 * name =	Name of the directory to create.
 */

static HRESULT C_mkdir(CINTERPRETER *interpreter, DWORD count)
{
	return(S_OK);
}

/************************** rmdir() *************************
 * Deletes a directory.
 *
 * rmdir(name)
 *
 * name =	Name of the directory to delete.
 */

static HRESULT C_rmdir(CINTERPRETER *interpreter, DWORD count)
{
	return(S_OK);
}

/************************** getenv() *************************
 * Gets the value of an environment variable.
 *
 * getenv(name)
 *
 * name =	Name of the environment variable.
 */

static HRESULT C_getenv(CINTERPRETER *interpreter, DWORD count)
{
	return(S_OK);
}

/************************** putenv() *************************
 * Sets the value of an environment variable.
 *
 * putenv(name, value)
 *
 * name =	Name of the environment variable.
 * value =	Value.
 */

static HRESULT C_putenv(CINTERPRETER *interpreter, DWORD count)
{
	return(S_OK);
}

/************************** free() ***************************
 * Frees a block of memory allocated with malloc().
 *
 * free(block)
 * free("name", type)
 *
 * block =	The mem to free.
 */

static HRESULT C_free(CINTERPRETER *interpreter, DWORD count)
{
	register HRESULT	hr;

	if (count && count <= 2)
	{
		register SCRIPTVARIANT	*var;

		// Get the type, or block, arg
		var = interpreter->DataStack;
		interpreter->DataStack = var->Next;
		if (count == 1)
			 clearVariant(var->Value);
		else
		{
			register CSYMBOL	*symbol;

			freeScriptVariant(var);

			// Get the variable name
			var = interpreter->DataStack;
			interpreter->DataStack = var->Next;
			if (var->Value->vt != VT_BSTR)
			{
				hr = DISP_E_TYPEMISMATCH;
				freeScriptVariant(var);
				goto out;
			}

			// Get the CSYMBOL for this variable
			if ((symbol = searchSymbolTables(interpreter, var->Value->bstrVal)))
				clearVariant(&symbol->SymbolValue);

			freeScriptVariant(var);
		}

		hr = S_OK;
	}
	else
		hr = DISP_E_BADPARAMCOUNT;
out:
	return(hr);
}

static long get_long(CINTERPRETER *interpreter, HRESULT *hr)
{
	register SCRIPTVARIANT	*var;
	VARIANT					temp;

	// Pull the value off of the stack
	var = interpreter->DataStack;
	interpreter->DataStack = var->Next;

	// Make sure it's a long and return it
	*hr = VariantChangeType(&temp, var->Value, 0, VT_I4);

	return(temp.lVal);
}

static long get_ulong(CINTERPRETER *interpreter, HRESULT *hr)
{
	register SCRIPTVARIANT	*var;
	VARIANT					temp;

	// Pull the value off of the stack
	var = interpreter->DataStack;
	interpreter->DataStack = var->Next;

	// Make sure it's a unsigned long and return it
	*hr = VariantChangeType(&temp, var->Value, 0, VT_UI4);

	return(temp.ulVal);
}

/************************** malloc() ***************************
 * Allocates a block of memory.
 *
 * block = malloc(size)
 *
 * size =	The number of bytes to allocate.
 *
 * error = malloc("name", size)
 *
 * name = The name of the variable where the block will be stored.
 *		  The size of the block depends upon the variable's
 *		  datatype.
 * size = How many instances of the block should be allocated in
 *		  an array.
 */

static HRESULT C_malloc(CINTERPRETER *interpreter, DWORD count)
{
	register DWORD	size;
	HRESULT			hr;

	if (count && count <= 2)
	{
		register SCRIPTVARIANT	*var;

		// We need a SCRIPTVARIANT to return the block, or error result
		if (!(var = getScriptVariant(0)))
		{
			hr = E_OUTOFMEMORY;
			goto out;
		}

		if (count == 1)
		{
			// Get the size
			if (!(size = get_ulong(interpreter, &hr)))
			{
badcount:		hr = DISP_E_TYPEMISMATCH;
free:			freeScriptVariant(var);
				goto out;
			}

			// Allocate the memory
			if ((var->Value->bstrVal = ALLOCMEM(size)))
				var->Value->vt = VT_VECTOR|VT_BSTR;

			// If a memory failure, return VT_NOTHING
		}
		else
		{
			register CSYMBOL	*symbol;
			SCRIPTVARIANT		*name;

			if (!(size = get_ulong(interpreter, &hr))) goto badcount;

			// Get the variable name where to store the block
			name = interpreter->DataStack;
			interpreter->DataStack = name->Next;
			if (name->Value->vt != VT_BSTR)
			{
				hr = DISP_E_TYPEMISMATCH;
free2:			freeScriptVariant(name);
				goto free;
			}

			// Get the CSYMBOL for this variable. Note: We can store a block
			// only to a variable in one of our CINTERPRETERs
			if (!(symbol = searchSymbolTables(interpreter, name->Value->bstrVal)))
			{
				hr = DISP_E_UNKNOWNNAME;
				goto free2;
			}

			clearVariant(&symbol->SymbolValue);

			// Adjust the size to reflect how many items we're allocating
			switch (symbol->Flags & 0x00FF)
			{
				case VT_I2:
				case VT_UI2:
					count = sizeof(short);
					break;

				case VT_I4:
				case VT_UI4:
					count = sizeof(long);
					break;

				case VT_R4:
					count = 4;
					break;

				case VT_R8:
					count = 8;
					break;

				case VT_BSTR:
				{
					if (!(symbol->Flags & SYMTYPE_8BIT))
					{	
						count = sizeof(OLECHAR);
						break;
					}

					// Fall through
				}

				default:
//				case VT_I1:
//				case VT_UI1:
					count = sizeof(char);
			}

			count *= size;

			// Allocate the memory
			if ((symbol->SymbolValue.bstrVal = ALLOCMEM(count)))
				symbol->SymbolValue.vt = VT_VECTOR|(symbol->Flags && 0x00FF);

			freeScriptVariant(name);
		}

		// Success
		hr = S_OK;

		// Push the return on the stack
		var->Next = interpreter->DataStack;
		interpreter->DataStack = var;
	}
	else
		hr = DISP_E_BADPARAMCOUNT;
out:
	return(hr);
}

/************************** memset() ***************************
 * Sets a block of memory to a certain value. Alternately, can
 * set a variable's value.
 *
 * memset(block, length, value)
 * memset(&varName, length, value)
 *
 * block =	Memblock handle.
 * length =	Length of block. If omitted, the block must either
 *			be a char string, or allocated with malloc().
 * value =	Value to set. If omitted, 0.
 */

static HRESULT C_memset(CINTERPRETER *interpreter, DWORD count)
{
	register SCRIPTVARIANT	*var;
	register HRESULT		hr;
	DWORD					value;
	void					*block;
	VARIANT					temp;

	if (count <= 3)
	{
		value = 0;
		temp.vt = VT_EMPTY;

		// Did he supply the value?
		if (count > 2)
		{
			// If a BSTR, get the first char as the value
			var = interpreter->DataStack;
			interpreter->DataStack = var->Next;
			if (var->Value->vt == VT_BSTR)
				value = (DWORD)var->Value->bstrVal[0];
			else
			{
				// If not a BSTR, get the value as VT_I4
				if ((hr = VariantChangeType(&temp, var->Value, 0, VT_I4)))
				{
error:				freeScriptVariant(var);
					return(hr);
				}
				value = (DWORD)temp.lVal;
			}

			freeScriptVariant(var);
		}

		var = interpreter->DataStack;
		interpreter->DataStack = var->Next;

		// Did he supply the length?
		if (count)
		{
			if ((hr = VariantChangeType(&temp, var->Value, 0, VT_UI4))) goto error;
			count = (DWORD)temp.ulVal;
			freeScriptVariant(var);

			// Get the handle arg
			var = interpreter->DataStack;
			interpreter->DataStack = var->Next;

			// Make sure we have either a variable name or malloc() block
			if (var->Value->vt != VT_BSTR || !(var->Value->vt & VT_VECTOR))
			{
badtype:		hr = DISP_E_TYPEMISMATCH;
				goto error;
			}

			block = var->Value->bstrVal;

			if (!(var->Value->vt & VT_VECTOR) && count > SysStringByteLen(block))
			{
				hr = INVALID_REFERENCE;
				goto error;
			}
		}
		else
		{
			if (var->Value->vt != VT_BSTR) goto badtype;
			block = var->Value->bstrVal;
			count = SysStringByteLen(block);
		}

		memset(block, value, count);

		freeScriptVariant(var);

		return(S_OK);
	}

	return(DISP_E_BADPARAMCOUNT);
}

/************************** remove() ***************************
 * Deletes a file.
 *
 * remove(name, type)
 *
 * name =	The name of the file.
 * type =	
 */

static HRESULT C_remove(CINTERPRETER *interpreter, DWORD count)
{
	return(S_OK);
}


/************************* filelength() ************************
 * Get the size of a file.
 *
 * filelength(file, type)
 *
 * file =	The name of the file, or a handle gotten from open().
 * type =	1 if file is a handle, or 0 otherwise.	
 */

static HRESULT C_filelength(CINTERPRETER *interpreter, DWORD count)
{
	return(S_OK);
}

/************************** rename() **************************
 * Renames a file.
 *
 * rename(name, newname)
 *
 * name =	The original name of the file.
 * newname = The new name.
 */

static HRESULT C_rename(CINTERPRETER *interpreter, DWORD count)
{
	return(S_OK);
}

/************************** strcat() ***************************
 * Appends a string to a memory block.
 *
 * strcat(handle, string)
 */

static HRESULT C_strcat(CINTERPRETER *interpreter, DWORD count)
{
	return(S_OK);
}

/************************** strchr() ***************************
 * Returns the position of a specific char within a memory block.
 *
 * strchr(handle, char)
 */

static HRESULT C_strchr(CINTERPRETER *interpreter, DWORD count)
{
	return(S_OK);
}

/************************** strrchr() **************************
 * Returns the position of the rightmost occurence of a
 * specific char within a memory block.
 *
 * strrchr(handle, char)
 */

static HRESULT C_strrchr(CINTERPRETER *interpreter, DWORD count)
{
	return(S_OK);
}

/************************** strcmp() ***************************
 * Compares the strings within 2 memory buffers.
 *
 * result = strcmp(handle1, handle2, count)
 *
 * handle1 =	The first memory buffer handle.
 * handle2 =	The second memory buffer handle. If omitted, then
 *				a zeroed memory buffer of the same size as handle1
 *				is assumed.
 * count =		The number of bytes to limit comparison. If omitted,
 *				then buffers are compared upto any embedded nul.
 * sensitive =	1 if non-case-sensitive, or 0 otherwise. If omitted,
 *				0 is assumed.
 *
 * RETURNS: 0 if equal, 1 if handle1 > handle2, or -1 otherwise.
 */

static HRESULT C_strcmp(CINTERPRETER *interpreter, DWORD count)
{
	return(S_OK);
}

/************************* strcpy() ***************************
 * Copies a string to a memory block.
 *
 * strcpy(handle, string)
 */

static HRESULT C_strcpy(CINTERPRETER *interpreter, DWORD count)
{
	return(S_OK);
}

/************************** strdup() ***************************
 * Duplicates a memory block.
 *
 * newhandle = strdup(handle)
 */

static HRESULT C_strdup(CINTERPRETER *interpreter, DWORD count)
{
	return(S_OK);
}

/************************* strlen() ***************************
 * Returns the char length of a memory block.
 *
 * newhandle = strlen(handle)
 */

static HRESULT C_strlen(CINTERPRETER *interpreter, DWORD count)
{
	return(S_OK);
}

/************************* strstr() ***************************
 * Returns the position of a specific string within a memory block.
 *
 * strstr(handle, string)
 */

static HRESULT C_strstr(CINTERPRETER *interpreter, DWORD count)
{
	return(S_OK);
}

/************************* system() **************************
 * Launches an executable.
 *
 * system(exeName)
 */

static HRESULT C_system(CINTERPRETER *interpreter, DWORD count)
{
	return(S_OK);
}

/************************ atodata() **************************
 * Converts a variable's value to some other datatype.
 *
 * error = atodata(variableName, newType)
 */

static HRESULT C_atodata(CINTERPRETER *interpreter, DWORD count)
{
	return(S_OK);
}

/************************* memmove() *************************
 * Copies bytes within a memory block.
 *
 * memmove(handle, origPosition, newPosition, count)
 */

static HRESULT C_memmove(CINTERPRETER *interpreter, DWORD count)
{
	return(S_OK);
}

/************************* sprintf() *************************
 * Formats a string within a memory buffer.
 *
 * sprintf(handle, formatSpec, ...)
 */

static HRESULT C_sprintf(CINTERPRETER *interpreter, DWORD count)
{
	return(S_OK);
}

/************************* tolower() *************************
 * Converts a buffer to lower case.
 *
 * tolower(handle)
 */

static HRESULT C_tolower(CINTERPRETER *interpreter, DWORD count)
{
	return(S_OK);
}

/************************* toupper() *************************
 * Converts a buffer to upper case.
 *
 * toupper(handle)
 */

static HRESULT C_toupper(CINTERPRETER *interpreter, DWORD count)
{
	return(S_OK);
}

/************************ strerror() *************************
 * Returns the last error number.
 *
 * errorNum = strerror()
 * message = strerror(errorNum)
 */

static HRESULT C_strerror(CINTERPRETER *interpreter, DWORD count)
{
	if (count <= 1)
	{
		register SCRIPTVARIANT	*var;

		if (count)
		{
			// Get the error #
			{
			register SCRIPTVARIANT	*error;
			VARIANT					errorNum;

			error = interpreter->DataStack;
			interpreter->DataStack = error->Next;
			errorNum.vt = VT_EMPTY;
			if ((count = VariantChangeType(&errorNum, error->Value, 0, VT_I4))) return(count);
			count = errorNum.lVal;
			}

			// Get the error message
			{
			WCHAR			buffer[256];
			register WCHAR	*ptr;

			FormatMessageW(FORMAT_MESSAGE_FROM_SYSTEM, 0, count, MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT), &buffer[0], 256, 0);

			// Make sure that there aren't any EOL chars in it
			ptr = &buffer[0];
			while (*ptr)
			{
				if (*ptr < ' ') *ptr = ' ';
				++ptr;
			}

			// Get a SCRIPTVARIANT with the BSTR error message and push it on the data stack
			if (!(var = getScriptVariant(0)))
badmem:			return(E_OUTOFMEMORY);
			var->Value->vt = VT_BSTR;
			if (!(var->Value->bstrVal = SysAllocString(&buffer[0])))
			{
				freeScriptVariant(var);
				goto badmem;
			}
			}
		}
		else
		{
			// Return the LastSysError #
			if (!(var = getScriptVariant(0))) goto badmem;
			var->Value->vt = VT_I4;
			var->Value->lVal = interpreter->Parent->LastSysError;
		}

		var->Next = interpreter->DataStack;
		interpreter->DataStack = var;

		return(S_OK);
	}

	return(DISP_E_BADPARAMCOUNT);
}

/*********************** splitpath() *************************
 * Splits a path into parts.
 *
 * splitpath(path, drive, dir, name, ext)
 *
 * path = The full path.
 * drive =	Name of variable where to store the drive.
 */

static HRESULT C_splitpath(CINTERPRETER *interpreter, DWORD count)
{
	return(S_OK);
}

/*********************** CreateObject() *************************
 * Creates an instance of some COM object.
 *
 * object = CreateObject(ProdID)
 *
 */

static HRESULT C_CreateObject(CINTERPRETER *interpreter, DWORD count)
{
	return(S_OK);
}

















// Names of built-in functions. These must match the order of Functions[]
static const WCHAR Names[] =	{2, 'c','d', 0,
4, 'f','r','e','e', 0,
4, 'o','p','e','n', 0,
4, 'r','e','a','d', 0,
4, 's','e','e','k', 0,
5, 'c','l','o','s','e', 0,
5, 'm','k','d','i','r', 0,
5, 'r','m','d','i','r', 0,
5, 'w','r','i','t','e', 0,
6, 'g','e','t','e','n','v', 0,
6, 'm','a','l','l','o','c', 0,
6, 'm','e','m','s','e','t', 0,
6, 'm','s','g','b','o','x', 0,
6, 'p','u','t','e','n','v', 0,
6, 'r','e','m','o','v','e', 0,
6, 'r','e','n','a','m','e', 0,
6, 's','t','r','c','a','t', 0,
6, 's','t','r','c','h','r', 0,
6, 's','t','r','c','m','p', 0,
6, 's','t','r','c','p','y', 0,
6, 's','t','r','c','a','t', 0,
6, 's','t','r','d','u','p', 0,
6, 's','t','r','l','e','n', 0,
6, 's','t','r','s','t','r', 0,
6, 's','y','s','t','e','m', 0,
7, 'a','t','o','d','a','t','a', 0,
7, 'm','e','m','m','o','v','e', 0,
7, 's','p','r','i','n','t','f', 0,
7, 's','t','r','r','c','h','r', 0,
7, 't','o','l','o','w','e','r', 0,
7, 't','o','u','p','p','e','r', 0,
8, 's','t','r','e','r','r','o','r', 0,
9, 's','p','l','i','t','p','a','t','h', 0,
10, 'f','i','l','e','l','e','n','g','t','h', 0,
12, 'C','r','e','a','t','e','O','b','j','e','c','t', 0,
(WCHAR)-1};

BuiltinFuncPtr * Functions[MAX_BUILTINS] = {C_cd,
C_free,
C_open,
C_read,
C_seek,
C_close,
C_mkdir,
C_rmdir,
C_write,
C_getenv,
C_malloc,
C_memset,
C_msgbox,
C_putenv,
C_remove,
C_rename,
C_strcat,
C_strchr,
C_strcmp,
C_strcpy,
C_strdup,
C_strlen,
C_strstr,
C_system,
C_atodata,		// Converts a string to some other datatype and stores it in the specified variable
C_memmove,
C_sprintf,
C_strrchr,
C_tolower,
C_toupper,
C_strerror,
C_splitpath,
C_filelength,
C_CreateObject};

/*********************** lookupBuiltin() ************************
 * Checks if the specified name matches the name of one of our
 * built-in functions.
 *
 * RETURNS: A pointer to the function to call if a match, or 0
 * otherwise.
 */

BuiltinFuncPtr * lookupBuiltin(LPOLESTR name, BuiltinFuncPtr **store)
{
	register BuiltinFuncPtr			**funcs;
	register const WCHAR			*funcNames;
	register unsigned short			size;
	int								result;

	size = lstrlenW(name);

	// Check the Identifier against builtin function names
	funcs = &Functions[0];
	funcNames = &Names[0];
	while ((unsigned short)(*funcNames) <= size)
	{
		if (*funcNames == size)
		{
			if (!(result = memcmp(name, funcNames + 1, size * sizeof(WCHAR))))
			{
				*store = (BuiltinFuncPtr *)funcs;
				return(*funcs);
			}

			if (result < 0) break;
		}

		funcNames += (*funcNames + 2);
		++funcs;
	}

	return(0);
}
