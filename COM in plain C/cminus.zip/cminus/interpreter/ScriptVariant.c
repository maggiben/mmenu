/*
 * Functions that operate upon a SCRIPTVARIANT, which is a wrapper
 * for a VARIANT. Its primary purpose is to indicate which
 * VARIANTs we have allocated versus VARIANTs that are supplied
 * by the host.
 */

// NOTE: The VariantClear()s here should be replaced with clearVariant(),
// but we also need to modify routines to handle a VARIANT with VT_VECTOR!!!
// For now, let's just assume that a user would not perform direct math
// operations and such upon blocks allocated via malloc(). It is assumed
// that malloc would be used only with calling some DLL that is not really
// COM aware such as an operating system function.

#define INC_OLE2
#define CONST_VTABLE
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <objbase.h>
#include "../Mem.h"
#include "../TraceWin.h"
#include "ScriptVariant.h"


static HRESULT convertToNumeric(VARIANT *, SCRIPTVARIANT *, VARIANT *);
extern void clearVariant(VARIANT *);


static const WCHAR Pointer[] =  L" *";





/********************** getScriptVariant() ********************
 * Allocates/Initializes a SCRIPTVARIANT.
 *
 * ptr =	A VARIANT to wrap, or 0 if a new VARIANT should be
 *			created.
 *
 * RETURNS: Pointer to new SCRIPTVARIANT, or 0 if memory fail.
 *
 * If a new VARIANT is created, then it will be freed by
 * freeScriptVariant().
 */

SCRIPTVARIANT * getScriptVariant(VARIANT *ptr)
{
	register SCRIPTVARIANT	*var;

	// Get a SCRIPTVARIANT to wrap the VARIANT, and a VARIANT
	if ((var = (SCRIPTVARIANT *)ALLOCMEM(ptr ? sizeof(SCRIPTVARIANT) : sizeof(SCRIPTVARIANT) + sizeof(VARIANT))))
	{
		// Set the pointer to the VARIANT
		if (!(var->Value = ptr))
		{
			// Caller didn't supply the VARIANT to wrap, so we allocated the VARIANT
			// appended directly after the SCRIPTVARIANT. This VARIANT will be
			// deleted in freeScriptVariant()
			var->Value = (VARIANT *)((unsigned char *)var + sizeof(SCRIPTVARIANT));

			// Initialize the VARIANT as empty
			VariantInit(var->Value);
		}
	}

	return(var);
}





/******************* getScriptVariantFromStr() *****************
 * Allocates/Initializes a SCRIPTVARIANT with a new VT_BSTR
 * VARIANT.
 *
 * str =	The BSTR to wrap by the VARIANT.
 *
 * RETURNS: Pointer to new SCRIPTVARIANT, or 0 if memory fail.
 *
 * The VARIANT will be freed by freeScriptVariant().
 */
/*
SCRIPTVARIANT * getScriptVariantFromStr(LPCOLESTR str)
{
	register SCRIPTVARIANT	*var;

	if ((var = getScriptVariant(0)))
	{
		if ((var->Value->bstrVal = SysAllocString(str)))
			var->Value->vt = VT_BSTR;
		else
		{
			FREEMEM(var);
			var = 0;
		}
	}

	return(var);
}
*/




/******************* freeScriptVariant() *****************
 * Frees a SCRIPTVARIANT.
 *
 * var =	The SCRIPTVARIANT to free.
 */

void freeScriptVariant(SCRIPTVARIANT *var)
{
	// If we allocated the VARIANT appended to this SCRIPTVARIANT, then clear
	// the VARIANT. Otherwise, this VARIANT is someone else's, and must not be
	// freed
	if (var->Value == (VARIANT *)((unsigned char *)var + sizeof(SCRIPTVARIANT)))
		clearVariant(var->Value);

	FREEMEM(var);
}





/********************** isResultTrue() ********************
 * Tests if a VARIANT's value == 1.
 *
 * RETURNS: 1 if the value is 1, or 0 otherwise.
 */

BOOL isResultTrue(SCRIPTVARIANT *var)
{
	VARIANT			temp;

	if (var->Value->vt & VT_VECTOR)
	{
		if (var->Value->bstrVal) return(1);
	}
	else
	{
		temp.vt = VT_EMPTY;

		// Attempt to convert the comparison value to double
		if (!VariantChangeType(&temp, var->Value, 0, VT_R8))
			return(temp.dblVal != 0.0);
	}

	return(0);
}





/********************* makeTypeString() ********************
 * Creates a string that indicates the VARIANT's datatype.
 * This is typically used by the host to display the
 * datatype to the user.
 *
 * var =	The VARIANT to make a type string from.
 *
 * RETURNS: A BSTR, or 0 if memory fail.
 *
 * NOTE: Caller must free the BSTR.
 */

BSTR makeTypeString(VARIANT *var)
{
	WCHAR					buffer[80];
	register const WCHAR	*ptr;

	switch (var->vt & ~VT_BYREF)
	{
		case VT_EMPTY:
			ptr = L"Unitialized";
			break;

		case VT_UI1:
			ptr =  L"char";
			break;

		case VT_I2:
			ptr =  L"short";
			break;

		case VT_I4:
			ptr = L"long";
			break;

		case VT_R4:
			ptr = L"float";
			break;

		case VT_R8:
			ptr = L"double";
			break;

		case VT_BOOL:
			ptr = L"bool";
			break;

		case VT_ERROR:
			ptr = L"long";
			break;

		case VT_BSTR:
			ptr = L"string";
			break;

		case VT_DISPATCH:
		case VT_UNKNOWN:
			ptr = L"object";
			break;

		default:
			ptr = L"Unprintable type";
			goto out;
	}

	lstrcpyW(&buffer[0], ptr);
	if (var->vt & VT_BYREF) lstrcatW(&buffer[0], &Pointer[0]);
out:
	return(SysAllocString(&buffer[0]));
}





/********************* variantToString() ********************
 * Creates a string that indicates the VARIANT's value.
 * This is typically used by the host to display the
 * value to the user.
 *
 * var =	The VARIANT to make a value string from.
 *
 * RETURNS: A BSTR, or 0 if memory fail.
 *
 * NOTE: Caller must free the BSTR.
 */

BSTR variantToString(VARIANT *var)
{
	VARIANT		temp;

	temp.vt = VT_EMPTY;

	// Change the VARIANT's value to a BSTR
	if (!VariantChangeType(&temp, var, 0, VT_BSTR))
	{
		// Return the BSTR. NOTE: We don't VariantClear() temp because
		// we're giving the BSTR to the caller
		return(temp.bstrVal);
	}

	// Return an empty string for the value if it can't be expressed as a BSTR
	return(SysAllocString(&Pointer[2]));
}





// ========================== Logical Operations ======================

HRESULT LeftShiftOperation(VARIANT *var1, SCRIPTVARIANT *scriptVar2, VARIANT *result)
{
	VARIANT				temp1;
	VARIANT				temp2;
	register HRESULT	hr;
	register VARIANT	*var2;

	var2 = scriptVar2->Value;

	// Create some temporaries
	temp1.vt = temp2.vt = VT_EMPTY;

	// Attempt to convert the shift value to long
	if (!(hr = VariantChangeType(&temp2, var2, 0, VT_I4)))
	{
		// If a VT_BSTR, then shift that many chars from the head
		// of the string
		if (var1->vt == VT_BSTR)
		{
			temp1.lVal = SysStringLen(var1->bstrVal);
			if (temp2.lVal >= temp1.lVal) temp2.lVal = temp1.lVal;

			if (!(temp1.bstrVal = SysAllocStringLen(var1->bstrVal, temp2.lVal)))
				hr = E_OUTOFMEMORY;

			if (result == var1) SysFreeString(result->bstrVal);
			result->vt = VT_BSTR;
			result->bstrVal = temp1.bstrVal;
		}

		else if (!(hr = VariantChangeType(&temp1, var1, 0, VT_I4)))
		{
			// Do the operation and return the result in var1
			VariantClear(result);

			result->vt = VT_I4;
			result->lVal = temp1.lVal << temp2.lVal;
		}
	}

	return(hr);
}

HRESULT RightShiftOperation(VARIANT *var1, SCRIPTVARIANT *scriptVar2, VARIANT *result)
{
	VARIANT				temp1;
	VARIANT				temp2;
	register HRESULT	hr;
	register VARIANT	*var2;

	var2 = scriptVar2->Value;

	temp1.vt = temp2.vt = VT_EMPTY;

	if (!(hr = VariantChangeType(&temp2, var2, 0, VT_I4)))
	{
		// If a VT_BSTR, then shift that many chars from the end
		// of the string
		if (var1->vt == VT_BSTR)
		{
			temp1.lVal = SysStringLen(var1->bstrVal);
			if (temp2.lVal >= temp1.lVal)
			{
				temp2.lVal = temp1.lVal;
				temp1.lVal = 0;
			}
			else
				temp1.lVal -= temp2.lVal;

			if (!(temp1.bstrVal = SysAllocStringLen(&var1->bstrVal[temp1.lVal], temp2.lVal)))
				hr = E_OUTOFMEMORY;

			if (result == var1) SysFreeString(result->bstrVal);
			result->vt = VT_BSTR;
			result->bstrVal = temp1.bstrVal;
		}

		else if (!(hr = VariantChangeType(&temp1, var1, 0, VT_I4)))
		{
			VariantClear(result);

			result->vt = VT_I4;
			result->lVal = temp1.lVal >> temp2.lVal;
		}
	}

	return(hr);
}

HRESULT BitOrOperation(VARIANT *var1, SCRIPTVARIANT *scriptVar2, VARIANT *result)
{
	VARIANT				temp1;
	VARIANT				temp2;
	register HRESULT	hr;
	register VARIANT	*var2;

	var2 = scriptVar2->Value;

	// Create some temporaries
	temp1.vt = temp2.vt = VT_EMPTY;

	// Attempt to convert the comparison values to numeric
	if (!(hr = VariantChangeType(&temp1, var1, 0, VT_I4)) && !(hr = VariantChangeType(&temp2, var2, 0, VT_I4)))
	{
		// Do the operation and return the result in var1
		VariantClear(result);

		result->vt = VT_I4;
		result->lVal = temp1.lVal | temp2.lVal;
	}

	return(hr);
}

HRESULT BitAndOperation(VARIANT *var1, SCRIPTVARIANT *scriptVar2, VARIANT *result)
{
	VARIANT				temp1;
	VARIANT				temp2;
	register HRESULT	hr;
	register VARIANT	*var2;

	var2 = scriptVar2->Value;

	temp1.vt = temp2.vt = VT_EMPTY;

	if (!(hr = VariantChangeType(&temp1, var1, 0, VT_I4)) && !(hr = VariantChangeType(&temp2, var2, 0, VT_I4)))
	{
		VariantClear(result);

		result->vt = VT_I4;
		result->lVal = temp1.lVal & temp2.lVal;
	}

	return(hr);
}

HRESULT BitXorOperation(VARIANT *var1, SCRIPTVARIANT *scriptVar2, VARIANT *result)
{
	VARIANT				temp1;
	VARIANT				temp2;
	register HRESULT	hr;
	register VARIANT	*var2;

	var2 = scriptVar2->Value;

	// Create some temporaries
	temp1.vt = temp2.vt = VT_EMPTY;

	// Attempt to convert the comparison values to numeric
	if (!(hr = VariantChangeType(&temp1, var1, 0, VT_I4)) && !(hr = VariantChangeType(&temp2, var2, 0, VT_I4)))
	{
		// Do the operation and return the result in var1
		VariantClear(result);

		result->vt = VT_I4;
		result->lVal = temp1.lVal ^ temp2.lVal;
	}

	return(hr);
}





/************************ OrTest() ********************
 * Tests if the value of either of 2 VARIANTs is 1.
 */

HRESULT OrTest(VARIANT *var1, SCRIPTVARIANT *scriptVar2, VARIANT *result)
{
	VARIANT				temp1;
	VARIANT				temp2;
	register HRESULT	hr;
	register VARIANT	*var2;

	var2 = scriptVar2->Value;

	temp1.vt = temp2.vt = VT_EMPTY;

	if (!(hr = VariantChangeType(&temp1, var1, 0, VT_R8)) && !(hr = VariantChangeType(&temp2, var2, 0, VT_R8)))
	{
		VariantClear(result);

		result->vt = VT_R8;
		result->dblVal = temp1.dblVal || temp2.dblVal;
	}

	return(hr);
}





/************************ AndTest() *******************
 * Tests if the value of both VARIANTs are 1.
 */

HRESULT AndTest(VARIANT *var1, SCRIPTVARIANT *scriptVar2, VARIANT *result)
{
	VARIANT				temp1;
	VARIANT				temp2;
	register HRESULT	hr;
	register VARIANT	*var2;

	var2 = scriptVar2->Value;

	temp1.vt = temp2.vt = VT_EMPTY;

	if (!(hr = VariantChangeType(&temp1, var1, 0, VT_R8)) && !(hr = VariantChangeType(&temp2, var2, 0, VT_R8)))
	{
		VariantClear(result);

		result->vt = VT_R8;
		result->dblVal = temp1.dblVal && temp2.dblVal;
	}

	return(hr);
}





/********************** EqualComparison() ****************
 * Tests if the 2 VARIANTs have the same value.
 *
 * Sets var1->vt to VT_R4, and var1->lVal to
 * 1 if equal, or 0 if not equal.
 */

HRESULT EqualComparison(VARIANT *var1, SCRIPTVARIANT *scriptVar2, VARIANT *result)
{
	register HRESULT	hr;
	register VARIANT	*var2;

	var2 = scriptVar2->Value;

	// If both operands are VT_BSTR, then do a string compare
	if (var1->vt == VT_BSTR && var2->vt == VT_BSTR)
	{
		hr = (long)SysStringByteLen(var1->bstrVal);
		if (hr == (long)SysStringByteLen(var2->bstrVal))
			hr = (memcmp(var1->bstrVal, var2->bstrVal, hr) == 0);
		else
			hr = 0;
		VariantClear(result);
		result->vt = VT_R4;
		result->lVal = hr;
		hr = S_OK;
	}

	// If numeric, then convert to the larger data type and do a numeric compare
	else if (!(hr = convertToNumeric(var1, scriptVar2, result)))
	{
		result->vt = VT_I4;
		var2 = scriptVar2->Value;

		switch (var1->vt)
		{
			case VT_I2:
			case VT_UI2:
				result->lVal = var1->uiVal == var2->uiVal;
				break;

			case VT_I4:
			case VT_UI4:
				result->lVal = var1->ulVal == var2->ulVal;
				break;

			case VT_R4:
				result->lVal = var1->fltVal == var2->fltVal;
				break;

			case VT_R8:
				result->lVal = var1->dblVal == var2->dblVal;
				break;

			default:
			//case VT_I1:
			//case VT_UI1:
				result->lVal = var1->bVal == var2->bVal;
		}
	}

	return(hr);
}





/********************** convertToNumeric() ****************
 * Converts two SCRIPTVARIANTs so they are the same, numeric
 * C datatype.
 *
 * NOTE: The SCRIPTVARIANTs are converted in place. Caller
 * must pass a copy if the original must not be changed.
 *
 * NOTE: The relationship between C numeric datatypes and
 * VARIANT VT_ defines is as follows:
 *
 * VT_I2 = short
 * VT_I4 = long
 * VT_R4 = float
 * VT_R8 = double
 * VT_I1 = char
 * VT_UI1 = unsigned char
 * VT_UI2 = unsigned short
 * VT_UI4 = unsigned long
 */

static HRESULT convertToNumeric(VARIANT *var1, SCRIPTVARIANT *scriptVar2, VARIANT *result)
{
	register VARIANT		*var2;
	register unsigned char	type1;

	var2 = scriptVar2->Value;

	{
	register unsigned char	type2;

	type1 = (unsigned char)var1->vt;
	type2 = (unsigned char)var2->vt;

	// See if var1 is a numeric data type
	if ((type1 >= VT_I2 && type1 <= VT_R8) || (type1 >= VT_I1 && type1 <= VT_UI4))
	{
		// If var2 is the same data type, then no conversion is needed
		if (type2 == type1)
done:		return(S_OK);

		// If var2 isn't a numeric type, then we'll have to assume the largest numeric format needed
		// and perform conversion
		if ((type2 >= VT_I2 && type2 <= VT_R8) || (type2 >= VT_I1 && type2 <= VT_UI4))
		{
			// Both VARIANTs are numeric types, but aren't the same type. So we need to find
			// the larger of the two and also respect the sign.

			// Is var2 signed?
			if (type2 < VT_UI1)
			{
				// If var1's type is unsigned, then convert it to signed
				if (type1 >= VT_UI2)
					type1 -= (VT_UI2 - VT_I2);
				else
					--type1;

				// Both var1 and var2 are now signed. If they've ended up being the same
				// datatype, no further conversion is necessary
dosigned:		if (type2 == type1) goto done;

				// Find the larger of the two datatypes and perform the conversion on the
				// smaller
				if (type1 == VT_I1 || type1 < type2)
				{
					// var1 is smaller
convertvar1:		return(VariantChangeType(var1, var1, 0, type2));
				}

				// var2 is smaller. NOTE: We must use the result VARIANT if var2 is a
				// VARIANT borrowed from someone else. We can't alter the original then
convertvar2:	if (((unsigned char *)scriptVar2 + sizeof(SCRIPTVARIANT)) != (unsigned char *)var2)
				{
					CopyMemory(result, var2, sizeof(VARIANT));
					scriptVar2->Value = var2 = result;
				}

				return(VariantChangeType(var2, var2, 0, type1));
			}

			// If var1 is signed, then we need to convert var2 to signed
			if (type1 < VT_UI1)
			{
				if (type2 >= VT_UI2)
					type2 -= (VT_UI2 - VT_I2);
				else
					--type2;
				goto dosigned;
			}

			// Both are unsigned, but not the same datatype
			if (type1 < type2) goto convertvar1;
			goto convertvar2;
		}
	}
	}
	// One or both the VARIANTs aren't a numeric datatype, so we'll have
	// to assume the largest numeric datatype is needed for the conversion
	// to numeric, and the comparison operation
	{
	register HRESULT	hr;

	if (!(hr = VariantChangeType(var1, var1, 0, VT_R8)))
	{
		type1 = VT_R8;
		goto convertvar2;
	}
	return(hr);
	}
}





/********************** NotEqualComparison() ****************
 * Tests if the 2 VARIANTs don't have the same value.
 *
 * Sets var1->vt to VT_R4, and var1->lVal to
 * 1 if not equal, or 0 if equal.
 */

HRESULT NotEqualComparison(VARIANT *var1, SCRIPTVARIANT *scriptVar2, VARIANT *result)
{
	register HRESULT	hr;
	register VARIANT	*var2;

	var2 = scriptVar2->Value;

	if (var1->vt == VT_BSTR && var2->vt == VT_BSTR)
	{
		hr = (long)SysStringByteLen(var1->bstrVal);
		if (hr == (long)SysStringByteLen(var2->bstrVal))
			hr = (memcmp(var1->bstrVal, var2->bstrVal, hr) != 0);
		else
			hr = 1;
		VariantClear(result);
		result->vt = VT_R4;
		result->lVal = hr;
		hr = S_OK;
	}
	else if (!(hr = convertToNumeric(var1, scriptVar2, result)))
	{
		result->vt = VT_I4;
		var2 = scriptVar2->Value;

		switch (var1->vt)
		{
			case VT_I2:
			case VT_UI2:
				result->lVal = var1->uiVal != var2->uiVal;
				break;

			case VT_I4:
			case VT_UI4:
				result->lVal = var1->ulVal != var2->ulVal;
				break;

			case VT_R4:
				result->lVal = var1->fltVal != var2->fltVal;
				break;

			case VT_R8:
				result->lVal = var1->dblVal != var2->dblVal;
				break;

			default:
			//case VT_I1:
			//case VT_UI1:
				result->lVal = var1->bVal != var2->bVal;
		}
	}

	return(hr);
}





/********************** LessThanComparison() ****************
 * Tests if the var1 < var2.
 *
 * Sets var1->vt to VT_R4, and var1->lVal to
 * 1 if <, or 0 if not.
 */

HRESULT LessThanComparison(VARIANT *var1, SCRIPTVARIANT *scriptVar2, VARIANT *result)
{
	register HRESULT	hr;
	register VARIANT	*var2;

	var2 = scriptVar2->Value;

	if (var1->vt == VT_BSTR && var2->vt == VT_BSTR)
	{
		hr = lstrcmpW(var1->bstrVal, var2->bstrVal) < 0;
		VariantClear(result);
		result->vt = VT_R4;
		result->lVal = hr;
		hr = S_OK;
	}

	else if (!(hr = convertToNumeric(var1, scriptVar2, result)))
	{
		result->vt = VT_I4;
		var2 = scriptVar2->Value;

		switch (var1->vt)
		{
			case VT_I2:
				result->lVal = var1->iVal < var2->iVal;
				break;

			case VT_UI2:
				result->lVal = var1->uiVal < var2->uiVal;
				break;

			case VT_I4:
				result->lVal = var1->lVal < var2->lVal;
				break;

			case VT_UI4:
				result->lVal = var1->ulVal < var2->ulVal;
				break;

			case VT_R4:
				result->lVal = var1->fltVal < var2->fltVal;
				break;

			case VT_I1:
				result->lVal = var1->cVal < var2->cVal;
				break;

			case VT_UI1:
				result->lVal = var1->bVal < var2->bVal;
				break;

			default:
				result->lVal = var1->dblVal < var2->dblVal;
		}
	}

	return(hr);
}





/********************** GreaterThanComparison() ****************
 * Tests if the var1 > var2.
 *
 * Sets var1->vt to VT_R4, and var1->lVal to
 * 1 if >, or 0 if not.
 */

HRESULT GreaterThanComparison(VARIANT *var1, SCRIPTVARIANT *scriptVar2, VARIANT *result)
{
	register HRESULT	hr;
	register VARIANT	*var2;

	var2 = scriptVar2->Value;

	if (var1->vt == VT_BSTR && var2->vt == VT_BSTR)
	{
		hr = lstrcmpW(var1->bstrVal, var2->bstrVal) > 0;
		VariantClear(result);
		result->vt = VT_R4;
		result->lVal = hr;
		hr = S_OK;
	}

	else if (!(hr = convertToNumeric(var1, scriptVar2, result)))
	{
		result->vt = VT_I4;
		var2 = scriptVar2->Value;

		switch (var1->vt)
		{
			case VT_I2:
				result->lVal = var1->iVal > var2->iVal;
				break;

			case VT_UI2:
				result->lVal = var1->uiVal > var2->uiVal;
				break;

			case VT_I4:
				result->lVal = var1->lVal > var2->lVal;
				break;

			case VT_UI4:
				result->lVal = var1->ulVal > var2->ulVal;
				break;

			case VT_R4:
				result->lVal = var1->fltVal > var2->fltVal;
				break;

			case VT_I1:
				result->lVal = var1->cVal > var2->cVal;
				break;

			case VT_UI1:
				result->lVal = var1->bVal > var2->bVal;
				break;

			default:
				result->lVal = var1->dblVal > var2->dblVal;
		}
	}

	return(hr);
}





/********************** GreaterEqualComparison() ****************
 * Tests if the var1 >= var2.
 *
 * Sets var1->vt to VT_R4, and var1->lVal to
 * 1 if >=, or 0 if not.
 */

HRESULT GreaterEqualComparison(VARIANT *var1, SCRIPTVARIANT *scriptVar2, VARIANT *result)
{
	register HRESULT	hr;
	register VARIANT	*var2;

	var2 = scriptVar2->Value;

	if (var1->vt == VT_BSTR && var2->vt == VT_BSTR)
	{
		hr = lstrcmpW(var1->bstrVal, var2->bstrVal) <= 0;
		VariantClear(result);
		result->vt = VT_R4;
		result->lVal = hr;
		hr = S_OK;
	}

	else if (!(hr = convertToNumeric(var1, scriptVar2, result)))
	{
		result->vt = VT_I4;
		var2 = scriptVar2->Value;

		switch (var1->vt)
		{
			case VT_I2:
				result->lVal = var1->iVal >= var2->iVal;
				break;

			case VT_UI2:
				result->lVal = var1->uiVal >= var2->uiVal;
				break;

			case VT_I4:
				result->lVal = var1->lVal >= var2->lVal;
				break;

			case VT_UI4:
				result->lVal = var1->ulVal >= var2->ulVal;
				break;

			case VT_R4:
				result->lVal = var1->fltVal >= var2->fltVal;
				break;

			case VT_I1:
				result->lVal = var1->cVal >= var2->cVal;
				break;

			case VT_UI1:
				result->lVal = var1->bVal >= var2->bVal;
				break;

			default:
				result->lVal = var1->dblVal >= var2->dblVal;
		}
	}

	return(hr);
}





/********************** LessEqualComparison() ****************
 * Tests if the var1 <= var2.
 *
 * Sets var1->vt to VT_R4, and var1->lVal to
 * 1 if <=, or 0 if not.
 */

HRESULT LessEqualComparison(VARIANT *var1, SCRIPTVARIANT *scriptVar2, VARIANT *result)
{
	register HRESULT	hr;
	register VARIANT	*var2;

	var2 = scriptVar2->Value;

	// If BSTRs, instead of a <= comparison, do a case-insensitive compare
	if (var1->vt == VT_BSTR && var2->vt == VT_BSTR)
	{
		hr = lstrcmpW(var1->bstrVal, var2->bstrVal) >= 0;
		VariantClear(result);
		result->vt = VT_R8;
		result->dblVal = hr;
		hr = S_OK;
	}

	else if (!(hr = convertToNumeric(var1, scriptVar2, result)))
	{
		result->vt = VT_I4;
		var2 = scriptVar2->Value;

		switch (var1->vt)
		{
			case VT_I2:
				result->lVal = var1->iVal <= var2->iVal;
				break;

			case VT_UI2:
				result->lVal = var1->uiVal <= var2->uiVal;
				break;

			case VT_I4:
				result->lVal = var1->lVal <= var2->lVal;
				break;

			case VT_UI4:
				result->lVal = var1->ulVal <= var2->ulVal;
				break;

			case VT_R4:
				result->lVal = var1->fltVal <= var2->fltVal;
				break;

			case VT_I1:
				result->lVal = var1->cVal <= var2->cVal;
				break;

			case VT_UI1:
				result->lVal = var1->bVal <= var2->bVal;
				break;

			default:
				result->lVal = var1->dblVal <= var2->dblVal;
		}
	}

	return(hr);
}








// ======================== Math Operations ========================

/********************** AddOperation() ****************
 * Adds var1 and var2.
 *
 * Sets var1 to the result.
 *
 * NOTE: var1's datatype is promoted to the larger of
 * the two datatypes.
 */

HRESULT AddOperation(VARIANT *var1, SCRIPTVARIANT *scriptVar2, VARIANT *result)
{
	register HRESULT	hr;
	register VARIANT	*var2;

	// Convert the two VARIANTs to the same numeric datatype
	if (!(hr = convertToNumeric(var1, scriptVar2, result)))
	{
		// Perform the math operation
		var2 = scriptVar2->Value;
		
		switch ((result->vt = var2->vt))
		{
			case VT_I2:
				result->iVal = var1->iVal + var2->iVal;
				break;

			case VT_UI2:
				result->uiVal = var1->uiVal + var2->uiVal;
				break;

			case VT_I4:
				result->lVal = var1->lVal + var2->lVal;
				break;

			case VT_UI4:
				result->ulVal = var1->ulVal + var2->ulVal;
				break;

			case VT_R4:
				result->fltVal = var1->fltVal + var2->fltVal;
				break;

			case VT_I1:
				result->cVal = var1->cVal + var2->cVal;
				break;

			case VT_UI1:
				result->bVal = var1->bVal + var2->bVal;
				break;

			default:
				result->dblVal = var1->dblVal + var1->dblVal;
		}
	}

	return(hr);
}





/********************** SubOperation() ****************
 * Subtracts var2 from var1.
 *
 * Sets var1 to the result.
 *
 * NOTE: var1's datatype is promoted to the larger of
 * the two datatypes.
 */

HRESULT SubOperation(VARIANT *var1, SCRIPTVARIANT *scriptVar2, VARIANT *result)
{
	register HRESULT	hr;
	register VARIANT	*var2;

	if (!(hr = convertToNumeric(var1, scriptVar2, result)))
	{
		var2 = scriptVar2->Value;
		
		switch ((result->vt = var2->vt))
		{
			case VT_I2:
				result->iVal = var1->iVal - var2->iVal;
				break;

			case VT_UI2:
				result->uiVal = var1->uiVal - var2->uiVal;
				break;

			case VT_I4:
				result->lVal = var1->lVal - var2->lVal;
				break;

			case VT_UI4:
				result->ulVal = var1->ulVal - var2->ulVal;
				break;

			case VT_R4:
				result->fltVal = var1->fltVal - var2->fltVal;
				break;

			case VT_I1:
				result->cVal = var1->cVal - var2->cVal;
				break;

			case VT_UI1:
				result->bVal = var1->bVal - var2->bVal;
				break;

			default:
				result->dblVal = var1->dblVal - var1->dblVal;
		}
	}

	return(hr);
}




/********************** MultOperation() ****************
 * Multiplies var1 and var2.
 *
 * Sets var1 to the result.
 *
 * NOTE: var1's datatype is promoted to the larger of
 * the two datatypes.
 */

HRESULT MultOperation(VARIANT *var1, SCRIPTVARIANT *scriptVar2, VARIANT *result)
{
	register HRESULT	hr;
	register VARIANT	*var2;

	if (!(hr = convertToNumeric(var1, scriptVar2, result)))
	{
		var2 = scriptVar2->Value;

		switch ((result->vt = var2->vt))
		{
			case VT_I2:
				result->iVal = var1->iVal * var2->iVal;
				break;

			case VT_UI2:
				result->uiVal = var1->uiVal * var2->uiVal;
				break;

			case VT_I4:
				result->lVal = var1->lVal * var2->lVal;
				break;

			case VT_UI4:
				result->ulVal = var1->ulVal * var2->ulVal;
				break;

			case VT_R4:
				result->fltVal = var1->fltVal * var2->fltVal;
				break;

			case VT_I1:
				result->cVal = var1->cVal * var2->cVal;
				break;

			case VT_UI1:
				result->bVal = var1->bVal * var2->bVal;
				break;

			default:
				result->dblVal = var1->dblVal * var1->dblVal;
		}
	}

	return(hr);
}





/********************** DivOperation() ****************
 * Divides var1 by var2.
 *
 * Sets var1 to the result.
 *
 * NOTE: var1's datatype is promoted to the larger of
 * the two datatypes.
 */

HRESULT DivOperation(VARIANT *var1, SCRIPTVARIANT *scriptVar2, VARIANT *result)
{
	register HRESULT	hr;
	register VARIANT	*var2;

	if (!(hr = convertToNumeric(var1, scriptVar2, result)))
	{
		var2 = scriptVar2->Value;

		switch ((result->vt = var2->vt))
		{
			case VT_I2:
				result->iVal = var1->iVal / var2->iVal;
				break;

			case VT_UI2:
				result->uiVal = var1->uiVal / var2->uiVal;
				break;

			case VT_I4:
				result->lVal = var1->lVal / var2->lVal;
				break;

			case VT_UI4:
				result->ulVal = var1->ulVal / var2->ulVal;
				break;

			case VT_R4:
				result->fltVal = var1->fltVal / var2->fltVal;
				break;

			case VT_I1:
				result->cVal = var1->cVal / var2->cVal;
				break;

			case VT_UI1:
				result->bVal = var1->bVal / var2->bVal;
				break;

			default:
				result->dblVal = var1->dblVal / var1->dblVal;
		}
	}

	return(hr);
}





/********************** ModOperation() ****************
 * Divides var1 by var2, and gets the remainder.
 *
 * Sets var1 to the result.
 *
 * NOTE: var1's datatype is promoted to the larger of
 * the two datatypes.
 */

HRESULT ModOperation(VARIANT *var1, SCRIPTVARIANT *scriptVar2, VARIANT *result)
{
	register HRESULT	hr;
	register VARIANT	*var2;

	if (!(hr = convertToNumeric(var1, scriptVar2, result)))
	{
		var2 = scriptVar2->Value;

		switch ((result->vt = var2->vt))
		{
			case VT_I2:
				result->iVal = var1->iVal % var2->iVal;
				break;

			case VT_UI2:
				result->uiVal = var1->uiVal % var2->uiVal;
				break;

			case VT_I4:
				result->lVal = var1->lVal % var2->lVal;
				break;

			case VT_UI4:
				result->ulVal = var1->ulVal % var2->ulVal;
				break;

			case VT_I1:
				result->cVal = var1->cVal % var2->cVal;
				break;

			case VT_UI1:
				result->bVal = var1->bVal % var2->bVal;
				break;

			default:
				hr = DISP_E_TYPEMISMATCH;
		}
	}

	return(hr);
}






//========================= Unary Operations ====================

HRESULT IncOperator(VARIANT *var, VARIANT *result)
{
	// If BSTR, do an upper case conversion
	if (var->vt == VT_BSTR)
	{
		if (var != result && VariantCopy(result, var)) return(E_OUTOFMEMORY);
		CharUpperW(result->bstrVal);
	}
	else
	{
		if (var != result) CopyMemory(result, var, sizeof(VARIANT));

		switch (result->vt)
		{
			case VT_I2:
			case VT_UI2:
				++result->uiVal;
				break;

			case VT_I4:
			case VT_UI4:
				++result->ulVal;
				break;

			case VT_R4:
				++result->fltVal;
				break;

			case VT_R8:
				++result->dblVal;
				break;

			case VT_I1:
			case VT_UI1:
				++result->bVal;
				break;

			default:
				return(DISP_E_TYPEMISMATCH);
		}
	}

	return(S_OK);
}

HRESULT DecOperator(VARIANT *var, VARIANT *result)
{
	// If BSTR, do a lower case conversion
	if (var->vt == VT_BSTR)
	{
		if (var != result && VariantCopy(result, var)) return(E_OUTOFMEMORY);
		CharLowerW(result->bstrVal);
	}
	else
	{
		if (var != result) CopyMemory(result, var, sizeof(VARIANT));
		switch (result->vt)
		{
			case VT_I2:
			case VT_UI2:
				--result->uiVal;
				break;

			case VT_I4:
			case VT_UI4:
				--result->ulVal;
				break;

			case VT_R4:
				--result->fltVal;
				break;

			case VT_R8:
				--result->dblVal;
				break;

			case VT_I1:
			case VT_UI1:
				--result->bVal;
				break;

			default:
				return(DISP_E_TYPEMISMATCH);
		}
	}

	return(S_OK);
}

HRESULT NegateOperator(VARIANT *var, VARIANT *result)
{
	switch (var->vt)
	{
		case VT_I2:
		case VT_UI2:
			result->iVal = -var->iVal;
			break;

		case VT_I4:
		case VT_UI4:
			result->lVal = -var->lVal;
			break;

		case VT_R4:
			result->fltVal = -var->fltVal;
			break;

		case VT_R8:
			result->dblVal = -var->dblVal;
			break;

		case VT_I1:
		case VT_UI1:
			result->cVal = -var->cVal;
			break;

		default:
			return(DISP_E_TYPEMISMATCH);
	}

	result->vt = var->vt;
	return(S_OK);
}

HRESULT NotOperator(VARIANT *var, VARIANT *result)
{
	// If BSTR, test if string is 0 length
	if (var->vt == VT_BSTR)
	{
		register long	hr;

		hr = SysStringByteLen(var->bstrVal) == 0;
		VariantClear(result);
		result->vt = VT_R4;
		result->lVal = hr;
	}

	else
	{
		switch (var->vt)
		{
			case VT_I2:
			case VT_UI2:
				result->uiVal = !var->uiVal;
				break;

			case VT_I4:
			case VT_UI4:
				result->ulVal = !var->ulVal;
				break;

			case VT_R4:
				result->fltVal = !var->fltVal;
				break;

			case VT_R8:
				result->dblVal = !var->dblVal;
				break;

			case VT_I1:
			case VT_UI1:
				result->bVal = !var->bVal;
				break;

			default:
				return(DISP_E_TYPEMISMATCH);
		}

		result->vt = var->vt;
	}

	return(S_OK);
}

HRESULT BitNotOperator(VARIANT *var, VARIANT *result)
{
	switch (var->vt)
	{
		case VT_I2:
		case VT_UI2:
			result->uiVal = ~var->uiVal;
			break;

		case VT_I4:
		case VT_UI4:
			result->ulVal = ~var->ulVal;
			break;

		case VT_I1:
		case VT_UI1:
			result->bVal = ~var->bVal;

		default:
//		case VT_R4:
//		case VT_R8:
			return(DISP_E_TYPEMISMATCH);
	}

	result->vt = var->vt;
	return(S_OK);
}
