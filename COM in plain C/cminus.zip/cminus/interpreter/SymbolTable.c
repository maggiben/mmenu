/* Functions to manage a stack of CSYMBOLTABLE/CSYMBOL structs. They handle
 * scope resolution of variables declared and referenced in a script.
 */

#define INC_OLE2
#define CONST_VTABLE
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <objbase.h>
#include "../TraceWin.h"
#include "../Active Engine/ActiveScript.h"
#include "SymbolTable.h"





/************************ pushScope() *************************
 * Creates a new symbol table (CSYMBOLTABLE) and pushes it onto
 * the symbol table stack. The top CSYMBOLTABLE on the stack
 * represents the innermost symbol scope.
 *
 * stacktable =	The "Symbol Stack" that the new CSYMBOLTABLE is
 *				pushed upon.
 * scopeName =	The name for this CSYMBOLTABLE.
 *
 * RETURNS: The new CSYMBOLTABLE pointer, or 0 if memory fail.
 */

CSYMBOLTABLE * pushScope(struct _CINTERPRETER *interpreter) 
{
	register CSYMBOLTABLE	*table;

	LOGFUNC("pushScope");

	// Allocate a CSYMBOLTABLE with room to append the name
	if ((table = (CSYMBOLTABLE *)ALLOCMEM(sizeof(CSYMBOLTABLE))))
	{
		ZeroMemory(table, sizeof(CSYMBOLTABLE));

		// Save the topmost DEBUGSTACKFRAMEDESCRIPTOR as the one
		// this CSYMBOLTABLE belongs to
		if (interpreter->Parent->StackFrames)
			table->Frame = interpreter->Parent->StackFrames->Value;

		// Add the new CSYMBOLTABLE to the stack
		if (!stackPush(&interpreter->SymbolTable, table))
		{
			FREEMEM(table);
			table = 0;
		}
	}

	LOGHEXPARAM("Returned CSYMBOLTABLE:", (DWORD)table);
	UNLOGFUNC();
	return(table);
}





/************************** popScope() *************************
 * Pops the topmost symbol table off the stack, destroying it in
 * the process. Any symbols in this table have gone out of
 * scope and should not be found in a symbol search.
 */

HRESULT popScope(struct _CINTERPRETER *interpreter) 
{
	register CSYMBOLTABLE	*table;
	register CSYMBOL		*symbol;
	register HRESULT		hr;

	LOGFUNC("popScope");

	hr = S_OK;

	if ((table = (CSYMBOLTABLE *)stackPop(&interpreter->SymbolTable)))
	{
		// Clear the VARIANTs of all the CSYMBOLs that have been added to this table.
		// Also clear the SYMTYPE_ADDED CSYMBOL->Flag
		symbol = table->SymbolList;
		while (symbol)
		{
			// If the value on top of the DataStack happens to be using this
			// SCRIPTVARIANT, then what we've had is a return instruction that
			// happens to be returning the value of this local variable. In that
			// case, we'll have to make a copy of the value now before we clear
			// it, and substitute this new SCRIPTVARIANT on the stack
			if (interpreter->DataStack && interpreter->DataStack->Value == &symbol->SymbolValue)
			{
				SCRIPTVARIANT	*var;

				var = interpreter->DataStack;
				interpreter->DataStack = var->Next;
				freeScriptVariant(var);

				if (!(var = getScriptVariant(0))) hr = E_OUTOFMEMORY;
				else
				{
					CopyMemory(var->Value, &symbol->SymbolValue, sizeof(VARIANT));
					symbol->SymbolValue.vt = VT_EMPTY;

					var->Next = interpreter->DataStack;
					interpreter->DataStack = var;
				}
			}

			clearVariant(&symbol->SymbolValue);
			symbol->Flags &= ~SYMTYPE_ADDED;
			symbol = symbol->Next;
		}

		FREEMEM(table);
	}

	UNLOGFUNC();
	return(hr);
}





/*********************** findSymbol() *************************
 * Finds the CSYMBOL with the matching name.
 *
 * table =	The CSYMBOLTABLE to search.
 * name =	The desired symbol name.
 *
 * RETURNS: The CSYMBOL pointer, or 0 if not found.
 *
 * NOTE: C variable names are case-sensitive.
 */

static CSYMBOL * findSymbol(CSYMBOLTABLE *table, const WCHAR *name)
{
	register CSYMBOL	*symbol;

	LOGFUNC("findSymbol");

	symbol = table->SymbolList;
	while (symbol)
	{
		if (!lstrcmpW(&symbol->Name[0], name)) break;	// NOTE: case-sensitive
		symbol = symbol->Next;
	}

	LOGHEXPARAM("Returns", (DWORD)symbol);
	UNLOGFUNC();
	return(symbol);
}





/******************** searchSymbolTables() ********************
 * Searches all the symbol tables for the specified symbol.
 *
 * stacktable =	The "Symbol Stack" to search.
 * symbolName = The name of the desired symbol.
 *
 * RETURNS: The CSYMBOL * if the symbol is found. 0 otherwise.
 */

CSYMBOL * searchSymbolTables(struct _CINTERPRETER *interpreter, const WCHAR *symbolName)
{
	register CSYMBOL	*symbol;
	register TSTACK		*stacktable;

	stacktable = interpreter->SymbolTable;
	do
	{
		if ((symbol = findSymbol((CSYMBOLTABLE *)stacktable->Value, symbolName))) return(symbol);
	} while ((stacktable = stacktable->Next));

	return(0);
}





/******************** clearVariant() ********************
 * Clear a CSYMBOL's value.
 *
 * symbol = The CSYMBOL.
 */

void clearVariant(VARIANT *var)
{
	// If a malloc'ed block, then we need to free it via FREEMEM()
	if (var->vt & VT_VECTOR)
	{
		FREEMEM(var->bstrVal);
		var->vt = VT_EMPTY;
	}
	else
		VariantClear(var);
}
