// Contains the CLEXER which reads a stream of characters and parses it
// into tokens. The lexer is implemented as a Finite-State-Automaton
// which consumes the character stream using a principle of maximal munch.

#include <windows.h>
#include <objbase.h>
#include "CLexer.h"
#include "../English/Resource.h"
#include "../Active Engine/ErrorHandler.h"

// C keywords. These must match the order of KeywordTokens[]
const WCHAR	Keywords[] =	{2, 'd','o', 0,
2, 'i','f', 0,
3, 'f','o','r', 0,
3, 'i','n','t', 0,
4, 'a','u','t','o', 0,
4, 'b','y','t','e', 0,
4, 'c','a','s','e', 0,
4, 'c','h','a','r', 0,
4, 'e','l','s','e', 0,
4, 'e','n','u','m', 0,
4, 'g','o','t','o', 0,
4, 'l','o','n','g', 0,
4, 'v','o','i','d', 0,
5, 'b','r','e','a','k', 0,
5, 'c','o','n','s','t', 0,
5, 'f','l','o','a','t', 0,
5, 's','h','o','r','t', 0,
5, 'u','n','i','o','n', 0,
5, 'w','c','h','a','r', 0,
5, 'w','h','i','l','e', 0,
6, 'd','o','u','b','l','e', 0,
6, 'e','x','t','e','r','n', 0,
6, 'r','e','t','u','r','n', 0,
6, 's','i','g','n','e','d', 0,
6, 's','i','z','e','o','f', 0,
6, 's','t','a','t','i','c', 0,
6, 's','t','r','u','c','t', 0,
6, 's','w','i','t','c','h', 0,
7, 'd','e','f','a','u','l','t', 0,
7, 't','y','p','e','d','e','f', 0,
8, 'c','o','n','t','i','n','u','e', 0,
8, 'r','e','g','i','s','t','e','r', 0,
8, 'u','n','s','i','g','n','e','d', 0,
8, 'v','o','l','a','t','i','l','e', 0,
(WCHAR)-1};

const unsigned char	KeywordTokens[] = {TOKEN_DO,
TOKEN_IF,
TOKEN_FOR,
TOKEN_LONG,
TOKEN_AUTO,
TOKEN_BYTE,
TOKEN_CASE,
TOKEN_CHAR,
TOKEN_ELSE,
TOKEN_ENUM,
TOKEN_GOTO,
TOKEN_LONG,
TOKEN_VOID,
TOKEN_BREAK,
TOKEN_CONST,
TOKEN_FLOAT,
TOKEN_SHORT,
TOKEN_UNION,
TOKEN_WCHAR,
TOKEN_WHILE,
TOKEN_DOUBLE,
TOKEN_EXTERN,
TOKEN_RETURN,
TOKEN_SIGNED,
TOKEN_SIZEOF,
TOKEN_STATIC,
TOKEN_STRUCT,
TOKEN_SWITCH,
TOKEN_DEFAULT,
TOKEN_TYPEDEF,
TOKEN_CONTINUE,
TOKEN_REGISTER,
TOKEN_UNSIGNED,
TOKEN_VOLATILE};





/********************** consumeCharacter() ************************
 * Remove a char from the input stream and adds it to the current
 * token buffer.
 */

static void consumeCharacter(CLEXER *lexer)
{
	// See if we need a larger token buffer
	if (((unsigned char *)lexer->TokenBufferPtr - (unsigned char *)lexer->TokenBuffer) >= lexer->TokenBufferSize)
	{
		register WCHAR	*ptr;
	
		if (!(ptr = (WCHAR *)ALLOCMEM(lexer->TokenBufferSize << 1))) return;
		lexer->TokenBufferSize <<= 1;
		CopyMemory(ptr, lexer->TokenBuffer, (unsigned char *)lexer->TokenBufferPtr - (unsigned char *)lexer->TokenBuffer);
		lexer->TokenBufferPtr = (WCHAR *)((unsigned char *)lexer->TokenBuffer + ((unsigned char *)lexer->TokenBufferPtr - (unsigned char *)lexer->TokenBuffer));
	}

	*(lexer->TokenBufferPtr)++ = *(lexer->CurrentPtr)++;

	// Increment char position in the source
	++lexer->TextPosition.CharOnLine;
	++lexer->CharOffset;
}






/*********************** lexerIdentifier() ************************
 * Extracts a C identifier from the stream, once it's recognized as
 * an identifier.  After it is extracted, this function determines
 * if the identifier is a keyword.
 *
 * RETURNS: TOKEN_ define.
 */

static unsigned char lexerIdentifier(CLEXER *lexer)
{
	{	
	register WCHAR			chr;

	// Copy the source that makes up this token
	// An identifier is a string of letters, digits and/or underscores
	do
	{
		consumeCharacter(lexer);
		chr = *lexer->CurrentPtr;
	} while (((chr & 0xFF5F) >= 'A' && (chr & 0xFF5F) <= 'Z') || (chr >= '0' && chr <= '9') || *lexer->CurrentPtr == '_');
	*lexer->TokenBufferPtr = 0;
	}

	{	
	register const unsigned char	*tokens;
	register const WCHAR			*keywords;
	register unsigned short			size;
	int								result;

	size = lexer->TokenBufferPtr - lexer->TokenBuffer;

	// Check the Identifier against C keywords
	tokens = &KeywordTokens[0];
	keywords = &Keywords[0];
	while ((unsigned short)(*keywords) <= size)
	{
		if (*keywords == size)
		{
			if (!(result = memcmp(lexer->TokenBuffer, keywords + 1, size * sizeof(WCHAR))))
			{
				// Indicate a standard C keyword, so we don't need to save the text in the CINSTRUCTION
				lexer->TokenBufferPtr = 0;
				return(*tokens);
			}

			if (result < 0) break;
		}

		keywords += (*keywords + 2);
		++tokens;
	}
	}

	return(TOKEN_IDENTIFIER);
}





/************************* lexerNumber() **************************
 * Extracts a numerical constant from the stream. It only extracts
 * the digits that make up the number. No conversion from string
 * to numeral is performed here.
 *
 * RETURNS: TOKEN_ define.
 */

static unsigned char lexerNumber(CLEXER * lexer)
{
	register unsigned char	type;

	//copy the source that makes up this token
	//a constant is one of these:
	//0[xX][a-fA-F0-9]+{u|U|l|L}
	//0{D}+{u|U|l|L}

	// Hexadecimal? (begins with 0x)
	if (*lexer->CurrentPtr == '0' && (*(lexer->CurrentPtr+1) == 'x' || *(lexer->CurrentPtr+1) == 'X'))
	{
		lexer->CurrentPtr += 2;
		while ((iswdigit(*lexer->CurrentPtr)) || (*lexer->CurrentPtr >= 'a' && *lexer->CurrentPtr <= 'f')
			|| (*lexer->CurrentPtr >= 'A' && *lexer->CurrentPtr <= 'F'))
		{
			consumeCharacter(lexer);
		}

		if (*lexer->CurrentPtr == 'u' || *lexer->CurrentPtr == 'U')
			consumeCharacter(lexer);
		if (*lexer->CurrentPtr == 'l' || *lexer->CurrentPtr == 'L')
			consumeCharacter(lexer);

		type = TOKEN_HEXCONSTANT;
	}
	else
	{
		while (iswdigit(*lexer->CurrentPtr))
			consumeCharacter(lexer);

		// Engineering format float?
		if (*lexer->CurrentPtr == 'E' || *lexer->CurrentPtr == 'e') goto flt;

		// Scientific format float?
		if (*lexer->CurrentPtr == '.')
		{
			consumeCharacter(lexer);   
			while (iswdigit(*lexer->CurrentPtr))
				consumeCharacter(lexer);
         
			if (*lexer->CurrentPtr == 'E' || *lexer->CurrentPtr == 'e')
			{
flt:			consumeCharacter(lexer);
            
				while (iswdigit(*lexer->CurrentPtr))
					consumeCharacter(lexer);

				if (*lexer->CurrentPtr == 'f' || *lexer->CurrentPtr == 'F' || *lexer->CurrentPtr == 'l' || *lexer->CurrentPtr == 'L')
					consumeCharacter(lexer);
			}

			type = TOKEN_FLOATCONSTANT;
		}
		else
			type = TOKEN_INTCONSTANT;
	}

	return(type);
}






/********************** lexerOperation() ************************
 * Extracts a C operation char(s) from the character stream.
 *
 * RETURNS: TOKEN_ define.
 */

static unsigned char lexerOperation(CLEXER *lexer)
{
	register unsigned char	type;

	type = (unsigned char)-1;

	if (*lexer->CurrentPtr == '>')
	{
		consumeCharacter(lexer);

		//">>"
		if (*lexer->CurrentPtr == '>')
		{
			consumeCharacter(lexer);

			//">>="
			if (*lexer->CurrentPtr == '=')
			{
				consumeCharacter(lexer);
				type = TOKEN_RIGHT_ASSIGN;
			}
			else
				type = TOKEN_RIGHTSHIFT;
		}

		//">="
		else if (*lexer->CurrentPtr == '=')
		{
			consumeCharacter(lexer);
			type = TOKEN_GE_OP;
		}

		//">"
		else
			type = TOKEN_GT;
	}

	else if (*lexer->CurrentPtr == '<')
	{
		consumeCharacter(lexer);

		//"<<"
		if (*lexer->CurrentPtr == '<')
		{
			consumeCharacter(lexer);

			//"<<="
			if (*lexer->CurrentPtr == '=')
			{
				consumeCharacter(lexer);
				type = TOKEN_LEFT_ASSIGN;
			}
			else
				type = TOKEN_LEFTSHIFT;
		}

		//"<="
		else if (*lexer->CurrentPtr == '=')
		{
			consumeCharacter(lexer);
			type = TOKEN_LE_OP;
		}

		//"<"
		else
			type = TOKEN_LT;
	}

	else if (*lexer->CurrentPtr == '+')
	{
		consumeCharacter(lexer);

		//"++"
		if (*lexer->CurrentPtr == '+')
		{
			consumeCharacter(lexer);
			type = TOKEN_INC;
		}

		//"+="
		else if (*lexer->CurrentPtr == '=')
		{
			consumeCharacter(lexer);
			type = TOKEN_ADD_ASSIGN;
		}

		//"+"
		else
			type = TOKEN_ADD;
	}


	else if (*lexer->CurrentPtr == '-')
	{
		consumeCharacter(lexer);

		//"--"
		if (*lexer->CurrentPtr == '-')
		{
			consumeCharacter(lexer);
			type = TOKEN_DEC;
		}

		//"-="
		else if (*lexer->CurrentPtr == '=')
		{
			consumeCharacter(lexer);
			type = TOKEN_SUB_ASSIGN;
		}

		//"-"
		else
			type = TOKEN_SUB;
	}

	else if (*lexer->CurrentPtr == '*')
	{
		consumeCharacter(lexer);

		//"*="
		if (*lexer->CurrentPtr == '=')
		{
			consumeCharacter(lexer);
			type = TOKEN_MUL_ASSIGN;
		}
		//"*"
		else
			type = TOKEN_MUL;
	}

	else if (*lexer->CurrentPtr == '%')
	{
		consumeCharacter(lexer);

		//"%="
		if (*lexer->CurrentPtr == '=')
		{
			consumeCharacter(lexer);
			type = TOKEN_MOD_ASSIGN;
		}
		//"%"
		else
			type = TOKEN_MOD;
	}

	else if (*lexer->CurrentPtr == '&')
	{
		consumeCharacter(lexer);

		//"&&"
		if (*lexer->CurrentPtr == '&')
		{
			consumeCharacter(lexer);
			type = TOKEN_AND_OP;
		}

		//"&="
		else if (*lexer->CurrentPtr == '=')
		{
			consumeCharacter(lexer);
			type = TOKEN_AND_ASSIGN;
		}

		//"&"
		else
			type = TOKEN_BITWISE_AND;
	}

	else if (*lexer->CurrentPtr == '^')
	{
		consumeCharacter(lexer);

		//"^="
		if (*lexer->CurrentPtr == '=')
		{
			consumeCharacter(lexer);
			type = TOKEN_XOR_ASSIGN;
		}
		//"^"
		else
			type = TOKEN_BITWISE_XOR;
	}


	else if (*lexer->CurrentPtr == '|')
	{
		consumeCharacter(lexer);

		//"||"
		if (*lexer->CurrentPtr == '|')
		{
			consumeCharacter(lexer);
			type = TOKEN_OR_OP;
		}

		//"|="
		else if (*lexer->CurrentPtr == '=')
		{
			consumeCharacter(lexer);
			type = TOKEN_OR_ASSIGN;
		}

		//"|"
		else
			type = TOKEN_BITWISE_OR;
	}

	else if (*lexer->CurrentPtr == '=')
	{
		consumeCharacter(lexer);

		//"=="
		if (*lexer->CurrentPtr == '=')
		{
			consumeCharacter(lexer);
			type = TOKEN_EQ_OP;
		}
		//"="
		else
			type = TOKEN_ASSIGN;
	}

	else if (*lexer->CurrentPtr == '!')
	{
		consumeCharacter(lexer);

		//"!="
		if (*lexer->CurrentPtr == '=')
		{
			consumeCharacter(lexer);
			type = TOKEN_NE_OP;
		}
		//"!"
		else
			type = TOKEN_BOOLEAN_NOT;
	}

	//";"
	else if (*lexer->CurrentPtr == ';')
	{
		consumeCharacter(lexer);
		((CPARSER *)lexer)->Flags |= CPARSER_SEMICOLON;
		type = TOKEN_SEMICOLON;
	}

	//"{"
	else if (*lexer->CurrentPtr == '{')
	{
		consumeCharacter(lexer);
		type = TOKEN_LCURLY;
	}

	//"}"
	else if (*lexer->CurrentPtr == '}')
	{
		consumeCharacter(lexer);
		type = TOKEN_RCURLY;
	}

	//","
	else if (*lexer->CurrentPtr == ',')
	{
		consumeCharacter(lexer);
		type = TOKEN_COMMA;
	}

	//":"
	else if (*lexer->CurrentPtr == ':')
	{
		consumeCharacter(lexer);
		type = TOKEN_COLON;
	}

	//"("
	else if (*lexer->CurrentPtr == '(')
	{
		consumeCharacter(lexer);
		type = TOKEN_LPAREN;
	}

	//")"
	else if (*lexer->CurrentPtr == ')')
	{
		consumeCharacter(lexer);
		type = TOKEN_RPAREN;
	}

	//"["
	else if (*lexer->CurrentPtr == '[')
	{
		consumeCharacter(lexer);
		type = TOKEN_LBRACKET;
	}

	//"]"
	else if (*lexer->CurrentPtr == ']')
	{
		consumeCharacter(lexer);
		type = TOKEN_RBRACKET;
	}

	// If ".", then assume a reference to some object. After all, our C language doesn't
	// support structs, so we don't expect "." to be used to reference a struct
	else if (*lexer->CurrentPtr == '.')
	{
		consumeCharacter(lexer);
		type = TOKEN_FIELD;
	}

	//"~"
	else if (*lexer->CurrentPtr == '~')
	{
		consumeCharacter(lexer);
		type = TOKEN_BITWISE_NOT;
	}

	//"?"
	else if (*lexer->CurrentPtr == '?')
	{
		consumeCharacter(lexer);
		type = TOKEN_CONDITIONAL;
	}

	return(type);
}





/********************** lexerComment() ***********************
 * Extracts a comment from the character stream.
 */

static HRESULT lexerComment(CLEXER *lexer, OLECHAR theType)
{
	// If a double slash, we simply skip chars to the end of the line
	if (theType == '/')
	{
		do
		{
			++lexer->CurrentPtr;
			++lexer->TextPosition.CharOnLine;
			++lexer->CharOffset;

			// break out if we hit a new line
			if (*lexer->CurrentPtr == '\n') goto comdone;
			if (*lexer->CurrentPtr == '\r')
			{
				if (*(lexer->CurrentPtr + 1) == '\n')
				{
					++lexer->CurrentPtr;
					++lexer->CharOffset;
				}

comdone:		lexer->TextPosition.CharOnLine = 0;
comdone2:		++lexer->TextPosition.LineNum;
ok:				return(S_OK);
			}

			if (*lexer->CurrentPtr == '\f') goto comdone2;

		} while (*lexer->CurrentPtr);
	}

	else
	{
		// Consume the '*' that gets this comment started
		goto comstart;
		
		// Loop through the characters till we hit '*/'
		while (*lexer->CurrentPtr)
		{
			if (*lexer->CurrentPtr == '*' && *(lexer->CurrentPtr+1) == '/')
			{
				lexer->CurrentPtr += 2;
				lexer->TextPosition.CharOnLine += 2;
				lexer->CharOffset += 2;
				goto ok;
			}

			if (*lexer->CurrentPtr == '\n') goto newline;
			if (*lexer->CurrentPtr == '\r')
			{
				if (*(lexer->CurrentPtr + 1) == '\n')
				{
					++lexer->CurrentPtr;
					++lexer->CharOffset;
				}

newline:		lexer->TextPosition.CharOnLine = 0;
				goto inc_row;
			}
			else if (*lexer->CurrentPtr == '\f')
inc_row:		++lexer->TextPosition.LineNum;
comstart:
			++lexer->CurrentPtr;
			++lexer->TextPosition.CharOnLine;
			++lexer->CharOffset;
		}
	}

	return(E_FAIL);
}





/******************* lexerGetNextToken() *****************
 * Searches the input WCHAR stream and returns the next token
 * found within that stream, using the principle of maximal
 * munch. It embodies the start state of the FSA.
 *
 * lexer =	The initialized CLEXER containing the input
 *			stream.
 */

HRESULT lexerGetNextToken(CLEXER *lexer)
{
	register unsigned char		type;
	register WCHAR				chr;

	// Reset the TokenBufferPtr
	lexer->TokenBufferPtr = lexer->TokenBuffer;

	// Save the start position of the token
	CopyMemory(&lexer->TokenPosition, &lexer->TextPosition, sizeof(TEXTPOS));
	lexer->TokenCharOffset = lexer->CharOffset;

again:
	// The source code ends with a nul WCHAR, so see if we have
	// any more source text to parse
	if (!(chr = *lexer->CurrentPtr))
	{
		type = (unsigned char)TOKEN_EOF;

		// Make sure we end with a semicolon if the last token wasn't a semicolon
		if (!((CPARSER *)lexer)->Flags & CPARSER_SEMICOLON)
		{
			((CPARSER *)lexer)->Flags |= CPARSER_SEMICOLON;
			type = TOKEN_SEMICOLON;
		}

		// Nul-terminate the copied token text
token:	*lexer->TokenBufferPtr = 0;

		// Save the TOKEN_ type
ret:	lexer->TokenType = type;

		return(S_OK);
	}

	// ===============================================
	// Eat whitespace and newlines.

	// Newline?
	if (chr == '\n') goto reset;
      
	// carriage return
	if (chr == '\r')
	{
		// Skip over any subsequent '\n' as well
		if (*(lexer->CurrentPtr + 1) == '\n')
		{
			++lexer->CurrentPtr;
			++lexer->CharOffset;
		}

		// Reset the line char offset to zero
reset:	lexer->TextPosition.CharOnLine = 0;

		// Increment the line counter
		goto nextline;
	}
      
	// line feed
	if (chr == '\f')
	{
		// Increment the line counter
nextline:
		++lexer->TextPosition.LineNum;
		goto nextchar;
	}
      
	// space
	if (chr == ' ' || chr == '\t')
	{
		// Increment the line char counter
		++lexer->TextPosition.CharOnLine;

		// Increment char pointer
nextchar:
		++lexer->CurrentPtr;
		++lexer->CharOffset;
		goto again;
	}

	// ===============================================
	// Got the start of a token.

	// Save the start position of the token
	CopyMemory(&lexer->TokenPosition, &lexer->TextPosition, sizeof(TEXTPOS));
	lexer->TokenCharOffset = lexer->CharOffset;

	// Assume this token won't be a semicolon
	((CPARSER *)lexer)->Flags &= ~CPARSER_SEMICOLON;

	// An Identifier starts with an alphabetical character or underscore
	if (((chr & 0xFF5F) >= 'A' && (chr & 0xFF5F) <= 'Z') || chr == '_')
	{
		type = lexerIdentifier(lexer);
		goto ret;
	}

	// A Number starts with a numerical character
	if (iswdigit(chr))
	{
		type = lexerNumber(lexer);
		goto token;
	}

	// A string starts with a double quote. Parse the entire string into
	// the token buffer. A quoted char starts with a single quote
	if (chr == '"' || chr == '\'')
	{
		// Skip opening quote
		++lexer->TextPosition.CharOnLine;
again2:
		++lexer->CurrentPtr;
		++lexer->CharOffset;

		while (*lexer->CurrentPtr && *lexer->CurrentPtr != chr)
		{
			// Skip newline or carriage return
			if (*lexer->CurrentPtr == '\r')
			{
				if (*(lexer->CurrentPtr + 1) == '\n')
				{
					++lexer->CurrentPtr;
					++lexer->CharOffset;
				}

reset2:			lexer->TextPosition.CharOnLine = 0;
				++lexer->TextPosition.LineNum;
				goto again2;
			}
			if (*lexer->CurrentPtr == '\n') goto reset2;

			// See if we have an escaped char such as '\t'
			if (*lexer->CurrentPtr == '\\')
			{
				// Skip the '\\'
				++lexer->CurrentPtr;
				++lexer->TextPosition.CharOnLine;
				++lexer->CharOffset;

				switch (*lexer->CurrentPtr)
				{
					case '0':
						chr = 0;
						break;

					case 't':
						chr = '\t';
						break;

					case 'r':
						chr = '\r';
						break;

					case 'n':
						chr = '\n';
						break;

					case '\\':
						goto consume;

					case '\'':
					case '"':
						chr = *lexer->CurrentPtr;
						break;

					default:
						goto err;
				}

				*(lexer->TokenBufferPtr)++ = chr;
				++lexer->CurrentPtr;
				++lexer->TextPosition.CharOnLine;
				++lexer->CharOffset;
			}
			else
consume:		consumeCharacter(lexer);
		}
   
		// Missing ending quote?
		if (!(*lexer->CurrentPtr))
		{
			type = MISSING_QUOTE;
			goto error;
		}

		// Skip the last quote
		++lexer->CurrentPtr;
		++lexer->TextPosition.CharOnLine;
		++lexer->CharOffset;

		type = TOKEN_STRING_LITERAL;
		goto token;
	}

	// Check for a comment, or division sign
	if (chr == '/')
	{
		consumeCharacter(lexer);

		// If a comment, extract it and toss it away
		if (*lexer->CurrentPtr == '/' || *lexer->CurrentPtr == '*')
		{
			lexer->TokenBufferPtr = lexer->TokenBuffer;
			if (!lexerComment(lexer, *lexer->CurrentPtr)) goto again;
			goto err;
		}

		// If not a comment, this could be a division assignment /=
		if (*lexer->CurrentPtr == '=')
		{
			consumeCharacter(lexer);
			type = TOKEN_DIV_ASSIGN;
		}
		// A division sign in an expression
		else
			type = TOKEN_DIV;

		goto token;
	}
      
	// Check for a C operation indicator
	if ((type = lexerOperation(lexer)) != (unsigned char)-1) goto token;

	// If we get here, we've hit a character we don't recognize
err:
	// Consume the character so handleCompileError can copy it
	consumeCharacter(lexer);
	type = UNRECOGNIZED_CHARACTER;

error:
	// Create a CINSTRUCTION/CTOKEN along with the source text, and
	// report the error to the host
	*lexer->TokenBufferPtr = 0;
	lexer->TokenType = TOKEN_ERROR;
	handleCompileError(lexer, type);
	return(E_FAIL);
}
