#ifndef _CINSTRUCTION_H_
#define _CINSTRUCTION_H_

#include <objbase.h>
#include <activdbg.h>

// A struct to contain the position of each token
#pragma pack(1)
typedef struct {
	DWORD			LineNum;
	unsigned short	CharOnLine;
} TEXTPOS;
#pragma pack()

// =======================================================================

// A CTOKEN stores some extra position and type information about a
// single C token that the CLEXER creates. A C instruction can be
// comprised of many tokens, for example:
//
// i = 5
//
// ...consists of 3 CTOKENs
//
// This extra info is used only when the host is debugging a script.
#pragma pack(1)
typedef struct _CTOKEN {
	DWORD			CharOffset;		// Char offset of token from start of file.
	unsigned char	Type;			// Token type -- one of the TOKEN_ defines.
} CTOKEN;
#pragma pack()

// CTOKEN->Type
// Enumerates the possible parser token types. Some tokens here, such as LBRACKET, are
// never used
// The following BINARY operators must be in this order
#define TOKEN_GE_OP				1
#define TOKEN_GT				2
#define TOKEN_LE_OP				3
#define TOKEN_LT				4
#define TOKEN_LEFTSHIFT			5
#define TOKEN_RIGHTSHIFT		6
#define TOKEN_BITWISE_AND		7
#define TOKEN_BITWISE_OR		8
#define TOKEN_BITWISE_XOR		9
#define TOKEN_EQ_OP				10
#define TOKEN_NE_OP				11
#define TOKEN_OR_OP				12
#define TOKEN_AND_OP			13
#define TOKEN_MUL				14
#define TOKEN_DIV				15
#define TOKEN_MOD				16
#define TOKEN_ADD				17
#define TOKEN_SUB				18
// ===============================
// The following UNARY operators must be in this order
#define	TOKEN_INC				19
#define	TOKEN_DEC				20
#define TOKEN_BOOLEAN_NOT		21
#define TOKEN_BITWISE_NOT		22
// ===============================
// The following ASSIGNMENT operators must be in this order
#define TOKEN_ASSIGN			25
#define TOKEN_MUL_ASSIGN		26
#define TOKEN_DIV_ASSIGN		27
#define TOKEN_MOD_ASSIGN		28
#define TOKEN_ADD_ASSIGN		29
#define TOKEN_SUB_ASSIGN		30
#define TOKEN_LEFT_ASSIGN		31
#define TOKEN_RIGHT_ASSIGN		32
#define TOKEN_AND_ASSIGN		33
#define TOKEN_OR_ASSIGN			34
#define TOKEN_XOR_ASSIGN		35
// ===============================
// Constant Datatypes must be in this order
#define	TOKEN_HEXCONSTANT		40
#define	TOKEN_INTCONSTANT		41
#define	TOKEN_FLOATCONSTANT		42
#define	TOKEN_STRING_LITERAL	43
// ===============================
// Variable Datatypes must be in this order
#define	TOKEN_IDENTIFIER		45
#define TOKEN_CHAR				46
#define TOKEN_SHORT				47
#define TOKEN_LONG				48
#define TOKEN_FLOAT				49
#define TOKEN_DOUBLE			50
#define TOKEN_BYTE				51
#define TOKEN_WCHAR				52
#define TOKEN_STRUCT			53
#define TOKEN_UNION				54
#define TOKEN_VOID				55
#define TOKEN_ENUM				56
// ===============================
// Datatype qualifiers must be in this order
#define	TOKEN_PTR_OP			57
#define TOKEN_STATIC			58
#define TOKEN_UNSIGNED			59
#define TOKEN_CONST				60	// Anything above const is not a bit stored in the CSYMBOL->Flags
#define TOKEN_EXTERN			61	// extern must follow TOKEN_CONST. We temporarily set a CSYMBOL->Flags bit for it
#define TOKEN_VOLATILE			62
#define TOKEN_TYPEDEF			63
#define TOKEN_SIGNED			64
#define TOKEN_REGISTER			65
#define TOKEN_AUTO				66
// ===============================
#define TOKEN_ELLIPSIS			70
#define TOKEN_CASE				71
#define TOKEN_DEFAULT			72
#define TOKEN_IF				73
#define TOKEN_ELSE				74
#define TOKEN_SWITCH			75
#define TOKEN_WHILE				76
#define TOKEN_DO				77
#define TOKEN_FOR				78
#define TOKEN_GOTO				79
#define TOKEN_CONTINUE			80
#define TOKEN_BREAK				81
#define TOKEN_RETURN			82
#define TOKEN_SEMICOLON			83
#define TOKEN_LCURLY			84
#define TOKEN_RCURLY			85
#define TOKEN_COMMA				86
#define TOKEN_COLON				87
#define TOKEN_LPAREN			88
#define TOKEN_RPAREN			89
#define TOKEN_LBRACKET			90
#define TOKEN_RBRACKET			91
#define TOKEN_FIELD				92
#define TOKEN_COMMENT			93
#define	TOKEN_SIZEOF			94
#define TOKEN_CONDITIONAL		95

#define TOKEN_EOF				-1
#define TOKEN_ERROR				-1

// =======================================================================

// The CINSTRUCTION contains a single "opcode" for our interpreter
// to execute. A C source instruction may translate into numerous
// CINSTRUCTIONs. Think of a CINSTRUCTION as an interpreted version
// of an assembly opcode

#pragma pack(1)
typedef struct _CINSTRUCTION {
	struct _CINSTRUCTION	*Next;
	TEXTPOS					TextPosition;	// Position of token within the source line where it appears.
	unsigned char			Flags;
	unsigned char			OpCode;
	// The CINSTRUCTION's Data will be appended. See CInstructions.htm
} CINSTRUCTION;
#pragma pack()

// For CINSTRUCTION->Flags
#define BREAKPOINT_BITS			0x03	// Bottom 2 bits are reserved for BREAKPOINT_STATE
#define IS_DEBUG_INSTRUCTION	0x04	// Indicates the CINSTRUCTION has a CTOKEN prepended to it
#define IMMMEDIATE_COMPLETED	0x08	// Indicates this CINSTRUCTION has already been executed immediately
#define INUSE_BY_ERRORHANDLER	0x10	// Indicates this CINSTRUCTION is in use by an ERRORHANDLER, but not yet
										// left to the ERRORHANDLER to GlobalFree()
#define IMMEDIATE_INSTRUCTION	0x20	// Indicates this CINSTRUCTION is to be executed immediately when added
#define INSTRUCTION_HAS_LABEL	0x40	// The CINSTRUCTION has a C label prepended to it
#define LABEL_IS_DWORD			0x80	// The label is a numeric DWORD (instead of a pointer to a string)
#define DO_NOT_ADD				0x80000000

// CINSTRUCTION->OpCode
// The following BINARY operators must be in this order
#define OPCODE_GE			TOKEN_GE_OP
#define OPCODE_GT			TOKEN_GT
#define OPCODE_LE			TOKEN_LE_OP
#define OPCODE_LT			TOKEN_LT
#define OPCODE_LEFTSHIFT	TOKEN_LEFTSHIFT
#define OPCODE_RIGHTSHIFT	TOKEN_RIGHTSHIFT
#define OPCODE_BITWISE_AND	TOKEN_BITWISE_AND
#define OPCODE_BITWISE_OR	TOKEN_BITWISE_OR
#define OPCODE_BITWISE_XOR	TOKEN_BITWISE_XOR
#define OPCODE_EQ			TOKEN_EQ_OP
#define OPCODE_NE			TOKEN_NE_OP
#define OPCODE_OR			TOKEN_OR_OP
#define OPCODE_AND			TOKEN_AND_OP
#define OPCODE_MUL			TOKEN_MUL
#define OPCODE_DIV			TOKEN_DIV
#define OPCODE_MOD			TOKEN_MOD
#define OPCODE_ADD			TOKEN_ADD
#define OPCODE_SUB			TOKEN_SUB
// ===============================
// The following UNARY operators must be in this order
#define OPCODE_INC			TOKEN_INC
#define OPCODE_DEC			TOKEN_DEC
#define OPCODE_NOT			TOKEN_BOOLEAN_NOT
#define OPCODE_BITWISE_NOT	TOKEN_BITWISE_NOT
#define OPCODE_NEG			(TOKEN_BITWISE_NOT + 1)
#define OPCODE_INC2			(TOKEN_BITWISE_NOT + 2)
#define OPCODE_DEC2			(TOKEN_BITWISE_NOT + 2)
//================================
#define OPCODE_CONSTSTR		30
#define OPCODE_CONSTDBL		31
#define OPCODE_CONSTLONG	32
#define OPCODE_LOAD			33
#define OPCODE_SAVE			34
#define OPCODE_FIELD		35
#define OPCODE_CALL			36
#define OPCODE_JUMP			37
#define OPCODE_PUSH			38
#define OPCODE_POP			39
#define OPCODE_BRANCH_FALSE	40
#define OPCODE_BRANCH_TRUE	41
#define OPCODE_DATA			42
#define OPCODE_PARAM		43
#define OPCODE_RET			44
#define OPCODE_CHECKARG		45
#define OPCODE_CLEAN		46
// The following opcodea are ignored by evalInstruction()
#define OPCODE_NOOP			47
#define OPCODE_FUNCENTRY	48
#define OPCODE_CONTEXT		49

// =======================================================================

#endif // _CINSTRUCTION_H_