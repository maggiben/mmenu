#ifndef _BUILTINS_H_
#define _BUILTINS_H_

#define MAX_BUILTINS	44

typedef HRESULT BuiltinFuncPtr(CINTERPRETER *, DWORD);
extern BuiltinFuncPtr * Functions[MAX_BUILTINS];

BuiltinFuncPtr * lookupBuiltin(LPOLESTR, BuiltinFuncPtr **);

#endif