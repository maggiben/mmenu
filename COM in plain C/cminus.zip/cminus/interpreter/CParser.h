#ifndef _CPARSER_H_
#define _CPARSER_H_

#include "../Active Engine/CInterpreter.h"
#include "CLexer.h"
#include "TStack.h"

#pragma pack(1)
typedef struct {
	CLEXER					Lexer;					// This parser's CLEXER
	unsigned char			Flags;
	struct _CINTERPRETER	*Interpreter;			// The CINTERPRETER to which we're adding CINSTRUCTIONs
	TSTACK					*LabelStack;			// A stack of labels for use in jumps for a break instruction
	TSTACK					*ContinueStack;			// A stack of labels for use in jumps for a continue instruction
	DWORD					ReturnLabel;			// A numeric label for the OPCODE_RET instruction
	LPOLESTR				VarName;				// A temporary pointer to a variable name
	CINSTRUCTION			*InstructionList;		// Head of instruction list
	CINSTRUCTION			*CurrentInstruction;	// Where to link the next CINSTRUCTION (ie, after this one)
//	LPOLESTR				*Label;					// If non-zero, a text label for the next instruction
} CPARSER;
#pragma pack()

// CPARSER->Flags
#define CPARSER_DEBUG		0x01
#define CPARSER_SEMICOLON	0x02
#define CPARSER_ASSIGNMENT	0x04

extern CINSTRUCTION *	addInstruction(CPARSER *, DWORD, DWORD, DWORD, LPOLESTR);
extern HRESULT			startScriptParsing(CPARSER *);
extern HRESULT			parseFunction(CPARSER *);
extern HRESULT			format_expr(CPARSER *, unsigned char);
extern void				freeCInstruction(CINSTRUCTION *);
extern void				freeInstructionList(CINSTRUCTION *);

#endif //_CPARSER_H_