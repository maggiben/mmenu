#ifndef _SCRIPTVARIANT_H_
#define _SCRIPTVARIANT_H_

typedef struct _SCRIPTVARIANT {
	struct _SCRIPTVARIANT	*Next;
	VARIANT					*Value;
} SCRIPTVARIANT;

typedef long UnaryOperatorPtr(VARIANT *, VARIANT *);
typedef long BinaryOperatorPtr(VARIANT *, SCRIPTVARIANT *, VARIANT *);

extern SCRIPTVARIANT *	getScriptVariant(VARIANT *);
extern SCRIPTVARIANT *	getScriptVariantFromStr(LPCOLESTR);
extern void				freeScriptVariant(SCRIPTVARIANT *);
extern BOOL				isResultTrue(SCRIPTVARIANT *);
extern BSTR				makeTypeString(VARIANT *);
extern BSTR				variantToString(VARIANT *);
extern HRESULT			LeftShiftOperation(VARIANT *, SCRIPTVARIANT *, VARIANT *);
extern HRESULT			RightShiftOperation(VARIANT *, SCRIPTVARIANT *, VARIANT *);
extern HRESULT			BitOrOperation(VARIANT *, SCRIPTVARIANT *, VARIANT *);
extern HRESULT			BitAndOperation(VARIANT *, SCRIPTVARIANT *, VARIANT *);
extern HRESULT			BitXorOperation(VARIANT *, SCRIPTVARIANT *, VARIANT *);
extern HRESULT			OrTest(VARIANT *, SCRIPTVARIANT *, VARIANT *);
extern HRESULT			AndTest(VARIANT *, SCRIPTVARIANT *, VARIANT *);
extern HRESULT			EqualComparison(VARIANT *, SCRIPTVARIANT *, VARIANT *);
extern HRESULT			NotEqualComparison(VARIANT *, SCRIPTVARIANT *, VARIANT *);
extern HRESULT			LessThanComparison(VARIANT *, SCRIPTVARIANT *, VARIANT *);
extern HRESULT			GreaterThanComparison(VARIANT *, SCRIPTVARIANT *, VARIANT *);
extern HRESULT			GreaterEqualComparison(VARIANT *, SCRIPTVARIANT *, VARIANT *);
extern HRESULT			LessEqualComparison(VARIANT *, SCRIPTVARIANT *, VARIANT *);
extern HRESULT			AddOperation(VARIANT *, SCRIPTVARIANT *, VARIANT *);
extern HRESULT			SubOperation(VARIANT *, SCRIPTVARIANT *, VARIANT *);
extern HRESULT			MultOperation(VARIANT *, SCRIPTVARIANT *, VARIANT *);
extern HRESULT			DivOperation(VARIANT *, SCRIPTVARIANT *, VARIANT *);
extern HRESULT			ModOperation(VARIANT *, SCRIPTVARIANT *, VARIANT *);
extern HRESULT			IncOperator(VARIANT *, VARIANT *);
extern HRESULT			DecOperator(VARIANT *, VARIANT *);
extern HRESULT			NegateOperator(VARIANT *, VARIANT *);
extern HRESULT			NotOperator(VARIANT *, VARIANT *);
extern HRESULT			BitNotOperator(VARIANT *, VARIANT *);

#endif // _SCRIPTVARIANT_H_
