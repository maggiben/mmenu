#ifndef _CLEXER_H_
#define _CLEXER_H_

#include "CInstruction.h"

// The CLEXER is used by the lexer to parse a script (ie, a string of unicode
// characters) and create a series of TOKENs based on the script. Its purpose
// is to break down the characters into "words" for the parser
#pragma pack(1)
typedef struct {
	LPCOLESTR		CurrentPtr;			// Pointer to the next char the lexer will parse from the C source
	DWORD			CharOffset;			// Current offset from the start of the script
	void			*ActiveScript;		// Our ACTIVESCRIPT that owns this CLEXER
	OLECHAR			*TokenBuffer;		// A temporary buffer to store the token text
	OLECHAR			*TokenBufferPtr;	// Where within 'TokenBuffer' we store the next source char
	TEXTPOS			TextPosition;		// Current line/char within the C source file where the lexer is parsing
	TEXTPOS			TokenPosition;		// Line/char position of token within the line
	DWORD			TokenCharOffset;	// Token's offset from the start of the script
	DWORD			Context;			// App-supplied context for all of the CINSTRUCTIONs
	unsigned short	TokenBufferSize;	// Size of TokenBuffer
	unsigned char	TokenType;			// TOKEN_ define
} CLEXER;
#pragma pack()

extern HRESULT				lexerGetNextToken(CLEXER *);

extern const WCHAR			Keywords[];
extern const unsigned char	KeywordTokens[];

#endif // _CLEXER_H_