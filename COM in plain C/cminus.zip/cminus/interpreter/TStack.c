/*
 * Contains the definition of a linked list that contains
 * TSTACKs that have a generic "void *" data field. It is
 * designed for use in stacks and queues.
 */

#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include "TStack.h"
#include "../Mem.h"




/*********************** stackPush() **********************
 * Allocates/pushes a new TSTACK with the specified Value
 * field,
 *
 * RETURNS: Pointer to new TSTACK, or 0 if memory error.
 */

TSTACK * stackPush(TSTACK **list, void *value)
{
	register TSTACK *node;

	// Create a new TSTACK
	if ((node = (TSTACK *)ALLOCMEM(sizeof(TSTACK))))
	{
		// Insert at the head of the list
		node->Next = *list;
		*list = node;

		// Store the value
		node->Value = value;
	}

	return(node);
}





/*********************** stackPop() **********************
 * Pops the next TSTACK and returns its Value field,
 * freeing the TSTACK.
 */

void * stackPop(TSTACK **list)
{
	register TSTACK	*node;
	register void	*value;

	value = 0;
	if ((node = *list))
	{
		*list = node->Next;
		value = node->Value;
		FREEMEM(node);
	}

	return(value);
}





/*********************** freeTStack() **********************
 * Frees a TSTACK list. Zeroes the list pointer.
 */

void freeTStack(TSTACK **list, TStackDeletePtr *func)
{
	register TSTACK	*node;
	register TSTACK	*nextnode;

	nextnode = *list;

	// Free each TSTACK in the list
	while ((node = nextnode))
	{
		nextnode = node->Next;

		// Free the TSTACK value field
		(*func)(node->Value);

		FREEMEM(node);
	}

	// Zero the list
	*list = 0;
}
