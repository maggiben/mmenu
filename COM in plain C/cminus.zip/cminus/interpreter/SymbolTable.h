#ifndef _CSYMBOLTABLE_H_
#define _CSYMBOLTABLE_H_

#include "TStack.h"
#include "../Active Engine/CInterpreter.h"
#include "../Active Debugging/StackFrameDesc.h"

// CSYMBOL->Flags
// The low 8 bits is the VT_ datatype
// These must be in the same order as the "Datatype qualifier" TOKEN_ defines in CInstruction.h
#define SYMTYPE_PTR_OP			0x0100			// A malloc'ed value
#define SYMTYPE_STATIC			0x0200
#define SYMTYPE_UNSIGNED		0x0400
#define SYMTYPE_CONST			0x0800
#define SYMTYPE_EXTERN			0x1000
#define SYMTYPE_ADDED			SYMTYPE_EXTERN	// Temporarily corresponds to TOKEN_EXTERN bit too
#define SYMTYPE_8BIT			0x8000			// "char", instead of "wchar", datatype

#pragma pack(1)
// Stores a single C symbol's (variable's) value
typedef struct _CYMBOL {
	VARIANT			SymbolValue;	// The value for the Symbol. We use a VARIANT so we can wrap any COM datatype
	struct _CYMBOL	*Next;
	unsigned short	Flags;			// The symbol's datatype
	WCHAR			Name[1];		// The Symbol name. This is variably-sized so it must be last
} CSYMBOL;

// ==============================================

// Stores all of the CSYMBOLs at a given scope (ie, call level)
typedef struct {
	CSYMBOL								*SymbolList; // List of CSYMBOLS
	struct _DEBUGSTACKFRAMEDESCRIPTOR	*Frame;		 // The DEBUGSTACKFRAMEDESCRIPTOR to which this CSYMBOLTABLE belongs
} CSYMBOLTABLE;
#pragma pack()

// ==============================================

extern CSYMBOLTABLE *	pushScope(struct _CINTERPRETER *);
extern HRESULT			popScope(struct _CINTERPRETER *);
extern CSYMBOL *		searchSymbolTables(struct _CINTERPRETER *, const WCHAR *);
extern void				clearVariant(VARIANT *);

#endif // _CSYMBOLTABLE_H_