#ifndef _TSTACK_H_
#define _TSTACK_H_

typedef void TStackDeletePtr(void *);

typedef struct _TSTACK {
	struct _TSTACK	*Next;			// Next TSTACK in the list
	void			*Value;			// The value for the TSTACK. This may point to anything
} TSTACK;

// ==============================================

extern void		freeTStack(TSTACK **, TStackDeletePtr *);
extern TSTACK *	stackPush(TSTACK **, void *);
extern void *	stackPop(TSTACK **);

#endif // _TSTACK_H_