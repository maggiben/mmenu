// Contains the token sets for the parser,
// which provide the map of allowable tokens for the parser

static const unsigned char StatementList[] = {TOKEN_LCURLY, TOKEN_IF, TOKEN_WHILE, TOKEN_DO, TOKEN_FOR, TOKEN_BREAK, TOKEN_RETURN, TOKEN_INC, TOKEN_DEC, TOKEN_ADD, TOKEN_SUB, TOKEN_BOOLEAN_NOT, TOKEN_IDENTIFIER, TOKEN_HEXCONSTANT, TOKEN_INTCONSTANT, TOKEN_FLOATCONSTANT, TOKEN_STRING_LITERAL, TOKEN_LPAREN, 0};
static const unsigned char StatementEnd[] = {TOKEN_RCURLY, (unsigned char)-1 /* Add StatementList[] */};
static const unsigned char Operations[] = {TOKEN_INC, TOKEN_DEC, TOKEN_ADD, TOKEN_SUB, TOKEN_BOOLEAN_NOT, TOKEN_IDENTIFIER, TOKEN_HEXCONSTANT, TOKEN_INTCONSTANT, TOKEN_FLOATCONSTANT, TOKEN_STRING_LITERAL, TOKEN_LPAREN, 0};
static const unsigned char IfSelect[] = {TOKEN_IF, 0};
static const unsigned char WhileDoFor[] = {TOKEN_WHILE, TOKEN_DO, TOKEN_FOR, 0};
static const unsigned char EndAssignmentOps[] = {TOKEN_SEMICOLON, TOKEN_RPAREN, TOKEN_COMMA, 0};
static const unsigned char ExpressionToken[] = {TOKEN_IDENTIFIER, TOKEN_HEXCONSTANT, TOKEN_INTCONSTANT, TOKEN_FLOATCONSTANT, TOKEN_STRING_LITERAL, TOKEN_LPAREN, 0};
static const unsigned char NextExpressionToken[] = {TOKEN_SEMICOLON, TOKEN_RPAREN, TOKEN_COMMA, 0};
