#ifndef _ACTIVESCRIPT_H_
#define _ACTIVESCRIPT_H_

#include "activdbg.h"
#include "../Mem.h"
#include "ScriptObject.h"
#include "CInterpreter.h"
#include "CEventHandler.h"
#include "../Active Debugging/EnumStackFrames.h"
#include "../Active Debugging/StackFrameDesc.h"
#include "../Interpreter/TStack.h"

extern const IRemoteDebugApplicationEventsVtbl IRemoteDebugApplicationEvents_Vtbl;

//#define SCRIPTTHREADSTATE_RUNNING	0x01
#define ACTIVESCRIPTFLAG_HALTRAISED	0x02

// Wraps our IActiveScript and all its COM sub-objects. Also
// includes private data for maintaining a list of interpreters,
// one per each script object (containing C source code) added
// to the engine
#pragma pack(1)
typedef struct _ACTIVESCRIPT {
	const void *			ActiveScript;					// Our IActiveScript VTable. Must be first
	const void *			ActiveScriptParse;				// Our IActiveScriptParse VTable.
	const void *			ActiveScriptParseProcedure;		// Our IActiveScriptParseProcedure VTable.
	const void *			HostInfoUpdate;					// Our IHostInfoUpdate VTable.
	const void *			ObjectSafety;					// Our IObjectSafety VTable.
	const void *			RemoteDebugAppEvents;			// Our IRemoteDebugApplicationEvents VTable.
	const void *			ActiveScriptDebug;				// Our IActiveScriptDebug VTable.
	const void *			DebugStackFrameSniffer;			// Our IDebugStackFrameSniffer VTable.
	struct _ACTIVESCRIPT	*Next;							// For linking the ACTIVESCRIPT objects into a list.
	ULONG					RefCount;						// Reference count.
	DWORD					LastSysError;					// Last error from GetLastError()
	struct _SCRIPTOBJECT	*ScriptObjectList;				// List of host script objects.
	struct _CINTERPRETER	*InterpreterList;				// List of CINTERPRETERs.
	struct _CEVENTHANDLER	*EventHandlerList;				// List of event handlers for HTML events.
	IActiveScriptSite		*HostScriptSite;				// Host's IActiveScriptSite.
	IRemoteDebugApplicationThread	*HostDebugThread;		// Host's IRemoteDebugApplicationThread if debugging.
	IActiveScriptSiteDebug	*HostScriptSiteDebug;			// Host's IActiveScriptSiteDebug (or our own SMARTHOST *) if debugging.
	IDebugApplication		*HostDebugApplication;			// Host's IDebugApplication if debugging.
	IConnectionPoint		*HostEventsConnPoint;			// For connecting to host's IRemoteDebugApplicationEvents.
	DWORD					HostEventsConnCookie;			// For connecting to host's IRemoteDebugApplicationEvents.
	DWORD					SnifferCookie;					// Host cookie when we give it our IDebugStackFrameSniffer.
	DWORD					HostThreadID;					// ID of the host thread that calls SetScriptSite().
	TSTACK					*StackFrames;					// Stack of DEBUGSTACKFRAMEDESCRIPTOR's. All our interpreters
															// store their stack frames on this one stack. Since we're
															// single threaded, this is okay. Used only when debugging.
	APPBREAKFLAGS			BreakFlags;
	unsigned char			EngineState;					// Current engine state (SCRIPTSTATE).
	unsigned char			BreakResumeAction;				// BREAKRESUMEACTION from host debugger.
	unsigned char			Flags;
} ACTIVESCRIPT;
#pragma pack()

extern IActiveScript *	allocActiveScript(void);
extern void				initializeActiveScript(ACTIVESCRIPT *);
extern ULONG			incActiveScriptRefcount(ACTIVESCRIPT *);
extern ULONG			decActiveScriptRefcount(ACTIVESCRIPT *);
extern HRESULT			queryActiveScriptInterface(ACTIVESCRIPT *, REFIID, void **);
extern void				close_host_objects(ACTIVESCRIPT *);

#endif // _ACTIVESCRIPT_H_
