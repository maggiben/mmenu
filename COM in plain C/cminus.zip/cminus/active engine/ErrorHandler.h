#ifndef _ERRORHANDLER_H_
#define _ERRORHANDLER_H_

#include "../Interpreter/CLexer.h"
#include "../Interpreter/CInstruction.h"
#include "CInterpreter.h"

extern void				handleCompileError(CLEXER *, DWORD);
extern void				handleRuntimeError(CINSTRUCTION *, DWORD, CINTERPRETER *);
extern const WCHAR *	getSourceTokenText(CTOKEN *, CINSTRUCTION *);
void					errorFreeMsgLib(void);
void					errorInitMsgLib(void);
void					errorSetLocale(LCID);

#endif