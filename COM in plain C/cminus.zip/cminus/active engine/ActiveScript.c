/*
 * Contains the functions for our ACTIVESCRIPT. This struct wraps our IActiveScript
 * (or IActiveScriptDebug) object, with its sub-objects IActiveScriptParse,
 * IActiveScriptParseProcedure, IObjectSafety, and IHostInfoUpdate.
 */

#define INC_OLE2
#define CONST_VTABLE
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <stddef.h>
#include <objbase.h>
#include <activscp.h>
#include <activdbg.h>
#include <objsafe.h>
#include "../TraceWin.h"
#include "../IClassFactory.h"
#include "../Guids.h"
#include "ActiveScript.h"
#include "../Active Debugging/SimpleHostBackup.h"
#include "../Interpreter/ScriptVariant.h"
#include "../Interpreter/SymbolTable.h"
#include "../Interpreter/CParser.h"
#include "../Interpreter/BuiltIns.h"
#include "ErrorHandler.h"
extern const IActiveScriptDebug32Vtbl IActiveScriptDebug_Vtbl;


// HostInfo.h
#define hostinfoLocale 0
#define	hostinfoCodePage 1
#define	hostinfoErrorLocale 2

static const GUID IID_IHostInfoUpdate = {0x1d044690, 0x8923, 0x11d0, {0xab, 0xd2, 0x0, 0xa0, 0xc9, 0x11, 0xe8, 0xb2}};
static const GUID IID_IActiveScriptParseProcedure32 = {0xaa5b6a80, 0xb834, 0x11d0, 0x93, 0x2f, 0x00, 0xA0, 0xc9, 0x0d, 0xca, 0xa9};
static const GUID IID_IActiveScriptParse32 = {0xbb1a2ae2, 0xa4f9, 0x11cf, 0x8f, 0x20, 0x00, 0x80, 0x5f, 0x2c, 0xd0, 0x64};

typedef struct {
	struct _IHostInfoUpdateVtbl *lpVtbl;
} IHostInfoUpdate;

typedef HRESULT STDMETHODCALLTYPE QueryInterfacePtr(IHostInfoUpdate *, REFIID, void **);
typedef ULONG STDMETHODCALLTYPE AddRefPtr(IHostInfoUpdate *);
typedef ULONG STDMETHODCALLTYPE ReleasePtr(IHostInfoUpdate *);
typedef HRESULT STDMETHODCALLTYPE UpdateInfoPtr(IHostInfoUpdate *, DWORD);

typedef struct _IHostInfoUpdateVtbl {
	QueryInterfacePtr  *QueryInterface;
	AddRefPtr          *AddRef;
	ReleasePtr         *Release;
	UpdateInfoPtr       *UpdateInfo;
} IHostInfoUpdateVtbl;

typedef struct {
	struct _IHostInfoProviderVtbl *lpVtbl;
} IHostInfoProvider;

typedef HRESULT STDMETHODCALLTYPE HPQueryInterfacePtr(IHostInfoProvider *, REFIID, void **);
typedef ULONG STDMETHODCALLTYPE HPAddRefPtr(IHostInfoProvider *);
typedef ULONG STDMETHODCALLTYPE HPReleasePtr(IHostInfoProvider *);
typedef HRESULT STDMETHODCALLTYPE GetHostInfoPtr(IHostInfoProvider *, DWORD, void **);

typedef struct _IHostInfoProviderVtbl {
	HPQueryInterfacePtr  *QueryInterface;
	HPAddRefPtr          *AddRef;
	HPReleasePtr         *Release;
	GetHostInfoPtr       *GetHostInfo;
} IHostInfoProviderVtbl;

static const GUID IID_IHostInfoProvider = {0xf8418ae0, 0x9a5d, 0x11d0, {0xab, 0xd4, 0x0, 0xa0, 0xc9, 0x11, 0xe8, 0xb2}};

// IActiveScript VTable
static STDMETHODIMP Script_QueryInterface(ACTIVESCRIPT *, REFIID, void **);
static STDMETHODIMP_(ULONG) Script_AddRef(ACTIVESCRIPT *);
static STDMETHODIMP_(ULONG) Script_Release(ACTIVESCRIPT *);
static STDMETHODIMP AddNamedItem(ACTIVESCRIPT *, LPCOLESTR, DWORD);
static STDMETHODIMP AddTypeLib(ACTIVESCRIPT *, REFGUID, DWORD, DWORD, DWORD);
static STDMETHODIMP Clone(ACTIVESCRIPT *, IActiveScript **);
static STDMETHODIMP Close(ACTIVESCRIPT *);
static STDMETHODIMP GetCurrentScriptThreadID(ACTIVESCRIPT *, SCRIPTTHREADID *);
static STDMETHODIMP GetScriptDispatch(ACTIVESCRIPT *, LPCOLESTR, IDispatch **);
static STDMETHODIMP GetScriptSite(ACTIVESCRIPT *, REFIID, void **);
static STDMETHODIMP GetScriptState(ACTIVESCRIPT *, SCRIPTSTATE *);
static STDMETHODIMP GetScriptThreadID(ACTIVESCRIPT *, DWORD, SCRIPTTHREADID *);
static STDMETHODIMP GetScriptThreadState(ACTIVESCRIPT *, SCRIPTTHREADID, SCRIPTTHREADSTATE *);
static STDMETHODIMP InterruptScriptThread(ACTIVESCRIPT *, SCRIPTTHREADID, const EXCEPINFO *, DWORD);
static STDMETHODIMP SetScriptSite(ACTIVESCRIPT *, IActiveScriptSite *);
static STDMETHODIMP SetScriptState(ACTIVESCRIPT *, SCRIPTSTATE);

const struct IActiveScriptVtbl IActiveScript_Vtbl = {Script_QueryInterface,
Script_AddRef,
Script_Release,
SetScriptSite,
GetScriptSite,
SetScriptState,
GetScriptState,
Close,
AddNamedItem,
AddTypeLib,
GetScriptDispatch,
GetCurrentScriptThreadID,
GetScriptThreadID,
GetScriptThreadState,
InterruptScriptThread,
Clone};

// IActiveScriptParse32 VTable
static STDMETHODIMP ScriptParse_QueryInterface(IActiveScriptParse32 *, REFIID, void **);
static STDMETHODIMP_(ULONG) ScriptParse_AddRef(IActiveScriptParse32 *);
static STDMETHODIMP_(ULONG) ScriptParse_Release(IActiveScriptParse32 *);
static STDMETHODIMP InitNew(IActiveScriptParse32 *);
static STDMETHODIMP AddScriptlet(IActiveScriptParse32 *, LPCOLESTR, LPCOLESTR, LPCOLESTR, LPCOLESTR, LPCOLESTR, LPCOLESTR, DWORD, ULONG, DWORD, BSTR *, EXCEPINFO *);
static STDMETHODIMP ParseScriptText(IActiveScriptParse32 *, LPCOLESTR, LPCOLESTR, IUnknown *, LPCOLESTR, DWORD, ULONG, DWORD, VARIANT *, EXCEPINFO *);

const struct IActiveScriptParse32Vtbl IActiveScriptParse_Vtbl = {ScriptParse_QueryInterface,
ScriptParse_AddRef,
ScriptParse_Release,
InitNew,
AddScriptlet,
ParseScriptText};

// IActiveScriptParseProcedure VTable
static STDMETHODIMP Proc_QueryInterface(IActiveScriptParseProcedure *, REFIID, void **);
static STDMETHODIMP_(ULONG) Proc_AddRef(IActiveScriptParseProcedure *);
static STDMETHODIMP_(ULONG) Proc_Release(IActiveScriptParseProcedure *);
static STDMETHODIMP ParseProcedureText(IActiveScriptParseProcedure *, LPCOLESTR, LPCOLESTR, LPCOLESTR, LPCOLESTR, IUnknown *, LPCOLESTR, DWORD, ULONG, DWORD, IDispatch **);

const struct IActiveScriptParseProcedure32Vtbl IActiveScriptParseProcedure_Vtbl = {Proc_QueryInterface,
Proc_AddRef,
Proc_Release,
ParseProcedureText};

// IHostInfoUpdate VTable
static STDMETHODIMP Host_QueryInterface(IHostInfoUpdate *, REFIID, void **);
static STDMETHODIMP_(ULONG) Host_AddRef(IHostInfoUpdate *);
static STDMETHODIMP_(ULONG) Host_Release(IHostInfoUpdate *);
static STDMETHODIMP UpdateInfo(IHostInfoUpdate *, DWORD);

const IHostInfoUpdateVtbl IHostInfoUpdate_Vtbl = {Host_QueryInterface,
Host_AddRef,
Host_Release,
UpdateInfo};

// IObjectSafety VTable
static STDMETHODIMP Safety_QueryInterface(IObjectSafety *, REFIID, void **);
static STDMETHODIMP_(ULONG) Safety_AddRef(IObjectSafety *);
static STDMETHODIMP_(ULONG) Safety_Release(IObjectSafety *);
static STDMETHODIMP GetInterfaceSafetyOptions(IObjectSafety *, REFIID, DWORD *, DWORD *);
static STDMETHODIMP SetInterfaceSafetyOptions(IObjectSafety *, REFIID, DWORD, DWORD);

const struct IObjectSafetyVtbl IObjectSafety_Vtbl = {Safety_QueryInterface,
Safety_AddRef,
Safety_Release,
GetInterfaceSafetyOptions,
SetInterfaceSafetyOptions};


static const WCHAR DefaultName[] = L"a";

// For Debugging
#ifdef LOGTRACE
unsigned char LogFlag = 0;
#endif






/********************* allocActiveScript() **********************
 * Allocates/Initializes our IActiveScript (actually ACTIVESCRIPT)
 * for our script engine.
 *
 * RETURNS: ACTIVESCRIPT pointer, or 0 if memory fail.
 */

IActiveScript * allocActiveScript(void)
{
	register ACTIVESCRIPT		*pObj;

	if ((pObj = (ACTIVESCRIPT *)ALLOCMEM(sizeof(ACTIVESCRIPT))))
	{
		ZeroMemory(pObj, sizeof(ACTIVESCRIPT));

//		iactive->EngineState = SCRIPTSTATE_UNINITIALIZED;

		// Set the COM object VTables
		pObj->ActiveScript = &IActiveScript_Vtbl;
		pObj->ActiveScriptParse = &IActiveScriptParse_Vtbl;
		pObj->ActiveScriptParseProcedure = &IActiveScriptParseProcedure_Vtbl;
		pObj->HostInfoUpdate = &IHostInfoUpdate_Vtbl;
		pObj->ObjectSafety = &IObjectSafety_Vtbl;
		pObj->RemoteDebugAppEvents = &IRemoteDebugApplicationEvents_Vtbl;
		pObj->DebugStackFrameSniffer = &IDebugStackFrameSniffer_Vtbl;
		pObj->ActiveScriptDebug = &IActiveScriptDebug_Vtbl;

		// Link it into the master list
		EnterCriticalSection(&InterruptSection);
		pObj->Next = ActiveScriptList;
		ActiveScriptList = pObj;
		LeaveCriticalSection(&InterruptSection);
	}

	return((IActiveScript *)pObj);
}





/****************** incActiveScriptRefcount() *******************
 * Increment's our IActiveScript's (ACTIVESCRIPT) reference count.
 */

ULONG incActiveScriptRefcount(ACTIVESCRIPT *iactive)
{
#ifdef LOGTRACE
	if (LogFlag != (unsigned char)-1) UNLOGFUNC();			// Caller will have LOGFUNC'ed
#endif
	incOutstandingObjs();
	++iactive->RefCount;
	return(iactive->RefCount);
}





/****************** decActiveScriptRefcount() *******************
 * Decrement's our IActiveScript's (ACTIVESCRIPT) reference count.
 */

ULONG decActiveScriptRefcount(ACTIVESCRIPT *iactive)
{
#ifdef LOGTRACE
	if (LogFlag != (unsigned char)-1) UNLOGFUNC();			// Caller will have LOGFUNC'ed
#endif

	if (!IsBadWritePtr(iactive, sizeof(ACTIVESCRIPT)))
	{
		register ULONG	val;

		decOutstandingObjs();
		if (!(val = --iactive->RefCount))
		{
			register ACTIVESCRIPT	*this;
			register ACTIVESCRIPT	*prev;

			// If we're not CLOSED, then do a close
			if (iactive->HostScriptSite)
			{
				iactive->HostThreadID = GetCurrentThreadId();
				Close(iactive);
			}

			// Remove it from the master list
			prev = 0;
			EnterCriticalSection(&InterruptSection);
			this = ActiveScriptList;
			while (this)
			{
				if (this == iactive)
				{
					if (prev)
						prev->Next = iactive->Next;
					else
						ActiveScriptList = iactive->Next;
					break;
				}

				prev = this;
				this = this->Next;
			}
			LeaveCriticalSection(&InterruptSection);

			// Free the ACTIVESCRIPT
			FREEMEM(iactive);
		}

#ifdef LOGTRACE
		if (LogFlag != (unsigned char)-1) LOGINTPARAM("Outstanding references", val);
#endif
		return(val);
	}
	return(0);
}





/****************** queryActiveScriptInterface() *******************
 * Does the work of our IActiveScript's QueryInterface().
 */

HRESULT queryActiveScriptInterface(ACTIVESCRIPT *iactive, REFIID riid, void **ppvObj)
{
//	if (!IsBadWritePtr(ppvObj, sizeof(void *)))
	{
		*ppvObj = 0;

		if (!IsBadWritePtr(iactive, sizeof(ACTIVESCRIPT)))
		{
			// Only a debugging host sees the following sub-objects
			if (iactive->HostDebugApplication)
			{
				if (IsEqualIID(riid, &IID_IRemoteDebugApplicationEvents))
				{
					*ppvObj = (void *)((unsigned char *)iactive + offsetof(ACTIVESCRIPT, RemoteDebugAppEvents));
add:				incActiveScriptRefcount(iactive);
					return(S_OK);
				}

				if (IsEqualIID(riid, &IID_IDebugStackFrameSniffer))
				{
					*ppvObj = (void *)((unsigned char *)iactive + offsetof(ACTIVESCRIPT, DebugStackFrameSniffer));
					goto add;
				}

				if (IsEqualIID(riid, &IID_IActiveScriptDebug))
				{
					*ppvObj = (void *)((unsigned char *)iactive + offsetof(ACTIVESCRIPT, ActiveScriptDebug));
					goto add;
				}
			}

			// Check for other sub-objects that are given to both a debugging and non-debugging host
			if (IsEqualIID(riid, &IID_IActiveScript) || IsEqualIID(riid, &IID_IUnknown))
			{
				*ppvObj = (void *)iactive;
				goto add;
			}

			if (IsEqualIID(riid, &IID_IActiveScriptParse))
			{
				*ppvObj = (void *)((unsigned char *)iactive + offsetof(ACTIVESCRIPT, ActiveScriptParse));
				goto add;
			}

			if (IsEqualIID(riid, &IID_IActiveScriptParseProcedure))
			{
				*ppvObj = (void *)((unsigned char *)iactive + offsetof(ACTIVESCRIPT, ActiveScriptParseProcedure));
				goto add;
			}

			if (IsEqualIID(riid, &IID_IHostInfoUpdate))
			{
				*ppvObj = (void *)((unsigned char *)iactive + offsetof(ACTIVESCRIPT, HostInfoUpdate));
				goto add;
			}

			if (IsEqualIID(riid, &IID_IObjectSafety))
			{
				*ppvObj = (void *)((unsigned char *)iactive + offsetof(ACTIVESCRIPT, ObjectSafety));
				goto add;
			}

			LOGGUID("UNSUPPORTED: ", riid);
#ifdef LOGTRACE
			if (LogFlag != (unsigned char)-1) UNLOGFUNC();
#endif
			return(E_NOINTERFACE);
		}
	}

#ifdef LOGTRACE
	if (LogFlag != (unsigned char)-1) UNLOGFUNC();
#endif
	return(E_POINTER);
}
















// ===========================================================================
// The IActiveScript is the main object for an ActiveX Script Engine.
// It controls the object model the engine can use in its scripts. IActiveScript
// also give the host control over the running of scripts, from starting scripts
// to controlling the script thread.
// ===========================================================================

// NOTE: The IUnknown functions of all other objects embedded inside of
// our ACTIVESCRIPT delegate to the IActiveScript's QueryInterface, AddRef,
// and Release functions. That way, any one of those objects can be gotten
// by QueryInterface'ing on any other of those objects. 

/************************ QueryInterface() *************************
 */

static STDMETHODIMP Script_QueryInterface(ACTIVESCRIPT *this, REFIID riid, void **ppvObj)
{
	LOGFUNC("IActiveScript::QueryInterface");
	return(queryActiveScriptInterface(this, riid, ppvObj));
}

/*************************** AddRef() ******************************
 */

static STDMETHODIMP_(ULONG) Script_AddRef(ACTIVESCRIPT *this)
{
	LOGFUNC("IActiveScript::AddRef");
	return(incActiveScriptRefcount(this));
}

/************************** Release() ******************************
 */

static STDMETHODIMP_(ULONG) Script_Release(ACTIVESCRIPT *this)
{
	LOGFUNC("IActiveScript::Release");
	return(decActiveScriptRefcount(this));
}





/************************* AddTypeLib() *************************
 * Allows the host to provide a type lib to the engine for
 * constants, named item type information, etc.
 *
 * guid =		The type library's GUID.
 * dwMaj =		The major version of the type library
 * dwMin =		The minor version of the type library
 * flags =		SCRIPTTYPELIB_ISCONTROL 
 *				SCRIPTTYPELIB_ISPERSISTENT
 *				SCRIPTTYPELIB_ALL_FLAGS
 */

static STDMETHODIMP AddTypeLib(ACTIVESCRIPT *this, REFGUID guid, DWORD dwMaj, DWORD dwMin, DWORD flags)
{
	LOGFUNC("IActiveScript::AddTypeLib");
	UNLOGFUNC();

	// We don't support AddTypeLib in this engine
	return(E_NOTIMPL);
}





/*************************** Clone() **************************
 * Clones this script engine, returning a new script engine which
 * is identical to this one, if it were transitioned back to the
 * initialized state. All named items added with SCRIPTITEM_ISPERSISTENT,
 * all typelibs added with SCRIPTTYPELIB_ISPERSISTENT, and all
 * script added with SCRIPTTEXT_ISPERSISTENT are carried over to
 * the new engine.
 *
 * pObj =	Where to return the IActiveScript for the new engine.
 *
 * NOTE: The host must followup with a call to the new engine's
 * SetScriptSite to give it the host's IActiveScriptSite.
 *
 * NOTE: This can be called from a thread other than the one that
 * initially called our SetScriptSite (ie, our base thread). We
 * must _not_ call any other function that mandates that it can be
 * called only from the base thread. We also must not call any of
 * the host's IActiveScriptSite methods.
 */

static STDMETHODIMP Clone(ACTIVESCRIPT *this, IActiveScript **pObj)
{
	LOGFUNC("IActiveScript::Clone");
	UNLOGFUNC();

	// Currently, we don't support Cloning this script engine
	*pObj = 0;
	return(E_NOTIMPL);
}





/************************ GetScriptSite() ************************
 * Returns some sub-object of host's IActiveScriptSite object.
 *
 * vTableGuid = The VTable GUID of the sub-object to return. For
 *				example, to return the IActiveScriptSite, pass
 *				IID_IActiveScriptSite.
 * pObj =		Where to return the sub-object.
 *
 * NOTE: Does an AddRef(), so the caller is expected to Release()
 * the returned sub-object.
 */

static STDMETHODIMP GetScriptSite(ACTIVESCRIPT *this, REFIID vTableGuid, void **pObj)
{
	LOGFUNC("IActiveScript::GetScriptSite");
	UNLOGFUNC();

	// NOTE: Technically, we should check this->HostThreadID == GetCurrentThreadId()
	// to make sure that the caller thread is the same one that called SetScriptSite,
	// but let's leave this up to the app

	if (!IsBadWritePtr(this, sizeof(ACTIVESCRIPT)) && this->HostScriptSite)
		return(this->HostScriptSite->lpVtbl->QueryInterface(this->HostScriptSite, vTableGuid, pObj));
	return(E_FAIL);
}





/*********************** SetScriptSite() ***********************
 * Called by the host to give us its IActiveScriptSite object.
 * This must be called before any other IActiveScript method
 * may be used.
 */

static STDMETHODIMP SetScriptSite(ACTIVESCRIPT *this, IActiveScriptSite *hostScriptSite)
{
	register HRESULT	hr;

	LOGFUNC("IActiveScript::SetScriptSite");

	hr = E_INVALIDARG;
	if (!IsBadWritePtr(this, sizeof(ACTIVESCRIPT)) && !this->HostScriptSite)
	{
		// Get the host's IActiveScriptSiteDebug
		if ((hr = hostScriptSite->lpVtbl->QueryInterface(hostScriptSite, &IID_IActiveScriptSiteDebug, (void **)&this->HostScriptSiteDebug)))
		{
			// We have a dumb host (ie, it doesn't implement IActiveScriptSiteDebug), which means
			// we have to implement that on behalf of the host if the enduser wants to allow debugging.
			// One method would be to check if a certain registry key is set (by the enduser) to allow
			// debugging. If so, then we'll implement the need host debugger hooks here via allocSmartHost()
//			if ()
//			{
//				// Create a new IActiveScriptSiteDebug (ie, actually a SIMPLEHOST)
//				hr = S_OK;
//				if (!(( this->HostScriptSiteDebug = allocSmartHost(hostScriptSite) ))) hr = E_OUTOFMEMORY;
//			}
		}

		// Get the host's IDebugApplication
		if (!hr && !(hr = this->HostScriptSiteDebug->lpVtbl->GetApplication(this->HostScriptSiteDebug, &this->HostDebugApplication)))
		{
			// Give the host's IDebugApplication our IDebugStackFrameSniffer, so the host
			// can browse the variables/functions in this engine. Save the cookie we get
			// back, so we can detach our IDebugStackFrameSniffer when we close
			hr = this->HostDebugApplication->lpVtbl->AddStackFrameSniffer(this->HostDebugApplication, (IDebugStackFrameSniffer *)((unsigned char *)this + offsetof(ACTIVESCRIPT, DebugStackFrameSniffer)), &this->SnifferCookie);
		}

		// No debugging facilities? If not, cleanup from above
		if (hr)
		{
			if (this->HostScriptSiteDebug)
			{
				this->HostScriptSiteDebug->lpVtbl->Release(this->HostScriptSiteDebug);
				this->HostScriptSiteDebug = 0;
			}
				
			if (this->HostDebugApplication)
			{
				this->HostDebugApplication->lpVtbl->Release(this->HostDebugApplication);
				this->HostDebugApplication = 0;
			}
		}
		else
		{
			IConnectionPointContainer	*container;

			// AddRef the host IDebugApplication. Is this a duplication from GetApplication()???!!!
			this->HostDebugApplication->lpVtbl->AddRef(this->HostDebugApplication);

			// Get the current break flags and debug thread of the debugger
			this->HostDebugApplication->lpVtbl->GetBreakFlags(this->HostDebugApplication, &this->BreakFlags, &this->HostDebugThread);

			// We need to attach ourselves to some events which are available from the IDebugApplication.
			// If we fail to do this, then we won't receive those events, and we won't know to break.

			// Get the IConnectionPointContainer of the source object
			if (!(hr = this->HostDebugApplication->lpVtbl->QueryInterface(this->HostDebugApplication, &IID_IConnectionPointContainer, (void **)&container)))
			{
				// Use the IConnectionPointContainer to get the IConnectionPoint we want
				hr = container->lpVtbl->FindConnectionPoint(container, &IID_IRemoteDebugApplicationEvents, &this->HostEventsConnPoint);

				// We're done with the IConnectionPointContainer, so release it
				container->lpVtbl->Release(container);
   
				if (!hr)
				{
					// Use the IConnectionPoint to hook up to the event source
					this->HostEventsConnPoint->lpVtbl->Advise(this->HostEventsConnPoint, (IUnknown *)&this->RemoteDebugAppEvents, &this->HostEventsConnCookie);
				}
			}
		}

		hr = S_OK;

		// Save the Thread ID of the calling thread. From now on, only this thread may call
		// certain of our other IActiveScript, IActiveScriptParse, and IActiveScriptParseProcedure
		// functions, with noted exceptions. So, the host thread that calls us here is now
		// considered the "base thread"
		this->HostThreadID = GetCurrentThreadId();

		// AddRef the host's IActiveScriptSite and store it in our ACTIVESCRIPT
		this->HostScriptSite = hostScriptSite;
		hostScriptSite->lpVtbl->AddRef(hostScriptSite);

		// Get the LCID to use for Error msgs, and load the appropriate DLL
		{
		LCID	currentLCID;

		if (!hostScriptSite->lpVtbl->GetLCID(hostScriptSite, &currentLCID)) errorSetLocale(currentLCID);
		}

		// Set our engine state to INITIALIZED if host has already called InitNew()
		if (this->InterpreterList && (this->EngineState == SCRIPTSTATE_CLOSED || this->EngineState == SCRIPTSTATE_UNINITIALIZED))
			this->HostScriptSite->lpVtbl->OnStateChange(this->HostScriptSite, (this->EngineState = SCRIPTSTATE_INITIALIZED));
	}

	LOGHEXPARAM("Returns", hr);
	UNLOGFUNC();
	return(hr);
}





/************************ GetScriptState() ***********************
 * Gets the current state of the engine.
 *  
 * pss =	Where to return the current state of the engine.
 *
 * NOTE: This can be called from a thread other than the one that
 * initially called our SetScriptSite (ie, our base thread). We
 * must _not_ call any other function that mandates that it can be
 * called only from the base thread. We also must not call any of
 * the host's IActiveScriptSite methods.
 */

static STDMETHODIMP GetScriptState(ACTIVESCRIPT *this, SCRIPTSTATE *pss)
{
	register ACTIVESCRIPT	*iactive;

	*pss = 0;

	LOGFUNC("IActiveScript::GetScriptState");

	// Because any thread can call here, we'll just temporarily disable multi-tasking,
	// before we access the ACTIVESCRIPT so that we don't do that while the base thread
	// may be Release()'ing it
	EnterCriticalSection(&InterruptSection);

	// Get the first ACTIVESCRIPT site created by the process that loaded our DLL
	// (ie, the caller's process)
	iactive = ActiveScriptList;
	do
	{
		// Is this ACTIVESCRIPT running? NOTE: We assume this ACTIVESCRIPT is the
		// one that the currently running engine thread is using. but there could
		// be several threads
		if (iactive->Flags & SCRIPTTHREADSTATE_RUNNING)
		{
			// Yes, return its state
			*pss = this->EngineState;
			break;
		}

		// Get the next ACTIVESCRIPT created by caller's process
	} while ((iactive = iactive->Next));

	// Re-enable multi-tasking
	LeaveCriticalSection(&InterruptSection);

	UNLOGFUNC();
	return(S_OK);
}





/********************* resetEngine() ************************
 * Resets the engine to an initialized state. Immediate
 * CINSTRUCTIONs are reset to flag them as "yet to be run",
 * and all non-persistent script objects are removed.
 */

static void resetEngine(ACTIVESCRIPT *iactive)
{
	unsigned char			reset;

	{
	register SCRIPTOBJECT	*scriptObj;
	register SCRIPTOBJECT	**pscriptObj;

	LOGFUNC("resetEngine");

	// Assume we won't need to update FUNCENTRY CINSTRUCTIONs
	reset = 0;

	// Scan the list of NamedItems. If the NamedItem is persistent, then reset
	// it and its associated CEVENTHANDLER and CINTERPRETER. If not, delete
	// it

	pscriptObj = &iactive->ScriptObjectList;
	while ((scriptObj = *pscriptObj))
	{
		CINTERPRETER	*interpreter;
		CEVENTHANDLER	*eventObject;

		// Release the host IDispatch we use to call the script object's functions
		releaseHostIDispatch(scriptObj);

		// See if it has a CINTERPRETER
		if (interpreter = findInterpreter(iactive, scriptObj->ObjName))

			// See if it's also a callback object
			eventObject = findEventObject(iactive, interpreter);

		// Is the object persistent?
		if (scriptObj->Flags & SCRIPTITEM_ISPERSISTENT)
		{
			if (interpreter)
			{
				// Reset IMMEDIATE CINSTRUCTIONs
				resetInterpreter(interpreter);

				// Is this CINTERPRETER for a callback IDispatch of ours?
				if (eventObject)
				{
					IDispatch	*hostDispatch;

					// Reset the callback IDispatch (ie, disconnect from host and free the CEVENTs).
					// NOTE: There is a potential problem here if the host called AddScriptlet().
					// We may have called aliasEvent() to substitute our internal name generated
					// by AddScriptlet(). But now, that will be lost. A different scheme should
					// perhaps be employed!!! But, this event sinking stuff is really archaic
					// IE support, so screw it
					resetCEventHandler(eventObject);

					// Get the host IDispatch from which we get the IConnectionPoint and ITypeInfo
					if (!getHostIDispatch(scriptObj, &hostDispatch, iactive->HostScriptSite))
					{
						// Update the list of functions/properties the host expects us to sink
						initCEventHandler(eventObject, hostDispatch);
					}
				}
			}

			pscriptObj = &(scriptObj->Next);
		}

		// Delete this SCRIPTOBJECT (and its CINTERPRETER and CEVENTHANDLER if it has one)
		else
		{
			// Unlink the SCRIPTOBJECT from the list
			*pscriptObj = (scriptObj->Next);

			if (interpreter)
			{
				if (eventObject)
				{
					// Remove its CEVENTHANDLER from the list
					{
					register CEVENTHANDLER	*evt;
					register CEVENTHANDLER	*prevEvt;

					prevEvt = 0;
					evt = iactive->EventHandlerList;
					while (evt)
					{
						if (evt == eventObject)
						{
							if (!prevEvt)
								iactive->EventHandlerList = evt->Next;
							else
								prevEvt->Next = evt->Next;
							break;
						}

						prevEvt = evt;
						evt = evt->Next;
					}
					}

					// Release the CEVENTHANDLER. This will resetCEventHandler() too
					releaseCEventHandler(eventObject);
				}

				// Unlink the CASINTEPRETER from the list
				{
				register CINTERPRETER	*this;
				register CINTERPRETER	*prev;

				prev = 0;
				this = iactive->InterpreterList;
				while (this)
				{
					if (this == interpreter)
					{
						if (!prev)
							iactive->InterpreterList = this->Next;
						else
							prev->Next = this->Next;
						break;
					}

					prev = this;
					this = this->Next;
				}
				}

				// Free the CINTERPRETER
				reset = 1;
				freeInterpreter(interpreter);
			}

			// Delete SCRIPTOBJECT
			freeScriptObject(scriptObj);
		}
	}
	}

	// Go through the CINSTRUCTIONs of all CINTERPRETERs and check that any
	// OPCODE_FUNCENTRY's ptr field is not invalid now (ie, it could have been
	// pointing to one of the CINSTRUCTIONs we just deleted)
	if (reset)
	{
		register CINTERPRETER	*interpreter;

		interpreter = iactive->InterpreterList;
		while (interpreter)
		{
			register CINSTRUCTION	*instruction;

			instruction = interpreter->InstructionList;
			while (instruction)
			{
				// Found the context yet?
				if (instruction->OpCode == OPCODE_FUNCENTRY)
				{
					register void	*ptr;

					ptr = *((void **)((unsigned char *)instruction + sizeof(CINSTRUCTION)));
					if ((ptr < (void *)&Functions[0] || ptr >= (void *)&Functions[MAX_BUILTINS]) && IsBadWritePtr(ptr, sizeof(CINSTRUCTION)));
						*((CINSTRUCTION **)((unsigned char *)instruction + sizeof(CINSTRUCTION))) = 0;
				}

				instruction = instruction->Next;
			}

			interpreter = interpreter->Next;
		}
	}

	UNLOGFUNC();
}

/******************** disableCallbacks() ********************
 * Iterates through all the CEVENTHANDLERS and tells them to
 * attach to their events.
 */

static void disableCallbacks(ACTIVESCRIPT *iactive)
{
	register CEVENTHANDLER	*pEventHandler;

	LOGFUNC("disableCallbacks");

	// Iterate through the list of event handlers and tell them to disconnect
	pEventHandler = iactive->EventHandlerList;
	while (pEventHandler)
	{
		disconnectCallbacks(pEventHandler);
		pEventHandler = pEventHandler->Next;
	}

	UNLOGFUNC();
}

/*********************** enableCallbacks() *************************
 * Tells the CEVENTHANDLERS to iterate through their events and
 * connect to their sources.
 */

static void enableCallbacks(ACTIVESCRIPT *iactive)
{
	register CEVENTHANDLER	*pEventHandler;

	LOGFUNC("enableCallbacks");

	//Iterate through the list of event handlers and tell them to connect
	pEventHandler = iactive->EventHandlerList;
	while (pEventHandler)
	{
		connectCallbacks(pEventHandler);
		pEventHandler = pEventHandler->Next;
	}

	UNLOGFUNC();
}

/********************** executeImmediateScripts() ********************
 * Iterates through the CINTERPRETERs and tells them to execute any 
 * code that has been added to their immediate code lists.
 */

void executeImmediateScripts(ACTIVESCRIPT *iactive)
{
	register CINTERPRETER	*interpreter;

	interpreter = iactive->InterpreterList;
	while (interpreter)
	{
		evaluateImmediate(interpreter, 0);
		interpreter = interpreter->Next;
	}
}


/********************** SetScriptState() ***********************
 * Moves the engine to the given state. If there are intervening
 * states between the current engine state and the requested
 * state, the engine transitions through those states.
 *
 * ss =		One of the following:
 *			SCRIPTSTATE_UNINITIALIZED
 *			SCRIPTSTATE_INITIALIZED
 *			SCRIPTSTATE_STARTED
 *			SCRIPTSTATE_CONNECTED
 *			SCRIPTSTATE_DISCONNECTED
 *			SCRIPTSTATE_CLOSED
 */

static STDMETHODIMP SetScriptState(ACTIVESCRIPT *this, SCRIPTSTATE ss)
{
	register HRESULT		hr;

	LOGFUNC("IActiveScript::SetScriptState");

	hr = E_INVALIDARG;
	if (!IsBadWritePtr(this, sizeof(ACTIVESCRIPT)))
	{
		// If we're in a CLOSED state, then this shouldn't have been called
		// so return E_UNEXPECTED
		if (this->EngineState == SCRIPTSTATE_CLOSED || this->HostThreadID != GetCurrentThreadId())
			return(E_UNEXPECTED);

		// Assume OK
		hr = S_OK;

		// If we are already in the requested state, do nothing and return S_OK
		if (ss != this->EngineState)
		{	
			// Transition from the current state to the requested state.  
			// Switch statements allow us to fall through intermediate states to the
			// desired state.
			switch (ss)
			{
				// We want to go to Uninitialized state
				case SCRIPTSTATE_UNINITIALIZED:
				// We want to go to Initialized state
				case SCRIPTSTATE_INITIALIZED:
				{
					switch (this->EngineState)
					{
						case SCRIPTSTATE_CONNECTED:
						{
							// Disconnect our callback objects from the host
							disableCallbacks(this);
						}

						case SCRIPTSTATE_DISCONNECTED:
						case SCRIPTSTATE_STARTED:
						{
							// Remove all non-persistant named items
							resetEngine(this);
						}

						case SCRIPTSTATE_INITIALIZED:
						{
							// NOTE: ss == SCRIPTSTATE_UNINITIALIZED
							// Release the IActiveScriptSite interface. This can't be right!!! We should
							// be freeing the host's IActiveScriptSiteDebug and other related objects
							// gotten in SetScriptSite()
							this->HostScriptSite->lpVtbl->Release(this->HostScriptSite);
							this->HostScriptSite = this->HostThreadID = 0;
						}
					}

					break;
				}

				case SCRIPTSTATE_STARTED:
				{
					switch (this->EngineState)
					{
						case SCRIPTSTATE_CONNECTED:
    						disableCallbacks(this);

						case SCRIPTSTATE_DISCONNECTED:
						case SCRIPTSTATE_UNINITIALIZED:
						case SCRIPTSTATE_INITIALIZED:
						{
							// Execute immediate scripts
							executeImmediateScripts(this);
						}
					}

					break;
				}

				case SCRIPTSTATE_CONNECTED:
				{
					switch (this->EngineState)
					{
						case SCRIPTSTATE_UNINITIALIZED:
						case SCRIPTSTATE_INITIALIZED:
						case SCRIPTSTATE_STARTED:
							executeImmediateScripts(this);

						case SCRIPTSTATE_DISCONNECTED:
						{
							// Give our callback IDispatches to the host
							enableCallbacks(this);
						}
					}

					break;
				}

				case SCRIPTSTATE_DISCONNECTED:
				{
					if (this->EngineState == SCRIPTSTATE_CONNECTED) disableCallbacks(this);
					break;
				} 

				case SCRIPTSTATE_CLOSED:
				{
#ifdef LOGTRACE
					LogFlag = 1;
#endif
					Close(this);
				}
			}

			this->EngineState = (unsigned char)ss;
			if (ss != SCRIPTSTATE_CLOSED && ss != SCRIPTSTATE_UNINITIALIZED) this->HostScriptSite->lpVtbl->OnStateChange(this->HostScriptSite, ss);
		}
	}

	LOGHEXPARAM("Returns", hr);
	UNLOGFUNC();
	return(hr);
}





/************************** Close() ************************
 * Causes the engine to complete any immediate script
 * event sinks, and macro invocations already in progress,
 * release any objects it may have, and abandon any scripts
 * it may have, thus entering a closed state. Host must
 * call this before Release()'ing the engine to avoid
 * reference counting problems.
 */

static STDMETHODIMP Close(ACTIVESCRIPT *this)
{
#ifdef LOGTRACE
	if (!LogFlag) LOGFUNC("IActiveScript::Close");
#endif

	if (!IsBadWritePtr(this, sizeof(ACTIVESCRIPT)))
	{
		if (this->HostThreadID && this->HostThreadID != GetCurrentThreadId())
		{
#ifdef LOGTRACE
			if (!LogFlag) UNLOGFUNC();
			LogFlag = 0;
#endif
			return(E_UNEXPECTED);
		}

		if (this->HostScriptSite) disableCallbacks(this);

		// Set the engine state to closed
		this->EngineState = SCRIPTSTATE_CLOSED;

		// If we gave an IDebugStackFrameSniffer to the host, we need to get it back
		if (this->SnifferCookie)
		{
			this->HostDebugApplication->lpVtbl->RemoveStackFrameSniffer(this->HostDebugApplication, this->SnifferCookie);
			this->SnifferCookie = 0;
		}

		// Release some extra objects/resources
		close_host_objects(this);

		// Free our "stack frame" stack
		freeTStack(&this->StackFrames, free_block);

		// Release the host's IActiveScriptSiteDebug
		if (this->HostScriptSiteDebug)
		{
			this->HostScriptSiteDebug->lpVtbl->Release(this->HostScriptSiteDebug);
			this->HostScriptSiteDebug = 0;
		}

		// Empty the list of SCRIPTOBJECTs
		{
		register SCRIPTOBJECT	*scriptObj;

		while ((scriptObj = this->ScriptObjectList))
		{
			this->ScriptObjectList = scriptObj->Next;
			freeScriptObject(scriptObj);
		}
		}

		// Empty the list of CEVENTHANDLERs
		{
		register CEVENTHANDLER	*handler;

		while ((handler = this->EventHandlerList))
		{
			this->EventHandlerList = handler->Next;
			releaseCEventHandler(handler);
		}
		}

		// Empty the list of CINTERPRETERs
		{
		register CINTERPRETER	*interpreter;

		while ((interpreter = this->InterpreterList))
		{
			this->InterpreterList = interpreter->Next;
			freeInterpreter(interpreter);
		}
		}

		// Release the host IActiveScriptSite
		if (this->HostScriptSite)
		{
			this->HostScriptSite->lpVtbl->OnStateChange(this->HostScriptSite, SCRIPTSTATE_CLOSED);
			this->HostScriptSite->lpVtbl->Release(this->HostScriptSite);
			this->HostScriptSite = this->HostThreadID = 0;
		}   
	}

#ifdef LOGTRACE
	if (!LogFlag) UNLOGFUNC();
	LogFlag = 0;
#endif
	return(S_OK);
}





/****************** GetCurrentScriptThreadID() *******************
 * Gets an engine-defined ID that the host can use to refer
 * to the currently running script thread. For example, the host
 * can pass this as the "id" arg to InterruptScriptThread() to
 * abort this script's thread.
 *
 * engineID = Where to return the engine-defined ID.
 *
 * NOTE: This can be called from a thread other than the one that
 * initially called our SetScriptSite (ie, our base thread). We
 * must _not_ call any other function that mandates that it can be
 * called only from the base thread. We also must not call any of
 * the host's IActiveScriptSite methods.
 *
 * NOTE: We can return whatever value we want to use as the engine-ID.
 * This can include a pointer to one of our own internal structs that
 * positively identifies the script thread, such as a pointer to the
 * ACTIVESCRIPT. But we must not use the values SCRIPTTHREADID_BASE
 * SCRIPTTHREADID_CURRENT, nor SCRIPTTHREADID_ALL for our own uses,
 * as those are reserved.
 */

static STDMETHODIMP GetCurrentScriptThreadID(ACTIVESCRIPT *this, SCRIPTTHREADID *engineID)
{
	register ACTIVESCRIPT	*iactive;

	LOGFUNC("IActiveScript::GetCurrentScriptThreadID");

	// Assume we won't find an ACTIVESCRIPT that is running
	*engineID = 0;

	// Because any thread can call here, we'll just temporarily disable multi-tasking,
	// before we access the ACTIVESCRIPT so that we don't do that while the base thread
	// may be Release()'ing it
	EnterCriticalSection(&InterruptSection);

	// Get the first ACTIVESCRIPT site created by the process that loaded our DLL
	// (ie, the caller's process)
	iactive = ActiveScriptList;
	do
	{
		// Is this ACTIVESCRIPT running? NOTE: We assume this ACTIVESCRIPT is the
		// one that the currently running engine thread is using. but there could
		// be several threads
		if (iactive->Flags & SCRIPTTHREADSTATE_RUNNING)
		{
			// Yes, return its ID
			*engineID = iactive->HostThreadID;
			break;
		}

		// Get the next ACTIVESCRIPT created by caller's process
	} while ((iactive = iactive->Next));

	// Re-enable multi-tasking
	LeaveCriticalSection(&InterruptSection);

	UNLOGFUNC();
	return(S_OK);
}





/************************* GetScriptThreadID() **********************
 * Translates a Win32 thread ID to our own engine-defined ID that the
 * host can use to refer to the passed thread. For example,
 * the host can pass this as the "id" arg to InterruptScriptThread()
 * to abort this script thread. 
 *
 * win32ThreadID = ID of a running Win32 thread in the caller's
 *				process.
 * engineID =	Where to return the engine-defined ID.
 *
 * NOTE: This can be called from a thread other than the one that
 * initially called our SetScriptSite (ie, our base thread). We
 * must _not_ call any other function that mandates that it can be
 * called only from the base thread. We also must not call any of
 * the host's IActiveScriptSite methods.
 */

static STDMETHODIMP GetScriptThreadID(ACTIVESCRIPT *this, DWORD win32ThreadID, SCRIPTTHREADID *engineID)
{
	register ACTIVESCRIPT	*iactive;
	
	LOGFUNC("IActiveScript::GetScriptThreadID");

	// Assume we won't find an ACTIVESCRIPT with a matching thread ID
	*engineID = 0;

	EnterCriticalSection(&InterruptSection);

	iactive = ActiveScriptList;
	do
	{
		// Does this ACTIVESCRIPT's creator thread ID match the one the caller wants?
		if (win32ThreadID == iactive->HostThreadID)
		{
			// Yes, return its "id" as defined by our own engine. Since our engine ID is
			// simply the same thing as the Win32 thread ID that did the SetScriptSite for
			// this ACTIVESCRIPT, we return that Win32 thread ID
			*engineID = win32ThreadID;
			break;
		}

	} while ((iactive = iactive->Next));

	LeaveCriticalSection(&InterruptSection);

	UNLOGFUNC();
	return(S_OK);
}





/************************* GetScriptThreadState() **********************
 * Returns the state of the specified script thread.
 *
 * engineID =	 The engine-defined ID of the thread whose state is to
 *				be returned. Could be one of the constants:
 *				SCRIPTTHREADID_BASE
 *				SCRIPTTHREADID_CURRENT
 * state =		Where to return the state.
 *
 * NOTE: This can be called from a thread other than the one that
 * initially called our SetScriptSite (ie, our base thread). We
 * must _not_ call any other function that mandates that it can be
 * called only from the base thread. We also must not call any of
 * the host's IActiveScriptSite methods.
 */

static STDMETHODIMP GetScriptThreadState(ACTIVESCRIPT *this, SCRIPTTHREADID engineID, SCRIPTTHREADSTATE *state)
{
	register ACTIVESCRIPT		*iactive;
	register SCRIPTTHREADSTATE	result;

	LOGFUNC("IActiveScript::GetScriptThreadState");

	// Assume script is not running
	result = 0;

	EnterCriticalSection(&InterruptSection);

	iactive = ActiveScriptList;
	if (engineID == SCRIPTTHREADID_CURRENT)
		engineID = GetCurrentThreadId();
	else if (engineID == SCRIPTTHREADID_BASE)
		engineID = iactive->HostThreadID;
	do
	{
		// Does this ACTIVESCRIPT's creator thread ID match the one the caller wants?
		if (engineID == iactive->HostThreadID && (iactive->Flags & SCRIPTTHREADSTATE_RUNNING))
		{
			// Yes, return its state
			result = SCRIPTTHREADSTATE_RUNNING;
			break;
		}

	} while ((iactive = iactive->Next));

	LeaveCriticalSection(&InterruptSection);

	*state = result;

	UNLOGFUNC();
	return(S_OK);
}





/********************** InterruptScriptThread() ***********************
 * Interrupts the execution of a running script thread (an event sink,
 * an immediate execution, or a macro invocation). This can be used to
 * terminate a script that is stuck (in an infinite loop, for example).
 *
 * engineID =	 The engine-defined ID of the thread to interrupt. Could be one
 *				of the constants:
 *				SCRIPTTHREADID_ALL
 *				SCRIPTTHREADID_BASE
 *				SCRIPTTHREADID_CURRENT
 *				It may also be an ID as returned from GetScriptThreadID().
 * pei =		Where to return EXCEPINFO struct info.
 * flags =		SCRIPTINTERRUPT_DEBUG
 *				SCRIPTINTERRUPT_RAISEEXCEPTION   
 *
 * NOTE: This can be called from a thread other than the one that
 * initially called our SetScriptSite (ie, our base thread). We
 * must _not_ call any other function that mandates that it can be
 * called only from the base thread. We also must not call any of
 * the host's IActiveScriptSite methods.
 */

static STDMETHODIMP InterruptScriptThread(ACTIVESCRIPT *this, SCRIPTTHREADID engineID, const EXCEPINFO *pei, DWORD flags)
{
	register ACTIVESCRIPT	*iactive;

	LOGFUNC("IActiveScript::InterruptScriptThread");
	LOGHEXPARAM("ThreadID", engineID);

	EnterCriticalSection(&InterruptSection);

	iactive = ActiveScriptList;

	if (engineID == SCRIPTTHREADID_CURRENT)
		engineID = GetCurrentThreadId();
	else if (engineID == SCRIPTTHREADID_BASE)
		engineID = iactive->HostThreadID;

	do
	{
		// Is this ACTIVESCRIPT currently running a script?
		// Does this ACTIVESCRIPT's creator thread ID match the one the caller wants to abort?
		if ((iactive->Flags & SCRIPTTHREADSTATE_RUNNING) && (engineID == SCRIPTTHREADID_ALL || engineID == iactive->HostThreadID))
		{
			// Indicate that the interpreter is in a condition of being halted by
			// setting the ACTIVESCRIPTFLAG_HALTRAISED flag. NOTE: The engine may not
			// yet be halted. This is simply a pending halt. The engine may be
			// executing in another thread.
			//
			// NOTE: This engine's language doesn't support SCRIPTINTERRUPT_RAISEEXCEPTION.
			// And our engine doesn't support SCRIPTINTERRUPT_DEBUG
			iactive->Flags |= ACTIVESCRIPTFLAG_HALTRAISED;
		}

	} while ((iactive = iactive->Next));

	LeaveCriticalSection(&InterruptSection);

	UNLOGFUNC();
	return(S_OK);
}





/*********************** GetScriptDispatch() ***********************
 * Allows the host to dynamically create/access variables, and call
 * functions found in the script (via our CINTERPRETER's IDispatch
 * Invoke function).
 *
 * itemName =	The name of the item the host needs an IDispatch for.
 * ppDisp =		Where to return the IDispatch pointer.
 *
 * Returns: S_OK, E_INVALIDARG, E_POINTER, E_UNEXPECTED, S_FALSE.
 *
 * NOTE: Each CINTERPRETER has its own IDispatch so a host can
 * use it to make calls to some function in a script, or set/query
 * variables).
 */

static STDMETHODIMP GetScriptDispatch(ACTIVESCRIPT *this, LPCOLESTR itemName, IDispatch **pObj)
{
	register CINTERPRETER		*interpreter;
	register HRESULT			hr;

	LOGFUNC("IActiveScript::GetScriptDispatch");

	hr = E_INVALIDARG;
	if (!IsBadWritePtr(this, sizeof(ACTIVESCRIPT)))
	{
		if (GetCurrentThreadId() != this->HostThreadID)
			hr = E_UNEXPECTED;
		else
		{
			hr = E_FAIL;

			// Find the CINTERPRETER that the caller wants and return its IDispatch
			if ((interpreter = findInterpreter(this, itemName)))
			{
				*pObj = (IDispatch *)interpreter;
				Dispatch_AddRef(interpreter);
				hr = S_OK;
			}
		}
	}

	LOGHEXPARAM("Returns", hr);
	UNLOGFUNC();
	*pObj = 0;
	return(hr);
}





/************************ AddNamedItem() ************************
 * Allows the host to add a named item (object) to the script
 * engine's global namespace. The engine can therefore automate
 * objects through the host IActiveScriptSite's GetItemInfo().
 * Code added to the engine with AddScriptlet or ParseScriptText
 * where itemName is not NULL must use an Item name previously
 * added with AddNamedItem.
 *
 * pstrName -- The name to be added to the engine's namespace
 * flags =	Any combination of the following OR'ed together:
 *				SCRIPTITEM_CODEONLY
 *				SCRIPTITEM_GLOBALMEMBERS
 *				SCRIPTITEM_ISPERSISTENT
 *				SCRIPTITEM_ISSOURCE
 *				SCRIPTITEM_ISVISIBLE
 *				SCRIPTITEM_NOCODE
 */

static STDMETHODIMP AddNamedItem(ACTIVESCRIPT *this, LPCOLESTR pstrName, DWORD flags)
{
	register HRESULT	hr;

	LOGFUNC("IActiveScript::AddNamedItem");

	if (IsBadWritePtr(this, sizeof(ACTIVESCRIPT))) goto badarg;

	// Make sure host has called our SetScriptSite() and InitNew()
	if (!this->InterpreterList || this->HostThreadID != GetCurrentThreadId()) hr = E_FAIL;
	else
	{
		// CODEONLY conflicts with everything but ISPERSISTENT
		if ((flags & SCRIPTITEM_CODEONLY) && (flags & (SCRIPTITEM_GLOBALMEMBERS|SCRIPTITEM_ISSOURCE|SCRIPTITEM_ISVISIBLE|SCRIPTITEM_NOCODE)))
badarg:		hr = E_INVALIDARG;
		else
		{
			// If the object is NOCODE, we don't need a CINTERPRETER for it. The
			// host will not be giving us any code for this object. Typically,
			// the NOCODE is used in conjunction with ISVISIBLE to indicate that
			// the host is giving us an object whose functions will be callable
			// by the script and accessed by our engine calling a host IDispatch's
			// Invoke (so all the coding for that function is inside the host)
			if (flags & SCRIPTITEM_NOCODE)
			{
				// If the host isn't going to supply any script code to us, then
				// this object _can't_ be our callback object. After all, how can our
				// engine allow the host to call some script function that hasn't
				// been given us?
				if (flags & SCRIPTITEM_ISSOURCE) goto badarg;

				// We don't want to create a SCRIPTOBJECT here because the object may not
				// be visible (ie, SCRIPTITEM_ISVISIBLE may not be specified). Although
				// NOCODE without ISVISIBLE doesn't make much sense, it's allowable
			}

			// If GLOBALMEMBERS or ISVISIBLE, then the script itself can call this
			// host object's functions. In that case, we need a SCRIPTOBJECT struct so
			// we can store the host IDispatch whose GetIDsOfNames and Invoke
			// functions we'll call on behalf of the script
			else if (flags & (SCRIPTITEM_GLOBALMEMBERS|SCRIPTITEM_ISVISIBLE))
			{
				register SCRIPTOBJECT	*scriptObj;

				if (!(scriptObj = findScriptObject(this, pstrName)))
				{
					// NOTE: We haven't yet gotten the host IDispatch. We'll get it
					// later, when we actually need it
					if (!(scriptObj = allocScriptObject(pstrName, flags)))
					{
nomem:					hr = E_OUTOFMEMORY;
						goto out;
					}

					// Link it into the SCRIPTOBJECTs list
					scriptObj->Next = this->ScriptObjectList;
					this->ScriptObjectList = scriptObj;
				}
				else if (scriptObj->Flags != flags)
					goto badarg;
			}

			hr = S_OK;

			// Is this for a callback object? (ie, The host plans to give us some
			// script code, and expects us to provide the host with some callback
			// IDispatch the host can use to Invoke the script). Or, is it at
			// least some object which the host will be adding code to?
			if ((flags & SCRIPTITEM_ISSOURCE) || !(flags & SCRIPTITEM_NOCODE))
			{
				register CINTERPRETER		*interpreter;

				if ((interpreter = findInterpreter(this, pstrName)))
				{
					register CEVENTHANDLER	*eventObject;

					eventObject = findEventObject(this, interpreter);
					if (flags & SCRIPTITEM_ISSOURCE)
					{
						if (!eventObject) goto badarg;
					}
					else if (eventObject) goto badarg;
					goto out;
				}

				// Create a new CINTERPRETER (with its embedded IDispatch so a host
				// can get that IDispatch via our IActiveScript's GetScriptDispatch
				// and call a script function) for this object
				if (!(interpreter = allocInterpreter(pstrName, this))) goto nomem;

				// If a callback object, then we need to also create a CEVENTHANDLER
				// for this object, so that we can manage the translation of a
				// DISPID to a call to its respective script function. We'll
				// actually get the DISPID when the host later adds the code via
				// AddScriptlet or ParseScriptText
				if (flags & SCRIPTITEM_ISSOURCE)
				{
					register CEVENTHANDLER	*eventObject;

					if (!(eventObject	= allocCEventHandler(interpreter))) goto nomem;
					eventObject->Next = this->EventHandlerList;
					this->EventHandlerList = eventObject;
				}
			}
		}
	}

out:
	LOGHEXPARAM("Returns", hr);
	UNLOGFUNC();
	return(hr);
}





















// ===========================================================================
// The IActiveScriptParse controls the initialization and addition of script
// to a script engine.
// ===========================================================================

/************************ QueryInterface() *************************
 */

static STDMETHODIMP ScriptParse_QueryInterface(IActiveScriptParse *this, REFIID riid, void **ppvObj)
{
	LOGFUNC("IActiveScriptParse::QueryInterface");
	return(queryActiveScriptInterface((ACTIVESCRIPT *)((unsigned char *)this - offsetof(ACTIVESCRIPT, ActiveScriptParse)), riid, ppvObj));
}

/*************************** AddRef() ******************************
 */

static STDMETHODIMP_(ULONG) ScriptParse_AddRef(IActiveScriptParse *this)
{
	LOGFUNC("IActiveScriptParse::AddRef");
	return(incActiveScriptRefcount((ACTIVESCRIPT *)((unsigned char *)this - offsetof(ACTIVESCRIPT, ActiveScriptParse))));
}

/************************** Release() ******************************
 */

static STDMETHODIMP_(ULONG) ScriptParse_Release(IActiveScriptParse *this)
{
	LOGFUNC("IActiveScriptParse::Release");
	return(decActiveScriptRefcount((ACTIVESCRIPT *)((unsigned char *)this - offsetof(ACTIVESCRIPT, ActiveScriptParse))));
}





/**************************** InitNew() *************************
 * Initializes the script engine. This must be called before any
 * script is added with AddScriptlet or ParseScriptText.
 */

static STDMETHODIMP InitNew(IActiveScriptParse *this)
{
	register HRESULT		hr;
	register ACTIVESCRIPT	*iactive;

	LOGFUNC("IActiveScriptParse::InitNew");

	// Get the ACTIVESCRIPT
	iactive = (ACTIVESCRIPT *)((unsigned char *)this - offsetof(ACTIVESCRIPT, ActiveScriptParse));

	// Check args
	hr = E_INVALIDARG;
	if (!IsBadWritePtr(iactive, sizeof(ACTIVESCRIPT)))
	{
		// Create a CINTERPRETER for our "global or default object". This is the
		// object that contains code that the host adds without specifying a
		// "named item" (ie, object name) when the host calls ParseScriptText.
		// This code also automatically runs when the engine's state is set to
		// CONNECTED. (ie, It contains the "entry point" of the script)
		hr = S_OK;
		if (!iactive->InterpreterList && !allocInterpreter(0, iactive)) hr = E_OUTOFMEMORY;

		// Set our engine state to INITIALIZED if host has already SetScriptSite()
		else if (iactive->HostScriptSite && (iactive->EngineState == SCRIPTSTATE_CLOSED || iactive->EngineState == SCRIPTSTATE_UNINITIALIZED))
			iactive->HostScriptSite->lpVtbl->OnStateChange(iactive->HostScriptSite, (iactive->EngineState = SCRIPTSTATE_INITIALIZED));
	}

	LOGHEXPARAM("Returns", hr);
	UNLOGFUNC();
	return(hr);
}





/********************** getNamedItemIDispatch() **********************
 * Retrieves the IDispatch pointer associated with a name added by the
 * host via our IActiveScript's AddNamedItem.
 *
 * itemName -- The name added with AddNamedItem
 * subItemName -- The name of a subitem within itemName. If
 *                   specified, the IDispatch of the subitem will
 *                   be returned.
 * ppDispatch -- Where to return the IDispatch pointer.
 *
 * Returns: S_OK, E_INVALIDARG, E_POINTER, TYPE_E_ELEMENTNOTFOUND
 */

static HRESULT getNamedItemIDispatch(ACTIVESCRIPT *iactive, LPCOLESTR itemName, LPCOLESTR subItemName, IDispatch **ppDispatch)
{
	register HRESULT	hr;
	IUnknown			*unknown;
	IDispatch			*dispatch;

	LOGFUNC("getNamedItemIDispatch");

	// Call host's IActiveScriptSite GetItemInfo to retrieve the IDispatch of named item
	if (!(hr = iactive->HostScriptSite->lpVtbl->GetItemInfo(iactive->HostScriptSite, itemName, SCRIPTINFO_IUNKNOWN, &unknown, 0)))
	{
		// Get the IDispatch from the IUnknown and AddRef it
		hr = unknown->lpVtbl->QueryInterface(unknown, &IID_IDispatch, (void **)&dispatch);
		unknown->lpVtbl->Release(unknown);
		if (!hr)
		{
			// If a SubItem name is specified, then we need to get that SubItem's
			// IDispatch, we do this using the parent object's GetIDsOfNames and
			// Invoke functions
			if (subItemName)
			{
				DISPID		dispId;
				VARIANT		ret;

				VariantInit(&ret);

				// Get the DISPID of the SubItem name
				if (!(hr = dispatch->lpVtbl->GetIDsOfNames(dispatch, &IID_NULL, (unsigned short **)&subItemName, 1, 0, &dispId)))
				{
					DISPPARAMS		params;

					ZeroMemory(&params, sizeof(DISPPARAMS));
              
					// Get the value of this SubItem (as a propget). It should return an IDispatch *
					if (!(hr = dispatch->lpVtbl->Invoke(dispatch, dispId, &IID_NULL, 0, DISPATCH_PROPERTYGET, &params, &ret, 0, 0)))
					{
						if (ret.vt != VT_DISPATCH)
						{
							VariantClear(&ret);
							hr = TYPE_E_ELEMENTNOTFOUND;
						}

						// NOTE: Do not VariantClear() if we got the SubItem IDispatch. Invoke()
						// has done an AddRef() on it, and we want that AddRef maintained. A
						// VariantClear would do a Release()
					}
				}

				// Release the parent IDispatch
				dispatch->lpVtbl->Release(dispatch);

				// Use the SubItem's IDispatch
				dispatch = ret.pdispVal;
			}

			// Return the IDispatch to the caller
			*ppDispatch = dispatch;
		}
	}

	if (hr) *ppDispatch = 0;
	LOGHEXPARAM("Returns", hr);
	UNLOGFUNC();
	return(hr);
}

/************************ ParseScriptText() ***********************
 * Parses the given script text, adding it to the engine's
 * namespace. If the engine is in CONNECTED state, or the host
 * asks for the code to be "evaluated" (ie, its return value
 * to be returned), then the script is also run.
 *
 * scriptCode =	The script code in textual form, nul-terminated.
 * itemName =	The name of the object to which this script
 *				belongs. 0 if the script should be placed in
 *				the global (default) object. This name must
 *				have been previously registered by the host
 *				calling our IActiveScript's AddNamedItem.
 * punk =		Reserved for the debugger.
 * delimiter =	The delimiter the host used to mark the start
 *				and end of the script. This is used when the
 *				script is embedded on a web page.
 * cookie =		Host-defined value for debugging
 * startLineNum = Zero-based number defining where parsing began.
 * flags =		SCRIPTTEXT_DELAYEXECUTION 
 *				SCRIPTTEXT_ISVISIBLE
 *				SCRIPTTEXT_ISEXPRESSION
 *				SCRIPTTEXT_ISPERSISTENT
 *				SCRIPTTEXT_HOSTMANAGESSOURCE
 *				SCRIPTTEXT_ALL_FLAGS
 * result =		Where to return the scriptlet's return value.
 * pei =		Where to return error information.
 *
 * Returns: S_OK, DISP_E_EXCEPTION, E_INVALIDARG, E_POINTER, E_NOTIMPL
 * E_UNEXPECTED, OLESCRIPT_E_SYNTAX
 */

static STDMETHODIMP ParseScriptText(IActiveScriptParse *this, LPCOLESTR scriptCode, LPCOLESTR itemName, IUnknown *punk, LPCOLESTR delimiter, DWORD context, ULONG startLineNum, DWORD flags, VARIANT *result, EXCEPINFO *pei)
{
	register HRESULT		hr;
	register ACTIVESCRIPT	*iactive;

	LOGFUNC("IActiveScriptParse::ParseScriptText");

	// Get the ACTIVESCRIPT
	iactive = (ACTIVESCRIPT *)((unsigned char *)this - offsetof(ACTIVESCRIPT, ActiveScriptParse));

	// Check args
	hr = E_INVALIDARG;
	if (/* !IsBadReadPtr(scriptCode, sizeof(OLECHAR)) && (!itemName || !IsBadReadPtr(itemName, sizeof(OLECHAR))) && */
		!IsBadWritePtr(iactive, sizeof(ACTIVESCRIPT)) && iactive->HostThreadID == GetCurrentThreadId() && iactive->InterpreterList)
	{
		// Clear caller's return variables
		if (result)
		{
//			if (IsBadWritePtr(result, sizeof(VARIANT))) goto out;
			VariantInit(result);
		}

		if (pei)
		{
//			if (IsBadWritePtr(pei, sizeof(EXCEPINFO))) goto out;
			ZeroMemory(pei, sizeof(EXCEPINFO));
		}

		// We don't support SCRIPTTEXT_DELAYEXECUTION, SCRIPTTEXT_ISEXPRESSION, or any future-defined flags
		if (flags & ~(SCRIPTTEXT_ISVISIBLE|SCRIPTTEXT_ISPERSISTENT|SCRIPTTEXT_HOSTMANAGESSOURCE))
			hr = E_NOTIMPL;
		else
		{
			register CINTERPRETER	*interpreter;
			BOOL					fWasConnected;

			// Make sure that the host has called InitNew(). If so, we have
			// a "global" CINTERPRETER. Also make sure that the host's
			// IActiveScripSite was given to us
			if (!(interpreter = iactive->InterpreterList) || !iactive->HostScriptSite) hr = E_FAIL;
			else
			{
				// If we implemented our own Smart Host, we need to do something that the
				// host should have done, namely, add this script's text to the IDebugDocumentHelper
				if (iactive->HostScriptSiteDebug && iactive->HostScriptSiteDebug->lpVtbl == &IActiveScriptSiteDebug_Vtbl)
				{
					addScriptTextToDebugger(iactive, scriptCode, 0);
					context = (DWORD)scriptCode;
				}

				// If we've given the host some callback IDispatches, temporarily disallow the host to
				// Invoke() any script functions via those IDispatches. We don't want the host to be
				// doing that while we're adding a new script to our engine
				fWasConnected = 0;
				if (iactive->EngineState == SCRIPTSTATE_CONNECTED)
				{
					disableCallbacks(iactive);
					iactive->EngineState = SCRIPTSTATE_DISCONNECTED;
					fWasConnected = 1;
				}

				hr = S_OK;

				// Did the host specify the name of an object to which this script is added?
				if (itemName && *itemName)
				{
					CEVENTHANDLER	*pEventHandler;

					// Retrieve the CINTERPRETER for this object
					if (!(interpreter = findInterpreter(iactive, itemName))) hr = E_INVALIDARG;

					// See if there is also a CEVENTHANDLER associated with this object.
					// (ie, If the host has specified that this object sources events -- the
					// host wants us to implement an IDispatch "callback object" -- then
					// we should have allocated a CEVENTHANDLER for it when the host
					// called our IActiveScript's AddNamedItem)
					else if ((pEventHandler = findEventObject(iactive, interpreter)) &&

						// Yes, it's a callback object. We need to create an IDispatch
						// and give it to the host's IConnectionPoint so that the host
						// can use our IDispatch Invoke() to call this script that is
						// just now being added

						// If the CEVENTHANDLER isn't already initialized, do that now
						!(pEventHandler->Flags & HANDLER_ISINITIALIZED))
					{
						IDispatch	*hostDispatch;

						// Get the IDispatch for this host object (ie, the IDispatch we use to get
						// get the host's IConnectPoint, and also get the ITypeInfo that tells us
						// what names we should give to the callback functions in the script).
						//
						// NOTE: getNamedItemIDispatch does an AddRef
						if (!getNamedItemIDispatch(iactive, itemName, 0, &hostDispatch))
						{
							// Get the list of function names (and their DISPIDs) that the
							// host expects a script to implement
							initCEventHandler(pEventHandler, hostDispatch);
						}
					}
				}

				// Parse the script text inside the object's CINTERPRETER
				if (!hr) hr = createInstructionList(interpreter, scriptCode, startLineNum, context);

				// Let the host use our callback IDispatches again, if we had
				// temporarily disabled them above
				if (fWasConnected)
				{
					enableCallbacks(iactive);
					iactive->EngineState = SCRIPTSTATE_CONNECTED;
				}

				// If the engine has been started, then execute any immediate code in
				// the code block
				if (!hr && (iactive->EngineState == SCRIPTSTATE_STARTED || iactive->EngineState == SCRIPTSTATE_CONNECTED))
					hr = evaluateImmediate(interpreter, result);
			}
		}
	}
//out:
	LOGHEXPARAM("Returns", hr);
	UNLOGFUNC();
	return(hr);
}





/************************* AddScriptlet() **************************
 * Adds a scriptlet to the engine.  This is primarily used in HTML
 * based scripting to add event handlers to the engine. In a way,
 * it's like a call to AddNamedItem and ParseScriptText rolled
 * into one.
 *
 * defaultName = Default name of the scriptlet
 * scriptCode =	The scriptlet text, in textual form.
 * itemName =	The script object name associated with the script
 * subItemName = The script sub-name associated with the script.
 *				ItemName and subItemName designate the object whose 
 *				event this scriptlet sinks.
 * eventName =	The name of the event this scriptlet sinks.
 * delimiter =	The delimiter the host used to detect
 *				the end of the scriptlet
 * context =	Application defined value for debugging
 * startLineNum = zero-based number defining where parsing began.
 * flags =		SCRIPTTEXT_ISVISIBLE
 *				SCRIPTTEXT_ISPERSISTENT  
 * funcName =	Where to return the name we use to identify the scriptlet
 * pei =		Where to return error information.
 *
 * Returns: S_OK, DISP_E_EXCEPTION, E_INVALIDARG, E_NOTIMPL, E_POINTER
 * E_UNEXPECTED, OLESCRIPT_E_INVALIDNAME, OLESCRIPT_E_SYNTAX  
 */

static STDMETHODIMP AddScriptlet(IActiveScriptParse *this, LPCOLESTR defaultName, LPCOLESTR scriptCode, LPCOLESTR itemName, LPCOLESTR subItemName, LPCOLESTR eventName, LPCOLESTR delimiter, DWORD context, ULONG startLineNum, DWORD flags, BSTR *funcName, EXCEPINFO *pei)
{
	register HRESULT		hr;
	register ACTIVESCRIPT	*iactive;

	LOGFUNC("IActiveScriptParse::AddScriptlet");

	// Get the ACTIVESCRIPT
	iactive = (ACTIVESCRIPT *)((unsigned char *)this - offsetof(ACTIVESCRIPT, ActiveScriptParse));

	hr = E_INVALIDARG;
	if (/* !IsBadReadPtr(scriptCode, sizeof(OLECHAR)) && !IsBadReadPtr(itemName, sizeof(OLECHAR)) &&
		!IsBadReadPtr(eventName, sizeof(OLECHAR)) && (!funcName || !IsBadWritePtr(funcName, sizeof(void *))) && */
		!IsBadWritePtr(iactive, sizeof(ACTIVESCRIPT)) && iactive->HostThreadID == GetCurrentThreadId() && iactive->InterpreterList)
	{
		CINTERPRETER	*interpreter;
		CEVENTHANDLER	*eventHandler;
		BOOL			fWasConnected;

		if (pei)
		{
//			if (IsBadWritePtr(pei, sizeof(EXCEPINFO))) goto badout;
			ZeroMemory(pei, sizeof(EXCEPINFO));
		}

		if (!iactive->InterpreterList || !iactive->HostScriptSite) hr = E_FAIL;
		else
		{
			if (iactive->HostScriptSiteDebug && iactive->HostScriptSiteDebug->lpVtbl == &IActiveScriptSiteDebug_Vtbl)
			{
				addScriptTextToDebugger(iactive, scriptCode, 1);
				context = (DWORD)scriptCode;
			}

			fWasConnected = 0;
			if (iactive->EngineState == SCRIPTSTATE_CONNECTED)
			{
				disableCallbacks(iactive);
				iactive->EngineState = SCRIPTSTATE_DISCONNECTED;
				fWasConnected = 1;
			}

			// Search for the CINTERPRETER for this host object (which we should
			// have allocated in the host's call to our IActiveScript's AddNamedItem)
			if (!(interpreter = findInterpreter(iactive, itemName)))
				hr = E_INVALIDARG;
			else
			{
				LPOLESTR	objectName;
				LPOLESTR	functionName;

				objectName = functionName = 0;

				// Create an object name that encapsules this scriptlet, The name we
				// construct is "itemName_subItemName" or just "itemName"
				// if no subItemName
				{
				register DWORD		len;

				len = lstrlenW(itemName) + 1;
				if (subItemName)
				{
					if (!(objectName = (WCHAR *)ALLOCMEM(sizeof(WCHAR) * (len + lstrlenW(subItemName) + 1)))) goto badmem;
					lstrcpyW(objectName, itemName);
					*(objectName + len - 1) = '_';
					lstrcpyW(objectName + len + 1, subItemName);
				}
				else
				{
					if (!(objectName = (WCHAR *)ALLOCMEM(sizeof(WCHAR) * len))) goto badmem;
					lstrcpyW(objectName, itemName);
				}
				}

				// Search for an existing CEVENTHANDLER for this object. If it 
				// doesn't exist, then create it
				if (!(eventHandler = findEventObject(iactive, interpreter)))
				{
					if (!(eventHandler = allocCEventHandler(interpreter)))
					{
badmem:					hr = E_OUTOFMEMORY;
						goto error;
					}

					// Link it into the list
					eventHandler->Next = iactive->EventHandlerList;
					iactive->EventHandlerList = eventHandler;
				}

				// Make sure the CEVENTHANDLER has been initialized, but don't try to 
				// initialize it more than once
				if (!(eventHandler->Flags & HANDLER_ISINITIALIZED))
				{
					IDispatch	*hostDispatch;

					// Get the host IDispatch from which we get the IConnectionPoint and ITypeInfo
					if ((hr = getNamedItemIDispatch(iactive, itemName, subItemName, &hostDispatch)) ||
						(hr = initCEventHandler(eventHandler, hostDispatch)))
					{
						goto error;
					}
				}

				{
				register DWORD	len;

				// Create a function name for the scriptlet. The name we construct is
				// "objectName_eventName"
				len = lstrlenW(objectName) + lstrlenW(eventName) + 2;
				if (!(functionName = (WCHAR *)ALLOCMEM(sizeof(WCHAR) * len))) goto badmem;
				lstrcpyW(functionName, objectName);
				lstrcatW(functionName, L"_");
				lstrcatW(functionName, eventName);
				}

				{
				register IDispatch	*temp;

				temp = interpreter->ResolveDispatch;
				interpreter->Flags |= FLAG_PARSEASFUNCTION;
				interpreter->ResolveDispatch = (IDispatch *)functionName;

				// Parse the script inside the appropriate interpreter
				hr = createInstructionList(interpreter, scriptCode, startLineNum, context);

				interpreter->ResolveDispatch = temp;
				interpreter->Flags &= ~FLAG_PARSEASFUNCTION;
				}

				// If the engine has been started, then execute any immediate code in the code block
				if (!hr && (iactive->EngineState == SCRIPTSTATE_STARTED || iactive->EngineState == SCRIPTSTATE_CONNECTED))
					hr = evaluateImmediate(interpreter, 0);

				// Return the function name to the caller, if he wants it
				if (funcName) *funcName = SysAllocString(functionName);

				// The host's type library will have an event name like "onclick", but internally,
				// we've got a function name like "itemName_subItemName_eventName".
				// So, we need to substitute our internal name in the respective CEVENT
				aliasEvent(eventHandler, eventName, &functionName);

				// Clean up
error:			if (objectName) FREEMEM(objectName);
				if (functionName) FREEMEM(functionName);
			}

			// If the script engine was connected to events before this call, then
			// reconnect it to those events
			if (fWasConnected)
			{
				enableCallbacks(iactive);
				iactive->EngineState = SCRIPTSTATE_CONNECTED;
			}
		}
	}

//badout:
	LOGHEXPARAM("Returns", hr);
	UNLOGFUNC();
	return(hr);
}

























// ===========================================================================
// The IActiveScriptParseProcedure sub-object allows an Active Script Host to
// use IDispatch-style function pointers to fire methods, instead of using the
// more difficult method of Connection Points.
// ===========================================================================

/************************ QueryInterface() *************************
 */

static STDMETHODIMP Proc_QueryInterface(IActiveScriptParseProcedure *this, REFIID riid, void **ppvObj)
{
	LOGFUNC("IActiveScriptParseProcedure::QueryInterface");
	return(queryActiveScriptInterface((ACTIVESCRIPT *)((unsigned char *)this - offsetof(ACTIVESCRIPT, ActiveScriptParseProcedure)), riid, ppvObj));
}

/*************************** AddRef() ******************************
 */

static STDMETHODIMP_(ULONG) Proc_AddRef(IActiveScriptParseProcedure *this)
{
	LOGFUNC("IActiveScriptParseProcedure::AddRef");
	return(incActiveScriptRefcount((ACTIVESCRIPT *)((unsigned char *)this - offsetof(ACTIVESCRIPT, ActiveScriptParseProcedure))));
}

/************************** Release() ******************************
 */

static STDMETHODIMP_(ULONG) Proc_Release(IActiveScriptParseProcedure *this)
{
	LOGFUNC("IActiveScriptParseProcedure::Release");
	return(decActiveScriptRefcount((ACTIVESCRIPT *)((unsigned char *)this - offsetof(ACTIVESCRIPT, ActiveScriptParseProcedure))));
}


/************************ ParseProcedureText() ************************
 * Allows the host to use IDispatch-style function pointers to fire
 * script functions instead of using the more difficult method of
 * IConnectionPoint. It parses a scriptlet and wraps it in an anonymous
 * IDispatch interface, which the host can use in lieu of Connection
 * Points to handle events.
 *
 * Essentially, this is the equivalent of combining a call to
 * IActiveScriptParse::ParseScriptText and IActiveScript::GetScriptDispatch,
 * and using the IDispatch->Invoke to call the desired function.
 *
 * scriptCode =		The script code to tokenize and add to the engine.
 * formalParams =	Any formal parameters to the scriptlet. (ignored!!!)
 * procedureName =	Name of the event (ie, function name for the scriptlet).
 * itemName =		Name of the host object that this scriptlet belongs to.
 * punk =			The context object - reserved for the debugger.
 * delimiter =		The delimiter the host uses to mark the start/end
 *					of the scriptlet. (ignored!!!)
 * context =		App-defined value for debugging.
 * startLineNum =	Zero-based number defining where parsing began.
 * flags =			SCRIPTPROC_HOSTMANAGESSOURCE
 *					SCRIPTPROC_IMPLICIT_THIS
 *					SCRIPTPROC_IMPLICIT_PARENTS
 * pObj =			Where we return our IDispatch pointer that the host
 *					uses to call this scriptlet.
 */

static STDMETHODIMP ParseProcedureText(IActiveScriptParseProcedure *this, LPCOLESTR scriptCode, LPCOLESTR formalParams, LPCOLESTR procedureName, 
      LPCOLESTR itemName, IUnknown *punk, LPCOLESTR delimiter, DWORD context, ULONG startLineNum, DWORD flags, IDispatch **pObj)
{
	register HRESULT		hr;
	register ACTIVESCRIPT	*iactive;

	LOGFUNC("IActiveScriptParseProcedure::ParseProcedureText");

	// Get the ACTIVESCRIPT
	iactive = (ACTIVESCRIPT *)((unsigned char *)this - offsetof(ACTIVESCRIPT, ActiveScriptParseProcedure));

	if (/* scriptCode && !IsBadWritePtr(pObj, sizeof(void *)) && */ !IsBadWritePtr(iactive, sizeof(ACTIVESCRIPT)))
	{
		register CINTERPRETER	*interpreter;
		register unsigned char	fWasConnected;

		*pObj = 0;

		if (iactive->HostThreadID != GetCurrentThreadId()) hr = E_UNEXPECTED;
		else
		{
			if (iactive->HostScriptSiteDebug && iactive->HostScriptSiteDebug->lpVtbl == &IActiveScriptSiteDebug_Vtbl)
			{
				addScriptTextToDebugger(iactive, scriptCode, 0);
				context = (DWORD)scriptCode;
			}

			// If the script engine is currently connected to events, temporarily disconnect
			fWasConnected = 0;
			if (iactive->EngineState == SCRIPTSTATE_CONNECTED)
			{
				disableCallbacks(iactive);
				iactive->EngineState = SCRIPTSTATE_DISCONNECTED;
				fWasConnected = 1;
			}

			// NOTE: procedureName may be empty, in which case, we use a default function name
			if (!procedureName || !(*procedureName)) procedureName = &DefaultName[0];

			// Create an unnamed CINTERPRETER to serve as the IDispatch we return to the host
			if ((interpreter = allocInterpreter(0, iactive)))
			{
				// Temporarily store the function name in interpreter->ResolveDispatch for
				// parseFunction() to get to it. Also set the FLAG_PARSEASFUNCTION so
				// createInstructionList() knows to call parseFunction()
				{
				register IDispatch	*temp;

				temp = interpreter->ResolveDispatch;
				interpreter->Flags |= FLAG_PARSEASFUNCTION;
				interpreter->ResolveDispatch = (IDispatch *)procedureName;

				// Parse the script inside the interpreter
				hr = createInstructionList(interpreter, scriptCode, startLineNum, context);

				// Restore state that we altered above
				interpreter->ResolveDispatch = temp;
				interpreter->Flags &= ~FLAG_PARSEASFUNCTION;
				}

				if (!hr)
				{
					DISPID		dispid;

					// In order for this event to be set up as the default property of 
					// the interpreter, we need to reference it once (to create a
					// MEMBERINFO and DISPID for it). This is just a quirk of CINTERPRETER,
					// and not important to scripting
					if (!(hr = Dispatch_GetIDsOfNames(interpreter, &IID_NULL, (OLECHAR **)&procedureName, 1, 0, &dispid)))
					{
						// Return our IDispatch in the host's pointer and AddRef it
						*pObj = (IDispatch *)interpreter;
						Dispatch_AddRef(interpreter);
					}
					else
						freeInterpreter(interpreter);
				}

				goto out;
			}

			hr = E_OUTOFMEMORY;

			// If the engine was connected to events before this call, then
			// reconnect it to those events
out:		if (fWasConnected)
			{
				enableCallbacks(iactive);
				iactive->EngineState = SCRIPTSTATE_CONNECTED;
			}
		}
	}

	// Weren't passed the required args
	else
		hr = E_INVALIDARG;

	LOGHEXPARAM("Returns", hr);
	UNLOGFUNC();
	return(hr);
}
















// ===========================================================================
// The IHostInfoUpdate sub-object is included as a concession to IE4 and 
// 4.01. It allows IE to change the LCID's used for messages and error 
// reporting to the user.
// ===========================================================================

/************************ QueryInterface() *************************
 */

static STDMETHODIMP Host_QueryInterface(IHostInfoUpdate *this, REFIID riid, void **ppvObj)
{
	LOGFUNC("IHostInfoUpdate::QueryInterface");
	return(queryActiveScriptInterface((ACTIVESCRIPT *)((unsigned char *)this - offsetof(ACTIVESCRIPT, HostInfoUpdate)), riid, ppvObj));
}

/*************************** AddRef() ******************************
 */

static STDMETHODIMP_(ULONG) Host_AddRef(IHostInfoUpdate *this)
{
	LOGFUNC("IHostInfoUpdate::AddRef");
	return(incActiveScriptRefcount((ACTIVESCRIPT *)((unsigned char *)this - offsetof(ACTIVESCRIPT, HostInfoUpdate))));
}

/************************** Release() ******************************
 */

static STDMETHODIMP_(ULONG) Host_Release(IHostInfoUpdate *this)
{
	LOGFUNC("IHostInfoUpdate::Release");
	return(decActiveScriptRefcount((ACTIVESCRIPT *)((unsigned char *)this - offsetof(ACTIVESCRIPT, HostInfoUpdate))));
}

/************************** UpdateInfo() ************************
 * Called by a host to request that the engine use the LCID
 * specified by the host's IHostInfoProvider.
 *
 * hostinfoNew =	hostinfoLocale
 *					hostinfoCodePage
 *					hostinfoErrorLocale
 */

static STDMETHODIMP UpdateInfo(IHostInfoUpdate *this, DWORD hostinfoNew)
{
	register HRESULT		hr;
	register ACTIVESCRIPT	*iactive;

	LOGFUNC("IHostInfoUpdate::UpdateInfo");

	// Get the ACTIVESCRIPT
	iactive = (ACTIVESCRIPT *)((unsigned char *)this - offsetof(ACTIVESCRIPT, HostInfoUpdate));

	if (!IsBadWritePtr(iactive, sizeof(ACTIVESCRIPT)))
	{
		// Make sure we have an IActiveScriptSite pointer
		if (!iactive->HostScriptSite)
			hr = E_UNEXPECTED;
		else
		{
			IHostInfoProvider	*pHostInfoProvider;
			void				*pvInfo;

			// Get the host's IHostInfoProvider
			if (!(hr = iactive->HostScriptSite->lpVtbl->QueryInterface(iactive->HostScriptSite, &IID_IHostInfoProvider, &pHostInfoProvider)))
			{
				// Ask the host for its information
				hr = pHostInfoProvider->lpVtbl->GetHostInfo(pHostInfoProvider, hostinfoNew, &pvInfo);

				// Release the pHostInfoProvider
				pHostInfoProvider->lpVtbl->Release(pHostInfoProvider);

				// If we got the information we needed, then fill in the right values
				if (!hr)
				{
					LCID	lcid;

					lcid = *((LCID *)pvInfo);       

					// Free up the memory that IHostInfoProvider allocated
					CoTaskMemFree(pvInfo);

					switch (hostinfoNew)
					{
						case hostinfoLocale:
						{
							// Set the LCID for both normal messages and error messages. Since
							// We don't have any normal messages, so just fall through to set
							// the error messages LCID
						}

						case hostinfoErrorLocale:
						{
							// Set the LCID for error msgs
							errorSetLocale(lcid);
							break;
						}

		//				case hostinfoCodePage:
							//We don't understand hostinfoCodePage, so return E_INVALIDARG
						default:
							goto invalid;
					}
				}
			}
		}
	}
	else
invalid:
		hr = E_INVALIDARG;

	UNLOGFUNC();
	return(hr);
}




















// ===========================================================================
// The IObjectSafety sub-object is included so scripts can be run in Internet
// Explorer. In order to maintain the security model of IE, an IActiveScript
// must support this sub-object.
// ===========================================================================

/************************ QueryInterface() *************************
 */

static STDMETHODIMP Safety_QueryInterface(IObjectSafety *this, REFIID riid, void **ppvObj)
{
	LOGFUNC("IObjectSafety::QueryInterface");
	return(queryActiveScriptInterface((ACTIVESCRIPT *)((unsigned char *)this - offsetof(ACTIVESCRIPT, ObjectSafety)), riid, ppvObj));
}

/*************************** AddRef() ******************************
 */

static STDMETHODIMP_(ULONG) Safety_AddRef(IObjectSafety *this)
{
	LOGFUNC("IObjectSafety::AddRef");
	return(incActiveScriptRefcount((ACTIVESCRIPT *)((unsigned char *)this - offsetof(ACTIVESCRIPT, ObjectSafety))));
}

/************************** Release() ******************************
 */

static STDMETHODIMP_(ULONG) Safety_Release(IObjectSafety *this)
{
	LOGFUNC("IObjectSafety::Release");
	return(decActiveScriptRefcount((ACTIVESCRIPT *)((unsigned char *)this - offsetof(ACTIVESCRIPT, ObjectSafety))));
}

/******************** GetInterfaceSafetyOptions() ******************
 * Returns the safety options supported by the script engine. Since
 * some supported options may not be currently enabled, this method
 * also returns the currently enabled options.
 */

static STDMETHODIMP GetInterfaceSafetyOptions(IObjectSafety *this, REFIID riid, DWORD *pdwSupportedOptions, DWORD *pdwEnabledOptions)
{
	LOGFUNC("IObjectSafety::GetInterfaceSafetyOptions");

 	// For now, we only return information about the engine itself, so we can
 	// ignore the riid.

 	// OR in the options that the engine supports and has enabled
 	*pdwSupportedOptions = *pdwEnabledOptions = (INTERFACESAFE_FOR_UNTRUSTED_CALLER | 
		INTERFACESAFE_FOR_UNTRUSTED_DATA | INTERFACE_USES_DISPEX | INTERFACE_USES_SECURITY_MANAGER );

	UNLOGFUNC();
	return S_OK;
}

/******************** SetInterfaceSafetyOptions() *******************
 * Sets the safety options that the host wants enabled on the script
 * engine.  Objects that support IObjectSafety should check the
 * dwOptionSetMask to make sure they support the options requested.
 */

static STDMETHODIMP SetInterfaceSafetyOptions(IObjectSafety *this, REFIID riid, DWORD dwOptionSetMask, DWORD dwEnabledOptions)
{
	register HRESULT	hr;

	LOGFUNC("IObjectSafety::SetInterfaceSafetyOptions");

	hr = S_OK;

	//For now, we only set information about the engine itself, so we can
	//ignore the riid.

	//Check dwOptionSetMask to be sure we support the requested options.
	//This is somewhat redundant since we support all options, but it's good
	//anyway.  The Exclusive OR finds differences between the flags we support 
	//and dwOptionSetMask, and the AND makes sure that we support more flags
	//that dwOptionSetMask, not less.
	if (dwOptionSetMask & (dwOptionSetMask ^ (INTERFACESAFE_FOR_UNTRUSTED_CALLER|INTERFACESAFE_FOR_UNTRUSTED_DATA|INTERFACE_USES_DISPEX|INTERFACE_USES_SECURITY_MANAGER)))

		//Somehow, we got a request for a flag we don't support
		hr = E_FAIL;


	//Here we would set the enabled options, but since our options are 
	//unchangeable, we just return S_OK;
	UNLOGFUNC();
	return(hr);
}
