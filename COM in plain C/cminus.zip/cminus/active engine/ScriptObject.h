#ifndef _SCRIPTOBJECT_H_
#define _SCRIPTOBJECT_H_

#include <activscp.h>
#include <activdbg.h>
#include "activescript.h"

typedef struct _SCRIPTOBJECT
{
	struct _SCRIPTOBJECT	*Next;			// For linking SCRIPTOBJECTs into a list.
	DWORD					Flags;			// Flags passed to our IActiveScript's AddNamedItem().
	IDispatch				*HostIDispatch;	// The host's IDispatch * gotten via host IActiveScriptSite's GetItemInfo().
	OLECHAR					ObjName[1];		// The nul-terminated object name. A variably-sized field, so it must be last.
} SCRIPTOBJECT;

SCRIPTOBJECT *	allocScriptObject(LPCOLESTR, DWORD);
SCRIPTOBJECT *	findScriptObject(struct _ACTIVESCRIPT *, LPCOLESTR);
void			freeScriptObject(SCRIPTOBJECT *);
HRESULT			getHostIDispatch(SCRIPTOBJECT *, IDispatch **, IActiveScriptSite *);
void			releaseHostIDispatch(SCRIPTOBJECT *);

#endif