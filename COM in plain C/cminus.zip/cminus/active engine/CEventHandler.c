// Contains functions for our CEVENTHANDLER struct.
//
// A host can add a named item (ie, script object) to our engine by calling
// our IActiveScript's AddNamedItem. If the host specifies this script object
// as ISSOURCE, then it expects us to create a "callback IDispatch" for this script
// object, which the host may use to call some function that is added to this
// script object. (And note that a host adds a function to the object by calling
// ParseScriptText or AddScriptlet). The host will call the script function via
// our callback IDispatch's Invoke().
//
// Our CEVENTHANDLER contains our callback IDispatch. The CEVENTHANDLER also
// obtains and stores the host's IConnectionPoint so that it can give our
// callback IDispatch to the host.
//
// We also create a CINTERPRETER for each script object. This simply wraps
// our interpreter's functions. It also maintains the list of scripts added
// to its script object. Instead of directly interfacing with our interpreter's
// functions, we create an IDispatch for it, and call script functions through
// this IDispatch. This is just a design decision we've made so that all
// interpreter functions are accessible through an IDispatch Invoke().
//
// Our CEVENTHANDLER also stores the IDispatch to the CINTERPRETER.
//
// Finally, the  CEVENTHANDLER also maintains a list which maps between the
// DISPIDs that the host tells our callback IDispatch to use for each script
// function, andthe DISPIDs that our CINTERPRETER's IDispatch uses.
//
// So, a CEVENTHANDLER's purpose is to provide the callback IDispatch for a
// host to call some script function.

#define INC_OLE2
#define CONST_VTABLE
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <tchar.h>
#include <objbase.h>
#include <activscp.h>
#include "../TraceWin.h"
#include "../IClassFactory.h"
#include "CInterpreter.h"
#include "CEventHandler.h"




// Here's our CEVENTHANDLER IDispatch VTable. It never changes so we can declare it
// static. NOTE: You may get compiler warnings that the first arg is different
// than the function declarations. After all, we declare our functions as being
// passed an CEVENTHANDLER, rather than IDispatch, pointer. But since our CEVENTHANDLER
// begins with an embedded IDispatch, it can masquerade as an IDispatch, so this
// is a trivial warning.

static STDMETHODIMP QueryInterface(CEVENTHANDLER *, REFIID, void **);
static STDMETHODIMP_(ULONG) AddRef(CEVENTHANDLER *);
static STDMETHODIMP_(ULONG) Release(CEVENTHANDLER *);
static STDMETHODIMP GetTypeInfoCount(CEVENTHANDLER *, unsigned int *);
static STDMETHODIMP GetTypeInfo(CEVENTHANDLER *, unsigned int, LCID, ITypeInfo **);
static STDMETHODIMP GetIDsOfNames(CEVENTHANDLER *, REFIID, OLECHAR **, unsigned int, LCID, DISPID *);
static STDMETHODIMP Invoke(CEVENTHANDLER *, DISPID, REFIID, LCID, unsigned short, DISPPARAMS *, VARIANT *, EXCEPINFO *, unsigned int *);

static const IDispatchVtbl IDispatch_Vtbl = {QueryInterface,
AddRef,
Release,
GetTypeInfoCount,
GetTypeInfo,
GetIDsOfNames,
Invoke};

#ifdef LOGTRACE
unsigned char LogFlag2 = 0;
#endif





//===================================================================
//======================= Helper functions ==========================
//===================================================================


/********************** allocCEventHandler() *******************
 * Allocates a CEVENTHANDLER.
 *
 * objectName =	The object name the host gives (via AddNamedItem).
 *
 * RETURNS: Pointer to the CEVENTHANDLER, or 0 if memory failure.
 */

CEVENTHANDLER * allocCEventHandler(CINTERPRETER *interpreter)
{
	register CEVENTHANDLER	*handler;

	LOGFUNC("allocCEventHandler");

	if ((handler = (CEVENTHANDLER *)ALLOCMEM(sizeof(CEVENTHANDLER))))
	{
		ZeroMemory(handler, sizeof(CEVENTHANDLER));
		handler->RefCount = 1;
		handler->lpVtbl = (void *)&IDispatch_Vtbl;
		handler->EngineIDispatch = interpreter;

		// One more outstanding object
		incActiveScriptRefcount(interpreter->Parent);
	}

	UNLOGFUNC();

	return(handler);
}




void releaseCEventHandler(CEVENTHANDLER *handler)
{
	LOGFUNC("releaseCEventHandler");
	Release(handler);
	UNLOGFUNC();
}




/************************ aliasEvent() ***********************
 * Maps a script function name (given by the host) to a different
 * name in our CINTERPRETER. We do this simply by associating
 * the host's DISPID for this function to the script function
 * DISPID in our CINTERPRETER.
 *
 * hostName =	The function name used by the host.
 * engineName =	The function name used by our interpreter.
 */

void aliasEvent(CEVENTHANDLER *handler, LPCOLESTR hostName, LPCOLESTR *engineName)
{
	register CEVENT		*ptr;
	register DWORD		i;
	register LPCOLESTR	name;

	ptr = handler->Events;
	i = handler->NumEvents;
	name = *engineName;

	while (i--)
	{
		// Find the CEVENT with the matching function name
		if (!ptr->Found && !lstrcmpW((WCHAR *)ptr->Ptr, hostName))
		{
			// Replace the host function name with the name our CINTERPRETER will use
			FREEMEM(ptr->Ptr);
			ptr->Ptr = (void *)name;

			// Clear the ptr so caller doesn't free it
			*engineName = 0;

			break;
		}

		++ptr;
	}
}





/******************** connectCallbacks() ********************
 * If this handler has not already connected, finds the
 * IConnectionPoint for the interface this handler sinks,
 * and calls IConnectionPoint::Advise() on it.
 */

HRESULT connectCallbacks(CEVENTHANDLER *handler)
{
	register HRESULT		hr;

	LOGFUNC("connectCallbacks");

	hr = E_FAIL;

	// Make sure we have a host IDispatch
	if (handler->HostIDispatch)
	{
		// Give our callback IDispatch to the host
//		if (!handler->ConnectionPoint)
		{
			IConnectionPointContainer	*container;

			// Get the host's IConnectionPointContainer
			if (!(hr = handler->HostIDispatch->lpVtbl->QueryInterface(handler->HostIDispatch, &IID_IConnectionPointContainer, (void **)&container)))
			{
				// Get the IConnectionPoint for this CEVENTHANDLER's script object
				if (!(hr = container->lpVtbl->FindConnectionPoint(container, &handler->Guid, &handler->ConnectionPoint)))
				{
					// Call IConnectionPoint's Advise to give it our callback IDispatch
					if (!(hr = handler->ConnectionPoint->lpVtbl->Advise(handler->ConnectionPoint, (IUnknown *)&handler->lpVtbl, &handler->Cookie)))
					{
						// Indicate we're connected
						handler->Flags |= (HANDLER_ISCONNECTED|HANDLER_PSEUDOCONNECT);
					}
					else
					{
						handler->ConnectionPoint->lpVtbl->Release(handler->ConnectionPoint);
						handler->ConnectionPoint = 0;
					}
				}

				// We no longer need the IConnectionPointContainer. But note that we hold
				// onto the IConnectionPoint so that we can later call its Unadvise()
				container->lpVtbl->Release(container);
			}
		}
	}

	LOGHEXPARAM("Returns", hr);
	UNLOGFUNC();

	return(hr);
}





/*********************** pseudoDisconnect() *************************
 * There may be times when we wish to not allow the host to call some
 * script function, but we don't actually want the host to Release
 * our IDispatch, nor do we want to give back its IConnectionPoint.
 * This clears the HANDLER_PSEUDOCONNECT flag so our callback IDispatch's
 * Invoke() ignores the host's attempt to call some script function.
 */

void pseudoDisconnect(CEVENTHANDLER *handler)
{
	LOGFUNC("pseudoDisconnect");

	handler->Flags &= ~HANDLER_PSEUDOCONNECT;

	UNLOGFUNC();
}





/************************** pseudoConnect() ************************
 * If we pseudoDisconnect, we'll need a way to resume responding to
 * the host without calling its IConnectionPoint Advise again. This
 * sets the m_isConnected flag so our callback IDispatch's
 * Invoke() resumes allowing the host to call some script function.
 */

void pseudoConnect(CEVENTHANDLER *handler)
{
	LOGFUNC("psuedoConnect");

	handler->Flags |= HANDLER_PSEUDOCONNECT;

	UNLOGFUNC();
}





/********************** disconnectCallbacks() **********************
 * If we've given the host our callback IDispatch, tells the
 * host to stop using it and Release() it.
 */

HRESULT disconnectCallbacks(CEVENTHANDLER *handler)
{
	HRESULT		hr;

	LOGFUNC("disconnectCallbacks");

	hr = S_OK;

	// Did we give our callback IDispatch to the host?
	if (handler->ConnectionPoint && (handler->Flags & HANDLER_ISCONNECTED))
	{
		// Indicate we're no longer connected
		handler->Flags &= ~(HANDLER_ISCONNECTED|HANDLER_PSEUDOCONNECT);

		// Tell the host to stop using our IDispatch, and Release() it
		hr = handler->ConnectionPoint->lpVtbl->Unadvise(handler->ConnectionPoint, handler->Cookie);
      
		// Give the host back its IConnectionPoint
		handler->ConnectionPoint->lpVtbl->Release(handler->ConnectionPoint);

		// Indicate we no longer have the IConnectionPoint
		handler->ConnectionPoint = 0;
	}

	LOGHEXPARAM("Returns", hr);
	UNLOGFUNC();

	return(hr);
}





/*********************** getSourceTypeInfo() **********************
 * Retrieves the ITypeInfo for [source, default] VTable associated
 * with the host's IDispatch.
 *
 * If the VTable is not found, *srcITypeInfo = 0.
 */

static HRESULT getSourceTypeInfo(IDispatch *hostIDispatch, ITypeInfo **srcITypeInfo)
{
	register HRESULT	hr;
	IProvideClassInfo	*pClassInfo;
	TYPEATTR			*typeAttr;
	ITypeInfo			*classTypeInfo;

	*srcITypeInfo = 0;

	// Get the host's IProvideClassInfo object from its IDispatch
	if (!(hr = hostIDispatch->lpVtbl->QueryInterface(hostIDispatch, &IID_IProvideClassInfo, (void **)&pClassInfo)))
	{
		// Get the coClass object's ITypeInfo from the IProvideClassInfo
		hr = pClassInfo->lpVtbl->GetClassInfo(pClassInfo, &classTypeInfo);
		pClassInfo->lpVtbl->Release(pClassInfo);
		if (!hr)
		{
			// Make sure we got a coClass ITypeInfo
			if ((hr = classTypeInfo->lpVtbl->GetTypeAttr(classTypeInfo, &typeAttr)) || typeAttr->typekind != TKIND_COCLASS)
			{
				if (!hr)
				{
					classTypeInfo->lpVtbl->ReleaseTypeAttr(classTypeInfo, typeAttr);
					hr = E_FAIL;
				}
			}
			else
			{
				register UINT		numVTables, vTableNum;

				// Get how many VTables are in this coClass object
				numVTables = typeAttr->cImplTypes;

				// We no longer need the TYPEATTR now that we have numVTables
				classTypeInfo->lpVtbl->ReleaseTypeAttr(classTypeInfo, typeAttr);

				// Search through the VTables in this coClass object, and find the one marked
				// [default, source] (which is not restricted)
				for (vTableNum = 0; vTableNum < numVTables; vTableNum++)
				{
					INT		flags;

					if (!(hr = classTypeInfo->lpVtbl->GetImplTypeFlags(classTypeInfo, vTableNum, &flags)) &&
						(flags & (IMPLTYPEFLAG_FDEFAULT|IMPLTYPEFLAG_FSOURCE|IMPLTYPEFLAG_FRESTRICTED)) == (IMPLTYPEFLAG_FDEFAULT|IMPLTYPEFLAG_FSOURCE))
					{
						HREFTYPE refType;

						// This is the VTable we want, so get/return its ITypeInfo
						if (!(hr = classTypeInfo->lpVtbl->GetRefTypeOfImplType(classTypeInfo, vTableNum, &refType)))
							hr = classTypeInfo->lpVtbl->GetRefTypeInfo(classTypeInfo, refType, srcITypeInfo);

						break;
					}
				}
			}
		}
	}

	return(hr);
}





/************************ initCEventHandler() **********************
 * Initializes a newly allocated CEVENTHANDLER. Takes IDispatch *'s
 * for the source (host IDispatch) and sink (our CINTERPRETER
 * IDispatch) and uses them to construct the array of CEVENTS which
 * maps between the DISPIDs of the outgoing interface and the DISPIDs
 * of the sinking interface.
 */

HRESULT initCEventHandler(CEVENTHANDLER *handler, IDispatch *hostIDispatch)
{
	register HRESULT		hr;

	LOGFUNC("initCEventHandler");

	hr = S_OK;

	// If we've already setup this CEVENTHANDLER's CEVENTs, then don't do it again
	if (!(handler->Flags & HANDLER_ISINITIALIZED))
	{
		ITypeInfo	*srcITypeInfo;

		// Find the ITypeInfo for the [default, source] VTable of the host coClass
		// object (to which its IDispatch belongs)
		if (!(hr = getSourceTypeInfo(hostIDispatch, &srcITypeInfo)))
		{
			UINT		numEvents;
			TYPEATTR	*typeAttr;

			// Get the TYPEATTR
			srcITypeInfo->lpVtbl->GetTypeAttr(srcITypeInfo, &typeAttr);

			// Make sure the host's ITypeInfo defines some script functions for our
			// callback IDispatch
			if (!(numEvents = typeAttr->cFuncs))
				hr = E_NOINTERFACE;
			else
			{
				// Alloc one big array of CEVENTs for all the callback funcs
				if ((handler->Events = ALLOCMEM(sizeof(CEVENT) * numEvents)))
				{
					// Store the GUID of the [source, default] VTable. We'll use it
					// later with the host's IConnectionPoint Advise()
					CopyMemory(&handler->Guid, &typeAttr->guid, sizeof(GUID));

					// Get the name and DISPID of each CEVENT's function
					while (numEvents--)
					{
						FUNCDESC	*pfdesc;
						UINT		count;
						BSTR		name;

						handler->Events[handler->NumEvents].Found = 0;

						// Get the function description
						if ((hr = srcITypeInfo->lpVtbl->GetFuncDesc(srcITypeInfo, handler->NumEvents, &pfdesc)) ||

							// Get the function name
							(hr = srcITypeInfo->lpVtbl->GetNames(srcITypeInfo, pfdesc->memid, &name, 1, &count)))
						{
							srcITypeInfo->lpVtbl->ReleaseFuncDesc(srcITypeInfo, pfdesc);
							goto bad;
						}

						// Save the DISPID that the host assigned to this function
						handler->Events[handler->NumEvents].HostDispid = pfdesc->memid;

						// Release the function description
						srcITypeInfo->lpVtbl->ReleaseFuncDesc(srcITypeInfo, pfdesc);

						// Save a copy of its name, and free the BSTR
						count = SysStringByteLen(name) + sizeof(OLECHAR);
						if (!(handler->Events[handler->NumEvents].Ptr = ALLOCMEM(count)))
						{
							SysFreeString(name);
							hr = E_OUTOFMEMORY;
bad:						while (handler->NumEvents)
							{
								--handler->NumEvents;
								FREEMEM((void *)handler->Events[handler->NumEvents].Ptr);	
							}
							FREEMEM(handler->Events);
							goto out;
						}
						lstrcpyW(handler->Events[handler->NumEvents].Ptr, name);
						SysFreeString(name);

						// Increment count of functions
						++handler->NumEvents;
					}

					// This CEVENTHANDLER is now initialized
					handler->Flags |= HANDLER_ISINITIALIZED;

					// Store the host's IDispatch from which we'll get its IConnectionPoint
					handler->HostIDispatch = hostIDispatch;
				}
				else
					hr = E_OUTOFMEMORY;
			}

out:		srcITypeInfo->lpVtbl->ReleaseTypeAttr(srcITypeInfo, typeAttr);
			srcITypeInfo->lpVtbl->Release(srcITypeInfo);
		}
		else 
			hr = E_FAIL;
	}
	else
		hr = E_FAIL;

	// If an error, free the host IDispatch
	if (hr) hostIDispatch->lpVtbl->Release(hostIDispatch);

	LOGHEXPARAM("Returns", hr);
	UNLOGFUNC();

	return(hr);
}





/********************* findEventObject() *********************
 * Finds the CEVENTHANDLER for the specified CINTERPRETER.
 */

CEVENTHANDLER * findEventObject(ACTIVESCRIPT *iactive, CINTERPRETER *interpreter)
{
	register CEVENTHANDLER	*handler;

	handler = iactive->EventHandlerList;
	while (handler)
	{
		if (handler->EngineIDispatch == interpreter) break;
		handler = handler->Next;
	}

	return(handler);
}






















//===================================================================
//======== CEVENTHANDLER's callback IDispatch functions =============
//===================================================================

/******************* IUnknown->QueryInterface() *******************
 */

static STDMETHODIMP QueryInterface(CEVENTHANDLER *this, REFIID riid, void **ppvObj)
{
	LOGFUNC("CEVENTHANDLER::QueryInterface");

	if (!IsBadWritePtr(ppvObj, sizeof(void *)))
	{
		if (IsEqualIID(riid, &IID_IUnknown) || IsEqualIID(riid, &IID_IDispatch) || IsEqualIID(riid, &this->Guid))
		{
			*ppvObj = this;
#ifdef LOGTRACE
			LogFlag2 = 1;
#endif
			AddRef(this);
			return(NOERROR);
		}
		*ppvObj = 0;
		LOGGUID("UNSUPPORTED: ", riid);
		UNLOGFUNC();
		return(E_NOINTERFACE);
	}

	UNLOGFUNC();
	return(E_POINTER);
}

/*********************** IUnknown->AddRef() ***********************
 */

static STDMETHODIMP_(ULONG) AddRef(CEVENTHANDLER *this)
{
#ifdef LOGTRACE
	ULONG	val;
#endif

	// One more outstanding object
	incActiveScriptRefcount(this->EngineIDispatch->Parent);

#ifdef LOGTRACE
	if (!LogFlag2) LOGFUNC("CEVENTHANDLER::AddRef");
	val = ++this->RefCount;
	UNLOGFUNC();
	LogFlag2 = 0;
	return(val);
#else
	UNLOGFUNC();
	return(++this->RefCount);
#endif
}

/********************** resetCEventHandler() *******************
 * Resets the CEVENTHANDLER by releasing its host IDispatch,
 * and tossing away the names of callback functions the host
 * defines.
 */

void resetCEventHandler(CEVENTHANDLER *handler)
{
	LOGFUNC("resetCEventHandler");

	// Tell the host to give back our callback IDispatch (and
	// hopefully it will Release() our CEVENTHANDLER). Also,
	// release the host's IConnectionPoint
	disconnectCallbacks(handler);

	// Free all the CEVENTS
	{
	register CEVENT		*ptr;
	register DWORD		i;

	if ((i = handler->NumEvents))
	{
		ptr = handler->Events;
		while (i--)
		{
			if (!ptr->Found) FREEMEM(ptr->Ptr);
			++ptr;
		}
		FREEMEM(handler->Events);
		handler->NumEvents = 0;
	}
	}

	UNLOGFUNC();
}

/*********************** IUnknown->Release() **********************
 */

static STDMETHODIMP_(ULONG) Release(CEVENTHANDLER *this)
{
	LOGFUNC("CEVENTHANDLER::Release");

	if (!IsBadWritePtr(this, sizeof(CEVENTHANDLER)))
	{
		if ((--this->RefCount))
		{
			UNLOGFUNC();
			return(this->RefCount);
		}

		resetCEventHandler(this);

		// One less outstanding object
		decActiveScriptRefcount(this->EngineIDispatch->Parent);

		FREEMEM(this);
	}

	UNLOGFUNC();
	return(0);
}

/***************** IDispatch->GetTypeInfoCount() ******************
 */

static STDMETHODIMP GetTypeInfoCount(CEVENTHANDLER *this, unsigned int *pctinfo)
{
	LOGFUNC("CEVENTHANDLER::GetTypeInfoCount");
	UNLOGFUNC();

	// Our CEVENTHANDLER object has no need for any ITypeInfo. Tell the caller we
	// don't have one
	*pctinfo = 0;

	return(NOERROR);
}

/******************* IDispatch->GetTypeInfo() ********************
 */

static STDMETHODIMP GetTypeInfo(CEVENTHANDLER *this, unsigned int itinfo, LCID lcid, ITypeInfo **pptinfo)
{
	// Because our CEVENTHANDLER has no extra functions in it (ie, it has
	// only the IUnknown and IDispatch functions), it would be senseless
	// for anyone to call our GetTypeInfo. After all, this is to get
	// an ITypeInfo for the purpose of obtaining information about
	// CEVENTHANDLER's extra function. And since we have no extra functions,
	// we have no need for a ITypeInfo. So we simply return E_NOTIMPL to
	// tell the dummy calling us that we're a freaking event sink
	// (ie, plain IDispatch) without any extra functions nor ITypeInfo
	LOGFUNC("CEVENTHANDLER::GetTypeInfo");
	UNLOGFUNC();
	*pptinfo = 0;
	return(DISP_E_BADINDEX);
}

/***************** IDispatch->GetIDsOfNames() *******************
 */

static STDMETHODIMP GetIDsOfNames(CEVENTHANDLER *this, REFIID riid, OLECHAR **rgszNames, unsigned int cNames, LCID lcid, DISPID *rgdispid)
{
	// Because our CEVENTHANDLER has no extra functions in it, see above note
	LOGFUNC("CEVENTHANDLER::GetIDsOfNames");
	UNLOGFUNC();
	return(E_NOTIMPL);
}


/*********************** IDispatch->Invoke() ***********************
 * Called by the host to run some callback function in the script
 * (ie, a function that the host previously added with our
 * IActiveScript's AddNamedItem and IActiveScriptParse's AddScriptlet).
 *
 * We need to take the DISPID passed by the host, and look up the
 * object/function associated with that DISPID.
 */

static STDMETHODIMP Invoke(CEVENTHANDLER *this, DISPID dispId, REFIID riid, LCID lcid, unsigned short flags, DISPPARAMS *args, VARIANT *result, EXCEPINFO *pei, unsigned int *puArgErr)
{
	register HRESULT	hr;

	LOGFUNC("CEVENTHANDLER::Invoke");

	// Clear out the host's result
	if (result) VariantInit(result);

	// Clear out the host's EXCEPINFO struct
	if (pei) ZeroMemory(pei, sizeof(EXCEPINFO));

	if (!IsEqualIID(riid, &IID_NULL)) hr = E_INVALIDARG;

	// If we are pseudo-disconnected, ignore the call and return S_OK
//	else if (!(this->Flags & HANDLER_PSEUDOCONNECT)) hr = S_OK;

	// If a pending halt, skip the call
//	else if (this->script->Flags & ACTIVESCRIPTFLAG_HALTRAISED) goto interrupt;

	// Find the EVENT struct with this matching DISPID
	else
	{
		register DWORD		i;
		register CEVENT		*ptr;

		hr = DISP_E_MEMBERNOTFOUND;

		ptr = this->Events;
		i = this->NumEvents;

		// Go through the CEVENT array and locate the one with the matching host DISPID
		while (i--)
		{
			if (ptr->HostDispid == dispId)
			{
				// If we found one, check to see if the host actually added some script function
				// for this DISPID. If so, then call the CINTERPRETER IDispatch's Invoke with
				// the matching CINTERPRETER DISPID
				if (!ptr->Found)
				{
					DISPID		id;

					// Get the DISPID that our CINTERPRETER has assigned to this script function
					if ((hr = Dispatch_GetIDsOfNames(this->EngineIDispatch, &IID_NULL, (unsigned short **)&ptr->Ptr, 1, 0, &id))) goto out;

					// Indicate this script function has been found
					ptr->Found = 1;

					// We can free the name now
					FREEMEM(ptr->Ptr);

					// Save the DISPID
					ptr->Ptr = (void *)id;
				}


				LOGINTPARAM("Executing event handler", dispId);
				hr = Dispatch_Invoke(this->EngineIDispatch, (DISPID)ptr->Ptr, riid, lcid, flags, args, result, pei, puArgErr);
				break;
			}

			++ptr;
		}
	}
out:
	LOGINTPARAM("Returns", hr);
	UNLOGFUNC();
    return(hr);
}
