#ifndef _CINTERPRETER_H_
#define _CINTERPRETER_H_

#include "ActiveScript.h"
#include "../Interpreter/CParser.h"
#include "../Interpreter/SymbolTable.h"
#include "../Interpreter/CInstruction.h"

// MEMBERINFO->Flags
#define MEMBER_IS_DEFAULT	0x01
#define MEMBER_IS_METHOD	0x02

// Maps a DISPID to an function/variable name for CINTERPRETER IDispatch's Invoke()
#pragma pack(1)
typedef struct _MEMBERINFO
{
	struct _MEMBERINFO	*Next;
//	DISPID				DispId;
	void				*Ptr;
	unsigned char		Flags;
} MEMBERINFO;
#pragma pack()

//==============================================

// CINTERPRETER->Flags
#define FLAG_DO_IMMEDIATE		0x01	// Set to 1 when the evaluating immediate instructions
#define FLAG_MAINCOMPLETED		0x02 	// Set to 1 when the script's main() function is run
#define FLAG_EXPRESSIONENGINE	0x04	// Set to 1 if the interpreter is being used to evaluate expressions from the host
#define FLAG_DEBUGINSTRUCTIONS	0x08	// Set to 1 if the interpreter needs DEBUGINSTRUCTIONs instead of CINSTRUCTIONs
#define FLAG_PARSEASFUNCTION	0x10	// Set to 1 if parsing script source text as if it was embodied in a function

// Handles a collection of scripts/variables that belong to a single
// script object
#pragma pack(1)
typedef struct _CINTERPRETER {
	const void *		lpVtbl;				// The IDispatch VTable through which the host calls this interpreter's C script functions. Must be first.
	struct _CINTERPRETER	*Next;			// For a linked list of CASINTEPRETERs
	MEMBERINFO			*MemberInfoList;	// List of DISPIDs that have been assigned to particular functions/variables in this interpreter.
	struct _ACTIVESCRIPT *Parent;			// Pointer to the ACTIVESCRIPT to which this interpreter belongs.
	TSTACK				*SymbolTable;		// Stack of CSYMBOLTABLEs.
	CINSTRUCTION		*InstructionList;	// List of CINSTRUCTIONs.
	CINSTRUCTION		*CurrentInstruction; // Currently executing CINSTRUCTION.
	SCRIPTVARIANT		*DataStack;			// List of SCRIPTVARIANTs
	IDispatch			*ResolveDispatch;	// IDispatch being used to resolve some script call to a function
											// external to this CINTERPRETER's functions. This includes
											// setting/querying variables not in this CINTERPRETER
	DWORD				LabelCount;			// Count of internal numeric labels
	unsigned char		Flags;
	unsigned char		Pad;				// Not used.
	WCHAR				Name[1];			// Item (object) name for this interpreter. This is variably-sized, so it must be last.
} CINTERPRETER;
#pragma pack()

//==============================================

extern const WCHAR		GlobalTableName[];

extern HRESULT			evaluateImmediate(CINTERPRETER *, VARIANT *);
extern HRESULT			evaluateCall(CINTERPRETER *);
extern CINTERPRETER *	allocInterpreter(const WCHAR *, struct _ACTIVESCRIPT *);
extern void				freeInterpreter(CINTERPRETER *);
extern CINTERPRETER *	findInterpreter(struct _ACTIVESCRIPT *, const WCHAR *);
extern void				resetInterpreter(CINTERPRETER *);
extern HRESULT			parseText(CINTERPRETER *, LPCOLESTR, ULONG, DWORD);
extern HRESULT			createInstructionList(CINTERPRETER *, LPCOLESTR, ULONG, DWORD);
extern void				free_block(void *);
extern CINSTRUCTION *	gotoLastInstruction(CINSTRUCTION *);

extern STDMETHODIMP			Dispatch_QueryInterface(CINTERPRETER *, REFIID, void **);
extern STDMETHODIMP_(ULONG) Dispatch_AddRef(CINTERPRETER *);
extern STDMETHODIMP_(ULONG) Dispatch_Release(CINTERPRETER *);
extern STDMETHODIMP			Dispatch_GetIDsOfNames(CINTERPRETER *, REFIID, OLECHAR **, UINT, LCID, DISPID *);
extern STDMETHODIMP			Dispatch_Invoke(CINTERPRETER *, DISPID, REFIID, LCID, WORD, DISPPARAMS *, VARIANT *, EXCEPINFO *, UINT *);

#endif // _CINTERPRETER_H_