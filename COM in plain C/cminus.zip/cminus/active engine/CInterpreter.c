/*
 * Contains the routines for our CINTERPRETER. We create a CINTERPRETER for
 * every "host object" (ie, an object created by the host calling our IActiveScript's
 * AddNamedItem) that the host has specified script code will be added to. We also
 * create a CINTERPRETER for our "global object" (ie, to which script code is
 * added when the host doesn't specify another, particular host object).
 *
 * These routines run the CINSTRUCTIONs that we created by the CPARSER (when the
 * host called our IActiveScriptParse's ParseScriptText or AddScriptlet, or
 * IActiveScriptParseProcedure's ParseProcedureText, to add some script code to
 * the object).
 *
 * Our CINTERPRETER also wraps an IDispatch interface which the host can obtain
 * (by calling our IActiveScript's GetScriptDispatch). The host can use this
 * IDispatch's Invoke() to call script functions in this CINTERPRETER, or
 * query/set its script variables.
 */

#define INC_OLE2
#define CONST_VTABLE
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <stddef.h>
#include <objbase.h>
#include <activscp.h>
#include <activdbg.h>
#include "../TraceWin.h"
#include "../IClassFactory.h"
#include "../Guids.h"
#include "../English/Resource.h"
#include "../Interpreter/ScriptVariant.h"
#include "../Interpreter/SymbolTable.h"
#include "../Interpreter/CParser.h"
#include "../Interpreter/BuiltIns.h"
#include "../Active Debugging/StackFrameDesc.h"
#include "../Active Engine/ActiveScript.h"
#include "ErrorHandler.h"
#include "CInterpreter.h"

static HRESULT			callInvoke(CINTERPRETER *, IDispatch *, DISPID, VARIANT *, WORD);
static HRESULT			evalInstruction(CINTERPRETER *);
static CINSTRUCTION *	findLabel(CINTERPRETER *, const WCHAR *);
static CINSTRUCTION *	findNumericLabel(CINTERPRETER *, DWORD);
static CINSTRUCTION *	findFunction(CINTERPRETER *, const WCHAR *);
static void				report_error(CINSTRUCTION *, HRESULT, CINTERPRETER *);

// IDispatch VTable
STDMETHODIMP Dispatch_QueryInterface(CINTERPRETER *, REFIID, void**);
STDMETHODIMP_(ULONG) Dispatch_AddRef(CINTERPRETER *);
STDMETHODIMP_(ULONG) Dispatch_Release(CINTERPRETER *);
static STDMETHODIMP GetTypeInfoCount(CINTERPRETER *, UINT *);
static STDMETHODIMP GetTypeInfo(CINTERPRETER *, UINT, LCID, ITypeInfo **);
STDMETHODIMP Dispatch_GetIDsOfNames(CINTERPRETER *, REFIID, OLECHAR **, UINT, LCID, DISPID *);
STDMETHODIMP Dispatch_Invoke(CINTERPRETER *, DISPID, REFIID, LCID, WORD, DISPPARAMS *, VARIANT *, EXCEPINFO *, UINT *);

static const struct IDispatchVtbl IDispatch_Vtbl = {Dispatch_QueryInterface,
Dispatch_AddRef,
Dispatch_Release,
GetTypeInfoCount,
GetTypeInfo,
Dispatch_GetIDsOfNames,
Dispatch_Invoke};

// A running count of DISPIDs, to create unique ids
//static DWORD			CurrentDispid = 0;

static UnaryOperatorPtr * UnaryOperators[] = {IncOperator, DecOperator, NotOperator, BitNotOperator, NegateOperator};
static BinaryOperatorPtr * BinaryOperators[] = {GreaterEqualComparison,
GreaterThanComparison,
LessEqualComparison,
LessThanComparison,
LeftShiftOperation,
RightShiftOperation,
BitAndOperation,
BitOrOperation,
BitXorOperation,
EqualComparison,
NotEqualComparison,
OrTest,
AndTest,
MultOperation,
DivOperation,
ModOperation,
AddOperation,
SubOperation};

// The name of the C language entry function
static const WCHAR	MainFuncName[] = L"main";

static const WCHAR	GlobalDescName[] = L"Global Code";

// Name for the global CSYMBOLTABLE
const WCHAR	GlobalTableName[] = L"Global";






//==============================================================================
// Here are our IDispatch functions for our CINTERPRETER. These routines
// allow the host to call script functions in this CINTERPRETER, or set/query
// script variables.
//==============================================================================

/********************** QueryInterface() *********************
 */

STDMETHODIMP Dispatch_QueryInterface(CINTERPRETER *this, REFIID riid, void **ppvObj)
{
	LOGFUNC("IDispatch::QueryInterface");

	if (!IsBadWritePtr(this, sizeof(CINTERPRETER)))
	{
		if (IsEqualIID(riid, &IID_IDispatch))
		{
			*ppvObj = this;
			Dispatch_AddRef(this);
			return(S_OK);
		}

		return(queryActiveScriptInterface(this->Parent, riid, ppvObj));
	}

	UNLOGFUNC();
	return(E_FAIL);
}

/************************** AddRef() *************************
 */

STDMETHODIMP_(ULONG) Dispatch_AddRef(CINTERPRETER *this)
{
	LOGFUNC("IDispatch::AddRef");

	// Increment RefCount of ACTIVESCRIPT
	return(incActiveScriptRefcount(this->Parent));
}

/************************** Release() ************************
 */

STDMETHODIMP_(ULONG) Dispatch_Release(CINTERPRETER *this)
{
	LOGFUNC("IDispatch::Release");

	if (!IsBadWritePtr(this, sizeof(CINTERPRETER)))
	{
		// Decrement RefCount of ACTIVESCRIPT
		return(decActiveScriptRefcount(this->Parent));
	}

	UNLOGFUNC();
	return(0);
}

/********************* GetTypeInfoCount() *********************
 */

static STDMETHODIMP GetTypeInfoCount(CINTERPRETER *this, UINT *iTInfo)
{
	LOGFUNC("IDispatch::GetTypeInfoCount");
	UNLOGFUNC();
   
	// We don't support type information
	*iTInfo = 0;
	return(S_OK);
}

/********************** GetTypeInfo() **************************
 */

static STDMETHODIMP GetTypeInfo(CINTERPRETER *this, UINT iTInfo, LCID lcid, ITypeInfo **ppTInfo)
{
	LOGFUNC("IDispatch::GetTypeInfo");
	UNLOGFUNC();
   
	// We don't support type information
	*ppTInfo = 0;
	return(DISP_E_BADINDEX);
}





/********************* allocMemberInfo() ***********************
 * Helper functions to allocates/initialize a new MEMBERINFO.
 *
 * RETURNS: MEMBERINFO *, or 0 if memory fail.
 */

static MEMBERINFO * allocMemberInfo(void)
{
	register MEMBERINFO	*member;

	LOGFUNC("allocMemberInfo");

	if ((member = (MEMBERINFO *)ALLOCMEM(sizeof(MEMBERINFO))))
		ZeroMemory(member, sizeof(MEMBERINFO));

	UNLOGFUNC();
	return(member);
}





/********************* GetIDsOfNames() ********************
 * The host calls this to retrieve the DISPIDs of script
 * functions, and script variables. Each function and
 * variable in the script must have a unique DISPID.
 *
 * NOTE: The variable must have been declared in the
 * script (which causes the variable to be created when the
 * scriptis run, or created when the script is parsed if the
 * variable is in the "global code block"), or the
 * function must exist in the script.
 */

STDMETHODIMP Dispatch_GetIDsOfNames(CINTERPRETER *this, REFIID riid, OLECHAR **nameArray, UINT nameCount, LCID lcid, DISPID *retDispIds)
{
	HRESULT		hr;

	LOGFUNC("IDispatch::GetIDsOfNames");

	if (!IsEqualIID(riid, &IID_NULL) || IsBadWritePtr(this, sizeof(CINTERPRETER))) hr = E_INVALIDARG;
	else
	{
		hr = S_OK;

		// Loop through the array of names passed in
		while (nameCount--)
		{
			register MEMBERINFO	*member;
			register LPCOLESTR	curName;
			void				*item;

			curName = nameArray[nameCount];

			// First look for this name in our MEMBERINFO list. If we created it
			// upon a previous GetIDsOfNames(), then we already have a DISPID for it
			member = this->MemberInfoList;
			while (member)
			{
				if (member->Flags & DISPATCH_METHOD)
					if (!lstrcmpW((WCHAR *)((unsigned char *)member->Ptr + sizeof(CINSTRUCTION)), curName)) break;
				else
					if (!lstrcmpW(((CSYMBOL *)member->Ptr)->Name, curName)) break;
				member = member->Next;
			}

			if (member)
			{
				// Copy the DISPID into the array. NOTE: We use the MEMBERINFO struct address
				// as the DISPID. This works for 32-bit systems
//				retDispIds[nameCount] = member->DispId;
				retDispIds[nameCount] = (long)member;
			}

			// We haven't searched for this name before, so we need to create a
			// new MEMBERINFO struct for it. Start by trying to find the
			// name in our internal symbol table
			else if ((item = searchSymbolTables(this, curName)))
			{
				// Create a new MEMBERINFO
				if (!(member = allocMemberInfo()))
				{
badmem:				hr = E_OUTOFMEMORY;
					break;
				}
				goto ins;
			}

			// This name isn't in our symbol table, so it's not a property
			// (ie, variable). Look in our instruction list and try to find the
			// name as a method (ie, function). This should return the function's
			// OPCODE_FUNCENTRY CINSTRUCTION
			else if ((item = findFunction(this, curName)))
			{
				// Create a new MEMBERINFO
				if (!(member = allocMemberInfo())) goto badmem;

				// Indicate this is a function
				member->Flags = MEMBER_IS_METHOD;

				// Assign a new, unique DISPID
ins:			member->Ptr = item;
//				retDispIds[nameCount] = member->DispId = ++CurrentDispid;
				retDispIds[nameCount] = (long)member;

				// Insert the new MEMBERINFO into the MEMBERINFO list
				member->Next = this->MemberInfoList;
				this->MemberInfoList = member;
			}

			else
			{
				// We couldn't find the name, so we'll return DISP_E_UNKNOWNNAME
				hr = DISP_E_UNKNOWNNAME;
				break;
			}
		}
	}

	LOGHEXPARAM("Returns", hr);
	UNLOGFUNC();
	return(hr);
}





/************************** Invoke() ***********************
 * Takes a DISPID and uses it to call some function, or
 * set/query some variable, defined in the script that is
 * loaded into this CINTERPRETER.
 *
 * dispId =		DISPID number for the desired function/variable.
 * riid =		Must be IID_NULL.
 * lcid =
 *
 * NOTE: The caller must have gotten the DISPID from our
 * GetIDsOfNames() function above.
 */

STDMETHODIMP Dispatch_Invoke(CINTERPRETER *this, DISPID dispId, REFIID riid, LCID lcid, WORD wFlags, DISPPARAMS *pDispParams, VARIANT *result, EXCEPINFO *pei, UINT *puArgErr)
{
	register HRESULT		hr;
	register MEMBERINFO		*member;

	LOGFUNC("IDispatch::Invoke");

	// Initialize the caller's result VARIANT
	if (result)
	{
		if (IsBadWritePtr(result, sizeof(VARIANT)))
		{
			hr = DISP_E_BADVARTYPE;
			goto out;
		}

		VariantInit(result);
	}

	if (IsEqualIID(riid, &IID_NULL) && !IsBadWritePtr(this, sizeof(CINTERPRETER)))
	{
		// Does caller want us to use a default property?
		if (!dispId)
		{
			// Yes. Get the MEMBERINFO of whatever we have decided will be our default property.
			// Let's assume the first member in the list (and since we've linked the list in
			// reverse order, we'll search to the last item)
			member = this->MemberInfoList;
			while (member && member->Next) member = member->Next;
		}

		// No, he passed a particular DISPID. Search our MEMBERINFO list and find the one with the
		// matching DISPID. It had better be in that list. (ie, The caller should have already
		// called our GetIDsOfNames() above to fetch the unique DISPID for the item he desires)
		else
		{
//			member = this->MemberInfoList;
//			while (member)
//			{
//				if (member->DispId == dispId) break;
//				member = member->Next;
//			}

			member = (MEMBERINFO *)dispId;
			if (IsBadWritePtr(member, sizeof(MEMBERINFO))) member = 0;
		}

		// Make sure we found the matching item
		if (member)
		{
			// If caller wants us to call some function, make sure that the MEMBERINFO item we found
			// is for a method
			if (wFlags & DISPATCH_METHOD)
			{
				if (member->Flags & MEMBER_IS_METHOD)
				{
					this->CurrentInstruction = member->Ptr;
					if (!IsBadWritePtr(member->Ptr, sizeof(CINSTRUCTION)))
					{
						SCRIPTVARIANT		*prevStack;

						// We want to ensure stack integrity around our call to evaluateCall(),
						// so get the current SCRIPTVARIANT at the top of the list. If evaluateCall()
						// fails and leaves garbage on the stack, we'll be able to clean it up here
						prevStack = this->DataStack;

						// Push copies of any args onto the data stack so evaluateCall() can use
						// them. NOTE: evaluateCall() uses our own format called a SCRIPTVARIANT
						// to wrap a VARIANT
						for (hr = 0; (ULONG)hr < pDispParams->cArgs; hr++)
						{
							register SCRIPTVARIANT	*scriptVar;

							if (!(scriptVar = getScriptVariant(&pDispParams->rgvarg[hr])))
							scriptVar->Next = this->DataStack;
							this->DataStack = scriptVar;
							{
badmem:							hr = E_OUTOFMEMORY;
								goto pop;
							}
						}

						// Push the arg count onto the stack, so our interpreter
						// can confirm the number is correct
						{
						register SCRIPTVARIANT	*scriptVar;

						if (!(scriptVar = getScriptVariant(0))) goto badmem;
						scriptVar->Next = this->DataStack;
						this->DataStack = scriptVar;
						scriptVar->Value->vt = VT_I4;
						scriptVar->Value->lVal = pDispParams->cArgs;
						}

						// Indicate we're executing a script
						lcid = this->Parent->Flags & ~(SCRIPTTHREADSTATE_RUNNING|ACTIVESCRIPTFLAG_HALTRAISED);
						this->Parent->Flags |= SCRIPTTHREADSTATE_RUNNING;

						// Call (ie, run) the script function
						hr = evaluateCall(this);

						// Restore state
						this->Parent->Flags = (this->Parent->Flags & ~(SCRIPTTHREADSTATE_RUNNING|ACTIVESCRIPTFLAG_HALTRAISED)) | (unsigned char)lcid;

						{
						register SCRIPTVARIANT	*scriptVar;

						if (!hr &&

							// Check if caller wants the return value
							result &&

							// Check if there's a return value
							(scriptVar = this->DataStack) != prevStack)
						{
							this->DataStack = scriptVar->Next;

							// If the VARIANT isn't borrowed from someone else, than steal away
							// its value
							if (((unsigned char *)scriptVar + sizeof(SCRIPTVARIANT)) == (unsigned char *)scriptVar->Value)
							{
								CopyMemory(result, scriptVar->Value, sizeof(VARIANT));
								scriptVar->Value->vt = VT_EMPTY;
							}
							else
								hr = VariantCopy(result, scriptVar->Value);
							goto freeit;
						}

						// Now that we're done, ensure stack integrity
pop:					while (prevStack && (scriptVar = this->DataStack) != prevStack)
						{
							this->DataStack = scriptVar->Next;
freeit:						freeScriptVariant(scriptVar);
						}
						}

						goto out;
					}
				}
			}

			// If we're querying/setting some property, make sure the MEMBERINFO item we found was
			// for a property (ie. variable, and not a function)
			else if (!(member->Flags & MEMBER_IS_METHOD))
			{
				register CSYMBOL		*symbol;

				symbol = (CSYMBOL *)member->Ptr;
				if (!IsBadWritePtr(symbol, sizeof(CSYMBOL)))
				{
					// If we're querying some property, make sure the MEMBERINFO item we found was
					// for a property (ie. variable, and not a function) and the caller supplied a
					// result VARIANT
					if (wFlags & DISPATCH_PROPERTYGET)
					{
						// Copy the value from the CSYMBOL to the result VARIANT
						hr = VariantCopy(result, &symbol->SymbolValue);

						goto out;
					}

					// If we're setting some property, make sure the MEMBERINFO item we found was
					// for a property (ie. variable, and not a function) and the caller supplied
					// one argument in pDispParams
					if (wFlags & DISPATCH_PROPERTYPUT)
					{
						if (pDispParams->cArgs == 1)
						{
							// Set the value of this variable within our internal symbol table

							// Clear any previous value
							clearVariant(&symbol->SymbolValue);

							// Copy the passed value to the CSYMBOL
							hr = VariantCopy(&symbol->SymbolValue, &pDispParams->rgvarg[0]);

							goto out;
						}

						// The number of parameters is wrong
						hr = DISP_E_BADPARAMCOUNT;
						goto out;
					}
				}
			}
		}
	}

	hr = E_INVALIDARG;
out:
	LOGHEXPARAM("Returns", hr);
	UNLOGFUNC();
	return(hr);
}



























//=====================================================================
// Miscellaneous functions.
//=====================================================================


/********************* putInternalValue() **********************
 * Sets a variable's value.
 *
 * name =	The variable's name.
 * value =	The value.
 *
 * NOTE: The passed VARIANT is copied.
 */

static HRESULT putInternalValue(CINTERPRETER *interpreter, LPCOLESTR name, VARIANT *value)
{
	register HRESULT	hr;
	register CSYMBOL	*symbol;

	hr = DISP_E_UNKNOWNNAME;

	// See if the variable is in our internal symbol table, by
	// searching for the CSYMBOL matching this variable name
	if ((symbol = searchSymbolTables(interpreter, name)))
	{
		// Clear any previous value
		clearVariant(&symbol->SymbolValue);

		// Copy the passed value to the CSYMBOL
		hr = VariantCopy(&symbol->SymbolValue, value);
	}

	return(hr);
}





/*********************** putValue() **************************
 * Sets the value of the specified variable. This variable may
 * be not actually be in our interpreter's internal symbol table.
 * (ie, It may be a variable created and maintained by someone
 * else). But it must be a variable that we can somehow set to a
 * particular value here.
 *
 * variable =	The name of the variable.
 * value =		The new value for the variable.
 *
 * NOTE: Caller should free 'value' and 'name' upon return from
 * this function.
 */

static HRESULT putValue(CINTERPRETER *interpreter, LPCOLESTR name, VARIANT *value)
{
	register HRESULT		hr;

	LOGFUNC("putValue");

	// If we have some other object's IDispatch interface, then call its
	// Invoke() function to tell it to set the value of the specified
	// variable. In other words, we assume that the other object is
	// maintaining the variable whose value we wish to set. When do we
	// set the ResolveDispatch? When the script uses some syntax that definitely
	// shows that it is accessing an object's variable such as this:
	//
	// MyObject.SomeVariable = 1
	//
	// NOTE: A script could optionally omit the object name, in which case, we
	// aren't sure whether it's a variable in this CINTERPRETER, another
	// CINTERPRETER's global module, or a host object.
	if (interpreter->ResolveDispatch)
	{
		// If this is the IDispatch for one of our own CINTERPRETERs, then we 
		// can directly call putInternalValue() on it
		if (interpreter->ResolveDispatch->lpVtbl == &IDispatch_Vtbl)
			hr = putInternalValue((CINTERPRETER *)((unsigned char *)interpreter->ResolveDispatch - offsetof(CINTERPRETER, ResolveDispatch)), name, value);

		// Otherwise we need to treat it like an outside entity and call its Invoke(). This
		// would be the case for a host object's variable
		else
		{
			DISPID	dispId;

			if (!(hr = interpreter->ResolveDispatch->lpVtbl->GetIDsOfNames(interpreter->ResolveDispatch, &IID_NULL, (LPOLESTR *)&name, 1, 0, &dispId)))
				hr = callInvoke(interpreter, interpreter->ResolveDispatch, dispId, value, DISPATCH_PROPERTYPUT);
		}
      
		// Free up the ResolveDispatch pointer so it doesn't mess up later calls
		interpreter->ResolveDispatch->lpVtbl->Release(interpreter->ResolveDispatch);
		interpreter->ResolveDispatch = 0;
	}

	// If we don't have some other object's IDispatch, then the variable
	// may be in our own internal symbol table.
	else
	{
		register CSYMBOL	*symbol;

		hr = DISP_E_UNKNOWNNAME;

		// See if the variable is in our internal symbol table, by
		// searching for the CSYMBOL matching this variable name
		if ((symbol = searchSymbolTables(interpreter, name)))
		{
			// Clear any previous value
			clearVariant(&symbol->SymbolValue);

			// Copy the passed value to the CSYMBOL. If the datatype isn't what
			// the CSYMBOL was declared to be, change it
			hr = VariantChangeType(&symbol->SymbolValue, value, 0, (VARTYPE)(symbol->Flags & 0x00FF));
		}

		// If it wasn't found there, then search any global members in the list of Script Objects
		else
		{
			register SCRIPTOBJECT	*scriptObj;

			scriptObj = interpreter->Parent->ScriptObjectList;
			while (scriptObj)
			{
				// Only search it if it's a global member
				if (scriptObj->Flags & SCRIPTITEM_GLOBALMEMBERS)
				{
					IDispatch	*pDispatch;
					DISPID		dispId;

					// Try to get a pointer to the IDispatch for this script object
					// so we can call its Invoke() function to set the value of the
					// specified variable
					if (!(hr = getHostIDispatch(scriptObj, &pDispatch, interpreter->Parent->HostScriptSite)))
					{
						// If this is the IDispatch for one of our own CINTERPRETERs, then we 
						// can directly call putInternalValue() on it
						if (pDispatch->lpVtbl == &IDispatch_Vtbl)
							hr = putInternalValue((CINTERPRETER *)pDispatch, name, value);

						// Otherwise we need to treat it like an outside entity and call its GetIDsOfNames().
						// This would be the case for a host object's variable
						else if (!(hr = pDispatch->lpVtbl->GetIDsOfNames(pDispatch, &IID_NULL, (LPOLESTR *)&name, 1, 0, &dispId)))
						{
							hr = callInvoke(interpreter, pDispatch, dispId, value, DISPATCH_PROPERTYPUT);
							pDispatch->lpVtbl->Release(pDispatch);
							break;
						}

						// We're done with its IDispatch
						pDispatch->lpVtbl->Release(pDispatch);

						// If we found/set that variable, then we're done
						if (!hr) break;

						hr = DISP_E_UNKNOWNNAME;
					}
				}

				scriptObj = scriptObj->Next;
			}
		}
	}

	LOGHEXPARAM("Returns", hr);
	UNLOGFUNC();
	return(hr);
}





/********************* getInternalValue() **********************
 * Retrieves a variable's value.
 *
 * name =	The variable's name.
 *
 * NOTE: The variable's value is pushed on the data stack,
 * wrapped in a SCRIPTVARIANT. The SCRIPTVARIANT's VARIANT
 * is borrowed from some CSYMBOL. It is the caller's
 * responsibility to free the SCRIPTVARIANT/VARIANT.
 */

static HRESULT getInternalValue(CINTERPRETER *interpreter, LPCOLESTR name, SCRIPTVARIANT **var)
{
	register CSYMBOL	*symbol;
	register HRESULT	hr;

	hr = DISP_E_UNKNOWNNAME;

	// Get the specified CSYMBOL by name
	if ((symbol = searchSymbolTables(interpreter, name)))
	{
		hr = S_OK;

		// Get the CSYMBOL's VARIANT wrapped in a SCRIPTVARIANT
		if (!(*var = getScriptVariant(&symbol->SymbolValue))) hr = E_OUTOFMEMORY;
	}

	return(hr);
}





/************************* getValue() ************************
 * Queries the value of the specified variable. This variable
 * may be not actually be in this CINTERPRETER's internal symbol
 * table. (ie, It may be a variable created and maintained by
 * someone else). But it must be a variable whose value we can
 * somehow query here.
 *
 * interpreter =	The CINTERPRETER which wishes to fetch the
 *					value
 * name =			The name of the variable.
 *
 * NOTE: The variable's value is pushed on the data stack,
 * wrapped in a SCRIPTVARIANT. The SCRIPTVARIANT's VARIANT
 * may be borrowed from some CSYMBOL. It is the caller's
 * responsibility to free the SCRIPTVARIANT/VARIANT.
 */

static HRESULT getValue(CINTERPRETER *interpreter, LPCOLESTR name)
{
	register HRESULT	hr;
	SCRIPTVARIANT		*var;

	LOGFUNC("getValue");

	var = 0;

	// See notes in putValue()
	if (interpreter->ResolveDispatch)
	{
		// If this is the IDispatch for one of our own CINTERPRETERs, then we can directly
		// call getInternalValue() on it
		if (interpreter->ResolveDispatch->lpVtbl == &IDispatch_Vtbl)
			hr = getInternalValue((CINTERPRETER *)((unsigned char *)interpreter->ResolveDispatch - offsetof(CINTERPRETER, ResolveDispatch)), name, &var);
		else
		{
			DISPID	dispId;

			if (!(var = getScriptVariant(0)))
badmem:			return(E_OUTOFMEMORY);

			if (!(hr = interpreter->ResolveDispatch->lpVtbl->GetIDsOfNames(interpreter->ResolveDispatch, &IID_NULL, (LPOLESTR *)&name, 1, 0, &dispId)))
				hr = callInvoke(interpreter, interpreter->ResolveDispatch, dispId, var->Value, DISPATCH_PROPERTYGET);
		}

		interpreter->ResolveDispatch->lpVtbl->Release(interpreter->ResolveDispatch);
		interpreter->ResolveDispatch = 0;
	}

	// If we don't have some other object's IDispatch, then the variable
	// may be in our own internal symbol table
	else
	{
		register CSYMBOL	*symbol;
		
		// See if the variable is in our internal symbol table, by
		// searching for the CSYMBOL matching this variable name
		if ((symbol = searchSymbolTables(interpreter, name)))
		{
			// Get the CSYMBOL's VARIANT wrapped in a SCRIPTVARIANT
			if (!(var = getScriptVariant(&symbol->SymbolValue))) goto badmem;

			hr = S_OK;
		}
		else
		{
			register SCRIPTOBJECT	*scriptObj;

			// First see if this variable is actually the name of a script object
			scriptObj = interpreter->Parent->ScriptObjectList;
			while (scriptObj)
			{
				// Is this is the object name we want?
				if (!lstrcmpW(scriptObj->ObjName, name))
				{
					// The value of this variable is a pointer to some IDispatch, so
					// return that pointer in our VARIANT
					if (!(var = getScriptVariant(0))) goto badmem;
					var->Value->vt = VT_DISPATCH;

					// Get the object's IDispatch
					hr = getHostIDispatch(scriptObj, &var->Value->pdispVal, interpreter->Parent->HostScriptSite);
	
					goto retHr;
				}

				scriptObj = scriptObj->Next;
			}

			hr = DISP_E_UNKNOWNNAME;

			// If the above failed, then the variable isn't a named item, but it may be 
			// in a global module, so search those too
			scriptObj = interpreter->Parent->ScriptObjectList;
			while (scriptObj)
			{
				// Only search it if it's a global member
				if (scriptObj->Flags & SCRIPTITEM_GLOBALMEMBERS)
				{
					IDispatch	*pDispatch;
					DISPID		dispId;

					// Get a pointer to its IDispatch object
					if ((hr = getHostIDispatch(scriptObj, &pDispatch, interpreter->Parent->HostScriptSite))) break;

					// If this is the IDispatch for one of our own CINTERPRETERs, then we 
					// can directly call getInternalValue() on it
					if (pDispatch->lpVtbl == &IDispatch_Vtbl)
						hr = getInternalValue((CINTERPRETER *)pDispatch, name, &var);

					// Otherwise we need to treat it like an outside entity and call its
					// GetIDsOfNames(). This would be the case for a host object's variable
					else if (!(hr = pDispatch->lpVtbl->GetIDsOfNames(pDispatch, &IID_NULL, (LPOLESTR *)&name, 1, 0, &dispId)))
					{
						if (!(var = getScriptVariant(0))) goto badmem;
						hr = callInvoke(interpreter, pDispatch, dispId, var->Value, DISPATCH_PROPERTYGET);
					}

					// We're done with its IDispatch
					pDispatch->lpVtbl->Release(pDispatch);

					// If success, or an error other then DISP_E_UNKNOWNNAME, abort
					if (hr != DISP_E_UNKNOWNNAME) break;
				}

				scriptObj = scriptObj->Next;
			}
		}
	}
retHr:

	if (hr)
	{
		if (var) freeScriptVariant(var);
	}
	else
	{
		var->Next = interpreter->DataStack;
		interpreter->DataStack = var;
	}

	LOGHEXPARAM("Returns", hr);
	UNLOGFUNC();
	return(hr);
}





/********************* callScriptFunction() *********************
 * Calls the specified script function. This function may not
 * actually be one of our internal functions. (ie, It could be a
 * function accessed via some other object's IDispatch interface,
 * such as would be the case if we were calling a function in
 * another CINTERPRETER or host-supplied function).
 *
 * NOTE: The args for the function must have been pushed upon
 * the CINTERPRETER's data stack, and also a count of args
 * pushed.
 *
 * The function's return value will be placed upon the data
 * stack.
 *
 * This is called by evalInstruction()'s OPCODE_CALL, so
 * interpreter->CurrentInstruction contains an OPCODE_CALL
 * CINSTRUCTION whose data member is the name of the function
 * to call (nul-terminated WCHAR).
 */

static HRESULT callScriptFunction(CINTERPRETER *interpreter)
{
	register HRESULT		hr;
	register CINSTRUCTION	*instruction;
	LPOLESTR				funcName;

	LOGFUNC("callScriptFunction");

	// Get the name of the function to call from the current CINSTRUCTION
	instruction = interpreter->CurrentInstruction;
	funcName = (LPOLESTR)((unsigned char *)instruction + sizeof(CINSTRUCTION) + sizeof(void *));

	// If we have some other object's IDispatch interface, then call its
	// Invoke() function to tell it to call the specified function
	if (interpreter->ResolveDispatch)
	{
		DISPID		dispId;

		if (!(hr = interpreter->ResolveDispatch->lpVtbl->GetIDsOfNames(interpreter->ResolveDispatch, &IID_NULL, &funcName, 1, 0, &dispId)))
		{
			register SCRIPTVARIANT	*var;

			if (!(var = getScriptVariant(0)))
badmem:			return(E_OUTOFMEMORY);

			// Call the object's IDispatch Invoke() to indirectly call the desired function.
			// NOTE: callInvoke() pulls the passed args off of the data stack to pass
			// them to the object's Invoke(), and will push the object function's return on
			// the data stack if there is a return
			hr = callInvoke(interpreter, interpreter->ResolveDispatch, dispId, var->Value, DISPATCH_METHOD);
		}

		// Free up the IDispatch pointer so it doesn't mess up later calls
		interpreter->ResolveDispatch->lpVtbl->Release(interpreter->ResolveDispatch);
		interpreter->ResolveDispatch = 0;

		goto checkerr;
	}

	{
	register BuiltinFuncPtr		*ptr;

	// Did we already look up the CINSTRUCTION entry point on a previous
	// call? If so, the OPCODE_CALL's ptr field already has that
	if ((interpreter->CurrentInstruction = *((CINSTRUCTION **)((unsigned char *)instruction + sizeof(CINSTRUCTION)))))
	{
		// See if this is a built-in function
		if (interpreter->CurrentInstruction < (CINSTRUCTION *)&Functions[0] || interpreter->CurrentInstruction >= (CINSTRUCTION *)(&Functions[MAX_BUILTINS]))
			goto internal2;

		ptr = *((BuiltinFuncPtr **)interpreter->CurrentInstruction);
		goto builtin;
	}

	// Check if one of our interpreter's built-in functions
	if ((ptr = lookupBuiltin(funcName, (BuiltinFuncPtr **)((unsigned char *)instruction + sizeof(CINSTRUCTION)))))
	{
		register SCRIPTVARIANT	*var;
builtin:
		// Assume no error
		interpreter->Parent->LastSysError = 0;

		// Pop the arg count off the stack
		var = interpreter->DataStack;
		interpreter->DataStack = var->Next;
		hr = var->Value->lVal;
		freeScriptVariant(var);

		hr = (ptr)(interpreter, (DWORD)hr);
		if (hr == E_FAIL) goto done;
		goto checkerr;
	}
	}

	// Search for a script function (in this interpreter) by that name
	if ((interpreter->CurrentInstruction = findFunction(interpreter, funcName)))
		goto internal;

	// If not found, then search any global host objects (in our named items list)
	{
	register SCRIPTOBJECT	*scriptObj;

	scriptObj = interpreter->Parent->ScriptObjectList;
	while (scriptObj)
	{
		// Only search it if it's a global member
		if (scriptObj->Flags & SCRIPTITEM_GLOBALMEMBERS)
		{
			IDispatch	*pDispatch;
			DISPID		dispId;

			// Get the host object's IDispatch which we use to (perhaps) call the function
			if ((hr = getHostIDispatch(scriptObj, &pDispatch, interpreter->Parent->HostScriptSite))) goto checkerr;

			// If this is the IDispatch for one of our own CINTERPRETERs, then we 
			// can directly call evaluateCall() on it
			if (pDispatch->lpVtbl == &IDispatch_Vtbl)
			{
				// Search for the specified function's entry point in our CINSTRUCTION list
				if ((interpreter->CurrentInstruction = findFunction(interpreter, funcName)))
				{
					Dispatch_Release((CINTERPRETER *)pDispatch);

					// Update the OPCODE_FUNCENTRY's ptr field with the CINSTRUCTION entry
					// point of the function
internal:			*((CINSTRUCTION **)((unsigned char *)instruction + sizeof(CINSTRUCTION))) = interpreter->CurrentInstruction;

					// Run this function's CINSTRUCTIONs until an error, or OPCODE RET
internal2:			hr = evaluateCall(interpreter);

					// NOTE: We don't report the error here, because evaluateCall()
					// will already do that
					goto done;
				}
			}

			// Otherwise we need to treat it like an outside entity and call its GetIDsOfNames()
			// to see if this function name is in this host object. If so, call the function via
			// the host IDispatch->Invoke(). This would be the case for a host object function
			else if (!(hr = pDispatch->lpVtbl->GetIDsOfNames(pDispatch, &IID_NULL, &funcName, 1, 0, &dispId)))
			{
				register SCRIPTVARIANT	*var;

				if (!(var = getScriptVariant(0))) goto badmem;
				hr = callInvoke(interpreter, pDispatch, dispId, var->Value, DISPATCH_METHOD);
				pDispatch->lpVtbl->Release(pDispatch);
				goto checkerr;
			}

			// We don't need the host IDispatch now that we've perhaps called the function
			pDispatch->lpVtbl->Release(pDispatch);
		}

		scriptObj = scriptObj->Next;
	}
	}

	// Can't locate the function to call
	hr = DISP_E_UNKNOWNNAME;

checkerr:
	if (hr) report_error(instruction, hr, interpreter);
done:
	LOGHEXPARAM("Returns", hr);
	UNLOGFUNC();
	return(hr);
}





/*********************** findFunction() **********************
 * Locates the CINSTRUCTION with the specified function
 * entry point.
 *
 * RETURNS: Pointer to CINSTRUCTION, or 0 if not found.
 */

static CINSTRUCTION * findFunction(CINTERPRETER *interpreter, const WCHAR *match)
{
	register CINSTRUCTION	*instruction;

	instruction = interpreter->InstructionList;
	while (instruction)
	{
		if (instruction->OpCode == OPCODE_FUNCENTRY && !lstrcmpW((LPOLESTR)((unsigned char *)instruction + sizeof(CINSTRUCTION) + sizeof(unsigned short)), match))
			break;
		instruction = instruction->Next;
	}

	return(instruction);
}





/********************* report_error() ***********************
 * Looks up an error message (from our own error message
 * dll) based upon the specified HRESULT, and calls the host
 * IActiveScriptSite's OnScriptError to report the error.
 */

static void report_error(CINSTRUCTION *instruction, HRESULT hr, CINTERPRETER *interpreter)
{
	switch (hr)
	{
		case E_OUTOFMEMORY:
			hr = PARSER_OUTOFMEMORY;
			break;

		case DISP_E_BADVARTYPE:
		case TYPE_E_UNDEFINEDTYPE:
			hr = VAR_NOT_INITIALIZED;
			break;

		case DISP_E_BADPARAMCOUNT:
			hr = WRONG_ARGCOUNT;
			break;

		case DISP_E_MEMBERNOTFOUND:
		case DISP_E_PARAMNOTFOUND:
		case DISP_E_UNKNOWNNAME:
		case TYPE_E_ELEMENTNOTFOUND:
			hr = FUNC_NOT_FOUND;
			break;

		case DISP_E_TYPEMISMATCH:
		case TYPE_E_WRONGTYPEKIND:
		case TYPE_E_TYPEMISMATCH:
			hr = WRONG_ARGTYPE;
			break;

		default:
			hr = INVALID_REFERENCE;
	}

	handleRuntimeError(instruction, hr, interpreter);
}





/************************* callInvoke() ************************
 * Calls an object's Invoke() to indirectly set/query one of its
 * variables, or call one of its functions.
 *
 * pDispatch =	Pointer to the IDispatch object whose Invoke() we're calling.
 * dispId =		The DISPID of the function (in the IDispatch object) that we
 *				wish to call, or the DISPID of the variable whose value we wish
 *				to set or query.
 * result =		Where Invoke() will return the return value of the
 *				function we call, or the value of the property we query.
 * dwFlags =	DISPATCH_METHOD, DISPATCH_PROPERTYPUT, or DISPATCH_PROPERTYGET.
 *
 * RETURNS: The HRESULT returned by Invoke().
 */

static HRESULT callInvoke(CINTERPRETER *interpreter, IDispatch *pDispatch, DISPID dispId, VARIANT *result, WORD dwFlags)
{
	DISPPARAMS	dspp;
	DISPID		dispidNamed;
	VARIANT		extra;

	dspp.rgdispidNamedArgs = dspp.cArgs = dspp.cNamedArgs = 0;

	if (dwFlags == DISPATCH_METHOD)
	{
		register SCRIPTVARIANT	*var;
		register DWORD			count;

		// The last instruction before CALL should have pushed a parameter
		// count for this call. We can use this to construct the parameter
		// array we need
		var = interpreter->DataStack;
		interpreter->DataStack = var->Next;
		dspp.cArgs = var->Value->lVal;
		freeScriptVariant(var);

		// Create an array of VARIANTS to pass as parameters
		if (dspp.cArgs)
		{
			if (!(dspp.rgvarg = (VARIANT *)ALLOCMEM(dspp.cArgs * sizeof(VARIANT))))
			{
				dispidNamed = E_OUTOFMEMORY;
				if (dwFlags == DISPATCH_METHOD) goto fail;
				goto fail2;
			}

			for (count = 0; count < dspp.cArgs; count++)
			{
				// Get the next arg
				var = interpreter->DataStack;
				interpreter->DataStack = var->Next;

				// NOTE: If VT_VECTOR, then we must allocate another VARIANT and use
				// VT_BYREF!!!

				// Copy it to the VARIANT array
				CopyMemory(&dspp.rgvarg[count], var->Value, sizeof(VARIANT));

				// Set the SCRIPTVARIANT to VT_EMPTY, and free it
				var->Value->vt = VT_EMPTY;
				freeScriptVariant(var);
			}
		}
	}
	else if (dwFlags == DISPATCH_PROPERTYPUT)
	{
		dspp.rgvarg = result;
		result = &extra;
		dspp.cArgs = 1;
		dspp.cNamedArgs = 1;
		dispidNamed = DISPID_PROPERTYPUT;
		dspp.rgdispidNamedArgs = &dispidNamed;
	}

	// Call the Invoke() function of the specifed IDispatch
	dispidNamed = pDispatch->lpVtbl->Invoke(pDispatch, dispId, &IID_NULL, 0, dwFlags, &dspp, result, 0, 0);

	// Now that our call to Invoke is done, free up our VARIENT copies and their contents
	if (dwFlags == DISPATCH_METHOD)
	{
		{
		register DWORD			count;

		for (count = 0; count < dspp.cArgs; count++) VariantClear(&dspp.rgvarg[count]);
		FREEMEM(dspp.rgvarg);
		}

		{
		register SCRIPTVARIANT	*var;

fail:	var = (SCRIPTVARIANT *)((unsigned char *)result - sizeof(SCRIPTVARIANT));

		// Push the return value on the Data stack if success
		if (dispidNamed)
			freeScriptVariant(var);
		else
			var->Next = interpreter->DataStack;
			interpreter->DataStack = var;
		}
	}
fail2:
 	return((HRESULT)dispidNamed);
}





/********************* push_descriptor() **********************
 * Creates/initializes an ExtendedDSFDescriptor for the
 * script function about to be run, and pushes it on the
 * "stack frame" stack.
 */

static HRESULT push_descriptor(CINTERPRETER *interpreter, DWORD frameAddress, LPCOLESTR name)
{
	register DEBUGSTACKFRAMEDESCRIPTOR	*desc;

	if ((desc = (DEBUGSTACKFRAMEDESCRIPTOR *)ALLOCMEM(sizeof(DEBUGSTACKFRAMEDESCRIPTOR))))
	{
		desc->DebugStackFrame = &IDebugStackFrame_Vtbl;
		desc->DebugExpressionContext = &IDebugExpressionContext_Vtbl;
		desc->FrameAddress = frameAddress;
		desc->Interpreter = interpreter;
		desc->Instruction = interpreter->CurrentInstruction;
		desc->Name = name;

		// Push the DEBUGSTACKFRAMEDESCRIPTOR onto the "Frame stack", so we can see it at breakpoints
		if (stackPush(&interpreter->Parent->StackFrames, desc)) return(S_OK);
		FREEMEM(desc);
	}

	return(E_OUTOFMEMORY);
}





/*********************** pop_descriptor() **********************
 * Removes the topmost DEBUGSTACKFRAMEDESCRIPTOR from the
 * "stack frame" stack, and frees it.
 */

static void pop_descriptor(CINTERPRETER *interpreter)
{
	register DEBUGSTACKFRAMEDESCRIPTOR	*desc;

	// Pop DEBUGSTACKFRAMEDESCRIPTOR off the stack and delete it
	desc = (DEBUGSTACKFRAMEDESCRIPTOR *)stackPop(&interpreter->Parent->StackFrames);
	FREEMEM(desc);

	// After a script function call, there's no pending breakpoint
	interpreter->Parent->BreakResumeAction = BREAKRESUMEACTION_CONTINUE;
}





/********************* evaluateImmediate() *********************
 * Scans the instruction list and runs any immediate code that
 * may be present. In the instruction list, an immediate
 * CINSTRUCTION has its IMMEDIATE_INSTRUCTION flag set.
 *
 * NOTE: For a C language engine, we always consider the "main"
 * function as immediate execution.
 */

HRESULT evaluateImmediate(CINTERPRETER *interpreter, VARIANT *result)
{
	register HRESULT		hr;

	LOGFUNC("evaluateImmediate");

	if (result) VariantInit(result);

	hr = S_OK;

	if (interpreter->InstructionList)
	{
		// Reset instruction list to start
		interpreter->CurrentInstruction = interpreter->InstructionList;

		// Initially, no pending debugger breakpoint
		interpreter->Parent->BreakResumeAction = BREAKRESUMEACTION_CONTINUE;

		// If host is debugger-aware, then create a DEBUGSTACKFRAMEDESCRIPTOR, and
		// push it on the "stack frame" stack
		if (!interpreter->Parent->HostDebugApplication ||

			// NOTE: To determine the stack frame address, we can use the address of a
			// variable local to this function. We could also do this with some
			// inline assembly code, but that would make our code machine dependent
			!(hr = push_descriptor(interpreter, (DWORD)&interpreter, &GlobalDescName[0])))
		{
			// Before interpreting any instruction, we have to notify the host that
			// we're going to execute code. What is this for? I suspect that the purpose
			// of this is to let the host debugger update its "call stack". After all,
			// we're now entering another call level. In this case, we need to call
			// the host's OnEnterScript *after* we allocate the above stack frame
			if (!(hr = interpreter->Parent->HostScriptSite->lpVtbl->OnEnterScript(interpreter->Parent->HostScriptSite)))
			{
				// Indicate we're executing a script
				interpreter->Parent->Flags |= SCRIPTTHREADSTATE_RUNNING;

				// Run through all the instructions in the list, only executing those marked
				// as IMMEDIATE
				interpreter->Flags |= FLAG_DO_IMMEDIATE;
				hr = evalInstruction(interpreter);
				interpreter->Flags &= ~FLAG_DO_IMMEDIATE;

				// The "main" function isn't technically immediate code, but it is the well
				// known entry point into C code, so we call it as part of immediate execution.
				// But don't call "main" if it has already been called once
				if (!hr && !(interpreter->Flags & FLAG_MAINCOMPLETED))
				{
					// Search for "main" function's entry point in our CINSTRUCTION list
					if ((interpreter->CurrentInstruction = findFunction(interpreter, &MainFuncName[0])))
					{
						register SCRIPTVARIANT	*prevStack;
						register SCRIPTVARIANT	*var;

						// We want to ensure stack integrity around our call to evalInstruction(),
						// so get the current SCRIPTVARIANT at the top of the list. If the evalInstruction()
						// fails and leaves garbage on the stack, we'll be able to clean it up here
						prevStack = interpreter->DataStack;

						// Push an arg count of 0 (ie, we pass no args to main)
						if (!(var = getScriptVariant(0)))
						{
							hr = E_OUTOFMEMORY;
							goto skip;
						}
						var->Value->vt = VT_I4;
						var->Value->lVal = 0;
						var->Next = interpreter->DataStack;
						interpreter->DataStack = var;

						// Evaluate instructions until an error occurs or until main returns
						if (!(hr = evaluateCall(interpreter)) &&

							// Check if caller wants main()'s return value
							result &&

							// Check if main() returned a value. If so, copy to caller's VARIANT
							(var = interpreter->DataStack) != prevStack)
						{
							// If the VARIANT isn't borrowed from someone else, than steal away
							// its value
							if (((unsigned char *)var + sizeof(SCRIPTVARIANT)) == (unsigned char *)var->Value)
							{
								CopyMemory(result, var->Value, sizeof(VARIANT));
								var->Value->vt = VT_EMPTY;
							}
							else
								hr = VariantCopy(result, var->Value);

							freeScriptVariant(var);
						}

						// Now that we're done, ensure stack integrity
						while (prevStack && (var = interpreter->DataStack) != prevStack)
						{
							interpreter->DataStack = var->Next;
							freeScriptVariant(var);
						}
					}

					// Do not search for, nor run, main() again
					interpreter->Flags |= FLAG_MAINCOMPLETED;
				}

				// Free any object IDispatch we were holding onto
skip:			if (interpreter->ResolveDispatch) interpreter->ResolveDispatch->lpVtbl->Release(interpreter->ResolveDispatch);
				interpreter->ResolveDispatch = 0;

				// Pop global descriptor
				if (interpreter->Parent->HostDebugApplication) pop_descriptor(interpreter);

				// We have to notify the host that we're done executing code
				{
				register HRESULT	hr2;
				if ((hr2 = interpreter->Parent->HostScriptSite->lpVtbl->OnLeaveScript(interpreter->Parent->HostScriptSite)) && !hr) hr = hr2;
				}

				// Indicate we're no longer executing a script
				interpreter->Parent->Flags &= ~(SCRIPTTHREADSTATE_RUNNING|ACTIVESCRIPTFLAG_HALTRAISED);
			}
			else if (interpreter->Parent->HostDebugApplication)
				pop_descriptor(interpreter);
		}
		else
			hr = E_OUTOFMEMORY;
	}

	LOGHEXPARAM("Returns", hr);
	UNLOGFUNC();
	return(hr);
}





/************************* findLabel() ***********************
 * Locates the CINSTRUCTION with the specified text label.
 *
 * RETURNS: Pointer to CINSTRUCTION, or 0 if not found.
 */

static CINSTRUCTION * findLabel(CINTERPRETER *interpreter, const WCHAR *match)
{
	register CINSTRUCTION	*instruction;

	instruction = interpreter->InstructionList;
	while (instruction)
	{
		if ((instruction->Flags & INSTRUCTION_HAS_LABEL) && !(instruction->Flags & LABEL_IS_DWORD)
			&& !lstrcmpW(*((LPOLESTR *)((unsigned char *)instruction - sizeof(void *))), match))
		{
			break;
		}
		instruction = instruction->Next;
	}

	return(instruction);
}





/********************* findNumericLabel() ********************
 * Locates the CINSTRUCTION with the specified numeric
 * label.
 *
 * RETURNS: Pointer to CINSTRUCTION, or 0 if not found.
 */

static CINSTRUCTION * findNumericLabel(CINTERPRETER *interpreter, DWORD match)
{
	register CINSTRUCTION	*instruction;

	instruction = interpreter->InstructionList;
	while (instruction)
	{
		if ((instruction->Flags & (INSTRUCTION_HAS_LABEL|LABEL_IS_DWORD)) == (INSTRUCTION_HAS_LABEL|LABEL_IS_DWORD) &&
			*((DWORD *)((unsigned char *)instruction - sizeof(void *))) == match)
		{
			break;
		}
		instruction = instruction->Next;
	}

	return(instruction);
}





/*********************** evaluateCall() *************************
 * Evaluates the instructions of a call to some script function.
 *
 * NOTE: interpreter->CurrentInstruction must be set to the
 * first (OPCODE_FUNCENTRY) CINSTRUCTION of the script function.
 */

HRESULT evaluateCall(CINTERPRETER *interpreter)
{
	register HRESULT	hr;

	LOGFUNC("evaluateCall");

	hr = E_OUTOFMEMORY;

	if (!interpreter->Parent->HostDebugApplication || !(hr = push_descriptor(interpreter, (DWORD)&interpreter, (LPCOLESTR)((unsigned char *)interpreter->CurrentInstruction + sizeof(CINSTRUCTION) + sizeof(unsigned short)))))
	{
		// Create a symbol table for this function
		if (pushScope(interpreter))
		{
			if (!(hr = interpreter->Parent->HostScriptSite->lpVtbl->OnEnterScript(interpreter->Parent->HostScriptSite)))
			{
				register HRESULT	hr2;

				// Evaluate instructions until an error occurs or until the function returns
				hr = evalInstruction(interpreter);

				// Pop a symbol scope (ie, free up the current symbol table and
				// reinstate the previously pushed one)
				if ((hr2 = popScope(interpreter)) && !hr) hr = hr2;

				// Remove this function's stack frame
				if (interpreter->Parent->HostDebugApplication) pop_descriptor(interpreter);

				// Tell host to update its lists
				if ((hr2 = interpreter->Parent->HostScriptSite->lpVtbl->OnLeaveScript(interpreter->Parent->HostScriptSite)) && !hr) hr = hr2;
			}
			else
				popScope(interpreter);
		}
		else if (interpreter->Parent->HostDebugApplication)
			pop_descriptor(interpreter);
	}

	LOGHEXPARAM("Returns", hr);
	UNLOGFUNC();
	return(hr);
}





/********************* evalInstruction() ***********************
 * Evaluates a single byte-code instruction.
 */

static HRESULT evalInstruction(CINTERPRETER *interpreter)
{
	register CINSTRUCTION	*instruction;
	HRESULT					hr;

	LOGFUNC("evalInstruction");

	hr = S_OK;

	// Get first instruction
	instruction = interpreter->CurrentInstruction;
	do
	{
again:	// Abort?
		if (interpreter->Parent->Flags & ACTIVESCRIPTFLAG_HALTRAISED)
		{
abort:		hr = E_ABORT;
			goto out;
		}
	
		// Make sure this instruction hasn't already been executed in immediate mode
		if (!(instruction->Flags & IMMMEDIATE_COMPLETED) &&

			// Do this if an immediate instruction
			(!(interpreter->Flags & FLAG_DO_IMMEDIATE) || (instruction->Flags & IMMEDIATE_INSTRUCTION)))
		{	
			// We need to update the current instruction pointer for our IDebugStackFrame's
			// GetCodeContext()
			interpreter->CurrentInstruction = instruction;

			if (interpreter->Parent->HostDebugApplication)
			{
				register ACTIVESCRIPT	*activeScript;
				register unsigned char	breakReason;

				activeScript = interpreter->Parent;

				// If our log window is open, do some message handling
				LOGHANDLER();

				// Update current stack frame's current instruction
				((DEBUGSTACKFRAMEDESCRIPTOR *)activeScript->StackFrames->Value)->Instruction = instruction;

  				// Check the host debugger's state for block or halt 
  				if (activeScript->BreakFlags & APPBREAKFLAG_DEBUGGER_BLOCK)
				{
					// Break with BREAKREASON_DEBUGGER_BLOCK. HandleBreakPoint
					// will block until the debugger is done interacting with the user
					breakReason = BREAKREASON_DEBUGGER_BLOCK;
					goto dobreak2;
				}
  				if (activeScript->BreakFlags & APPBREAKFLAG_DEBUGGER_HALT)
				{
					// Break with BREAKREASON_DEBUGGER_HALT
					breakReason = BREAKREASON_DEBUGGER_HALT;
dobreak2: 			activeScript->BreakFlags = 0;
					goto dobreak;
				}

				// Assume break with BREAKREASON_STEP
				breakReason = BREAKREASON_STEP;
				if (activeScript->BreakFlags & APPBREAKFLAG_STEPTYPE_MASK) goto dobreak2;

				// If a STEPOUT, then wait until we descend out of the current function before
				// we honor any more breakpoints
				if (activeScript->BreakResumeAction != BREAKRESUMEACTION_STEP_OUT)
				{
					DWORD		breakAction;

					// Check to see if the current instruction has a breakpoint set
					if ((instruction->Flags & BREAKPOINT_BITS) == BREAKPOINT_ENABLED) breakReason = BREAKREASON_BREAKPOINT;
      
					// Check the break state of the engine
					else switch (activeScript->BreakResumeAction)
					{
						// For anything except CONTINUE and IGNORE, force a STEP
						case BREAKRESUMEACTION_CONTINUE:
						case BREAKRESUMEACTION_IGNORE:
							goto skipbreak;
					}
 
dobreak:			if ((hr = activeScript->HostDebugApplication->lpVtbl->HandleBreakPoint(activeScript->HostDebugApplication, breakReason, &breakAction))) goto out;
					activeScript->BreakResumeAction = (unsigned char)breakAction;
					if (breakAction == BREAKRESUMEACTION_ABORT) goto abort;
				}
			}

			{
			register SCRIPTVARIANT	*pSVar1;

			// The OpCode will tell us what operation to perform
skipbreak:	if (instruction->OpCode < OPCODE_NOOP)
			{
				// A UNARY operation?
				if (instruction->OpCode >= OPCODE_INC && instruction->OpCode <= OPCODE_NEG)
				{
					register VARIANT	*orig;
					register VARIANT	*ret;

					// Pop the last SCRIPTVARIANT pushed onto the data stack
					if (!(pSVar1 = interpreter->DataStack)) goto stackfail;
					interpreter->DataStack = pSVar1->Next;
					ret = orig = pSVar1->Value;

					// Make sure that it's a legitimate value. If we previously did an OPCODE_LOAD of a
					// variable that was never assigned a value, or pushed an empty return from a function
					// call that returned no value, then we'll have a VT_EMPTY VARIANT on the stack
					if (orig->vt == VT_EMPTY)
					{
empty:					freeScriptVariant(pSVar1);
noval:					hr = EMPTY_EXPRESSION;
						goto reporterr;
					}

					// Can we reuse its VARIANT to return the result? We can if its
					// VARIANT isn't borrowed from someone else
					if (((unsigned char *)pSVar1 + sizeof(SCRIPTVARIANT)) != (unsigned char *)orig)
					{
						// It's a borrowed VARIANT. We can't alter its value.

						// Free the orig SCRIPTVARIANT. NOTE: This frees only the SCRIPTVARIANT -- not its VARIANT
						freeScriptVariant(pSVar1);

						// Get a new SCRIPTVARIANT/VARIANT
						if (!(pSVar1 = getScriptVariant(0))) goto badmem;
						ret = (VARIANT *)((unsigned char *)pSVar1 + sizeof(SCRIPTVARIANT));
					}

					// Perform the UNARY operation, and store the VARIANT's value
					if ((hr = (UnaryOperators[instruction->OpCode - OPCODE_INC])(orig, ret))) goto badop;

					// For an OPCODE_DEC/OPCODE_INC, we must update the value of the variable with
					// this new value
					if (instruction->OpCode == OPCODE_INC || instruction->OpCode == OPCODE_DEC)
					{
						if ((hr = putValue(interpreter, *((LPOLESTR *)((unsigned char *)instruction + sizeof(CINSTRUCTION))), ret))) goto badop;
					}

					// Push the result SCRIPTVARIANT on the data stack
					pSVar1->Next = interpreter->DataStack;
					interpreter->DataStack = pSVar1;
				}

				// A OPCODE_INC2/OPCODE_DEC2 operation?
				else if (instruction->OpCode == OPCODE_INC2 || instruction->OpCode == OPCODE_DEC2)
				{
					register SCRIPTVARIANT	*temp;

					if (!(temp = interpreter->DataStack)) goto stackfail;
					if (temp->Value->vt == VT_EMPTY) goto noval;

					// Get a SCRIPTVARIANT to return the result value on the data stack. We don't
					// want to alter the value already on the stack because the increment should
					// affect the variable's value only AFTER we've fetched the value for use in
					// some expression
					if (!(pSVar1 = getScriptVariant(0))) goto badmem;
					if (!(hr = (UnaryOperators[instruction->OpCode - OPCODE_INC2])(temp->Value, pSVar1->Value)))
					{
						hr = putValue(interpreter, *((LPOLESTR *)((unsigned char *)instruction + sizeof(CINSTRUCTION))), pSVar1->Value);
					}

					if (hr) goto badop;

					// Substitute the result value on the stack
					pSVar1->Next = temp->Next;
					interpreter->DataStack = pSVar1;
					freeScriptVariant(temp);
				}

				// A BINARY operation?
				else if (instruction->OpCode >= OPCODE_GE && instruction->OpCode <= OPCODE_SUB)
				{
					register SCRIPTVARIANT	*pSVar2;

					// Get the last item pushed onto the data stack. NOTE: Pop it off. After we perform
					// the binary operation on the two stack items, we want to leave only the 1 result
					// on the stack
					if ((pSVar2 = interpreter->DataStack))
					{
						interpreter->DataStack = pSVar2->Next;

						// Get the second-to-last item pushed onto the data stack. NOTE: Don't pop it off
						if ((pSVar1 = interpreter->DataStack))
						{
							register VARIANT	*orig;
							register VARIANT	*ret;

							interpreter->DataStack = pSVar1->Next;
							ret = orig = pSVar1->Value;

							if (pSVar2->Value->vt == VT_EMPTY || pSVar1->Value->vt == VT_EMPTY)
							{
								freeScriptVariant(pSVar2);
								goto empty;
							}

							if (((unsigned char *)pSVar1 + sizeof(SCRIPTVARIANT)) != (unsigned char *)orig)
							{
								freeScriptVariant(pSVar1);
								if (!(pSVar1 = getScriptVariant(0)))
								{
									freeScriptVariant(pSVar2);
									goto badmem;
								}
								ret = (VARIANT *)((unsigned char *)pSVar1 + sizeof(SCRIPTVARIANT));
							}

							hr = (BinaryOperators[instruction->OpCode - OPCODE_GE])(orig, pSVar2, ret);
							freeScriptVariant(pSVar2);

							if (hr) goto badop;

							pSVar1->Next = interpreter->DataStack;
							interpreter->DataStack = pSVar1;
							goto next;
						}

						freeScriptVariant(pSVar2);
					}

					goto stackfail;
				}

				else switch (instruction->OpCode)
				{
					// Push a constant string
					case OPCODE_CONSTSTR:
					{
						if ((pSVar1 = getScriptVariant(0)))
						{
							register DWORD	size;

							size = *((DWORD *)((unsigned char *)instruction + sizeof(CINSTRUCTION)));
							if ((pSVar1->Value->bstrVal = SysAllocStringByteLen(0, size)))
							{
								pSVar1->Value->vt = VT_BSTR;
								CopyMemory(pSVar1->Value->bstrVal, (unsigned char *)instruction + sizeof(CINSTRUCTION) + sizeof(DWORD), size);
								goto push;
							}

							FREEMEM(pSVar1);
						}

badmem:					hr = E_OUTOFMEMORY;
						goto reporterr;
					}

					// Push a constant long
					case OPCODE_CONSTLONG:
					{
						// Alloc a SCRIPTVARIANT
						if (!(pSVar1 = getScriptVariant(0))) goto badmem;

						// Fill in the VARIANT with a long value
						pSVar1->Value->vt = VT_I4;
						pSVar1->Value->lVal = *((long *)((unsigned char *)instruction + sizeof(CINSTRUCTION)));

						// Push the SCRIPTVARIANT on the data stack, to be pulled off later by a
						// SAVE operation or a CALL, or used in some UNARY/BINARY operation, etc
push:					pSVar1->Next = interpreter->DataStack;
						interpreter->DataStack = pSVar1;
						break;
					}

					// Push a constant double
					case OPCODE_CONSTDBL:
					{
						if (!(pSVar1 = getScriptVariant(0))) goto badmem;

						// Fill in the VARIANT with a double value
						pSVar1->Value->vt = VT_R8;
						CopyMemory(&pSVar1->Value->dblVal, (unsigned char *)instruction + sizeof(CINSTRUCTION), sizeof(double));

						goto push;
					}

					// Load the value of a variable into the data stack
					case OPCODE_LOAD:
					{
						// Get the value of the variable into a SCRIPTVARIANT
						// and push it on the stack
						if ((hr = getValue(interpreter, (LPOLESTR)((unsigned char *)instruction + sizeof(CINSTRUCTION)))))
						{
reporterr:					report_error(instruction, hr, interpreter);
							goto fail;
						}

						break;
					}

					// Save a value from the data stack to a variable
					case OPCODE_SAVE:
					{
						register VARIANT		*var;

						// Get the SCRIPTVARIANT that we previously pushed onto the stack
						pSVar1 = interpreter->DataStack;

						// See if we need to make a copy of the value. This could be the case if we
						// have an instruction containing an embedded assignment within an expression
						// such as
						//
						// myFunction((var1 = "Some value"));
						if (*((unsigned char *)((unsigned char *)instruction + sizeof(CINSTRUCTION) + sizeof(void *) + 1)))
						{
							var = pSVar1->Value;
							if (!(pSVar1 = getScriptVariant(0))) goto badmem;
							if ((hr = VariantCopy(pSVar1->Value, var))) goto badop;
						}
						else
							interpreter->DataStack = pSVar1->Next;

						// Make sure we got a legitimate value
						if (pSVar1->Value->vt == VT_EMPTY)
						{
							hr = DISP_E_BADVARTYPE;
badop:						freeScriptVariant(pSVar1);
							goto reporterr;
						}

						// Set the value of that variable to this VARIANT
						if ((hr = putValue(interpreter, *((LPOLESTR *)((unsigned char *)instruction + sizeof(CINSTRUCTION))), pSVar1->Value))) goto badop;

						// Delete the SCRIPTVARIANT now that putValue() has set the variable's value
						goto cleanup;
					}

					// Create a new variable and add it to the current symbol table. This
					// happens when a variable is declared
					case OPCODE_DATA:
					{
						register CSYMBOLTABLE	*table;
						register CSYMBOL		*symbol;

						symbol = (CSYMBOL *)((unsigned char *)instruction + sizeof(CINSTRUCTION));

						// Has it already been added to this level? If so, don't do it again
						if (!(symbol->Flags & SYMTYPE_ADDED))
						{
							symbol->Flags |= SYMTYPE_ADDED;

							// Add this CYMBOL to the CSYMBOLTABLE list
							table = interpreter->SymbolTable->Value;
							symbol->Next = table->SymbolList;
							table->SymbolList = symbol;
						}

						break;
					}

					// Create a new variable, add it to the current symbol table, and set its value
					// to whatever was last pushed onto the data stack. This happens when a function
					// pulls its args off of the stack and puts them into local args (variables) upon
					// entry to the function
					case OPCODE_PARAM: 
					{
						register CSYMBOLTABLE	*table;
						register CSYMBOL		*symbol;

						if (!(pSVar1 = interpreter->DataStack))
						{
stackfail:					hr = STACK_FAILURE;
error:						handleRuntimeError(instruction, hr, interpreter);
fail:						hr = E_FAIL;
							goto out;
						}
						interpreter->DataStack = pSVar1->Next;

						if (pSVar1->Value->vt == VT_EMPTY)
						{
noval2:						hr = EMPTY_EXPRESSION;
							goto error;
						}

						symbol = (CSYMBOL *)((unsigned char *)instruction + sizeof(CINSTRUCTION));

						// Copy the SCRIPTVARIANT's VARIANT
						if (((unsigned char *)pSVar1 + sizeof(SCRIPTVARIANT)) == (unsigned char *)pSVar1->Value)
						{
							clearVariant(&symbol->SymbolValue);
							CopyMemory(&symbol->SymbolValue, pSVar1->Value, sizeof(VARIANT));
							pSVar1->Value->vt = VT_EMPTY;
						}
						else
							if ((hr = VariantCopy(&symbol->SymbolValue, pSVar1->Value))) goto badop;

						freeScriptVariant(pSVar1);

						// Add this CYMBOL to the CSYMBOLTABLE list
						table = interpreter->SymbolTable->Value;
						symbol->Next = table->SymbolList;
						table->SymbolList = symbol;

						break;
					}

					// Pop the top element of the data stack, and check to see if it's an 
					// IDispatch pointer. If so, put that pointer into ResolveDispatch so
					// the next callScriptFunction(), putValue(), SetValue() will go out to this
					// IDispatch's Invoke() to perform the operation
					case OPCODE_FIELD:
					{
						register LPOLESTR	name;

						// Is there a variable name supplied?
						name = (LPOLESTR)((unsigned char *)instruction + sizeof(CINSTRUCTION));
						if (*name)
						{
							// Yes. Get the IDispatch from the variable's value

							// Get the value of the variable into a SCRIPTVARIANT
							if ((hr = getValue(interpreter, name))) goto reporterr;
						}

						// Grab the VARIANT (ie, IDispatch) previously pushed on the data stack
						// via an OPCODE_LOAD
						pSVar1 = interpreter->DataStack;
						interpreter->DataStack = pSVar1->Next;

						// If the VARIANT is not holding an IDispatch pointer, report an error
						if (!pSVar1 || pSVar1->Value->vt != VT_DISPATCH)
						{
							if (pSVar1) freeScriptVariant(pSVar1);
							hr = OBJECT_REQUIRED;
							goto error;
						}

						// Free any previous IDispatch we were holding onto
						if (interpreter->ResolveDispatch) interpreter->ResolveDispatch->lpVtbl->Release(interpreter->ResolveDispatch);
						interpreter->ResolveDispatch = 0;

						// Store the IDispatch and AddRef() it
						interpreter->ResolveDispatch = pSVar1->Value->pdispVal;
						interpreter->ResolveDispatch->lpVtbl->AddRef(interpreter->ResolveDispatch);

						goto cleanup;
					}

					// A function call
					case OPCODE_CALL:
					{
						register SCRIPTVARIANT	*prevStack;

						{
						register DWORD	argCount;

						// We want to ensure stack integrity around our call to callScriptFunction(),
						// so get the current SCRIPTVARIANT at the top of the list. If callScriptFunction()
						// fails and leaves garbage on the stack, we'll be able to clean it up here.
						// NOTE: The item currently at the top of the stack is a count of how many
						// args are passed. We need to get the stack position prior to the arg count
						// and pushed args (because we want to clean those up if we don't carry out
						// all our OPCODE_PARAM instructions)
						pSVar1 = prevStack = interpreter->DataStack;
						argCount = pSVar1->Value->lVal;
						do
						{
							prevStack = prevStack->Next;
						} while (argCount--);
						}

						{
						register unsigned char	breakResume;

						// If a STEPOVER, change to a STEPOUT so breakpoints are skipped
						breakResume = interpreter->Parent->BreakResumeAction;
						if (breakResume == BREAKRESUMEACTION_STEP_OVER)
							interpreter->Parent->BreakResumeAction = BREAKRESUMEACTION_STEP_OUT;

						// Call the specified script function. NOTE: callScriptFunction() will push
						// any return value on the stack
						if ((hr = callScriptFunction(interpreter)))
						{
							// Now that we're done, ensure stack integrity
							while (prevStack && (pSVar1 = interpreter->DataStack) != prevStack)
							{
								interpreter->DataStack = pSVar1->Next;
								freeScriptVariant(pSVar1);
							}

							// Don't report an error. The called function should have done that
							goto out;
						}

						// If originally a STEPOVER, then we need a STEPINTO now
						if (breakResume == BREAKRESUMEACTION_STEP_OVER)
							interpreter->Parent->BreakResumeAction = BREAKRESUMEACTION_STEP_INTO;
						}

						// Did the caller return a value?
						if (interpreter->DataStack == prevStack)
						{
							// If the function didn't push a return value on the data stack, then
							// we need to push a VT_EMPTY SCRIPTVARIANT to indicate no data
							// return, and also to allow an OPCODE_CLEAN to pop it off the stack
							// if the return value is not being used
							if (!(pSVar1 = getScriptVariant(0))) goto badmem;
							pSVar1->Next = interpreter->DataStack;
							interpreter->DataStack = pSVar1;
						}

						break;
					}

					// Jump to the specified label
					case OPCODE_JUMP:
					{
						// Find the CINSTRUCTION and set it as instruction->CurrentItem
						instruction = findNumericLabel(interpreter, *((DWORD *)((unsigned char *)instruction + sizeof(CINSTRUCTION))));
testjump:				if (!instruction)
						{
							hr = LABEL_MISSING;
							goto error;
						}

						goto again;
					}

					// Jump if the SCRIPTVARIANT on the top of the data stack resolves to false
					case OPCODE_BRANCH_FALSE:
					{
						pSVar1 = interpreter->DataStack;
						interpreter->DataStack = pSVar1->Next;
						if (pSVar1->Value->vt == VT_EMPTY) goto noval2;
						if (!isResultTrue(pSVar1))
						{
jump:						instruction = findNumericLabel(interpreter, *((DWORD *)((unsigned char *)instruction + sizeof(CINSTRUCTION))));
							freeScriptVariant(pSVar1);
							goto testjump;
						}
						goto cleanup;
					}

					// Jump if the top SCRIPTVARIANT resolves to true
					case OPCODE_BRANCH_TRUE: 
					{
						pSVar1 = interpreter->DataStack;
						interpreter->DataStack = pSVar1->Next;
						if (pSVar1->Value->vt == VT_EMPTY) goto noval2;
						if (isResultTrue(pSVar1)) goto jump;
						goto cleanup;
					}

					case OPCODE_RET:
						goto out;

					// At the start of every script function, there is an OPCODE_CHECKARG
					// which holds a count of how many args the function expects to be
					// passed. Right before every OPCODE_CALL, there is a OPCODE_CONSTLONG
					// that pushes the count of args that were actually passed. It is the
					// last item pushed on the data stack when we get here. So we pop that
					// value and check it to see if the caller passed the correct # of args
					case OPCODE_CHECKARG:
					{
						// Get the arg count the caller pushed on the stack (via his
						// OPCODE_CONSTLONG CINSTRUCTION)
						pSVar1 = interpreter->DataStack;
						interpreter->DataStack = pSVar1->Next;

						// Compare it to our CHECKARG CINSTRUCTION's count
						if ((DWORD)pSVar1->Value->lVal != *((DWORD *)((unsigned char *)instruction + sizeof(CINSTRUCTION))))
						{
							// Caller did not pass the correct # of args
							hr = DISP_E_BADPARAMCOUNT;
							goto badop;
						}

cleanup:				freeScriptVariant(pSVar1);
						break;
					}

					// Instructs the interpreter to clean one value off the stack. We have to
					// clean up any evaluated expression's result (SCRIPTVARIANT) if it isn't
					// being used
					case OPCODE_CLEAN:
					{
						// NOTE: There may not be a value pushed on the stack. Why??? Because some functions
						// do not return a value (ie, push a value on the data stack), and so if this
						// expression is a function call where the return value is not used, and the
						// function doesn't return a value, this happens.
						//
						// NOTE: This should be fixed now, but just in case...
						if ((pSVar1 = interpreter->DataStack))
						{
							interpreter->DataStack = pSVar1->Next;
							goto cleanup;
						}
						break;
					}

					// Push a symbol scope (ie, create a new symbol table)
					case OPCODE_PUSH:
						// NOTE: We pass a nul string as the name
						if (!pushScope(interpreter)) goto badmem;
						break; 

					// Pop a symbol scope (ie, free up the current symbol table and
					// reinstate the previously pushed one)
					case OPCODE_POP:
						popScope(interpreter);
#ifndef _NDEBUG
						break;

					// An unrecognized instruction
					default:
					{
						// Report an error
						hr = INVALID_INSTRUCTION;
						goto error;
					}
#endif
				}
			}
			}

			// Flag this instruction as having now been executed in immediate mode
next:		if (instruction->Flags & IMMEDIATE_INSTRUCTION) instruction->Flags |= IMMMEDIATE_COMPLETED;
		}

	// Next instruction
	} while ((instruction = instruction->Next));

out:
	LOGHEXPARAM("Returns", hr);
	UNLOGFUNC();
	return(hr);
}





/********************* allocInterpreter() **********************
 * Creates a new CINTERPRETER with the given object name.
 *
 * name =		The object name, or 0 if the global object.
 * iactive =	ACTIVESCRIPT that owns this CINTERPRETER
 *
 * RETURNS: Ptr to CINTERPRETER, or 0 if memory failure.
 */

CINTERPRETER * allocInterpreter(const WCHAR *name, ACTIVESCRIPT *iactive)
{
	register CINTERPRETER	*interpreter;
	register DWORD			len;

	// Get a CINTERPRETER, plus room to append the name
	len = 0;
	if (name) len = lstrlenW(name) * sizeof(WCHAR);
	if ((interpreter = (CINTERPRETER *)ALLOCMEM(sizeof(CINTERPRETER) + len)))
	{
		ZeroMemory(interpreter, sizeof(CINTERPRETER));

		// Set the IDispatch VTable
		interpreter->lpVtbl = &IDispatch_Vtbl;

		// Copy the name
		if (name) lstrcpyW(&interpreter->Name[0], name);

		// Save the ptr to the ACTIVESCRIPT
		interpreter->Parent = iactive;

		// Create a CSYMBOLTABLE for the global scope. This
		// will be deleted when the CINTERPRETER itself is deleted
		if (!pushScope(interpreter))
		{
			FREEMEM(interpreter);
			interpreter = 0;
		}
		else
		{
			// Insert this CINTERPRETER into the list
			
			// Always leave the global interpreter first
			if (iactive->InterpreterList)
			{
				interpreter->Next = iactive->InterpreterList->Next; 
				iactive->InterpreterList->Next = interpreter;
			}
			else
			{
				interpreter->Next = 0; 
				iactive->InterpreterList = interpreter;
			}
		}
	}

	return(interpreter);
}





void free_block(void *ptr)
{
	FREEMEM(ptr);
}





/********************* freeInterpreter() **********************
 * Frees a CINTERPRETER.
 *
 * interpreter =	CINTERPRETER to free.
 *
 * NOTE: Caller must unlink the CINTERPRETER from its
 * ACTIVESCRIPT->InterpreterList list.
 */

void freeInterpreter(CINTERPRETER *interpreter)
{
	// Free any external IDispatch we're holding onto
	if (interpreter->ResolveDispatch) interpreter->ResolveDispatch->lpVtbl->Release(interpreter->ResolveDispatch);

	// Empty the MEMBERINFO list
	{
	register MEMBERINFO	*pInfo;

	while ((pInfo = interpreter->MemberInfoList))
	{
		interpreter->MemberInfoList = interpreter->MemberInfoList->Next;
		FREEMEM(pInfo);
	}
	}

	// Empty the data stack (ie, returned results from functions/scripts)
	{
	register SCRIPTVARIANT	*var;

	while ((var = interpreter->DataStack))
	{
		interpreter->DataStack = var->Next;
		freeScriptVariant(var);
	}
	}

	// Free the global CSYMBOLTABLE
	popScope(interpreter);

	// Free the CINSTRUCTIONs
	freeInstructionList(interpreter->InstructionList);

	// Free the CINTERPRETER
	FREEMEM(interpreter);
}





/********************* findInterpreter() **********************
 * Locates the CINTERPRETER with the matching name
 *
 * RETURNS: Ptr to CINTERPRETER, or 0 if not found.
 */

CINTERPRETER * findInterpreter(ACTIVESCRIPT *iactive, LPCOLESTR name)
{
	register CINTERPRETER	*interpreter;

	if (!name) name = &MainFuncName[4];		// An empty string

	interpreter = iactive->InterpreterList;
	while (interpreter)
	{
		if (!lstrcmpW(name, &interpreter->Name[0])) break;
		interpreter = interpreter->Next;
	}

	return(interpreter);
}





/******************** resetInterpreter() ***********************
 * Resets the interpreter's instruction list, so that immediate
 * code is marked as "yet to be run".
 */

void resetInterpreter(CINTERPRETER *interpreter)
{
	// Reset the "main() has been executed" flag
	interpreter->Flags &= ~FLAG_MAINCOMPLETED;

	// Reset the IMMMEDIATE_COMPLETED flag of all instructions.
	// NOTE: Each instruction is responsible for tracking whether or not it
	// has been executed in immediate mode
	{
	register CINSTRUCTION	*instruction;

	instruction = interpreter->InstructionList;
	while (instruction)
	{
		instruction->Flags &= (~IMMMEDIATE_COMPLETED);
		instruction = instruction->Next;
	}
	}

	// Empty the data stack (ie, returned results from functions/scripts)
	{
	register SCRIPTVARIANT	*var;

	while ((var = interpreter->DataStack))
	{
		interpreter->DataStack = var->Next;
		freeScriptVariant(var);
	}
	}
}





/******************* gotoLastInstruction() ******************
 * Returns the last CINSTRUCTION in the list.
 */

CINSTRUCTION * gotoLastInstruction(CINSTRUCTION *instruction)
{
	if (instruction)
	{
		while (instruction->Next) instruction = instruction->Next;
	}

	return(instruction);
}





/*********************** createInstructionList() *********************
 * Parses the text in scriptText into a list of CINSTRUCTIONs for
 * the interpreter to "run".
 *
 * scriptText =		The script to be parsed, in textual form.
 * startLineNum =	The line number the script starts on.
 * context =		Host-defined value used for debugging.
 */

HRESULT createInstructionList(CINTERPRETER *interpreter, LPCOLESTR scriptText, ULONG startLineNum, DWORD context)
{
	register CPARSER	*parser;
	
	LOGFUNC("createInstructionList");

	// Create a new CPARSER/CLEXER to use on this script
	if (!(parser = (CPARSER *)ALLOCMEM(sizeof(CPARSER))))
badmem:	context = E_OUTOFMEMORY;
	else
	{
		ZeroMemory(parser, sizeof(CPARSER));
		parser->Lexer.CurrentPtr = scriptText;
		parser->Lexer.TextPosition.LineNum = startLineNum;
		parser->Lexer.TextPosition.CharOnLine = 1;
		parser->Lexer.Context = context;
		parser->Lexer.ActiveScript = interpreter->Parent;
		parser->Interpreter = interpreter;

		if (!(parser->Lexer.TokenBuffer = (WCHAR *)ALLOCMEM((parser->Lexer.TokenBufferSize = 256)))) goto badmem;

		// Get the first token
		if (!(context = lexerGetNextToken(&parser->Lexer)))
		{
			// Create an OPCODE_CONTEXT CINSTRUCTION that holds the context for
			// all the instructions we're about to create
			if (!(parser->InstructionList = parser->CurrentInstruction = addInstruction(parser, OPCODE_CONTEXT, DO_NOT_ADD, sizeof(DWORD), 0))) goto badmem;
			*((DWORD *) ((unsigned char *)parser->CurrentInstruction + sizeof(CINSTRUCTION)) ) = parser->Lexer.Context;

			// Indicate whether we need extra debugging info per each CINSTRUCTION
			if (interpreter->Parent->HostDebugApplication) parser->Flags = CPARSER_DEBUG;

			// Parse the script text, adding CINSTRUCTIONs to our list
			if (interpreter->Flags & FLAG_EXPRESSIONENGINE)
				context = format_expr(parser, 1);
			else if (interpreter->Flags & FLAG_PARSEASFUNCTION)
				context = parseFunction(parser);
			else
				context = startScriptParsing(parser);

			// If all went well, transfer the CINSTRUCTIONs to CINTERPRETER's list
			if (!context && parser->InstructionList->Next)
			{
				// If the new OPCODE_CONTEXT is the same as the first OPCODE_CONTEXT,
				// then we don't need a duplicate
				if (interpreter->InstructionList &&
					*((DWORD *)((unsigned char *)interpreter->InstructionList + sizeof(CINSTRUCTION))) == parser->Lexer.Context)
				{
					parser->CurrentInstruction->Next = interpreter->InstructionList->Next;
					freeCInstruction(interpreter->InstructionList);
				}
				else
					parser->CurrentInstruction->Next = interpreter->InstructionList;
	
				/* interpreter->CurrentInstruction = */ interpreter->InstructionList = parser->InstructionList;
			}
			else
				freeInstructionList(parser->InstructionList);

			// Free any remaining crap in the parser
			freeTStack(&parser->LabelStack, free_block);
			freeTStack(&parser->ContinueStack, free_block);
		}
	}

	// We're done with the parser, so delete it
	if (parser)
	{
		if (parser->Lexer.TokenBuffer) FREEMEM(parser->Lexer.TokenBuffer);
		FREEMEM(parser);
	}

	LOGHEXPARAM("Returns", context);
	UNLOGFUNC();
	return(context);
}
