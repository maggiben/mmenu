// Contains our ERRORHANDLER functions, which wrap an
// IActiveScriptError (to report script errors to the host).

#include <windows.h>
#include <tchar.h>
#include <stddef.h>
#include <objbase.h>
#include <activscp.h>
#include <activdbg.h>
#include "../TraceWin.h"
#include "../IClassFactory.h"
#include "../Guids.h"
#include "../English/Resource.h"
#include "../Active Engine/ActiveScript.h"
#include "../Interpreter/CLexer.h"
#include "../Interpreter/CInstruction.h"




// The HINSTANCE of the resource-only dll that contains the language-specific
// error messages
static HINSTANCE	ResourceHInst;

// Wraps an IActiveScriptError or IActiveScriptErrorDebug
#pragma pack(1)
typedef struct {
	const void				*lpVtbl;			// IActiveScriptError/IActiveScriptErrorDebug. Must be first!!!
	ULONG					RefCount;
	CINSTRUCTION			*ErrorInstruction;	// CINSTRUCTION where the error occurred
	DWORD					Context;			// App-supplied debugger value.
	CINTERPRETER			*Interpreter;		// CINTERPRETER where the error occurred.
	unsigned short			ErrMsgNum;			// One of our error numbers from Resource.h that indicates what string to load from the error DLL's stringtable
} ERRORHANDLER;
#pragma pack()

// IActiveScriptError VTable
static STDMETHODIMP QueryInterface(ERRORHANDLER *, REFIID, void **);
static STDMETHODIMP_(ULONG) AddRef(ERRORHANDLER *);
static STDMETHODIMP_(ULONG) Release(ERRORHANDLER *);
static STDMETHODIMP GetSourcePosition(ERRORHANDLER *, DWORD *, ULONG *, LONG *);
static STDMETHODIMP GetExceptionInfo(ERRORHANDLER *, EXCEPINFO *);
static STDMETHODIMP GetSourceLineText(ERRORHANDLER *, BSTR *);

static const IActiveScriptErrorVtbl IActiveScriptError_Vtbl = {QueryInterface,
AddRef,
Release,
GetExceptionInfo,
GetSourcePosition,
GetSourceLineText};

// IActiveScriptErrorDebug VTable. NOTE: This VTable contains the
// IActiveScriptError functions too
static STDMETHODIMP Debug_GetDocumentContext(ERRORHANDLER *, IDebugDocumentContext **); 
static STDMETHODIMP Debug_GetStackFrame(ERRORHANDLER *, IDebugStackFrame **); 

static const IActiveScriptErrorDebugVtbl IActiveScriptErrorDebug_Vtbl = {QueryInterface,
AddRef,
Release,
GetExceptionInfo,
GetSourcePosition,
GetSourceLineText,
Debug_GetDocumentContext,
Debug_GetStackFrame};

#ifdef LOGTRACE
static unsigned char LogFlag2 = 0;
#endif

static const TCHAR	NumFormat[] = _T("%04X");
static const TCHAR	LangDLLRoot[] = _T("CMinus");




/************************* errorFreeMsgLib() **************************
 * Frees the DLL containing error messages.
 */

void errorFreeMsgLib(void)
{
	if (ResourceHInst) FreeLibrary(ResourceHInst);
}





/************************* errorInitMsgLib() **************************
 * Initializes the error message variables. Called when the DLL
 * first loads.
 */

void errorInitMsgLib(void)
{
	ResourceHInst = 0;
}





/************************ errorSetLocale() ***************************
 * Sets, or resets, the locale used for displaying error messages.
 * Must be called once (by host) before any errors are reported.
 */

void errorSetLocale(LCID newLCID)
{
	register DWORD	len;
	TCHAR			path[MAX_PATH];

	// Make sure that any previous resource dll is freed
	errorFreeMsgLib();

	// Get this DLL's file name. This gives us the path to where our DLL is
	GetModuleFileName(DllHandle, &path[0], MAX_PATH);

	// Remove the Dll name
	len = lstrlen(&path[0]);
	while (len && path[len - 1] != '\\') --len;

	if (newLCID == LOCALE_USER_DEFAULT)
		newLCID = GetUserDefaultLCID();

	// Append CMinusXXX.dll where XXX is the language ID (ie, 0x409 for
	// english)
	lstrcpy(&path[len], &LangDLLRoot[0]);
	len += lstrlen(&path[len]);
	wsprintf(&path[len], &NumFormat[0], newLCID);

	if (!(ResourceHInst = LoadLibrary(&path[0])))
	{
		wsprintf(&path[len], &NumFormat[0], 0x409);

		if (!(ResourceHInst = LoadLibrary(&path[0])))
		{
			register LPTSTR		ptr;

			FormatMessage(FORMAT_MESSAGE_FROM_SYSTEM, 0, GetLastError(), MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT), &path[0], MAX_PATH, 0);
			MessageBox(0, &path[0], &LangDllErrTitle[0], MB_OK);

			// Make sure that there aren't any EOL chars in it
			ptr = &path[0];
			while(*ptr)
			{
				if (*ptr < ' ') *ptr = ' ';
				ptr++;
			}
		}
	}
}





/*********************** allocErrorHandler() ************************
 * Allocates/Initializes a ERRORHANDLER (with its embedded
 * IActiveScriptError COM object).
 */

static ERRORHANDLER * allocErrorHandler(DWORD errMsgNum, DWORD extra)
{
	register ERRORHANDLER	*errorHandler;

	// Create a ERRORHANDLER (with its embedded IActiveScriptError or
	// IActiveScriptErrorDebug COM object) to deal with the error
	if ((errorHandler = (ERRORHANDLER *)ALLOCMEM(sizeof(ERRORHANDLER) + extra)))
	{
		ZeroMemory(errorHandler, sizeof(ERRORHANDLER) + extra);
		errorHandler->lpVtbl = &IActiveScriptError_Vtbl;
		errorHandler->ErrMsgNum = (unsigned short)errMsgNum;
	}

	return(errorHandler);
}





/******************** handleCompileError() ******************
 * Reports a compile-time error to the host. A compile-time
 * error is some error that happens while we're constructing
 * a CINTERPRETER's list of CINSTRUCTIONs, ie, during
 * createInstructionList().
 *
 * errMsgNum =	The stringtable ID number for the error message
 *				to display. See Resource.h in the language DLLs.
 */

void handleCompileError(CLEXER *lexer, DWORD errMsgNum)
{
	register DWORD			tokenSize;
	register ERRORHANDLER	*errorHandler;

	LOGFUNC("handleCompileError");

	tokenSize = 0;
	if (lexer->TokenBufferPtr) tokenSize = (unsigned char *)lexer->TokenBufferPtr - (unsigned char *)lexer->TokenBuffer;

	// Create a ERRORHANDLER (with its embedded IActiveScriptError
	// COM object) to deal with the error. Also embed a phony CINSTRUCTION,
	// and a CTOKEN
	if ((errorHandler = allocErrorHandler(errMsgNum, sizeof(CINSTRUCTION) + sizeof(CTOKEN) + tokenSize)))
	{
		register CTOKEN		*token;

		errorHandler->Context = lexer->Context;
//		errorHandler->Interpreter = ((CPARSER *)lexer)->interpreter;

		token = (CTOKEN *)((unsigned char *)errorHandler + sizeof(ERRORHANDLER));
		errorHandler->ErrorInstruction = (CINSTRUCTION *)((unsigned char *)token + sizeof(CTOKEN));
		token->CharOffset = lexer->TokenCharOffset;
		token->Type = lexer->TokenType;
		if (tokenSize)
		{
			lstrcpyW((WCHAR *)((unsigned char *)errorHandler->ErrorInstruction + sizeof(CINSTRUCTION)), lexer->TokenBuffer);
			token->Type = (unsigned char)TOKEN_ERROR;
		}

		errorHandler->ErrorInstruction->OpCode = lexer->TokenType;
		CopyMemory(&errorHandler->ErrorInstruction->TextPosition, &lexer->TokenPosition, sizeof(TEXTPOS));

		// Since this CINSTRUCTION is part of the ERRORHANDLER, mark
		// it INUSE_BY_ERRORHANDLER so Release() doesn't try to free it
		// separately
		errorHandler->ErrorInstruction->Flags = INUSE_BY_ERRORHANDLER|IS_DEBUG_INSTRUCTION;

		// AddRef it for the host
#ifdef LOGTRACE
		LogFlag2 = 1;
#endif
		AddRef(errorHandler);

		// Call host's IActiveScriptSite::OnScriptError, handing it our IActiveScriptError
		((ACTIVESCRIPT *)lexer->ActiveScript)->HostScriptSite->lpVtbl->OnScriptError(((ACTIVESCRIPT *)lexer->ActiveScript)->HostScriptSite, (IActiveScriptError *)errorHandler);
	}
	else
		UNLOGFUNC();
}





/********************** handleRuntimeError() ********************
 * Reports a run-time error to the host. A run-time error is
 * some error that happens while we're executing/interpreting
 * a CINTERPRETER's list of CINSTRUCTIONs, ie, during
 * evalInstruction().
 *
 * instruction =	The CINSTRUCTION where the run-time error occurred.
 * errMsgNum =		The stringtable ID number for the error message
 *					to display. See Resource.h in the language DLLs.
 * interpreter =	The interpreter in which the runtime error occurred.
 */

void handleRuntimeError(CINSTRUCTION *instruction, DWORD errMsgNum, CINTERPRETER *interpreter)
{
	register ACTIVESCRIPT	*iactive;
	register ERRORHANDLER	*errorHandler;

	iactive = interpreter->Parent;

	LOGFUNC("handleRuntimeError");

	// Create a ERRORHANDLER (with its embedded IActiveScriptError
	// COM object) to deal with the error
	if ((errorHandler = allocErrorHandler(errMsgNum, 0)))
	{
		// We need to get the context from the instruction list
		{
		register CINSTRUCTION	*list;
		register DWORD			context;

		context = 0;
		list = interpreter->InstructionList;
		while (list)
		{
			if (list->OpCode == OPCODE_CONTEXT)
				context = *((DWORD *)((unsigned char *)instruction + sizeof(CINSTRUCTION)));

			if (instruction == list) break;

			list = list->Next;
		}
		errorHandler->Context = context;
		}

		{
		BREAKRESUMEACTION	breakAction;
		ERRORRESUMEACTION	resumeAction;
		BOOL				callFlag;

		errorHandler->ErrorInstruction = instruction;

		// Are we a debugging engine? If so, change to using the IActiveScriptErrorDebug VTable
		if (!iactive->HostDebugApplication) goto dohost;
		errorHandler->lpVtbl = &IActiveScriptErrorDebug_Vtbl;
		errorHandler->Interpreter = interpreter;

		// Report the error to the IDebugApplication
		if (!iactive->HostDebugApplication->lpVtbl->HandleRuntimeError(iactive->HostDebugApplication, (IActiveScriptErrorDebug *)errorHandler, iactive->HostScriptSite, &breakAction, &resumeAction, &callFlag))
		{
			// Set the interpreter's BreakResumeAction to what HandleRuntimeError() wants
			interpreter->Parent->BreakResumeAction = (unsigned char)breakAction;

			// We don't handle the ERRORRESUMEACTION, but if we did, this is where
			// it would go.

			// Does the IDebugApplication want us to report the error to the host?
			if (callFlag)
			{
dohost:			// AddRef our IActiveScriptError for the host
#ifdef LOGTRACE
				LogFlag2 = 1;
#endif
				AddRef(errorHandler);

				// Indicate that this CINSTRUCTION is in use by the error handler, so
				// the owner should not free it. If the owner goes away, then it will
				// clear this flag and just abandon the CINSTRUCTION
				errorHandler->ErrorInstruction->Flags |= INUSE_BY_ERRORHANDLER;

				// Call host IActiveScriptSite's OnScriptError to report the error
				iactive->HostScriptSite->lpVtbl->OnScriptError(iactive->HostScriptSite, (IActiveScriptError *)errorHandler);

				return;
			}
		}
		}

		FREEMEM(errorHandler);
	}

	UNLOGFUNC();
}



















//=============================================================================
// The IActiveScriptError sub-object is given to the host to provide info
// about an error that has occurred in a running script engine.
//=============================================================================

/************************ QueryInterface() *************************
 */

static STDMETHODIMP QueryInterface(ERRORHANDLER *this, REFIID riid, void **ppvObj)
{
	LOGFUNC("IActiveScriptError::QueryInterface");

//	if (!IsBadWritePtr(ppvObj, sizeof(void *)))
//	{
		if (IsEqualIID(riid, &IID_IUnknown) || IsEqualIID(riid, &IID_IActiveScriptError) ||
			(IsEqualIID(riid, &IID_IActiveScriptErrorDebug) && this->lpVtbl == &IActiveScriptErrorDebug_Vtbl))
		{
			*ppvObj = this;
#ifdef LOGTRACE
			LogFlag2 = 1;
#endif
			AddRef(this);
			return(NOERROR);
		}

		*ppvObj = 0;
		LOGGUID("UNSUPPORTED: ", riid);
		UNLOGFUNC();
		return(E_NOINTERFACE);
//	}

	UNLOGFUNC();
	return(E_POINTER);
}

/*************************** AddRef() ****************************
 */

static STDMETHODIMP_(ULONG) AddRef(ERRORHANDLER *this)
{
#ifdef LOGTRACE
	ULONG	val;
#endif
	
	// One more outstanding object
	incOutstandingObjs();

#ifdef LOGTRACE
	if (!LogFlag2) LOGFUNC("IActiveScriptError::AddRef");
	val = ++this->RefCount;
	UNLOGFUNC();
	LogFlag2 = 0;
	return(val);
#else
	UNLOGFUNC();
	return(++this->RefCount);
#endif
}

/*************************** Release() **************************
 */

static STDMETHODIMP_(ULONG) Release(ERRORHANDLER *this)
{
	LOGFUNC("IActiveScriptError::Release");

	if (!IsBadWritePtr(this, sizeof(ERRORHANDLER)))
	{
		// One less outstanding object
		decOutstandingObjs();

		if ((--this->RefCount))
		{
			UNLOGFUNC();
			return(this->RefCount);
		}

		// See if the CINSTRUCTION is still owned by someone else. If the
		// INUSE_BY_ERRORHANDLER is still set, then the owner hasn't
		// abandoned it yet
		if (!(this->ErrorInstruction->Flags & INUSE_BY_ERRORHANDLER))
			freeCInstruction(this->ErrorInstruction);
		else
			this->ErrorInstruction->Flags &= ~INUSE_BY_ERRORHANDLER;

		// Free the ERRORHANDLER
		FREEMEM(this);
	}

	UNLOGFUNC();
	return(0);
}





/************************ GetExceptionInfo() ***************************
 * Fills in the host's EXCEPINFO struct with info about an error that
 * has occurred.
 *
 * pei =		 Where to return the EXCEPINFO info.
 */

static STDMETHODIMP GetExceptionInfo(ERRORHANDLER *this, EXCEPINFO *pei)
{
	wchar_t				buffer[256];
	register HRESULT	hr;

	LOGFUNC("IActiveScriptError GetExceptionInfo");

//	if (!IsBadWritePtr(pei, sizeof(EXCEPINFO)))
//	{
		ZeroMemory(pei, sizeof(EXCEPINFO));

		// Load the description string (from our DLL resources) into buffer
		buffer[0] = 0;
		LoadStringW(ResourceHInst, this->ErrMsgNum, buffer, sizeof(buffer));

		pei->bstrDescription = SysAllocString(&buffer[0]);
		pei->bstrSource = SysAllocString(&FullEngineLanguageStr[0]);
		pei->scode = E_FAIL;

		hr = S_OK;
//	}
//	else
//		hr = E_POINTER;

	LOGHEXPARAM("Returns", hr);
	UNLOGFUNC();
	return(hr);
}






/********************** getSourceTokenText() ***********************
 * Gets the C source text from which a given token was parsed.
 *
 * token =		The CTOKEN for this token, or 0 if not available.
 * instruction = The CINSTRUCTION for this token.
 *
 * RETURNS: A nul-terminated WCHAR string with the source text.
 *
 * NOTE: Caller may not alter the returned string, nor free it. It
 * is borrowed from the CTOKEN/CINSTRUCTION.
 *
 * The returned text may be a nul string if the token has no
 * particular text.
 */

const WCHAR * getSourceTokenText(CTOKEN *token, CINSTRUCTION *instruction)
{
	register const WCHAR			*keywords;
	register const unsigned char	*tokens;

	if (token)
	{
		// The token text may have been appended to the CINSTRUCTION. If
		// so, the type was set to TOKEN_ERROR
		if (token->Type == (unsigned char)TOKEN_ERROR) goto gotit2;

		// If a standard C keyword token, then we get the text
		// from Keywords[]
		tokens = &KeywordTokens[0];
		keywords = &Keywords[0];
		do
		{
			if (*tokens == token->Type) goto gotit;
			keywords += (*keywords + 2);
			++tokens;
		} while (*keywords != (WCHAR)-1);
	}

	// Otherwise, we need to get the text from the CINSTRUCTION
	switch (instruction->OpCode)
	{
		case OPCODE_LOAD:
		case OPCODE_FIELD:
		case OPCODE_FUNCENTRY:
		{
gotit2:		keywords = (const WCHAR *)((unsigned char *)instruction + sizeof(CINSTRUCTION));
			goto gotit;
		}

		case OPCODE_CONSTSTR:
		case OPCODE_CALL:
		{
			keywords = (const WCHAR *)((unsigned char *)instruction + sizeof(CINSTRUCTION) + sizeof(void *));
			goto gotit;
		}

		case OPCODE_DATA:
		case OPCODE_PARAM:
		{
			register CSYMBOL	*symbol;

			symbol = (CSYMBOL *)((unsigned char *)instruction + sizeof(CINSTRUCTION));
			keywords = (const WCHAR *)symbol->Name;
			goto gotit;
		}

		case OPCODE_SAVE:
		{
			keywords = *((const WCHAR **)((unsigned char *)instruction + sizeof(CINSTRUCTION)));
			goto gotit;
		}
	}

	// Return a nul string
	keywords = &GlobalTableName[6];
gotit:
	return(keywords);
}





/********************** GetSourceLineText() **********************
 * Allocates/returns a BSTR with the script sourceline that caused
 * the error.
 *
 * srcLine =	Where to return a BSTR of the sourceline.
 *
 * NOTE: Host must SysFreeString() the returned BSTR.
 */

static STDMETHODIMP GetSourceLineText(ERRORHANDLER *this, BSTR *srcLine)
{
	register unsigned char	*token;
	register HRESULT		hr;

	LOGFUNC("IActiveScriptError GetSourceLineText");

	token = (unsigned char *)this->ErrorInstruction;

	// See if we have a CTOKEN to draw information from. If so, then we have a CTOKEN which
	// will contain the source text. Otherwise, we'll have to try to glean the source text
	// from the CINSTRUCTION (which may not always produce the text)
	if (((CINSTRUCTION *)token)->Flags & IS_DEBUG_INSTRUCTION)
	{
		if (((CINSTRUCTION *)token)->Flags & INSTRUCTION_HAS_LABEL) token -= sizeof(LPOLESTR *);
		token -= sizeof(CTOKEN);
	}
	else
		token = 0;

	hr = E_FAIL;
	if ((*srcLine = SysAllocString(getSourceTokenText((CTOKEN *)token, this->ErrorInstruction)))) hr = S_OK;

	LOGHEXPARAM("Returns", hr);
	UNLOGFUNC();
	return(hr);
}





/************************** GetSourcePosition() *************************
 * Retrieves information on the source context, line number, and
 * character position of the error.
 *
 * context =	Where to return the source context of the error.
 * lineNum =	Where to return the line number of the error.
 * charPos =	Where to return the character position of the error.
 */

static STDMETHODIMP GetSourcePosition(ERRORHANDLER *this, DWORD *context, ULONG *lineNum, LONG *charPos)
{
	LOGFUNC("IActiveScriptError GetSourcePosition");

	if (context) *context = this->Context;
	if (lineNum) *lineNum = this->ErrorInstruction->TextPosition.LineNum;
	if (charPos) *charPos = (long)this->ErrorInstruction->TextPosition.CharOnLine;

	UNLOGFUNC();
	return(S_OK);
}























//=============================================================================
// The IActiveScriptErrorDebug provides context information for errors that
// occur during script execution.
//=============================================================================

/********************** GetDocumentContext() **********************
 * Retrieves our IDebugCodeContext for the associated error. The
 * character-position range should include the entire offending text.
 *
 * pObj =	Where to return the IDebugDocumentContext.
 */

static STDMETHODIMP Debug_GetDocumentContext(ERRORHANDLER *this, IDebugDocumentContext **pObj)
{
	register HRESULT					hr;
	register IActiveScriptSiteDebug		*debugSite;

	// Delegate this call to the host IActiveScriptSiteDebug's GetDocumentContextFromPosition()
	hr = E_NOTIMPL;

	if ((debugSite = this->Interpreter->Parent->HostScriptSiteDebug))
	{
		register unsigned char	*token;

		hr = E_UNEXPECTED;

		token = (unsigned char *)this->ErrorInstruction;

		// Make sure we have a CTOKEN to draw information from
//		if (((CINSTRUCTION *)token)->Flags & IS_DEBUG_INSTRUCTION)
//		{
			if (((CINSTRUCTION *)token)->Flags & INSTRUCTION_HAS_LABEL) token -= sizeof(LPOLESTR *);
			token -= sizeof(CTOKEN);

			// Our host is a smart host, so we can use its IActiveScriptSiteDebug's
			// GetDocumentContextFromPosition to retrieve the IDebugDocumentContext
			hr = debugSite->lpVtbl->GetDocumentContextFromPosition(debugSite, this->Context, ((CTOKEN *)token)->CharOffset, lstrlenW(getSourceTokenText((CTOKEN *)token, this->ErrorInstruction)), pObj);
//		}
	}

	return(hr);
}





/************************* GetStackFrame() ************************
 * For runtime errors, retrieves the stack frame (IDebugStackFrame)
 * that is in effect when the error occurs.
 *
 * pObj =	Where to return the IDebugStackFrame.
 */

STDMETHODIMP Debug_GetStackFrame(ERRORHANDLER *this, IDebugStackFrame **pObj)
{
	register TSTACK		*ptr;
	register HRESULT	hr;	

	LOGFUNC("IActiveScriptErrorDebug::GetStackFrame");
	UNLOGFUNC();

	hr = E_FAIL;
	*pObj = 0;

	if ((ptr = this->Interpreter->Parent->StackFrames))
	{
		register DEBUGSTACKFRAMEDESCRIPTOR	*frame;

		frame = (DEBUGSTACKFRAMEDESCRIPTOR *)ptr->Value;

		if (this->ErrorInstruction == frame->Instruction)
		{
			frame->DebugStackFrame->AddRef((IDebugStackFrame *)frame);
			*pObj = (IDebugStackFrame *)frame;
			hr = S_OK;
		}
	}

	return(hr);
}
