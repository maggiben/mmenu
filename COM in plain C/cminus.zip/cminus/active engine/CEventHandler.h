#ifndef EVENTHANDLER_H
#define EVENTHANDLER_H

#include "ActiveScript.h"
#include "CInterpreter.h"

// We have one CEVENT for each callback function in a given
// callback IDispatch
#pragma pack(1)
typedef struct {
	void			*Ptr;			// Points to OLECHAR name of function if not yet resolved. If resolved,
									// the DISPID our CINTERPRETER uses for this function.
	DISPID			HostDispid;		// Host's DISPID for this function.
	unsigned char	Found;			// 1 if resolved, so 0 if not.
} CEVENT;
#pragma pack()

// For CEVENTHANDLER flags
#define HANDLER_ISCONNECTED		0x01
#define HANDLER_ISINITIALIZED	0x02
#define HANDLER_PSEUDOCONNECT	0x04

// We have one CEVENTHANDLER for each callback IDispatch that
// the host tells us to give it (when it adds an ISSOURCE
// script object via our IActiveScript's AddNamedItem)
#pragma pack(1)
typedef struct _CEVENTHANDLER {
	void					*lpVtbl;			// The embedded callback IDispatch. It must be first
	struct _CEVENTHANDLER	*Next;				// For linking into a list.
	CEVENT					*Events;			// Pointer to an array of CEVENTs.
	IDispatch				*HostIDispatch;		// Host's IDispatch we use to get the IConnectionPoint and ITypeInfo.
	struct _CINTERPRETER	*EngineIDispatch;	// Our CINTERPRETER's IDispatch we use to call script functions.
	IConnectionPoint		*ConnectionPoint;	// Host's IConnectionPoint.
	DWORD					Cookie;				// Host's IConnectionPoint Advise() cookie.
	GUID					Guid;				// GUID for the IConnectionPoint.
	ULONG					RefCount;			// Reference count.
	unsigned short			NumEvents;			// Number of CEVENTs in events[] array
	unsigned short			Flags;				// Various bits. See above.
} CEVENTHANDLER;
#pragma pack()

CEVENTHANDLER * allocCEventHandler(struct _CINTERPRETER *);
void			releaseCEventHandler(CEVENTHANDLER *);
void			aliasEvent(CEVENTHANDLER *, LPCOLESTR, LPCOLESTR *);
HRESULT			connectCallbacks(CEVENTHANDLER *);
HRESULT			disconnectCallbacks(CEVENTHANDLER *);
void			resetCEventHandler(CEVENTHANDLER *);
HRESULT			initCEventHandler(CEVENTHANDLER *, IDispatch *);
CEVENTHANDLER *	findEventObject(struct _ACTIVESCRIPT *, struct _CINTERPRETER *);

#endif // EVENTHANDLER_H