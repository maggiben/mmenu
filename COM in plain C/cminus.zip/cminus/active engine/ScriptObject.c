// Functions for our SCRIPTOBJECT, which helps us keep track of
// object names added to our namespace (when the host calls our
// IActiveScript's AddNamedItem) and their respective IDispatch's
// that we obtain by calling the host IActiveScriptSite's GetItemInfo().

#include <windows.h>
#include <objbase.h>
#include <activscp.h>
#include "../TraceWin.h"
#include "ScriptObject.h"





/********************** allocScriptObject() *********************
 * Allocates and initializes a SCRIPTOBJECT.
 *
 * objName =	The script object name passed to AddNamedItem.
 * flags =		Flags passed to AddNamedItem().
 *
 * RETURNS: The new SCRIPTOBJECT is success, or 0 if a
 * memory failure.
 */

SCRIPTOBJECT * allocScriptObject(LPCOLESTR objName, DWORD flags)
{
	register DWORD			temp;
	register SCRIPTOBJECT	*obj;

	LOGFUNC("allocScriptObject");

	temp = lstrlenW(objName);

	// Allocate the SCRIPTOBJECT and room for its script object name (nul-terminated)
	if ((obj = (SCRIPTOBJECT *)ALLOCMEM(sizeof(SCRIPTOBJECT) + (temp * sizeof(OLECHAR)))))
	{
		// Copy the object name
		lstrcpyW(&obj->ObjName[0], objName);

		// Store the flags
		obj->Flags = flags;

		// We haven't yet gotten the host IDispath
		obj->HostIDispatch = 0;
	}

	UNLOGFUNC();

	return(obj);
}





/********************** findScriptObject() *********************
 * Searches for a SCRIPTOBJECT by name.
 *
 * objName =	The script object name passed to AddNamedItem.
 *
 * RETURNS: The new SCRIPTOBJECT is success, or 0 if a
 * memory failure.
 */

SCRIPTOBJECT * findScriptObject(struct _ACTIVESCRIPT *this, LPCOLESTR objName)
{
	register SCRIPTOBJECT	*obj;

	if ((obj = this->ScriptObjectList))
	{
		do
		{
			if (!lstrcmpW(&obj->ObjName[0], objName)) break;
		} while ((obj = obj->Next));
	}

	return(obj);
}





/********************* releaseHostIDispatch() **********************
 * Releases the IDispatch for this script object. This is used
 * when transitioning into the SCRIPTSTATE_UNINITIALIZED state.
 */

void releaseHostIDispatch(SCRIPTOBJECT *obj)
{
	LOGFUNC("releaseHostIDispatch");

	if (obj->HostIDispatch)
	{
		obj->HostIDispatch->lpVtbl->Release(obj->HostIDispatch);
		obj->HostIDispatch = 0;
	}

	UNLOGFUNC();
}





/********************* freeScriptObject() *********************
 * Frees a SCRIPTOBJECT and its resources.
 */

void freeScriptObject(SCRIPTOBJECT *obj)
{
	LOGFUNC("freeScriptObject");

	if (obj->HostIDispatch) obj->HostIDispatch->lpVtbl->Release(obj->HostIDispatch);
	FREEMEM(obj);

	UNLOGFUNC();
}





/************************ getHostIDispatch() ***********************
 * Retrieves the host's IDispatch for this script object.
 *
 * pObj =		Where to return the IDispatch pointer.
 * scriptSite =	Host's IActiveScriptSite object.
 *
 * NOTE: The IDispatch is AddRef'ed, so caller must Release() when done.
 */

HRESULT getHostIDispatch(SCRIPTOBJECT *obj, IDispatch **pObj, IActiveScriptSite * scriptSite)
{
	register HRESULT		hr;
	IUnknown				*unknown;

	LOGFUNC("getHostIDispatch");

	hr = S_OK;

	// If we haven't gotten the host IDispatch yet, get it now
	if (!obj->HostIDispatch &&

		// Get the object's IUnknown
		!(hr = scriptSite->lpVtbl->GetItemInfo(scriptSite, &obj->ObjName[0], SCRIPTINFO_IUNKNOWN, &unknown, 0)))
	{
		// Get the IDispatch
		hr = unknown->lpVtbl->QueryInterface(unknown, &IID_IDispatch, (void **)&obj->HostIDispatch);

		// We don't need the IUnknown now that we have the IDispatch
		unknown->lpVtbl->Release(unknown);
	}

	*pObj = obj->HostIDispatch;

	// AddRef() the IDispatch for the caller
	if (!hr) obj->HostIDispatch->lpVtbl->AddRef(obj->HostIDispatch);

	LOGHEXPARAM("Returns", hr);
	UNLOGFUNC();

	return(hr);
}
