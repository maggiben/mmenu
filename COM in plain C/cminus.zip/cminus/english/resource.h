//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by English.rc
//
#define PARSER_OUTOFMEMORY				1
#define PARSER_EXTERNAL_DECL            2
#define PARSER_DECL_SPEC                3
#define PARSER_DECL                     4
#define PARSER_FUNCDECL                 5
#define PARSER_STMT_LIST                6
#define PARSER_NOTALLOWED               7
#define PARSER_STMT                     8
#define PARSER_NEEDSTMT					9
#define PARSER_MISSINGELSE				10
#define PARSER_DEFER_EXPR_STMT          11
#define PARSER_OPT_EXPR                 12
#define PARSER_EXPR                     13
#define PARSER_ASSIGNMENT_EXPR          14
#define MISSING_QUOTE					15
#define PARSER_VARNAME					16
#define PARSER_MISSINGLCURLY			17
#define MISSING_LOOPINIT				18
#define	PARSER_MISSINGLPAREN			19
#define PARSER_MISSINGRPAREN			20
#define PARSER_MISSINGRCURLY			21
#define PARSER_MISSINGWHILE				22
#define PARSER_MISSINGSEMI				23
#define PARSER_MISSINGLOOPTEST			24
#define PARSER_BADOBJNAME				25
#define WRONG_ARGTYPE					26
#define FUNC_NOT_FOUND					27
#define LABEL_MISSING					28
#define WRONG_ARGCOUNT					29
#define EMPTY_EXPRESSION				30
#define INVALID_TOKEN             31
#define VAR_NOT_INITIALIZED				32
#define PARSER_ARG_EXPR_LIST            33
#define PARSER_BADARGLIST				34
#define PARSER_PRIMARY_EXPR             35
#define PARSER_CONSTANT                 36
#define UNRECOGNIZED_CHARACTER          37
#define INVALID_REFERENCE               38
#define OBJECT_REQUIRED                 39
#define INVALID_METHOD                  40
#define INVALID_INSTRUCTION             41
#define STACK_FAILURE                   42

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        43
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           43
#endif
#endif
