/*
 * This file contains no real code because English.dll is a resource-only DLL
 * that contains only the message strings for english error messages in
 * the sample script engine.
 */

#include <windows.h>

BOOL WINAPI _DllMainCRTStartup(HANDLE hinstDLL, DWORD fdwReason, LPVOID lpvReserved)
{
	return(1);
}