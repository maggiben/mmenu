#ifndef _MEM_H_
#define _MEM_H_

#ifndef _DEBUG
#define ALLOCMEM(size) GlobalAlloc(GMEM_FIXED, size)
#define FREEMEM(ptr) GlobalFree(ptr)
#else
extern void * AllocMem(DWORD);
extern void FreeMem(void *);
#define ALLOCMEM(size) AllocMem(size)
#define FREEMEM(ptr) FreeMem(ptr)
#endif

#endif