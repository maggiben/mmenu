#ifdef _DEBUG

#include <windows.h>

typedef struct MEMBLOCK {
	struct MEMBLOCK		*Next;
	DWORD				Size;
};

struct MEMBLOCK	*MemBlocks = 0;

void * AllocMem(DWORD size)
{
	register struct MEMBLOCK *ptr;

	if ((ptr = (struct MEMBLOCK *)GlobalAlloc(GMEM_FIXED, size + sizeof(struct MEMBLOCK) + 4)))
	{
		ptr->Next = MemBlocks;
		MemBlocks = ptr;
		ptr->Size = size;
		*((DWORD *)((unsigned char *)ptr + sizeof(struct MEMBLOCK) + size)) = 0xFFFEFDFC;
		return((unsigned char *)ptr + sizeof(struct MEMBLOCK));
	}

	return(0);
}

void FreeMem(void *mem)
{
	register struct MEMBLOCK *ptr;

	ptr = (struct MEMBLOCK *)((unsigned char *)mem - sizeof(struct MEMBLOCK));
	if (!IsBadWritePtr(ptr, sizeof(struct MEMBLOCK)))
	{	
		if (!IsBadWritePtr((unsigned char *)mem, ptr->Size + 4))
		{
			if (*((DWORD *)((unsigned char *)mem + ptr->Size)) == 0xFFFEFDFC)
			{
				register struct MEMBLOCK *prev;

				prev = (struct MEMBLOCK *)&MemBlocks;
				while ((ptr = prev->Next))
				{
					if ((struct MEMBLOCK *)((unsigned char *)mem - sizeof(struct MEMBLOCK)) == ptr)
					{
						prev->Next = ptr->Next;
						GlobalFree(ptr);
						return;
					}

					prev = ptr;
				}
			}
		}
	}

	ptr = 0;
	return;
}

#endif