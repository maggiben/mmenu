#ifndef TRACEWIN_H
#define TRACEWIN_H

#ifdef __cplusplus
extern "C" {
#endif

#ifdef LOGTRACE
extern HWND	TraceWindow;
extern void traceOpenWindow(HWND);
extern void traceCloseWindow(void);
extern void traceEnterFunc(LPCTSTR);
extern void traceShowArgs(LPCTSTR, DWORD, VARIANT *);
extern void traceShowState(DWORD, DWORD);
extern void traceShowInt(LPCTSTR, DWORD);
extern void traceShowHex(LPCTSTR, DWORD);
extern void traceShowStr(LPCTSTR, LPCOLESTR);
extern void traceShowWStr(LPCOLESTR, DWORD);
extern void traceLeaveFunc(void);
extern void traceShowGUID(LPCTSTR, const GUID *);
extern void traceMsgHandler(void);

#define LOGOPEN(a) traceOpenWindow(a)
#define LOGCLOSE() traceCloseWindow()
#define LOGHANDLER() traceMsgHandler()
#define LOGOLESTRPARAM(a, b) traceShowStr(a, b)
#define LOGFUNC(a) traceEnterFunc(a)
#define UNLOGFUNC()  traceLeaveFunc()
#define LOGSTATEPARAM(a, b) traceShowState(a, b)
#define LOGINTPARAM(a, b) traceShowInt(a, b)
#define LOGHEXPARAM(a, b) traceShowHex(a, b)
#define LOGARGSPARAM(a, b, c) traceShowArgs(a, b, c)
#define LOGGUID(a, b) traceShowGUID(a, b)
#else
#define LOGOPEN(a)
#define LOGCLOSE()
#define LOGHANDLER()
#define LOGOLESTRPARAM(a, b)
#define LOGFUNC(a)
#define UNLOGFUNC()
#define LOGSTATEPARAM(a, b)
#define LOGINTPARAM(a, b)
#define LOGHEXPARAM(a, b)
#define LOGARGSPARAM(a, b, c)
#define LOGGUID(a, b)
#endif

#ifdef __cplusplus
}
#endif

#endif