// Registers our TScript.DLL as an ActiveX Script Engine.

#define INITGUID
#include <windows.h>
#include <tchar.h>
#include <objbase.h>
#include <guiddef.h>
#include <activscp.h>
#include <comcat.h>
#include "../Guids.c"

// Set this to the desired language name used in the HTML tag, for example VBscript
static const TCHAR		LanguageName[] = "CMinus";

// Set this to a description of the engine
static const TCHAR		Description[] = "CMinus Language";

// Set this to an alternate language name, if you hav one
#ifdef GOT_LANGALTERNATENAME
static const TCHAR		AltLanguageName[] = "CMinus2";
#endif

// Set this to an extension associated with the engine, if you have one, such as vbs
#ifdef GOT_EXTENSION
static const TCHAR		ExtensionStr[] = "xxx";
#endif

static const TCHAR Success[] = _T("CMinus.dll unregistered as an ActiveX script engine.");

// Do not change these strings
static const TCHAR		OleScriptStr[] = "OLEScript";
static const TCHAR		CLSIDStr[] = "CLSID";
static const TCHAR		ProgIDStr[] = "ProgID";
static const TCHAR		GUID_Format[] = _T("{%08lX-%04X-%04X-%02X%02X-%02X%02X%02X%02X%02X%02X}");
static const TCHAR		ServerKeyName[] = "InprocServer32";

// For File Dialog
static const TCHAR		FileDlgExt[] = _T("DLL files\000*.dll\000\000");
static const TCHAR		OurDllName[] = _T("CMinus.dll");
static const TCHAR		FileDlgTitle[] = _T("Locate CMinus.dll to unregister it");






/************************ stringFromCLSID() ***********************
 * Converts an object's GUID (array) to an ascii string (in a special
 * format where there are groups of ascii digits separated by a dash).
 * NOTE: Using wsprintf() avoids needing to load ole32.dll just to
 * call StringFromCLSID(). We're just doing the same thing it would do.
 */

static void stringFromCLSID(LPTSTR buffer, REFCLSID ri)
{
	wsprintf(buffer, &GUID_Format[0],
		((REFCLSID)ri)->Data1, ((REFCLSID)ri)->Data2, ((REFCLSID)ri)->Data3, ((REFCLSID)ri)->Data4[0],
		((REFCLSID)ri)->Data4[1], ((REFCLSID)ri)->Data4[2], ((REFCLSID)ri)->Data4[3],
		((REFCLSID)ri)->Data4[4], ((REFCLSID)ri)->Data4[5], ((REFCLSID)ri)->Data4[6],
		((REFCLSID)ri)->Data4[7]);
}





/************************** WinMain() ************************
 * Program Entry point
 */

int WINAPI WinMain(HINSTANCE hinstExe, HINSTANCE hinstPrev, LPSTR lpszCmdLine, int nCmdShow)
{
	HRESULT			hr;
	TCHAR			filename[MAX_PATH];

	{
	OPENFILENAME	ofn;

	// Pick out where our DLL is located. We need to know its location in
	// order to register it as a COM component
	lstrcpy(&filename[0], &OurDllName[0]);
	ZeroMemory(&ofn, sizeof(OPENFILENAME));
	ofn.lStructSize = sizeof(OPENFILENAME);
	ofn.lpstrFilter = &FileDlgExt[0];
	ofn.lpstrFile = &filename[0];
	ofn.nMaxFile = MAX_PATH;
	ofn.lpstrTitle = &FileDlgTitle[0];
	ofn.Flags = OFN_FILEMUSTEXIST|OFN_EXPLORER|OFN_PATHMUSTEXIST;
	hr = GetOpenFileName(&ofn);
	}

	if (hr)
	{
		CoInitialize(0);

		{
		ICatRegister	*pcr;

		if (!CoCreateInstance(&CLSID_StdComponentCategoriesMgr, 0, CLSCTX_ALL, &IID_ICatRegister, (void **)&pcr))
		{
			// Unregister this category as being "implemented" by the class
			CATID rgcatid[1];

			rgcatid[0] = CATID_ActiveScript;
			pcr->lpVtbl->UnRegisterClassImplCategories(pcr, &CLSID_CMinus, 1, rgcatid);

			rgcatid[0] = CATID_ActiveScriptParse;
			pcr->lpVtbl->UnRegisterClassImplCategories(pcr, &CLSID_CMinus, 1, rgcatid);

			pcr->lpVtbl->Release(pcr);
		}
		}

		{
		HKEY		hk;
		TCHAR		buffer[39];

		stringFromCLSID(&buffer[0], (REFCLSID)&CLSID_CMinus);

		// Delete HKEY_CLASSES_ROOT\{LanguageName}\*
		if (!RegOpenKey(HKEY_CLASSES_ROOT, &LanguageName[0], &hk))
		{
			// Delete HKEY_CLASSES_ROOT\{LanguageName}\CLSID
			RegDeleteKey(hk, &CLSIDStr[0]);

			// Delete HKEY_CLASSES_ROOT\{LanguageName}\OLEScript
			RegDeleteKey(hk, &OleScriptStr[0]);

			RegCloseKey(hk);

			// Delete HKEY_CLASSES_ROOT\{LanguageName}
			RegDeleteKey(HKEY_CLASSES_ROOT, &LanguageName[0]);
		}

		// Delete alternate language key
#ifdef GOT_LANGALTERNATENAME
		if (!RegOpenKey(HKEY_CLASSES_ROOT, &AltLanguageName[0], &hk))
		{
			RegDeleteKey(hk, &CLSIDStr[0]);
			RegDeleteKey(hk, &OleScriptStr[0]);
			RegCloseKey(hk);
			RegDeleteKey(HKEY_CLASSES_ROOT, &AltLanguageName[0]);
		}
#endif

		// Delete HKEY_CLASSES_ROOT\CLSID\{class GUID string}\*
 		if (!RegOpenKey(HKEY_CLASSES_ROOT, &CLSIDStr[0], &hk))
		{
			// Delete HKEY_CLASSES_ROOT\CLSID\{class GUID string}\progid
			RegDeleteKey(hk, &ProgIDStr[0]);

			// Delete HKEY_CLASSES_ROOT\CLSID\{class GUID string}\OLEScript
			RegDeleteKey(hk, &OleScriptStr[0]);

			// Delete HKEY_CLASSES_ROOT\CLSID\{class GUID string}
			RegDeleteKey(hk, &ServerKeyName[0]);
			RegCloseKey(hk);

			// Delete HKEY_CLASSES_ROOT\CLSID\{class GUID string}\*
			RegDeleteKey(hk, &buffer[0]);
		}
		}

#ifdef GOT_EXTENSION
		// Delete extension key
		RegDeleteKey(HKEY_CLASSES_ROOT, &ExtensionStr[0]);
#endif
		CoUninitialize();

		MessageBox(0, &Success[0], &Description[0], MB_OK|MB_ICONEXCLAMATION);
	}

	return(0);
}
