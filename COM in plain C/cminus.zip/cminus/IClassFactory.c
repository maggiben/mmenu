/*
 * Implementation of IClassFactory object for the script engine.
 */

#define INC_OLE2
#define CONST_VTABLE
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <activscp.h>
#include <activdbg.h>
#include "Guids.h"
#include "IClassFactory.h"
#include "Active Engine/ActiveScript.h"
#include "Active Engine/ErrorHandler.h"
#include "TraceWin.h"




// Handle to this DLL
HMODULE				DllHandle;

static DWORD		OutstandingObjects;
static DWORD		LockCount;

CRITICAL_SECTION	InterruptSection;

// Master list of ACTIVESCRIPT objects gotten by the host process using this DLL
struct _ACTIVESCRIPT *ActiveScriptList;









#if 0

// This N*3 array contains the keys, value names, and values that
// are associated with this dll in the registry.
static const char *g_RegTable[][3] = {
	//format is {key, value name, value}
	{"CScript", 0, "CScript"},
	{"CScript\\CLSID", 0, "{37633081-5D06-11d2-94A2-006008939020}"},
	{"CScript\\OLEScript", 0, ""},

	{"CScript.1", 0, "CScript.1"},
	{"CScript.1\\CLSID", 0, "{37633081-5D06-11d2-94A2-006008939020}"},
	{"CScript.1\\OLEScript", 0, ""},

	{"CLSID\\{37633081-5D06-11d2-94A2-006008939020}", 0, "CScript"},
	{"CLSID\\{37633081-5D06-11d2-94A2-006008939020}\\Implemented Categories\\{F0B7A1A1-9847-11CF-8F20-00805F2CD064}", 0, ""},
	{"CLSID\\{37633081-5D06-11d2-94A2-006008939020}\\Implemented Categories\\{F0B7A1A2-9847-11CF-8F20-00805F2CD064}", 0, ""},

	//CScript lives in a DLL, so register it as InprocServer32
	//Server path is a rogue value to indicate DllRegisterServer should use the
	//current file path
	{"CLSID\\{37633081-5D06-11d2-94A2-006008939020}\\InprocServer32", 0, (const char *)-1},
	{"CLSID\\{37633081-5D06-11d2-94A2-006008939020}\\InprocServer32", "ThreadingModel", "Apartment"},
	{"CLSID\\{37633081-5D06-11d2-94A2-006008939020}\\OLEScript", 0, ""},
	{"CLSID\\{37633081-5D06-11d2-94A2-006008939020}\\ProgId", 0, "CScript.1"},
	{"CLSID\\{37633081-5D06-11d2-94A2-006008939020}\\VersionIndependentProgId", 0, "CScript"},
};


/********************* DllUnregisterServer() ***************************
 * Removes the keys added to the registry by DllRegisterServer.
 */

STDAPI DllUnregisterServer(void)
{
	DWORD		nEntries, i;

	nEntries = sizeof(g_RegTable)/sizeof(*g_RegTable);
	for (i = nEntries - 1; i >= 0; i--)
		RegDeleteKeyA(HKEY_CLASSES_ROOT, g_RegTable[i][0]);

	return(S_OK);
}

/********************** DLLRegisterServer() ***************************
 * Self-registers this component. It removes the need for a .reg file.
 */

STDAPI DllRegisterServer(void)
{
	char		szFileName[MAX_PATH];
	HRESULT		hr;
	DWORD		nEntries, i;

	hr = S_OK;

	GetModuleFileName(DllHandle, szFileName, MAX_PATH);

	// register entries from the table
	nEntries = sizeof(g_RegTable)/sizeof(*g_RegTable);
	for (i = 0; i < nEntries; i++)
	{
		HKEY		hkey;
		long		err;
		const char	*pszName;
		const char	*pszValueName;
		const char	*pszValue;

		pszName = g_RegTable[i][0];
		pszValueName = g_RegTable[i][1];
		pszValue = g_RegTable[i][2];

		// Remap -1 char * to DLL file name
		if (pszValue == (const char *)-1) pszValue = szFileName;

		// Create the key
		err = RegCreateKeyA(HKEY_CLASSES_ROOT, pszName, &hkey);

		// Set the value
		if (!err)
		{
			err = RegSetValueExA(hkey, pszValueName, 0, REG_SZ, (const BYTE *)pszValue, (lstrlenA(pszValue) + 1));
			RegCloseKey(hkey);
		}

		// if error, back out and fail
		if (err)
		{
			DllUnregisterServer();
			hr = E_FAIL;
			break;
		}
	}

	return(hr);
}

#endif










// Since we only ever need one IClassFactory object, we declare
// it static. The only requirement is that we ensure any
// access to its members is thread-safe
static IClassFactory	MyIClassFactoryObj;

// IClassFactory's AddRef()
static ULONG STDMETHODCALLTYPE classAddRef(IClassFactory *this)
{
	// Someone is obtaining my IClassFactory, so inc the count of
	// pointers that I've returned which some app needs to Release()
	InterlockedIncrement(&OutstandingObjects);

	// Since we never actually allocate/free an IClassFactory (ie, we
	// use just 1 static one), we don't need to maintain a separate
	// reference count for our IClassFactory. We'll just tell the caller
	// that there's at least one of our IClassFactory objects in existance
	return(1);
}

// IClassFactory's QueryInterface()
static HRESULT STDMETHODCALLTYPE classQueryInterface(IClassFactory *this, REFIID factoryGuid, void **ppv)
{
	// Make sure the caller wants either an IUnknown or an IClassFactory.
	// In either case, we return the same IClassFactory pointer passed to
	// us since it can also masquerade as an IUnknown
	if (IsEqualIID(factoryGuid, &IID_IUnknown) || IsEqualIID(factoryGuid, &IID_IClassFactory))
	{
		// Call my IClassFactory's AddRef
		this->lpVtbl->AddRef(this);

		// Return (to the caller) a ptr to my IClassFactory
		*ppv = this;

		return(NOERROR);
	}

	// We don't know about any other GUIDs
	*ppv = 0;
	return(E_NOINTERFACE);
}

// IClassFactory's Release()
static ULONG STDMETHODCALLTYPE classRelease(IClassFactory *this)
{
	// One less object that an app has not yet Release()'ed
	return(InterlockedDecrement(&OutstandingObjects));
}

#ifdef LOGTRACE
extern unsigned char LogFlag;
#endif

// IClassFactory's CreateInstance() function. It is called by
// someone who has a pointer to our IClassFactory object and now
// wants to create and retrieve a pointer to our IExample2
static HRESULT STDMETHODCALLTYPE classCreateInstance(IClassFactory *this, IUnknown *punkOuter, REFIID vTableGuid, void **objHandle)
{
	HRESULT					hr;
	register IActiveScript	*thisObj;

	// Assume an error by clearing caller's handle
	*objHandle = 0;

	LOGFUNC("IClassFactory CreateInstance");

	// We don't support aggregation in this example
	if (punkOuter)
		hr = CLASS_E_NOAGGREGATION;
	else
	{
		// Allocate our ACTIVESCRIPT object
		if (!(thisObj = allocActiveScript()))
			hr = E_OUTOFMEMORY;
		else
		{
#ifdef LOGTRACE
			LogFlag = (unsigned char)-1;
#endif
			incActiveScriptRefcount((ACTIVESCRIPT *)thisObj);

			// Fill in the caller's handle with a pointer to the ACTIVESCRIPT we just
			// allocated above. We'll let ACTIVESCRIPT's QueryInterface do that, because
			// it also checks the GUID the caller passed, and also increments the
			// reference count (to 2) if all goes well
			hr = queryActiveScriptInterface((ACTIVESCRIPT *)thisObj, vTableGuid, objHandle);

			// Decrement reference count. NOTE: If there was an error in QueryInterface()
			// then Release() will be decrementing the count back to 0 and will free the
			// ACTIVESCRIPT for us. One error that may occur is that the caller is asking for
			// some sort of object that we don't support (ie, it's a GUID we don't recognize)
			decActiveScriptRefcount((ACTIVESCRIPT *)thisObj);
		}
	}

#ifdef LOGTRACE
	LogFlag = 0;
	LOGHEXPARAM("Returns", hr);
	UNLOGFUNC();
#endif	
	return(hr);
}

// IClassFactory's LockServer(). It is called by someone
// who wants to lock this DLL in memory
static HRESULT STDMETHODCALLTYPE classLockServer(IClassFactory *this, BOOL flock)
{
	if (flock) InterlockedIncrement(&LockCount);
	else InterlockedDecrement(&LockCount);

	return(NOERROR);
}

// IClassFactory's VTable
static const IClassFactoryVtbl IClassFactory_Vtbl = {classQueryInterface,
classAddRef,
classRelease,
classCreateInstance,
classLockServer};
















// Miscellaneous functions ///////////////////////////////////////////////////////

/********************* incOutstandingObjs() *********************
 * Called whenever we allocate some object (ie, an IActiveScript
 * or IActiveScriptError, for example), AddRef it, and return it
 * to the host.
 */

void incOutstandingObjs(void)
{
	InterlockedIncrement(&OutstandingObjects);
}





/********************** decOutstandingObjs() ********************
 * Called whenever the host Release()'s an object that we called
 * DllAddRef() for.
 */

void decOutstandingObjs(void)
{
	InterlockedDecrement(&OutstandingObjects);
}





/************************ DllGetClassObject() ***********************
 * This is called by the OLE functions CoGetClassObject() or
 * CoCreateInstance() in order to get our DLL's IClassFactory object 
 * (and return it to someone who wants to use it to get ahold of one
 * of our IActiveScript objects). Our IClassFactory's CreateInstance() can
 * be used to allocate/retrieve our IActiveScript object.
 *
 * NOTE: After we return the pointer to our IClassFactory, the caller
 * will typically call its CreateInstance() function.
 */

HRESULT PASCAL DllGetClassObject(REFCLSID objGuid, REFIID factoryGuid, void **factoryHandle)
{
	register HRESULT		hr;

	LOGOPEN(0);
	LOGFUNC("DllGetClassObject");

	// Check if the caller is passing our script engine IActiveScript GUID
	if (IsEqualCLSID(objGuid, &CLSID_CMinus))
	{
		// Fill in the caller's handle with a pointer to our IClassFactory object.
		// We'll let our IClassFactory's QueryInterface do that, because it also
		// checks the IClassFactory GUID and does other book-keeping
		hr = classQueryInterface(&MyIClassFactoryObj, factoryGuid, factoryHandle);
	}
	else
	{
		// We don't understand this GUID. It's obviously not for our DLL.
		// Let the caller know this by clearing his handle and returning
		// CLASS_E_CLASSNOTAVAILABLE
		*factoryHandle = 0;
		hr = CLASS_E_CLASSNOTAVAILABLE;
	}

	LOGHEXPARAM("DllGetClassObject returns", hr);
	UNLOGFUNC();
	return(hr);
}





/************************ DllCanUnloadNow() ***********************
 * This is called by some OLE function in order to determine
 * whether it is safe to unload our DLL from memory.
 *
 * RETURNS: S_OK if safe to unload, or S_FALSE if not.
 */

HRESULT PASCAL DllCanUnloadNow(void)
{
	// If someone has retrieved pointers to any of our objects, and
	// not yet Release()'ed them, then we return S_FALSE to indicate
	// not to unload this DLL. Also, if someone has us locked, return
	// S_FALSE
	return((OutstandingObjects | LockCount) ? S_FALSE : S_OK);
}





/************************** DllMain() **************************
 * Called by OS when this DLL is loaded or unloaded.
 */

BOOL WINAPI DllMain(HINSTANCE instance, DWORD fdwReason, LPVOID lpvReserved)
{
	switch (fdwReason)
	{
		case DLL_PROCESS_ATTACH:
		{
			DllHandle = instance;

			// Clear global counts
			ActiveScriptList = OutstandingObjects = LockCount = 0;

			// Initialize my IClassFactory with the pointer to its vtable
			MyIClassFactoryObj.lpVtbl = (IClassFactoryVtbl *)&IClassFactory_Vtbl;

			// Initialize IActiveScriptError stuff
			errorInitMsgLib();

			InitializeCriticalSection(&InterruptSection);

			// We don't need to do any thread initialization
			DisableThreadLibraryCalls(instance);
			break;
		}

		case DLL_PROCESS_DETACH:
		{
			DeleteCriticalSection(&InterruptSection);

			// Free error msg lib
			errorFreeMsgLib();

			// Close trace window
			LOGCLOSE();
		}
	}

	return(1);
}
