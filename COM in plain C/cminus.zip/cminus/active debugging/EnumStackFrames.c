/*
 * Functions for our ENUMDEBUGSTACKFRAMES struct, which wraps an
 * IEnumDebugStackFrames. The IEnumDebugStackFrames is a standard 
 * COM enumerator to allow the host to enumerate the DebugStackFrameDescriptor
 * structs pushed on our stack frame. What we've done is simply put the
 * DebugStackFrameDescriptors of all interpreters into one big
 * TSTACK that is placed in our ACTIVESCRIPT.
 *
 * Also included is our IDebugStackFrameSniffer COM object functions.
 * The IDebugStackFrameSniffer is used by the host to create the
 * IEnumDebugStackFrames.
 */

#define INC_OLE2
#define CONST_VTABLE
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <stddef.h>
#include <objbase.h>
#include <activdbg.h>
#include "../TraceWin.h"
#include "../IClassFactory.h"
#include "../Interpreter/TStack.H"
#include "../Active Engine/ActiveScript.h"


// Our IDebugStackFrameSniffer VTable
static STDMETHODIMP SniffQueryInterface(IDebugStackFrameSniffer *, REFIID, void **);
static STDMETHODIMP_(ULONG) SniffAddRef(IDebugStackFrameSniffer *);
static STDMETHODIMP_(ULONG) SniffRelease(IDebugStackFrameSniffer *);
static STDMETHODIMP EnumStackFrames(IDebugStackFrameSniffer *, IEnumDebugStackFrames **); 

const IDebugStackFrameSnifferVtbl IDebugStackFrameSniffer_Vtbl = {SniffQueryInterface,
SniffAddRef,
SniffRelease,
EnumStackFrames};

// Wraps an IEnumDebugStackFrames
typedef struct {
	const void *		lpVtbl;					// IEnumDebugStackFrames VTable. Must be first
	ACTIVESCRIPT		*ActiveScript;			// The ACTIVESCRIPT whose frames are being enumerated
	TSTACK				*CurStackFrameDesc;		// Pointer to the current item in the IEnumDebugStackFrames
	ULONG				RefCount;
} ENUMDEBUGSTACKFRAMES;

// Our IEnumDebugStackFrames VTable
static STDMETHODIMP QueryInterface(ENUMDEBUGSTACKFRAMES *, REFIID, void **);
static STDMETHODIMP_(ULONG) AddRef(ENUMDEBUGSTACKFRAMES *);
static STDMETHODIMP_(ULONG) Release(ENUMDEBUGSTACKFRAMES *);
static STDMETHODIMP Next(ENUMDEBUGSTACKFRAMES *, ULONG, DebugStackFrameDescriptor *, ULONG *);
static STDMETHODIMP Skip(ENUMDEBUGSTACKFRAMES *, ULONG);
static STDMETHODIMP Reset(ENUMDEBUGSTACKFRAMES *);
static STDMETHODIMP Clone(ENUMDEBUGSTACKFRAMES *, IEnumDebugStackFrames **);

static const IEnumDebugStackFramesVtbl IEnumDebugStackFrames_Vtbl = {QueryInterface,
AddRef,
Release,
Next,
Skip,
Reset,
Clone};

#ifdef LOGTRACE
static unsigned char LogFlag2 = 0;
#endif

static IEnumDebugStackFrames * allocIEnumDebugStackFrames(ACTIVESCRIPT *);















//===============================================================================
// The IDebugStackFrameSniffer exposes the stack frames of this script engine
// to the debugger. It allows the debugger to get an enumerator object to obtain
// information about all the stack frames. This host would use this to provide
// data browsing capabilities.
//===============================================================================

/************************ QueryInterface() **************************
 */

static STDMETHODIMP SniffQueryInterface(IDebugStackFrameSniffer *this, REFIID riid, void **ppvObj)
{
	LOGFUNC("IDebugStackFrameSniffer::QueryInterface");

	return(queryActiveScriptInterface((ACTIVESCRIPT *)((unsigned char *)this - offsetof(ACTIVESCRIPT, DebugStackFrameSniffer)), riid, ppvObj));
}

/**************************** AddRef() ******************************
 */

static STDMETHODIMP_(ULONG) SniffAddRef(IDebugStackFrameSniffer *this)
{
	LOGFUNC("IDebugStackFrameSniffer::AddRef");

	// Increment RefCount of ACTIVESCRIPT
	return(incActiveScriptRefcount((ACTIVESCRIPT *)((unsigned char *)this - offsetof(ACTIVESCRIPT, DebugStackFrameSniffer))));
}

/*************************** Release() *****************************
 */

static STDMETHODIMP_(ULONG) SniffRelease(IDebugStackFrameSniffer *this)
{
	LOGFUNC("IDebugStackFrameSniffer::Release");

	// Decrement RefCount of ACTIVESCRIPT
	return(decActiveScriptRefcount((ACTIVESCRIPT *)((unsigned char *)this - offsetof(ACTIVESCRIPT, DebugStackFrameSniffer))));
}

/************************ EnumStackFrames() ************************
 * Allocates and give to the host an IEnumDebugStackFrames to
 * enumerate all the stack frames available in this engine.
 *
 * pObj =	Where to return our IEnumDebugStackFrames.
 */

static STDMETHODIMP EnumStackFrames(IDebugStackFrameSniffer *this, IEnumDebugStackFrames **pObj)
{
	register HRESULT			hr;

	LOGFUNC("IDebugStackFrameSniffer::EnumStackFrames");

	// Check the args
//	if (*pObj)
//		hr = E_POINTER;
//	else
//	{
		hr = E_OUTOFMEMORY;

		// Create a new IEnumDebugStackFrames (actually ENUMDEBUGSTACKFRAMES).
		// NOTE: allocIEnumDebugStackFrames AddRef()'s it
		if ((*pObj = allocIEnumDebugStackFrames((ACTIVESCRIPT *)((unsigned char *)this - offsetof(ACTIVESCRIPT, DebugStackFrameSniffer))))) hr = S_OK;
//	}

	LOGHEXPARAM("Returns", hr);
	UNLOGFUNC();
	return(hr);
}



















//===============================================================================
// The IEnumDebugStackFrames enumerates the DebugStackFrameDescriptor structs
// pushed on our stack frames.
//===============================================================================

/****************** allocIEnumDebugStackFrames() ******************
 * Allocates/initializes an IEnumDebugStackFrames (actually an
 * ENUMDEBUGSTACKFRAMES).
 *
 * iactive =	A pointer to the ACTIVESCRIPT holding the list of
 *				interpreters (and the stack frame list).
 *
 * RETURNS: The IEnumDebugStackFrames *, or 0 if memory failure.
 *
 * NOTE: AddRefs the returned object.
 */

static IEnumDebugStackFrames * allocIEnumDebugStackFrames(ACTIVESCRIPT *iactive)
{
	register ENUMDEBUGSTACKFRAMES	*obj;

	if ((obj = (ENUMDEBUGSTACKFRAMES *)ALLOCMEM(sizeof(ENUMDEBUGSTACKFRAMES))))
	{
		obj->lpVtbl = &IEnumDebugStackFrames_Vtbl;
		obj->ActiveScript = iactive;
		obj->CurStackFrameDesc = iactive->StackFrames;
		obj->RefCount = 1;
		incActiveScriptRefcount(iactive);
	}

	return((IEnumDebugStackFrames *)obj);
}

/************************ QueryInterface() **************************
 */

static STDMETHODIMP QueryInterface(ENUMDEBUGSTACKFRAMES *this, REFIID riid, void **ppvObj)
{
	LOGFUNC("IEnumDebugStackFrames::QueryInterface");

//	if (!IsBadWritePtr(ppvObj, sizeof(void *)))
//	{
		if (IsEqualIID(riid, &IID_IUnknown) || IsEqualIID(riid, &IID_IEnumDebugStackFrames))
		{
			*ppvObj = this;
#ifdef LOGTRACE
			LogFlag2 = 1;
#endif
			AddRef(this);
			return(NOERROR);
		}

		return(queryActiveScriptInterface((ACTIVESCRIPT *)this->ActiveScript, riid, ppvObj));
//	}

//	UNLOGFUNC();
//	return(E_POINTER);
}

/**************************** AddRef() ******************************
 */

static STDMETHODIMP_(ULONG) AddRef(ENUMDEBUGSTACKFRAMES *this)
{
#ifdef LOGTRACE
	if (!LogFlag2) LOGFUNC("IEnumDebugStackFrames::AddRef");
	LogFlag2 = 0;
#endif

	++this->RefCount;

	// Increment RefCount of ACTIVESCRIPT
	return(incActiveScriptRefcount((ACTIVESCRIPT *)this->ActiveScript));
}

/*************************** Release() *****************************
 */

static STDMETHODIMP_(ULONG) Release(ENUMDEBUGSTACKFRAMES *this)
{
	register ACTIVESCRIPT *iactive;

	LOGFUNC("IEnumDebugStackFrames::Release");

	iactive = (ACTIVESCRIPT *)this->ActiveScript;
	if (--this->RefCount == 0)
	{
		FREEMEM(this);
	}

	// Decrement RefCount of ACTIVESCRIPT
	return(decActiveScriptRefcount(iactive));
}

/*************************** Next() ***************************
 * Retrieves the next DebugStackFrameDescriptor(s),
 * if they're available.
 *
 * count =		The number of DebugStackFrameDescriptors to retrieve.
 * pi =			Array of DebugStackFrameDescriptor structs to fill.
 * fetched =	Where to return the # of DebugStackFrameDescriptors
 *				actually returned.
 */

static STDMETHODIMP Next(ENUMDEBUGSTACKFRAMES *this, ULONG count, DebugStackFrameDescriptor *pi, ULONG *fetched)
{
	ULONG		i;
	HRESULT		hr;

	LOGFUNC("IEnumDebugStackFrames::Next");

	hr = S_OK;

	i = 0;

	// Just make sure that we're not trying to enumerate a DEBUGSTACKFRAMEDESCRIPTOR that
	// has been deleted
	if (IsBadWritePtr(this->CurStackFrameDesc, sizeof(DEBUGSTACKFRAMEDESCRIPTOR))) goto done;

	// Walk down the list the specified number of DEBUGSTACKFRAMEDESCRIPTORs. If we run out of
	// DEBUGSTACKFRAMEDESCRIPTORs before we've enumerated enough, return S_FALSE
	while (i < count)
	{
		register DEBUGSTACKFRAMEDESCRIPTOR	*pDesc;

		// Make sure we haven't run out of DEBUGSTACKFRAMEDESCRIPTORs
		if (!this->CurStackFrameDesc)
		{
done:		hr = S_FALSE;
			break;
		}

		// Get the DEBUGSTACKFRAMEDESCRIPTOR we're working on
		pDesc = (DEBUGSTACKFRAMEDESCRIPTOR *)this->CurStackFrameDesc->Value;

		// Copy the values of our DEBUGSTACKFRAMEDESCRIPTOR into caller's DebugStackFrameDescriptor
		pi[i].pdsf = (IDebugStackFrame *)pDesc;
		pi[i].dwMin = pDesc->FrameAddress;
		pi[i].dwLim = 1;
		pi[i].punkFinal = (IUnknown *)pi[i].fFinal = 0;

		// We must AddRef() our IDebugStackFrame on behalf of the caller.
		// NOTE: Our IDebugStackFrame::AddRef() simply calls
		// incActiveScriptRefcount(), but if it did something
		// more, we should actually call its AddRef
		incActiveScriptRefcount((ACTIVESCRIPT *)this->ActiveScript);

		// Increment the count of DebugStackFrameDescriptor's we're returning
		++i;

		// Move on to the next stack frame. If we're out of
		// DebugStackFrameDescriptors in this interpreter, then
		// move on to the next interpreter. Since all stack
		// frames for all debug interpreters are kept in one large
		// TSTACK, then this automatically works to go between
		// debug interpreters
		this->CurStackFrameDesc = this->CurStackFrameDesc->Next;
	}
   
	// Report the actual number of DebugStackFrameDescriptor's we've returned
	*fetched = i;

	return(hr);
} 

/************************* Skip() ****************************
 * Skips a given number of DebugStackFrameDescriptor(s) in
 * the enumeration.
 *
 * count =	Number of DebugStackFrameDescriptors to skip.
 */

static STDMETHODIMP Skip(ENUMDEBUGSTACKFRAMES *this, ULONG count)
{
	register ULONG		i;
	register HRESULT	hr;

	LOGFUNC("IEnumDebugStackFrames::Skip");

	hr = S_OK;

	if (IsBadWritePtr(this->CurStackFrameDesc, sizeof(DEBUGSTACKFRAMEDESCRIPTOR))) goto done;

	// Walk down the list the specified number of DEBUGSTACKFRAMEDESCRIPTORs.  If we run out of
	// DEBUGSTACKFRAMEDESCRIPTORs before we've skipped enough, return S_FALSE.
	for (i = 0; i < count; i++)
	{
		// Move to the next DebugStackFrameDescriptor in this interpreter.
		// If no more, then move on to the next interpreter
		if ((this->CurStackFrameDesc = this->CurStackFrameDesc->Next))
		{
done:		hr = S_FALSE;
			break;
		}
	}
   
	return(hr);
}

/************************** Reset() ***************************
 * Resets the enumerator to the beginning of the list.
 */

static STDMETHODIMP Reset(ENUMDEBUGSTACKFRAMES *this)
{
	LOGFUNC("IEnumDebugStackFrames::Reset");

	this->CurStackFrameDesc = this->ActiveScript->StackFrames;

	LOGHEXPARAM("Returns", S_OK);
	UNLOGFUNC();

	return(S_OK);
} 

/************************* Clone() **************************
 * Creates a new IEnumDebugStackFrames enumerator with
 * the same enumerator state as this one.
 *
 * ppepi =	 Where to return the new IEnumDebugStackFrames.
 */

static STDMETHODIMP Clone(ENUMDEBUGSTACKFRAMES *this, IEnumDebugStackFrames **pObj)
{
	register HRESULT	hr;

	LOGFUNC("IEnumDebugStackFrames::Clone");

	hr = S_OK;

	// Get a new IEnumDebugStackFrames (actually ENUMDEBUGSTACKFRAMES)
	if (!(*pObj = allocIEnumDebugStackFrames(this->ActiveScript)))
		hr = E_OUTOFMEMORY;

	LOGHEXPARAM("Returns", hr);
	UNLOGFUNC();

	return(hr);
}
