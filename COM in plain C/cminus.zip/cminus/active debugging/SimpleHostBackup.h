#ifndef _SMARTHOST_H_
#define _SMARTHOST_H_

#include "../Active Engine/ActiveScript.h"

extern IActiveScriptSiteDebug *	allocSmartHost(IActiveScriptSite *);
extern void						addScriptTextToDebugger(ACTIVESCRIPT *, LPCOLESTR, BOOL);

extern const IActiveScriptSiteDebug32Vtbl IActiveScriptSiteDebug_Vtbl;

#endif