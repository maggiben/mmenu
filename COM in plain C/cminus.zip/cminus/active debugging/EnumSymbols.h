#ifndef _ENUMSYMBOLS_H_
#define _ENUMSYMBOLS_H_

#include "../Active Debugging/StackFrameDesc.h"

extern IDebugProperty * allocDebugStackedSymbols(DEBUGSTACKFRAMEDESCRIPTOR *);

#endif