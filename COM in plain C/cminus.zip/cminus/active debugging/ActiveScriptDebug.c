/*
 * Contains functions for the IActiveScriptDebug and IRemoteDebugApplicationEvents
 * (debugger) sub-objects of our IActiveScript (ACTIVESCRIPT). These sub-objects
 * support a host debugger, and are available only if the host obtains an
 * IDebugApplication from the Process Debug Manager (PDM), and our engine gets
 * this from the host (when the host calls our SetScriptSite()).
 */

#define INC_OLE2
#define CONST_VTABLE
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <stddef.h>
#include <objbase.h>
#include <activscp.h>
#include <activdbg.h>
#include "../TraceWin.h"
#include "../IClassFactory.h"
#include "../Active Engine/ActiveScript.h"
#include "IDebugCodeContext.h"





// Our IRemoteDebugApplicationEvents VTable
static STDMETHODIMP RemQueryInterface(IRemoteDebugApplicationEvents *, REFIID, void **);
static STDMETHODIMP_(ULONG) RemAddRef(IRemoteDebugApplicationEvents *);
static STDMETHODIMP_(ULONG) RemRelease(IRemoteDebugApplicationEvents *);
static STDMETHODIMP OnConnectDebugger(IRemoteDebugApplicationEvents *, IApplicationDebugger *); 
static STDMETHODIMP OnDisconnectDebugger(IRemoteDebugApplicationEvents *); 
static STDMETHODIMP OnSetName(IRemoteDebugApplicationEvents *, LPCOLESTR);
static STDMETHODIMP OnDebugOutput(IRemoteDebugApplicationEvents *, LPCOLESTR);
static STDMETHODIMP OnClose(IRemoteDebugApplicationEvents *); 
static STDMETHODIMP OnEnterBreakPoint(IRemoteDebugApplicationEvents *, IRemoteDebugApplicationThread *); 
static STDMETHODIMP OnLeaveBreakPoint(IRemoteDebugApplicationEvents *, IRemoteDebugApplicationThread *); 
static STDMETHODIMP OnCreateThread(IRemoteDebugApplicationEvents *, IRemoteDebugApplicationThread *); 
static STDMETHODIMP OnDestroyThread(IRemoteDebugApplicationEvents *, IRemoteDebugApplicationThread *); 
static STDMETHODIMP OnBreakFlagChange(IRemoteDebugApplicationEvents *, APPBREAKFLAGS, IRemoteDebugApplicationThread *); 

const IRemoteDebugApplicationEventsVtbl IRemoteDebugApplicationEvents_Vtbl = {RemQueryInterface,
RemAddRef,
RemRelease,
OnConnectDebugger,
OnDisconnectDebugger,
OnSetName,
OnDebugOutput,
OnClose,
OnEnterBreakPoint,
OnLeaveBreakPoint,
OnCreateThread,
OnDestroyThread,
OnBreakFlagChange};

// Our IActiveScriptDebug VTable
static STDMETHODIMP DS_QueryInterface(IActiveScriptDebug *, REFIID, void **);
static STDMETHODIMP_(ULONG) DS_AddRef(IActiveScriptDebug *);
static STDMETHODIMP_(ULONG) DS_Release(IActiveScriptDebug *);
static STDMETHODIMP GetScriptTextAttributes(IActiveScriptDebug *, LPCOLESTR, ULONG, LPCOLESTR, DWORD, SOURCE_TEXT_ATTR *); 
static STDMETHODIMP GetScriptletTextAttributes(IActiveScriptDebug *, LPCOLESTR, ULONG, LPCOLESTR, DWORD, SOURCE_TEXT_ATTR *);
static STDMETHODIMP EnumCodeContextsOfPosition(IActiveScriptDebug *, DWORD, ULONG, ULONG, IEnumDebugCodeContexts **);

const IActiveScriptDebug32Vtbl IActiveScriptDebug_Vtbl = {DS_QueryInterface,
DS_AddRef,
DS_Release,
GetScriptTextAttributes,
GetScriptletTextAttributes,
EnumCodeContextsOfPosition};






//=============================================================================
// Our IRemoteDebugApplicationEvents is used by the host to provide notifications
// when various events occur within the host. This lets us know what the current
// break flags are, when the host is calling the PDM IDebugApplication's
// ConnectDebugger or DisconnectDebugger, etc.
//=============================================================================

/************************ QueryInterface() *************************
 */

static STDMETHODIMP RemQueryInterface(IRemoteDebugApplicationEvents *this, REFIID riid, void **ppvObj)
{
	LOGFUNC("IRemoteDebugApplicationEvents::QueryInterface");

	return(queryActiveScriptInterface((ACTIVESCRIPT *)((unsigned char *)this - offsetof(ACTIVESCRIPT, RemoteDebugAppEvents)), riid, ppvObj));
}

/*************************** AddRef() ******************************
 */

static STDMETHODIMP_(ULONG) RemAddRef(IRemoteDebugApplicationEvents *this)
{
	LOGFUNC("IRemoteDebugApplicationEvents::AddRef");

	// Increment RefCount of ACTIVESCRIPT
	return(incActiveScriptRefcount((ACTIVESCRIPT *)((unsigned char *)this - offsetof(ACTIVESCRIPT, RemoteDebugAppEvents))));
}

/************************** Release() ******************************
 */

static STDMETHODIMP_(ULONG) RemRelease(IRemoteDebugApplicationEvents *this)
{
	LOGFUNC("IRemoteDebugApplicationEvents::Release");

	// Decrement RefCount of ACTIVESCRIPT
	return(decActiveScriptRefcount((ACTIVESCRIPT *)((unsigned char *)this - offsetof(ACTIVESCRIPT, RemoteDebugAppEvents))));
}

/******************** OnConnectDebugger() **********************
 * Informs us when the host debugger has been called the PDM
 * IDebugApplication's ConnectDebugger() to connect its
 * IApplicationDebugger.
 *
 * appDebugger =	The host IApplicationDebugger that has been
 *					attached.
 */

static STDMETHODIMP OnConnectDebugger(IRemoteDebugApplicationEvents *this, IApplicationDebugger *appDebugger)
{
	LOGFUNC("IRemoteDebugApplicationEvents::OnConnectDebugger");
	UNLOGFUNC();

	// We don't really care, so just return S_OK
	return(S_OK);
}

/******************* OnDisconnectDebugger() ********************
 * Informs us when the host debugger has been called the PDM
 * IDebugApplication's DisconnectDebugger() to detach its
 * IApplicationDebugger.
 */

static STDMETHODIMP OnDisconnectDebugger(IRemoteDebugApplicationEvents *this)
{
	LOGFUNC("IRemoteDebugApplicationEvents::OnDisconnectDebugger");
	UNLOGFUNC();

	// We don't really care, so just return S_OK
	return(S_OK);
}

/************************* OnSetName() *************************
 * Informs us when the host calls the PDM IDebugApplication's
 * SetName() to set the application name.
 *
 * name =	The name of the debug application
 */

static STDMETHODIMP OnSetName(IRemoteDebugApplicationEvents *this, LPCOLESTR name)
{
	LOGFUNC("IRemoteDebugApplicationEvents::OnSetName");
	UNLOGFUNC();

	// We don't really care, so just return S_OK
	return(S_OK);
}

/********************** OnDebugOutput() ************************
 * Informs us when the host debugger presents some output to
 * the user.
 *
 * pstr =	The string presented to the user
 */

static STDMETHODIMP OnDebugOutput(IRemoteDebugApplicationEvents *this, LPCOLESTR pstr)
{
	LOGFUNC("IRemoteDebugApplicationEvents::OnDebugOutput");
	UNLOGFUNC();

	// We don't really care, so just return S_OK
	return(S_OK);
}


/******************** close_host_objects() *********************
 * A helper function to release the host's IDebugApplication,
 * IRemoteDebugApplicationThread, and the IConnectionPoint we
 * used to attach our IRemoteDebugApplicationEvents to the
 * host's IDebugApplication events.
 *
 * iactive =	The ACTIVESCRIPT to be cleaned up.
 */

void close_host_objects(ACTIVESCRIPT *activeScript)
{
	if (activeScript->HostDebugApplication)
	{
		activeScript->HostDebugApplication->lpVtbl->Release(activeScript->HostDebugApplication);
		activeScript->HostDebugApplication = 0;
		activeScript->SnifferCookie = 0;	// NOTE: We don't detach our IDebugStackFrameSniffer because we assume the
										// host's IDebugApplication is smart enough to have Release()'ed it already
	}

	if (activeScript->HostDebugThread)
	{
		activeScript->HostDebugThread->lpVtbl->Release(activeScript->HostDebugThread);
		activeScript->HostDebugThread = 0;
	}

	if (activeScript->HostEventsConnPoint)
	{
		activeScript->HostEventsConnPoint->lpVtbl->Unadvise(activeScript->HostEventsConnPoint, activeScript->HostEventsConnCookie);
		activeScript->HostEventsConnPoint->lpVtbl->Release(activeScript->HostEventsConnPoint);
		activeScript->HostEventsConnPoint = 0;
	}
}


/************************** OnClose() **************************
 * Informs us when the host is Release()'ing its IDebugApplication.
 * This could be important if we're running a script.
 */

static STDMETHODIMP OnClose(IRemoteDebugApplicationEvents *this)
{
	register ACTIVESCRIPT	*activeScript;

	activeScript = (ACTIVESCRIPT *)((unsigned char *)this - offsetof(ACTIVESCRIPT, RemoteDebugAppEvents));

	LOGFUNC("IRemoteDebugApplicationEvents::OnClose");

	if (!IsBadWritePtr(activeScript, sizeof(ACTIVESCRIPT))) close_host_objects(activeScript);

	UNLOGFUNC();
	return(S_OK);
}

/******************** OnEnterBreakPoint() **********************
 * Informs us when the host debugger enters a breakpoint. (ie,
 * We've called the host IDebugApplication's HandleBreakPoint()).
 * This is important because we might try to call into a stopped
 * engine.
 *
 * appThread =	Pointer to the IRemoteDebugApplicationThread which
 *				has entered a breakpoint.
 */

static STDMETHODIMP OnEnterBreakPoint(IRemoteDebugApplicationEvents *this, IRemoteDebugApplicationThread *appThread)
{
	LOGFUNC("IRemoteDebugApplicationEvents::OnEnterBreakPoint");
	UNLOGFUNC();

	// We don't really care, so just return S_OK
	return(S_OK);
}

/********************* OnLeaveBreakPoint() *********************
 * Informs us when any script engine running in the host
 * debugger leaves a breakpoint. This is important because we
 * may try to call into the newly started engine.
 *
 * appThread =	Pointer to the IRemoteDebugApplicationThread which
 *				has left a breakpoint.
 */

static STDMETHODIMP OnLeaveBreakPoint(IRemoteDebugApplicationEvents *this, IRemoteDebugApplicationThread *appThread)
{
	LOGFUNC("IRemoteDebugApplicationEvents::OnLeaveBreakPoint");
	UNLOGFUNC();

	// We don't really care, so just return S_OK
	return(S_OK);
}

/*********************** OnCreateThread() ***********************
 * Informs us when a new thread is created in the host.
 *
 * appThread =	Pointer to the newly created IRemoteDebugApplicationThread.
 */

static STDMETHODIMP OnCreateThread(IRemoteDebugApplicationEvents *this, IRemoteDebugApplicationThread *appThread)
{
	LOGFUNC("IRemoteDebugApplicationEvents::OnCreateThread");
	UNLOGFUNC();

	// We don't really care, so just return S_OK
	return(S_OK);
}


/*********************** OnDestroyThread() ***********************
 * Informs us when a host thread has been destroyed.
 *
 * appThread =	The IRemoteDebugApplicationThread that has been destroyed.
 */

static STDMETHODIMP OnDestroyThread(IRemoteDebugApplicationEvents *this, IRemoteDebugApplicationThread *appThread)
{
	LOGFUNC("IRemoteDebugApplicationEvents::OnDestroyThread");
	UNLOGFUNC();

	// We don't really care, so just return S_OK
	return(S_OK);
}

/********************* OnBreakFlagChange() **********************
 * Informs us when the host debugger changes its break flags.
 * This is critical to us because we need to know both what the
 * current break flags are, and what the current stepping thread is.
 */

static STDMETHODIMP OnBreakFlagChange(IRemoteDebugApplicationEvents *this, APPBREAKFLAGS breakFlags, IRemoteDebugApplicationThread *appThread)
{
	DWORD					dwSteppingThread;
	register ACTIVESCRIPT	*activeScript;

	activeScript = (ACTIVESCRIPT *)((unsigned char *)this - offsetof(ACTIVESCRIPT, RemoteDebugAppEvents));

	LOGFUNC("IRemoteDebugApplicationEvents::OnBreakFlagChange");

	if (!IsBadWritePtr(activeScript, sizeof(ACTIVESCRIPT)))
	{
		// Get the thread ID of the stepping thread and see if it's our debugging thread
		if (appThread)
		{
			appThread->lpVtbl->GetSystemThreadId(appThread, &dwSteppingThread);
			if (dwSteppingThread == activeScript->HostThreadID) goto store;
		}

		// This is not our thread! We store APPBREAKFLAG_STEP only if we are
		// the current stepping thread. So mask it off now
		breakFlags &= ~APPBREAKFLAG_STEP;

		// Cache the new APPBREAKFLAGS
store:	activeScript->BreakFlags = breakFlags;

		dwSteppingThread = S_OK;
	}
	else
		dwSteppingThread = E_POINTER;

	LOGHEXPARAM("Returns", dwSteppingThread);
	UNLOGFUNC();
	return(dwSteppingThread);
}
















//===============================================================================
// The IActiveScriptDebug is a sub-object of an IActiveScript object.
// The IActiveScriptDebug has functions to provide information about
// text coloring, and provide access to IDebugCodeContext's for the script.
//
// NOTE: We provide this to the host only if it supports debugging (and we
// therefore have CINSTRUCTIONs with extra CTOKEN information).
//===============================================================================

/******************************************************************************
 */

static STDMETHODIMP DS_QueryInterface(IActiveScriptDebug *this, REFIID riid, void **ppvObj)
{
	LOGFUNC("IActiveScriptDebug::QueryInterface");

	return(queryActiveScriptInterface((ACTIVESCRIPT *)((unsigned char *)this - offsetof(ACTIVESCRIPT, ActiveScriptDebug)), riid, ppvObj));
}

/******************************************************************************
 */

static STDMETHODIMP_(ULONG) DS_AddRef(IActiveScriptDebug *this)
{
	LOGFUNC("IActiveScriptDebug::AddRef");

	// Increment RefCount of ACTIVESCRIPT
	return(incActiveScriptRefcount((ACTIVESCRIPT *)((unsigned char *)this - offsetof(ACTIVESCRIPT, ActiveScriptDebug))));
}

/******************************************************************************
 */

static STDMETHODIMP_(ULONG) DS_Release(IActiveScriptDebug *this)
{
	LOGFUNC("IActiveScriptDebug::Release");

	// Decrement RefCount of ACTIVESCRIPT
	return(decActiveScriptRefcount((ACTIVESCRIPT *)((unsigned char *)this - offsetof(ACTIVESCRIPT, ActiveScriptDebug))));
}

/******************** GetScriptTextAttributes() ********************
 * Retrieves the attributes of a given segment of script. Typically,
 * the IDebugDocumentText's GetText() calls this.
 *
 * scriptlet =	The script text. Need not be NULL terminated
 * count =		Number of chars in the the script text
 * delim =		Pointer to any delimiter the host used to detect
 *				the end of the script
 * dwFlags =	SCRIPTTEXT_DELAYEXECUTION 
 *				SCRIPTTEXT_ISVISIBLE
 *				SCRIPTTEXT_ISEXPRESSION
 *				SCRIPTTEXT_ISPERSISTENT
 *				SCRIPTTEXT_HOSTMANAGESSOURCE
 * pattr =		Pointer to an array that we must fill in with
 *				syntax-coloring info.
 */

HRESULT scanScript(LPCOLESTR, ULONG, SOURCE_TEXT_ATTR *);

static STDMETHODIMP GetScriptTextAttributes(IActiveScriptDebug *this, LPCOLESTR scriptlet, ULONG count, LPCOLESTR delim, DWORD dwFlags, SOURCE_TEXT_ATTR *pattr)
{
	LOGFUNC("IActiveScriptDebug::GetScriptTextAttributes");

	// Check the args
//	if (!scriptlet)
//		return E_INVALIDARG;
//	if (!pattr)
//		return E_POINTER;

	return(scanScript(scriptlet, count, pattr));
} 

/******************* GetScriptletTextAttributes() *****************
 * Retrieves the attributes of a given segment of script. Typically,
 * the IDebugDocumentText's GetText() calls this.
 */

static STDMETHODIMP GetScriptletTextAttributes(IActiveScriptDebug *this, LPCOLESTR scriptlet, ULONG count, LPCOLESTR delim, DWORD dwFlags, SOURCE_TEXT_ATTR *pattr)
{
	LOGFUNC("IActiveScriptDebug::GetScriptletTextAttributes");

	// Check the args
//	if (!scriptlet)
//		return E_INVALIDARG;
//	if (!pattr)
//		return E_POINTER;

	return(scanScript(scriptlet, count, pattr));
} 

/********************** scanScript() ************************
 * Helper function that scans some script source and stores
 * the text attributes.
 *
 * pstrCode =	The script text to scan
 * numChars =	The number of OLECHARs in pstrCode
 * pattr =		An array of SOURCE_TEXT_ATTRs where we store
 *				the script text attributes
 */

HRESULT scanScript(LPCOLESTR pstrCode, ULONG numChars, SOURCE_TEXT_ATTR *pattr)
{
	register OLECHAR	chr;
	register LPCOLESTR	currentPtr;

	// NOTE: Caller does the LOGFUNC

	currentPtr = pstrCode;
	pstrCode += numChars;

	while (currentPtr < pstrCode)
	{
		chr = *(currentPtr)++;

		// Whitespace?
		if (chr == '\n' || chr == '\t' || chr == '\r' || chr == '\f' || chr == ' ')
			*(pattr)++ = SOURCETEXT_ATTR_NONSOURCE;
  
		// An identifier starts with an alphabetical character or underscore
		else if (iswalpha(chr) || chr == '_')
		{
			LPCOLESTR				start;
			register const WCHAR	*keywords;
			short					result;

			start = currentPtr - 1;

			// Find the end of the identifier
			do
			{
			} while (currentPtr < pstrCode && (iswalpha((chr = *(currentPtr)++)) || iswdigit(chr) || chr == '_'));

			// Check if it's a C keyword
			numChars = currentPtr - start;
			keywords = &Keywords[0];
			while ((ULONG)(*keywords) <= numChars)
			{
				if (*keywords == numChars)
				{
					if (!(result = memcmp(start, keywords + 1, numChars * sizeof(WCHAR))))
					{
						result = SOURCETEXT_ATTR_KEYWORD;
						goto finish;
					}

					if (result < 0) break;
				}

				keywords += (*keywords + 2);
			}

			// If it's not a keyword, then it's an identifier
//			result = SOURCETEXT_ATTR_IDENTIFIER;
			result = SOURCETEXT_ATTR_NONSOURCE;

finish:		while (numChars--) *(pattr)++ = (SOURCE_TEXT_ATTR)result;
		}

		// a Number starts with a numerical character
		//0[xX][a-fA-F0-9]+{u|U|l|L}
		//0{D}+{u|U|l|L}
		else if (iswdigit(chr))
		{
			*(pattr)++ = SOURCETEXT_ATTR_NUMBER;

			if (chr == '0' && currentPtr < pstrCode && (*(currentPtr+1) == 'x' || *(currentPtr+1) == 'X'))
			{
				goto numstart;
				while (++currentPtr < pstrCode && (iswdigit((chr = *currentPtr)) || (*currentPtr >= 'a' && *currentPtr <= 'f') || (*currentPtr >= 'A' && *currentPtr <= 'F')))
numstart:			*(pattr)++ = SOURCETEXT_ATTR_NUMBER;

				if (currentPtr < pstrCode && (chr == 'u' || chr == 'U'))
				{
					*(pattr)++ = SOURCETEXT_ATTR_NUMBER;
					chr = *(currentPtr)++;
				}

				if (currentPtr < pstrCode && (chr == 'l' || chr == 'L'))
				{
					*(pattr)++ = SOURCETEXT_ATTR_NUMBER;
					++currentPtr;
				}
			}
			else
			{
				while (++currentPtr < pstrCode && iswdigit((chr = *currentPtr)))
					*(pattr)++ = SOURCETEXT_ATTR_NUMBER;

				if (chr == 'E' || chr == 'e') goto flt;

				if (chr == '.')
				{
					do
					{
						*(pattr)++ = SOURCETEXT_ATTR_NUMBER;
					} while (++currentPtr < pstrCode && iswdigit((chr = *currentPtr)));
	
					if (chr == 'E' || chr == 'e')
					{
flt:					do
						{
							*(pattr)++ = SOURCETEXT_ATTR_NUMBER;
						} while (++currentPtr < pstrCode && iswdigit((chr = *currentPtr)));
	
						if (currentPtr < pstrCode && (chr == 'f' || chr == 'F' || chr == 'l' || chr == 'L'))
						{
							*(pattr)++ = SOURCETEXT_ATTR_NUMBER;
							++currentPtr;
						}
					}
				}
			}
		}
			
		// A String literal starts with a double or single quote
		else if (chr == '\"' || chr == '\'')
		{
			register unsigned char	flag;

			goto quote;
			while (++currentPtr < pstrCode && (flag || *currentPtr != chr))
			{
				if (*currentPtr == '\r' || *currentPtr == '\n')
					*(pattr)++ = 0;
				else
				{
					if (*currentPtr == '\\' && !flag)
						flag = 1;
					else
quote:					flag = 0;
					*(pattr)++ = SOURCETEXT_ATTR_STRING;
				}
			}

			// Consume the final quote mark
			if (currentPtr >= pstrCode) goto out;
			*(pattr)++ = SOURCETEXT_ATTR_STRING;
		}

		// Divide or comment?
		else if (*currentPtr == '/')
		{
			if (currentPtr >= pstrCode) goto div;
			chr = *currentPtr;

			// A comment?
			if (chr == '//' || chr == '*')
			{
				// Mark the comment slash
				*(pattr)++ = SOURCETEXT_ATTR_COMMENT;

				if (chr == '/')
				{
					while (++currentPtr < pstrCode && *currentPtr != '\n') *(pattr)++ = SOURCETEXT_ATTR_COMMENT;
				}

				else if (currentPtr < pstrCode)
				{
					unsigned char	flag;

					flag = 0;

					// Mark the opening '*'
					goto begin;

					// Loop through the characters till we hit '*/'
					while (!flag || *currentPtr != '/')
					{
			begin:		*(pattr)++ = SOURCETEXT_ATTR_COMMENT;

						if (++currentPtr >= pstrCode) goto out;

						flag = 0;
						if (*currentPtr == '*') flag = 1;
					}

					*(pattr)++ = SOURCETEXT_ATTR_COMMENT;
				}
			}
			else
			{

				// If not a comment, this could be a division assignment /=
				if (chr == '=')
				{
					*(pattr)++ = SOURCETEXT_ATTR_OPERATOR;
					if (++currentPtr >= pstrCode) goto out;
				}

				// A plain division
div:			*(pattr)++ = SOURCETEXT_ATTR_OPERATOR;
			}
		}

		// See if a C operator such as ++, ==, etc
		else
  		{
			register SOURCE_TEXT_ATTR		color;

			color = SOURCETEXT_ATTR_OPERATOR;

			if (chr == '>' || chr == '<')
			{
				*(pattr)++ = color;
				if (++currentPtr >= pstrCode) goto out;

				if (*currentPtr == chr)
				{	
					*(pattr)++ = color;
					++currentPtr;
				}

				goto chkequal;
			}

			else if (chr == '+' || chr == '-' || chr == '&' || chr == '|')
			{
				*(pattr)++ = color;
				if (++currentPtr >= pstrCode) goto out;

				if (*currentPtr != chr) goto chkequal2;
				++currentPtr;
			}

			else if (chr == '*' || chr == '^' || chr == '%' || chr == '=' || chr == '!')
			{
				*(pattr)++ = color;

chkequal:		if (++currentPtr >= pstrCode) goto out;
chkequal2:		if (*currentPtr != '=') continue;
				++currentPtr;
			}

			//";"
			else if (chr != ';'  && chr != '{' && chr != '}' && chr != ',' && chr != ':' && chr != '(' && chr != ')' &&
				chr != '['  && chr != ']' && chr != '.' && chr != '~' && chr != '?')
			{
				// If we get here, we've hit a character we don't recognize
				// Mark the character as non-source
				color = SOURCETEXT_ATTR_NONSOURCE;
			}

			*(pattr)++ = color;
		}
	}

out:
	UNLOGFUNC();
	return(S_OK);
}

/***************** EnumCodeContextsOfPosition() ****************
 * Retrieves our IEnumDebugCodeContexts enumerator for all the
 * IDebugCodeContexts associated with a given host "context"
 * between a start and end source code position.
 *
 * context =	The host context that was passed to our
 *				ActiveScriptParse's ParseScriptText or AddScriptlet
 *				when the code was added (ie, CINSTRUCTIONs were created).
 * charOffset =	The offset from the beginning of the script block where the
 *				enumerator should begin looking for IDebugCodeContext's.
 * count =		The number of chars whose IDebugCodeContext's should be
 *				included in the enumeration.
 * pObj =		Where to return our IEnumDebugCodeContexts.
 */

static STDMETHODIMP EnumCodeContextsOfPosition(IActiveScriptDebug *this, DWORD context, ULONG charOffset, ULONG count, IEnumDebugCodeContexts **pObj)
{
	register HRESULT	hr;
	ACTIVESCRIPT		*activeScript;

	activeScript = (ACTIVESCRIPT *)((unsigned char *)this - offsetof(ACTIVESCRIPT, ActiveScriptDebug));

	LOGFUNC("IActiveScriptDebug::EnumCodeContextsOfPosition");

	if (IsBadWritePtr(activeScript, sizeof(ACTIVESCRIPT)) /* || IsBadWritePtr(pObj, sizeof(void *)) */)
		hr = E_POINTER;

	// Search through all the interpreters for the one with the specified host context.
	// NOTE: We assume that each interpreter has a different host context. This is not
	// necessarily an accurate assumption!!!
	else
	{
		register CINTERPRETER		*interpreter;

		hr = E_FAIL;
		interpreter = activeScript->InterpreterList;
		while (interpreter)
		{
			register CINSTRUCTION	*instruction;

			// Scan the instruction list looking for the given context and offset
			instruction = interpreter->InstructionList;
			while (instruction)
			{
				// Found the context yet?
				if (instruction->OpCode == OPCODE_CONTEXT && context == *((DWORD *)((unsigned char *)instruction + sizeof(CINSTRUCTION))))
				{
					// Yes. Now look for the desired position (until we run out of CINSTRUCTIONs
					// or hit a different context)
					instruction = instruction->Next;
					while (instruction && (instruction->OpCode != OPCODE_CONTEXT || context == *((DWORD *)((unsigned char *)instruction + sizeof(CINSTRUCTION)))))
					{
						unsigned char	*token;

						if (instruction->OpCode != OPCODE_CONTEXT)
						{
							token = (unsigned char *)instruction;
							if (instruction->Flags & INSTRUCTION_HAS_LABEL) token -= sizeof(LPOLESTR *);
							token -= sizeof(CTOKEN);

							if (((CTOKEN *)token)->CharOffset >= charOffset)
							{
								// Alloc/return an IEnumDebugCodeContexts for this CINSTRUCTION
								if ((*pObj = allocIEnumDebugCodeContexts(instruction, activeScript->HostScriptSiteDebug, context))) hr = S_OK;
								goto out;
							}
						}

						instruction = instruction->Next;
					}

					// Not found
					break;
				}

				instruction = instruction->Next;
			}

			interpreter = interpreter->Next;
		}
	}
out:
	UNLOGFUNC();
	return(hr);
} 
