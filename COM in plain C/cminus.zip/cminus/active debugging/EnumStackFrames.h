#ifndef _ENUMDEBUGSTACKFRAMES_H_
#define _ENUMDEBUGSTACKFRAMES_H_

extern const IDebugStackFrameSnifferVtbl IDebugStackFrameSniffer_Vtbl;

#endif