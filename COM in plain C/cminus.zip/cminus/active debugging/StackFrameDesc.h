#ifndef _DEBUGSTACKFRAMEDESCRIPTOR_H_
#define _DEBUGSTACKFRAMEDESCRIPTOR_H_

#include "../Active Engine/CInterpreter.h"
#include "../Interpreter/ScriptVariant.h"
#include "../Interpreter/CInstruction.h"

// Wraps only the pertinent information we require in a DebugStackFrameDescriptor
typedef struct _DEBUGSTACKFRAMEDESCRIPTOR {
	const IDebugStackFrameVtbl			*DebugStackFrame;			// Our IDebugStackFrame VTable for this DEBUGSTACKFRAMEDESCRIPTOR. Must be first!
	const IDebugExpressionContextVtbl	*DebugExpressionContext;	// Our IDebugExpressionContext VTable.
	DWORD						FrameAddress;	// Address of the function called.
	struct _CINTERPRETER		*Interpreter;	// CINTERPRETER that contains the called function.
	CINSTRUCTION				*Instruction;	// Currently executing CINSTRUCTION at this level.
	LPCOLESTR					Name;			// Name of function called when this struct created. Borrowed from someone else.
} DEBUGSTACKFRAMEDESCRIPTOR;

extern const IDebugStackFrameVtbl IDebugStackFrame_Vtbl;
extern const IDebugExpressionContextVtbl IDebugExpressionContext_Vtbl;

#endif