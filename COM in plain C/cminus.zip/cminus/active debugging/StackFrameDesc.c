/*
 * Functions for our IDebugStackFrame, IDebugExpressionContext,
 * IDebugExpression, and IDebugProperty (for the IDebugExpression)
 * COM objects.
 */

#define INC_OLE2
#define CONST_VTABLE
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <stddef.h>
#include <objbase.h>
#include <activscp.h>
#include <activdbg.h>
#include "../TraceWin.h"
#include "../IClassFactory.h"
#include "../Guids.h"
#include "../Interpreter/ScriptVariant.h"
#include "../Active Engine/ActiveScript.h"
#include "EnumSymbols.h"
#include "StackFrameDesc.h"
#include "IDebugCodeContext.h"





// Our IDebugStackFrame VTable
static STDMETHODIMP QueryInterface(DEBUGSTACKFRAMEDESCRIPTOR *, REFIID, void **);
static STDMETHODIMP_(ULONG) AddRef(DEBUGSTACKFRAMEDESCRIPTOR *);
static STDMETHODIMP_(ULONG) Release(DEBUGSTACKFRAMEDESCRIPTOR *);
static STDMETHODIMP GetCodeContext(DEBUGSTACKFRAMEDESCRIPTOR *, IDebugCodeContext **); 
static STDMETHODIMP GetDescriptionString(DEBUGSTACKFRAMEDESCRIPTOR *, BOOL, BSTR *); 
static STDMETHODIMP GetLanguageString(DEBUGSTACKFRAMEDESCRIPTOR *, BOOL, BSTR *);
static STDMETHODIMP GetThread(DEBUGSTACKFRAMEDESCRIPTOR *, IDebugApplicationThread **);
static STDMETHODIMP GetDebugProperty(DEBUGSTACKFRAMEDESCRIPTOR *, IDebugProperty **);

const IDebugStackFrameVtbl IDebugStackFrame_Vtbl = {QueryInterface,
AddRef,
Release,
GetCodeContext,
GetDescriptionString,
GetLanguageString,
GetThread,
GetDebugProperty};

// Our IDebugExpressionContext VTable
static STDMETHODIMP CntQueryInterface(IDebugExpressionContext *, REFIID, void **);
static STDMETHODIMP_(ULONG) CntAddRef(IDebugExpressionContext *);
static STDMETHODIMP_(ULONG) CntRelease(IDebugExpressionContext *);
static STDMETHODIMP ParseLanguageText(IDebugExpressionContext *, LPCOLESTR, UINT, LPCOLESTR, DWORD, IDebugExpression **); 
static STDMETHODIMP GetLanguageInfo(IDebugExpressionContext *, BSTR *, GUID *);

const IDebugExpressionContextVtbl IDebugExpressionContext_Vtbl = {CntQueryInterface,
CntAddRef,
CntRelease,
ParseLanguageText,
GetLanguageInfo};

typedef struct {
	const IDebugExpressionVtbl	*lpVtbl;
	DWORD						RefCount;
	DEBUGSTACKFRAMEDESCRIPTOR	*Desc;
	SCRIPTVARIANT				*Result;
	CINSTRUCTION				*FirstInstruction;
} DEBUGEXPRESSION;

// Our IDebugExpression VTable
static STDMETHODIMP ExQueryInterface(DEBUGEXPRESSION *, REFIID, void **);
static STDMETHODIMP_(ULONG) ExAddRef(DEBUGEXPRESSION *);
static STDMETHODIMP_(ULONG) ExRelease(DEBUGEXPRESSION *);
static STDMETHODIMP Start(DEBUGEXPRESSION *, IDebugExpressionCallBack *);
static STDMETHODIMP Abort(DEBUGEXPRESSION *);
static STDMETHODIMP QueryIsComplete(DEBUGEXPRESSION *); 
static STDMETHODIMP GetResultAsString(DEBUGEXPRESSION *, HRESULT *, BSTR *); 
static STDMETHODIMP GetResultAsDebugProperty(DEBUGEXPRESSION *, HRESULT *, IDebugProperty **); 

static const IDebugExpressionVtbl IDebugExpression_Vtbl = {ExQueryInterface,
ExAddRef,
ExRelease,
Start,
Abort,
QueryIsComplete,
GetResultAsString,
GetResultAsDebugProperty};

typedef struct {
	const IDebugPropertyVtbl	*lpVtbl;
	DWORD						RefCount;
	DEBUGEXPRESSION				*Parent;
} DEBUGRESULTPROPERTY;

// Our IDebugProperty VTable
static STDMETHODIMP PropQueryInterface(DEBUGRESULTPROPERTY *, REFIID, void **);
static STDMETHODIMP_(ULONG) PropAddRef(DEBUGRESULTPROPERTY *);
static STDMETHODIMP_(ULONG) PropRelease(DEBUGRESULTPROPERTY *);
static STDMETHODIMP GetPropertyInfo(DEBUGRESULTPROPERTY *, DWORD, UINT, DebugPropertyInfo *);
static STDMETHODIMP GetExtendedInfo(DEBUGRESULTPROPERTY *, ULONG, GUID *, VARIANT *);
static STDMETHODIMP SetValueAsString(DEBUGRESULTPROPERTY *, LPCOLESTR, UINT);
static STDMETHODIMP EnumMembers(DEBUGRESULTPROPERTY *, DWORD, UINT, REFIID, IEnumDebugPropertyInfo **);
static STDMETHODIMP EGetParent(DEBUGRESULTPROPERTY *, IDebugProperty **);

static const IDebugPropertyVtbl IDebugProperty_Vtbl = {PropQueryInterface,
PropAddRef,
PropRelease,
GetPropertyInfo,
GetExtendedInfo,
SetValueAsString,
EnumMembers,
EGetParent};

#ifdef LOGTRACE
static unsigned char LogFlag2 = 0;
#endif






//==============================================================================
// The IDebugStackFrame manages the logical (call) stack frame within the
// script engine. It lets the host identify the script engine, obtain the
// DebugApplicationThread, and browse the names of called functions in this
// stack frame.
//==============================================================================

/************************ QueryInterface() *************************
 */

static STDMETHODIMP QueryInterface(DEBUGSTACKFRAMEDESCRIPTOR *this, REFIID riid, void **ppvObj)
{
#ifdef LOGTRACE
	if (!LogFlag2) LOGFUNC("IDebugStackFrame::QueryInterface");
#endif

//	if (!IsBadWritePtr(ppvObj, sizeof(void *)))
//	{
		*ppvObj = 0;

		if (!IsBadWritePtr(this, sizeof(DEBUGSTACKFRAMEDESCRIPTOR)))
		{
			if (IsEqualIID(riid, &IID_IUnknown) || IsEqualIID(riid, &IID_IDebugStackFrame))
			{
				*ppvObj = this;
add:
#ifdef LOGTRACE
				LogFlag2 = 1;
#endif
				AddRef(this);
				return(NOERROR);
			}

			if (IsEqualIID(riid, &IID_IDebugExpressionContext))
			{
				*ppvObj = (void *)((unsigned char *)this + offsetof(DEBUGSTACKFRAMEDESCRIPTOR, DebugExpressionContext));
				goto add;
			}

			return(queryActiveScriptInterface((ACTIVESCRIPT *)this->Interpreter->Parent, riid, ppvObj));
		}
//	}

	UNLOGFUNC();
	return(E_POINTER);
}

/*************************** AddRef() ******************************
 */

static STDMETHODIMP_(ULONG) AddRef(DEBUGSTACKFRAMEDESCRIPTOR *this)
{
#ifdef LOGTRACE
	if (!LogFlag2) LOGFUNC("IDebugStackFrame::AddRef");
	LogFlag2 = 0;
#endif

	// Increment refCount of ACTIVESCRIPT
	return(incActiveScriptRefcount((ACTIVESCRIPT *)this->Interpreter->Parent));
}

/************************** Release() ******************************
 */

static STDMETHODIMP_(ULONG) Release(DEBUGSTACKFRAMEDESCRIPTOR *this)
{
	if (!IsBadWritePtr(this, sizeof(DEBUGSTACKFRAMEDESCRIPTOR)))
	{
#ifdef LOGTRACE
		if (!LogFlag2) LOGFUNC("IDebugStackFrame::Release");
		LogFlag2 = 0;
#endif
		// Decrement refCount of ACTIVESCRIPT
		return(decActiveScriptRefcount((ACTIVESCRIPT *)this->Interpreter->Parent));
	}

	UNLOGFUNC();
	return(0);
}





/*********************** GetCodeContext() ************************
 * Returns the IDebugCodeContext of this DEBUGSTACKFRAMEDESCRIPTOR.
 * This is used to get info about the current CINSTRUCTION
 * executing at this DEBUGSTACKFRAMEDESCRIPTOR's respective
 * script level.
 *
 * pObj =	Where to return our IDebugCodeContext.
 */

static STDMETHODIMP GetCodeContext(DEBUGSTACKFRAMEDESCRIPTOR *this, IDebugCodeContext **pObj)
{
	register HRESULT	hr;
	CINTERPRETER		*interpreter;

	LOGFUNC("IDebugStackFrame::GetCodeContext");

	if (/* IsBadWritePtr(pObj, sizeof(void *)) || */ IsBadWritePtr(this, sizeof(DEBUGSTACKFRAMEDESCRIPTOR)))
		hr = E_POINTER;
	else
	{
		register CINSTRUCTION	*instruction;
		register DWORD			context;

		// Assume an error
		*pObj = (IDebugCodeContext *)context = 0;

		// We need to first locate the context for this CINSTRUCTION. Rather than storing the context
		// in each CINSTRUCTION, we store the context (DWORD) once-only in an OPCODE_CONTEXT CINSTRUCTION.
		// Then all of the following CINSTRUCTIONs (up to another OPCODE_CONTEXT) have that same context.
		// The loop below also succeeds in checking that the CINSTRUCTION is still valid
		interpreter = this->Interpreter;
		if (!IsBadWritePtr(interpreter, sizeof(CINTERPRETER)))
		{
			hr = E_UNEXPECTED;
			
			instruction = interpreter->InstructionList;
			while (instruction)
			{
				if (instruction->OpCode == OPCODE_CONTEXT)
					context = *((DWORD *)((unsigned char *)instruction + sizeof(CINSTRUCTION)));
				if (this->Instruction == instruction)
				{
					// Get an IDebugCodeContext for this CINSTRUCTION
					hr = E_OUTOFMEMORY;
					if ((*pObj = allocIDebugCodeContext(instruction, interpreter->Parent->HostScriptSiteDebug, context))) hr = S_OK;
					break;
				}

				instruction = instruction->Next;
			}
		}
	}

	LOGHEXPARAM("Returns", hr);
	UNLOGFUNC();
	return(hr);
}





/********************* GetDescriptionString() ******************
 * Returns a description (string) of this stack frame. If full
 * is false, then it only returns the name of the stack frame.
 * If full is true, then it may also return function parameters
 * or other relevant information.
 *
 * full =	Whether to return parameters or other context information.
 * desc =	Where to return the description BSTR.
 */

static STDMETHODIMP GetDescriptionString(DEBUGSTACKFRAMEDESCRIPTOR *this, BOOL full, BSTR *desc)
{
	register HRESULT			hr;

	LOGFUNC("IDebugStackFrame::GetDescriptionString");

	if (/* IsBadWritePtr(desc, sizeof(BSTR *)) || */ IsBadWritePtr(this, sizeof(DEBUGSTACKFRAMEDESCRIPTOR)))
		hr = E_POINTER;
	else
	{
		hr = E_OUTOFMEMORY;

		// The description string is rather arbitrary. Let's use the name of the 
		// script function that was being executed when this stack frame was created
		if ((*desc = SysAllocString(this->Name))) hr = S_OK;
	}

	LOGHEXPARAM("Returns", hr);
	UNLOGFUNC();
	return(hr);
}





/********************* GetLanguageString() *********************
 * Returns a short or long textual description of the language.
 * When full is false, just the language name should be 
 * provided, eg, "Pascal". When full is true, a full product
 * description may be provided, eg, "Gnat Software's Flaming
 * Pascal v3.72".
 *
 * full =	Whether or not to return full description of the language.
 * lang =	Where to return the engine language BSTR.
 */

static STDMETHODIMP GetLanguageString(DEBUGSTACKFRAMEDESCRIPTOR *this, BOOL full, BSTR *lang)
{
	register const WCHAR	*str;

	LOGFUNC("IDebugStackFrame::GetLanguageString");

	if (full)
		str = &FullEngineLanguageStr[0];
	else
		str = &ShortEngineLanguageStr[0];

	if ((*lang = SysAllocString(str)))
	{
		LOGHEXPARAM("Returns", S_OK);
		UNLOGFUNC();
		return(S_OK);
	}

	UNLOGFUNC();
	return(E_OUTOFMEMORY);
}





/************************* GetThread() ***********************
 * Returns the thread associated with this stack frame.
 *
 * pObj =	 Where to return our IDebugApplicationThread.
 */

static STDMETHODIMP GetThread(DEBUGSTACKFRAMEDESCRIPTOR *this, IDebugApplicationThread **pObj)
{
	LOGFUNC("IDebugStackFrame::GetThread");
	UNLOGFUNC();

	// Just return the thread we got from the host (when we called its
	// IDebugApplication's GetBreakFlags in our IActiveScript's SetScriptSite)
	return(this->Interpreter->Parent->HostDebugThread->lpVtbl->QueryInterface(this->Interpreter->Parent->HostDebugThread, &IID_IDebugApplicationThread, (void **)pObj));
}





/*********************** GetDebugProperty() ********************
 * Returns a IDebugProperty for this stack frame. The host can
 * use our IDebugProperty to enumerate the script variables at
 * the respective script level for this DEBUGSTACKFRAMEDESCRIPTOR.
 *
 * pObj =	 Where to return our IDebugProperty.
 */

static STDMETHODIMP GetDebugProperty(DEBUGSTACKFRAMEDESCRIPTOR *this, IDebugProperty **pObj)
{
	register HRESULT			hr;

	LOGFUNC("IDebugStackFrame::GetDebugProperty");

	// Check the args
	if (/* IsBadWritePtr(pObj, sizeof(void *)) || */ IsBadWritePtr(this, sizeof(DEBUGSTACKFRAMEDESCRIPTOR)))
		hr = E_POINTER;
	else
	{
		hr = E_OUTOFMEMORY;

		// The IDebugProperty here is meant to allow browsing of the current data
		// associated with this function level. Therefore, the IDebugProperty
		// is an enumerator for its symbol table
		if ((*pObj = allocDebugStackedSymbols(this))) hr = S_OK;
	}

	LOGHEXPARAM("Returns", hr);
	UNLOGFUNC();
	return(hr);
} 

















//==============================================================================
// The IDebugExpressionContext is a sub-object of the IDebugStackFrame. (ie,
// The IDebugExpressionContext is gotten from the IDebugStackFrame's
// QueryInterface). IDebugExpressionContext allows expressions to be evaluated
// in the context of this stack frame. This means that script functions can be
// called and variables queried/set. It also creates our IDebugExpression to
// let the script get the results of the evaluation.
//==============================================================================


/************************ QueryInterface() *************************
 */

static STDMETHODIMP CntQueryInterface(IDebugExpressionContext *this, REFIID riid, void **ppvObj)
{
#ifdef LOGTRACE
	LOGFUNC("IDebugExpressionContext::QueryInterface");
	LogFlag2 = 1;
#endif

	return(QueryInterface((DEBUGSTACKFRAMEDESCRIPTOR *)((unsigned char *)this - offsetof(DEBUGSTACKFRAMEDESCRIPTOR, DebugExpressionContext)), riid, ppvObj));
}

/*************************** AddRef() ******************************
 */

static STDMETHODIMP_(ULONG) CntAddRef(IDebugExpressionContext *this)
{
#ifdef LOGTRACE
	LOGFUNC("IDebugExpressionContext::AddRef");
	LogFlag2 = 1;
#endif

	return(AddRef((DEBUGSTACKFRAMEDESCRIPTOR *)((unsigned char *)this - offsetof(DEBUGSTACKFRAMEDESCRIPTOR, DebugExpressionContext))));
}

/************************** Release() ******************************
 */

static STDMETHODIMP_(ULONG) CntRelease(IDebugExpressionContext *this)
{
#ifdef LOGTRACE
	LOGFUNC("IDebugExpressionContext::Release");
	LogFlag2 = 1;
#endif

	return(Release((DEBUGSTACKFRAMEDESCRIPTOR *)((unsigned char *)this - offsetof(DEBUGSTACKFRAMEDESCRIPTOR, DebugExpressionContext))));
}





/********************* ParseLanguageText() ***********************
 * Takes a script expression and creates an IDebugExpression based
 * on it. This allows expressions to be evaluated.
 *
 * pstrCode =	The script expression to be evaluated
 * radix =		The radix to use.   (eg. "x = 0x5" radix is 16)
 *				(eg. "x = 101" radix is 2)
 * delim =		The delimiter the host used to detect the end of the scriptlet
 * flags =		SCRIPTTEXT_DELAYEXECUTION 
 *				SCRIPTTEXT_ISVISIBLE
 *				SCRIPTTEXT_ISEXPRESSION
 *				SCRIPTTEXT_ISPERSISTENT
 *				SCRIPTTEXT_HOSTMANAGESSOURCE
 * pObj			Where to return our IDebugExpression.
 */

static STDMETHODIMP ParseLanguageText(IDebugExpressionContext *this, LPCOLESTR pstrCode, UINT radix, LPCOLESTR delim, DWORD flags, IDebugExpression **pObj)
{
	register DEBUGSTACKFRAMEDESCRIPTOR	*desc;

	LOGFUNC("IDebugExpressionContext::ParseLanguageText");

	desc = (DEBUGSTACKFRAMEDESCRIPTOR *)((unsigned char *)this - offsetof(DEBUGSTACKFRAMEDESCRIPTOR, DebugExpressionContext));
	if (!IsBadWritePtr(desc, sizeof(DEBUGSTACKFRAMEDESCRIPTOR)))
	{
		register CINTERPRETER		*interpreter;
		register DEBUGEXPRESSION	*exp;
		CINSTRUCTION				*instructionList;

		interpreter = desc->Interpreter;

		radix = E_OUTOFMEMORY;

		// Create a new IDebugExpression (ie, DEBUGEXPRESSION)
		if ((exp = (DEBUGEXPRESSION *)ALLOCMEM(sizeof(DEBUGEXPRESSION))))
		{
			ZeroMemory(exp, sizeof(DEBUGEXPRESSION));
			exp->lpVtbl = &IDebugExpression_Vtbl;
			exp->Desc = desc;

			// Save away CINTERPRETER's orig InstructionList
			instructionList = interpreter->InstructionList;

			// Clear it
			interpreter->InstructionList = 0;

			// Give the text to the DEBUGEXPRESSION to parse
			if (!(radix = createInstructionList(interpreter, pstrCode, 0, 0)))
			{
				// Fill in caller's IDebugExpression ptr. NOTE: This AddRef()'s it for the host
				ExQueryInterface(exp, &IID_IDebugExpression, pObj);

				// Save the instruction list
				exp->FirstInstruction = interpreter->InstructionList;
			}
			else
			{
				FREEMEM(exp);
				*pObj = 0;
			}

			// Restore CINTERPRETER's orig InstructionList
			interpreter->InstructionList = instructionList;
		}
	}
	else
		radix = E_POINTER;

	LOGHEXPARAM("Returns", radix);
	UNLOGFUNC();
	return(radix);
} 





/********************* GetLanguageInfo() **********************
 * Returns the name and GUID of the language which owns this
 * context.
 *
 * langName =	Where to return the language name BSTR.
 * langGUID =	Where to return the language GUID.
 */

static STDMETHODIMP GetLanguageInfo(IDebugExpressionContext *this, BSTR *langName, GUID *langGUID)
{
	register HRESULT			hr;

	LOGFUNC("IDebugExpressionContext::GetLanguageInfo");

//	if (IsBadWritePtr(langName, sizeof(BSTR *)) || IsBadWritePtr(langGUID, sizeof(GUID)))
//		hr = E_POINTER;
//	else
//	{
		CopyMemory(langGUID, &CLSID_CMinus, sizeof(GUID)); 
		if ((*langName = SysAllocString(&ShortEngineLanguageStr[0]))) hr = S_OK;
		else hr = E_OUTOFMEMORY;
//	}

	LOGHEXPARAM("Returns", hr);
	UNLOGFUNC();
	return(hr);
}





















//==============================================================================
// The IDebugExpression is gotten from the IDebugExpressionContext's
// ParseLanguageText(). We should therefore treat it sort of as a sub-object
// of the IDebugStackFrame.
//
// The IDebugExpression allows the result of an expression to be gotten.
//==============================================================================

/************************ QueryInterface() *************************
 */

static STDMETHODIMP ExQueryInterface(DEBUGEXPRESSION *this, REFIID riid, void **ppvObj)
{
#ifdef LOGTRACE
	LOGFUNC("IDebugExpression::QueryInterface");
	LogFlag2 = 1;
#endif

//	if (!IsBadWritePtr(ppvObj, sizeof(void *)))
	{
		*ppvObj = 0;

		if (!IsBadWritePtr(this, sizeof(DEBUGEXPRESSION)))
		{
			if (IsEqualIID(riid, &IID_IUnknown) || IsEqualIID(riid, &IID_IDebugExpression))
			{
				*ppvObj = this;
				ExAddRef(this);
				return(S_OK);
			}

			return(QueryInterface(this->Desc, riid, ppvObj));
		}
	}

	UNLOGFUNC();
	return(E_POINTER);
}

/*************************** AddRef() ******************************
 */

static STDMETHODIMP_(ULONG) ExAddRef(DEBUGEXPRESSION *this)
{
#ifdef LOGTRACE
	if (!LogFlag2) LOGFUNC("IDebugExpression::AddRef");
	LogFlag2 = 1;
#endif

	if (!IsBadWritePtr(this, sizeof(DEBUGEXPRESSION)))
	{
		++this->RefCount;
		return(AddRef(this->Desc));
	}

	UNLOGFUNC();
	return(E_POINTER);
}

/************************** Release() ******************************
 */

static STDMETHODIMP_(ULONG) ExRelease(DEBUGEXPRESSION *this)
{
#ifdef LOGTRACE
	if (!LogFlag2) LOGFUNC("IDebugExpression::Release");
	LogFlag2 = 1;
#endif

	if (!IsBadWritePtr(this, sizeof(DEBUGEXPRESSION)))
	{
		register DEBUGSTACKFRAMEDESCRIPTOR	*ptr;

		ptr = this->Desc;

		if (--this->RefCount == 0)
		{
			if (this->Result) freeScriptVariant(this->Result);

			if (this->FirstInstruction) freeInstructionList(this->FirstInstruction);

			FREEMEM(this);
		}

		return(Release(ptr));
	}
	UNLOGFUNC();
	return(E_POINTER);
}





/************************* Start() *************************
 * Starts the asynchronous evaluation of the expression
 * that has been added to this DEBUGEXPRESSION.
 *
 * Upon completion, the IDebugExpressionCallBack is used to
 * inform the debugger that evaluation is done.
 *
 * hostCallback =	The host's IDebugExpressionCallBack used to
 *					inform it that evaluation is complete.
 */

static STDMETHODIMP Start(DEBUGEXPRESSION *this, IDebugExpressionCallBack *hostCallback)
{
	register HRESULT	hr;

	LOGFUNC("IDebugExpression::Start");

	hr = E_POINTER;

	// Execute the instruction list. This call should be asynchronous, but adding
	// the code necessary to do so would obfuscate the sample. So we just do
	// synchronous
	if (/* !IsBadReadPtr(hostCallback, sizeof(void *)) && */ !IsBadWritePtr(this, sizeof(DEBUGEXPRESSION)) && !IsBadWritePtr(this->Desc, sizeof(DEBUGSTACKFRAMEDESCRIPTOR)))
	{
		register CINSTRUCTION		*instructionList;
		register CINTERPRETER		*interpreter;
		register unsigned char		oldState;

		interpreter = this->Desc->Interpreter;
		if (!IsBadWritePtr(interpreter, sizeof(CINTERPRETER)))
		{
			// Save away CINTERPRETER's orig InstructionList
			instructionList = interpreter->InstructionList;

			// NOTE: We need to locate the CINTERPRETER's SymbolTable to this DEBUGEXPRESSION->Desc's
			// respective CSYMBOLTABLE (saving away any CSYMBOLTABLEs we temporary pop off the stack),
			// and locate the ACTIVESCRIPTDEBUG's StackFrame to this DEBUGEXPRESSION->Desc (also saving
			// any we pop off. After we do evaluateCall(), then we restore. Implement this!!!




			// Set DEBUGEXPRESSION's instruction list
			interpreter->InstructionList = interpreter->CurrentInstruction = this->FirstInstruction;

			// Indicate we're executing a script
			oldState = interpreter->Parent->Flags & ~SCRIPTTHREADSTATE_RUNNING;
			interpreter->Parent->Flags |= SCRIPTTHREADSTATE_RUNNING;

			// Initially, no pending debugger breakpoint
			interpreter->Parent->BreakResumeAction = BREAKRESUMEACTION_CONTINUE;
			
			// Run the instructions
			hr = evaluateCall(interpreter);

			// Restore state
			interpreter->Parent->Flags = (interpreter->Parent->Flags & ~(SCRIPTTHREADSTATE_RUNNING|ACTIVESCRIPTFLAG_HALTRAISED)) | oldState;

			// Restore CINTERPRETER's orig InstructionList
			/* interpreter->CurrentInstruction = */ interpreter->InstructionList = instructionList;

			// Save away any result SCRIPTVARIANT
			if ((this->Result = interpreter->DataStack))
				interpreter->DataStack = interpreter->DataStack->Next;

			// Tell host we're finished
			hostCallback->lpVtbl->onComplete(hostCallback);
		}
	}

	UNLOGFUNC();
	return(hr);
}





/************************** Abort() ************************
 * Aborts the expression evaluation (began by Start()).
 *
 * NOTE: If the expression is actually aborted, then
 * GetResultAsString() and GetResultAsDebugProperty() will
 * return E_ABORT for the HRESULT.
 *
 */

static STDMETHODIMP Abort(DEBUGEXPRESSION *this)
{
	LOGFUNC("IDebugExpression::Abort");
	UNLOGFUNC();

	// It's not possible for us to abort expression evaluation, because by the
	// time this method would be called, we've already completed. If we make
	// Start() asynchronous, then this should be implemented
	return(E_NOTIMPL);
}





/********************* QueryIsComplete() *********************
 * Determines if the expression (began by Start()) has
 * finished evaluating yet.
 *
 * RETURNS: S_FALSE if the expression is still pending, or
 * S_OK if completed.
 */

static STDMETHODIMP QueryIsComplete(DEBUGEXPRESSION *this)
{
	LOGFUNC("IDebugExpression::QueryIsComplete");
	UNLOGFUNC();

	// By the time this method would be called, we've already completed
	// evaluation, so just return S_OK. If we make
	// Start() asynchronous, then this should be implemented
	return(S_OK);
} 





/********************* GetResultAsString() *********************
 * Retrieves the result of the expression evaluation as a BSTR,
 * and the success or failure of the evaluation in an HRESULT.
 *
 * phrResult =	Where to return the HRESULT indicating the success
 *				or failure of the expression evaluation. If
 *				expression evaluation was aborted, this is set to
 *				E_ABORTED.
 * pbstrResult = Where to return the BSTR that is the result of the
 *				expression evaluation.
 */

static STDMETHODIMP GetResultAsString(DEBUGEXPRESSION *this, HRESULT *hResult, BSTR *result)
{
	register HRESULT		hr;

	LOGFUNC("IDebugExpression::GetResultAsString");

	hr = E_POINTER;

	if (/* !IsBadWritePtr(hResult, sizeof(HRESULT)) && !IsBadWritePtr(result, sizeof(BSTR *)) && */ !IsBadWritePtr(this, sizeof(DEBUGEXPRESSION)))
	{
		// If the expression was aborted, hResult should be set to E_ABORTED
		*hResult = hr = S_OK;

		// Make sure there's a result value. If not, indicate an unexpected failure
		if (!this->Result)
		{
			hr = E_UNEXPECTED;
			*result = 0;
		}
		else
		{
			// Give the host a BSTR version of the result
			if (!(*result = variantToString(this->Result->Value)))
				hr = E_OUTOFMEMORY;
		}
	}

	UNLOGFUNC();
	return(hr);
} 





/******************** GetResultAsDebugProperty() ********************
 * Retrieves the result of the expression evaluation as an
 * IDebugProperty, and the success or failure of the evaluation in an
 * HRESULT.
 *
 * phrResult =	Where to return the HRESULT indicating the success
 *				or failure of the expression evaluation. If
 *				expression evaluation was aborted, this is set to
 *				E_ABORTED.
 * pObj =		Where to return our IDebugProperty wrapping the
 *				expression evaluation VARIANT.
 */

static STDMETHODIMP GetResultAsDebugProperty(DEBUGEXPRESSION *this, HRESULT *hResult, IDebugProperty **pObj)
{
	register HRESULT		hr;

	LOGFUNC("IDebugExpression::GetResultAsDebugProperty");

	hr = E_POINTER;

	if (/* !IsBadWritePtr(hResult, sizeof(HRESULT)) && !IsBadWritePtr(pObj, sizeof(void *)) && */ !IsBadWritePtr(this, sizeof(DEBUGEXPRESSION)))
	{
		// If the expression was aborted, hResult should be set to E_ABORTED
		*hResult = hr = S_OK;

		// Make sure there's a result value. If not, indicate an unexpected failure
		if (!this->Result)
		{
			hr = E_UNEXPECTED;
			*pObj = 0;
		}
		else
		{
			register DEBUGRESULTPROPERTY *obj;

			// Create a new IDebugProperty (ie, DEBUGRESULTPROPERTY) to allow the host
			// to query the result of our expression evaluation
			if ((obj = (DEBUGRESULTPROPERTY *)ALLOCMEM(sizeof(DEBUGRESULTPROPERTY))))
			{
				ZeroMemory(obj, sizeof(DEBUGRESULTPROPERTY));
				obj->lpVtbl = &IDebugProperty_Vtbl;
				obj->Parent = this;
				PropQueryInterface(obj, &IID_IDebugProperty, pObj);
				hr = S_OK;
			}
			else
				hr = E_OUTOFMEMORY;
		}
	}

	UNLOGFUNC();
	return(hr);
}























//==============================================================================
// This IDebugProperty is gotten from the IDebugExpression's
// GetResultAsDebugProperty(). We should therefore treat it sort of as a sub-object
// of the IDebugStackFrame.
//
// The IDebugProperty allows the result of an expression to be queried in more
// detail than from the IDebugExpression. Wow, this debugger API is really
// ill-conceived and illogically laid out.
//==============================================================================

/************************ QueryInterface() *************************
 */

static STDMETHODIMP PropQueryInterface(DEBUGRESULTPROPERTY *this, REFIID riid, void **ppvObj)
{
	LOGFUNC("IDebugProperty (result)::QueryInterface");

//	if (!IsBadWritePtr(ppvObj, sizeof(void *)))
	{
		*ppvObj = 0;
		
		if (!IsBadWritePtr(this, sizeof(DEBUGRESULTPROPERTY)))
		{
			if (IsEqualIID(riid, &IID_IUnknown) || IsEqualIID(riid, &IID_IDebugProperty))
			{
				*ppvObj = this;
#ifdef LOGTRACE
				LogFlag2 = 1;
#endif
				PropAddRef(this);
				return(S_OK);
			}

			return(QueryInterface(this->Parent->Desc, riid, ppvObj));
		}
	}

	UNLOGFUNC();
	return(E_POINTER);
}

/*************************** AddRef() ******************************
 */

static STDMETHODIMP_(ULONG) PropAddRef(DEBUGRESULTPROPERTY *this)
{
#ifdef LOGTRACE
	if (!LogFlag2) LOGFUNC("IDebugProperty (result)::AddRef");
#endif
	if (!IsBadWritePtr(this, sizeof(DEBUGRESULTPROPERTY)))
	{
		++this->RefCount;
		return(ExAddRef(this->Parent));
	}

	UNLOGFUNC();
	return(E_POINTER);
}

/************************** Release() ******************************
 */

static STDMETHODIMP_(ULONG) PropRelease(DEBUGRESULTPROPERTY *this)
{
	LOGFUNC("IDebugProperty (result)::Release");

	if (!IsBadWritePtr(this, sizeof(DEBUGRESULTPROPERTY)))
	{
		register DEBUGEXPRESSION	*parent;

		parent = this->Parent;

		if (!(--this->RefCount)) FREEMEM(this);

#ifdef LOGTRACE
		LogFlag2 = 1;
#endif
		return(ExRelease(parent));
	}

	UNLOGFUNC();
	return(E_POINTER);
}





/*********************** GetPropertyInfo() ***********************
 * Retrieves information about the result of an evaluation of some
 * "script expression".
 *
 * fieldSpec =	DBGPROP_INFO_FLAGS specifying which information 
 *				the host wants set into its DebugPropertyInfo.
 * radix =		The radix in which to retrieve information 
 *				(eg. 16 = Hex, 2 = Binary).
 * propInfo =	Host's DebugPropertyInfo struct to fill in.
 */

static STDMETHODIMP GetPropertyInfo(DEBUGRESULTPROPERTY *this, DWORD fieldSpec, UINT radix, DebugPropertyInfo *propInfo)
{
	register HRESULT		hr;

	LOGFUNC("IDebugProperty (result)::GetPropertyInfo");

	hr = E_POINTER;

	// Check args
	if (/* !IsBadWritePtr(propInfo, sizeof(DebugPropertyInfo)) && */ !IsBadWritePtr(this, sizeof(DEBUGRESULTPROPERTY)))
	{
		ZeroMemory(propInfo, sizeof(DebugPropertyInfo));
		hr = S_OK;

		// Fill in the DebugPropertyInfo fields that the caller has requested
		// us to fill in (by setting the appropriate bits in fieldSpec). The
		// only fields valid for an expression result are PROP_INFO_TYPE and
		// PROP_INFO_VALUE
		if (fieldSpec & PROP_INFO_TYPE)
		{
			// Fill in the type
			if (!(propInfo->m_bstrType = makeTypeString(this->Parent->Result->Value))) goto badmem;

			// Indicate the type field is filled in
			propInfo->m_dwValidFields = PROP_INFO_TYPE;
		}

		if (fieldSpec & PROP_INFO_VALUE)
		{
			if (!(propInfo->m_bstrValue = variantToString(this->Parent->Result->Value)))
			{
				if (propInfo->m_bstrType) SysFreeString(propInfo->m_bstrType);
				propInfo->m_bstrType = 0;
				propInfo->m_dwValidFields = 0;
badmem:			hr = E_OUTOFMEMORY;
				goto out;
			}

			// Indicate the value field is filled in
			propInfo->m_dwValidFields |= PROP_INFO_VALUE;
		}
	}

out:	
	LOGHEXPARAM("Returns", hr);
	UNLOGFUNC();
	return(hr);
}





/********************** GetExtendedInfo() *********************
 * Retrieves information that does not lend itself to being
 * stored in a DebugPropertyInfo structure.
 *
 * cInfos =		The number of extended infos to retrieve.
 * guids =		Array of GUIDs of the extended info to retrieve.
 * rgvar =		Array of VARIANT's to contain the extended info.
 */

static STDMETHODIMP GetExtendedInfo(DEBUGRESULTPROPERTY *this, ULONG cInfos, GUID *guids, VARIANT *rgvar)
{
	LOGFUNC("IDebugProperty (result)::GetPropertyInfo");
	UNLOGFUNC();

	// We don't currently support extended info
	return(E_NOTIMPL);
}





/********************** SetValueAsString() *********************
 * Takes an LPCOLESTR which contains a string representation of
 * the desired value and uses it to reset the value of this
 * property.
 *
 * pszValue =	The new value of this property
 * radix =		The radix of the value in pszValue 
 *				(eg. 16 = Hex, 2 = Binary )
 */

static STDMETHODIMP SetValueAsString(DEBUGRESULTPROPERTY *this, LPCOLESTR pszValue, UINT radix)
{
	LOGFUNC("IDebugProperty (result)::SetValueAsString");
	UNLOGFUNC();

	// Since this is the value of an evaluated expression, it's meaningless to
	// change it's value in the general case
	return(E_NOTIMPL);
}





/*********************** EnumMembers() ********************
 * Creates/returns an IEnumDebugPropertyInfo that the host
 * uses to enumerate of all the sub-properties of this
 * property.
 *
 * fieldSpec =	The subset of members to retrieve
 * radix =		The radix in which to retrieve information 
 *				(eg. 16 = Hex, 2 = Binary)
 * refiid =		Reserved, must be NULL.
 * pObj =		Where to return our IEnumDebugPropertyInfo.
 */

static STDMETHODIMP EnumMembers(DEBUGRESULTPROPERTY *this, DWORD fieldSpec, UINT radix, REFIID refiid, IEnumDebugPropertyInfo **pObj)
{
	LOGFUNC("IDebugProperty (result)::EnumMembers");
	UNLOGFUNC();

	// There are no members for this property. It's just property info
	*pObj = 0;
	return(E_NOTIMPL);
}





/************************* EGetParent() **********************
 * Returns the parent IDebugProperty of this IDebugProperty,
 * if it's available.
 *
 * pObj = Where to return the parent IDebugProperty.
 */

static STDMETHODIMP EGetParent(DEBUGRESULTPROPERTY *this, IDebugProperty **pObj)
{
	LOGFUNC("IDebugProperty (result)::GetParent");
	LOGHEXPARAM("Returns", S_FALSE);
	UNLOGFUNC();

	// There is no parent of an evaluated expression
	*pObj = 0;
	return(S_FALSE);
}
