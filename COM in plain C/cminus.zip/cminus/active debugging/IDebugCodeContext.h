#ifndef _IDEBUGCODECONTEXT_H_
#define _IDEBUGCODECONTEXT_H_

#include <activdbg.h>
#include "../Interpreter/CInstruction.h"

IEnumDebugCodeContexts * allocIEnumDebugCodeContexts(CINSTRUCTION *, IActiveScriptSiteDebug *, DWORD);
IDebugCodeContext * allocIDebugCodeContext(CINSTRUCTION *, IActiveScriptSiteDebug *, DWORD);

#endif
