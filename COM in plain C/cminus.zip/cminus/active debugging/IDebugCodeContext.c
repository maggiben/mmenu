/*
 * Functions for our IDebugCodeContext COM object. The IDebugCodeContext
 * allows a host to get info about a particular instruction. It is gotten
 * from our IDebugStackFrame's GetCodeContext(). It can also be gotten
 * from our IEnumCodeContexts' Next().
 *
 * Also contains our ENUMDEBUGCODECONTEXTS functions. Our
 * ENUMDEBUGCODECONTEXTS wraps our IEnumDebugCodeContexts COM object.
 * The host gets our IEnumDebugCodeContexts object by calling our
 * IActiveScriptDebug's EnumCodeContextsOfPosition(). The
 * IEnumDebugCodeContexts is a standard enumerator for all the
 * CINSTRUCTIONs in a given "context", starting at a given source
 * position, and spanning a given number of source chars.
 */

#define INC_OLE2
#define CONST_VTABLE
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <stddef.h>
#include <objbase.h>
#include <activscp.h>
#include <activdbg.h>
#include "../TraceWin.h"
#include "../IClassFactory.h"
#include "../Interpreter/CInstruction.h"
#include "../Active Engine/ErrorHandler.h"




// Wraps an IDebugCodeContext object
typedef struct {
	const void				*lpVtbl;			// IDebugCodeContext VTable
	ULONG					RefCount;
	IActiveScriptSiteDebug	*DebugSite;			// Host's IActiveScriptSiteDebug
	CINSTRUCTION			*Instruction;		// CINSTRUCTION for this IDebugCodeContext
	DWORD					Context;			// Host-defined debugging value
} DEBUGCODECONTEXT;

// Our IDebugCodeContext VTable
static STDMETHODIMP QueryInterface(DEBUGCODECONTEXT *, REFIID, void **);
static STDMETHODIMP_(ULONG) AddRef(DEBUGCODECONTEXT *);
static STDMETHODIMP_(ULONG) Release(DEBUGCODECONTEXT *);
STDMETHODIMP GetDocumentContext(DEBUGCODECONTEXT *, IDebugDocumentContext **); 
static STDMETHODIMP SetBreakPoint(DEBUGCODECONTEXT *, BREAKPOINT_STATE); 

const IDebugCodeContextVtbl IDebugCodeContext_Vtbl = {QueryInterface,
AddRef,
Release,
GetDocumentContext,
SetBreakPoint};

// Wraps an IEnumDebugCodeContexts object
typedef struct {
	const void				*lpVtbl;			// IEnumDebugCodeContexts VTable
	ULONG					RefCount;
	DWORD					Index;
	IActiveScriptSiteDebug	*DebugSite;			// Smart host's IActiveScriptSiteDebug
	CINSTRUCTION			*Instruction;		// matching CINSTRUCTION
	DWORD					Context;
} ENUMDEBUGCODECONTEXTS;

// Our IEnumDebugCodeContexts VTable
static STDMETHODIMP EnumQueryInterface(ENUMDEBUGCODECONTEXTS *, REFIID, void **);
static STDMETHODIMP_(ULONG) EnumAddRef(ENUMDEBUGCODECONTEXTS *);
static STDMETHODIMP_(ULONG) EnumRelease(ENUMDEBUGCODECONTEXTS *);
static STDMETHODIMP Next(ENUMDEBUGCODECONTEXTS *, ULONG, IDebugCodeContext **, ULONG *);
static STDMETHODIMP Skip(ENUMDEBUGCODECONTEXTS *, ULONG);
static STDMETHODIMP Reset(ENUMDEBUGCODECONTEXTS *);
static STDMETHODIMP Clone(ENUMDEBUGCODECONTEXTS *, IEnumDebugCodeContexts **);

static const IEnumDebugCodeContextsVtbl IEnumDebugCodeContexts_Vtbl = {EnumQueryInterface,
EnumAddRef,
EnumRelease,
Next,
Skip,
Reset,
Clone};

#ifdef LOGTRACE
static unsigned char LogFlag2 = 0;
#endif









//============================================================================
// Our IDebugCodeContext object.
//============================================================================

/******************* allocIDebugCodeContext() *******************
 * Allocates/initializes an IDebugCodeContext (actually our
 * DEBUGCODECONTEXT).
 *
 * instruction = The CINSTRUCTION that this IDebugCodeContext object
 *				 is for.
 * debugSite =	 Pointer to host's IActiveScriptSiteDebug.
 *
 * RETURNS: The IDebugCodeContext *, or 0 if memory failure.
 *
 * NOTE: AddRefs the returned object.
 */

IDebugCodeContext * allocIDebugCodeContext(CINSTRUCTION *instruction, IActiveScriptSiteDebug *debugSite, DWORD context)
{
	register DEBUGCODECONTEXT	*obj;

	if ((obj = (DEBUGCODECONTEXT *)ALLOCMEM(sizeof(DEBUGCODECONTEXT))))
	{
		obj->lpVtbl = &IDebugCodeContext_Vtbl;
		obj->Instruction = instruction;
		obj->DebugSite = debugSite;
		obj->RefCount = 1;
		obj->Context = context;
		incOutstandingObjs();
	}

	return((IDebugCodeContext *)obj);
}


/************************ QueryInterface() *************************
 */

static STDMETHODIMP QueryInterface(DEBUGCODECONTEXT *this, REFIID riid, void **ppvObj)
{
	LOGFUNC("IDebugCodeContext::QueryInterface");

//	if (!IsBadWritePtr(ppvObj, sizeof(void *)))
	{
		*ppvObj = 0;

		if (!IsBadWritePtr(this, sizeof(DEBUGCODECONTEXT)))
		{
			if (IsEqualIID(riid, &IID_IUnknown) || IsEqualIID(riid, &IID_IDebugCodeContext))
			{
				*ppvObj = this;
#ifdef LOGTRACE
				LogFlag2 = 1;
#endif
				AddRef(this);
				return(NOERROR);
			}

			LOGGUID("UNSUPPORTED: ", riid);
			UNLOGFUNC();
			return(E_NOINTERFACE);
		}
	}

	UNLOGFUNC();
	return(E_POINTER);
}

/*************************** AddRef() ******************************
 */

static STDMETHODIMP_(ULONG) AddRef(DEBUGCODECONTEXT *this)
{
	if (!IsBadWritePtr(this, sizeof(DEBUGCODECONTEXT)))
	{
#ifdef LOGTRACE
		ULONG	val;
#endif
		incOutstandingObjs();

#ifdef LOGTRACE
		if (!LogFlag2) LOGFUNC("IDebugCodeContext::AddRef");
		val = ++this->RefCount;
		UNLOGFUNC();
		LogFlag2 = 0;
		return(val);
#else
		return(++this->RefCount);
#endif
	}

	return(0);
}

/************************** Release() ******************************
 */

static STDMETHODIMP_(ULONG) Release(DEBUGCODECONTEXT *this)
{
	if (!IsBadWritePtr(this, sizeof(DEBUGCODECONTEXT)))
	{
		register ULONG	val;

		LOGFUNC("IDebugCodeContext::Release");
		UNLOGFUNC();

		decOutstandingObjs();

		if (!(val = --this->RefCount))
		{
			// NOTE: We don't free the CINSTRUCTION because it's still in our
			// interpreter's list
			FREEMEM(this);
		}

		return(val);
	}

	return(0);
}

/********************* GetDocumentContext() ******************
 * Retrieves the IDebugDocumentContext associated with this
 * instruction.
 *
 * pObj =	Where to return the IDebugDocumentContext pointer.
 */

STDMETHODIMP GetDocumentContext(DEBUGCODECONTEXT *this, IDebugDocumentContext **pObj)
{
	register HRESULT		hr;

	LOGFUNC("GetDocumentContext");

	*pObj = 0;

	hr = E_INVALIDARG;
	if (!IsBadWritePtr(this, sizeof(DEBUGCODECONTEXT)))
	{
		register CINSTRUCTION	*instruction;
		register unsigned char	*token;

		instruction = (CINSTRUCTION *)this->Instruction;
		if (!IsBadWritePtr(instruction, sizeof(CINSTRUCTION)))
		{
			hr = E_NOTIMPL;
			if (this->DebugSite && (instruction->Flags & IS_DEBUG_INSTRUCTION))
			{
				token = (unsigned char *)instruction;
				if (instruction->Flags & INSTRUCTION_HAS_LABEL) token -= sizeof(LPOLESTR *);
				token -= sizeof(CTOKEN);

				// Our host is a smart host, so we can use the IActiveScriptSiteDebug's
				// GetDocumentContextFromPosition to retrieve the IDebugDocumentContext
				hr = this->DebugSite->lpVtbl->GetDocumentContextFromPosition(this->DebugSite, this->Context, ((CTOKEN *)token)->CharOffset, lstrlenW(getSourceTokenText((CTOKEN *)token, instruction)), pObj);
			}
		}
	}

	LOGHEXPARAM("Returns", hr);
	UNLOGFUNC();

	return(hr);
} 

/************************* SetBreakPoint() **************************
 * Sets or removes a breakpoint at this instruction. It is the
 * responsibility of our interpreter to detect the breakpoint and
 * respond appropriately, which we do in evalInstruction().
 *
 * bps =	BREAKPOINT_STATE to set on this instruction.
 */

static STDMETHODIMP SetBreakPoint(DEBUGCODECONTEXT *this, BREAKPOINT_STATE bps)
{
	register CINSTRUCTION	*instruction;
	register HRESULT		hr;

	LOGFUNC("SetBreakPoint");

	hr = E_INVALIDARG;
	if (!IsBadWritePtr(this, sizeof(DEBUGCODECONTEXT)))
	{
		instruction = (CINSTRUCTION *)this->Instruction;
		if (!IsBadWritePtr(instruction, sizeof(CINSTRUCTION)))
		{
			// Save the new state of the breakpoint
			instruction->Flags &= (~BREAKPOINT_BITS);
			instruction->Flags |= bps;
		}
	}

	UNLOGFUNC();
	return(S_OK);
}





























//============================================================================
// Our IEnumDebugCodeContexts object.
//============================================================================

/******************* allocIEnumDebugCodeContexts() ****************
 * Allocates/initializes an IEnumDebugCodeContexts (actually our
 * ENUMDEBUGCODECONTEXTS).
 *
 * instruction =	The first CINSTRUCTION that this
 *					IEnumDebugCodeContexts enumerates.
 *
 * RETURNS: The IEnumDebugCodeContexts *, or 0 if memory failure.
 *
 * NOTE: AddRefs the returned object.
 */

IEnumDebugCodeContexts * allocIEnumDebugCodeContexts(CINSTRUCTION *instruction, IActiveScriptSiteDebug *debugSite, DWORD context)
{
	register ENUMDEBUGCODECONTEXTS	*obj;

	if ((obj = (ENUMDEBUGCODECONTEXTS *)ALLOCMEM(sizeof(ENUMDEBUGCODECONTEXTS))))
	{
		obj->lpVtbl = &IEnumDebugCodeContexts_Vtbl;
		obj->Index = 0;
		obj->DebugSite = debugSite;
		obj->Instruction = instruction;
		obj->RefCount = 1;
		obj->Context = context;
		incOutstandingObjs();
	}

	return((IEnumDebugCodeContexts *)obj);
}

/************************ QueryInterface() *************************
 */

static STDMETHODIMP EnumQueryInterface(ENUMDEBUGCODECONTEXTS *this, REFIID riid, void **ppvObj)
{
	LOGFUNC("IEnumDebugCodeContexts::QueryInterface");

	if (!IsBadWritePtr(ppvObj, sizeof(void *)))
	{
		if (IsEqualIID(riid, &IID_IUnknown) || IsEqualIID(riid, &IID_IEnumDebugCodeContexts))
		{
			*ppvObj = this;
#ifdef LOGTRACE
			LogFlag2 = 1;
#endif
			EnumAddRef(this);
			return(NOERROR);
		}
		*ppvObj = 0;
		LOGGUID("UNSUPPORTED: ", riid);
		UNLOGFUNC();
		return(E_NOINTERFACE);
	}

	UNLOGFUNC();
	return(E_POINTER);
}

/*************************** AddRef() ******************************
 */

static STDMETHODIMP_(ULONG) EnumAddRef(ENUMDEBUGCODECONTEXTS *this)
{
#ifdef LOGTRACE
	ULONG	val;
#endif

	incOutstandingObjs();

#ifdef LOGTRACE
	if (!LogFlag2) LOGFUNC("IEnumDebugCodeContexts::AddRef");
	val = ++this->RefCount;
	UNLOGFUNC();
	LogFlag2 = 0;
	return(val);
#else
	UNLOGFUNC();
	return(++this->RefCount);
#endif
}

/************************** Release() ******************************
 */

static STDMETHODIMP_(ULONG) EnumRelease(ENUMDEBUGCODECONTEXTS *this)
{
	LOGFUNC("IEnumDebugCodeContexts::Release");

	if (!IsBadWritePtr(this, sizeof(ENUMDEBUGCODECONTEXTS)))
	{
		// One less outstanding object
		decOutstandingObjs();

		if ((--this->RefCount))
		{
			UNLOGFUNC();
			return(this->RefCount);
		}

		FREEMEM(this);
	}

	UNLOGFUNC();
	return(0);
}

/*************************** Next() ***************************
 * Retrieves the next IDebugCodeContext(s) in this enumerator,
 * if they're available. The host obtains a IDebugCodeContext
 * to get information on the current CINSTRUCTION at a given
 * stack frame (ie, script call level).
 *
 * count =		The number of IDebugCodeContext(s) to retrieve.
 * pi =			Array of IDebugCodeContext pointers to fill.
 * fetched =	Number of IDebugCodeContexts actually retrieved.
 */

static STDMETHODIMP Next(ENUMDEBUGCODECONTEXTS *this, ULONG count, IDebugCodeContext **pObj, ULONG *fetched)
{
	HRESULT		hr;

	LOGFUNC("IEnumDebugCodeContexts::Next");

	*pObj = 0;
	hr = S_FALSE;
	*fetched = 0;

	// We have only 1, so unless index = 0, he's asking for something we don't have
	if (!this->Index &&

		// If an element was requested, return the IDebugCodeContext
		count == 1 && (*pObj = allocIDebugCodeContext(this->Instruction, this->DebugSite, this->Context)))
	{
		*fetched = this->Index = 1;
		hr = S_OK;
	}

	LOGHEXPARAM("Returns", hr);
	UNLOGFUNC();

	return(hr);
} 

/************************* Skip() ****************************
 * Skips a given number of elements in the enumeration.
 *
 * count =	Number of elements to skip.
 */

static STDMETHODIMP Skip(ENUMDEBUGCODECONTEXTS *this, ULONG count)
{
	register HRESULT	hr;

	LOGFUNC("IEnumDebugCodeContexts::Skip");

	hr = S_OK;

	// Increment the index, even though there's nothing to skip
	this->Index += count;
	if (this->Index) hr = S_FALSE;

	LOGHEXPARAM("Returns", hr);
	UNLOGFUNC();
	
	return(hr);
}

/************************** Reset() ***************************
 * Resets the enumerator to the beginning of the list.
 */

static STDMETHODIMP Reset(ENUMDEBUGCODECONTEXTS *this)
{
	LOGFUNC("IEnumDebugCodeContexts::Reset");

	// Reset the index back to zero so we can retrieve the IDebugDocumentContext again
	this->Index = 0;

	LOGHEXPARAM("Returns", S_OK);
	UNLOGFUNC();

	return(S_OK);
} 

/************************* Clone() **************************
 * Creates a new IEnumDebugCodeContexts enumerator with
 * the same enumerator state as this one.
 *
 * ppepi =	 Where to return the new IEnumDebugCodeContexts.
 */

static STDMETHODIMP Clone(ENUMDEBUGCODECONTEXTS *this, IEnumDebugCodeContexts **pObj)
{
	register HRESULT	hr;

	LOGFUNC("IEnumDebugCodeContexts::Clone");

	hr = S_OK;

	// Run the copy-constructor to get a new instance of this enumerator
	if (!(*pObj = allocIEnumDebugCodeContexts(this->Instruction, this->DebugSite, this->Context)))
		hr = E_OUTOFMEMORY;

	LOGHEXPARAM("Returns", hr);
	UNLOGFUNC();

	return(hr);
}
