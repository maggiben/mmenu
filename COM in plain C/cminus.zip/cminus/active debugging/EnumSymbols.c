/*
 * Functions for our SYMBOLTABLEINFO, which wraps an IDebugProperty COM object that
 * the host uses to get information about the CSYMBOLTABLEs of a particular, running
 * script function. This IDebugProperty provides human-readable information to allow
 * an IDE to browse and modify variables at design or run-time.
 *
 * Also contains functions for our SYMBOLSINFO, which wraps an IEnumDebugPropertyInfo.
 * IEnumDebugPropertyInfo is a standard COM enumerator that the host uses to enumerate
 * the CSYMBOLs in a particular, running script function.
 */

#define INC_OLE2
#define CONST_VTABLE
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <objbase.h>
#include <activscp.h>
#include <activdbg.h>
#include "../TraceWin.h"
#include "../IClassFactory.h"
#include "../Interpreter/ScriptVariant.h"
#include "../Interpreter/SymbolTable.h"
#include "EnumSymbols.h"


static IEnumDebugPropertyInfo * allocIEnumDebugPropertyInfo(DEBUGSTACKFRAMEDESCRIPTOR *);


// Wraps an IEnumDebugPropertyInfo that enumerates CSYMBOLs
#pragma pack(1)
typedef struct {
	const void					*lpVtbl;		// IEnumDebugPropertyInfo
	ULONG						RefCount;
	DEBUGSTACKFRAMEDESCRIPTOR	*Desc;			// DEBUGSTACKFRAMEDESCRIPTOR whose symbols are being enumerated
	TSTACK						*SymbolList;	// TSTACK containing the currently enumerated CSYMBOLTABLE
	CSYMBOL						*CurrentSymbol;	// Next CSYMBOL to enumerate within SymbolList
} SYMBOLSINFO;
#pragma pack()

// Our IEnumDebugPropertyInfo VTable
static STDMETHODIMP EnumQueryInterface(SYMBOLSINFO *, REFIID, void **);
static STDMETHODIMP_(ULONG) EnumAddRef(SYMBOLSINFO *);
static STDMETHODIMP_(ULONG) EnumRelease(SYMBOLSINFO *);
static STDMETHODIMP Next(SYMBOLSINFO *, ULONG, DebugPropertyInfo *, ULONG *);
static STDMETHODIMP Skip(SYMBOLSINFO *, ULONG);
static STDMETHODIMP Reset(SYMBOLSINFO *);
static STDMETHODIMP Clone(SYMBOLSINFO *, IEnumDebugPropertyInfo **);
static STDMETHODIMP GetCount(SYMBOLSINFO *, ULONG *);

static const IEnumDebugPropertyInfoVtbl IEnumDebugPropertyInfo_Vtbl = {EnumQueryInterface,
EnumAddRef,
EnumRelease,
Next,
Skip,
Reset,
Clone,
GetCount};

// Wraps an IDebugProperty that gets info about a CSYMBOLTABLE
typedef struct {
	const IDebugPropertyVtbl	*lpVtbl;
	ULONG						RefCount;
	DEBUGSTACKFRAMEDESCRIPTOR	*Desc;
} SYMBOLTABLEINFO;

// Our IDebugProperty VTable
static STDMETHODIMP QueryInterface(SYMBOLTABLEINFO *, REFIID, void **);
static STDMETHODIMP_(ULONG) AddRef(SYMBOLTABLEINFO *);
static STDMETHODIMP_(ULONG) Release(SYMBOLTABLEINFO *);
static STDMETHODIMP GetPropertyInfo(SYMBOLTABLEINFO *, DWORD, UINT, DebugPropertyInfo *);
static STDMETHODIMP GetExtendedInfo(SYMBOLTABLEINFO *, ULONG, GUID *, VARIANT *);
static STDMETHODIMP SetValueAsString(SYMBOLTABLEINFO *, LPCOLESTR, UINT);
static STDMETHODIMP EnumMembers(SYMBOLTABLEINFO *, DWORD, UINT, REFIID, IEnumDebugPropertyInfo **);
static STDMETHODIMP PGetParent(SYMBOLTABLEINFO *, IDebugProperty **);

static const IDebugPropertyVtbl IDebugProperty_Vtbl = {QueryInterface,
AddRef,
Release,
GetPropertyInfo,
GetExtendedInfo,
SetValueAsString,
EnumMembers,
PGetParent};

static const WCHAR SymbolType[] = L"Variables";

#ifdef LOGTRACE
static unsigned char LogFlag2 = 0;
#endif






/****************** allocDebugStackedSymbols() ******************
 * Allocates/initializes a SYMBOLTABLEINFO (which
 * wraps an IDebugProperty that gives info about a symbol table).
 *
 * RETURNS: The IDebugProperty *, or 0 if memory failure.
 *
 * NOTE: AddRefs the returned object.
 */

IDebugProperty * allocDebugStackedSymbols(DEBUGSTACKFRAMEDESCRIPTOR *desc)
{
	register SYMBOLTABLEINFO	*obj;

	if ((obj = (SYMBOLTABLEINFO *)ALLOCMEM(sizeof(SYMBOLTABLEINFO))))
	{
		ZeroMemory(obj, sizeof(SYMBOLTABLEINFO));
		obj->lpVtbl = &IDebugProperty_Vtbl;
		obj->RefCount = 1;
		obj->Desc = desc;
		incOutstandingObjs();
	}

	return((IDebugProperty *)obj);
}





/************************ QueryInterface() *************************
 */

static STDMETHODIMP QueryInterface(SYMBOLTABLEINFO *this, REFIID riid, void **ppvObj)
{
	LOGFUNC("IDebugProperty::QueryInterface");

//	if (/* !IsBadWritePtr(ppvObj, sizeof(void *)) && */ !IsBadWritePtr(this, sizeof(SYMBOLTABLEINFO)))
	{
		if (IsEqualIID(riid, &IID_IUnknown) || IsEqualIID(riid, &IID_IDebugProperty))
		{
			*ppvObj = this;
#ifdef LOGTRACE
			LogFlag2 = 1;
#endif
			AddRef(this);
			return(NOERROR);
		}
		*ppvObj = 0;
		LOGGUID("UNSUPPORTED: ", riid);
		UNLOGFUNC();
		return(E_NOINTERFACE);
	}

	UNLOGFUNC();
	return(E_POINTER);
}

/*************************** AddRef() ******************************
 */

static STDMETHODIMP_(ULONG) AddRef(SYMBOLTABLEINFO *this)
{
#ifdef LOGTRACE
	ULONG	val;
#endif

	incOutstandingObjs();

#ifdef LOGTRACE
	if (!LogFlag2) LOGFUNC("IDebugProperty::AddRef");
	val = ++this->RefCount;
	UNLOGFUNC();
	LogFlag2 = 0;
	return(val);
#else
	UNLOGFUNC();
	return(++this->RefCount);
#endif
}

/************************** Release() ******************************
 */

static STDMETHODIMP_(ULONG) Release(SYMBOLTABLEINFO *this)
{
	LOGFUNC("IDebugProperty::Release");

//	if (!IsBadWritePtr(this, sizeof(SYMBOLTABLEINFO)))
	{
		// One less outstanding object
		decOutstandingObjs();

		if ((--this->RefCount))
		{
			UNLOGFUNC();
			return(this->RefCount);
		}

		FREEMEM(this);
	}

	UNLOGFUNC();
	return(0);
}





/*********************** GetPropertyInfo() *********************
 * Retrieves information about this IDebugProperty's symbol 
 * table, and puts it in the caller's DebugPropertyInfo struct.
 *
 * flags =		PROP_INFO_FLAGS specifying which information 
 *				the host wants us to return.
 * radix =		The radix in which to retrieve information 
 *				(eg. 16 = Hex, 2 = Binary )
 * propInfo =	Host's DebugPropertyInfo struct to fill in.
 */

static STDMETHODIMP GetPropertyInfo(SYMBOLTABLEINFO *this, DWORD flags, UINT radix, DebugPropertyInfo *propInfo)
{
	register HRESULT		hr;

	LOGFUNC("IDebugProperty::GetPropertyInfo");

	hr = E_POINTER;
//	if (// !IsBadWritePtr(propInfo, sizeof(DebugPropertyInfo)) &&
//		!IsBadWritePtr(this, sizeof(SYMBOLTABLEINFO)) && !IsBadWritePtr(this->Desc, sizeof(DEBUGSTACKFRAMEDESCRIPTOR)))
	{
		hr = S_OK;

		ZeroMemory(propInfo, sizeof(DebugPropertyInfo));

		// Let the caller know which information we intend to return
//		propInfo->m_dwValidFields = flags & (PROP_INFO_NAME|PROP_INFO_TYPE|PROP_INFO_FULLNAME|PROP_INFO_ATTRIBUTES|PROP_INFO_DEBUGPROP);
		propInfo->m_dwValidFields = flags & (PROP_INFO_NAME|PROP_INFO_TYPE|PROP_INFO_FULLNAME|PROP_INFO_ATTRIBUTES);

		// Does caller want the name returned?
		if (flags & PROP_INFO_NAME)
		{
			// Fill in the value with the stack name
			propInfo->m_bstrName = SysAllocString(&this->Desc->Name[0]);
		}
      
		if (flags & PROP_INFO_TYPE)
		{
			// Fill in the value. We'll make our type "Variables"
			propInfo->m_bstrType = SysAllocString(&SymbolType[0]);
		}
      
//		if (flags & PROP_INFO_VALUE)
//		{
			// This is not a valid field for this object
//		}
      
		if (flags & PROP_INFO_FULLNAME)
		{
			// Fill in the value. We'll make our full name the same as our short
			propInfo->m_bstrFullName = SysAllocString(&this->Desc->Name[0]);
		}
      
		if (flags & PROP_INFO_ATTRIBUTES)
		{
			// Return the attributes of this symbol table
			propInfo->m_dwAttrib = /* OBJECT_ATTRIB_VALUE_IS_EXPANDABLE| */OBJECT_ATTRIB_VALUE_READONLY|OBJECT_ATTRIB_TYPE_IS_CONSTANT;
		}
      
//		if (flags & PROP_INFO_DEBUGPROP)
//		{
			// Fill in the value
//			propInfo->m_pDebugProp = (IDebugProperty *)this;

			// AddRef it for the host
//			AddRef(this);
//		}

		// PROP_INFO_AUTOEXPAND isn't one we need to worry about
	}

	LOGHEXPARAM("Returns", hr);
	UNLOGFUNC();

	return(hr);
} 





/********************** GetExtendedInfo() *********************
 * Retrieves information that does not lend itself to being
 * stored in a DebugPropertyInfo struct.
 *
 * cInfos =		The number of extended infos to retrieve.
 * guids =		Array of GUIDs of the extended info to retrieve.
 * rgvar =		Array of VARIANT's to contain the extended info.
 */

static STDMETHODIMP GetExtendedInfo(SYMBOLTABLEINFO *this, ULONG cInfos, GUID *guids, VARIANT *rgvar)
{
	LOGFUNC("IDebugProperty::GetPropertyInfo");
	UNLOGFUNC();

	// We don't currently support extended info
	return(E_NOTIMPL);
}





/********************** SetValueAsString() *********************
 * Takes an LPCOLESTR which contains a string representation of
 * the desired value and uses it to reset the value of this
 * property.
 *
 * pszValue =	The new value of this property
 * radix =		The radix of the value in pszValue 
 *				(eg. 16 = Hex, 2 = Binary )
 */

static STDMETHODIMP SetValueAsString(SYMBOLTABLEINFO *this, LPCOLESTR pszValue, UINT radix)
{
	LOGFUNC("IDebugProperty::SetValueAsString");
	UNLOGFUNC();

	// It would be really bad if we accidently blew away our symbol table,
	// so let's not allow that
	return(E_NOTIMPL);
}





/*********************** EnumMembers() ********************
 * Creates/returns an IEnumDebugPropertyInfo that the host
 * uses to enumerate of all the CSYMBOLs of this stack
 * frame's CSYMBOLTABLE.
 *
 * fieldSpec =	The subset of members to retrieve
 * radix =		The radix in which to retrieve information 
 *				(eg. 16 = Hex, 2 = Binary)
 * refiid =		Reserved, must be NULL.
 * pObj =		Where to return our IEnumDebugPropertyInfo.
 */

static STDMETHODIMP EnumMembers(SYMBOLTABLEINFO *this, DWORD fieldSpec, UINT radix, REFIID refiid, IEnumDebugPropertyInfo **pObj)
{
	register HRESULT		hr;
	
	LOGFUNC("IDebugProperty::EnumMembers");

	hr = E_POINTER;
//	if (!IsBadWritePtr(this, sizeof(SYMBOLTABLEINFO)) && !IsBadWritePtr(this->Desc, sizeof(DEBUGSTACKFRAMEDESCRIPTOR)))
	{
		hr = E_OUTOFMEMORY;

		// Create a new IEnumDebugPropertyInfo to enumerate this scope of symbols.
		// Give the host our IEnumDebugPropertyInfo. NOTE: allocIEnumDebugPropertyInfo()
		// AddRef()'s it
		if ((*pObj = allocIEnumDebugPropertyInfo(this->Desc))) hr = S_OK;
	}

	LOGHEXPARAM("Returns", hr);
	UNLOGFUNC();
	return(hr);
}





/************************* PGetParent() **********************
 * Returns the parent IDebugProperty of this IDebugProperty,
 * if it's available.
 *
 * pObj = Where to return the parent IDebugProperty.
 */

static STDMETHODIMP PGetParent(SYMBOLTABLEINFO *this, IDebugProperty **pObj)
{
	LOGFUNC("IDebugProperty::GetParent");
	LOGHEXPARAM("Returns", S_FALSE);
	UNLOGFUNC();

	// SYMBOLTABLEINFO doesn't have an IDebugProperty parent
	*pObj = 0;
	return(S_FALSE);
}

























/************************* reset_list() ************************
 * Resets the SYMBOLSINFO to the start of the symbol
 * table list for this level.
 */

static TSTACK * reset_list(SYMBOLSINFO *this)
{
	register TSTACK			*symbolList;
	
	// Find the first CSYMBOLTABLE for this DEBUGSTACKFRAMEDESCRIPTOR
	symbolList = this->Desc->Interpreter->SymbolTable;
	while (symbolList)
	{
		if (((CSYMBOLTABLE *)symbolList->Value)->Frame == this->Desc)
		{
			// Save the TSTACK
			this->SymbolList = symbolList;

			// Get the first CSYMBOL in this CSYMBOLTABLE
			this->CurrentSymbol = ((CSYMBOLTABLE *)symbolList->Value)->SymbolList;

			break;
		}

		symbolList = symbolList->Next;
	}

	return(symbolList);
}





/****************** allocIEnumDebugPropertyInfo() ******************
 * Allocates/initializes an IEnumDebugPropertyInfo (actually an
 * SYMBOLSINFO).
 *
 * desc =	A pointer to the DEBUGSTACKFRAMEDESCRIPTOR whose
 *			CSYMBOLs this IEnumDebugPropertyInfo enumerates.
 *
 * RETURNS: The IEnumDebugPropertyInfo *, or 0 if memory failure.
 *
 * NOTE: AddRefs the returned object.
 */

static IEnumDebugPropertyInfo * allocIEnumDebugPropertyInfo(DEBUGSTACKFRAMEDESCRIPTOR *desc)
{
	register SYMBOLSINFO	*obj;

	if ((obj = (SYMBOLSINFO *)ALLOCMEM(sizeof(SYMBOLSINFO))))
	{
		ZeroMemory(obj, sizeof(SYMBOLSINFO));
		obj->lpVtbl = &IEnumDebugPropertyInfo_Vtbl;
		obj->Desc = desc;
		obj->RefCount = 1;
		reset_list(obj);
		incOutstandingObjs();
	}

	return((IEnumDebugPropertyInfo *)obj);
}





/************************ QueryInterface() *************************
 */

static STDMETHODIMP EnumQueryInterface(SYMBOLSINFO *this, REFIID riid, void **ppvObj)
{
	LOGFUNC("IEnumDebugPropertyInfo::QueryInterface");

//	if (!IsBadWritePtr(ppvObj, sizeof(void *)))
	{
		if (IsEqualIID(riid, &IID_IUnknown) || IsEqualIID(riid, &IID_IEnumDebugPropertyInfo))
		{
			*ppvObj = this;
#ifdef LOGTRACE
			LogFlag2 = 1;
#endif
			EnumAddRef(this);
			return(NOERROR);
		}
		*ppvObj = 0;
		LOGGUID("UNSUPPORTED: ", riid);
		UNLOGFUNC();
		return(E_NOINTERFACE);
	}

	UNLOGFUNC();
	return(E_POINTER);
}

/*************************** AddRef() ******************************
 */

static STDMETHODIMP_(ULONG) EnumAddRef(SYMBOLSINFO *this)
{
#ifdef LOGTRACE
	ULONG	val;
#endif

	incOutstandingObjs();

#ifdef LOGTRACE
	if (!LogFlag2) LOGFUNC("IEnumDebugPropertyInfo::AddRef");
	val = ++this->RefCount;
	UNLOGFUNC();
	LogFlag2 = 0;
	return(val);
#else
	UNLOGFUNC();
	return(++this->RefCount);
#endif
}

/************************** Release() ******************************
 */

static STDMETHODIMP_(ULONG) EnumRelease(SYMBOLSINFO *this)
{
	LOGFUNC("IEnumDebugPropertyInfo::Release");

//	if (!IsBadWritePtr(this, sizeof(SYMBOLSINFO)))
	{
		// One less outstanding object
		decOutstandingObjs();

		if ((--this->RefCount))
		{
			UNLOGFUNC();
			return(this->RefCount);
		}

		FREEMEM(this);
	}

	UNLOGFUNC();
	return(0);
}





static CSYMBOL * nextSymbolList(SYMBOLSINFO *this)
{
	register CSYMBOL	*symbol;
	register TSTACK		*item;

	symbol = 0;

	if (this->SymbolList)
	{
		do
		{
			// Is there another CSYMBOLTABLE?
			if (!(item = this->SymbolList->Next) ||

				// Yes, there is. Now see if this CSYMBOLTABLE is for our
				// DEBUGSTACKFRAMEDESCRIPTOR. If not, we're about to dive
				// into some other function's variables. We don't want that
				((CSYMBOLTABLE *)item->Value)->Frame != this->Desc)
			{
				break;
			}

			this->SymbolList = item;

			// Are there any CSYMBOLs to enumerate in this CSYMBOLTABLE? If
			// not, dive into the next CSYMBOLTABLE (assuming its part of
			// the function whose variables we're enumerating)
		} while (!(symbol = ((CSYMBOLTABLE *)item->Value)->SymbolList));
	}

	return(symbol);
}





/*************************** Next() ***************************
 * Retrieves the next element or elements in this enumerator,
 * if they're available.
 *
 * count =		The number of elements to retrieve.
 * propInfo =	Array of DebugPropertyInfo structures to fill with the
 *				requested elements.
 * fetched =	Number of elements actually retrieved.
 */

static STDMETHODIMP Next(SYMBOLSINFO *this, ULONG count, DebugPropertyInfo *propInfo, ULONG *fetched)
{
	register ULONG				i;
	register DebugPropertyInfo	*pInfo;

	LOGFUNC("IEnumDebugPropertyInfo::Next");

	i = 0;

	// Clear out caller's DebugPropertyInfos
	ZeroMemory(propInfo, count * sizeof(DebugPropertyInfo));

	// Just make sure that we're not trying to enumerate a CSYMBOLTABLE that
	// has been deleted
//	if (!IsBadWritePtr(this->CurrentSymbol, sizeof(CSYMBOL)))
	{
		// Enumerate the specified number of CSYMBOLs
		pInfo = propInfo;
		while (i < count)
		{
			register CSYMBOL	*pSymbol;

			// If we've out of CSYMBOLs, see if the next CSYMBOLTABLE is within the current
			// function, and if so, dive into its CSYMBOLs. Otherwise, return S_FALSE to
			// indicate that we're run out of CSYMBOLs to fill the request
			if (!this->CurrentSymbol && !(this->CurrentSymbol = nextSymbolList(this))) break;

			// Get the CSYMBOL
			pSymbol = (CSYMBOL *)this->CurrentSymbol;

			// Set the flags for this DebugPropertyInfo
			pInfo->m_dwValidFields = PROP_INFO_NAME|PROP_INFO_TYPE|PROP_INFO_VALUE|PROP_INFO_ATTRIBUTES;

			// Note: If this variable was something that has "members", such as a struct or object, then
			// we'd also set the PROP_INFO_DEBUGPROP flag above, then below we'd have to create an IDebugProperty
			// which gave info about this struct/object, and stuff this IDebugProperty into pInfo->m_pDebugProp.
			// This IDebugProperty's EnumMembers() would have to create an IEnumDebugPropertyInfo that enumerated
			// the members of this struct/object.

			// Set the name
			if ((pInfo->m_bstrName = SysAllocString(&pSymbol->Name[0])))
			{
				// Set the type
				if ((pInfo->m_bstrType = makeTypeString(&pSymbol->SymbolValue)))
				{
					// Set the value (as a string)
					if ((pInfo->m_bstrValue = variantToString(&pSymbol->SymbolValue)))
					{
						// Set the Attribute flags
						pInfo->m_dwAttrib = OBJECT_ATTRIB_ACCESS_PUBLIC;
					}
				}
			}

			// Increment the count of the DebugPropertyInfo's we've filled in
			++i;
			++pInfo;

			// Get the next TNODE
			this->CurrentSymbol = this->CurrentSymbol->Next;
		}
	}
	
	// Return the actual number of DebugPropertyInfo's we've filled in
	*fetched = i;

	LOGHEXPARAM("Returns", i == count ? S_OK : S_FALSE);
	UNLOGFUNC();

	return(i == count ? S_OK : S_FALSE);
} 





/************************* Skip() ****************************
 * Skips a given number of CSYMBOLs in the enumeration.
 *
 * count =	Number of CSYMBOLs to skip.
 */

static STDMETHODIMP Skip(SYMBOLSINFO *this, ULONG count)
{
	register ULONG		i;
	register HRESULT	hr;

	LOGFUNC("IEnumDebugPropertyInfo::Skip");

	hr = S_OK;

	if (/* IsBadWritePtr(this->CurrentSymbol, sizeof(CSYMBOL)) && */ !reset_list(this)) return(E_POINTER);

	// Walk down the list the specified number of elements.  If we run out of
	// elements before we've skipped enough, return S_FALSE
	for (i = 0; i < count; i++)
	{
		// If this was the last element, then indicate we're through
		if (!this->CurrentSymbol && !(this->CurrentSymbol == nextSymbolList(this)))
		{
			hr = S_FALSE;
			break;
		}

		this->CurrentSymbol = this->CurrentSymbol->Next;
	}

	LOGHEXPARAM("Returns", hr);
	UNLOGFUNC();
	
	return(hr);
}





/************************** Reset() ***************************
 * Resets the enumerator to the beginning of the list.
 */

static STDMETHODIMP Reset(SYMBOLSINFO *this)
{
	LOGFUNC("IEnumDebugPropertyInfo::Reset");

	reset_list(this);

	UNLOGFUNC();
	return(S_OK);
} 





/************************* Clone() **************************
 * Creates a new IEnumDebugPropertyInfo enumerator with
 * the same enumerator state as this one.
 *
 * ppepi =	 Where to return the new IEnumDebugPropertyInfo.
 */

static STDMETHODIMP Clone(SYMBOLSINFO *this, IEnumDebugPropertyInfo **pObj)
{
	register HRESULT	hr;

	LOGFUNC("IEnumDebugPropertyInfo::Clone");

	hr = S_OK;

	// Get a new IEnumDebugPropertyInfo (actually SYMBOLSINFO)
	if (!(*pObj = allocIEnumDebugPropertyInfo(this->Desc)))
		hr = E_OUTOFMEMORY;

	LOGHEXPARAM("Returns", hr);
	UNLOGFUNC();

	return(hr);
}





/************************* GetCount() ***********************
 * Retrieves the number of CSYMBOLs in the list.
 *
 * count =	Where to return the count of CSYMBOLs
 */

static STDMETHODIMP GetCount(SYMBOLSINFO *this, ULONG *count)
{
	register DWORD		num;

	LOGFUNC("IEnumDebugPropertyInfo::GetCount");

	if (/* IsBadWritePtr(this->CurrentSymbol, sizeof(CSYMBOL)) && */ !reset_list(this)) return(E_POINTER);

	num = 0;
	do
	{
		while (this->CurrentSymbol)
		{
			++num;
			this->CurrentSymbol = this->CurrentSymbol->Next;
		}

	} while ((this->CurrentSymbol = nextSymbolList(this)));

	*count = num;
	reset_list(this);

	UNLOGFUNC();
	return(S_OK);
} 
