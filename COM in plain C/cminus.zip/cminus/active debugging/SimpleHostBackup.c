// Functions for our SMARTHOST struct, which fills in
// the missing Smart Host functionality for those Script Hosts which do
// not implement IActiveScriptSiteDebug.

#define INC_OLE2
#define CONST_VTABLE
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <stddef.h>
#include <objbase.h>
#include <activscp.h>
#include <activdbg.h>
#include "../TraceWin.h"
#include "../Guids.h"
#include "../IClassFactory.h"
#include "SimpleHostBackup.h"

typedef struct {
	const void *			lpVtbl;					// Our Smart Host IActiveScriptSiteDebug VTable
	IActiveScriptSite		*HostScriptSite;		// Original host's IActiveScriptSite
	IProcessDebugManager	*ProcDebugManager;
	IDebugApplication		*DebugApplication;
	IDebugDocumentHelper	*DebugDocumentHelper;
	ULONG					CharOffset;
	ULONG					RefCount;
} SMARTHOST;

#if 0
// IActiveScriptSite VTable
static STDMETHODIMP QueryInterface(SMARTHOST *, REFIID, void **);
static STDMETHODIMP_(ULONG) AddRef(SMARTHOST *);
static STDMETHODIMP_(ULONG) Release(SMARTHOST *);
static STDMETHODIMP GetLCID(SMARTHOST *, LCID *);
static STDMETHODIMP GetItemInfo(SMARTHOST *, LPCOLESTR, DWORD, IUnknown **, ITypeInfo **);
static STDMETHODIMP GetDocVersionString(SMARTHOST *, BSTR *);
static STDMETHODIMP OnScriptTerminate(SMARTHOST *, const VARIANT *, const EXCEPINFO *);
static STDMETHODIMP OnStateChange(SMARTHOST *, SCRIPTSTATE);
static STDMETHODIMP OnScriptError(SMARTHOST *, IActiveScriptError *);
static STDMETHODIMP OnEnterScript(SMARTHOST *);
static STDMETHODIMP OnLeaveScript(SMARTHOST *);
#endif

// IActiveScriptSiteDebug VTable
static STDMETHODIMP DebugQueryInterface(SMARTHOST *, REFIID, void **);
static STDMETHODIMP_(ULONG) DebugAddRef(SMARTHOST *);
static STDMETHODIMP_(ULONG) DebugRelease(SMARTHOST *);
static STDMETHODIMP GetDocumentContextFromPosition(SMARTHOST *, DWORD, ULONG, ULONG, IDebugDocumentContext **); 
static STDMETHODIMP GetApplication(SMARTHOST *, IDebugApplication **); 
static STDMETHODIMP GetRootApplicationNode(SMARTHOST *, IDebugApplicationNode **); 
static STDMETHODIMP OnScriptErrorDebug(SMARTHOST *, IActiveScriptErrorDebug *, BOOL *, BOOL *);

const IActiveScriptSiteDebug32Vtbl IActiveScriptSiteDebug_Vtbl = {DebugQueryInterface,
DebugAddRef,
DebugRelease,
GetDocumentContextFromPosition,
GetApplication,
GetRootApplicationNode,
OnScriptErrorDebug};





/*********************** allocSmartHost() **************************
 * Allocates/initializes a SMARTHOST wrapping our IActiveScriptSiteDebug
 * object.
 *
 * hostActiveSite =	Host's IActiveScriptSite pointer.
 *
 * Returns: TRUE if success.
 */

IActiveScriptSiteDebug * allocSmartHost(IActiveScriptSite *hostActiveSite)
{
	register SMARTHOST		*host;

	if ((host = (SMARTHOST *)ALLOCMEM(sizeof(SMARTHOST))))
	{
		ZeroMemory(host, sizeof(SMARTHOST));

		// Save the host's IActiveScriptSite and AddRef it
		host->HostScriptSite = hostActiveSite;
		hostActiveSite->lpVtbl->AddRef(hostActiveSite);

		// Set IActiveScriptSiteDebug VTable
		host->lpVtbl = &IActiveScriptSiteDebug_Vtbl;

		// AddRef it. We'll treat it as the real host's IActiveScriptSiteDebug
		// and release it when we're done with it
		host->RefCount = 1;

		// We need an IProcessDebugManager object
		if (CoCreateInstance(&CLSID_ProcessDebugManager, 0, CLSCTX_INPROC_SERVER|CLSCTX_INPROC_HANDLER|CLSCTX_LOCAL_SERVER, &IID_IProcessDebugManager, (void **)&host->ProcDebugManager))
		{
			// If that failed, we have no means to support smart debugging
			LOGOLESTRPARAM("No Process Debug Manager available!", 0);
bad:	//	Release(host);
			DebugRelease(host);
			host = 0;
			goto out;
		}

		// Get the IDebugApplication associated with our process 
		if (host->ProcDebugManager->lpVtbl->GetDefaultApplication(host->ProcDebugManager, &host->DebugApplication))
		{
			LOGOLESTRPARAM("Failed to get debug application.", 0);
			goto bad;
		}

		// Create a new DebugDocumentHelper to use with the script added by the simple host
		if (host->ProcDebugManager->lpVtbl->CreateDebugDocumentHelper(host->ProcDebugManager, 0, &host->DebugDocumentHelper))
		{
			LOGOLESTRPARAM("Failed to create debug document helper.", 0);
			goto bad;
		}
   
		// Initialize the DebugDocumentHelper so it's ready to handle the script
		if (host->DebugDocumentHelper->lpVtbl->Init(host->DebugDocumentHelper, host->DebugApplication, &DebugHostName[0], &DebugDocName[0], TEXT_DOC_ATTR_READONLY))
		{
			LOGOLESTRPARAM("Failed to initialize DebugDocumentHelper.", 0);
			goto bad;
		}
   
		// Attach our DebugDocumentHelper to the debugger application. The 0
		// parameter indicates that the DebugDocumentHelper should be at the root
		// of the debug tree
		if (host->DebugDocumentHelper->lpVtbl->Attach(host->DebugDocumentHelper, 0))
		{
			LOGOLESTRPARAM("Failed to attach DebugDocumentHelper.", 0);
			goto bad;
		}
	}
out:
	// Success
	return((IActiveScriptSiteDebug *)host);
}





HRESULT scanScript(LPCOLESTR, ULONG, SOURCE_TEXT_ATTR *);

/******************* addScriptTextToDebugger() ********************
 * Allows our own built-in Smart Host to add the script text to
 * the debugger manager.
 *
 * pstrCode =	The script text to enter into the debugger
 * iactive =	IActiveScript of the engine responsible for 
 *				this script block.
 * fScriptlet = Indicates whether or not the script block is a scriplet
 * context =	The source context provided by the host debugger.
 */

void addScriptTextToDebugger(ACTIVESCRIPT *iactive, LPCOLESTR pstrCode, BOOL fScriptlet)
{
	register DWORD				scriptLength;
	register SOURCE_TEXT_ATTR	*attribs;
	register SMARTHOST			*host;

	host = (SMARTHOST *)iactive->HostScriptSiteDebug;

	// Get the length of this script block
	scriptLength = lstrlenW(pstrCode);

	// Add the script text to the IDebugDocumentHelper
	if (host->DebugDocumentHelper->lpVtbl->AddUnicodeText(host->DebugDocumentHelper, pstrCode))
	{
		// This is bad, but it's not really a fatal error
		LOGOLESTRPARAM("Failed to add script text to debug document helper.", 0);
	}
	else
	{
		// Define the script block. NOTE: We use a ptr to the script text as the
		// "context" arg just so there's a hopefully unique value specified
		if (host->DebugDocumentHelper->lpVtbl->DefineScriptBlock(host->DebugDocumentHelper, host->CharOffset, scriptLength, (IActiveScript *)iactive, fScriptlet, (DWORD *)&pstrCode))
		{
			// Once again, this is bad, but not really fatal
			LOGOLESTRPARAM("Failed to define script block!", 0);
		}

		// We get a chance here to define script attributes, so use CScanner to get
		// the text attributes. Create an array of SOURCE_TEXT_ATTR's to fill first
		else if ((attribs = (SOURCE_TEXT_ATTR *)ALLOCMEM(sizeof(SOURCE_TEXT_ATTR) * scriptLength)))
		{
			LOGFUNC("addScriptTextToDebugger");

			// Scan the text and get the attributes
			if (scanScript(pstrCode, scriptLength, attribs) ||

				// Set the IDebugDocumentHelper's attributes for this script block
				host->DebugDocumentHelper->lpVtbl->SetTextAttributes(host->DebugDocumentHelper, host->CharOffset, scriptLength, attribs))
			{
				FREEMEM(attribs);

				// Still not a fatal error
				LOGOLESTRPARAM("Failed to set text attributes!", 0);
			}
		}
	}

	// Add the length of this script block to the current character offset
	host->CharOffset += scriptLength;
}












// ===========================================================================
// The IActiveScriptSite is the main object of an ActiveX Script Host. We
// implement it here if the host's IActiveScriptSite doesn't provide a
// IActiveScriptSiteDebug sub-object.
// ===========================================================================

#if 0
/************************ QueryInterface() *************************
 */

static STDMETHODIMP QueryInterface(SMARTHOST *this, REFIID riid, void **ppvObj)
{
	if (IsEqualIID(riid, &IID_IUnknown) || IsEqualIID(riid, &IID_IActiveScriptSite) || IsEqualIID(riid, &IID_IActiveScriptSiteDebug))
	{
		*ppvObj = this;
addit:	AddRef(this);
		return(S_OK);
	}

	if (IsEqualIID(riid, &IID_IActiveScriptSiteDebug))
	{
		*ppvObj = ((unsigned char *)this + offsetof(SMARTHOST, HostScriptSiteDebug));
		goto addit;
	}

	// Let the host provide this
	return(this->HostScriptSite->lpVtbl->QueryInterface(this->HostScriptSite, riid, ppvObj));
}

/*************************** AddRef() ******************************
 */

static STDMETHODIMP_(ULONG) AddRef(SMARTHOST *this)
{
	return(++RefCount);
}

/************************** Release() ******************************
 */

static STDMETHODIMP_(ULONG) Release(SMARTHOST *this)
{
	if (--this->RefCount == 0)
	{
		if (this->DebugDocumentHelper) this->DebugDocumentHelper->lpVtbl->Release(this->DebugDocumentHelper);
		if (this->ProcDebugManager) this->ProcDebugManager->lpVtbl->Release(this->ProcDebugManager);
		if (this->DebugApplication) this->DebugApplication->lpVtbl->Release(this->DebugApplication);
		this->HostScriptSite->lpVtbl->Release(this->HostScriptSite);
		FREEMEM(this);
		return 0;
	}
	return(this->RefCount);
}

/************************** GetLCID() *************************
 * Retrieves the locale identifier associated with the host's user 
 * interface. The scripting engine uses the identifier to ensure
 * that error strings and other user-interface elements generated
 * by the engine appear in the appropriate language.
 *
 * plcid =		Where to return the language identifier.
 */

static STDMETHODIMP GetLCID(SMARTHOST *this, LCID *plcid)
{
	// Call the host's IActiveScriptSite->GetLCID
	return(this->HostScriptSite->GetLCID(this->HostScriptSite, plcid));
}

/*********************** GetItemInfo() *************************
 * Allows the script engine to obtain information about an 
 * item added with our IActiveScript::AddNamedItem.
 *
 * pstrName -- address of item name
 * dwReturnMask -- bit mask for information retrieval
 * ppunkItem -- address of pointer to item's IUnknown
 * ppTypeInfo -- address of pointer to item's ITypeInfo
 */

static STDMETHODIMP GetItemInfo(SMARTHOST *this, LPCOLESTR pstrName, DWORD dwReturnMask, IUnknown **ppunkItem, ITypeInfo **ppTypeInfo)
{
	return(this->HostScriptSite->GetItemInfo(this->HostScriptSite, pstrName, dwReturnMask, ppunkItem, ppTypeInfo));
}

/********************** GetDocVersionString() ********************
 * Retrieves a host-defined string that uniquely identifies the
 * current document version. If the related document has changed
 * outside the scope of ActiveX Scripting (as in the case of an
 * HTML page being edited with NotePad), the script engine can
 * save this along with its persisted state, forcing a recompile
 * the next time the script is loaded. 
 *
 * pbstrVersionString -- address of document version string
 */

static STDMETHODIMP GetDocVersionString(SMARTHOST *this, BSTR *pbstrVersionString)
{
	return(this->HostScriptSite->GetDocVersionString(this->HostScriptSite, pbstrVersionString));
}

/********************* OnScriptTerminate() ***********************
 * Informs the host that the script has completed execution
 *
 * pvarResult -- address of script results
 * pexcepinfo -- address of structure with exception information
 */

static STDMETHODIMP OnScriptTerminate(SMARTHOST *this, const VARIANT *pvarResult, const EXCEPINFO *pexcepinfo)
{
	return(this->HostScriptSite->OnScriptTerminate(this->HostScriptSite, pvarResult, pexcepinfo));
}

/*********************** OnStateChange() ************************
 * Informs the host that the scripting engine has changed states
 *
 * ssScriptState -- new state of engine
 */

static STDMETHODIMP OnStateChange(SMARTHOST *this, SCRIPTSTATE ssScriptState)
{
	return(this->HostScriptSite->OnStateChange(this->HostScriptSite, ssScriptState));
}

/************************ OnScriptError() ************************
 * Informs the host that an execution error occurred while the 
 * engine was running the script
 *
 * pase -- address of error interface
 */

static STDMETHODIMP OnScriptError(SMARTHOST *this, IActiveScriptError *pase)
{
	return(this->HostScriptSite->OnScriptError(this->HostScriptSite, pase));
}

/************************ OnEnterScript() ************************
 * Informs the host that the scripting engine has begun 
 * executing the script code
 */

static STDMETHODIMP OnEnterScript(SMARTHOST *this)
{
	return(this->HostScriptSite->OnEnterScript(this->HostScriptSite));
}

/*********************** OnLeaveScript() *************************
 * Informs the host that the scripting engine has returned 
 * from executing script code
 */

static STDMETHODIMP OnLeaveScript(SMARTHOST *this)
{
	return(this->HostScriptSite->OnLeaveScript(this->HostScriptSite));
}

#endif















// ===========================================================================
// The IActiveScriptSiteDebug sub-object.
// ===========================================================================

/************************ QueryInterface() *************************
 */

static STDMETHODIMP DebugQueryInterface(SMARTHOST *this, REFIID riid, void **ppvObj)
{
	if (IsEqualIID(riid, &IID_IActiveScriptSiteDebug))
	{
		*ppvObj = this;
		DebugAddRef(this);
		return(S_OK);
	}

	// Let the host provide this
	return(this->HostScriptSite->lpVtbl->QueryInterface(this->HostScriptSite, riid, ppvObj));
}

/*************************** AddRef() ******************************
 */

static STDMETHODIMP_(ULONG) DebugAddRef(SMARTHOST *this)
{
	return(++this->RefCount);
}

/************************** Release() ******************************
 */

static STDMETHODIMP_(ULONG) DebugRelease(SMARTHOST *this)
{
	if (--this->RefCount == 0)
	{
		if (this->DebugDocumentHelper) this->DebugDocumentHelper->lpVtbl->Release(this->DebugDocumentHelper);
		if (this->ProcDebugManager) this->ProcDebugManager->lpVtbl->Release(this->ProcDebugManager);
		if (this->DebugApplication) this->DebugApplication->lpVtbl->Release(this->DebugApplication);
		this->HostScriptSite->lpVtbl->Release(this->HostScriptSite);
		FREEMEM(this);
		return(0);
	}
	return(this->RefCount);
}

/**************** GetDocumentContextFromPosition() *****************
 * Called by the script engine to delegate
 * IDebugCodeContext::GetSourceContext and get the
 * IDebugDocumentContext associated with a position.
 *
 * context =	Host defined cookie which was passed to 
 *				IActiveScriptParse::ParseScriptText or 
 *				IActiveScriptParse::AddScriptlet when the 
 *				text the engine is interested in was added.
 * charOffset =	Offset from the beginning of the script block.
 * uNumChars =	Length of the script block.
 * ppsc =		Where to return the IDebugDocumentContext.
 */

static STDMETHODIMP GetDocumentContextFromPosition(SMARTHOST *this, DWORD context, ULONG charOffset, ULONG uNumChars, IDebugDocumentContext **pObj)
{
	register HRESULT	hr;
	ULONG				ulStartPos;

	// Use the IDebugDocumentHelper to delegate this call.

	// Find out where this source context starts
	if (!(hr = this->DebugDocumentHelper->lpVtbl->GetScriptBlockInfo(this->DebugDocumentHelper, context, 0, &ulStartPos, 0)))

		// Create an IDebugDocumentContext
		hr = this->DebugDocumentHelper->lpVtbl->CreateDebugDocumentContext(this->DebugDocumentHelper, ulStartPos + charOffset, uNumChars, pObj);

	return(hr);
}

/************************ GetApplication() ***********************
 * Returns the debug application object associated with this 
 * script site. Provides a means for a smart host to define what
 * application object each script belongs to. Script engines should
 * attempt to call this method to get their containing application
 * and resort to IProcessDebugManager::GetDefaultApplication if
 * this fails. 
 *
 * ppda =	Where to return the IDebugApplication pointer.
 *
 *  Returns: S_OK, E_POINTER, E_FAIL
 */

static STDMETHODIMP GetApplication(SMARTHOST *this, IDebugApplication **pObj)
{
	return(this->DebugApplication->lpVtbl->QueryInterface(this->DebugApplication, &IID_IDebugApplication, (void **)pObj));
}

/******************** GetRootApplicationNode() ***********************
 * Gets the application node under which script documents should be
 * added. This method can return NULL if script documents should be
 * top-level.
 *
 * ppdanRoot =	Where to return the IDebugApplicationNode pointer.
 *
 *  Returns: S_OK, E_POINTER, E_FAIL
 */

static STDMETHODIMP GetRootApplicationNode(SMARTHOST *this, IDebugApplicationNode **pObj)
{
	return(this->DebugApplication->lpVtbl->GetRootNode(this->DebugApplication, pObj));
}

/*********************** OnScriptErrorDebug() ************************
 * Allows a smart host to control the handling of runtime errors.
 *
 * errorDebug =		The runtime error that occurred 
 * enterDebugger =	Whether to pass the error to the debugger to 
 *					do JIT debugging
 * callContinue =	Whether to call IActiveScriptSite::OnScriptError()
 *					when the user decides to continue without debugging. 
 *
 *  Returns: S_OK, E_POINTER, E_FAIL
 */

static STDMETHODIMP OnScriptErrorDebug(SMARTHOST *this, IActiveScriptErrorDebug *errorDebug, BOOL *enterDebugger, BOOL *callContinue)
{
	// Request JIT debugging
	*enterDebugger =

	// If JIT debugging is declined, call IActiveScriptSite::OnScriptError
	*callContinue = 1;

	return(S_OK);
}
