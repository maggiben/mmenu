#ifndef ICLASSFACTORY_H
#define ICLASSFACTORY_H

extern HMODULE DllHandle;
extern CRITICAL_SECTION	InterruptSection;
extern struct _ACTIVESCRIPT	*ActiveScriptList;

extern void incOutstandingObjs(void);
extern void decOutstandingObjs(void);

#endif
