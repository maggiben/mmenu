// Registers our TScript.DLL as an ActiveX Script Engine.

#define INITGUID
#include <windows.h>
#include <tchar.h>
#include <objbase.h>
#include <guiddef.h>
#include <activscp.h>
#include <comcat.h>
#include "../Guids.c"

// Set this to the desired language name used in the HTML tag, for example VBscript
static const TCHAR		LanguageName[] = "CMinus";

// Set this to a description of the engine
static const TCHAR		Description[] = "CMinus Language";

// Set this to an alternate language name, if you hav one
#ifdef GOT_LANGALTERNATENAME
static const TCHAR		AltLanguageName[] = "CMinus2";
#endif

// Set this to an extension associated with the engine, if you have one, such as vbs
#ifdef GOT_EXTENSION
static const TCHAR		ExtensionStr[] = "xxx";
#endif

static const TCHAR Failure[] = _T("Failed to register CMinus.dll as an ActiveX script engine.");
static const TCHAR Success[] = _T("CMinus.dll registered as an ActiveX script engine.");

// Do not change these strings
static const wchar_t	ActiveScriptEngineStr[] = L"Active Scripting Engine";
static const wchar_t	ActiveParseEngineStr[] = L"Active Scripting Engine with Parsing";
static const TCHAR		OleScriptStr[] = "OLEScript";
static const TCHAR		CLSIDStr[] = "CLSID";
static const TCHAR		ProgIDStr[] = "ProgID";
static const TCHAR		BothStr[] = "Both";
static const TCHAR		GUID_Format[] = _T("{%08lX-%04X-%04X-%02X%02X-%02X%02X%02X%02X%02X%02X}");
#if !NOMULTITHREAD
static const TCHAR		ThreadingModel[] = "ThreadingModel";
static const TCHAR		ServerKeyName[] = "InprocServer32";
#endif

// For File Dialog
static const TCHAR		FileDlgExt[] = _T("DLL files\000*.dll\000\000");
static const TCHAR		OurDllName[] = _T("CMinus.dll");
static const TCHAR		FileDlgTitle[] = _T("Locate CMinus.dll to register it");






/************************ stringFromCLSID() ***********************
 * Converts an object's GUID (array) to an ascii string (in a special
 * format where there are groups of ascii digits separated by a dash).
 * NOTE: Using wsprintf() avoids needing to load ole32.dll just to
 * call StringFromCLSID(). We're just doing the same thing it would do.
 */

static void stringFromCLSID(LPTSTR buffer, REFCLSID ri)
{
	wsprintf(buffer, &GUID_Format[0],
		((REFCLSID)ri)->Data1, ((REFCLSID)ri)->Data2, ((REFCLSID)ri)->Data3, ((REFCLSID)ri)->Data4[0],
		((REFCLSID)ri)->Data4[1], ((REFCLSID)ri)->Data4[2], ((REFCLSID)ri)->Data4[3],
		((REFCLSID)ri)->Data4[4], ((REFCLSID)ri)->Data4[5], ((REFCLSID)ri)->Data4[6],
		((REFCLSID)ri)->Data4[7]);
}





/************************** cleanup() ************************
 * Unregisters this entity as an ActiveX script engine.
 */

void cleanup(void)
{
	{
	ICatRegister	*pcr;

	if (!CoCreateInstance(&CLSID_StdComponentCategoriesMgr, 0, CLSCTX_ALL, &IID_ICatRegister, (void **)&pcr))
	{
		// Unregister this category as being "implemented" by the class
		CATID rgcatid[1];

		rgcatid[0] = CATID_ActiveScript;
		pcr->lpVtbl->UnRegisterClassImplCategories(pcr, &CLSID_CMinus, 1, rgcatid);

		rgcatid[0] = CATID_ActiveScriptParse;
		pcr->lpVtbl->UnRegisterClassImplCategories(pcr, &CLSID_CMinus, 1, rgcatid);

		pcr->lpVtbl->Release(pcr);
	}
	}

	{
	HKEY		hk;
	TCHAR		buffer[MAX_PATH];

	stringFromCLSID(&buffer[0], (REFCLSID)&CLSID_CMinus);

	// Delete HKEY_CLASSES_ROOT\{LanguageName}\*
	if (!RegOpenKey(HKEY_CLASSES_ROOT, &LanguageName[0], &hk))
	{
		// Delete HKEY_CLASSES_ROOT\{LanguageName}\CLSID
		RegDeleteKey(hk, &CLSIDStr[0]);

		// Delete HKEY_CLASSES_ROOT\{LanguageName}\OLEScript
		RegDeleteKey(hk, &OleScriptStr[0]);

		RegCloseKey(hk);

		// Delete HKEY_CLASSES_ROOT\{LanguageName}
		RegDeleteKey(HKEY_CLASSES_ROOT, &LanguageName[0]);
	}

	// Delete alternate language key
#ifdef GOT_LANGALTERNATENAME
	if (!RegOpenKey(HKEY_CLASSES_ROOT, &AltLanguageName[0], &hk))
	{
		RegDeleteKey(hk, &CLSIDStr[0]);
		RegDeleteKey(hk, &OleScriptStr[0]);
		RegCloseKey(hk);
		RegDeleteKey(HKEY_CLASSES_ROOT, &AltLanguageName[0]);
	}
#endif

	// Delete HKEY_CLASSES_ROOT\CLSID\{class GUID string}\*
 	if (!RegOpenKey(HKEY_CLASSES_ROOT, &CLSIDStr[0], &hk))
	{
		// Delete HKEY_CLASSES_ROOT\CLSID\{class GUID string}\progid
		RegDeleteKey(hk, &ProgIDStr[0]);

		// Delete HKEY_CLASSES_ROOT\CLSID\{class GUID string}\OLEScript
		RegDeleteKey(hk, &OleScriptStr[0]);

		// Delete HKEY_CLASSES_ROOT\CLSID\{class GUID string}
		RegDeleteKey(hk, &ServerKeyName[0]);
		RegCloseKey(hk);

		// Delete HKEY_CLASSES_ROOT\CLSID\{class GUID string}\*
		RegDeleteKey(hk, &buffer[0]);
	}
	}

#ifdef GOT_EXTENSION
	// Delete extension key
	RegDeleteKey(HKEY_CLASSES_ROOT, &ExtensionStr[0]);
#endif
}





/************************** WinMain() ************************
 * Program Entry point
 */

int WINAPI WinMain(HINSTANCE hinstExe, HINSTANCE hinstPrev, LPSTR lpszCmdLine, int nCmdShow)
{
	HRESULT			hr;
	TCHAR			filename[MAX_PATH];

	{
	OPENFILENAME	ofn;

	// Pick out where our DLL is located. We need to know its location in
	// order to register it as a COM component
	lstrcpy(&filename[0], &OurDllName[0]);
	ZeroMemory(&ofn, sizeof(OPENFILENAME));
	ofn.lStructSize = sizeof(OPENFILENAME);
	ofn.lpstrFilter = &FileDlgExt[0];
	ofn.lpstrFile = &filename[0];
	ofn.nMaxFile = MAX_PATH;
	ofn.lpstrTitle = &FileDlgTitle[0];
	ofn.Flags = OFN_FILEMUSTEXIST|OFN_EXPLORER|OFN_PATHMUSTEXIST;
	hr = GetOpenFileName(&ofn);
	}

	if (hr)
	{
		CoInitialize(0);

		// Create scripting categories
		{
		ICatRegister		*pcr;
		CATEGORYINFO		catinfo;
		CATID				rgcatid[1];

		catinfo.lcid = 0x0409 ; // english

		// Get the ICatRegister object
		if (!(hr = CoCreateInstance(&CLSID_StdComponentCategoriesMgr, 0, CLSCTX_ALL, &IID_ICatRegister, (void **)&pcr)))
		{
			// Register our engine (ie, put its IClassFactory GUID) under HKCR\Component Categories\CATID_ActiveScript.
			// This indicates out engine implements an IActiveScript object and one of the IPersist* objects
			// (IPersistStorage, IPersistStreamInit, or IPersistPropertyBag)
			rgcatid[0] = catinfo.catid = CATID_ActiveScript;
			lstrcpyW(catinfo.szDescription, &ActiveScriptEngineStr[0]);
			if (!(hr = pcr->lpVtbl->RegisterCategories(pcr, 1, &catinfo)))
			{
				if (!(hr = pcr->lpVtbl->RegisterClassImplCategories(pcr, &CLSID_CMinus, 1, rgcatid)))
				{
					// Register our engine under HKCR\Component Categories\CATID_ActiveScriptParse.
					// This indicates out engine IActiveScript and IActiveScriptParse objects
					rgcatid[0] = catinfo.catid = CATID_ActiveScriptParse;
					lstrcpyW(catinfo.szDescription, &ActiveParseEngineStr[0]);
					if (!(hr = pcr->lpVtbl->RegisterCategories(pcr, 1, &catinfo)))
						hr = pcr->lpVtbl->RegisterClassImplCategories(pcr, &CLSID_CMinus, 1, rgcatid);
				}
			}

			pcr->lpVtbl->Release(pcr);
		}
		}

		if (!hr)
		{
			HKEY		hk;
			HKEY		hkSub;
			HKEY		hkSub2;
			TCHAR		buffer[39];

			stringFromCLSID(&buffer[0], (REFCLSID)&CLSID_CMinus);

			// Register this engine's Language name (which would be used in an HTML script tag)
			if (!(hr = RegCreateKey(HKEY_CLASSES_ROOT, &LanguageName[0], &hk)))
			{
				if (!(hr = RegCreateKey(hk, &OleScriptStr[0], &hkSub)))
				{
					RegCloseKey(hkSub);
 					RegSetValue(HKEY_CLASSES_ROOT, &LanguageName[0], REG_SZ, &Description[0], lstrlen(&Description[0]) + 1);
					hr = RegSetValue(hk, &CLSIDStr[0], REG_SZ, &buffer[0], lstrlen(&buffer[0]) + 1);
				}

				RegCloseKey(hk);
			}

			if (!hr)
			{
				// Register "alternate language" name like above
#ifdef GOT_LANGALTERNATENAME
				if (!(hr = RegCreateKey(HKEY_CLASSES_ROOT, &AltLanguageName[0], &hk)))
				{
					if (!(hr = RegCreateKey(hk, &OleScriptStr[0], &hkSub)))
					{
						RegCloseKey(hkSub);
						RegSetValue(HKEY_CLASSES_ROOT, &AltLanguageName[0], REG_SZ, &Description[0], lstrlen(&Description[0]) + 1);
						hr = RegSetValue(hk, &CLSIDStr[0], REG_SZ, &buffer[0], lstrlen(&buffer[0]) + 1);
					}
					RegCloseKey(hk);
				}

				if (!hr)
				{
#endif
					// Register createable class
					if (!(hr = RegCreateKey(HKEY_CLASSES_ROOT, &CLSIDStr[0], &hk)))
					{
						if (!(hr = RegCreateKey(hk, &buffer[0], &hkSub)))
						{
							if (!(hr = RegCreateKey(hkSub, &OleScriptStr[0], &hkSub2)))
							{
								RegSetValue(hk, &buffer[0], REG_SZ, &Description[0], lstrlen(&Description[0]) + 1);
								if (!(hr = RegSetValue(hkSub, &ProgIDStr[0], REG_SZ, &LanguageName[0], lstrlen(&LanguageName[0]) + 1)))
								{
									if (!(hr = RegSetValue(hkSub, &ServerKeyName[0], REG_SZ, &filename[0], lstrlen(&filename[0]) + 1)))
									{
#if !NOMULTITHREAD
										HKEY	hkthread;

										// Set the threading model reg entry
										if (!(hr = RegOpenKeyEx(hkSub, &ServerKeyName[0], 0, KEY_SET_VALUE, &hkthread)))
										{
											hr = RegSetValueEx(hkthread, &ThreadingModel[0], 0, REG_SZ, (BYTE *)&BothStr[0], lstrlen(&BothStr[0]) + 1);
											RegCloseKey(hkthread);
										}
#endif // !NOMULTITHREAD
									}
								}

								RegCloseKey(hkSub2);
							}

							RegCloseKey(hkSub);
						}

						RegCloseKey(hk);
					}

#ifdef GOT_EXTENSION
					// Register the extension
					if (!hr) hr = RegSetValue(HKEY_CLASSES_ROOT, &ExtensionStr[0], REG_SZ, &LanguageName[0], lstrlen(&LanguageName[0]) + 1);
#endif
#ifdef GOT_LANGALTERNATENAME
				}
#endif
			}
		}

		CoUninitialize();

		// If an error, make sure we clean everything up
		if (hr)
		{
			cleanup();
			MessageBox(0, &Failure[0], &Description[0], MB_OK|MB_ICONEXCLAMATION);
		}
		else
			MessageBox(0, &Success[0], &Description[0], MB_OK|MB_ICONEXCLAMATION);
	}

	return(0);
}
