/*
 * Define the guids used by the project. Both internally defined
 * guids as well as guids from external sources.
 */

#ifdef __cplusplus
extern "C" {
#endif

#include <initguid.h>
#include "guids.h"

// You must replace the following GUID with your own when building a new script engine. Use GUIDGEN.exe
// GUID for this script engine {BDFF3FEB-48AA-4bc8-ACB7-EDC66F252931}
DEFINE_GUID(CLSID_CMinus, 0xbdff3feb, 0x48aa, 0x4bc8, 0xac, 0xb7, 0xed, 0xc6, 0x6f, 0x25, 0x29, 0x31);

// These are standard Microsoft GUIDs, and should not be changed
const GUID IID_IActiveScriptSiteDebug32 = {0x51973C11, 0xCB0C, 0x11d0, 0xB5, 0xC9, 0x00, 0xA0, 0x24, 0x4A, 0x0E, 0x7A};
const GUID IID_IActiveScriptDebug32 = {0x51973C10, 0xCB0C, 0x11d0, 0xB5, 0xC9, 0x00, 0xA0, 0x24, 0x4A, 0x0E, 0x7A};
const GUID IID_IProcessDebugManager32 = {0x51973C2f, 0xCB0C, 0x11d0, 0xB5, 0xC9, 0x00, 0xA0, 0x24, 0x4A, 0x0E, 0x7A};
const GUID IID_IDebugApplication32 = {0x51973C32, 0xCB0C, 0x11d0, 0xB5, 0xC9, 0x00, 0xA0, 0x24, 0x4A, 0x0E, 0x7A};

// NOTE: These strings should be changed for your own script engine
const WCHAR FullEngineLanguageStr[] =  L"C-- v1.0";
const WCHAR ShortEngineLanguageStr[] =  L"C--";	// C language implementation

const WCHAR DebugDocName[] = L"C-- document";
const WCHAR DebugHostName[] = L"CMinus";
const TCHAR	LangDllErrTitle[] = _T("C-- Language DLL");

#ifdef __cplusplus
}
#endif
