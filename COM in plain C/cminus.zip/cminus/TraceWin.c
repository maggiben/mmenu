#ifdef LOGTRACE

#include <windows.h>
#include <objbase.h>
#include "tracewin.h"
#include "tchar.h"

#define IDC_EDIT		1000
#define TEXTLIMIT		10000

static HANDLE			ThreadInitSignal;
static HANDLE			ThreadHandle = 0;
HWND					TraceWindow = 0;
static DWORD			Indent;
static HWND				EditWindow;
static short			Chars;

static const TCHAR		GUID_Format[] = _T("{%08lX-%04X-%04X-%02X%02X-%02X%02X%02X%02X%02X%02X}");
static const TCHAR		DebugWndClass[] = _T("TraceWin");
static const TCHAR		Separator[] = _T(" : ");
static const TCHAR		Comma[] = _T(", ");
static const TCHAR		NoStr[] = _T("$NOSTR$");
static const TCHAR		Opening[] = _T(" : [");
static const TCHAR		Closing[] = _T("]\r\n");
static const TCHAR		EngineStates[] = {"UNINITIALIZED\0\
STARTED\0\
CONNECTED\0\
DISCONNECTED\0\
CLOSED\0\
INITIALIZED\0\
UNKNOWN\0"};





static LRESULT CALLBACK debugTraceWndProc(HWND hwnd, UINT uMsg, WPARAM wparam, LPARAM lparam)
{
	switch (uMsg)
	{
		case WM_CREATE:
		{
			if (!(EditWindow = CreateWindow("EDIT", 0, WS_CHILD|WS_VISIBLE|WS_VSCROLL|ES_LEFT|ES_MULTILINE|ES_AUTOVSCROLL|ES_READONLY,
					0, 0, 0, 0, hwnd, (HMENU)IDC_EDIT, (HINSTANCE)GetWindowLong(hwnd, GWL_HINSTANCE), 0)))
			{
				return(-1);
			}

			SendMessage(EditWindow, EM_SETLIMITTEXT, TEXTLIMIT + 64, 0);

			Chars = Indent = 0;
			break;
		}

		case WM_SIZE:
			MoveWindow(EditWindow, 0, 0, LOWORD(lparam), HIWORD(lparam), TRUE);
			break;

		case WM_SETFOCUS:
			SetFocus(EditWindow);
			break;

		case WM_DESTROY:
			TraceWindow = 0;

		default:
			return(DefWindowProc(hwnd, uMsg, wparam, lparam));
	}

	return(0);
}





static DWORD WINAPI traceThread(void *arg)
{
	register	ATOM	*rc;
	{
	WNDCLASS			wc;

	ZeroMemory(&wc, sizeof(WNDCLASS));
	wc.style = CS_HREDRAW|CS_VREDRAW;
	wc.lpfnWndProc = debugTraceWndProc;
	wc.hInstance = GetModuleHandle(0);
	wc.hCursor = LoadCursor(0, MAKEINTRESOURCE(IDC_ARROW));
	wc.hbrBackground = (HBRUSH)(COLOR_WINDOW + 1);
	wc.lpszClassName = &DebugWndClass[0];

	// Make a window class instance for the window we want to create
	rc = RegisterClass(&wc);
	}
	if (rc)	
	{
		// Create window of default size
		if ((TraceWindow = CreateWindow(&DebugWndClass[0], "Debug Trace Window", WS_OVERLAPPEDWINDOW|WS_VISIBLE, 
			CW_USEDEFAULT, 0, CW_USEDEFAULT, 0, 0, 0, GetModuleHandle(0), 0)))
		{
			MSG		msg;

			// Update and show window
			ShowWindow(TraceWindow, SW_SHOW);
			UpdateWindow(TraceWindow);

			// Let main thread know that we're initialized
			SetEvent(ThreadInitSignal);

			// Do the message handling
			while (TraceWindow && GetMessage(&msg, TraceWindow, 0, 0) == 1)
			{
				TranslateMessage(&msg);
				DispatchMessage(&msg);
			}

			ThreadHandle = 0;
			return(0);
		}
	}

	ThreadHandle = 0;
	SetEvent(ThreadInitSignal);
	return(1);
}





void traceCloseWindow(void)
{
	if (ThreadHandle)
	{
		DestroyWindow(TraceWindow);
		WaitForSingleObject(ThreadHandle, INFINITE);
	}
}





void traceOpenWindow(HWND parent)
{
	// Is the thread started?
	if (!ThreadHandle)
	{
		// Get a signal that the thread can use to notify us when its done initializing
		if ((ThreadInitSignal = CreateEvent(0, TRUE, 0, 0)))
		{
			DWORD		threadID;

			if ((ThreadHandle = CreateThread(0, 0, traceThread, 0, 0, &threadID)))
			{
				// Wait for the thread to indicate its initialization is done
				WaitForSingleObject(ThreadInitSignal, INFINITE);
			}

			// We no longer need the signal
			CloseHandle(ThreadInitSignal);
		}
	}
}





static void indent(LPTSTR ptr)
{
	register DWORD	i;
	register LPTSTR	str;

	i = (DWORD)-1;
	if (Chars >= TEXTLIMIT) i = Chars = 0;
	SendMessage(EditWindow, EM_SETSEL, i, -1);

	str = ptr;
	if ((i = Indent))
	{
		Chars += (i * 2);
		while (i--)
		{
			lstrcpy(str, "  ");
			str += (2 * sizeof(TCHAR));
		}

		*str = 0;

		SendMessage(EditWindow, EM_REPLACESEL, 0, (LPARAM)ptr);
		SendMessage(EditWindow, EM_SETSEL, (WPARAM)-1, -1);
	}
}




static void newline(void)
{
	Chars += 2;
	SendMessage(EditWindow, EM_REPLACESEL, 0, (LPARAM)&Closing[1]);
	SendMessage(EditWindow, EM_SETSEL, (WPARAM)-1, -1);
}





void traceEnterFunc(LPCTSTR pszfuncName)
{
	TCHAR		buffer[120];

	if (!Indent) newline();
	indent(&buffer[0]);
	Chars += lstrlen(pszfuncName);
	SendMessage(EditWindow, EM_REPLACESEL, 0, (LPARAM)pszfuncName);
	SendMessage(EditWindow, EM_SETSEL, (WPARAM)-1, -1);
	newline();
	++Indent;
}





void traceShowArgs(LPCTSTR pszMsg, DWORD cArgs, VARIANT *rgpvarArgs)
{
	DWORD		i;
	TCHAR		buffer[256];
	VARIANTARG	varDest;

	indent(&buffer[0]);
	SendMessage(EditWindow, EM_REPLACESEL, 0, (LPARAM)pszMsg);
	Chars += lstrlen(pszMsg);
	SendMessage(EditWindow, EM_SETSEL, (WPARAM)-1, -1);

	SendMessage(EditWindow, EM_REPLACESEL, 0, (LPARAM)&Separator[0]);
	Chars += (sizeof(Separator) - sizeof(TCHAR));
	SendMessage(EditWindow, EM_SETSEL, (WPARAM)-1, -1);

	for (i = 0; i < cArgs; i++)
	{
		VariantInit(&varDest);
		if (!VariantChangeType(&varDest, &(rgpvarArgs[i]), 0, VT_BSTR))
		{
#ifndef UNICODE
			WideCharToMultiByte(CP_ACP, 0, varDest.bstrVal, -1, &buffer[0], sizeof(buffer), 0, 0);
			SendMessage(EditWindow, EM_REPLACESEL, 0, (LPARAM)&buffer[0]);
#else
			SendMessage(EditWindow, EM_REPLACESEL, 0, (LPARAM)varDest.bstrVal);
#endif
			VariantClear(&varDest);
			Chars += lstrlen(&buffer[0]);
		}
		else
		{
			SendMessage(EditWindow, EM_REPLACESEL, 0, (LPARAM)&NoStr[0]);
			Chars += (sizeof(NoStr) - sizeof(TCHAR));
		}

		SendMessage(EditWindow, EM_SETSEL, (WPARAM)-1, -1);

		if (i+1 != cArgs)
		{
			SendMessage(EditWindow, EM_REPLACESEL, 0, (LPARAM)&Comma[0]);
			SendMessage(EditWindow, EM_SETSEL, (WPARAM)-1, -1);
			Chars += (sizeof(Comma) - sizeof(TCHAR));
		}
	}

	newline();
}





void traceShowState(DWORD dwstFrom, DWORD dwstTo)
{
	TCHAR	buffer[256];
	LPTSTR	ptr;
	LPCTSTR	state;

	indent(&buffer[0]);

	ptr = &buffer[0];
	lstrcpy(ptr, "Changing State from ");
	ptr += lstrlen(ptr);

	state = &EngineStates[0];
	while (*state && dwstFrom--) state += (lstrlen(state) + 1);
	lstrcpy(ptr, state);
	ptr += lstrlen(ptr);

	lstrcpy(ptr, " to ");
	ptr += lstrlen(ptr);		

	state = &EngineStates[0];
	while (*state && dwstTo--) state += (lstrlen(state) + 1);
	lstrcpy(ptr, state);

	SendMessage(EditWindow, EM_SETSEL, (WPARAM)-1, -1);
	SendMessage(EditWindow, EM_REPLACESEL, 0, (LPARAM)&buffer[0]);
	Chars += lstrlen(&buffer[0]);
}





void traceShowInt(LPCTSTR pszMsg, DWORD dwParam)
{
	TCHAR	buffer[256];

	indent(&buffer[0]);
	Chars += wsprintf(&buffer[0], "%s : %ld\r\n", pszMsg, dwParam);
	SendMessage(EditWindow, EM_REPLACESEL, 0, (LPARAM)&buffer[0]);
}





void traceShowHex(LPCTSTR pszMsg, DWORD dwParam)
{
	TCHAR	buffer[256];

	indent(&buffer[0]);
	Chars += wsprintf(&buffer[0], "%s : 0x%08X\r\n", pszMsg, dwParam);
	SendMessage(EditWindow, EM_REPLACESEL, 0, (LPARAM)&buffer[0]);
}





void traceShowGUID(LPCTSTR pszMsg, const GUID *ri)
{
	TCHAR		buffer[39];

	indent(&buffer[0]);
	SendMessage(EditWindow, EM_REPLACESEL, 0, (LPARAM)pszMsg);
	SendMessage(EditWindow, EM_SETSEL, (WPARAM)-1, -1);

	Chars += wsprintf(buffer, &GUID_Format[0],
		((REFCLSID)ri)->Data1, ((REFCLSID)ri)->Data2, ((REFCLSID)ri)->Data3, ((REFCLSID)ri)->Data4[0],
		((REFCLSID)ri)->Data4[1], ((REFCLSID)ri)->Data4[2], ((REFCLSID)ri)->Data4[3],
		((REFCLSID)ri)->Data4[4], ((REFCLSID)ri)->Data4[5], ((REFCLSID)ri)->Data4[6],
		((REFCLSID)ri)->Data4[7]);

	SendMessage(EditWindow, EM_REPLACESEL, 0, (LPARAM)buffer);
	SendMessage(EditWindow, EM_SETSEL, (WPARAM)-1, -1);
}




void traceShowStr(LPCTSTR pszMsg, LPCOLESTR pwzParam)
{
	TCHAR	buffer[256];

	indent(&buffer[0]);
	SendMessage(EditWindow, EM_REPLACESEL, 0, (LPARAM)pszMsg);
	SendMessage(EditWindow, EM_SETSEL, (WPARAM)-1, -1);

	if (pwzParam)
	{
		SendMessage(EditWindow, EM_REPLACESEL, 0, (LPARAM)&Opening[0]);
		SendMessage(EditWindow, EM_SETSEL, (WPARAM)-1, -1);

#ifndef UNICODE
		Chars += WideCharToMultiByte(CP_ACP, 0, pwzParam, -1, buffer, sizeof(buffer), 0, 0);
		SendMessage(EditWindow, EM_REPLACESEL, 0, (LPARAM)&buffer[0]);
#else
		SendMessage(EditWindow, EM_REPLACESEL, 0, (LPARAM)pwzParam);
		Chars += lstrlen(pwzParam);
#endif
		SendMessage(EditWindow, EM_SETSEL, (WPARAM)-1, -1);

		SendMessage(EditWindow, EM_REPLACESEL, 0, (LPARAM)&Closing[0]);
	}
	else
		newline();
}





void traceShowWStr(LPCOLESTR pwzParam, DWORD nl)
{
	TCHAR	buffer[256];

	indent(&buffer[0]);
#ifndef UNICODE
	Chars += WideCharToMultiByte(CP_ACP, 0, pwzParam, -1, &buffer[0], sizeof(buffer), 0, 0);
	SendMessage(EditWindow, EM_REPLACESEL, 0, (LPARAM)&buffer[0]);
#else
	SendMessage(EditWindow, EM_REPLACESEL, 0, (LPARAM)pwzParam);
	Chars += lstrlen(pwzParam);
#endif

	if (nl)
	{
		SendMessage(EditWindow, EM_SETSEL, (WPARAM)-1, -1);
		newline();
	}
}





void traceLeaveFunc(void)
{
	if (Indent) --Indent;

	traceMsgHandler();
}





void traceMsgHandler(void)
{
	if (TraceWindow)
	{
		MSG		msg;

		while (PeekMessage(&msg, TraceWindow, 0, 0, PM_REMOVE)) DispatchMessage(&msg);
	}
}
#endif