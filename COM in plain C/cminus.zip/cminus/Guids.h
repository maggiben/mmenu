#ifndef GUIDS_H
#define GUIDS_H

#include <windows.h>
#include <tchar.h>

extern const CLSID CLSID_CMinus;

extern const WCHAR FullEngineLanguageStr[];
extern const WCHAR ShortEngineLanguageStr[];

extern const WCHAR DebugDocName[];
extern const WCHAR DebugHostName[];
extern const TCHAR LangDllErrTitle[];

//extern const GUID IID_IActiveScriptSiteDebug32;
//extern const GUID IID_IActiveScriptDebug32;
//extern const GUID IID_IProcessDebugManager32;
//extern const GUID IID_IDebugApplication32;

#endif