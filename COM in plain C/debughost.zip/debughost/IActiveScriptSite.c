// IActiveScriptSite.c
//
// This file contains our MyRealIActiveScriptSite object. This is
// a multiple interface object that has a standard IActiveScriptSite
// as the base object, and a standard IActiveScriptSiteWindow and
// IActiveScriptSiteDebug sub-objects.
//
// Our IActiveScriptSite's GetItemInfo function knows about, and
// returns, only one automation object that we allow the script to
// use via the name "application". This causes a pointer to our IApp
// (actually MyRealIApp) object to be returned.
//
// We also have our COM objects needed to do debugging. These include
// the IDebugDocumentTextAuthor (which also encapsules the IDebugDocumentText,
// IDebugDocument, IDebugDocumentProvider, and IDebugDocumentInfo objects).
// This is wrapped by our own

#include <windows.h>
#include <stddef.h>
#include <activscp.h>
#include <activdbg.h>
#include "IActiveScriptSite.h"
#include "Extern.h" 
#include "CallStack.h" 
#include "Variables.h"

// IActiveScriptSite VTable. NOTE: These functions should really have an
// IActiveScriptSite * as the first arg. But since our MyRealIActiveScriptSite
// starts with an IActiveScriptSite, they are essentially the same thing. But
// we specify MyRealIActiveScriptSite so that our functions don't have to do
// a lot of recasting from IActiveScriptSite to MyRealIActiveScriptSite. Ignore
// the trivial warning message from the compiler
static STDMETHODIMP QueryInterface(MyRealIActiveScriptSite *, REFIID, void **);
static STDMETHODIMP_(ULONG) AddRef(MyRealIActiveScriptSite *);
static STDMETHODIMP_(ULONG) Release(MyRealIActiveScriptSite *);
static STDMETHODIMP GetLCID(MyRealIActiveScriptSite *, LCID *);
static STDMETHODIMP GetItemInfo(MyRealIActiveScriptSite *, LPCOLESTR, DWORD, IUnknown **, ITypeInfo **);
static STDMETHODIMP GetDocVersionString(MyRealIActiveScriptSite *, BSTR *);
static STDMETHODIMP OnScriptTerminate(MyRealIActiveScriptSite *, const VARIANT *, const EXCEPINFO *);
static STDMETHODIMP OnStateChange(MyRealIActiveScriptSite *, SCRIPTSTATE);
static STDMETHODIMP OnScriptError(MyRealIActiveScriptSite *, IActiveScriptError *);
static STDMETHODIMP OnEnterScript(MyRealIActiveScriptSite *);
static STDMETHODIMP OnLeaveScript(MyRealIActiveScriptSite *);

static const IActiveScriptSiteVtbl SiteTable = {
	QueryInterface,
	AddRef,
	Release,
	GetLCID,
	GetItemInfo,
	GetDocVersionString,
	OnScriptTerminate,
	OnStateChange,
	OnScriptError,
	OnEnterScript,
	OnLeaveScript};

// IActiveScriptSiteWindow VTable
static STDMETHODIMP siteWnd_QueryInterface(IActiveScriptSiteWindow *, REFIID, void **);
static STDMETHODIMP_(ULONG) siteWnd_AddRef(IActiveScriptSiteWindow *);
static STDMETHODIMP_(ULONG) siteWnd_Release(IActiveScriptSiteWindow *);
static STDMETHODIMP GetSiteWindow(IActiveScriptSiteWindow *, HWND *);
static STDMETHODIMP EnableModeless(IActiveScriptSiteWindow *, BOOL);

static const IActiveScriptSiteWindowVtbl SiteWindowTable = {
	siteWnd_QueryInterface,
	siteWnd_AddRef,
	siteWnd_Release,
	GetSiteWindow,
	EnableModeless};

// IActiveScriptSiteDebug VTable
static STDMETHODIMP DebugQueryInterface(IActiveScriptSiteDebug *, REFIID, void **);
static STDMETHODIMP_(ULONG) DebugAddRef(IActiveScriptSiteDebug *);
static STDMETHODIMP_(ULONG) DebugRelease(IActiveScriptSiteDebug *);
static STDMETHODIMP GetDocumentContextFromPosition(IActiveScriptSiteDebug *, DWORD, ULONG, ULONG, IDebugDocumentContext **); 
static STDMETHODIMP GetApplication(IActiveScriptSiteDebug *, IDebugApplication **); 
static STDMETHODIMP GetRootApplicationNode(IActiveScriptSiteDebug *, IDebugApplicationNode **); 
static STDMETHODIMP OnScriptErrorDebug(IActiveScriptSiteDebug *, IActiveScriptErrorDebug *, BOOL *, BOOL *);

const IActiveScriptSiteDebug32Vtbl IActiveScriptSiteDebug_Vtbl = {DebugQueryInterface,
DebugAddRef,
DebugRelease,
GetDocumentContextFromPosition,
GetApplication,
GetRootApplicationNode,
OnScriptErrorDebug};

// IDebugDocumentTextAuthor VTable. NOTE: These functions should really have an
// IDebugDocumentTextAuthor * as the first arg. But since our MyRealIDebugDocument
// starts with an IDebugDocumentTextAuthor, they are essentially the same thing. But
// we specify MyRealIDebugDocument so that our functions don't have to do
// a lot of recasting from IDebugDocumentTextAuthor to MyRealIDebugDocument. Ignore
// the trivial warning message from the compiler
static STDMETHODIMP textAuthQueryInterface(MyRealIDebugDocument *, REFIID, void **);
static STDMETHODIMP_(ULONG) textAuthAddRef(MyRealIDebugDocument *);
static STDMETHODIMP_(ULONG) textAuthRelease(MyRealIDebugDocument *);
static STDMETHODIMP GetName(MyRealIDebugDocument *, DOCUMENTNAMETYPE, BSTR *);
static STDMETHODIMP GetDocumentClassId(MyRealIDebugDocument *, CLSID *);
static STDMETHODIMP GetDocumentAttributes(MyRealIDebugDocument *, TEXT_DOC_ATTR *);
static STDMETHODIMP GetSize(MyRealIDebugDocument *, ULONG *, ULONG *);
static STDMETHODIMP GetPositionOfLine(MyRealIDebugDocument *, ULONG, ULONG *);
static STDMETHODIMP GetLineOfPosition(MyRealIDebugDocument *, ULONG, ULONG *, ULONG *);
static STDMETHODIMP GetText(MyRealIDebugDocument *, ULONG, WCHAR *, SOURCE_TEXT_ATTR *, ULONG *, ULONG);
static STDMETHODIMP GetPositionOfContext(MyRealIDebugDocument *, IDebugDocumentContext *, ULONG *, ULONG *);
static STDMETHODIMP GetContextOfPosition(MyRealIDebugDocument *, ULONG, ULONG, IDebugDocumentContext **);
static STDMETHODIMP InsertText(MyRealIDebugDocument *, ULONG, ULONG, OLECHAR *);
static STDMETHODIMP RemoveText(MyRealIDebugDocument *, ULONG, ULONG);
static STDMETHODIMP textReplaceText(MyRealIDebugDocument *, ULONG, ULONG, OLECHAR *);

// NOTE: The IDebugDocumentTextAuthor also encapsules the IDebugDocumentText, IDebugDocument,
// IDebugDocumentProvider, and IDebugDocumentInfo objects
static const IDebugDocumentTextAuthorVtbl TextAuthorTable = {
	textAuthQueryInterface,
	textAuthAddRef,
	textAuthRelease,
	GetName,
	GetDocumentClassId,
	GetDocumentAttributes,
	GetSize,
	GetPositionOfLine,
	GetLineOfPosition,
	GetText,
	GetPositionOfContext,
	GetContextOfPosition,
	InsertText,
	RemoveText,
	textReplaceText};

// IDebugDocumentContext VTable
static STDMETHODIMP contextQueryInterface(IDebugDocumentContext *, REFIID, void **);
static STDMETHODIMP_(ULONG) contextAddRef(IDebugDocumentContext *);
static STDMETHODIMP_(ULONG) contextRelease(IDebugDocumentContext *);
static STDMETHODIMP GetDocument(IDebugDocumentContext *, IDebugDocument **);
static STDMETHODIMP EnumCodeContexts(IDebugDocumentContext *, IEnumDebugCodeContexts **);

static const IDebugDocumentContextVtbl ContextTable = {
	contextQueryInterface,
	contextAddRef,
	contextRelease,
	GetDocument,
	EnumCodeContexts};

// IApplicationDebugger VTable
static STDMETHODIMP AppDebugQueryInterface(IApplicationDebugger *, REFIID, void **);
static STDMETHODIMP_(ULONG) AppDebugAddRef(IApplicationDebugger *);
static STDMETHODIMP_(ULONG) AppDebugRelease(IApplicationDebugger *);
static STDMETHODIMP QueryAlive(IApplicationDebugger *);
static STDMETHODIMP CreateInstanceAtDebugger(IApplicationDebugger *, REFCLSID, IUnknown *, DWORD, REFIID, IUnknown **);
static STDMETHODIMP onDebugOutput(IApplicationDebugger *, LPCOLESTR pstr);
static STDMETHODIMP onHandleBreakPoint(IApplicationDebugger *, IRemoteDebugApplicationThread *, BREAKREASON, IActiveScriptErrorDebug *);
static STDMETHODIMP onClose(IApplicationDebugger *);
static STDMETHODIMP onDebuggerEvent(IApplicationDebugger *, REFIID, IUnknown *);

const IApplicationDebuggerVtbl IApplicationDebugger_Vtbl = {AppDebugQueryInterface,
AppDebugAddRef,
AppDebugRelease,
QueryAlive,
CreateInstanceAtDebugger,
onDebugOutput,
onHandleBreakPoint,
onClose,
onDebuggerEvent};

// IApplicationDebuggerUI VTable
static STDMETHODIMP UI_QueryInterface(IApplicationDebuggerUI *, REFIID, void **);
static STDMETHODIMP_(ULONG) UI_AddRef(IApplicationDebuggerUI *);
static STDMETHODIMP_(ULONG) UI_Release(IApplicationDebuggerUI *);
static STDMETHODIMP BringDocumentToTop(IApplicationDebuggerUI *, IDebugDocumentText *);
static STDMETHODIMP BringDocumentContextToTop(IApplicationDebuggerUI *, IDebugDocumentContext *);

static const IApplicationDebuggerUIVtbl IApplicationDebuggerUI_Vtbl = {
	UI_QueryInterface,
	UI_AddRef,
	UI_Release,
	BringDocumentToTop,
	BringDocumentContextToTop};

/*
// IDebugSessionProvider VTable
static STDMETHODIMP sessionQueryInterface(IDebugSessionProvider *, REFIID, void **);
static STDMETHODIMP_(ULONG) sessionDebugAddRef(IDebugSessionProvider *);
static STDMETHODIMP_(ULONG) sessionDebugRelease(IDebugSessionProvider *);
static STDMETHODIMP StartDebugSession(IDebugSessionProvider *, IRemoteDebugApplication *);

const IDebugSessionProviderVtbl IDebugSessionProvider_Vtbl = {sessionQueryInterface,
sessionDebugAddRef,
sessionDebugRelease,
StartDebugSession};
*/

const GUID IID_IActiveScriptSiteDebug32 = {0x51973C11, 0xCB0C, 0x11d0, 0xB5, 0xC9, 0x00, 0xA0, 0x24, 0x4A, 0x0E, 0x7A};
const GUID IID_IActiveScriptDebug32 = {0x51973C10, 0xCB0C, 0x11d0, 0xB5, 0xC9, 0x00, 0xA0, 0x24, 0x4A, 0x0E, 0x7A};
const GUID IID_IProcessDebugManager32 = {0x51973C2f, 0xCB0C, 0x11d0, 0xB5, 0xC9, 0x00, 0xA0, 0x24, 0x4A, 0x0E, 0x7A};
const GUID IID_IDebugApplication32 = {0x51973C32, 0xCB0C, 0x11d0, 0xB5, 0xC9, 0x00, 0xA0, 0x24, 0x4A, 0x0E, 0x7A};
const GUID IID_IDebugDocumentTextAuthor = {0x51973C24, 0xCB0C, 0x11d0, 0xB5, 0xC9, 0x00, 0xA0, 0x24, 0x4A, 0x0E, 0x7A};
const GUID GuidNull = {0x00000000, 0x0000, 0x0000, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00};








//===========================================================================
//============================ Helper functions =============================
//===========================================================================

/********************* initActiveScriptSite() *******************
 * Initializes our MyRealIActiveScriptSite object.
 *
 * RETURNS: 1 if success, or 0 if fail.
 */

BOOL initActiveScriptSite(MyRealIActiveScriptSite *this)
{
	ZeroMemory(this, sizeof(MyRealIActiveScriptSite));
	this->site.lpVtbl = (IActiveScriptSiteVtbl *)&SiteTable;
	this->siteWnd.lpVtbl = (IActiveScriptSiteWindowVtbl *)&SiteWindowTable;
	this->siteDebug.lpVtbl = (IActiveScriptSiteDebug32Vtbl *)&IActiveScriptSiteDebug_Vtbl;
	this->appDebug.lpVtbl = (IApplicationDebuggerVtbl *)&IApplicationDebugger_Vtbl;
	this->appDebugUI.lpVtbl = (IApplicationDebuggerUIVtbl *)&IApplicationDebuggerUI_Vtbl;

	// We need an IProcessDebugManager object (from Microsoft's Process Debug Manager, ie, PDM)
	if (CoCreateInstance(&CLSID_ProcessDebugManager, 0, CLSCTX_INPROC_SERVER|CLSCTX_INPROC_HANDLER|CLSCTX_LOCAL_SERVER, &IID_IProcessDebugManager, (void **)&this->iProcDebugManager))
	{
		// If that failed, we have no means to support ActiveX debugging. Microsoft's
		// PDM.DLL must be installed on the system
		MessageBox(0, "No Process Debug Manager available.", &ErrorStr[0], MB_SETFOREGROUND|MB_OK|MB_ICONEXCLAMATION);
bad:	freeActiveScriptSite(this);
		return(0);
	}

	// Get an IDebugApplication object 
	if (this->iProcDebugManager->lpVtbl->GetDefaultApplication(this->iProcDebugManager, &this->iDebugApplication))
	{
		MessageBox(0, "Failed to get debug application.", &ErrorStr[0], MB_SETFOREGROUND|MB_OK|MB_ICONEXCLAMATION);
		goto bad;
	}

	// Set the name for our application (so it shows up in the PDM's applications dialog)
	this->iDebugApplication->lpVtbl->SetName(this->iDebugApplication, &AppName[0]);

	return(1);
}

/********************* freeActiveScriptSite() *******************
 * Frees resource gotten for our MyRealIActiveScriptSite object.
 *
 * RETURNS: 1 if success, or 0 if fail.
 */

void freeActiveScriptSite(MyRealIActiveScriptSite *this)
{
	// Free MS' PDM, and the default IDebugApplication we got from it
	if (this->iProcDebugManager) this->iProcDebugManager->lpVtbl->Release(this->iProcDebugManager);
	if (this->iDebugApplication) this->iDebugApplication->lpVtbl->Release(this->iDebugApplication);
}



 











//===========================================================================
//======================= IActiveScriptSite functions =======================
//===========================================================================

/************************** QueryInterface() **********************
 */

static STDMETHODIMP QueryInterface(MyRealIActiveScriptSite *this, REFIID riid, void **pObj)
{
	// An ActiveX Script Host is supposed to provide an object
	// with multiple interfaces, where the base object is an
	// IActiveScriptSite, and there is an IActiveScriptSiteWindow
	// sub-object. Therefore, a caller can pass an IUnknown or
	// IActiveScript VTable GUID if it wants our IActiveScriptSite.
	// Or, the caller can pass a IActiveScriptSiteWindow VTable
	// GUID if it wants our IActiveScriptSiteWindow sub-object.
	if (IsEqualIID(riid, &IID_IUnknown) || IsEqualIID(riid, &IID_IActiveScriptSite))
		*pObj = this;
	else if (IsEqualIID(riid, &IID_IActiveScriptSiteWindow))
		*pObj = ((unsigned char *)this + offsetof(MyRealIActiveScriptSite, siteWnd)); 
	else if (IsEqualIID(riid, &IID_IActiveScriptSiteDebug))
		*pObj = ((unsigned char *)this + offsetof(MyRealIActiveScriptSite, siteDebug)); 
	else if (IsEqualIID(riid, &IID_IApplicationDebugger))
		*pObj = ((unsigned char *)this + offsetof(MyRealIActiveScriptSite, appDebug)); 
	else if (IsEqualIID(riid, &IID_IApplicationDebuggerUI))
		*pObj = ((unsigned char *)this + offsetof(MyRealIActiveScriptSite, appDebugUI)); 
	else
	{
		*pObj = 0;
		return(E_NOINTERFACE);
	}
	return(S_OK);
}

/***************************** AddRef() **************************
 */

static STDMETHODIMP_(ULONG) AddRef(MyRealIActiveScriptSite *this)
{
	return(1);
}

/***************************** Release() *************************
 */

static STDMETHODIMP_(ULONG) Release(MyRealIActiveScriptSite *this)
{
	// We never allocate our IActiveScriptSite, so we don't need to free it
	return(1);
}

/*************************** GetItemInfo() ***********************
 * Called by the script engine to get any pointers to our own
 * host-defined objects whose functions a script may directly
 * call. We don't implement that here.
 */
  
static STDMETHODIMP GetItemInfo(MyRealIActiveScriptSite *this, LPCOLESTR objectName, DWORD dwReturnMask, IUnknown **objPtr, ITypeInfo **typeInfo)
{
	if (dwReturnMask & SCRIPTINFO_IUNKNOWN) *objPtr = 0;
	if (dwReturnMask & SCRIPTINFO_ITYPEINFO) *typeInfo = 0;
	return(E_FAIL);
}

/************************* OnScriptError() **********************
 * Called by the script engine when there is an error running/parsing
 * a script. The script engine passes us its IActiveScriptError
 * object whose functions we can call to get information about the
 * error, such as the line/character position (in the script) where
 * the error occurred, an error message we can display to the user,
 * etc. Typically, our OnScriptError will get the error message and
 * display it to the user.
 */

static STDMETHODIMP OnScriptError(MyRealIActiveScriptSite *this, IActiveScriptError *scriptError)
{
	ULONG		lineNumber;
	BSTR		desc;
	EXCEPINFO	ei;
	OLECHAR		wszOutput[1024];	// NOTE: We really should allocate this, to ensure it's big enough

	// Call GetSourceLineText() to retrieve the line in the script that
	// has an error.
	//
	// Note: The IActiveScriptError is supposed to clear our BSTR pointer
	// if it can't return the line. So we shouldn't have to do
	// that first. But you may need to uncomment the following line
	// if a script engine isn't properly written. Unfortunately, too many
	// engines are not written properly, so we uncomment it
	desc = 0;
	scriptError->lpVtbl->GetSourceLineText(scriptError, &desc);

	// If desc is nul, assume that we've aborted the script, in which case,
	// we won't bother with an error message
	if (desc)
	{
		// Call GetSourcePosition() to retrieve the line # where
		// the error occurred in the script
		scriptError->lpVtbl->GetSourcePosition(scriptError, 0, &lineNumber, 0);

		// Call GetExceptionInfo() to fill in our EXCEPINFO struct with more
		// information.
		//
		// Note: The IActiveScriptError is supposed to zero out any fields of
		// our EXCEPINFO that it doesn't fill in. So we shouldn't have to do
		// that first. But you may need to uncomment the following line
		// if a script engine isn't properly written
	//	ZeroMemory(&ei, sizeof(ei));
		scriptError->lpVtbl->GetExceptionInfo(scriptError, &ei);

		// Format the message we'll display to the user
		wsprintfW(&wszOutput[0], L"%s\nLine %u: %s\n%s", ei.bstrSource, lineNumber + 1, ei.bstrDescription, desc);

		// Free what we got from the IActiveScriptError functions
		SysFreeString(desc);
		SysFreeString(ei.bstrSource);
		SysFreeString(ei.bstrDescription);
		SysFreeString(ei.bstrHelpFile);

		// Display the message
		MessageBoxW(0, &wszOutput[0], L"Error", MB_SETFOREGROUND|MB_OK|MB_ICONEXCLAMATION);
	}

	return(S_OK);
}

/*************************** GetLCID() *************************
 * Called when the script engine wants to know what language ID
 * our program is using.
 */

static STDMETHODIMP GetLCID(MyRealIActiveScriptSite *this, LCID *lcid)
{
	*lcid = LOCALE_USER_DEFAULT;
	return(S_OK);
}

/******************** GetDocVersionString() ********************
 * Called when the script engine wishes to retrieve the version
 * number (as a string) for the current document. We are expected
 * to return a SysAllocString()'ed BSTR copy of this version
 * string. The engine typically uses this string to make sure the
 * internally-cached state of the script engine is still in sync
 * with the current document. The engine may get this string when
 * we ParseScriptText some script, and then once again retrieve
 * this string before running the script to ensure that we haven't
 * updated the script in the interim. (Presumably we would update
 * this version string if we did that).
 */

static STDMETHODIMP GetDocVersionString(MyRealIActiveScriptSite *this, BSTR *version) 
{
	*version = SysAllocString(L"");
	return(S_OK);
}

/********************** OnScriptTerminate() *********************
 * Called when the engine has completely finished running scripts
 * and is returning to INITIALIZED state. In many engines, this is
 * not called because an engine alone can't determine when we are
 * going to stop adding scripts to it.
 */

static STDMETHODIMP OnScriptTerminate(MyRealIActiveScriptSite *this, const VARIANT *pvr, const EXCEPINFO *pei)
{
	return(S_OK);
}

/************************* OnStateChange() **********************
 * Called when the script engine's state is changed (for example,
 * by us calling the engine IActiveScript->SetScriptState). We're
 * passed the new state.
 */

static STDMETHODIMP OnStateChange(MyRealIActiveScriptSite *this, SCRIPTSTATE state)
{
	return(S_OK);
}

/************************* OnEnterScript() **********************
 * Called right before the script engine executes/interprets each
 * script function call. This is also called when our IApp object
 * calls some function in the script.
 */

static STDMETHODIMP OnEnterScript(MyRealIActiveScriptSite *this)
{
	// If user has selected the "Debug -> Start" menu item initially,
	// or the "Debug -> Break", then pause here


	return(S_OK);
}

/************************* OnLeaveScript() **********************
 * Called immediately after the script engine executes/interprets
 * each script function call.
 */

static STDMETHODIMP OnLeaveScript(MyRealIActiveScriptSite *this) 
{
	return(S_OK);
}





















//===========================================================================
//==================== IActiveScriptSiteWindow functions ====================
//===========================================================================

/************************** QueryInterface() **********************
 */

static STDMETHODIMP siteWnd_QueryInterface(IActiveScriptSiteWindow *this, REFIID riid, void **pObj)
{
	// Since our IActiveScriptSiteWindow is a sub-object embedded inside of our
	// MyRealIActiveScriptSite object (ie, our MyRealIActiveScriptSite has "multiple
	// interfaces" and our IActiveScriptSiteWindow happens to be a sub-object),
	// then we just delegate to our base object's (IActiveScriptSite's) QueryInterface
	// to do the real work. We do this by substituting our IActiveScriptSite object for
	// the "this" pointer. That's easy to do because both our IActiveScriptSiteWindow
	// and IActiveScriptSite objects are embedded inside of our one MyRealIActiveScriptSite.
	// So a little pointer arithmatic gets us what we want. The process of having one
	// object's QueryInterface, AddRef, and Release functions calling a base object's
	// functions is referred to as "delegation". Delegation is used with objects that
	// have multiple interfaces
	this = (IActiveScriptSiteWindow *)(((unsigned char *)this - offsetof(MyRealIActiveScriptSite, siteWnd)));
	return(QueryInterface((MyRealIActiveScriptSite *)this, riid, pObj));
}

/***************************** AddRef() **************************
 */

static STDMETHODIMP_(ULONG) siteWnd_AddRef(IActiveScriptSiteWindow *this)
{
	this = (IActiveScriptSiteWindow *)(((unsigned char *)this - offsetof(MyRealIActiveScriptSite, siteWnd)));
	return(AddRef((MyRealIActiveScriptSite *)this));
}

/***************************** Release() *************************
 */

static STDMETHODIMP_(ULONG) siteWnd_Release(IActiveScriptSiteWindow *this)
{
	this = (IActiveScriptSiteWindow *)(((unsigned char *)this - offsetof(MyRealIActiveScriptSite, siteWnd)));
	return(Release((MyRealIActiveScriptSite *)this));
}

/************************** GetSiteWindow() ***********************
 * Called by the script engine when it wants to know what window
 * it should use as the owner of any dialog box the engine presents.
 */

static STDMETHODIMP GetSiteWindow(IActiveScriptSiteWindow *this, HWND *phwnd)
{
	// Give it our main app window
	*phwnd = MainFrameWindow;
	return(S_OK);
}

/************************** EnableModeless() **********************
 * Called when the script engine wants us to enable/disable all of
 * our open windows.
 */

static STDMETHODIMP EnableModeless(IActiveScriptSiteWindow *this, BOOL enable)
{
	// We have only 1 open window -- our main window
	EnableWindow(MainFrameWindow, enable);
	return(S_OK);
}




















//===========================================================================
//==================== IActiveScriptSiteDebug functions ====================
//===========================================================================

/************************** QueryInterface() **********************
 */

static STDMETHODIMP DebugQueryInterface(IActiveScriptSiteDebug *this, REFIID riid, void **pObj)
{
	// Since our IActiveScriptSiteDebug is a sub-object embedded inside of our
	// MyRealIActiveScriptSite object (ie, our MyRealIActiveScriptSite has "multiple
	// interfaces" and our IActiveScriptSiteDebug happens to be a sub-object),
	// then we just delegate to our base object's (IActiveScriptSite's) QueryInterface
	// to do the real work
	this = (IActiveScriptSiteDebug *)(((unsigned char *)this - offsetof(MyRealIActiveScriptSite, siteDebug)));
	return(QueryInterface((MyRealIActiveScriptSite *)this, riid, pObj));
}

/***************************** AddRef() **************************
 */

static STDMETHODIMP_(ULONG) DebugAddRef(IActiveScriptSiteDebug *this)
{
	this = (IActiveScriptSiteDebug *)(((unsigned char *)this - offsetof(MyRealIActiveScriptSite, siteDebug)));
	return(AddRef((MyRealIActiveScriptSite *)this));
}

/***************************** Release() *************************
 */

static STDMETHODIMP_(ULONG) DebugRelease(IActiveScriptSiteDebug *this)
{
	this = (IActiveScriptSiteDebug *)(((unsigned char *)this - offsetof(MyRealIActiveScriptSite, siteDebug)));
	return(Release((MyRealIActiveScriptSite *)this));
}

/**************** GetDocumentContextFromPosition() *****************
 * Called by the script engine to get our IDebugDocumentContext
 * associated with a particular character position.
 *
 * context =	The "context" arg which we passed to the engine's
 *				IActiveScriptParse::ParseScriptText or 
 *				IActiveScriptParse::AddScriptlet when we added 
 *				this script to the engine. NOTE: We passed our
 *				MyRealIDebugDocument for this script, so that's
 *				what is passed here
 * charOffset =	Offset from the beginning of the script block.
 * uNumChars =	Length of the script block.
 * pObj =		Where we return our IDebugDocumentContext.
 */

static STDMETHODIMP GetDocumentContextFromPosition(IActiveScriptSiteDebug *this, DWORD context, ULONG charOffset, ULONG uNumChars, IDebugDocumentContext **pObj)
{
	register MyRealIDebugDocument	*docHost;

	docHost = (MyRealIDebugDocument *)context;

	// Make sure the char offset is legal
	if (docHost->ScriptSize > charOffset)
	{
		// The IDebugDocumentContext is embedded inside of our MyRealIDebugDocument. NOTE:
		// Ideally we should allocate a new IDebugDocumentContext for each call here. We
		// should wrap it in one of our own structs that has 3 extra, private fields. A
		// DWORD to maintain a reference count. A DWORD where we can store "charOffset".
		// A pointer to the MyRealIDebugDocument here. But the only reason this should be
		// called is because of the some of the calls that our own IApplicationDebugger's
		// onHandleBreakPoint() calls. So I expect that only 1 IDebugDocumentContext will
		// ever be asked for. It will be used, and then Release()'ed before anyone ever
		// asks for another one. So it should be ok to have only one, and embed it right
		// inside of our MyRealIDebugDocument
		*pObj = (IDebugDocumentContext *)(((unsigned char *)docHost + offsetof(MyRealIDebugDocument, context)));

		// Save the char position (for this IDebugDocumentContext) so that a subsequent call
		// to our IDebugDocumentTextAuthor's GetLineOfPosition() can retrieve it and deduce the
		// line number pertaining to this position
		docHost->Offset = charOffset;

		// AddRef it on behalf of the engine, which will later Release() it
		contextAddRef(*pObj);

		return(S_OK);
	}

	return(E_FAIL);
}

/************************ GetApplication() ***********************
 * Called by the script engine to get our IDebugApplication object
 * associated with this IActiveScriptSiteDebug.
 *
 * pObj =	Where to return the IDebugApplication pointer.
 */

static STDMETHODIMP GetApplication(IActiveScriptSiteDebug *this, IDebugApplication **pObj)
{
	register MyRealIActiveScriptSite	*obj;

	// We have the option of having a unique IDebugApplication object
	// for each script we load/debug. One reason for this is if we wanted
	// to have a different description and programming language name for
	// each script we have. But we're not going to bother with that. We'll
	// simply let Microsoft provide us with a default IDebugApplication that
	// tells the engine to provide its own description and language strings
	// (when it calls the IDebugApplication's GetDescriptionString and
	// GetLanguageString), and gives generic handling for the other
	// IDebugApplication functions. This is easiest. To get a default
	// IDebugApplication, we simply call the PDM's IDebugApplication
	// QueryInterface() and ask it for itself.

	obj = (MyRealIActiveScriptSite *)(((unsigned char *)this - offsetof(MyRealIActiveScriptSite, siteDebug)));

	// NOTE: This AddRef()s it for the caller
	return(obj->iDebugApplication->lpVtbl->QueryInterface(obj->iDebugApplication, &IID_IDebugApplication, (void **)pObj));
}

/******************** GetRootApplicationNode() ***********************
 * Gets the IDebugApplicationNode under which this script should be
 * added to the PDM's "document tree".
 *
 * pObj =	Where to return the IDebugApplicationNode pointer.
 *			Returns a 0 if script documents should be top-level.
 */

static STDMETHODIMP GetRootApplicationNode(IActiveScriptSiteDebug *this, IDebugApplicationNode **pObj)
{
	register MyRealIActiveScriptSite	*obj;

	// Our script is comprised of a single "source file", so its document
	// tree is really simple. It's just a "root node". So, we can get ask
	// Microsoft's PDM to give us a generic IDebugApplicationNode that we'll
	// return. This is easiest.
	//
	// If our "script" comprised several files that we had to load, we'd need
	// to provide our own IDebugApplicationNodes.

	obj = (MyRealIActiveScriptSite *)(((unsigned char *)this - offsetof(MyRealIActiveScriptSite, siteDebug)));
	return(obj->iDebugApplication->lpVtbl->GetRootNode(obj->iDebugApplication, pObj));
}

/*********************** OnScriptErrorDebug() ************************
 * Called by the script engine when there is a runtime error in the
 * script (ie, some error that happens after the script has been
 * successfully parsed and checked for correct syntax, and is now
 * "running").
 *
 * errorDebug =		An IActiveScriptErrorDebug provided by the script
 *					engine. We can call its functions to get information
 *					about the error, such as an error message.
 * enterDebugger =	We set this to 1 if we want Microsoft's PDM to break
 *					into the debugger (and start calling our debugging
 *					functions here, such as onHandleBreakPoint. It will
 *					be called with the BREAKREASON set to BREAKREASON_ERROR).
 * callContinue =	If the script is running in something like Internet
 *					Explorer, and this app is setup to be the debugger,
 *					then the PDM will prompt the user if he wants to
 *					debug the script. We set this to 1 if we want the
 *					PDM to call our IActiveScriptSite->OnScriptError()
 *					when the user decides to continue without debugging. 
 */

static STDMETHODIMP OnScriptErrorDebug(IActiveScriptSiteDebug *this, IActiveScriptErrorDebug *errorDebug, BOOL *enterDebugger, BOOL *callContinue)
{
	// Request JIT debugging
	*enterDebugger =

	// If JIT debugging is declined, call IActiveScriptSite::OnScriptError
	*callContinue = 1;

	return(S_OK);
}




















//===========================================================================
//====================== IApplicationDebugger functions =====================
//===========================================================================

/************************** QueryInterface() **********************
 */

static STDMETHODIMP AppDebugQueryInterface(IApplicationDebugger *this, REFIID riid, void **pObj)
{
	// Our IApplicationDebugger is a sub-object embedded inside of our
	// MyRealIActiveScriptSite object
	this = (IApplicationDebugger *)(((unsigned char *)this - offsetof(MyRealIActiveScriptSite, appDebug)));
	return(QueryInterface((MyRealIActiveScriptSite *)this, riid, pObj));
}

/***************************** AddRef() **************************
 */

static STDMETHODIMP_(ULONG) AppDebugAddRef(IApplicationDebugger *this)
{
	this = (IApplicationDebugger *)(((unsigned char *)this - offsetof(MyRealIActiveScriptSite, appDebug)));
	return(AddRef((MyRealIActiveScriptSite *)this));
}

/***************************** Release() *************************
 */

static STDMETHODIMP_(ULONG) AppDebugRelease(IApplicationDebugger *this)
{
	this = (IApplicationDebugger *)(((unsigned char *)this - offsetof(MyRealIActiveScriptSite, appDebug)));
	return(Release((MyRealIActiveScriptSite *)this));
}


/**************************** QueryAlive() ***********************
 * Called to see if this debugger app is still alive. We return
 * S_OK if so.
 */

static STDMETHODIMP QueryAlive(IApplicationDebugger *this)
{
	return(S_OK);
}

/******************* CreateInstanceAtDebugger() *****************
 */

static STDMETHODIMP CreateInstanceAtDebugger(IApplicationDebugger *this, REFCLSID rclsid, IUnknown *pUnkOuter, DWORD dwClsContext, REFIID riid, IUnknown **pObj)
{
	return(CoCreateInstance(rclsid, pUnkOuter, dwClsContext, riid, (void **)pObj));
}

/********************** onDebugOutput() *********************
 * Called by engine to display a string.
 *
 * pstr =	The string to display.
 */

static STDMETHODIMP onDebugOutput(IApplicationDebugger *this, LPCOLESTR pstr)
{
	MessageBoxW(0, pstr, 0, MB_SETFOREGROUND|MB_OK|MB_ICONEXCLAMATION);
	return(S_OK);
}

/******************** onHandleBreakPoint() ******************
 * If BREAKREASON is BREAKREASON_BREAKPOINT, this was called by
 * the engine when it runs an instruction upon which we've set
 * a breakpoint.
 *
 * If there was a runtime error, BREAKREASON is BREAKREASON_ERROR.
 *
 * There are other reasons why this may be called such as a
 * "halt" condition. See the BREAKREASON defines in activdbg.h.
 *   
 * The PDM passes us its IRemoteDebugApplicationThread. We need
 * to store this, and then return. After we return, the PDM will
 * pause our runScript() thread. (And note that this is called in
 * the context of that thread). Our runScript() thread does not
 * continue (and therefore the script remains paused at this
 * point) until we call the PDM IRemoteDebugApplication's
 * ResumeFromBreakPoint() (which we do in our main thread
 * when the user selects some action such as "Step Over",
 * Abort debugging", etc). We get the PDM's IRemoteDebugApplication
 * by calling the IRemoteDebugApplicationThread's GetApplication().
 * NOTE: After our main thread calls ResumeFromBreakPoint, that
 * particular IRemoteDebugApplicationThread "disappears" and the
 * pointer is no good (even though we don't Release it). Yeah, this
 * debugger API was really not well-designed.
 *
 * Our main thread also calls some IRemoteDebugApplicationThread
 * functions to get a listing of the current variables, and
 * callstack (but only until we resume running the script).
 */

static STDMETHODIMP onHandleBreakPoint(IApplicationDebugger *this, IRemoteDebugApplicationThread *remote, BREAKREASON br, IActiveScriptErrorDebug *pError)
{
	register HRESULT			hr;
	void						*ptr1;
	void						*ptr2;
	IDebugDocumentContext		*docContext;
	ULONG						line;

	// All the following code is just so we can determine which line the script
	// has paused on (due to a breakpoint, or error, or halt, etc). We need that
	// line number so our main thread can "highlight" that line, and let the user
	// visually know where we are currently paused in the script

	{
	DebugStackFrameDescriptor	descrip;

	// Get the IEnumStackFrames
	descrip.pdsf = 0;
	if (!remote->lpVtbl->EnumStackFrames(remote, (IEnumDebugStackFrames **)&ptr1))
	{
		// Fill in the DebugStackFrameDescriptor with the topmost stack frame's info
		((IEnumDebugStackFrames *)ptr1)->lpVtbl->Next((IEnumDebugStackFrames *)ptr1, 1, &descrip, &line);
		((IUnknown *)ptr1)->lpVtbl->Release((IUnknown *)ptr1);
	}

	if (!descrip.pdsf) goto out;

	// Get the IDebugCodeContext for the topmost stack frame
	hr = descrip.pdsf->lpVtbl->GetCodeContext(descrip.pdsf, (IDebugCodeContext **)&ptr1);
	descrip.pdsf->lpVtbl->Release(descrip.pdsf);
	}

	// Assume we can't get the line number
	line = (ULONG)-1;

	if (!hr)
	{
		// Get that IDebugCodeContext's IDebugDocumentContext
		hr = ((IDebugCodeContext *)ptr1)->lpVtbl->GetDocumentContext((IDebugCodeContext *)ptr1, &docContext);
		((IUnknown *)ptr1)->lpVtbl->Release((IUnknown *)ptr1);
		if (!hr &&

			// Get that IDebugDocumentContext's IDebugDocument
			!docContext->lpVtbl->GetDocument(docContext, (IDebugDocument **)&ptr1))
		{
			// If this is our own IDebugDocument *, then we saved the char position in
			// our MyRealIDebugDocument->Offset (in the call to GetDocumentContext above).
			// Otherwise, we'll need to continue drilling down into sub-objects to get the
			// line #
			if ((IDebugDocumentTextAuthorVtbl *)((IDebugDocument *)ptr1)->lpVtbl == &TextAuthorTable)
			{
				GetLineOfPosition((MyRealIDebugDocument *)ptr1, ((MyRealIDebugDocument *)ptr1)->Offset, &line, 0);
				((IUnknown *)ptr1)->lpVtbl->Release((IUnknown *)ptr1);
			}
			else
			{
				// Get that IDebugDocument's IDebugDocumentText sub-object
				hr = ((IDebugDocument *)ptr1)->lpVtbl->QueryInterface((IDebugDocument *)ptr1, &IID_IDebugDocumentText, &ptr2);
				((IUnknown *)ptr1)->lpVtbl->Release((IUnknown *)ptr1);
				if (!hr)
				{
					ULONG		position;
					ULONG		offset;

					if (!((IDebugDocumentText *)ptr2)->lpVtbl->GetPositionOfContext((IDebugDocumentText *)ptr2, docContext, &position, &offset))
					{
						((IDebugDocumentText *)ptr2)->lpVtbl->GetLineOfPosition((IDebugDocumentText *)ptr2, position, &line, &offset);
						// "line" contains the line #
					}
				}
			}

			docContext->lpVtbl->Release(docContext);
		}
	}
out:
	// Tell main window to update the current line, and Callstack/Variables windows.
	// We CANNOT use SendMessage or the PDM totally locks up our app. It seems as if
	// the PDM totally suspends all threads until we return from onHandleBreakPoint().
	// Microsoft's PDM is really nasty, evil, poorly conceived software!!!
	PostMessage(MainFrameWindow, WM_APP + 3, line, (LPARAM)remote);

	return(S_OK);
}

/************************* onClose() ************************
 * Called when the IDebugApplication's Close() is called.
 */

static STDMETHODIMP onClose(IApplicationDebugger *this)
{
	return(S_OK);
}

/********************* onDebuggerEvent() ********************
 * Called to handle some custom application event. This is
 * called when someone calls the IDebugApplication's
 * FireDebuggerEvent().
 */

static STDMETHODIMP onDebuggerEvent(IApplicationDebugger *this, REFIID riid, IUnknown *punk)
{
	// We haven't defined any custom events
	return(E_NOTIMPL);
}














//===========================================================================
//==================== IApplicationDebuggerUI functions ====================
//===========================================================================

/************************** QueryInterface() **********************
 */

static STDMETHODIMP UI_QueryInterface(IApplicationDebuggerUI *this, REFIID riid, void **pObj)
{
	// Since our IApplicationDebuggerUI is a sub-object of our
	// IActiveScriptSite, let's delegate
	this = (IApplicationDebuggerUI *)(((unsigned char *)this - offsetof(MyRealIActiveScriptSite, appDebugUI)));
	return(QueryInterface((MyRealIActiveScriptSite *)this, riid, pObj));
}

/***************************** AddRef() **************************
 */

static STDMETHODIMP_(ULONG) UI_AddRef(IApplicationDebuggerUI *this)
{
	this = (IApplicationDebuggerUI *)(((unsigned char *)this - offsetof(MyRealIActiveScriptSite, appDebugUI)));
	return(AddRef((MyRealIActiveScriptSite *)this));
}

/***************************** Release() *************************
 */

static STDMETHODIMP_(ULONG) UI_Release(IApplicationDebuggerUI *this)
{
	this = (IApplicationDebuggerUI *)(((unsigned char *)this - offsetof(MyRealIActiveScriptSite, appDebugUI)));
	return(Release((MyRealIActiveScriptSite *)this));
}

/************************** BringDocumentToTop() ***********************
 * Called by the script engine when it wants to bring a certain
 * document's window to the top.
 */

static STDMETHODIMP BringDocumentToTop(IApplicationDebuggerUI *this, IDebugDocumentText *docText)
{
	return(S_OK);
}

/********************** BringDocumentContextToTop() *******************
 * Called by the script engine when it wants to bring a certain
 * document's window to the top, and scroll to a specific context.
 */

static STDMETHODIMP BringDocumentContextToTop(IApplicationDebuggerUI *this, IDebugDocumentContext *docContext)
{
	return(S_OK);
}

















//===========================================================================
//================== IDebugDocumentTextAuthor functions =====================
//===========================================================================
// This object is encapsules several other objects. It allows the script engine
// to retrieve the text at a certain position in the script being debugged, and
// do other things with a particular script.
//
// We wrap this object in our own MyRealIDebugDocument. Each script we run
// needs its own MyRealIDebugDocument.

/********************* allocIDebugDocument() *******************
 * Allocates and initializes an MyRealIDebugDocument object.
 *
 * RETURNS: Pointer to new MyRealIDebugDocument if success, or 0 if fail.
 */

MyRealIDebugDocument * allocIDebugDocument(MyRealIActiveScriptSite *site)
{
	register MyRealIDebugDocument		*this;

	// Create a IDebugDocumentHost for this script. Actually, we create a
	// MyRealIDebugDocument which has some extra data members to do things
	// like maintain a reference count, and save the pointer to the
	// IDebugDocumentHelper we also need
	if (!(this = (MyRealIDebugDocument *)GlobalAlloc(GMEM_FIXED, sizeof(MyRealIDebugDocument))))
		MessageBox(0, "Out of memory.", &ErrorStr[0], MB_SETFOREGROUND|MB_OK|MB_ICONEXCLAMATION);
	else
	{
		ZeroMemory(this, sizeof(MyRealIDebugDocument));

		// Initialize the vtables that our MyRealIDebugDocument wraps
		this->textAuthor.lpVtbl = (IDebugDocumentTextAuthorVtbl *)&TextAuthorTable;
		this->context.lpVtbl = (IDebugDocumentContextVtbl *)&ContextTable;

		// Increment its count. When we give it to the script engine, we'll
		// AddRef() it also. We increment it here to make sure it doesn't get
		// freed until we explicitly call Release()
		this->count = 1;
	}

	return(this);
}


/************************** QueryInterface() **********************
 */

static STDMETHODIMP textAuthQueryInterface(MyRealIDebugDocument *this, REFIID riid, void **pObj)
{
	if (IsEqualIID(riid, &IID_IUnknown) || IsEqualIID(riid, &IID_IDebugDocumentTextAuthor) ||
		IsEqualIID(riid, &IID_IDebugDocumentText) || IsEqualIID(riid, &IID_IDebugDocument) ||
		IsEqualIID(riid, &IID_IDebugDocumentProvider) || IsEqualIID(riid, &IID_IDebugDocumentInfo))
	{
		*pObj = this;
	}
	else
	{
		*pObj = 0;
		return(E_NOINTERFACE);
	}
	textAuthAddRef(this);
	return(S_OK);
}

/***************************** AddRef() **************************
 */

static STDMETHODIMP_(ULONG) textAuthAddRef(MyRealIDebugDocument *this)
{
	return(++this->count);
}

/***************************** Release() *************************
 */

static STDMETHODIMP_(ULONG) textAuthRelease(MyRealIDebugDocument *this)
{
	if (--this->count) return(this->count);

	// Free the script text
	if (this->ScriptText) GlobalFree(this->ScriptText);

	// Free this MyRealIDebugDocument object
	GlobalFree(this);

	return(0);
}

/*************************** GetName() *************************
 * Called by the script engine to get the script's name.
 *
 * type =		The type of document name to return.
 *
 * name =		Where to return the name.
 */

static STDMETHODIMP GetName(MyRealIDebugDocument *this, DOCUMENTNAMETYPE type, BSTR *name)
{
	register WCHAR		*path;

	path = &this->Filename[0];

	if (type == DOCUMENTNAMETYPE_FILE_TAIL)
	{
		path += lstrlenW(path);
		while (--path > &this->Filename[0] && *path != '\\');
		++path;
	}

	if (!(*name = SysAllocString(path)))
		return(E_OUTOFMEMORY);

	return(S_OK);
}

/********************* GetDocumentClassId() *********************
 * Called by the script engine to get the script's GUID.
 *
 * guid =		Where to return the GUID.
 */

static STDMETHODIMP GetDocumentClassId(MyRealIDebugDocument *this, CLSID *guid)
{
	// We do not associate particular GUIDs with our scripts. So we just
	// return GUID_NULL
	CopyMemory(guid, &GuidNull, sizeof(GUID));
	return(S_OK);
}

/********************* GetDocumentAttributes() *********************
 * Called by the script engine to get the script's attribute.
 *
 * attr =		Where to return the TEXT_DOC_ATTR.
 */

static STDMETHODIMP GetDocumentAttributes(MyRealIDebugDocument *this, TEXT_DOC_ATTR *attr)
{
	*attr = TEXT_DOC_ATTR_READONLY;
	return(S_OK);
}

/****************************** GetSize() **************************
 * Called by the script engine to get the script's size.
 *
 * numLines =		Where to return the number of lines.
 *
 * numChars =		Where to return the number of characters.
 */

static STDMETHODIMP GetSize(MyRealIDebugDocument *this, ULONG *numLines, ULONG *numChars)
{
	register DWORD	chars;
	register DWORD	lines;
	register WCHAR	*ptr;

	chars = this->ScriptSize;
	*numChars = chars;

	ptr = this->ScriptStart;
	lines = 0;
	while (chars--)
	{
		if (*ptr == '\r')
		{
			if (chars && *(ptr + 1) == '\n')
			{
				--chars;
				++ptr;
			}

			goto inc;
		}

		if (*ptr == '\n')
inc:		++lines;

		++ptr;
	}

	// Count any final line that doesn't end with \r or \n
	if (this->ScriptSize && (*(ptr - 1) != '\r' || *(ptr - 1) != '\n')) ++lines;

	*numLines = lines;

	return(S_OK);
}

/************************ GetPositionOfLine() **********************
 * Called by the script engine to get the 0-based character position
 * (from the start of the script) for a given line number.
 *
 * lineNum =		The line number whose start position is desired.
 *
 * numChars =		Where to return the start position of the line.
 */

static STDMETHODIMP GetPositionOfLine(MyRealIDebugDocument *this, ULONG lineNum, ULONG *position)
{
	register DWORD	lines, offset;
	register WCHAR	*ptr;

	ptr = this->ScriptStart;
	offset = lines = 0;
	while (lineNum != lines && offset < this->ScriptSize)
	{
		if (*ptr == '\r')
		{
			if (offset < this->ScriptSize && *(ptr + 1) == '\n')
			{
				++offset;
				++ptr;
			}

			goto inc;
		}

		if (*ptr == '\n')
inc:		++lines;

		++offset;
		++ptr;
	}

	*position = offset;

	return(S_OK);
}


/************************ GetLineOfPosition() **********************
 * Called by the script engine to get the 0-based line number (and
 * character offset within that line) of a given, 0-based character
 * position.
 *
 * position =		Character position from the start of the script.
 *
 * lineNum =		Where to return the line number.
 *
 * charOffset =		Where to return the char offset on the line.
 */

static STDMETHODIMP GetLineOfPosition(MyRealIDebugDocument *this, ULONG position, ULONG *lineNum, ULONG *charOffset)
{
	register DWORD	lines, offset;
	register WCHAR	*ptr;
	DWORD			prevLine;

	ptr = this->ScriptStart;
	prevLine = offset = lines = 0;
	while (offset < this->ScriptSize && offset < position)
	{
		if (*ptr == '\r')
		{
			if (offset < this->ScriptSize && offset < position && *(ptr + 1) == '\n')
			{
				++offset;
				++ptr;
			}

			goto inc;
		}

		if (*ptr == '\n')
		{
inc:		prevLine = offset + 1;
			++lines;
		}

		++offset;
		++ptr;
	}

	*lineNum = lines;
	if (charOffset) *charOffset = offset - prevLine;

	return(S_OK);
}

/*************************** GetText() **************************
 * Called by the script engine to get some text at a given position
 * in the script.
 *
 * position =		Character position from the start of the script.
 *
 * text =			Where to return a pointer to the text.
 *
 * attr =			Where to return the attributes of the text.
 *
 * numChars =		Where to return the number of chars/attrs returned.
 *
 * max =			How many chars/attrs the caller wants returned.
 */

static STDMETHODIMP GetText(MyRealIDebugDocument *this, ULONG position, WCHAR *text, SOURCE_TEXT_ATTR *attr, ULONG *numChars, ULONG max)
{
	register DWORD		offset;
	register WCHAR		*ptr;
	IActiveScriptDebug	*debug;

	if (position >= this->ScriptSize)
	{
		*numChars = 0;
		if (!max) goto out;
fail:	return(E_FAIL);
	}

	// Get the start of text
	ptr = this->ScriptStart + position;

	// Make sure caller isn't asking for more chars than are remaining
	offset = max;
	if ((offset + position) > this->ScriptSize) offset = this->ScriptSize - position;
	*numChars = offset;

	if (text) CopyMemory(text, this->ScriptStart + position, offset);

	// Does caller want some attrs filled in?
	if (attr)
	{
		// Get the engine's IActiveScriptDebug
		if (EngineActiveScript->lpVtbl->QueryInterface(EngineActiveScript, &IID_IActiveScriptDebug, (void **)&debug)) goto fail;

		// Call its GetScriptTextAttributes to fill in the attrs array
		debug->lpVtbl->GetScriptTextAttributes(debug, this->ScriptStart + position, offset, 0, 0, attr);

		debug->lpVtbl->Release(debug);
	}
out:
	return(S_OK);
}

static STDMETHODIMP GetPositionOfContext(MyRealIDebugDocument *this, IDebugDocumentContext *context, ULONG *position, ULONG *numChars)
{
	// Our entire script falls under one IDebugDocumentContext
	*numChars = this->ScriptSize;
	*position = 0;
	return(S_OK);
}

static STDMETHODIMP GetContextOfPosition(MyRealIDebugDocument *this, ULONG position, ULONG numChars, IDebugDocumentContext **pObj)
{
	*pObj = (IDebugDocumentContext *)(((unsigned char *)this + offsetof(MyRealIDebugDocument, context)));
	contextAddRef(*pObj);
	return(S_OK);
}

static STDMETHODIMP InsertText(MyRealIDebugDocument *this, ULONG position, ULONG numChars, OLECHAR *text)
{
	return(E_FAIL);
}

static STDMETHODIMP RemoveText(MyRealIDebugDocument *this, ULONG position, ULONG numChars)
{
	return(E_FAIL);
}

static STDMETHODIMP textReplaceText(MyRealIDebugDocument *this, ULONG position, ULONG numChars, OLECHAR *text)
{
	return(E_FAIL);
}













//==================================================================
// IDebugDocumentContext object
//==================================================================

static STDMETHODIMP contextQueryInterface(IDebugDocumentContext *this,  REFIID riid, void **pObj)
{
	this = (IDebugDocumentContext *)(((unsigned char *)this - offsetof(MyRealIDebugDocument, context)));
	return(textAuthQueryInterface((MyRealIDebugDocument *)this, riid, pObj));
}

static STDMETHODIMP_(ULONG) contextAddRef(IDebugDocumentContext *this)
{
	this = (IDebugDocumentContext *)(((unsigned char *)this - offsetof(MyRealIDebugDocument, context)));
	return(textAuthAddRef((MyRealIDebugDocument *)this));
}

static STDMETHODIMP_(ULONG) contextRelease(IDebugDocumentContext *this)
{
	this = (IDebugDocumentContext *)(((unsigned char *)this - offsetof(MyRealIDebugDocument, context)));
	return(textAuthRelease((MyRealIDebugDocument *)this));
}

static STDMETHODIMP GetDocument(IDebugDocumentContext *this, IDebugDocument **pObj)
{
	register IDebugDocument	*debugDoc;

	debugDoc = (IDebugDocument *)(((unsigned char *)this - offsetof(MyRealIDebugDocument, context)));
	textAuthAddRef((MyRealIDebugDocument *)debugDoc);
	*pObj = debugDoc;
	return(S_OK);
}

static STDMETHODIMP EnumCodeContexts(IDebugDocumentContext *this, IEnumDebugCodeContexts **pObj)
{
	register MyRealIDebugDocument	*ptr;
	IActiveScriptDebug				*debug;
	register HRESULT				hr;

	// Assume an error
	*pObj = 0;

	// Get our MyRealIDebugDocument (which wraps this IDebugDocumentContext)
	ptr = (MyRealIDebugDocument *)(((unsigned char *)this - offsetof(MyRealIDebugDocument, context)));

	// Get the engine's IActiveScriptDebug
	if (EngineActiveScript->lpVtbl->QueryInterface(EngineActiveScript, &IID_IActiveScriptDebug, (void **)&debug))
		return(E_FAIL);

	// Call its EnumCodeContextsOfPosition to fill in the IEnumDebugCodeContexts ptr.
	// EnumCodeContextsOfPosition will AddRef() it. NOTE: We pass our MyRealIDebugDocument
	// pointer as the "context" arg since that is what we passed as the context arg to the 
	// engine IActiveScriptParse's ParseScriptText()
	hr = debug->lpVtbl->EnumCodeContextsOfPosition(debug, (DWORD)ptr, 0, ptr->ScriptSize, pObj);

	// Don't need the IActiveScriptDebug anymore
	debug->lpVtbl->Release(debug);

	return(hr);
}












//==================================================================
// IDebugSessionProvider object
//==================================================================
/*
STDMETHODIMP StartDebugSession(IDebugSessionProvider *this, IRemoteDebugApplication *pda)
{
	register MyRealIActiveScriptSite	*site;

	site = (MyRealIActiveScriptSite *)(((unsigned char *)this - offsetof(MyRealIActiveScriptSite, sessionProv)));

	return(pda->lpVtbl->ConnectDebugger(pda, &site->appDebug));
}
*/