// Main functions for an example program that loads and debugs a script.
//
// NOTE: This example uses my docking windows DLL (DockWnd.dll) to make
// the "Variables" and "Callstack" windows dockable. This is just to make
// the debugger more user-friendly, but otherwise has no bearing upon the
// ActiveX debugging functionality. For more information about this add-on,
// read my Code Project article.

#include <windows.h>
#include <commctrl.h>
#include <objbase.h>
#include <activscp.h>
#include <activdbg.h>
#include <tchar.h>
#include <afxres.h>
#include "TraceWin.h"
#include "IActiveScriptSite.h"
#include "resource.h"
#include "extern.h"
#include "DockWnd.h"
#include "CallStack.h"
#include "Variables.h"

// Which menu heading number the "Window" menu is, referenced from 0
#define WINDOWMENUOFFSET 3

// Definition of the entry function for our thread that runs a script
typedef unsigned int (__stdcall* PTHREAD_START)(MyRealIDebugDocument *);

HINSTANCE						InstanceHandle;
HWND							MainFrameWindow;
HWND							MainWindow;
HFONT							FontHandle;

// Used by our IApplicationDebugger's onHandleBreakPoint() to wait at
// a breakpoint
IRemoteDebugApplicationThread	*RemoteDebugApplicationThread;

// Currently executing line #. If -1, none
DWORD							DebugLine;

// Since we're only going to run one script at a time (and therefore
// require only 1 engine open at any given time), then we'll globally
// declare our IActiveScriptSite object (and initialize it with a call
// to intActiveScriptSite). NOTE: If we were going to allow a script
// to call some function written in a different language, then we would
// need to provide another IActiveScriptSite object for that language
// too. But, we're not
static MyRealIActiveScriptSite	MyActiveScriptSite;

// Engine's IActiveScript *
IActiveScript					*EngineActiveScript;

// Bitmap used to draw a breakpoint
static HBITMAP					BreakPointBitmap;

// Set to the handle of the script thread when some script is running
static HANDLE					ThreadHandle;

// For script file dialog
static const WCHAR	Load[] = L"Pick script to load (or Cancel to quit):";
static const WCHAR	ExtensionList[] = {'V','B','s','c','r','i','p','t',' ','(','*','.','v','b','s',')',0,
								'*','.','v','b','s',0,
								'J','S','c','r','i','p','t',' ','(','*','.','v','j','s',')',0,
								'*','.','j','v','s',0,
								'A','l','l',' ','f','i','l','e','s',' ','(','*','.','*',')',0,
								'*','.','*',0,0};

// For getting engine's GUID from registry
static const TCHAR	CLSIDStr[] = _T("CLSID");
static const TCHAR	ScriptEngineStr[] = _T("ScriptEngine");

// For creating Frame and main MDI window
const WCHAR			AppName[] = L"Script Debugger";
const TCHAR			AppClassName[] = _T("Debugger");
const TCHAR			MDIClientClass[] = _T("MDICLIENT");
const TCHAR			ClientClassName[] = _T("MyMDIClient");

// Error messages
const TCHAR			ErrorStr[] = _T("Error");
const TCHAR			CantRegWindow[] = _T("Can't register window!");
const TCHAR			CantCreateWindow[] = _T("Can't create window!");
const TCHAR			NoMem[] = _T("Out of memory!");

const GUID IID_IActiveScript = {0xbb1a2ae1, 0xa4f9, 0x11cf, 0x8f, 0x20, 0x00, 0x80, 0x5f, 0x2c, 0xd0, 0x64};
const GUID CATID_ActiveScriptParse = {0xf0b7a1a2, 0x9847, 0x11cf, 0x8f, 0x20, 0x00, 0x80, 0x5f, 0x2c, 0xd0, 0x64};
const GUID IID_IActiveScriptParse32 = {0xbb1a2ae2, 0xa4f9, 0x11cf, 0x8f, 0x20, 0x00, 0x80, 0x5f, 0x2c, 0xd0, 0x64};





/***************** getITypeInfoFromExe() ***************
 * Loads/creates an ITypeInfo for the specified GUID.
 *
 * guid =			The GUID of the Object/VTable for
 *					which we want an ITypeInfo.
 * iTypeInfo =		Where to return the ITypeInfo. 
 *
 * RETURNS: 0 if success, or HRESULT if fail.
 *
 * NOTE: Our type library must be embedded as a custom
 * resource in this EXE using the following line:
 *
 * 1 TYPELIB MOVEABLE PURE   "some_name.tlb"
 *
 * Where "some_name.tlb" would be the name of the type library.
 *
 * The caller must AddRef() the returned ITypeInfo to keep
 * it in memory.
 */

HRESULT getITypeInfoFromExe(const GUID *guid, ITypeInfo **iTypeInfo) 
{
	wchar_t				fileName[MAX_PATH];
	ITypeLib			*typeLib;
	register HRESULT	hr;

	// Assume an error
	*iTypeInfo = 0;

	// Load the type library from our EXE's resources
	GetModuleFileNameW(0, &fileName[0], MAX_PATH);
	if (!(hr = LoadTypeLib(&fileName[0], &typeLib)))
	{
		// Let Microsoft's GetTypeInfoOfGuid() create a generic ITypeInfo
		// for the requested VTable (whose GUID is passed)
		hr = typeLib->lpVtbl->GetTypeInfoOfGuid(typeLib, guid, iTypeInfo);

		// We no longer need the type library
		typeLib->lpVtbl->Release(typeLib);
	}

	return(hr);
}





/************************* getLoadName() ***********************
 * Gets the user's choice of script filename, and copies it
 * to MyRealIDebugDocument's Filename[].
 *
 * RETURNS: Newly allocated MyRealIDebugDocument if success,
 * or 0 if cancel/failure.
 */

BOOL getLoadName(MyRealIDebugDocument *docHost)
{
	OPENFILENAMEW	ofn;

	// Clear out fields
	ZeroMemory(&ofn, sizeof(OPENFILENAMEW));

	// Store passed buffer
	ofn.lpstrFile = &docHost->Filename[0];
	ofn.nMaxFile = MAX_PATH;

	// Set size
	ofn.lStructSize = sizeof(OPENFILENAME);

	// Set extensions
	ofn.lpstrFilter = &ExtensionList[0];

	// Set title
	ofn.lpstrTitle = &Load[0];

	// Set flags
	ofn.Flags = OFN_PATHMUSTEXIST|OFN_FILEMUSTEXIST|OFN_LONGNAMES|OFN_EXPLORER|OFN_HIDEREADONLY;

	// Present the dialog and get user's selection
	if (GetOpenFileNameW(&ofn)) return(0);

	// Abort
	return(1);
}





/********************* display_sys_error() ********************
 * Displays a messagebox for the passed OS error number.
 *
 * NOTE: If passed a 0, this calls GetLastError().
 */

void display_sys_error(DWORD err)
{
	TCHAR	buffer[160];

	if (!err) err = GetLastError();		// If passed a 0, caller wants us to call GetLastError(). Do it FIRST!
	buffer[0] = 0;
	FormatMessage(FORMAT_MESSAGE_FROM_SYSTEM, 0, err, MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT), &buffer[0], 160, 0);
	MessageBox(MainFrameWindow, &buffer[0], &ErrorStr[0], MB_OK);
}





/*********************** loadUnicodeScript() ********************
 * Reads a script off of disk, and copies it to a UNICODE
 * buffer.
 *
 * docHost =		Our MyRealIDebugDocument containing the
 *					filename.
 *
 * RETURNS: A pointer to the allocated UNICODE buffer if success,
 * or zero if failure.
 */

static OLECHAR * loadUnicodeScript(MyRealIDebugDocument *docHost)
{
	register HANDLE		hfile;

	// Open the file
	if ((hfile = CreateFileW(&docHost->Filename[0], GENERIC_READ, FILE_SHARE_READ, 0, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, 0)) != INVALID_HANDLE_VALUE)
	{
		char	*psz;

		// Get a buffer to read in the file
		docHost->ScriptSize = GetFileSize(hfile, 0);
		if ((psz = (char *)GlobalAlloc(GMEM_FIXED, docHost->ScriptSize + 1)))
 		{
			DWORD	read;

			// Read in the file
			ReadFile(hfile, psz, docHost->ScriptSize, &read, 0);

			// Get a buffer to convert to UNICODE (plus an extra wchar_t to nul-terminate it since
			// the engine's IActiveScriptParse ParseScriptText expects that)
			if ((docHost->ScriptStart = docHost->ScriptText = (OLECHAR *)GlobalAlloc(GMEM_FIXED, (docHost->ScriptSize + 1) * sizeof(OLECHAR))))
			{
				// Convert to UNICODE and nul-terminate
				MultiByteToWideChar(CP_ACP, 0, psz, docHost->ScriptSize, docHost->ScriptText, docHost->ScriptSize + 1);
				docHost->ScriptText[docHost->ScriptSize] = 0;
			}
			else
				display_sys_error(0);

			GlobalFree(psz);
		}
		else
			display_sys_error(0);

		CloseHandle(hfile);
	}
	else
		display_sys_error(0);

	return(docHost->ScriptText);
}





/********************** display_COM_error() ********************
 * Displays a messagebox for a COM error.
 *
 * msg =		Format string for sprintf().
 * hr =			COM error number.
 *
 * NOTE: Total size of error msg must be < 256 TCHARs.
 */

void display_COM_error(LPCTSTR msg, HRESULT hr)
{
	TCHAR			buffer[256];

	wsprintf(&buffer[0], msg, hr);
	MessageBox(MainFrameWindow, &buffer[0], &ErrorStr[0], MB_OK|MB_ICONEXCLAMATION);
}





/*********************** getEngineGuid() **********************
 * Gets the GUID of the engine needed to run this
 * MyRealIDebugDocument's script.
 */

DWORD getEngineGuid(MyRealIDebugDocument *docHost)
{
	register const WCHAR	*extension;
	HKEY					hk;
	DWORD					type;
	DWORD					size;

	// Let's see if we can find the appropriate script engine to use,
	// based upon the extension on the filename. Hopefully the script
	// engine associated itself with a particular file extension. If so,
	// then it should have set a registry key under HKEY_CLASSES_ROOT.

	// Isolate the extension on the filename
	extension = docHost->Filename + lstrlenW(docHost->Filename);
	goto backup;
	while (*extension != '.')
	{
		if (*extension == '\\' || extension <= docHost->Filename)
		{
			// No extension. We'll need to let the user pick out the engine
			goto choose;
		}

backup:	--extension;
	}

	// See if the engine set a file association
	if (RegOpenKeyExW(HKEY_CLASSES_ROOT, extension, 0, KEY_QUERY_VALUE|KEY_READ, &hk))
	{
		// It didn't. We'll have to let the user pick a script engine, and
		// copy the GUID to &buffer[60]
choose:	size = chooseEngineDlg(&docHost->GuidBuffer);
	}
	else
	{
		HKEY	subKey;
		WCHAR	buffer[100];

		type = REG_SZ;
		size = sizeof(buffer);
		size = RegQueryValueEx(hk, 0, 0, &type, (LPBYTE)&buffer[0], &size);
		RegCloseKey(hk);
		if (size) goto choose;

		// The engine set an association. We got the Language string in buffer[]. Now
		// we can use it to look up the engine's GUID

		// Open HKEY_CLASSES_ROOT\{LanguageName}
again:	size = sizeof(buffer);
		if (!RegOpenKeyEx(HKEY_CLASSES_ROOT, (LPCTSTR)&buffer[0], 0, KEY_QUERY_VALUE|KEY_READ, &hk))
		{
			// Read the GUID (in string format) into buffer[] by querying the value of CLSID
			if (!RegOpenKeyEx(hk, &CLSIDStr[0], 0, KEY_QUERY_VALUE|KEY_READ, &subKey))
			{
				size = RegQueryValueExW(subKey, 0, 0, &type, (LPBYTE)&buffer[0], &size);
				RegCloseKey(subKey);
			}
			else if (extension)
			{
				// If an error, see if we have a "ScriptEngine" key under here that contains
				// the real language name
				if (!RegOpenKeyEx(hk, &ScriptEngineStr[0], 0, KEY_QUERY_VALUE|KEY_READ, &subKey))
				{
					size = RegQueryValueEx(subKey, 0, 0, &type, (LPBYTE)&buffer[0], &size);
					RegCloseKey(subKey);
					if (!size)
					{
						RegCloseKey(hk);
						extension = 0;
						goto again;
					}
				}
			}

			RegCloseKey(hk);

			// Convert the GUID string to a GUID and put it in docHost's &GuidBuffer
			if (!size && (size = CLSIDFromString(&buffer[0], &docHost->GuidBuffer)))
				display_COM_error("Can't get engine GUID: %08X", size);
		}
	}

	// Mark that we're gotten the engine GUID (so that we don't need
	// to prompt the user each time he reruns this script)
	if (!size)
		docHost->Flags |= DOCHOST_GOTGUID;

	return(size);
}






/*********************** runScript() ***********************
 * A separate thread to run a script. This is the main
 * body of that thread.
 *
 * docHost =	Pointer to the MyRealIDebugDocument
 *				whose script is to be run.
 */

DWORD WINAPI runScript(MyRealIDebugDocument *docHost)
{
	register HRESULT	hr;
	IActiveScriptParse	*activeScriptParse;

	// Each thread must initialize the COM system individually
	CoInitialize(0);

	// Connect our debugger to the IDebugApplication
	if ((hr = MyActiveScriptSite.iDebugApplication->lpVtbl->ConnectDebugger(MyActiveScriptSite.iDebugApplication, &MyActiveScriptSite.appDebug)))
		display_COM_error("Can't connect our debugger: %08X", hr);
	else
	{
		// Create an instance of the script engine, and get its IActiveScript object
		if ((hr = CoCreateInstance(&docHost->GuidBuffer, 0, CLSCTX_ALL, &IID_IActiveScript, (void **)&EngineActiveScript)))
			display_COM_error("Can't get engine's IActiveScript: %08X", hr);
		else
		{
			// Get the script engine's IActiveScriptParse object (which we can do from its IActiveScript's QueryInterface)
			if ((hr = EngineActiveScript->lpVtbl->QueryInterface(EngineActiveScript, &IID_IActiveScriptParse, (void **)&activeScriptParse)))
				display_COM_error("Can't get engine's IActiveScriptParse: %08X", hr);
			else
			{
				// Initialize the engine 
				if ((hr = activeScriptParse->lpVtbl->InitNew(activeScriptParse)))
					display_COM_error("Can't initialize engine : %08X", hr);
				else
				{
					// Give the engine our IActiveScriptSite object. If all goes well, the engine
					// will call its QueryInterface (which will AddRef it)
					if ((hr = EngineActiveScript->lpVtbl->SetScriptSite(EngineActiveScript, (IActiveScriptSite *)&MyActiveScriptSite)))
						display_COM_error("Can't set our IActiveScriptSite : %08X", hr);
					else
					{
						// Have the script engine tokenize it and add it to its internal list of scripts to run.
						// NOTE: We pass this script's MyRealIDebugDocument as the "context" arg
						if (!(hr = activeScriptParse->lpVtbl->ParseScriptText(activeScriptParse, docHost->ScriptText, 0, 0, 0, (DWORD)docHost, 0, SCRIPTTEXT_ISPERSISTENT|SCRIPTTEXT_ISVISIBLE, 0, 0)))

						// NOTE: If the script engine has a problem parsing/tokenizing the script, it will
						// have called our IActiveScriptSite's OnScriptError() to display an error msg, so
						// we don't need to do that here
						{
							// No executing line
							DebugLine = (DWORD)-1;

							// Iterate over our entire breakpoint list and add a breakpoint within the
							// code for each breakpoint in the list
							{
							IActiveScriptDebug	*activeScriptDebug;
							MYBREAKPOINT		*breakpoint;

							if ((breakpoint = docHost->BreakPoints))
							{
								// Get the engine's IActiveScriptDebug object
								if (!EngineActiveScript->lpVtbl->QueryInterface(EngineActiveScript, &IID_IActiveScriptDebug, &activeScriptDebug))
								{
									do
									{
										IEnumDebugCodeContexts	*enumContexts;
										IDebugCodeContext		*codeContext;
										ULONG					numFetched;

										// Get a code context for the place where the breakpoint is set
										if (!(hr = activeScriptDebug->lpVtbl->EnumCodeContextsOfPosition(activeScriptDebug, (DWORD)docHost, breakpoint->LineNum, 40 /* hopefully there's some text within the first 40 chars */, &enumContexts)))
										{
											// First code context is as good as any other, so just use the
											// first one that is returned by the enumerator
											enumContexts->lpVtbl->Next(enumContexts, 1, &codeContext, &numFetched);
											if (numFetched)
											{
												codeContext->lpVtbl->SetBreakPoint(codeContext, BREAKPOINT_ENABLED);
												codeContext->lpVtbl->Release(codeContext);
											}

											enumContexts->lpVtbl->Release(enumContexts);
										}
									} while ((breakpoint = breakpoint->Next));
								}

								activeScriptDebug->lpVtbl->Release(activeScriptDebug);
							}
							}

							// If user selected "Debug -> Start", we want to break right at the very beginning
							if (docHost->Flags & DOCHOST_INITIALBREAK)
							{
								IRemoteDebugApplication	*remote;

								if (!MyActiveScriptSite.iDebugApplication->lpVtbl->QueryInterface(MyActiveScriptSite.iDebugApplication, &IID_IRemoteDebugApplication, &remote))
								{
									remote->lpVtbl->CauseBreak(remote);
									remote->lpVtbl->Release(remote);
								}
							}

							docHost->Flags |= DOCHOST_RUNNING;

							__try
							{
								// Set engine's state to CONNECTED. NOTE: If we have any "connection events", then
								// the script engine will QueryInterface our IActiveSite for the needed IDispatch
								// objects from us
								if ((hr = EngineActiveScript->lpVtbl->SetScriptState(EngineActiveScript, SCRIPTSTATE_CONNECTED)))
									display_COM_error("Can't start script running: %08X", hr);
								else
								{
									// Script is done. No executing line
									PostMessage(MainFrameWindow, WM_APP + 3, (WPARAM)-1, 0);
								}
							}

							__finally
							{
								goto done;
							}
						}
					}
				}

				// Release script engine's IActiveScriptParse
done:			activeScriptParse->lpVtbl->Release(activeScriptParse);
			}

			// Release script engine's IActiveScript
			EngineActiveScript->lpVtbl->Release(EngineActiveScript);
//			EngineActiveScript = 0;
		}

		// Disconnect our debugger so the IDebugApplication won't keep our app alive
		MyActiveScriptSite.iDebugApplication->lpVtbl->DisconnectDebugger(MyActiveScriptSite.iDebugApplication);
	}

	// Reset flag
	docHost->Flags &= ~(DOCHOST_INITIALBREAK|DOCHOST_RUNNING);

	// Close any script output window opened
	traceCloseWindow();

	CoUninitialize();

	// Let main thread know that we're done (running the script)
	CloseHandle(ThreadHandle);
	ThreadHandle = 0;

	// Terminate this thread
	return(0);
}





/********************* toggleBreakPoint() *********************
 * Toggles a breakpoint on the given line.
 */

static BOOL toggleBreakPoint(MyRealIDebugDocument *docHost, DWORD lineNum)
{
	register MYBREAKPOINT	*prevpoint;
	register MYBREAKPOINT	*breakpoint;

	// Find the MYBREAKPOINT with the given line number
	prevpoint = (MYBREAKPOINT *)&docHost->BreakPoints;
	while ((breakpoint = prevpoint->Next) && breakpoint->LineNum < lineNum) prevpoint = breakpoint;

	// If not found, allocate one
	if (!breakpoint)
	{
		if (!(breakpoint = (MYBREAKPOINT *)GlobalAlloc(GMEM_FIXED, sizeof(MYBREAKPOINT))))
		{
			MessageBox(MainWindow, &NoMem[0], &ErrorStr[0], MB_OK);
bad:		return(0);
		}

		breakpoint->Next = prevpoint->Next;
		prevpoint->Next = breakpoint;
		breakpoint->LineNum = lineNum;
	}

	// If found, remove it
	else
	{
		prevpoint->Next = breakpoint->Next;
		GlobalFree(breakpoint);
		breakpoint = 0;
	}

	// If the script is running (at a breakpoint), we need to add/remove the breakpoint with
	// the engine too. NOTE: VBscript doesn't seem to allow a breakpoint set while a script
	// is running. Too bad. That would be very useful. VBscript is not very useful
	if (docHost->Flags & DOCHOST_RUNNING)
	{
		IEnumDebugCodeContexts	*enumContexts;
		IDebugCodeContext		*codeContext;
		ULONG					numFetched;
		IActiveScriptDebug		*activeScriptDebug;
		register HRESULT		hr;

		if (!EngineActiveScript->lpVtbl->QueryInterface(EngineActiveScript, &IID_IActiveScriptDebug, &activeScriptDebug))
		{
			if (!(hr = activeScriptDebug->lpVtbl->EnumCodeContextsOfPosition(activeScriptDebug, (DWORD)docHost, lineNum, 40, &enumContexts)))
			{
				enumContexts->lpVtbl->Next(enumContexts, 1, &codeContext, &numFetched);
				if (numFetched)
				{
					hr = codeContext->lpVtbl->SetBreakPoint(codeContext, breakpoint ? BREAKPOINT_ENABLED : BREAKPOINT_DELETED);
					codeContext->lpVtbl->Release(codeContext);
				}

				enumContexts->lpVtbl->Release(enumContexts);
			}

			activeScriptDebug->lpVtbl->Release(activeScriptDebug);

			if (hr)
			{
				display_COM_error("Can't set breakpoint: %08X", hr);
				goto bad;
			}
		}
	}

	return(1);
}





/********************** clientWndProc() **********************
 * Window procedure for MDI client (document) windows.
 */

static LRESULT CALLBACK clientWndProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
	register MyRealIDebugDocument	*docHost;

	// We store this window's MyRealIDebugDocument in its GWL_USERDATA
	docHost = (MyRealIDebugDocument *)GetWindowLong(hwnd, GWL_USERDATA);

	switch (msg)
	{
		//***************************************************************
		//======================== Redraw window ========================
		case WM_PAINT:
		{
			register WCHAR	*ptr;
			register DWORD	len;
			PAINTSTRUCT		ps;
			HDC				hdc;
			HGDIOBJ			temp;
			RECT			rectWnd;
			long			bottom;
			DWORD			lineNum;
			MYBREAKPOINT	*breakpoint;
			unsigned char	extra;

			// Get DC
			hdc = BeginPaint(hwnd, &ps);

			// Get current width/height of Client
			GetClientRect(hwnd, &rectWnd);

			// Erase background
//			FillRect(hdc, &rectWnd, (HBRUSH)1);

			// Get the text start
			ptr = docHost->ScriptStart;

			// Blank out the area where the breakpoints are drawn. Use COLORINDEX_SELMARGIN
			lineNum = rectWnd.right;
			rectWnd.right = 20;
			SetBkColor(hdc, 0x00C0C0C0);
			ExtTextOut(hdc, 0, 0, ETO_OPAQUE, &rectWnd, 0, 0, 0);
			rectWnd.right = lineNum;

			// Set TRANSPARENT mode for text output
			SetBkColor(hdc, 0x004040FF);
			SetBkMode(hdc, TRANSPARENT);
			SetTextColor(hdc, 0);

			// Select the font
			temp = SelectObject(hdc, (HGDIOBJ)FontHandle);

			// Leave room for breakpoint bitmaps
			rectWnd.left = 21;

			// Start with top line
			rectWnd.top = 1;
			lineNum = docHost->StartLineNum;
			bottom = rectWnd.bottom;
			breakpoint = docHost->BreakPoints;

			do
			{
				rectWnd.bottom = rectWnd.top + 13;

				// Do we have some more chars to print?
				len = extra = 0;
				while (*(ptr + len))
				{
					// Newline?
					if (*(ptr + len) == '\r')
					{
						++extra;
						if (*(ptr + len + 1) == '\n') ++extra;
						break;
					}

					++len;
				}

				if (!len)
				{
					if (!*ptr)
					{
						docHost->Flags |= DOCHOST_LASTLINEHIT;
						break;
					}

					// A blank line
					goto skipline;
				}

				// Draw the breakpoint icon
				if (breakpoint && breakpoint->LineNum == lineNum)
				{
					HBITMAP		old_bm; 
					HDC			imgDC;

					imgDC = CreateCompatibleDC(hdc);
					old_bm = SelectObject(imgDC, BreakPointBitmap); 
					BitBlt(hdc, 0, rectWnd.top, 14, 14, imgDC, 0, 0, SRCCOPY); 
					SelectObject(imgDC, old_bm);
					DeleteDC(imgDC);
					breakpoint = breakpoint->Next;
				}

				// If the currently executing line, draw the background highlighted
				if (DebugLine == lineNum)
				{
					SetBkMode(hdc, OPAQUE);
					ExtTextOut(hdc, 0, 0, ETO_OPAQUE, &rectWnd, 0, 0, 0);
					SetBkMode(hdc, TRANSPARENT);
				}
		
				// Display this line
				DrawTextW(hdc, ptr, len, &rectWnd, DT_EXPANDTABS|DT_NOPREFIX|DT_SINGLELINE|DT_WORDBREAK);

				// Next line
skipline:		ptr += len + extra;
				rectWnd.top = rectWnd.bottom;
				++lineNum;

				// Any more chars to print? Is there room for another line?
			} while (*ptr && rectWnd.bottom < bottom);

			// ====================================================
			// Restore orig font
			SelectObject(hdc, temp);

			// Free DC
			EndPaint(hwnd, &ps);

ret0_2:		return(0);
		}	

		//******************************************************************
		// ======================= Mouse double-click ======================
		case WM_LBUTTONDBLCLK:
		{
			// If this script isn't running, or we're paused at a breakpoint right
			// now, toggle a breakpoint upon the line where the user clicked
			if (!ThreadHandle || RemoteDebugApplicationThread)
			{
				wParam = HIWORD(lParam);
				if (wParam)
				{
					toggleBreakPoint(docHost, docHost->StartLineNum + ((wParam - 1) / 13));
					RedrawWindow(hwnd, 0, 0, RDW_ERASE|RDW_INVALIDATE);
				}
			}	

			goto ret0_2;
		}

		//******************************************************************
		// ====================== User closing window ======================
		case WM_CLOSE:
		{
			// If this script is running, stop debugging (but don't close
			// the window yet)
			if (docHost->Flags & DOCHOST_RUNNING)
			{
				clientWndProc(hwnd, WM_COMMAND, IDM_DEBUG_STOPDEBUGGING, 1);
				goto ret0_2;
			}
			break;
		}

		//******************************************************************
		// ==================== User selected menu item ====================
		case WM_COMMAND:
		{
			switch (LOWORD(wParam))
			{
				// -------------------- MENU: Debug -> Go
				case IDM_DEBUG_START:
		        case IDM_DEBUG_GO:
				{
					// No script is running?
					if (!ThreadHandle)
					{
						if ((docHost->Flags & DOCHOST_GOTGUID) || !getEngineGuid(docHost))
						{
							// If "Start", rather than "Go", have an implicit breakpoint on the first instruction
							if (LOWORD(wParam) == IDM_DEBUG_START) docHost->Flags |= DOCHOST_INITIALBREAK;

							// Create a secondary thread to run the script. It will do the
							// actual call to the engine to run the script while we go back and
							// manage the user interface
							if (!(ThreadHandle = CreateThread(0, 0, (PTHREAD_START)runScript, docHost, 0, &wParam)) ||

								// Did the thread startup ok?
								ThreadHandle == (HANDLE)-1)
							{
								// No it didn't. Zero the handle
								ThreadHandle = 0;

								// Reset flag
								docHost->Flags &= ~DOCHOST_INITIALBREAK;
							}

							// NOTE: If script thread starts, 'ThreadHandle' will be closed by that
							// thread when it terminates
						}
					}

					// Script is already running. If we're at a breakpoint, resume execution
					else if (RemoteDebugApplicationThread)
					{
						IRemoteDebugApplication		*rda;

						wParam = BREAKRESUMEACTION_CONTINUE;
do_debug:				if (!RemoteDebugApplicationThread->lpVtbl->GetApplication(RemoteDebugApplicationThread, &rda))
						{
							rda->lpVtbl->ResumeFromBreakPoint(rda, RemoteDebugApplicationThread, wParam, ERRORRESUMEACTION_SkipErrorStatement);
							rda->lpVtbl->Release(rda);
						}

						// No docs available on this, but apparently, the Process Debug Manager doesn't
						// AddRef() the IRemoteDebugApplicationThread on our behalf. That is contrary
						// to every other COM object I've seen. Probably yet another oversight by MS'
						// scripting team
				//		RemoteDebugApplicationThread->lpVtbl->Release(RemoteDebugApplicationThread);

						// Clear this global to indicate we're no longer at a breakpoint
						RemoteDebugApplicationThread = 0;

						DebugLine = (DWORD)-1;
						InvalidateRect(hwnd, 0, 1);
					}

					break;
				}

				// -------------------- MENU: Debug -> Stop
		        case IDM_DEBUG_STOPDEBUGGING:
				{
					// Clear the Variables/Callstack windows
					updateVariables();
					updateCallStack();

					// If we're paused at a breakpoint, we can abort simply by
					// passing BREAKRESUMEACTION_ABORT to ResumeFromBreakPoint()
					if (RemoteDebugApplicationThread)
					{
						wParam = BREAKRESUMEACTION_ABORT;
						goto do_debug;
					}

					// Otherwise, we'll have to abort by calling InterruptScriptThread
					EngineActiveScript->lpVtbl->InterruptScriptThread(EngineActiveScript, SCRIPTTHREADID_ALL, 0, 0);

					DebugLine = (DWORD)-1;
					InvalidateRect(hwnd, 0, 1);

					break;
				}

				// -------------------- MENU: Debug -> Step into
		        case IDM_DEBUG_STEPINTO:
				{
					wParam = BREAKRESUMEACTION_STEP_INTO;
					goto do_debug;
				}

				// -------------------- MENU: Debug -> Step over
		        case IDM_DEBUG_STEPOVER:
				{
					wParam = BREAKRESUMEACTION_STEP_OVER;
					goto do_debug;
				}

				// -------------------- MENU: Debug -> Step out
		        case IDM_DEBUG_STEPOUT:
				{
					wParam = BREAKRESUMEACTION_STEP_OUT;
					goto do_debug;
				}

				// -------------------- MENU: Debug -> Break
				case IDM_DEBUG_BREAK:
				{
					// Note: Our IActiveScriptSite's () will be called
					// with BREAKREASON_DEBUGGER_HALT onHandleBreakPoint()
					MyActiveScriptSite.iDebugApplication->lpVtbl->CauseBreak(MyActiveScriptSite.iDebugApplication);
				}
			}

			return(0);
		}

		//******************************************************************
		case WM_DESTROY:
		{
			// Free the MyRealIDebugDocument
			docHost->textAuthor.lpVtbl->Release(&docHost->textAuthor);
			break;
		}

		//******************************************************************
		case WM_CREATE:
		{
			register CREATESTRUCT				*cs;

			cs = (CREATESTRUCT *)lParam;
			docHost = (MyRealIDebugDocument *)((MDICREATESTRUCT *)cs->lpCreateParams)->lParam;
			SetWindowLong(hwnd, GWL_USERDATA, (LPARAM)docHost);

			SetWindowTextW(hwnd, docHost->Filename);
		}
	}

	return(DefMDIChildProc(hwnd, msg, wParam, lParam));
}





/************************** setMenuState() **************************
 * Called before the main window's menu is about to be displayed.
 * We use this to update any checkmarks and enabled state of our
 * menu items.
 */

static void setMenuState(void)
{
	register MyRealIDebugDocument	*docHost;

	// Get the active document window
	{
	register HWND	child;

	docHost = 0;
	if ((child = (HWND)SendMessage(MainWindow, WM_MDIGETACTIVE, 0, 0)))
		docHost = (MyRealIDebugDocument *)GetWindowLong(child, GWL_USERDATA);
	}

	{
	register HMENU	menu;
	register DWORD	value;

	menu = GetMenu(MainFrameWindow);

	// Enable "Debug -> Start" if we haven't yet run a script, and a
	// script is loaded
	EnableMenuItem(menu, IDM_DEBUG_START, !ThreadHandle && docHost ? MF_ENABLED : MF_DISABLED|MF_GRAYED);

	// Enable "Debug -> Go" if we haven't yet run a script (and a script
	// is loaded), or if we're paused at a breakpoint
	value = MF_DISABLED|MF_GRAYED;
	if (!ThreadHandle)
	{
		if (docHost) value = MF_ENABLED;
	}
	else if (RemoteDebugApplicationThread)
		value = MF_ENABLED;
	EnableMenuItem(menu, IDM_DEBUG_GO, value);

	// Enable other Debug menu items if we're paused at a breakpoint
	if (RemoteDebugApplicationThread) value = MF_ENABLED;
	else value = MF_DISABLED|MF_GRAYED;
	EnableMenuItem(menu, IDM_DEBUG_STOPDEBUGGING, value);
	EnableMenuItem(menu, IDM_DEBUG_STEPINTO, value);
	EnableMenuItem(menu, IDM_DEBUG_STEPOVER, value);
	EnableMenuItem(menu, IDM_DEBUG_STEPOUT, value);

	// Enable "Debug -> Break" if we're running a script, and not
	// paused at a breakpoint
	EnableMenuItem(menu, IDM_DEBUG_BREAK, !ThreadHandle || RemoteDebugApplicationThread ? MF_DISABLED|MF_GRAYED : MF_ENABLED);

	DrawMenuBar(MainFrameWindow);
	}
}





/************************* frameWndProc() ***********************
 * Window procedure for main frame window.
 */

static LRESULT CALLBACK frameWndProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
	static int x = 200, y = 200;

	switch(msg)
	{
		case WM_CREATE:
		{
			CLIENTCREATESTRUCT	ccs;

			// Let the OS know where our "Window" menu is within our menus
			ccs.hWindowMenu = GetSubMenu(GetMenu(hwnd), WINDOWMENUOFFSET);
			ccs.idFirstChild = IDR_CLIENT;

			// Create an MDI client to host all of our client windows
			if ((MainWindow = CreateWindow(&MDIClientClass[0], 0, WS_CHILD|WS_CLIPCHILDREN|WS_CLIPSIBLINGS|WS_VISIBLE,
							0, 0, 0, 0, hwnd, (HMENU)1, InstanceHandle, (LPSTR)&ccs)))
			{
				goto ret0;
			}

			return(-1);
		}

		case WM_NCACTIVATE:
		{
			DOCKPARAMS	dockParams;

			dockParams.container = dockParams.hwnd = hwnd;
			dockParams.wParam = wParam;
			dockParams.lParam = lParam;
			return(DockingActivate(&dockParams));
		}

		case WM_ENABLE:
		{
			DOCKPARAMS	dockParams;

			dockParams.container = dockParams.hwnd = hwnd;
			dockParams.wParam = wParam;
			dockParams.lParam = lParam;
			return(DockingEnable(&dockParams));
		}

		case WM_DESTROY:
		{
			PostQuitMessage(0);
			goto ret0;
		}

		case WM_CLOSE:
		{
			register HWND	child;

close:		if ((child = (HWND)SendMessage(MainWindow, WM_MDIGETACTIVE, 0, 0)))
			{
				register MyRealIDebugDocument	*docHost;

				// If this script is running, stop debugging
				docHost = (MyRealIDebugDocument *)GetWindowLong(child, GWL_USERDATA);
				if (docHost->Flags & DOCHOST_RUNNING)
					clientWndProc(child, WM_COMMAND, IDM_DEBUG_STOPDEBUGGING, 1);
				else
					// Close the child
					SendMessage(MainWindow, WM_MDIDESTROY, (WPARAM)child, 0);
			}
			else
				DestroyWindow(hwnd);
			goto ret0;
		}

		case WM_SIZE:
		{
			HDWP	hdwp;
			RECT	rect;

			// Do the default handling of this message
			DefFrameProc(hwnd, MainWindow, msg, wParam, lParam);

			// Set the area where Docking Frame windows are allowed.
			// (Take into account any status bar, toolbar etc).
			rect.left = rect.top = 0;
			rect.right = LOWORD(lParam);
			rect.bottom = HIWORD(lParam);

			// Allocate enough space for all Docking Frames which are actually docked
			hdwp = BeginDeferWindowPos(DockingCountFrames(hwnd, 1) + 1);

			// Position the docked Docking Frame windows for this container
			// window. rect will be modified to contain the "inner" client
			// rectangle, where we can position an MDI client
			DockingArrangeWindows(hwnd, hdwp, &rect);

			// Here we resize our MDI client window so that it fits into the area
			// described by "rect". Do not let it extend outside of this
			// area or it (and the client windows inside of it) will be obscured
			// by docked toolwindows (or vice versa).
			DeferWindowPos(hdwp, MainWindow, 0, rect.left, rect.top, rect.right - rect.left, rect.bottom - rect.top, SWP_NOACTIVATE|SWP_NOZORDER);

			EndDeferWindowPos(hdwp);

			// Here, you really should figure out what state the contents of the MDI window is in.
			// For example, if some client window is maximized to fill the MDI client, then you
			// would simply leave things as above. On the other hand, if there are a bunch of
			// client windows visible, then you could rearrange them within the new (reduced)
			// area of the MDI client like so:
			//
			// SendMessage(MainWindow, WM_MDICASCADE, 0, 0);
			//
			// Not doing the above may leave some clients covered by a docking frame. But, the
			// user can remedy this situation himself by selecting the tile or cascade items
			// under the Window menu. So, it's not a big deal.

ret0:		return(0);
		}

		case WM_INITMENU:
		{
			setMenuState();
			goto ret0;
		}

		case WM_COMMAND:
		{
			switch (LOWORD(wParam))
			{
				// -------------------- MENU: File -> Close
		        case IDM_FILE_EXIT:
					goto close;

				// -------------------- MENU: File -> Load script
		        case IDM_FILE_LOADSCRIPT:
				{
					register MyRealIDebugDocument	*docHost;

					// Get one of our MyRealIDebugDocument objects for this window/script. This object
					// creates (and stores) a IDebugDocumentHelper object from the COM operating
					// system. The IDebugDocumentHelper encapsules a lot of ActiveX Debugging objects
					// that we would normally have to create ourselves. As long as we accept the
					// default behavior of the IDebugDocumentHelper's objects, then this is easiest
					if ((docHost = allocIDebugDocument(&MyActiveScriptSite)))
					{
						// Get the filename of the script to load
						if (!getLoadName(docHost))
						{
							// Load the script as UNICODE text
							if (loadUnicodeScript(docHost))
							{
								MDICREATESTRUCT		mcs;

								// Create another client window (and save the MyRealIDebugDocument in
								// the window's GWL_USERDATA)
								ZeroMemory(&mcs, sizeof(MDICREATESTRUCT));
 								mcs.szClass = &ClientClassName[0];
    							mcs.hOwner = InstanceHandle;
								mcs.x = mcs.cx = mcs.y = mcs.cy = CW_USEDEFAULT;
								mcs.lParam = (LPARAM)docHost;
								//mcs.style = 0;

								if (SendMessage(MainWindow, WM_MDICREATE, 0, (LPARAM)(LPMDICREATESTRUCT)&mcs)) break;
							}
						}

						docHost->textAuthor.lpVtbl->Release(&docHost->textAuthor);
					}

					break;
				}

				// -------------------- MENU: View -> Call stack
		        case IDM_VIEW_DEBUG_CALLSTACK:
				{
					onViewCallstack();
					break;
				}

				// -------------------- MENU: View -> Variables
		        case IDM_VIEW_DEBUG_VARIABLES:
				{
					onViewVariables();
					break;
				}

				case ID_WINDOW_TILE_HORZ:
				{
					SendMessage(MainWindow, WM_MDITILE, 0, 0);
					break;
				}

				case ID_WINDOW_CASCADE:
				{
					SendMessage(MainWindow, WM_MDICASCADE, 0, 0);
					break;
				}

				case ID_WINDOW_ARRANGE:
				{
					SendMessage(MainWindow, WM_MDIICONARRANGE, 0, 0);
					break;
				}

				// Let the MDIclient window handle all commands we don't handle here
				default:
				{
					register HWND	child;

					if ((child = (HWND)SendMessage(MainWindow, WM_MDIGETACTIVE, 0, 0)))
						return(clientWndProc(child, msg, wParam, lParam));
				}
			}

			goto ret0;
		}

		//******************************************************************
		case WM_APP + 3:
		{
			// Send by the script thread IApplicationDebugger's onHandleBreakPoint()
			// when it needs us to move the current cursor position to a particular
			// line
			register HWND	child;

			DebugLine = wParam;

			// Save the IRemoteDebugApplicationThread in a global so that
			// our main thread can query the callstack and variables, and
			// resume running the script
			RemoteDebugApplicationThread = (IRemoteDebugApplicationThread *)lParam;

			if ((child = (HWND)SendMessage(MainWindow, WM_MDIGETACTIVE, 0, 0)))
				InvalidateRect(child, 0, 1);

			updateCallStack();
			updateVariables();

			goto ret0;
		}
	}

	return(DefFrameProc(hwnd, MainWindow, msg, wParam, lParam));
}





/********************* createMainFrameWindow() *******************
 * Sets up and creates the main window.
 *
 * Registers the Window classes for the main application frame
 * window and the MDI child windows. Loads the 2 menus for the
 * MDI document and the main frame. Creates the main frame
 * window.
 */

static BOOL createMainFrameWindow(void)
{
	WNDCLASSEX	wc;

	// Register the main frame class
	ZeroMemory(&wc, sizeof(WNDCLASSEX));

	wc.cbSize = sizeof(WNDCLASSEX);
	wc.style = CS_HREDRAW|CS_VREDRAW|CS_CLASSDC|CS_PARENTDC;
	wc.lpfnWndProc = frameWndProc;
	wc.cbWndExtra = sizeof(DOCKINFO *);		// We'll keep the list of DOCKINFOs in the extra data area of the frame window
	wc.hInstance = InstanceHandle;
	wc.hIcon = LoadIcon(0, MAKEINTRESOURCE(IDR_MAINFRAME));
	wc.hCursor = LoadCursor(NULL, IDC_ARROW);
	wc.hbrBackground = (HBRUSH)(COLOR_WINDOW + 1);
	wc.lpszClassName = &AppClassName[0];
	wc.hIconSm = LoadIcon(NULL, MAKEINTRESOURCE(IDR_MAINFRAME));
	wc.lpszMenuName = MAKEINTRESOURCE(IDR_MAINFRAME);

	if (RegisterClassEx(&wc))
	{
		// Register the class for MDI child windows
		wc.lpfnWndProc = clientWndProc;
		wc.style = CS_HREDRAW|CS_VREDRAW|CS_CLASSDC|CS_PARENTDC|CS_DBLCLKS;
	    wc.lpszClassName = &ClientClassName[0];
		wc.cbWndExtra = 0;
		wc.hIcon = LoadIcon(NULL, MAKEINTRESOURCE(IDR_CLIENT));
		wc.hIconSm = LoadIcon(NULL, MAKEINTRESOURCE(IDR_CLIENT));

		if (RegisterClassEx(&wc))
		{
			// Create the frame window
			if ((MainFrameWindow = CreateWindow(&AppClassName[0], &AppClassName[0],
				WS_OVERLAPPEDWINDOW|WS_CLIPCHILDREN,
				CW_USEDEFAULT, CW_USEDEFAULT, CW_USEDEFAULT, CW_USEDEFAULT, 0,
				0, InstanceHandle, 0)))
			{
				// Show Callstack/Variables windows
				onViewCallstack();
				onViewVariables();

				// Success
				return(1);
			}

			MessageBox(0, &CantCreateWindow[0], &ErrorStr[0], MB_OK);
			goto bad;
		}
	}

	MessageBox(0, &CantRegWindow[0], &ErrorStr[0], MB_OK);
bad:
	return(0);
}





/************************** WinMain() **************************
 * Our EXE's entry point. This is called by Windows when our
 * EXE first starts up.
 */

int APIENTRY WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow)
{
	HRESULT				hr;

	// Save Instance handle which I need when opening the "Choose engine" dialog
	// box. That dialog is linked into this executable's resources, so I need to pass
	// this handle to DialogBox() when I open that dialog
	InstanceHandle = hInstance;

	// Loads Windows common control's DLL
	InitCommonControls();

	// Frame window not open yet
	MainFrameWindow =

	// No script running
	(HWND)RemoteDebugApplicationThread = ThreadHandle = 0;
	
	// No executing line
	DebugLine = (DWORD)-1;

	// Initialize use of DockWnd.dll
	if (DockingInitialize(0))
		display_sys_error(0);
	else
	{
		// Init variables for the docking windows
		initCallStack();
		initVariables();

		// Initialize COM DLL
		if ((hr = CoInitialize(0)))
			display_COM_error("Failed to initialize COM: %08X", hr);
		else
		{
			// Initialize our IActiveScriptSite object
			if (initActiveScriptSite(&MyActiveScriptSite))
			{
				// Get font used to draw lines
				FontHandle = GetStockObject(DEFAULT_GUI_FONT);

				// Load the break point bitmap
				if (!(BreakPointBitmap = LoadImage(InstanceHandle, MAKEINTRESOURCE(IDBM_BREAKPOINT), IMAGE_BITMAP, 14, 14, 0)))
					display_sys_error(0);
  				else
				{
					// Init docking windows
					initCallStackWindow();
					initVariablesWindow();

					// Register and create the main (container) window
					if (createMainFrameWindow())
					{
						MSG			msg;

						ShowWindow(MainFrameWindow, SW_SHOWDEFAULT);
						UpdateWindow(MainFrameWindow);

						// Do message loop
						while (GetMessage(&msg, 0, 0, 0) == 1)
						{
							if (!TranslateMDISysAccel(MainWindow, &msg))
							{
								TranslateMessage(&msg);
								DispatchMessage(&msg); 
							} 
						}
					}

					// Free docking windows
					freeVariables();
					freeCallStack();
				}

				// Free our IActiveScriptSite resources
				freeActiveScriptSite(&MyActiveScriptSite);
			}

			// Free COM
			CoUninitialize();
		}

		// Free docking library
		DockingUnInitialize();
	}

	return(0);
}
