// Presents a window containing all of the script "variables"
// at the currently running level.

#include <windows.h>
#include <tchar.h>
#include <commctrl.h>
#include <objbase.h>
#include <comcat.h>
#include <activscp.h>
#include <activdbg.h>
#include "Resource.h"
#include "Extern.h"
#include "DockWnd.h"





static HWND			VariablesFrame;
static DOCKINFO		*VariablesDockInfo;
static const TCHAR	VariablesTitle[] = "Variables";





static freeDebugPropertyInfo(DebugPropertyInfo *this)
{
	SysFreeString(this->m_bstrName);
	SysFreeString(this->m_bstrType);
	SysFreeString(this->m_bstrValue);
	SysFreeString(this->m_bstrFullName);

	if (this->m_pDebugProp) this->m_pDebugProp->lpVtbl->Release(this->m_pDebugProp);
}





static HRESULT addPropertyToList(TV_INSERTSTRUCTW *insertStruct, IDebugProperty *debugProperty)
{
	register HRESULT		hr;
	IEnumDebugPropertyInfo	*enumInfo;

	// Get the IEnumDebugPropertyInfo to enumerate the variables at this level 
	if (!debugProperty->lpVtbl->EnumMembers(debugProperty, PROP_INFO_STANDARD|PROP_INFO_DEBUGPROP, 10, &IID_IEnumDebugPropertyInfo, &enumInfo))
	{
		DebugPropertyInfo		propInfo;
		ULONG					numFetched;

		enumInfo->lpVtbl->Reset(enumInfo);

		for (;;)
		{
			register HTREEITEM			parent;

			// Get the next variable's DebugPropertyInfo
			enumInfo->lpVtbl->Next(enumInfo, 1, &propInfo, &numFetched);
			if (!numFetched) break;

			parent = insertStruct->hParent;

			// Get the variable name
			if (!(insertStruct->item.pszText = propInfo.m_bstrFullName))
				insertStruct->item.pszText = propInfo.m_bstrName;

			// Insert the item
			if (!(insertStruct->hParent = (HTREEITEM)SendMessageW(VariablesDockInfo->focusWindow, TVM_INSERTITEM, 0, (LPARAM)insertStruct)))
				freeDebugPropertyInfo(&propInfo);
			else
			{
				SysFreeString(propInfo.m_bstrName);
				SysFreeString(propInfo.m_bstrType);
				SysFreeString(propInfo.m_bstrValue);
				SysFreeString(propInfo.m_bstrFullName);

				// See if this property (variable) has sub-properties to list. If so,
				// recursively list them. Typically, if the variable was an object/struct,\
				// its sub-properties would be the members of that object
				if (propInfo.m_pDebugProp && (hr = addPropertyToList(insertStruct, propInfo.m_pDebugProp))) break;
			}

			insertStruct->hParent = parent;
		}

		enumInfo->lpVtbl->Release(enumInfo);
	}

	debugProperty->lpVtbl->Release(debugProperty);

	return(S_OK);	
}





/*********************** updateVariables() ************************
 * Updates the contents of the Variables window.
 */

void updateVariables(void) 
{
	if (VariablesFrame)
	{
		register HWND		child;

		child = VariablesDockInfo->focusWindow;
		TreeView_DeleteAllItems(child);

		if (RemoteDebugApplicationThread)
		{
			IEnumDebugStackFrames		*stackFrameEnum;
			DebugStackFrameDescriptor	stackFrame;
			IDebugProperty				*debugProperty;
			ULONG						numFetched;

			if (!RemoteDebugApplicationThread->lpVtbl->EnumStackFrames(RemoteDebugApplicationThread, &stackFrameEnum))
			{
				TV_INSERTSTRUCTW			insertStruct;

				stackFrameEnum->lpVtbl->Reset(stackFrameEnum);

				ZeroMemory(&insertStruct, sizeof(TV_INSERTSTRUCT));
				insertStruct.hInsertAfter = TVI_LAST;
				insertStruct.item.mask = TVIF_TEXT;

				while (stackFrameEnum->lpVtbl->Next(stackFrameEnum, 1, &stackFrame, &numFetched) == S_OK)
				{
					if (!stackFrame.pdsf->lpVtbl->GetDebugProperty(stackFrame.pdsf, &debugProperty))
						addPropertyToList(&insertStruct, debugProperty);

					stackFrame.pdsf->lpVtbl->Release(stackFrame.pdsf);
				}

				stackFrameEnum->lpVtbl->Release(stackFrameEnum);
			}
		}
	}
}















////////////////////////////////////////////////////////////////////////
// Initialization.
////////////////////////////////////////////////////////////////////////

/********************* variablesClose() ********************
 * Called when Variables window is closing.
 */

static void WINAPI variablesClose(DOCKINFO *dwp)
{
	VariablesFrame = 0;
}

/***************** createVariablesWindow() ****************
 * Creates the Variables (dockable) window, with a LISTBOX
 * that fills the window.
 *
 * RETURNS: Docking frame if success, or 0 if failure.
 */

static HWND createVariablesWindow(void) 
{
	// Create a Docking Frame window
	if ((VariablesFrame = DockingCreateFrame(VariablesDockInfo, MainFrameWindow, &VariablesTitle[0])))
	{
		// Create a "Variables" window. This window will be hosted inside
		// of the Docking Frame window (ie, the contents of the docking window's
		// client area). Save it in the DOCKWND
		if ((VariablesDockInfo->focusWindow = CreateWindow(WC_TREEVIEW, 0, 
			WS_VSCROLL|WS_CHILD|TVS_HASBUTTONS|TVS_HASLINES|TVS_SHOWSELALWAYS|WS_VISIBLE,
			0,0,0,0, VariablesFrame, (HMENU)1000, InstanceHandle, 0)))
		{
			SendMessage(VariablesDockInfo->focusWindow, WM_SETFONT, (WPARAM)FontHandle, 0);

			updateVariables();

			// Show the docking frame
			DockingShowFrame(VariablesDockInfo);

			return(VariablesFrame);
		}

		DestroyWindow(VariablesFrame);	// calls variablesClose()
	}

//	show_custom_errmsg(IDS_BADWINDOW);
	return(0);
}

/************************ initVariables() **************************
 * Called once at start of program to initialize Variables stuff.
 */

void initVariables(void)
{
	VariablesFrame = VariablesDockInfo = 0;
}

/*********************** initVariablesWindow() **********************
 * Called once at start of program to register the Variables
 * window class.
 */

void * initVariablesWindow(void)
{
	// Allocate a DOCKINFO struct
	if ((VariablesDockInfo = DockingAlloc(DWS_DOCKED_BOTTOM)))
	{
		VariablesDockInfo->DockDestroy = variablesClose;

		VariablesDockInfo->nDockedSize = 100;

		// Get Positions from the registry
//		loadWindowSettings((unsigned char *)&VariablesDockInfo->xpos, &VariablesTitle[0], &VariablesDockInfo->uDockedState);
	}

	return(VariablesDockInfo);
}

/************************ freeVariables() *********************
 * Called once at end of program to free the Variables window
 * resources.
 */

void freeVariables(void)
{
	if (VariablesDockInfo)
	{
		// If the DOCKINFO was used at least once, then save the
		// final window position/state to the registry
//		saveWindowSettings((unsigned char *)&VariablesDockInfo->xpos, &VariablesTitle[0], VariablesDockInfo->uDockedState);

		// Free the DOCKINFO
		DockingFree(VariablesDockInfo);
	}
}

/************************* onViewVariables() ************************
 * Toggles display of the Variables window.
 */

HWND onViewVariables(void)
{
	// Create/show it?
	if (!VariablesFrame)
		createVariablesWindow();
	else
	{
		// If the window is free floating, just bring it to the front
		if ((VariablesDockInfo->uDockedState & DWS_FLOATING) && (VariablesDockInfo->dwStyle & DWS_FREEFLOAT))
			SetWindowPos(VariablesFrame, HWND_TOP, 0, 0, 0, 0, SWP_NOMOVE|SWP_NOSIZE);
		else
			DestroyWindow(VariablesFrame);	// calls variablesClose()
	}

	return(VariablesFrame);
}
