//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by DEBUGHOST.rc
//
#define ID_BTNENABLE                    3
#define ID_BTNEVALUATE                  3
#define ID_BTNDISABLE                   4
#define ID_BTNREMOVE                    5
#define IDBM_BREAKPOINT                 100
#define IDD_ABOUTBOX                    100
#define IDR_MAINFRAME                   101
#define IDR_CLIENT                      102
#define IDR_SAMPLEDEBUGGER              102
#define IDD_ENGINELIST                  103
#define IDR_SCRIPTHOST                  103
#define IDR_SAMPLETYPE                  129
#define IDD_APPLICATIONTHREADS          130
#define IDD_VARIABLES                   131
#define IDD_CALLSTACK                   132
#define IDD_APPLICATIONS                133
#define IDD_BREAKPOINTS                 134
#define IDD_IMMEDIATE                   135
#define IDC_ENGINELIST                  1000
#define IDC_TRACE                       1000
#define IDC_LBLTHREADID                 1000
#define IDC_LBLSUSPEND                  1001
#define IDC_BTNSUSPEND                  1002
#define IDC_BTNRESUME                   1003
#define IDC_BTNSETFOCUS                 1004
#define IDC_PRIORITY                    1005
#define IDC_LBLLOCATION                 1006
#define IDC_LSTTHREADS                  1007
#define IDC_LBLVARIABLES                1009
#define IDC_TXTSHORTNAME                1010
#define IDC_LBLSHORTNAME                1011
#define IDC_LBLVALUE                    1012
#define IDC_TXTFULLNAME                 1013
#define IDC_TXTVALUE                    1014
#define IDC_LSTCALLSTACK                1015
#define IDC_LBLTYPE                     1015
#define IDC_TREEVARIABLES               1016
#define IDC_TXTTYPE                     1017
#define IDC_LSTAPPLICATIONS             1017
#define IDC_LBLFULLNAME                 1018
#define IDC_LBLNAME                     1018
#define IDC_BTNUPDATE                   1019
#define IDC_LSTBREAKPOINTS              1020
#define IDC_LBLBREAKPOINTS              1021
#define IDC_TXTEXPRESSION               1022
#define IDC_TXTRESULT                   1023
#define IDC_LBLEXPRESSION               1024
#define IDC_LBLRESULT                   1025
#define IDM_DEBUG_GO                    30000
#define IDM_DEBUG_START                 30001
#define IDM_DEBUG_STOPDEBUGGING         30002
#define IDM_DEBUG_STEPINTO              30003
#define IDM_DEBUG_STEPOVER              30004
#define IDM_DEBUG_STEPOUT               30005
#define IDM_DEBUG_BREAK                 30006
#define IDM_FILE_LOADSCRIPT             40001
#define IDM_FILE_EXIT                   40003
#define IDM_VIEW_TOOLWINDOW             50000
#define IDM_VIEW_DEBUG_VARIABLES        50001
#define IDM_VIEW_DEBUG_CALLSTACK        50002
#define IDM_VIEW_DEBUG_IMMEDIATEWINDOW  50003

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        103
#define _APS_NEXT_COMMAND_VALUE         40100
#define _APS_NEXT_CONTROL_VALUE         1002
#define _APS_NEXT_SYMED_VALUE           104
#endif
#endif
