#ifndef TRACEWIN_H
#define TRACEWIN_H

extern void	traceCloseWindow(void);
void traceNewline(void);
extern void traceShowWStr(LPCOLESTR, DWORD);

#endif