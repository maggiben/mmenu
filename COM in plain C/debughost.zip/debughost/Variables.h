#ifndef _VARIABLES_H_
#define _VARIABLES_H_

extern void		updateVariables(void);
extern void		initVariables(void);
extern void *	initVariablesWindow(void);
extern void		freeVariables(void);
extern HWND		onViewVariables(void);

#endif