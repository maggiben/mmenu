#ifdef __cplusplus
extern "C" {
#endif

#include <activdbg.h>

// Functions
extern HRESULT	getITypeInfoFromExe(const GUID *, ITypeInfo **); 
extern void		display_COM_error(LPCTSTR, HRESULT);
void			display_sys_error(DWORD);
extern int		chooseEngineDlg(GUID *);

// Global variables
extern HINSTANCE						InstanceHandle;
extern HWND								MainFrameWindow;
extern HWND								MainWindow;
extern const TCHAR						ErrorStr[];
extern const WCHAR						AppName[];
extern HFONT							FontHandle;
extern DWORD							DebugLine;
extern IRemoteDebugApplicationThread	*RemoteDebugApplicationThread;
extern IActiveScript					*EngineActiveScript;

#ifdef __cplusplus
}
#endif
