// Presents a window containing all of the script "function levels"
// that are currently running. This implements a "Call stack" display.

#include <windows.h>
#include <tchar.h>
#include <objbase.h>
#include <comcat.h>
#include <activscp.h>
#include <activdbg.h>
#include "Resource.h"
#include "Extern.h"
#include "DockWnd.h"





static HWND			CallStackFrame;
static DOCKINFO		*CallStackDockInfo;
static const TCHAR	CallStackClass[] = "Call stack";
static const TCHAR	ListClass[] = "Listbox";





/*********************** updateCallStack() ************************
 * Updates the contents of the Callstack window.
 */

void updateCallStack(void) 
{
	if (CallStackFrame)
	{
		register HWND		child;

		child = CallStackDockInfo->focusWindow;
		SendMessage(child, LB_RESETCONTENT, 0, 0);

		// If we're paused at a breakpoint, we can update the contents
		if (RemoteDebugApplicationThread)
		{
			BSTR						functionName;
			IEnumDebugStackFrames		*stackFrameEnum;
			DebugStackFrameDescriptor	stackFrame;
			ULONG						numFetched;

			if (!RemoteDebugApplicationThread->lpVtbl->EnumStackFrames(RemoteDebugApplicationThread, &stackFrameEnum))
			{
				stackFrameEnum->lpVtbl->Reset(stackFrameEnum);

				while (stackFrameEnum->lpVtbl->Next(stackFrameEnum, 1, &stackFrame, &numFetched) == S_OK)
				{
					// Get the description of the function from the call stack. NOTE: Passing a 1 means
					// that variable information should also be returned if possible
					if (!stackFrame.pdsf->lpVtbl->GetDescriptionString(stackFrame.pdsf, 1, &functionName))
					{
						SendMessageW(child, LB_ADDSTRING, 0, (LPARAM)functionName);

						// We need to manually clean up all parameters returned from
						// stack frame descriptor
						SysFreeString(functionName);
					}

					stackFrame.pdsf->lpVtbl->Release(stackFrame.pdsf);
				}

				stackFrameEnum->lpVtbl->Release(stackFrameEnum);
			}
		}
	}
}









////////////////////////////////////////////////////////////////////////
// Initialization.
////////////////////////////////////////////////////////////////////////

/********************* callstackClose() ********************
 * Called when Call stack window is closing.
 */

static void WINAPI callstackClose(DOCKINFO *dwp)
{
	CallStackFrame = 0;
}

/***************** createCallStackWindow() ****************
 * Creates the Call stack (dockable) window, with a LISTBOX
 * that fills the window.
 *
 * RETURNS: Docking frame if success, or 0 if failure.
 */

static HWND createCallStackWindow(void) 
{
	// Create a Docking Frame window
	if ((CallStackFrame = DockingCreateFrame(CallStackDockInfo, MainFrameWindow, &CallStackClass[0])))
	{
		// Create a "Call stack" window. This window will be hosted inside
		// of the Docking Frame window (ie, the contents of the docking window's
		// client area). Save it in the DOCKWND
		if ((CallStackDockInfo->focusWindow = CreateWindow(&ListClass[0], 0,
			WS_CHILD|WS_VISIBLE|WS_BORDER,
			0, 0, 0, 0, CallStackFrame, (HMENU)IDD_CALLSTACK, InstanceHandle, 0)))
		{
			SendMessage(CallStackDockInfo->focusWindow, WM_SETFONT, (WPARAM)FontHandle, 0);

			updateCallStack();

			// Show the docking frame
			DockingShowFrame(CallStackDockInfo);

			return(CallStackFrame);
		}

		DestroyWindow(CallStackFrame);	// calls callstackClose()
	}

//	show_custom_errmsg(IDS_BADWINDOW);
	return(0);
}

/************************ initCallStack() **************************
 * Called once at start of program to initialize Call stack stuff.
 */

void initCallStack(void)
{
	CallStackFrame = CallStackDockInfo = 0;
}

/*********************** initCallStackWindow() **********************
 * Called once at start of program to register the Call stack
 * window class.
 */

void * initCallStackWindow(void)
{
	// Allocate a DOCKINFO struct
	if ((CallStackDockInfo = DockingAlloc(DWS_DOCKED_RIGHT)))
	{
		CallStackDockInfo->DockDestroy = callstackClose;

		CallStackDockInfo->nDockedSize = 200;

		// Get Positions from the registry
//		loadWindowSettings((unsigned char *)&CallStackDockInfo->xpos, &CallStackClass[0], &CallStackDockInfo->uDockedState);
	}

	return(CallStackDockInfo);
}

/************************ freeCallStack() *********************
 * Called once at end of program to free the Call stack
 * resources.
 */

void freeCallStack(void)
{
	if (CallStackDockInfo)
	{
		// If the DOCKINFO was used at least once, then save the
		// final window position/state to the registry
//		saveWindowSettings((unsigned char *)&CallStackDockInfo->xpos, &CallStackClass[0], CallStackDockInfo->uDockedState);

		// Free the DOCKINFO
		DockingFree(CallStackDockInfo);
	}
}

/************************* onViewCallstack() ************************
 * Toggles display of the Call stack window.
 */

HWND onViewCallstack(void)
{
	// Create/show it?
	if (!CallStackFrame)
		createCallStackWindow();
	else
	{
		// If the window is free floating, just bring it to the front
		if ((CallStackDockInfo->uDockedState & DWS_FLOATING) && (CallStackDockInfo->dwStyle & DWS_FREEFLOAT))
			SetWindowPos(CallStackFrame, HWND_TOP, 0, 0, 0, 0, SWP_NOMOVE|SWP_NOSIZE);
		else
			DestroyWindow(CallStackFrame);	// calls callstackClose()
	}

	return(CallStackFrame);
}
