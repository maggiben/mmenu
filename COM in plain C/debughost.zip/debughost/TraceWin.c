// Implements displaying text to our a window containing an EDIT control
// just like it was a console window.

#include <windows.h>
#include <tchar.h>
#include "tracewin.h"
#include "extern.h"

static HWND				TraceWindow = 0;
static HWND				EditWindow;

static const TCHAR		DebugWndClass[] = _T("TraceWin");
static const TCHAR		NewLine[] = _T("\r\n");





static LRESULT CALLBACK debugTraceWndProc(HWND hwnd, UINT uMsg, WPARAM wparam, LPARAM lparam)
{
	switch (uMsg)
	{
		case WM_CREATE:
		{
			if (!(EditWindow = CreateWindow("EDIT", 0, WS_CHILD|WS_VISIBLE|WS_VSCROLL|ES_LEFT|ES_MULTILINE|ES_AUTOVSCROLL|ES_READONLY,
					0, 0, 0, 0, hwnd, (HMENU)1000, (HINSTANCE)GetWindowLong(hwnd, GWL_HINSTANCE), 0)))
			{
				return(-1);
			}

			SendMessage(EditWindow, WM_SETFONT, (LPARAM)FontHandle, 0);
			break;
		}

		case WM_SIZE:
			MoveWindow(EditWindow, 0, 0, LOWORD(lparam), HIWORD(lparam), TRUE);
			break;

		case WM_SETFOCUS:
			SetFocus(EditWindow);
			break;

		case WM_DESTROY:
			TraceWindow = 0;

		default:
			return(DefWindowProc(hwnd, uMsg, wparam, lparam));
	}

	return(0);
}





void traceCloseWindow(void)
{
	MSG			msg;

	if (TraceWindow)
	{
		while (TraceWindow && PeekMessage(&msg, 0, 0, 0, PM_REMOVE))
		{
			TranslateMessage(&msg);
			DispatchMessage(&msg); 
		}

		UnregisterClass(&DebugWndClass[0], GetModuleHandle(0));
	}
}





HWND traceOpenWindow(HWND parent)
{
	WNDCLASS	wc;

	if (!TraceWindow)
	{
		ZeroMemory(&wc, sizeof(WNDCLASS));
		wc.style = CS_HREDRAW|CS_VREDRAW;
		wc.lpfnWndProc = debugTraceWndProc;
		wc.hInstance = GetModuleHandle(0);
		wc.hCursor = LoadCursor(0, MAKEINTRESOURCE(IDC_ARROW));
		wc.hbrBackground = (HBRUSH)(COLOR_WINDOW + 1);
		wc.lpszClassName = &DebugWndClass[0];

		// Make a window class instance for the window we want to create
		if (RegisterClass(&wc))
		{
			// Create window of default size
			if ((TraceWindow = CreateWindow(&DebugWndClass[0], "Script Output Window", WS_OVERLAPPEDWINDOW|WS_VISIBLE, 
				10, 10, 300, 400, parent, 0, wc.hInstance, 0)))
			{
				// Update and show window
				ShowWindow(TraceWindow, SW_SHOW);
				UpdateWindow(TraceWindow);
			}
		}
	}

	return(TraceWindow);
}





void traceNewline(void)
{
	if (TraceWindow || traceOpenWindow(0))
	{
		SendMessage(EditWindow, EM_REPLACESEL, 0, (LPARAM)&NewLine[0]);
		SendMessage(EditWindow, EM_SETSEL, (WPARAM)-1, -1);
	}
}





void traceShowWStr(LPCOLESTR pwzParam, DWORD nl)
{
	TCHAR			buffer[256];

	if (TraceWindow || traceOpenWindow(0))
	{
	#ifndef UNICODE
		WideCharToMultiByte(CP_ACP, 0, pwzParam, -1, &buffer[0], sizeof(buffer), 0, 0);
		SendMessage(EditWindow, EM_REPLACESEL, 0, (LPARAM)&buffer[0]);
	#else
		SendMessage(EditWindow, EM_REPLACESEL, 0, (LPARAM)pwzParam);
	#endif

		if (nl)
		{
			SendMessage(EditWindow, EM_SETSEL, (WPARAM)-1, -1);
			traceNewline();
		}
	}
}
