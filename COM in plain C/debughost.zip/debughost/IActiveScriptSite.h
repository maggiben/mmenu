#ifndef _HOSTSITE_H
#define _HOSTSITE_H

// The definition of our MyRealIActiveScriptSite multiple interface
// object. It has an IActiveScriptSite object as the base object,
// and an IActiveScriptSiteWindow sub-object. It also adds an IApp
// object to any script it runs. The script refers to this object
// using the name "application".

#ifdef __cplusplus
extern "C" {
#endif

#include <activdbg.h>

// My MyRealIActiveScriptSite object wraps my IActiveScriptSite, and
// a couple other of its subobjects. It also wraps the IDispatch for
// our own functions that a script may call.
typedef struct {
	IActiveScriptSite			site;				// The IActiveScriptSite must be the base object.
	IActiveScriptSiteWindow		siteWnd;			// Our IActiveScriptSiteWindow sub-object for this IActiveScriptSite.
	IActiveScriptSiteDebug		siteDebug;			// Our IActiveScriptSiteDebug sub-object for this IActiveScriptSite.
	IApplicationDebugger		appDebug;			// Our IApplicationDebugger sub-object for this IActiveScriptSite.
	IApplicationDebuggerUI		appDebugUI;			// Our IApplicationDebuggerUI sub-object for this IActiveScriptSite.
	IProcessDebugManager		*iProcDebugManager;	// Pointer to Microsoft's PDM object.
	IDebugApplication			*iDebugApplication;	// Pointer to a default IDebugApplication we get from MS' PDM.
	ULONG						count;				// Reference count.
} MyRealIActiveScriptSite;

// To maintain a linked list of BreakPoints
typedef struct _MYBREAKPOINT {
	struct _MYBREAKPOINT	*Next;
	DWORD					LineNum;
} MYBREAKPOINT;

// Here's the definition of my MyRealIDebugDocument object, It
// wraps several objects we need for debugging. There is one of
// there allocated for each script we load/debug
typedef struct {
	IDebugDocumentTextAuthor textAuthor;			// Our IDebugDocumentTextAuthor. Must be first.
	IDebugDocumentContext	context;				// Our IDebugDocumentContext.
	ULONG					count;					// Reference count.
	WCHAR					*ScriptText;			// Pointer to a buffer containing our nul-terminated UNICODE script source code.
	DWORD					ScriptSize;				// Size (in WCHARs) of the source.
	WCHAR					*ScriptStart;			// WCHAR currently at the top of the editor window.
	DWORD					StartLineNum;			// Line number currently at the top of the editor window.
	MYBREAKPOINT			*BreakPoints;			// A linked list of break points.
	GUID					GuidBuffer;				// The GUID of the engine used to run this script.
	DWORD					Offset;					// Used to keep a current offset of where we are currently debugging within the script.
	unsigned short			Flags;					// See below.
	WCHAR					Filename[MAX_PATH];		// Full, nul-terminated pathname of the script.
} MyRealIDebugDocument;

// For MyRealIDebugDocument's Flags
#define DOCHOST_LASTLINEHIT		0x0001
#define DOCHOST_GOTGUID			0x0002
#define DOCHOST_INITIALBREAK	0x0004
#define DOCHOST_RUNNING			0x0008

extern BOOL initActiveScriptSite(MyRealIActiveScriptSite *);
extern void freeActiveScriptSite(MyRealIActiveScriptSite *);
extern MyRealIDebugDocument * allocIDebugDocument(MyRealIActiveScriptSite *);

#ifdef __cplusplus
}
#endif

#endif