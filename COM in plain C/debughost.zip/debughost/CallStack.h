#ifndef _CALLSTACK_H_
#define _CALLSTACK_H_

extern void		updateCallStack(void);
extern void		initCallStack(void);
extern void *	initCallStackWindow(void);
extern void		freeCallStack(void);
extern HWND		onViewCallstack(void);

#endif