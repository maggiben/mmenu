// TestXmlTreeViewView.cpp : implementation of the CTestXmlTreeViewView class
//

#include "stdafx.h"
#include "TestXmlTreeView.h"

#include "TestXmlTreeViewDoc.h"
#include "TestXmlTreeViewView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CTestXmlTreeViewView

IMPLEMENT_DYNCREATE(CTestXmlTreeViewView, CXmlTreeView)

BEGIN_MESSAGE_MAP(CTestXmlTreeViewView, CXmlTreeView)
	//{{AFX_MSG_MAP(CTestXmlTreeViewView)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG_MAP
	// Standard printing commands
	ON_COMMAND(ID_FILE_PRINT, CXmlTreeView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_DIRECT, CXmlTreeView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_PREVIEW, CXmlTreeView::OnFilePrintPreview)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CTestXmlTreeViewView construction/destruction

CTestXmlTreeViewView::CTestXmlTreeViewView()
{
	// TODO: add construction code here

}

CTestXmlTreeViewView::~CTestXmlTreeViewView()
{
}

BOOL CTestXmlTreeViewView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return CXmlTreeView::PreCreateWindow(cs);
}

/////////////////////////////////////////////////////////////////////////////
// CTestXmlTreeViewView drawing

void CTestXmlTreeViewView::OnDraw(CDC* pDC)
{
	CTestXmlTreeViewDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	// TODO: add draw code for native data here
}

void CTestXmlTreeViewView::OnInitialUpdate()
{
	CXmlTreeView::OnInitialUpdate();


	// TODO: You may populate your TreeView with items by directly accessing
	//  its tree control through a call to GetTreeCtrl().
}

/////////////////////////////////////////////////////////////////////////////
// CTestXmlTreeViewView printing

BOOL CTestXmlTreeViewView::OnPreparePrinting(CPrintInfo* pInfo)
{
	// default preparation
	return DoPreparePrinting(pInfo);
}

void CTestXmlTreeViewView::OnBeginPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add extra initialization before printing
}

void CTestXmlTreeViewView::OnEndPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add cleanup after printing
}

/////////////////////////////////////////////////////////////////////////////
// CTestXmlTreeViewView diagnostics

#ifdef _DEBUG
void CTestXmlTreeViewView::AssertValid() const
{
	CXmlTreeView::AssertValid();
}

void CTestXmlTreeViewView::Dump(CDumpContext& dc) const
{
	CXmlTreeView::Dump(dc);
}

CTestXmlTreeViewDoc* CTestXmlTreeViewView::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CTestXmlTreeViewDoc)));
	return (CTestXmlTreeViewDoc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CTestXmlTreeViewView message handlers

CTestXmlTreeViewView* CTestXmlTreeViewView::GetView()
{
    CFrameWnd * pFrame = (CFrameWnd *)(AfxGetApp()->m_pMainWnd);
    
    CView * pView = pFrame->GetActiveView();
    
    if ( !pView )
        return NULL;
    
    // Fail if view is of wrong kind
    // (this could occur with splitter windows, or additional
    // views on a single document
    if ( ! pView->IsKindOf( RUNTIME_CLASS(CTestXmlTreeViewView) ) )
        return NULL;
    
    return (CTestXmlTreeViewView *) pView;
}
