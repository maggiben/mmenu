//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by AnalyzeIE.rc
//
#define IDS_PROJNAME                    100
#define IDR_DOMPEEK                     101
#define IDD_ABOUTBOX                    102
#define IDR_CMDDICPATCH                 103
#define IDR_CMDDISPATCH                 104
#define IDR_MAINFRAME                   128
#define IDD_MAINDLG                     129
#define IDB_TREE1                       201
#define IDR_TREECONTEXTMENU             202
#define IDI_IESPY                       203
#define IDI_IESPYHOT                    204
#define IDC_TREE1                       1000
#define IDC_EXPANDALL                   1002
#define IDM_EXPANDALL                   32768
#define IDM_COLLAPSEALL                 32769

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        205
#define _APS_NEXT_COMMAND_VALUE         32770
#define _APS_NEXT_CONTROL_VALUE         1003
#define _APS_NEXT_SYMED_VALUE           105
#endif
#endif
