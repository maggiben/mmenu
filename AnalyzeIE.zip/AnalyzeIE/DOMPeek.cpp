// DOMPeek.cpp : Implementation of CDOMPeek
#include "stdafx.h"
#include "AnalyzeIE.h"
#include "DOMPeek.h"
#include "maindlg.h"

IStream* g_pIStream = NULL; // stream to (un)marshall interface pointer

/////////////////////////////////////////////////////////////////////////////
// CDOMPeek

// IDOMPeek

STDMETHODIMP CDOMPeek::get_DialogDisplay(BOOL *pVal)
{
	*pVal = IsDialogDisplayed() ? TRUE : FALSE;
	return S_OK;
}

STDMETHODIMP CDOMPeek::put_DialogDisplay(BOOL newVal)
{
	return SetDialogDisplayed( newVal ? true : false) ? S_OK : E_FAIL; 
}

// IObjectWithSite 

STDMETHODIMP CDOMPeek::SetSite(IUnknown *pUnkSite)
{
	HRESULT hr = IObjectWithSiteImpl<CDOMPeek>::SetSite( pUnkSite); // let base class handle it
	if ( SUCCEEDED( hr))
		m_spWebBrowser2 = m_spUnkSite; // m_spUnkSite is base class member
	else
		return hr;
	if ( !m_spWebBrowser2)
		return E_INVALIDARG;

	if ( SUCCEEDED( g_pGIT->RegisterInterfaceInGlobal( GetUnknown(), IID_IDOMPeek, &m_GITCookie)))
	{
		if ( SUCCEEDED( DispEventAdvise( m_spUnkSite)))
			_Module.m_pObjectArray->Add( m_GITCookie);
		else
			hr = g_pGIT->RevokeInterfaceFromGlobal( m_GITCookie);
	}
	return S_OK;
}

// DWebBrowserEvents2 - only download complete and quit events are handled at this time

STDMETHODIMP CDOMPeek::OnQuit()
{
	HRESULT hr = g_pGIT->RevokeInterfaceFromGlobal( m_GITCookie);
	_Module.m_pObjectArray->Remove( m_GITCookie);
	ATLASSERT( SUCCEEDED(hr));
	hr = DispEventUnadvise( m_spUnkSite);
	ATLASSERT( SUCCEEDED(hr));
	m_DocDlg.CloseDialog();
	return S_OK;
}

STDMETHODIMP CDOMPeek::DocumentComplete( IDispatch * pDisp, VARIANT * URL )
{
	HRESULT hr = S_OK;

	// This is document in frame if pDisp is not the same as IDispatch of IWebBrowser2
	// Only the top level frame IDispatch is the same as IDispatch from IWebBrowser2
	CComQIPtr<IDispatch> spDispatch = m_spWebBrowser2;
	bool bFrame = spDispatch != pDisp;

	// Do not display a dialog for each frame but only for the top frame
	if ( !bFrame)
	{
		// display the dialog only if current document supports IHTMLDocument2
		CComPtr<IDispatch> spDispatch;
		if ( SUCCEEDED( m_spWebBrowser2->get_Document( &spDispatch)))
		{
			m_spDoc2 = spDispatch;

			// if this is HTML and global flag for dialog display is set
			// then display new or refresh existing dialog
			if ( m_spDoc2 != NULL && _Module.IsShowDialog()) 
			{
				if ( !IsDialogDisplayed())
					StartNewDialog();
				else
				{
					ATLASSERT( g_pIStream == NULL);
					// see the comments below regarding this call for marshalling
					if ( SUCCEEDED( CoMarshalInterThreadInterfaceInStream( MSHTML::IID_IHTMLDocument2, m_spDoc2, &g_pIStream)))
						m_DocDlg.PostDOMUpdateMessage();
				}
			}
			else // no support for other documents or flag is set not to display the dialog
				m_DocDlg.CloseDialog();
		}
	}
	return hr;
}

bool CDOMPeek::StartNewDialog()
{
	USES_CONVERSION;
	if ( !m_spDoc2) // document download has not completed yet
	{
		CComPtr<IDispatch> spDispatch;
		if ( SUCCEEDED( m_spWebBrowser2->get_Document( &spDispatch)))
		{
			m_spDoc2 = spDispatch;
			if ( !m_spDoc2)// not a HTML document
				return false;
		}
		else
			return false;
	}

	// Check if document is complete - this is required since StartNewDialog can be
	// invoked when user clicks IE Extension button and there are no guarantees 
	// that document download will be complete at that time.

	CComBSTR bstrstate;
	m_spDoc2->get_readyState( &bstrstate);
	if ( lstrcmpi( W2T( bstrstate), _T("complete")))
		return false;

	// Marshalling call is not required since we are in the same thread. However, I'll keep it in the case
	// that dialog management code starts using additional thread. Within the same thread
	// we will get back the same pointer, so the overhead of this and unmarshalling call is negligible.
	// Altogether, we are using global variable g_pIStream to make IID_IHTMLDocument2 pointer
	// available to treeview when WM_INITDIALOG is called or when DOM display is updated.

	ATLASSERT( g_pIStream == NULL);
	if ( FAILED( CoMarshalInterThreadInterfaceInStream( MSHTML::IID_IHTMLDocument2, m_spDoc2, &g_pIStream)))
		return false;

	// plug our dialog into browser window
	HWND hwnd = NULL;
	if ( FAILED( m_spWebBrowser2->get_HWND( reinterpret_cast<long*>(&hwnd))))
		hwnd = ::GetActiveWindow();

	if ( m_DocDlg.Create( hwnd))
	{
		m_DocDlg.ShowWindow( SW_NORMAL);
		return true;
	}
	else
		return false;
}
