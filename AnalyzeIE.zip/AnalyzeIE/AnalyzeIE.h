/* this ALWAYS GENERATED file contains the definitions for the interfaces */


/* File created by MIDL compiler version 5.01.0164 */
/* at Thu Dec 06 20:38:48 2001
 */
/* Compiler settings for C:\dev\IE spy\AnalyzeIE\AnalyzeIE.idl:
    Oicf (OptLev=i2), W1, Zp8, env=Win32, ms_ext, c_ext
    error checks: allocation ref bounds_check enum stub_data 
*/
//@@MIDL_FILE_HEADING(  )


/* verify that the <rpcndr.h> version is high enough to compile this file*/
#ifndef __REQUIRED_RPCNDR_H_VERSION__
#define __REQUIRED_RPCNDR_H_VERSION__ 440
#endif

#include "rpc.h"
#include "rpcndr.h"

#ifndef __RPCNDR_H_VERSION__
#error this stub requires an updated version of <rpcndr.h>
#endif // __RPCNDR_H_VERSION__

#ifndef COM_NO_WINDOWS_H
#include "windows.h"
#include "ole2.h"
#endif /*COM_NO_WINDOWS_H*/

#ifndef __AnalyzeIE_h__
#define __AnalyzeIE_h__

#ifdef __cplusplus
extern "C"{
#endif 

/* Forward Declarations */ 

#ifndef __IDOMPeek_FWD_DEFINED__
#define __IDOMPeek_FWD_DEFINED__
typedef interface IDOMPeek IDOMPeek;
#endif 	/* __IDOMPeek_FWD_DEFINED__ */


#ifndef __DOMPeek_FWD_DEFINED__
#define __DOMPeek_FWD_DEFINED__

#ifdef __cplusplus
typedef class DOMPeek DOMPeek;
#else
typedef struct DOMPeek DOMPeek;
#endif /* __cplusplus */

#endif 	/* __DOMPeek_FWD_DEFINED__ */


#ifndef __ICmdDispatch_FWD_DEFINED__
#define __ICmdDispatch_FWD_DEFINED__
typedef interface ICmdDispatch ICmdDispatch;
#endif 	/* __ICmdDispatch_FWD_DEFINED__ */


#ifndef __CmdDispatch_FWD_DEFINED__
#define __CmdDispatch_FWD_DEFINED__

#ifdef __cplusplus
typedef class CmdDispatch CmdDispatch;
#else
typedef struct CmdDispatch CmdDispatch;
#endif /* __cplusplus */

#endif 	/* __CmdDispatch_FWD_DEFINED__ */


/* header files for imported files */
#include "oaidl.h"
#include "ocidl.h"

void __RPC_FAR * __RPC_USER MIDL_user_allocate(size_t);
void __RPC_USER MIDL_user_free( void __RPC_FAR * ); 

#ifndef __IDOMPeek_INTERFACE_DEFINED__
#define __IDOMPeek_INTERFACE_DEFINED__

/* interface IDOMPeek */
/* [unique][helpstring][dual][uuid][object] */ 


EXTERN_C const IID IID_IDOMPeek;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("0B6EF17E-18E5-4449-86EA-64C82D596EAE")
    IDOMPeek : public IDispatch
    {
    public:
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_DialogDisplay( 
            /* [retval][out] */ BOOL __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_DialogDisplay( 
            /* [in] */ BOOL newVal) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct IDOMPeekVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *QueryInterface )( 
            IDOMPeek __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void __RPC_FAR *__RPC_FAR *ppvObject);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *AddRef )( 
            IDOMPeek __RPC_FAR * This);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *Release )( 
            IDOMPeek __RPC_FAR * This);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfoCount )( 
            IDOMPeek __RPC_FAR * This,
            /* [out] */ UINT __RPC_FAR *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfo )( 
            IDOMPeek __RPC_FAR * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo __RPC_FAR *__RPC_FAR *ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetIDsOfNames )( 
            IDOMPeek __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR __RPC_FAR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID __RPC_FAR *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Invoke )( 
            IDOMPeek __RPC_FAR * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS __RPC_FAR *pDispParams,
            /* [out] */ VARIANT __RPC_FAR *pVarResult,
            /* [out] */ EXCEPINFO __RPC_FAR *pExcepInfo,
            /* [out] */ UINT __RPC_FAR *puArgErr);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_DialogDisplay )( 
            IDOMPeek __RPC_FAR * This,
            /* [retval][out] */ BOOL __RPC_FAR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_DialogDisplay )( 
            IDOMPeek __RPC_FAR * This,
            /* [in] */ BOOL newVal);
        
        END_INTERFACE
    } IDOMPeekVtbl;

    interface IDOMPeek
    {
        CONST_VTBL struct IDOMPeekVtbl __RPC_FAR *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IDOMPeek_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define IDOMPeek_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define IDOMPeek_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define IDOMPeek_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define IDOMPeek_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define IDOMPeek_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define IDOMPeek_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)


#define IDOMPeek_get_DialogDisplay(This,pVal)	\
    (This)->lpVtbl -> get_DialogDisplay(This,pVal)

#define IDOMPeek_put_DialogDisplay(This,newVal)	\
    (This)->lpVtbl -> put_DialogDisplay(This,newVal)

#endif /* COBJMACROS */


#endif 	/* C style interface */



/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IDOMPeek_get_DialogDisplay_Proxy( 
    IDOMPeek __RPC_FAR * This,
    /* [retval][out] */ BOOL __RPC_FAR *pVal);


void __RPC_STUB IDOMPeek_get_DialogDisplay_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IDOMPeek_put_DialogDisplay_Proxy( 
    IDOMPeek __RPC_FAR * This,
    /* [in] */ BOOL newVal);


void __RPC_STUB IDOMPeek_put_DialogDisplay_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __IDOMPeek_INTERFACE_DEFINED__ */



#ifndef __ANALYZEIELib_LIBRARY_DEFINED__
#define __ANALYZEIELib_LIBRARY_DEFINED__

/* library ANALYZEIELib */
/* [helpstring][version][uuid] */ 


EXTERN_C const IID LIBID_ANALYZEIELib;

EXTERN_C const CLSID CLSID_DOMPeek;

#ifdef __cplusplus

class DECLSPEC_UUID("834261E1-DD97-4177-853B-C907E5D5BD6E")
DOMPeek;
#endif

#ifndef __ICmdDispatch_INTERFACE_DEFINED__
#define __ICmdDispatch_INTERFACE_DEFINED__

/* interface ICmdDispatch */
/* [unique][helpstring][uuid][object] */ 


EXTERN_C const IID IID_ICmdDispatch;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("39334DA8-9B2A-497D-AF7A-22E239552967")
    ICmdDispatch : public IUnknown
    {
    public:
    };
    
#else 	/* C style interface */

    typedef struct ICmdDispatchVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *QueryInterface )( 
            ICmdDispatch __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void __RPC_FAR *__RPC_FAR *ppvObject);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *AddRef )( 
            ICmdDispatch __RPC_FAR * This);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *Release )( 
            ICmdDispatch __RPC_FAR * This);
        
        END_INTERFACE
    } ICmdDispatchVtbl;

    interface ICmdDispatch
    {
        CONST_VTBL struct ICmdDispatchVtbl __RPC_FAR *lpVtbl;
    };

    

#ifdef COBJMACROS


#define ICmdDispatch_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define ICmdDispatch_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define ICmdDispatch_Release(This)	\
    (This)->lpVtbl -> Release(This)


#endif /* COBJMACROS */


#endif 	/* C style interface */




#endif 	/* __ICmdDispatch_INTERFACE_DEFINED__ */


EXTERN_C const CLSID CLSID_CmdDispatch;

#ifdef __cplusplus

class DECLSPEC_UUID("0B9BE66E-F413-4EFE-8292-21511186D821")
CmdDispatch;
#endif
#endif /* __ANALYZEIELib_LIBRARY_DEFINED__ */

/* Additional Prototypes for ALL interfaces */

/* end of Additional Prototypes */

#ifdef __cplusplus
}
#endif

#endif
