// maindlg.h : interface of the CMainDlg class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_MAINDLG_H__E0443F76_31D2_4471_B6F6_E0F733D1385E__INCLUDED_)
#define AFX_MAINDLG_H__E0443F76_31D2_4471_B6F6_E0F733D1385E__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000


extern IStream* g_pIStream;

class CMainDlg : public CDialogImpl<CMainDlg>, public CDialogResize<CMainDlg>	
{
public:
	enum { IDD = IDD_MAINDLG };

	#define WM_UPDATEDOM ( WM_APP + 100) // custom message sent to dialog to update DOM tree and its title

	// treeview class 
	class CDOMTree : public CContainedWindowT<CTreeViewCtrl>
	{
	public:
		CDOMTree( CMessageMap* pObject, DWORD dwMsgMapID = 0) : 
		  CContainedWindowT<CTreeViewCtrl>( pObject, dwMsgMapID) {}

		// CDOMTree message handlers

		LRESULT OnTreeDestroy(UINT /*uMsg*/, WPARAM /*wParam*/, LPARAM /*lParam*/, BOOL& /*bHandled*/)
		{
			// We call SetupImageList method here because we are not destroying CDOMTree object
			// even when dialog and its child treeview window are destroyed. It is a member object.
			// So we can not destroy image list in destructor. 
			// DeleteAllItems() makes sure that OnTreeItemDeleted() is invoked for all items
			// which in turn releases interface pointer stored as item data

			SetupImageList( false); // destroys image list - it is not destroyed when window is
			DeleteAllItems();
			m_spDoc2 = NULL;
			return 0;
		}

		LRESULT OnExpandAll(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/, BOOL& /*bHandled*/)
		{
			ExpandAll();
			return 0;
		}
		
		LRESULT OnCollapseAll(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/, BOOL& /*bHandled*/)
		{
			CollapseAll();
			return 0;
		}

		LRESULT OnTreeItemExpanding( int /*idCtrl*/, LPNMHDR pnmh, BOOL& /*bHandled*/);

		LRESULT OnTreeItemExpanded( int /*idCtrl*/, LPNMHDR pnmh, BOOL& /*bHandled*/);
	
		LRESULT OnTreeGetDispInfo( int /*idCtrl*/, LPNMHDR pnmh, BOOL& /*bHandled*/);
		
		LRESULT OnTreeContextMenu(UINT /*uMsg*/, WPARAM wParam, LPARAM lParam, BOOL& bHandled);

		LRESULT OnTreeItemDeleted( int /*idCtrl*/, LPNMHDR pnmh, BOOL& /*bHandled*/);


		// CDOMTree helper methods

		// type of the CDOMTree method that will be called recursively for each node and all of its children
		typedef void (CDOMTree::*FOREACHITEM)(HTREEITEM);
		// flags for calling method on parent node and all of its children
		enum
		{
			// call method on the parent node first, then on its children
			// othwerwise, method is called on children first
			DOPARENTFIRST = 1,
			// don't call a method on topomost parent
			SKIPTOPPARENT = 2
		};

		void UpdateDOM( void); 
		void SetupImageList( bool bSet = true); 
		MSHTML::IHTMLDocument2* GetDocPtr( void) { return (MSHTML::IHTMLDocument2*)m_spDoc2; }

	private:
		bool PrepareDOMTree( void);
		HTREEITEM InsertDOMNode( MSHTML::IHTMLDOMNode* pINode, HTREEITEM hparent, HTREEITEM hinsertAfter);
		void InsertDOMNodeChildren( MSHTML::IHTMLDOMNode* pINode, HTREEITEM hparent);
		HTREEITEM InsertAttributeCollection( MSHTML::IHTMLAttributeCollection* pIAttrColl, HTREEITEM hparent);
		void InsertAttributes( MSHTML::IHTMLAttributeCollection* pIAttrColl, HTREEITEM hparent);
		HTREEITEM InsertAttribute( MSHTML::IHTMLDOMAttribute* pIAttribute, HTREEITEM hparent, HTREEITEM hinsertAfter);
		bool IsAnyAttributeSet( MSHTML::IHTMLAttributeCollection* pIAttrColl); 

		// recursive procedure that will call fp for the item and for all of its children
		void DoForItemAndChildren( HTREEITEM hParent, FOREACHITEM fp, unsigned int flags = 0);

		// ExpandItem method wih FOREACHITEM signature so it can be parameter to DoForItemAndChildren
		void ExpandItem( HTREEITEM hItem) 
		{
			// The following two calls are required to cover one strange bug in treeview. Namely,
			// TVE_COLLAPSE | TVE_COLLAPSERESET flags do not always clear TVIS_EXPANDEDONCE flag
			// as claimed in the documentation. Without SetItemState call, for example, tree root
			// item will always have TVIS_EXPANDEDONCE set, even if Expand( root, TVE_COLLAPSE | TVE_COLLAPSERESET)
			// was called on it right before expanding it.

			if ( ( GetItemState( hItem, 0xFF) & TVIS_EXPANDEDONCE))
			{
				Expand( hItem, TVE_COLLAPSE | TVE_COLLAPSERESET);
				SetItemState( hItem, 0, TVIS_EXPANDED | TVIS_EXPANDEDONCE);
			}

			ATLASSERT( (GetItemState( hItem, 0xFF) & TVIS_EXPANDEDONCE) == 0);
			// this is the only call we would make if documentation was not misleading and/or incomplete
			Expand( hItem);
		}
		void ExpandAll( void);
		void CollapseAll( void);
		void FormatNameAndValue( const CComBSTR& name, const CComVariant& value, TCHAR* pTextResult);

	// members
		CImageList m_ilist;
		CComPtr<MSHTML::IHTMLDocument2> m_spDoc2;
	}; // class CDOMTree


	// Dialog constructor 

	CMainDlg() : m_DOMTree( this, 1) {}

	BEGIN_MSG_MAP(CMainDlg)
		CHAIN_MSG_MAP( CDialogResize<CMainDlg>) 
		NOTIFY_HANDLER(IDC_TREE1, TVN_GETDISPINFO, m_DOMTree.OnTreeGetDispInfo)
		NOTIFY_HANDLER(IDC_TREE1, TVN_ITEMEXPANDING, m_DOMTree.OnTreeItemExpanding) 
		NOTIFY_HANDLER(IDC_TREE1, TVN_ITEMEXPANDED, m_DOMTree.OnTreeItemExpanded) 
		NOTIFY_HANDLER(IDC_TREE1, TVN_DELETEITEM, m_DOMTree.OnTreeItemDeleted) 
		MESSAGE_HANDLER(WM_INITDIALOG, OnInitDialog)
		COMMAND_ID_HANDLER(ID_APP_ABOUT, OnAppAbout)
		COMMAND_ID_HANDLER(IDCANCEL, OnCancel)
		MESSAGE_HANDLER(WM_CONTEXTMENU, m_DOMTree.OnTreeContextMenu)
		MESSAGE_HANDLER(WM_UPDATEDOM, OnUpdateDOM)

		ALT_MSG_MAP(1)   // Handlers for the subclassed tree view control.
			MESSAGE_HANDLER(WM_DESTROY, m_DOMTree.OnTreeDestroy)
			COMMAND_ID_HANDLER(IDM_EXPANDALL, m_DOMTree.OnExpandAll)
			COMMAND_ID_HANDLER(IDM_COLLAPSEALL, m_DOMTree.OnCollapseAll)
	END_MSG_MAP()
		
	BEGIN_DLGRESIZE_MAP(CMainDlg)
		DLGRESIZE_CONTROL( IDC_TREE1, DLSZ_SIZE_X | DLSZ_SIZE_Y)
	END_DLGRESIZE_MAP()

	LRESULT OnInitDialog(UINT /*uMsg*/, WPARAM /*wParam*/, LPARAM /*lParam*/, BOOL& /*bHandled*/)
	{
		m_DOMTree.SubclassWindow( GetDlgItem(IDC_TREE1)); 
		m_DOMTree.SetupImageList();
		m_DOMTree.UpdateDOM();
		SetTitle();

		DlgResize_Init();
		SetWindowText( m_title); 
		// set icons
		HICON hIcon = (HICON)::LoadImage(_Module.GetResourceInstance(), MAKEINTRESOURCE(IDI_IESPY), 
			IMAGE_ICON, ::GetSystemMetrics(SM_CXICON), ::GetSystemMetrics(SM_CYICON), LR_DEFAULTCOLOR);
		SetIcon(hIcon, TRUE);
		HICON hIconSmall = (HICON)::LoadImage(_Module.GetResourceInstance(), MAKEINTRESOURCE(IDI_IESPY), 
			IMAGE_ICON, ::GetSystemMetrics(SM_CXSMICON), ::GetSystemMetrics(SM_CYSMICON), LR_DEFAULTCOLOR);
		SetIcon(hIconSmall, FALSE);

		return TRUE;
	}

	LRESULT OnAppAbout(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/, BOOL& /*bHandled*/)
	{
		CSimpleDialog<IDD_ABOUTBOX, FALSE> dlg;
		dlg.DoModal();
		return 0;
	}

	LRESULT OnCancel(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/, BOOL& bHandled)
	{
		// Dialog is going to be destroyed when we exit this method so it is not
		// required to set the dialog return result. If bHandled were left to its default 
		// value of true BoundsChecker will notice it because dialog window handle may be
		// NULL by the time return result gets set. Result won't get set if message
		// was reported as not handled. This quiets down BoundsChecker.
		bHandled = false;
		CloseDialog();
		return 0;
	}

	LRESULT OnUpdateDOM(UINT /*uMsg*/, WPARAM /*wParam*/, LPARAM /*lParam*/, BOOL& /*bHandled*/)
	{
		m_DOMTree.UpdateDOM();
		SetTitle();
		return 0;
	}

	// CMainDlg helper methods 

	void SetTitle( void) 
	{ 
		CComPtr<MSHTML::IHTMLLocation> spLoc;
		MSHTML::IHTMLDocument2* ptrDoc = m_DOMTree.GetDocPtr();
		m_title[0] = _T('\0');		

		// get the *real* location, not the one displayed in address combo which may be unreachable
		if ( ptrDoc != NULL && SUCCEEDED( ptrDoc->get_location( &spLoc)))
		{
			CComBSTR dochref;

			if ( SUCCEEDED( spLoc->get_href( &dochref)))
			{
				USES_CONVERSION;

				// for some reason SetWindowText won't accept W2T(dochref) pointer so
				// we store current document href, which is dialog's title, in a member
				lstrcpyn( m_title, W2T(dochref), sizeof m_title/sizeof TCHAR);
				m_title[ ( sizeof m_title/sizeof TCHAR) - 1] = _T('\0');		
				if ( IsWindow())
					SetWindowText( m_title); 
			}
		}
	}

	void CloseDialog( void) 
	{ 
		if ( IsWindow()) 
			DestroyWindow(); 
	}
	
	void PostDOMUpdateMessage(void)
	{
		PostMessage( WM_UPDATEDOM);
	}

	// members
private:
	TCHAR m_title[MAX_PATH];
	CDOMTree m_DOMTree;
}; // class CMainDlg


//******************************************************************
//
// Helper methods and message handlers for CDOMTree
//
//******************************************************************


inline void CMainDlg::CDOMTree::UpdateDOM()
{
	SetRedraw( FALSE);
	DeleteAllItems();
	m_spDoc2 = NULL;

	MSHTML::IHTMLDocument2* pDoc = NULL;
	HRESULT hr = CoGetInterfaceAndReleaseStream( g_pIStream, MSHTML::IID_IHTMLDocument2, (void**)&pDoc);
	m_spDoc2 = pDoc;
	g_pIStream = NULL;
	if ( SUCCEEDED( hr) && !!m_spDoc2)
		PrepareDOMTree();
	SetRedraw( TRUE);
}

inline bool CMainDlg::CDOMTree::PrepareDOMTree()
{
	CComQIPtr<MSHTML::IHTMLDocument3, &MSHTML::IID_IHTMLDocument3> spDoc3 = m_spDoc2;
	bool bRet = spDoc3 != NULL;

	if ( bRet)
	{
		CComPtr<MSHTML::IHTMLElement> spRootElement;
		bRet = SUCCEEDED( spDoc3->get_documentElement( &spRootElement));
		if ( bRet)
		{
			CComQIPtr<MSHTML::IHTMLDOMNode> spRootNode = spRootElement;
			bRet = spRootNode != NULL;
			if ( bRet)
				InsertDOMNode( spRootNode, NULL, NULL);
		}
	}
	else
	{
		ATLASSERT(0); // IE 4 does not support IHTMLDocument3
	}
	return bRet;
}

inline void CMainDlg::CDOMTree::SetupImageList( bool bSet /* = true*/) 
{
	if ( bSet)
	{
		if ( m_ilist.CreateFromImage( IDB_TREE1, 24, 0, CLR_DEFAULT, IMAGE_BITMAP))
			SetImageList( m_ilist, TVSIL_NORMAL);
	}
	else
	{
		m_ilist.Destroy(); 
		m_ilist = NULL;
	}
}	

// Find which node are we expanding by checking for particular interface pointer
// stored as node data. Then insert its children. Creating children only on demand,
// like in this case, saves a bit of memory plus we don't need to call all interfaces
// and construct entire tree if it is not going to be entirely expanded.

inline LRESULT CMainDlg::CDOMTree::OnTreeItemExpanding( int /*idCtrl*/, LPNMHDR pnmh, BOOL& /*bHandled*/)
{
	LPNMTREEVIEW pnmtv = reinterpret_cast<LPNMTREEVIEW>(pnmh);
	TVITEM* pItem = &pnmtv->itemNew;
	RECT rc;
	
	if ( !pItem || !pItem->hItem)
		return 1;

	if ( pnmtv->action == TVE_EXPAND)
	{
		// lParam is documented as valid during this notification
		IUnknown* pIface = reinterpret_cast<IUnknown*>(pItem->lParam); 

		CComQIPtr<MSHTML::IHTMLDOMNode> spNode = pIface;
		if ( !!spNode)
			InsertDOMNodeChildren( spNode, pItem->hItem);
		else
		{
			CComQIPtr<MSHTML::IHTMLAttributeCollection> spAttrColl = pIface;
			// if expanding attribute collection this is the time to add attributes
			if ( !!spAttrColl)  
				InsertAttributes( spAttrColl, pItem->hItem);
			else
				ATLASSERT(0); // something strange here
	
		}
	}

	// Cause a call to OnTreeGetDispInfo which will take
	// care of displaying correct, i.e. expanded or collapsed node bitmap.
	// It is neccessary to handle this message since double-click,
	// which will expand or collapse the item, will not necesarily 
	// redisplay the item by calling OnTreeGetDispInfo
	
	if ( GetItemRect( pItem->hItem, &rc, FALSE))
		InvalidateRect( &rc);
	return 0;
}

// Here we delete collapsing node's children
inline LRESULT CMainDlg::CDOMTree::OnTreeItemExpanded( int /*idCtrl*/, LPNMHDR pnmh, BOOL& /*bHandled*/)
{
	LPNMTREEVIEW pnmtv = reinterpret_cast<LPNMTREEVIEW>(pnmh);

	if ( pnmtv->action & TVE_COLLAPSE)
	{
		TVITEM* pItem = &pnmtv->itemNew;
	
		if ( !pItem || !pItem->hItem)
			return 0;

		Expand( pItem->hItem, TVE_COLLAPSE | TVE_COLLAPSERESET);
		// TVE_COLLAPSERESET should clear TVIS_EXPANDEDONCE if it was set
		ATLASSERT( (GetItemState( pItem->hItem, 0xFF) & TVIS_EXPANDEDONCE) == 0);
	}
	return 0;
}

// DOM treeview display procedure. Finds the interface stored under tree item data and figures
// out what text and bitmap indices should be used for that interface

inline LRESULT CMainDlg::CDOMTree::OnTreeGetDispInfo( int /*idCtrl*/, LPNMHDR pnmh, BOOL& /*bHandled*/)
{
	USES_CONVERSION;
	LPNMTVDISPINFO lptvdi = reinterpret_cast<LPNMTVDISPINFO>(pnmh); 
	DWORD_PTR data = GetItemData( lptvdi->item.hItem);
	IUnknown* pIface = reinterpret_cast<IUnknown*>(data);
	static TCHAR itemtext[4096]; // not so good - should check for node type and call method to get text length
	
	if ( pIface == NULL)
		return 0;
	
	CComQIPtr<MSHTML::IHTMLDOMNode> spNode = pIface;
	if ( !spNode) // not a node, may be attribute collection
	{
		CComQIPtr<MSHTML::IHTMLAttributeCollection> spAttrColl = pIface;
		if ( !spAttrColl) // may be attribute itself
		{
			CComQIPtr<MSHTML::IHTMLDOMAttribute> spAttr = pIface;
			if ( !!spAttr)
			{
				if ( ( lptvdi->item.mask & TVIF_IMAGE) || ( lptvdi->item.mask & TVIF_SELECTEDIMAGE))
				{
					int imageidx = 8;
					lptvdi->item.iImage = lptvdi->item.iSelectedImage = imageidx;
				}

				if ( lptvdi->item.mask & TVIF_TEXT)
				{
					CComBSTR name;
					CComVariant value;
					
					spAttr->get_nodeName( &name);
					spAttr->get_nodeValue( &value); 
					FormatNameAndValue( name, value, itemtext);
					lptvdi->item.pszText = itemtext;
					lptvdi->item.cchTextMax = lstrlen( itemtext);
				}
			}
		}
		else
		{
			if ( ( lptvdi->item.mask & TVIF_IMAGE) || ( lptvdi->item.mask & TVIF_SELECTEDIMAGE))
			{
				bool bExpanded =  ( GetItemState( lptvdi->item.hItem, 0xFF) & TVIS_EXPANDED) != 0;
				int imageidx = 6;
				lptvdi->item.iImage = bExpanded ? ( imageidx + 1) : imageidx;
				lptvdi->item.iSelectedImage = lptvdi->item.iImage;
			}
			if ( lptvdi->item.mask & TVIF_TEXT)
			{
				static LPTSTR strAttributeCollectionTitle = _T("Attributes");
				lptvdi->item.pszText = strAttributeCollectionTitle;
				lptvdi->item.cchTextMax = lstrlen( strAttributeCollectionTitle);
			}
		}
	}
	else // this is a text, comment or element node
	{
		long type; //  1 == ELEMENT - no enum for node types in MSHTML headers ( 3 is text and 8 is comment)
		
		if ( FAILED(spNode->get_nodeType( &type)))
			return 0;
		
		ATLASSERT( type == 1 || type == 3 || type == 8);
		
		if ( ( lptvdi->item.mask & TVIF_IMAGE) || ( lptvdi->item.mask & TVIF_SELECTEDIMAGE))
		{
			bool bExpanded =  ( GetItemState( lptvdi->item.hItem, 0xFF) & TVIS_EXPANDED) != 0;
			int imageidx = type == 1 ? 0 : ( type == 8 ? 4 : 2);
			lptvdi->item.iImage = bExpanded ? ( imageidx + 1) : imageidx;
			lptvdi->item.iSelectedImage = lptvdi->item.iImage;
		}
		
		if ( lptvdi->item.mask & TVIF_TEXT)
		{
			CComBSTR name;
			CComVariant value;
			
			spNode->get_nodeName( &name);
			if ( type != 1)
				spNode->get_nodeValue( &value); // elements never have a value
			FormatNameAndValue( name, value, itemtext);
			lptvdi->item.pszText = itemtext;
			lptvdi->item.cchTextMax = lstrlen( itemtext);
		}
	}
	return 0;
}

// context menu allows us to expand or collapse entire tree (all its children, children's children tec.)
// for selected item,

inline LRESULT CMainDlg::CDOMTree::OnTreeContextMenu(UINT /*uMsg*/, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
{
	if ( HWND(wParam) != m_hWnd) // handle it only in this control
		return 0;
	
	int x = GET_X_LPARAM(lParam); 
	int y = GET_Y_LPARAM(lParam); 
	CMenu popup, context;
	popup.LoadMenu( IDR_TREECONTEXTMENU);
	context = popup.GetSubMenu(0);
	context.TrackPopupMenu( TPM_LEFTALIGN | TPM_LEFTBUTTON | TPM_RIGHTBUTTON, x, y, HWND(wParam));
	bHandled = TRUE;
	return 0;
}

// release interface pointer when tree item is deleted
inline LRESULT CMainDlg::CDOMTree::OnTreeItemDeleted( int /*idCtrl*/, LPNMHDR pnmh, BOOL& /*bHandled*/)
{
	LPNMTREEVIEW pnmtv = reinterpret_cast<LPNMTREEVIEW>(pnmh);
	TVITEM* pItem = &pnmtv->itemOld;
	
	if ( pItem && pItem->lParam)
	{
		IUnknown* pNodeUnknown = reinterpret_cast<IUnknown*>(pItem->lParam);

#if defined(_DEBUG)
		long relcnt = pNodeUnknown->Release(); // for AddRef when added to the tree item data
		ATLASSERT( relcnt == 0);
#else
		pNodeUnknown->Release(); 
#endif
	}
	return 0;
}

// some DOM elements have a lot of attributes but few that are set. 
inline bool CMainDlg::CDOMTree::IsAnyAttributeSet( MSHTML::IHTMLAttributeCollection* pIAttrColl) 
{
	bool bRet = false;
	long numChildren = 0;
	pIAttrColl->get_length( &numChildren);
	if ( numChildren > 0)
	{
		for ( long i = 0; i < numChildren; i++)
		{
			CComVariant index( i);
			CComPtr<IDispatch> spItemDispatch;
			pIAttrColl->raw_item( &index, &spItemDispatch);
			if ( spItemDispatch != NULL)
			{
				CComQIPtr<MSHTML::IHTMLDOMAttribute> spAttribute = spItemDispatch;
				if ( spAttribute != NULL)
				{
					VARIANT_BOOL bspecified = VARIANT_FALSE;
					spAttribute->get_specified( &bspecified);
					
					if ( bspecified == VARIANT_TRUE)
					{
						bRet = true;
						break; // one attribute is set, get out
					}
				}
			}
		}
	}
	return bRet;
}

// Except for inserting the node, this method figures out if it is a leaf node or it has children.
// Children are not inserted here but setting cChildren in TVITEM to 1 signals to treeview that
// node may be expanded so that children may be added at expansion time.

inline HTREEITEM CMainDlg::CDOMTree::InsertDOMNode( MSHTML::IHTMLDOMNode* pINode, HTREEITEM hparent, HTREEITEM hinsertAfter)
{
	CComPtr<IDispatch> spCollectionDispatch;
	CComPtr<MSHTML::IHTMLDOMNode> spNode(pINode);
	TV_INSERTSTRUCT tvis;

	tvis.hParent = hparent;
	tvis.hInsertAfter = hinsertAfter;
	tvis.item.mask =  TVIF_TEXT | TVIF_IMAGE | TVIF_SELECTEDIMAGE | TVIF_CHILDREN | TVIF_PARAM; 
	tvis.item.pszText = LPSTR_TEXTCALLBACK;
	tvis.item.iImage = I_IMAGECALLBACK; 
	tvis.item.iSelectedImage = I_IMAGECALLBACK;
	tvis.item.cChildren = 0;

	if ( SUCCEEDED( spNode->get_childNodes( &spCollectionDispatch)))
	{
		CComQIPtr<MSHTML::IHTMLDOMChildrenCollection> spCollection = spCollectionDispatch;
		if ( !!spCollection)
		{
			long numChildren = 0;
			spCollection->get_length( &numChildren);
			if ( numChildren > 0)
				tvis.item.cChildren = 1;
		}
	}
	// see if we have attributes
	if ( tvis.item.cChildren == 0)
	{
		// release for use in the the next call
		spCollectionDispatch = NULL;

	 	if ( SUCCEEDED( spNode->get_attributes( &spCollectionDispatch)))
		{
			CComQIPtr<MSHTML::IHTMLAttributeCollection> spCollection = spCollectionDispatch;
			if ( !!spCollection)
			{
				if ( IsAnyAttributeSet( spCollection))
					tvis.item.cChildren = 1;
			}
		}
	}

	// Need to AddRef because we'll be keeping interface pointer as treeview item data
	// and use it in display phase
	pINode->AddRef();

	tvis.item.lParam = reinterpret_cast<LPARAM>(pINode);
	HTREEITEM hthisItem = InsertItem( &tvis);
	if ( hthisItem == NULL)
	{
		pINode->Release();
		return NULL;
	}
	return hthisItem;
}

// This is HTMLDOMNode children isertion method. Only one level of children are inserted.
// Both attributes and "real" HTMLDOMNode children are added.

inline void CMainDlg::CDOMTree::InsertDOMNodeChildren( MSHTML::IHTMLDOMNode* pINode, HTREEITEM hparent)
{
	CComPtr<IDispatch> spCollectionDispatch;
	CComPtr<MSHTML::IHTMLDOMNode> spNode(pINode);

	HTREEITEM hlastInsertedChild = NULL;

 	if ( SUCCEEDED( spNode->get_attributes( &spCollectionDispatch)))
	{
		CComQIPtr<MSHTML::IHTMLAttributeCollection> spCollection = spCollectionDispatch;
		if ( !!spCollection && IsAnyAttributeSet( spCollection))
			hlastInsertedChild = InsertAttributeCollection( spCollection, hparent);		
	}

	// release for use in the the next call
	spCollectionDispatch = NULL;

	if ( SUCCEEDED( spNode->get_childNodes( &spCollectionDispatch)))
	{
		long numChildren = 0;
		CComQIPtr<MSHTML::IHTMLDOMChildrenCollection> spCollection = spCollectionDispatch;
		if ( !!spCollection)
		{
			spCollection->get_length( &numChildren);
			
			for ( long i = 0; i < numChildren; i++)
			{
				CComPtr<IDispatch> spItemDispatch;
				spCollection->raw_item( i, &spItemDispatch);
				if ( !!spItemDispatch)
				{
					CComQIPtr<MSHTML::IHTMLDOMNode> spItemNode = spItemDispatch;
					if ( !!spItemNode)
						hlastInsertedChild = InsertDOMNode( spItemNode, hparent, hlastInsertedChild);
				}
			}
		}
	}
}

// We will put all IHTMLDOMNode attributes under the separate treeview node and each attribute
// will be a child of that special node. We are limiting ourselves to IE 5 assuming
// that each attribute is childless treeview node. Newer IE 6 IHTMLDOMAttribute2 interface
// treats attribute as DOMNode so attribute can have it own IHTMLDOMNode children.

inline HTREEITEM CMainDlg::CDOMTree::InsertAttributeCollection( MSHTML::IHTMLAttributeCollection* pIAttrColl, 
															     HTREEITEM hparent)
{
	TV_INSERTSTRUCT tvis;
	tvis.hParent = hparent;
	tvis.hInsertAfter = NULL; // attribute collection is always the first child of each DOM node
	tvis.item.mask =  TVIF_TEXT | TVIF_IMAGE | TVIF_SELECTEDIMAGE | TVIF_CHILDREN | TVIF_PARAM; 
	tvis.item.pszText = LPSTR_TEXTCALLBACK;
	tvis.item.iImage = I_IMAGECALLBACK; 
	tvis.item.iSelectedImage = I_IMAGECALLBACK;
	tvis.item.cChildren  = 1;

	// we'll be keeping interface pointer as treeview item data so that we can call it during display phase
	pIAttrColl->AddRef();
	tvis.item.lParam = reinterpret_cast<LPARAM>(pIAttrColl);
	HTREEITEM hthisItem = InsertItem( &tvis);
	if ( !hthisItem)
		pIAttrColl->Release();
	return hthisItem;
}

// Attribute collection children are inserted when collection node is expanding
inline void CMainDlg::CDOMTree::InsertAttributes( MSHTML::IHTMLAttributeCollection* pIAttrColl, HTREEITEM hparent)
{
	long numChildren = 0;
	HTREEITEM hlastInsertedChild = NULL;
	pIAttrColl->get_length( &numChildren);
		
	for ( long i = 0; i < numChildren; i++)
	{
		CComVariant index( i);
		CComPtr<IDispatch> spItemDispatch;
		pIAttrColl->raw_item( &index, &spItemDispatch);
		if ( spItemDispatch != NULL)
		{
			CComQIPtr<MSHTML::IHTMLDOMAttribute> spAttribute = spItemDispatch;
			if ( spAttribute != NULL)
			{
				VARIANT_BOOL bspecified = VARIANT_FALSE;
				spAttribute->get_specified( &bspecified);
				
				if ( bspecified == VARIANT_TRUE)
					hlastInsertedChild = InsertAttribute( spAttribute, hparent, hlastInsertedChild);
			}
		}
	}
}

// single attribute leaf node insertion method
inline HTREEITEM CMainDlg::CDOMTree::InsertAttribute( MSHTML::IHTMLDOMAttribute* pIAttribute, HTREEITEM hparent, HTREEITEM hinsertAfter)
{
	TV_INSERTSTRUCT tvis;
	tvis.hParent = hparent;
	tvis.hInsertAfter = hinsertAfter;
	tvis.item.mask =  TVIF_TEXT | TVIF_IMAGE | TVIF_SELECTEDIMAGE | TVIF_PARAM; 
	tvis.item.pszText = LPSTR_TEXTCALLBACK;
	tvis.item.iImage = I_IMAGECALLBACK; 
	tvis.item.iSelectedImage = I_IMAGECALLBACK;


	// we'll be keeping interface pointer as treeview item data so that we can call it during display phase
	pIAttribute->AddRef();
	tvis.item.lParam = reinterpret_cast<LPARAM>(pIAttribute);
	HTREEITEM hthisItem = InsertItem( &tvis);
	if ( !hthisItem)
		pIAttribute->Release();
	return hthisItem;
}

// HTMLDOMNode and HTMLDOMAttribute can have null, string and integer values
inline void CMainDlg::CDOMTree::FormatNameAndValue( const CComBSTR& name, const CComVariant& value, TCHAR* pTextResult)
{
	USES_CONVERSION;
	static LPCTSTR pstrvaltitle = _T(" ; value=");
	static LPCTSTR pstrvalnull = _T("null");

	lstrcpy( pTextResult, W2T( name));
	lstrcat( pTextResult, pstrvaltitle);
	if ( value.vt != VT_EMPTY && value.vt != VT_NULL)
	{
		if ( value.vt == VT_BSTR)
		{
			if ( value.bstrVal != NULL)
				lstrcat( pTextResult, W2T( value.bstrVal));
			else
				lstrcat( pTextResult, pstrvalnull);
		}
		else if ( value.vt == VT_I4)
		{
			TCHAR number[64];
			wsprintf( number, _T("%d"), value.intVal);
			lstrcat( pTextResult, number);
		}
	}
	else
		lstrcat( pTextResult, pstrvalnull);
}

// Recursive helper that calls a method, that param fp points to, for a hParent node
// and all of its children, its children's children, etc.
// This is one of few cases where I used ->* notation for method call through a pointer

inline void CMainDlg::CDOMTree::DoForItemAndChildren( HTREEITEM hParent, FOREACHITEM fp, unsigned int flags /*= 0*/)
{
	// DOPARENTFIRST flag tells us if we want fp to be called on parent node first, then children, or viceversa
	if ( flags & DOPARENTFIRST)
	{
		if ( !( flags & SKIPTOPPARENT))
			(this->*fp)( hParent);
	}

	HTREEITEM hChild = GetChildItem(hParent);
	while ( hChild)
	{
		DoForItemAndChildren( hChild, fp, ( flags & DOPARENTFIRST) ? DOPARENTFIRST : 0);
		hChild = GetNextSiblingItem( hChild);
	};
	if ( !(flags & DOPARENTFIRST))
	{
		if ( !( flags & SKIPTOPPARENT))
			(this->*fp)( hParent);
	}
}

// Expand entire tree under currently selected node. Mouse click expands only
// one level so it may take quite some time to expand a large tree. 
inline void CMainDlg::CDOMTree::ExpandAll()
{
	HTREEITEM hCurrent = GetSelectedItem();
	if ( !hCurrent)
		hCurrent = GetRootItem();
	if ( hCurrent)
	{
		SetRedraw( FALSE);
		// When expanding we must expand parent before its children
		// because expanding notification is what inserts children in
		// the first place.
		unsigned int flags = DOPARENTFIRST;
		DoForItemAndChildren( hCurrent, ExpandItem, flags);
		EnsureVisible( hCurrent);
		SetRedraw( TRUE);
	}
}

inline void CMainDlg::CDOMTree::CollapseAll()
{
	HTREEITEM hCurrent = GetSelectedItem();
	if ( !hCurrent)
		hCurrent = GetRootItem();
	if ( hCurrent)
	{
		SetRedraw( FALSE);
		Expand( hCurrent, TVE_COLLAPSE | TVE_COLLAPSERESET);
		SetRedraw( TRUE);
	}
}

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_MAINDLG_H__E0443F76_31D2_4471_B6F6_E0F733D1385E__INCLUDED_)
