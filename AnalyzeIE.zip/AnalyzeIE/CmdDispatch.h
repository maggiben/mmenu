// CmdDispatch.h : Declaration of the CCmdDispatch

#ifndef __CMDDISPATCH_H_
#define __CMDDISPATCH_H_

#include "resource.h"     // main symbols
#include <docobj.h>		 // IOleCommandTarget

/////////////////////////////////////////////////////////////////////////////
// CCmdDispatch
class ATL_NO_VTABLE CCmdDispatch : 
	public CComObjectRootEx<CComSingleThreadModel>,
	public CComCoClass<CCmdDispatch, &CLSID_CmdDispatch>,
	public ICmdDispatch,
	public IOleCommandTarget
{
public:

DECLARE_REGISTRY_RESOURCEID(IDR_CMDDISPATCH)
DECLARE_CLASSFACTORY_SINGLETON(CCmdDispatch) // singleton object
DECLARE_NOT_AGGREGATABLE(CCmdDispatch)

DECLARE_PROTECT_FINAL_CONSTRUCT()

BEGIN_COM_MAP(CCmdDispatch)
	COM_INTERFACE_ENTRY(ICmdDispatch)
	COM_INTERFACE_ENTRY(IOleCommandTarget)
END_COM_MAP()

// ICmdDispatch
public:
	// IOleCommandTarget
    STDMETHOD(QueryStatus)( const GUID *, ULONG , OLECMD[], OLECMDTEXT *);
	STDMETHOD(Exec)( const GUID *, DWORD , DWORD , VARIANT *, VARIANT *);
};

#endif //__CMDDISPATCH_H_
