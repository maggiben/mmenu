// stdafx.h : include file for standard system include files,
//      or project specific include files that are used frequently,
//      but are changed infrequently

#if !defined(AFX_STDAFX_H__8587A94D_46D3_44AB_85C1_DCBC1B563416__INCLUDED_)
#define AFX_STDAFX_H__8587A94D_46D3_44AB_85C1_DCBC1B563416__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#define STRICT
#ifndef _WIN32_WINNT
#define _WIN32_WINNT 0x0400
#endif
#define _ATL_APARTMENT_THREADED

#if defined(_DEBUG)
//#define _ATL_DEBUG_INTERFACES
#endif

#include <atlbase.h>
#include <atlapp.h>

//You may derive a class from CComModule and use it if you want to override
//something, but do not change the name of _Module

class ThisModule : public CComModule
{
public:
	BOOL IsShowDialog( void) { return m_bDialog; }
	void SetShowDialog( BOOL bSet) { m_bDialog = bSet; } 

	BOOL m_bDialog; // TRUE if all DOMPeek objects instantiated in this module should display dialog
	CSimpleValArray<DWORD>* m_pObjectArray; // pointer instead of a member to avoid having to link to CRT
};

extern ThisModule _Module;
extern IGlobalInterfaceTable *g_pGIT; // DOMPeek objects would register their interface pointers here

//#include <atlmisc.h> // ATL CString - so far this code needed only Win32 lstr* functions

#include <atlcom.h>
#include <atlwin.h>
#include <AtlCtrls.h>
#include <atlframe.h>

#import "c:\winnt\system32\mshtml.tlb" named_guids
#import "c:\winnt\system32\shdocvw.dll" named_guids


//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_STDAFX_H__8587A94D_46D3_44AB_85C1_DCBC1B563416__INCLUDED)
