// CmdDispatch.cpp : Implementation of CCmdDispatch
#include "stdafx.h"
#include "AnalyzeIE.h"
#include "CmdDispatch.h"
#include "DOMPeek.h"

/////////////////////////////////////////////////////////////////////////////
// CCmdDispatch

// IOleCommandTarget implementation

STDMETHODIMP CCmdDispatch::QueryStatus( const GUID * /*pguidCmdGroup*/, ULONG cCmds, OLECMD prgCmds[], OLECMDTEXT * /*pCmdText*/)
{
	HRESULT hr = E_POINTER;

	if ( prgCmds != NULL)  
	{
		for ( ULONG i = 0; i < cCmds; i++)
			prgCmds[i].cmdf = OLECMDF_SUPPORTED | OLECMDF_ENABLED; 
		
		hr = S_OK;
	}
	return hr;	
}

STDMETHODIMP CCmdDispatch:: Exec( const GUID *pguidCmdGroup, DWORD nCmdID, DWORD nCmdexecopt, VARIANT * /*pvaIn*/, VARIANT * /*pvaOut*/)
{
	HRESULT hr = OLECMDERR_E_UNKNOWNGROUP;

	if ( pguidCmdGroup == NULL)
	{
		if ( nCmdID != 0)
			hr = OLECMDERR_E_NOTSUPPORTED;
		else
		{
			if ( nCmdexecopt == OLECMDEXECOPT_SHOWHELP)
			{
				hr = OLECMDERR_E_NOHELP;
			}
			else
			{
				// Button is a toggle - invert the original value
				BOOL bShow = _Module.IsShowDialog() ? FALSE : TRUE;
				_Module.SetShowDialog( bShow);

				int numobjs = _Module.m_pObjectArray->GetSize();
				if ( numobjs > 0)
				{
					// get interface to all DOMPeek objects that registered itself in GIT table
					// and display or destroy corresponding dialogs
					for ( int i = 0; i < numobjs; i++)
					{
						IDOMPeek* pIDOMPeek = NULL;
						if ( SUCCEEDED( g_pGIT->GetInterfaceFromGlobal( (*_Module.m_pObjectArray)[i],
																	IID_IDOMPeek, (void**)&pIDOMPeek)))
							pIDOMPeek->put_DialogDisplay( bShow);
					}
				}
				hr = S_OK;
			}
		}
	}
	return hr;
}
