// AnalyzeIE.cpp : Implementation of DLL Exports.


// Note: Proxy/Stub Information
//      To build a separate proxy/stub DLL, 
//      run nmake -f AnalyzeIEps.mk in the project directory.

#include "stdafx.h"
#include "resource.h"
#include <initguid.h>
#include "AnalyzeIE.h"

#include "AnalyzeIE_i.c"
#include "DOMPeek.h"
#include "CmdDispatch.h"

IGlobalInterfaceTable *g_pGIT = NULL;

ThisModule _Module;

BEGIN_OBJECT_MAP(ObjectMap)
OBJECT_ENTRY(CLSID_DOMPeek, CDOMPeek)
OBJECT_ENTRY(CLSID_CmdDispatch, CCmdDispatch)
END_OBJECT_MAP()

/////////////////////////////////////////////////////////////////////////////
// DLL Entry Point

extern "C"
BOOL WINAPI DllMain(HINSTANCE hInstance, DWORD dwReason, LPVOID /*lpReserved*/)
{
    if (dwReason == DLL_PROCESS_ATTACH)
    {
		TCHAR Loader[MAX_PATH];

		// lstrcmpi and calling new for m_pObjectArray member of ThisModule
		// avoids the need to link with CRT library when compiling for minimum dependency.
		// For this reason Win32 string functions are used in the rest of source code.
		GetModuleFileName( NULL, Loader, MAX_PATH);
		for ( int i = lstrlen( Loader); i > 0; i--)
			if ( Loader[i] == _T('\\'))
			{
				lstrcpy( Loader, Loader + i + 1);
				break;
			}
				
		// allow loading of BHO by these two programs only
		if ( lstrcmpi( Loader, _T("iexplore.exe")) != 0 && lstrcmpi( Loader, _T("regsvr32.exe")) != 0)
			return FALSE;

		if ( SUCCEEDED( CoCreateInstance( CLSID_StdGlobalInterfaceTable, 0,
					CLSCTX_INPROC_SERVER,
					IID_IGlobalInterfaceTable,
					(void**)&g_pGIT)))
		{
			_Module.Init(ObjectMap, hInstance, &LIBID_ANALYZEIELib);
			_Module.m_pObjectArray = new CSimpleValArray<DWORD>;
			_Module.SetShowDialog( TRUE); // by default show dialog with DOM tree (could be in Registry)
		}
		else
			return FALSE;

#if (_WIN32_IE >= 0x0300)
		INITCOMMONCONTROLSEX iccx;
		iccx.dwSize = sizeof(iccx);
		iccx.dwICC = ICC_COOL_CLASSES | ICC_BAR_CLASSES;
		BOOL bRet = ::InitCommonControlsEx(&iccx);
		bRet;
		ATLASSERT(bRet);
#else
		::InitCommonControls();
#endif

        DisableThreadLibraryCalls(hInstance);
    }
    else if (dwReason == DLL_PROCESS_DETACH)
	{
		if ( g_pGIT)
			g_pGIT->Release();
		 delete	_Module.m_pObjectArray;
        _Module.Term();
	}
    return TRUE;    // ok
}

/////////////////////////////////////////////////////////////////////////////
// Used to determine whether the DLL can be unloaded by OLE

STDAPI DllCanUnloadNow(void)
{
    return (_Module.GetLockCount()==0) ? S_OK : S_FALSE;
}

/////////////////////////////////////////////////////////////////////////////
// Returns a class factory to create an object of the requested type

STDAPI DllGetClassObject(REFCLSID rclsid, REFIID riid, LPVOID* ppv)
{
    return _Module.GetClassObject(rclsid, riid, ppv);
}

/////////////////////////////////////////////////////////////////////////////
// DllRegisterServer - Adds entries to the system registry

STDAPI DllRegisterServer(void)
{
    // registers object, typelib and all interfaces in typelib
    return _Module.RegisterServer(TRUE);
}

/////////////////////////////////////////////////////////////////////////////
// DllUnregisterServer - Removes entries from the system registry

STDAPI DllUnregisterServer(void)
{
    return _Module.UnregisterServer(TRUE);
}


