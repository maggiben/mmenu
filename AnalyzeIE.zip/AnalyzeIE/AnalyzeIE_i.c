/* this file contains the actual definitions of */
/* the IIDs and CLSIDs */

/* link this file in with the server and any clients */


/* File created by MIDL compiler version 5.01.0164 */
/* at Thu Dec 06 20:38:48 2001
 */
/* Compiler settings for C:\dev\IE spy\AnalyzeIE\AnalyzeIE.idl:
    Oicf (OptLev=i2), W1, Zp8, env=Win32, ms_ext, c_ext
    error checks: allocation ref bounds_check enum stub_data 
*/
//@@MIDL_FILE_HEADING(  )
#ifdef __cplusplus
extern "C"{
#endif 


#ifndef __IID_DEFINED__
#define __IID_DEFINED__

typedef struct _IID
{
    unsigned long x;
    unsigned short s1;
    unsigned short s2;
    unsigned char  c[8];
} IID;

#endif // __IID_DEFINED__

#ifndef CLSID_DEFINED
#define CLSID_DEFINED
typedef IID CLSID;
#endif // CLSID_DEFINED

const IID IID_IDOMPeek = {0x0B6EF17E,0x18E5,0x4449,{0x86,0xEA,0x64,0xC8,0x2D,0x59,0x6E,0xAE}};


const IID LIBID_ANALYZEIELib = {0xBD0022A3,0xA43F,0x4F44,{0xB6,0x4F,0x53,0xEA,0x75,0x75,0xF0,0x97}};


const CLSID CLSID_DOMPeek = {0x834261E1,0xDD97,0x4177,{0x85,0x3B,0xC9,0x07,0xE5,0xD5,0xBD,0x6E}};


const IID IID_ICmdDispatch = {0x39334DA8,0x9B2A,0x497D,{0xAF,0x7A,0x22,0xE2,0x39,0x55,0x29,0x67}};


const CLSID CLSID_CmdDispatch = {0x0B9BE66E,0xF413,0x4EFE,{0x82,0x92,0x21,0x51,0x11,0x86,0xD8,0x21}};


#ifdef __cplusplus
}
#endif

