// DOMPeek.h : Declaration of the CDOMPeek

#ifndef __DOMPEEK_H_
#define __DOMPEEK_H_

#include "resource.h"       // main symbols
#include "maindlg.h"
#include "exdispid.h"	// dispatch IDs for DWebBrowserEvents2

/////////////////////////////////////////////////////////////////////////////
// CDOMPeek
class ATL_NO_VTABLE CDOMPeek : 
	public CComObjectRootEx<CComSingleThreadModel>,
	public CComCoClass<CDOMPeek, &CLSID_DOMPeek>,
	public IObjectWithSiteImpl<CDOMPeek>,
	public IDispatchImpl<IDOMPeek, &IID_IDOMPeek, &LIBID_ANALYZEIELib>,
	public IDispEventImpl< 0, CDOMPeek, &SHDocVw::DIID_DWebBrowserEvents2, &SHDocVw::LIBID_SHDocVw, 1, 0>
{
public:
	~CDOMPeek() 
	{ 
		m_spDoc2.Release(); 
		m_spWebBrowser2.Release(); 
	}

DECLARE_REGISTRY_RESOURCEID(IDR_DOMPEEK)
DECLARE_NOT_AGGREGATABLE(CDOMPeek)

DECLARE_PROTECT_FINAL_CONSTRUCT()

BEGIN_COM_MAP(CDOMPeek)
	COM_INTERFACE_ENTRY(IDOMPeek)
	COM_INTERFACE_ENTRY(IDispatch)
	COM_INTERFACE_ENTRY(IObjectWithSite)
END_COM_MAP()

BEGIN_SINK_MAP(CDOMPeek)
	SINK_ENTRY_EX( 0, SHDocVw::DIID_DWebBrowserEvents2, DISPID_ONQUIT, OnQuit)
	SINK_ENTRY_EX( 0, SHDocVw::DIID_DWebBrowserEvents2, DISPID_DOCUMENTCOMPLETE, DocumentComplete)
END_SINK_MAP()

public:
	// IDOMPeek
	STDMETHOD(get_DialogDisplay)(/*[out, retval]*/ BOOL *pVal);
	STDMETHOD(put_DialogDisplay)(/*[in]*/ BOOL newVal);

	// IObjectWithSite 
	STDMETHOD(SetSite)(IUnknown *pUnkSite);

	// DWebBrowserEvents2 
	STDMETHOD( OnQuit)( void);
	STDMETHOD( DocumentComplete)( IDispatch * pDisp, VARIANT * URL );


	// helper methods
	bool IsDialogDisplayed( void) { return m_DocDlg.IsWindow() != 0; }

	bool SetDialogDisplayed( bool bDisplay) 
	{
		bool bRet = true;
		bool bWnd = m_DocDlg.IsWindow() != 0;
		if ( !bDisplay)
		{
			if ( bWnd)
				m_DocDlg.CloseDialog();
		}
		else if ( !bWnd)
			bRet = StartNewDialog();
		return bRet;
	}

	bool StartNewDialog( void);

// members
	CMainDlg m_DocDlg; // dialog displayed by this object
	CComQIPtr<SHDocVw::IWebBrowser2, &SHDocVw::IID_IWebBrowser2> m_spWebBrowser2;
	CComQIPtr<MSHTML::IHTMLDocument2, &MSHTML::IID_IHTMLDocument2> m_spDoc2;
	DWORD m_GITCookie; // cookie for object registration in GIT - makes it available to CmdDispatch object
};


#endif //__DOMPEEK_H_
