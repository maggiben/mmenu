//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by IconDlgTest.rc
//
#define IDS_ICO_FILTER                  1
#define IDS_ICO_CAPTION                 2
#define IDBROWSE                        3
#define IDS_NO_ICONS                    3
#define IDS_PLEASE_SELECT_ICON          4
#define IDS_NOT_A_FILE                  5
#define IDD_ICONDLGTEST                 102
#define IDR_POPUP_ICON                  103
#define IDR_MAINFRAME                   128
#define IDD_CHOOSE_ICON                 129
#define IDC_FILENAME                    1000
#define IDC_SHOW                        1002
#define IDC_ICONLIST                    1004
#define IDC_SELECTED_ICON               1005

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        132
#define _APS_NEXT_COMMAND_VALUE         32772
#define _APS_NEXT_CONTROL_VALUE         1006
#define _APS_NEXT_SYMED_VALUE           104
#endif
#endif
