#include "stdafx.h"
#include "IconDlgTest.h"
#include "IconDlgTestDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

BEGIN_MESSAGE_MAP(CIconDlgTestApp, CWinApp)
	//{{AFX_MSG_MAP(CIconDlgTestApp)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

CIconDlgTestApp::CIconDlgTestApp()
{
}

CIconDlgTestApp theApp;

BOOL CIconDlgTestApp::InitInstance()
{
	Enable3dControls();

	CIconDlgTestDlg dlg;
	m_pMainWnd = &dlg;
	int nResponse = dlg.DoModal();

	return FALSE;
}


