#include "stdafx.h"
#include "IconDlgTest.h"
#include "IconDlgTestDlg.h"
#include "IconDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

CIconDlgTestDlg::CIconDlgTestDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CIconDlgTestDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CIconDlgTestDlg)
	//}}AFX_DATA_INIT
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
  m_bRetreivedIcon = FALSE;
}

void CIconDlgTestDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CIconDlgTestDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CIconDlgTestDlg, CDialog)
	//{{AFX_MSG_MAP(CIconDlgTestDlg)
	ON_BN_CLICKED(IDC_SHOW, OnShow)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

BOOL CIconDlgTestDlg::OnInitDialog()
{
	CDialog::OnInitDialog();
	SetIcon(m_hIcon, TRUE);
	SetIcon(m_hIcon, FALSE);
	return TRUE;
}

void CIconDlgTestDlg::OnShow() 
{
	CIconDialog dlg(this);
  if (m_bRetreivedIcon)
    dlg.SetIcon(m_sFilename, m_nIconIndex);
  if (dlg.DoModal() == IDOK)
  {
    dlg.GetIcon(m_sFilename, m_nIconIndex);
    HICON hIcon = ExtractIcon(AfxGetInstanceHandle(), m_sFilename, m_nIconIndex);
    HICON hOldIcon = ((CStatic*) GetDlgItem(IDC_SELECTED_ICON))->SetIcon(hIcon);
  	SetIcon(hIcon, TRUE);
	  SetIcon(hIcon, FALSE);
    if (hOldIcon)
      DestroyIcon(hOldIcon);
    m_bRetreivedIcon = TRUE;
  }
}
