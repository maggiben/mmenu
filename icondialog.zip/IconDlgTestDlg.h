class CIconDlgTestDlg : public CDialog
{
public:
	CIconDlgTestDlg(CWnd* pParent = NULL);	// standard constructor

	//{{AFX_DATA(CIconDlgTestDlg)
	enum { IDD = IDD_ICONDLGTEST };
	//}}AFX_DATA

	//{{AFX_VIRTUAL(CIconDlgTestDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

protected:
	HICON m_hIcon;

	//{{AFX_MSG(CIconDlgTestDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnShow();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

  CString m_sFilename;
  int m_nIconIndex;
  BOOL m_bRetreivedIcon;
};
