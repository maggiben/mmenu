#pragma once



namespace UI
{
	class AFX_EXT_CLASS CTransparentDialogBase : public CDialog
	{
		DECLARE_DYNAMIC(CTransparentDialogBase)

	public:
		CTransparentDialogBase( LPCTSTR lpszFile, UINT nID, CWnd* pParent = NULL);   // standard constructor
		virtual ~CTransparentDialogBase();
		void Refresh();


	protected:
		virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

		DECLARE_MESSAGE_MAP()
		afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
		afx_msg BOOL OnEraseBkgnd(CDC* pDC);
		afx_msg void OnDestroy();
		afx_msg void OnMove(int x, int y);
		afx_msg void OnPaint();
		afx_msg void OnShowWindow(BOOL bShow, UINT nStatus);
		afx_msg void OnSize(UINT nType, int cx, int cy);
		afx_msg void OnActivate(UINT nState, CWnd* pWndOther, BOOL bMinimized);
		afx_msg void OnClose();


		virtual BOOL OnInitDialog();
		virtual void OnDraw(Graphics & graphics);

		void CreateFakeWnd(void);
		void DestoryFakeWnd(void);

		void DrawCtrl( Graphics & graphics, HDC hDC, HWND hWnd);
		void DrawCaret(Graphics & graph);

		void EnableDrag(BOOL bEnabled);


		Image 					m_Image;
		int						m_nWidth;
		int						m_nHeigh;
		HWND					m_hFakeWnd;
		BOOL					m_bEnableDrag;
		int						m_nAlpha;
		

		static UINT __cdecl ShowMotionThread( LPVOID pParam );
		static UINT __cdecl CloseMotionThread( LPVOID pParam );
	};

	
}
