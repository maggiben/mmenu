// TransparentDialogBase.cpp : implementation file
//

#include "stdafx.h"
#include "./TransparentDialogBase.h"


// CTransparentDialogBase dialog
BEGIN_MESSAGE_MAP(UI::CTransparentDialogBase, CDialog)
	ON_WM_LBUTTONDOWN()
	ON_WM_ERASEBKGND()
	ON_WM_DESTROY()
	ON_WM_MOVE()
	ON_WM_PAINT()
	ON_WM_SHOWWINDOW()
	ON_WM_SIZE()
	ON_WM_ACTIVATE()
	ON_WM_CLOSE()
END_MESSAGE_MAP()




namespace UI
{
	IMPLEMENT_DYNAMIC(CTransparentDialogBase, CDialog)

	//-------------------------------------------------------------------------
	// Function Name    :CTransparentDialogBase
	// Parameter(s)     :LPCTSTR lpszFile	The image file path
	//					:UINT nID			The resource id
	// Return           :
	// Create			:2007-4-28 16:26 ����
	// Memo             :
	//-------------------------------------------------------------------------
	CTransparentDialogBase::CTransparentDialogBase(  LPCTSTR lpszFile, UINT nID, CWnd* pParent /*=NULL*/)
		: CDialog( nID, pParent)
		, m_nWidth(0)
		, m_nHeigh(0)
		, m_Image( Generic::GetModulePath(NULL) + lpszFile)
		, m_hFakeWnd(NULL)
		, m_bEnableDrag(TRUE)
		, m_nAlpha(0)
	{
		m_nWidth = m_Image.GetWidth();
		m_nHeigh = m_Image.GetHeight();
	}

	CTransparentDialogBase::~CTransparentDialogBase()
	{
	}

	void CTransparentDialogBase::DoDataExchange(CDataExchange* pDX)
	{
		CDialog::DoDataExchange(pDX);
	}


	//-------------------------------------------------------------------------
	// Function Name    :EnableDrag
	// Parameter(s)     :BOOL bEnabled
	// Return           :
	// Create			:2007-5-8 11:42 ����
	// Memo             :TRUE: the window is dragable; FALSE:not dragable
	//-------------------------------------------------------------------------
	void CTransparentDialogBase::EnableDrag(BOOL bEnabled)
	{
		m_bEnableDrag = bEnabled;
	}

	//-------------------------------------------------------------------------
	// Function Name    :OnLButtonDown
	// Parameter(s)     :
	// Return           :
	// Create			:2007-5-7 18:52 ����
	// Memo             :To make this dialog can be dragable
	//-------------------------------------------------------------------------
	void CTransparentDialogBase::OnLButtonDown(UINT nFlags, CPoint point)
	{
		if( m_bEnableDrag )
		{
			::SystemParametersInfo(SPI_SETDRAGFULLWINDOWS,FALSE,NULL,0);
			::SendMessage( GetSafeHwnd(), WM_SYSCOMMAND, 0xF012, 0);  
		}


		CDialog::OnLButtonDown(nFlags, point);
	}



	#define FAKE_WND_CLASS_NAME _T("TranFakeWnd")

	//-------------------------------------------------------------------------
	// Function Name    :CreateFakeWnd
	// Parameter(s)     :
	// Return           :
	// Create			:2007-5-7 18:50 ����
	// Memo             :create the fake window
	//-------------------------------------------------------------------------
	void CTransparentDialogBase::CreateFakeWnd(void)
	{
		DestoryFakeWnd();

		WNDCLASSEX wcex;

		memset(&wcex, 0, sizeof(wcex));

		wcex.cbSize = sizeof(WNDCLASSEX); 
		wcex.style			= CS_HREDRAW | CS_VREDRAW;
		wcex.lpfnWndProc	= ::DefWindowProc;
		wcex.cbClsExtra		= 0;
		wcex.cbWndExtra		= 0;
		wcex.hInstance		= ::GetModuleHandle(NULL);
		wcex.hIcon			= NULL;
		wcex.hCursor		= ::LoadCursor(NULL, IDC_ARROW);
		wcex.hbrBackground	= (HBRUSH)(COLOR_WINDOW+1);
		wcex.lpszMenuName	= NULL;
		wcex.lpszClassName	= FAKE_WND_CLASS_NAME;
		wcex.hIconSm		= NULL;

		VERIFY( RegisterClassEx(&wcex) );


		CRect rc;
		GetWindowRect(rc);
		m_hFakeWnd = ::CreateWindowEx( WS_EX_LAYERED | WS_EX_TRANSPARENT | WS_EX_NOACTIVATE | WS_EX_LEFT
			, FAKE_WND_CLASS_NAME
			, NULL
			, WS_VISIBLE | WS_OVERLAPPED
			, 0
			, 0
			, rc.Width()
			, rc.Height()
			, GetSafeHwnd()
			, NULL
			, ::GetModuleHandle(NULL)
			, NULL
			);
		ASSERT( m_hFakeWnd != NULL );

	}


	//-------------------------------------------------------------------------
	// Function Name    :DestoryFakeWnd
	// Parameter(s)     :
	// Return           :
	// Create			:2007-5-8 11:43 ����
	// Memo             :Destory the fake wnd
	//-------------------------------------------------------------------------
	void CTransparentDialogBase::DestoryFakeWnd(void)
	{
		if( m_hFakeWnd != NULL )
		{
			::DestroyWindow(m_hFakeWnd);
			m_hFakeWnd = NULL;

			::UnregisterClass( FAKE_WND_CLASS_NAME, ::GetModuleHandle(NULL) );
		}
	}
	

	
	BOOL CTransparentDialogBase::OnInitDialog()
	{
		CDialog::OnInitDialog();

		// Set the dialog style
		::SetWindowPos( GetSafeHwnd()
			, NULL
			, 0
			, 0
			, m_Image.GetWidth()
			, m_Image.GetHeight()
			, SWP_NOMOVE | SWP_NOZORDER
			);

		CreateFakeWnd();

		::SetWindowLong( m_hWnd, GWL_EXSTYLE, GetWindowLong(m_hWnd, GWL_EXSTYLE) | WS_EX_LAYERED);
		BYTE bTran = 5;
		::SetLayeredWindowAttributes( m_hWnd, 0, bTran, LWA_ALPHA);

		return TRUE;  // return TRUE unless you set the focus to a control
		// EXCEPTION: OCX Property Pages should return FALSE
	}

	


	//-------------------------------------------------------------------------
	// Function Name    :DrawCtrl
	// Parameter(s)     :
	// Return           :
	// Create			:2007-4-28 16:21 ����
	// Memo             :Draw the child control
	//-------------------------------------------------------------------------
	void CTransparentDialogBase::DrawCtrl( Graphics & graphics, HDC hDC, HWND hWnd)
	{
		if( !::IsWindow(hWnd) )
			return;

		RECT rc;
		CWnd::FromHandle(hWnd)->GetWindowRect(&rc);
		ScreenToClient(&rc);

		HDC hdcMemory = ::CreateCompatibleDC(hDC);
		HBITMAP hBitmap = ::CreateCompatibleBitmap( hDC, rc.right - rc.left, rc.bottom - rc.top);
		HGDIOBJ hbmpOld = ::SelectObject( hdcMemory, hBitmap); 

		::SendMessage( hWnd, WM_PRINT, (WPARAM)hdcMemory, (LPARAM)PRF_NONCLIENT | PRF_CLIENT | PRF_CHILDREN | PRF_CHECKVISIBLE);

		Bitmap bitmap( hBitmap, NULL);
		graphics.DrawImage( &bitmap, rc.left, rc.top);

		::SelectObject( hdcMemory, hbmpOld); 
		::DeleteDC(hdcMemory);
		::DeleteObject(hBitmap); 
	}


		
	//-------------------------------------------------------------------------
	// Function Name    :Refresh
	// Parameter(s)     :
	// Return           :
	// Create			:2007-4-27 19:17 ����
	// Memo             :update the windows display
	//-------------------------------------------------------------------------
	void CTransparentDialogBase::Refresh(void)
	{
		if( !IsWindow(m_hFakeWnd) )
			return;

		RECT rc;
		::GetWindowRect( m_hFakeWnd, &rc);
		POINT ptSrc = { 0, 0};
		POINT ptWinPos = { rc.left, rc.top};
		SIZE szWin = { m_nWidth, m_nHeigh };
		BLENDFUNCTION stBlend = { AC_SRC_OVER, 0, m_nAlpha, AC_SRC_ALPHA };


		HDC hDC = ::GetDC(m_hFakeWnd);
		HDC hdcMemory = ::CreateCompatibleDC(hDC);

 
		BITMAPINFOHEADER bmih = { 0 };   
		int nBytesPerLine = ((m_nWidth * 32 + 31) & (~31)) >> 3;
		// Populate BITMAPINFO header   
		bmih.biSize = sizeof(BITMAPINFOHEADER);   
		bmih.biWidth = m_nWidth;   
		bmih.biHeight = m_nHeigh;   
		bmih.biPlanes = 1;   
		bmih.biBitCount = 32;   
		bmih.biCompression = BI_RGB;   
		bmih.biClrUsed = 0;   
		bmih.biSizeImage = nBytesPerLine * m_nHeigh;   

		PVOID pvBits = NULL;   
		HBITMAP hbmpMem = ::CreateDIBSection(NULL, (PBITMAPINFO)&bmih, DIB_RGB_COLORS, &pvBits, NULL, 0);
		ASSERT(hbmpMem != NULL);
		memset( pvBits, 0, m_nWidth * 4 * m_nHeigh);
		if(hbmpMem)   
		{   
			HGDIOBJ hbmpOld = ::SelectObject( hdcMemory, hbmpMem); 
			Graphics graph(hdcMemory);

			
			graph.SetPageScale(1.0);
			graph.SetPageUnit(UnitPixel);
			graph.SetSmoothingMode(SmoothingModeNone);

			
			// Draw the background
			graph.DrawImage( &m_Image, 0, 0, m_nWidth, m_nHeigh);

			// On draw 
			OnDraw(graph);

			
			// Draw all the controls
			HWND hwndChild = ::GetWindow( GetSafeHwnd(), GW_CHILD);  
			while(hwndChild)   
			{   
				DrawCtrl( graph, hDC, hwndChild);
				hwndChild = ::GetWindow( hwndChild, GW_HWNDNEXT);   
			}  
			

			// draw the caret
			DrawCaret(graph);

			
			
			::UpdateLayeredWindow( m_hFakeWnd
				, hDC
				, &ptWinPos
				, &szWin
				, hdcMemory
				, &ptSrc
				, 0
				, &stBlend
				, ULW_ALPHA
				);
				


			graph.ReleaseHDC(hdcMemory);
			::SelectObject( hdcMemory, hbmpOld);   
			::DeleteObject(hbmpMem); 
		}

		
		::DeleteDC(hdcMemory);
		::DeleteDC(hDC);
	}

	void CTransparentDialogBase::DrawCaret(Graphics & graph)
	{
		CWnd * pWnd = GetFocus();
		if( pWnd == NULL ||
			!::IsWindow(pWnd->GetSafeHwnd()) )
		{
			return;
		}

		TCHAR tszBuf[MAX_PATH] = {'\0'};
		::GetClassName( pWnd->GetSafeHwnd(), tszBuf, MAX_PATH);
		CString strClassName(tszBuf);

		if( strClassName.CompareNoCase(_T("EDIT")) != 0 )
			return;

		CPoint pt = GetCaretPos();
		pWnd->ClientToScreen(&pt);
		ScreenToClient(&pt);

		Pen pen( Color::Black, 1.0f);
		graph.DrawLine( &pen, pt.x, pt.y, pt.x, pt.y + 13);

		TRACE( _T("Caret: %s %d, %d\n"), tszBuf, pt.x, pt.y);
	}


	void CTransparentDialogBase::OnPaint()
	{
		Refresh();
	}

	//-------------------------------------------------------------------------
	// Function Name    :OnDraw
	// Parameter(s)     :
	// Return           :
	// Create			:2007-5-7 18:52 ����
	// Memo             :This function can be overridden in the child class
	//-------------------------------------------------------------------------
	void CTransparentDialogBase::OnDraw(Graphics & graphics)
	{
	}



	//-------------------------------------------------------------------------
	// Function Name    :OnEraseBkgnd
	// Parameter(s)     :
	// Return           :
	// Create			:2007-5-8 13:50 ����
	// Memo             :Erase back ground with nothing
	//-------------------------------------------------------------------------
	BOOL CTransparentDialogBase::OnEraseBkgnd(CDC* pDC)
	{
		return TRUE;
	}



	//-------------------------------------------------------------------------
	// Function Name    :OnDestroy
	// Parameter(s)     :
	// Return           :
	// Create			:2007-5-8 13:49 ����
	// Memo             :Destroy the fake window
	//-------------------------------------------------------------------------
	void CTransparentDialogBase::OnDestroy()
	{
		TRACE( _T("OnDestroy()\n") );

		CDialog::OnDestroy();

		DestoryFakeWnd();
	}




	//-------------------------------------------------------------------------
	// Function Name    :OnMove
	// Parameter(s)     :
	// Return           :
	// Create			:2007-5-8 13:49 ����
	// Memo             :When the dialog moved
	//-------------------------------------------------------------------------
	void CTransparentDialogBase::OnMove(int x, int y)
	{
		CDialog::OnMove(x, y);

		::SetWindowPos( m_hFakeWnd
			, NULL
			, x
			, y
			, 0
			, 0
			, SWP_NOZORDER | SWP_NOSIZE
			);
	}

	//-------------------------------------------------------------------------
	// Function Name    :OnSize
	// Parameter(s)     :
	// Return           :
	// Create			:2007-5-8 13:49 ����
	// Memo             :When the dialog sized
	//-------------------------------------------------------------------------
	void CTransparentDialogBase::OnSize(UINT nType, int cx, int cy)
	{
		CDialog::OnSize(nType, cx, cy);

		::SetWindowPos( m_hFakeWnd
			, NULL
			, 0
			, 0
			, cx
			, cy
			, SWP_NOZORDER | SWP_NOMOVE
			);
	}



	
	//-------------------------------------------------------------------------
	// Function Name    :OnShowWindow
	// Parameter(s)     :
	// Return           :
	// Create			:2007-5-8 13:49 ����
	// Memo             :When the Visible is changed
	//-------------------------------------------------------------------------
	void CTransparentDialogBase::OnShowWindow(BOOL bShow, UINT nStatus)
	{
		TRACE( _T("OnShowWindow( %d, %d)\n"), bShow, nStatus);
		CDialog::OnShowWindow(bShow, nStatus);
		::ShowWindow( m_hFakeWnd, bShow ? SW_SHOWNA : SW_HIDE);

		static BOOL s_bShown = FALSE;
		if( !s_bShown )
		{
			s_bShown = TRUE;
			AfxBeginThread( (AFX_THREADPROC)ShowMotionThread, this);
		}
	}





	//-------------------------------------------------------------------------
	// Function Name    :OnActivate
	// Parameter(s)     :
	// Return           :
	// Create			:2007-5-8 13:50 ����
	// Memo             :When activated, refresh the window, this is necessary
	//-------------------------------------------------------------------------
	void CTransparentDialogBase::OnActivate(UINT nState, CWnd* pWndOther, BOOL bMinimized)
	{
		TRACE( _T("OnActivate( %d, %d, %d)\n"), nState, pWndOther, bMinimized);

		CDialog::OnActivate(nState, pWndOther, bMinimized);

		if( nState == WA_ACTIVE )
		{
			Invalidate(TRUE);
		}
	}

	UINT __cdecl CTransparentDialogBase::ShowMotionThread( LPVOID pParam )
	{
		CTransparentDialogBase * pThis = static_cast<CTransparentDialogBase*>(pParam);

		while (pThis->m_nAlpha < 255)
		{
			pThis->m_nAlpha += 40;
			if( pThis->m_nAlpha > 255 )
				pThis->m_nAlpha = 255;

			::SendMessage( pThis->GetSafeHwnd(), WM_PAINT, 0, 0);
			Sleep(20);
		}
		
		return 0;
	}


	void CTransparentDialogBase::OnClose()
	{
		AfxBeginThread( (AFX_THREADPROC)CloseMotionThread, this);
	}

	UINT __cdecl CTransparentDialogBase::CloseMotionThread( LPVOID pParam )
	{
		CTransparentDialogBase * pThis = static_cast<CTransparentDialogBase*>(pParam);

		while (pThis->m_nAlpha > 0)
		{
			pThis->m_nAlpha -= 40;

			if( pThis->m_nAlpha < 0 )
				pThis->m_nAlpha = 0;

			::SendMessage( pThis->GetSafeHwnd(), WM_PAINT, 0, 0);
			Sleep(20);
		}

		pThis->EndDialog(IDOK);

		return 0;
	}


}











