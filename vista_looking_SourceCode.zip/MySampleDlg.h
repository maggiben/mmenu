// MySampleDlg.h : header file
//

#pragma once
#include "./ui/TransparentDialogBase.h"
using namespace UI;


// CMySampleDlg dialog
class CMySampleDlg : public CTransparentDialogBase
{
// Construction
public:
	CMySampleDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	enum { IDD = IDD_MYSAMPLE_DIALOG };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support


// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	virtual BOOL OnInitDialog();
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	DECLARE_MESSAGE_MAP()

	virtual void OnOK(){OnClose();}
	virtual void OnCancel(){OnClose();}
};
