#pragma once

#include <GdiPlus.h>
#pragma comment( lib, "gdiplus.lib" ) 
using namespace Gdiplus;

namespace Generic
{
	//-------------------------------------------------------------------------
	// Function Name    :GetModulePath
	// Parameter(s)     :HMODULE hModule	ģ����
	// Return           :ģ��·��
	// Create			:2007-1-10 11:24 ����
	// Memo             :��ȡģ��ľ���·��
	//-------------------------------------------------------------------------
	CString GetModulePath(HMODULE hModule = NULL);


	//-------------------------------------------------------------------------
	// Function Name    :ExtractResourceToFile
	// Parameter(s)     :UINT nResID			��ԴID
	//					:LPCTSTR lpszFilename	�ļ���
	//					:HMODULE hModule		ģ����
	// Return           :BOOL					�Ƿ�ɹ�
	// Create			:2007-1-8 17:35 ����
	// Memo             :����Դ�ͷŵ��ļ�
	//-------------------------------------------------------------------------
	BOOL ExtractResourceToFile(LPCTSTR lpszType, UINT nResID, LPCTSTR lpszFilename, HMODULE hModule = NULL);


	//-------------------------------------------------------------------------
	// Function Name    :IsFileExist
	// Parameter(s)     :LPCTSTR lpszFilePath
	// Return           :
	// Create			:2007-4-23 15:13 ����
	// Memo             :�ж��ļ��Ƿ����
	//-------------------------------------------------------------------------
	BOOL IsFileExist(LPCTSTR lpszFilePath);


	void Initialize(void);
	void Uninitialize(void);
}