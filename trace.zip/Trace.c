//
//	MODULE:		Trace.c
//
//	PURPOSE:	Provides TRACE macros (ala MFC) which wrap the 
//				OutputDebugString API call - removing these
//				calls in release build.
//
//	USAGE:		TRACE(...)  for TCHAR-strings
//				TRACEA(...) for char-strings
//				TRACEW(...) for WCHAR-strings
//
//	HISTORY:	v1.0 16/04/2002 J Brown		- Initial version
//

#define STRICT
#define WIN32_LEAN_AND_MEAN

#include <windows.h>
#include <stdarg.h>
#include "Trace.h"

//
//	Wide-character (UNICODE) version
//
void TraceW(LPCWSTR szFmt, ...)
{
	wchar_t szBuf[0x200];

	va_list arg;

	if(szFmt == 0) return;

	va_start(arg, szFmt);

	_vsnwprintf(0x200, szBuf, szFmt, arg);
	OutputDebugStringW(szBuf);
	
	va_end(arg);
}

//
//	Single-character (ANSI) version
//
void TraceA(LPCSTR szFmt, ...)
{
	char szBuf[0x200];

	va_list arg;

	if(szFmt == 0) return;

	va_start(arg, szFmt);

	_vsnprintf(0x200, szBuf, szFmt, arg);
	OutputDebugStringA(szBuf);
	
	va_end(arg);
}

