using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using System.Runtime.InteropServices;
using MenuLibrary;


namespace FullyCustomMenu
{
	public class Form1 : System.Windows.Forms.Form
	{
		#region Fields

		private System.Windows.Forms.MainMenu mainMenu1;
		private System.Windows.Forms.ContextMenu contextMenu1;
		private System.Windows.Forms.MenuItem menuItem8;
		private System.Windows.Forms.MenuItem menuItem9;
		private System.Windows.Forms.MenuItem menuItem10;
		private System.Windows.Forms.MenuItem menuItem11;
		private System.Windows.Forms.ListBox tracer;
		private System.Windows.Forms.ImageList images;
		private System.ComponentModel.IContainer components;

		delegate int MyWndProc(IntPtr hwnd, int msg, IntPtr wparam, IntPtr lparam);
		delegate void MyWndProc1(ref Message m);
		delegate int HookProc(int code, IntPtr wparam, ref CWPSTRUCT cwp);

		[DllImport("User32.dll",CharSet = CharSet.Auto, SetLastError = true)]
		static extern IntPtr GetWindowDC(IntPtr handle);

		[DllImport("User32.dll",CharSet = CharSet.Auto, SetLastError = true)]
		static extern bool GetWindowRect(IntPtr handle, ref RECT r);

		[DllImport("User32.dll",CharSet = CharSet.Auto, SetLastError = true)]
		static extern IntPtr SetWindowLong(IntPtr hwnd, int index, MyWndProc my);

		[DllImport("User32.dll",CharSet = CharSet.Auto, SetLastError = true)]
		static extern IntPtr SetWindowLong(IntPtr hwnd, int index, int style);

		[DllImport("User32.dll",CharSet = CharSet.Auto, SetLastError = true)]
		static extern IntPtr GetWindowLong(IntPtr hwnd, int index);

		[DllImport("User32.dll",CharSet = CharSet.Auto, SetLastError = true)]
		static extern IntPtr ReleaseDC(IntPtr handle, IntPtr hDC);

		[DllImport("User32.dll",CharSet = CharSet.Auto, SetLastError = true)]
		static extern int CallWindowProc(IntPtr wndProc, IntPtr hwnd, 
			int msg, IntPtr wparam,	IntPtr lparam);

		[DllImport("User32.dll",CharSet = CharSet.Auto, SetLastError = true)]
		static extern IntPtr SetWindowsHookEx(int type, HookProc hook, IntPtr instance, int threadID);

		[DllImport("User32.dll",CharSet = CharSet.Auto, SetLastError = true)]
		static extern bool UnhookWindowsHookEx(IntPtr hookHandle);

		[DllImport("User32.dll",CharSet = CharSet.Auto, SetLastError = true)]
		static extern int GetWindowThreadProcessId(IntPtr hwnd, int ID);

		[DllImport("User32.dll",CharSet = CharSet.Auto, SetLastError = true)]
		static extern IntPtr GetMenu(IntPtr hwnd);

		[DllImport("User32.dll",CharSet = CharSet.Auto, SetLastError = true)]
		static extern int GetClassName(IntPtr hwnd, char[] className, int maxCount);

		[DllImport("User32.dll",CharSet = CharSet.Auto, SetLastError = true)]
		static extern int CallNextHookEx(IntPtr hookHandle, int code, IntPtr wparam, ref CWPSTRUCT cwp);

		[DllImport("User32.dll",CharSet = CharSet.Auto, SetLastError = true)]
		static extern int SendMessage(IntPtr hwnd, int msg, IntPtr wparam, IntPtr lparam);

		[DllImport("Gdi32.dll",CharSet = CharSet.Auto, SetLastError = true)]
		static extern IntPtr CreateCompatibleDC(IntPtr hdc);

		[DllImport("User32.dll",CharSet = CharSet.Auto, SetLastError = true)]
		static extern IntPtr GetParent(IntPtr hwnd);

		[DllImport("User32.dll", CharSet=CharSet.Auto, SetLastError = true)]
		static extern bool AnimateWindow(IntPtr hwnd, uint dwTime, uint dwFlags);

		[DllImport("User32.dll", CharSet=CharSet.Auto, SetLastError = true)]
		static extern bool SetWindowPos(IntPtr hwnd, IntPtr hwndAfter, 
			int x, int y, int cx, int cy, uint flags);

		//[DllImport("User32.dll", CharSet=CharSet.Auto, SetLastError = true)]
		//static extern bool AdjustWindowRect(IntPtr hwnd
		
		//The win32 rectangle structure
		[StructLayout(LayoutKind.Sequential)]
		public struct RECT
		{
			public int left;
			public int top;
			public int right;
			public int bottom;
		}

		//Needed for the hook method
		[StructLayout(LayoutKind.Sequential)]
		public struct CWPSTRUCT
		{
			public IntPtr lparam;
			public IntPtr wparam;
			public int message;
			public IntPtr hwnd;
		}

		//Needed for filling the NCCALCSIZE_PARAMS struct
		[StructLayout(LayoutKind.Sequential)]
		public struct WINDOWPOS
		{
			public IntPtr hwnd;
			public IntPtr hwndAfter;
			public int x;
			public int y;
			public int cx;
			public int cy;
			public uint flags;
		}

		[StructLayout(LayoutKind.Sequential)]
		public struct NCCALCSIZE_PARAMS
		{
			public RECT rgc;
			public WINDOWPOS wndpos;
		}

		IntPtr defaultWndProc = IntPtr.Zero;//Pointer to menu's default WndProc
		MyWndProc subWndProc;//Delegate of type MyWndProc - needed to subclass the window
		HookProc hookProc;//This is delegate of type HookProc - needed to process the hooked window
		IntPtr hookHandle = IntPtr.Zero;//Pointer to hookProc
		IntPtr topPopupMenu = IntPtr.Zero;
		IntPtr firstPopupMenu = IntPtr.Zero;
		int itemWidth = 0;
		bool underTopItem = false;
		bool topItemSelected = false;
		
		#endregion

		#region Constructor

		public Form1()
		{
			InitializeComponent();
			//Construct the delegate that will process the hooked windows proc
			hookProc = new HookProc(Hooked);
			//Construct the delegate that will process the subclassed windows proc
			subWndProc = new MyWndProc(SubclassWndProc);

			InitMenuItems();

			if(Menu != null)
			{
				EventHandler e = new EventHandler(SelectedMenuItem);
				foreach(MenuItem mi in Menu.MenuItems)
				{
					AddSelectHandler(mi, e);					
					mi.Select += e;
				}
			}

			
			//Hook all the messages send through this form
			hookHandle = SetWindowsHookEx(4, hookProc, IntPtr.Zero ,GetWindowThreadProcessId(Handle,0));			
		}

		#endregion

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container();
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(Form1));
			this.mainMenu1 = new System.Windows.Forms.MainMenu();
			this.contextMenu1 = new System.Windows.Forms.ContextMenu();
			this.menuItem8 = new System.Windows.Forms.MenuItem();
			this.menuItem9 = new System.Windows.Forms.MenuItem();
			this.menuItem10 = new System.Windows.Forms.MenuItem();
			this.menuItem11 = new System.Windows.Forms.MenuItem();
			this.tracer = new System.Windows.Forms.ListBox();
			this.images = new System.Windows.Forms.ImageList(this.components);
			this.SuspendLayout();
			// 
			// contextMenu1
			// 
			this.contextMenu1.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																						 this.menuItem8,
																						 this.menuItem9,
																						 this.menuItem10,
																						 this.menuItem11});
			// 
			// menuItem8
			// 
			this.menuItem8.Index = 0;
			this.menuItem8.Text = "Test Item";
			// 
			// menuItem9
			// 
			this.menuItem9.Index = 1;
			this.menuItem9.Text = "Test Item";
			// 
			// menuItem10
			// 
			this.menuItem10.Index = 2;
			this.menuItem10.Text = "Test Item";
			// 
			// menuItem11
			// 
			this.menuItem11.Index = 3;
			this.menuItem11.Text = "Test Item";
			// 
			// tracer
			// 
			this.tracer.Dock = System.Windows.Forms.DockStyle.Fill;
			this.tracer.IntegralHeight = false;
			this.tracer.Name = "tracer";
			this.tracer.Size = new System.Drawing.Size(544, 430);
			this.tracer.TabIndex = 0;
			// 
			// images
			// 
			this.images.ColorDepth = System.Windows.Forms.ColorDepth.Depth8Bit;
			this.images.ImageSize = new System.Drawing.Size(16, 16);
			this.images.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("images.ImageStream")));
			this.images.TransparentColor = System.Drawing.Color.Transparent;
			// 
			// Form1
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.BackColor = System.Drawing.SystemColors.Window;
			this.ClientSize = new System.Drawing.Size(544, 430);
			this.ContextMenu = this.contextMenu1;
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.tracer});
			this.Menu = this.mainMenu1;
			this.Name = "Form1";
			this.Text = "Form1";
			this.ResumeLayout(false);

		}
		#endregion

		#region Subclassed wndProc

		int Hooked(int code, IntPtr wparam, ref CWPSTRUCT cwp)
		{
			switch(code)
			{
				case 0://HC_ACTION -> this means that the hook procedure should process the message
					//contained in CWPSTRUCT
				switch(cwp.message)
				{
					case 0x0001://WM_CREATE - catch this before the window is created
						string s = string.Empty;
						char[] className = new char[10];
						//Get the window class name
						int length = GetClassName(cwp.hwnd,className,9);
						//Convert it to string
						for(int i=0;i<length;i++)
							s += className[i];
						//Now check if the window is a menu
						if(s == "#32768")//System class for menu
							//if true - subclass the window
							defaultWndProc = SetWindowLong(cwp.hwnd, (-4), subWndProc);
						break;
				}
					break;
			}
			return CallNextHookEx(hookHandle,code,wparam, ref cwp);
		}

		int SubclassWndProc(IntPtr hwnd, int msg, IntPtr wparam, IntPtr lparam)
		{
			//tracer.Items.Add(msg.ToString());
			switch(msg)
			{
				/*case 0x0001://WM_CREATE					
					break;
				case 0x0018://WM_SHOWWINDOW
					
					return 0;*/
				case 0x0085://WM_NCPAINT
					IntPtr menuDC  = GetWindowDC(hwnd);					
					Graphics g = Graphics.FromHdc(menuDC);

					DrawBorder(g,underTopItem);
                    
					ReleaseDC(hwnd,menuDC);
					g.Dispose();
					return 0;
				//case 0x0046://WM_WINDOWPOSCHANGING
				//case 0x0047://WM_WINDOWPOSCHANGED
					//WINDOWPOS wpos = new WINDOWPOS();
					//wpos = (WINDOWPOS)Marshal.PtrToStructure(lparam,typeof(WINDOWPOS));
					//SetWindowPos(hwnd,IntPtr.Zero,wpos.x+2,wpos.y+2,wpos.cx,wpos.cy,0x0004);
					//SendMessage(hwnd,0x0317,IntPtr.Zero,lparam);
					//return 0;
				case 0x0083://WM_NCCALCSIZE
					/*//Get the NCCALCSIZE_PARAMS from the lparam pointer
					NCCALCSIZE_PARAMS calc = (NCCALCSIZE_PARAMS)Marshal.PtrToStructure(lparam,typeof(NCCALCSIZE_PARAMS));
					//Now adjust the borders of the menu window
					calc.rgc.top += 5;
					calc.rgc.right += 5;					
					calc.rgc.right -= 5;
					calc.rgc.bottom -= 5;
					//IntPtr newWparam = Marshal.AllocCoTaskMem(Marshal.SizeOf(calc));
					//Marshal.StructureToPtr(calc,newWparam,true);
					CallWindowProc(defaultWndProc,hwnd,msg,wparam,lparam);
					return 0;*/
					break;
				/*case 0x0014://WM_ERASEBKGND -> This message uccurs before WM_NCPAINT
					//So send the message WM_NCPAINT
					g = Graphics.FromHdc(wparam);
					g.Clear(SystemColors.Menu);
					g.Dispose();
					SendMessage(hwnd, 0x0085, wparam, lparam);					
					break;*/
				case 0x0317://WM_PRINT
					int result = CallWindowProc(defaultWndProc,hwnd,msg,wparam,lparam);
					menuDC  = wparam;
					g = Graphics.FromHdc(menuDC);
					//Draw the border around the menu
					DrawBorder(g,underTopItem);
                    
					ReleaseDC(hwnd,menuDC);
					g.Dispose();
					return result;
			}			
			return CallWindowProc(defaultWndProc,hwnd,msg,wparam,lparam);
		}

		#endregion

		#region MainForm WndProc

		protected override void WndProc(ref Message m)
		{
			switch(m.Msg)
			{
				case 0x0125://WM_UNINITMENUPOPUP
					//Set the underTopItem flag to false
					if(underTopItem)
						underTopItem = false;					
					base.WndProc(ref m);
					break;
				case 0x0002://WM_DESTROY -> we have to unhook the hooked windows
					UnhookWindowsHookEx(hookHandle);					
					base.WndProc(ref m);
					break;
				default:
					base.WndProc(ref m);
					break;
			}
		}
		
		#endregion

		#region Event Handlers

		void SelectedMenuItem(object sender, EventArgs e)
		{
			if(sender is TopMenuItem)
			{
				itemWidth = ((TopMenuItem)sender).Width;
				underTopItem = true;
			}
			else
			{
				MenuItem m = sender as MenuItem;
				if(m.IsParent)
					underTopItem = false;
				else
				{
					if(m.Parent is TopMenuItem)
						underTopItem = true;
				
					else
						underTopItem = false;					
				}
			}			
		}

		void TopMenuItemsPopup(object sender, EventArgs e)
		{			
		}

		#endregion

		#region Support methods

		void AddSelectHandler(MenuItem mi, EventHandler e)
		{
			foreach(MenuItem m in mi.MenuItems)
			{
				m.Select += e;
				if(m.IsParent)
					AddSelectHandler(m, e);
			}
		}

		void DrawBorder(Graphics g, bool underTop)
		{
			Rectangle r = new Rectangle(0,0,(int)g.VisibleClipBounds.Width-1, 
				(int)g.VisibleClipBounds.Height-1);					
			Rectangle r1 = new Rectangle(1,1,(int)g.VisibleClipBounds.Width-3, 
				(int)g.VisibleClipBounds.Height-3);
			Rectangle r2 = new Rectangle(2,2,(int)g.VisibleClipBounds.Width-5, 
				(int)g.VisibleClipBounds.Height-5);

			if(underTop)
			{
				g.DrawLine(Pens.Black,r.Left,r.Bottom,r.Left,r.Top);
				g.DrawLine(new Pen(SystemColors.Menu),r.Left+1,r.Top,
					r.Left+itemWidth-2,r.Top);
				g.DrawLine(Pens.Black,r.Left+itemWidth-1,r.Top,r.Right,r.Top);
				g.DrawLine(Pens.Black,r.Right,r.Top,r.Right,r.Bottom);
				g.DrawLine(Pens.Black,r.Left,r.Bottom,r.Right,r.Bottom);
			}
			else
				g.DrawRectangle(Pens.Black,r);

			g.DrawRectangle(new Pen(SystemColors.Menu),r1);
			g.DrawRectangle(new Pen(SystemColors.Menu),r2);
		}

		void InitMenuItems()
		{
			TopMenuItem tmi = new TopMenuItem("Test Item 1");
			TopMenuItem tmi1 = new TopMenuItem("Test Item 2");
			TopMenuItem tmi2 = new TopMenuItem("Test Item 3");

			Menu.MenuItems.AddRange(new MenuItem[]{tmi,tmi1,tmi2});

			MyMenuItem mi1 = new MyMenuItem("Test Item");
			mi1.ItemImage = images.Images[0];
			MyMenuItem mi2 = new MyMenuItem("Test Item");
			mi2.ItemImage = images.Images[1];
			MyMenuItem mi3 = new MyMenuItem("Test Item");
			mi3.ItemImage = images.Images[2];			

			Menu.MenuItems[0].MenuItems.AddRange(new MenuItem[]{mi1,mi2,mi3});

			MyMenuItem mi4 = new MyMenuItem("Test Item");
			MyMenuItem mi5 = new MyMenuItem("Test Item");
			MyMenuItem mi6 = new MyMenuItem("Test Item");

			Menu.MenuItems[1].MenuItems.AddRange(new MenuItem[]{mi4,mi5,mi6});

			MyMenuItem mi7 = new MyMenuItem("Test Item");
			MyMenuItem mi8 = new MyMenuItem("Test Item");
			MyMenuItem mi9 = new MyMenuItem("Test Item");

			Menu.MenuItems[1].MenuItems[2].MenuItems.AddRange(new MenuItem[]{mi7,mi8,mi9});

			MyMenuItem mi10 = new MyMenuItem("Test Item");
			MyMenuItem mi11 = new MyMenuItem("Test Item");
			MyMenuItem mi12 = new MyMenuItem("Test Item");

			Menu.MenuItems[1].MenuItems[2].MenuItems[2].MenuItems.AddRange(new MenuItem[]
															{mi10,mi11,mi12});

			MyMenuItem mi13 = new MyMenuItem("Test Item");
			mi13.ItemImage = images.Images[0];
			mi13.Shortcut = Shortcut.CtrlShiftP;
			mi13.Enabled = false;
			MyMenuItem mi14 = new MyMenuItem("Test Item");
			mi14.ItemImage = images.Images[1];
			MyMenuItem mi15 = new MyMenuItem("Test Item");
			mi15.ItemImage = images.Images[2];
			MyMenuItem mi31 = new MyMenuItem("-");
			MyMenuItem mi16 = new MyMenuItem("Test Item");
			mi16.ItemImage = images.Images[3];
			MyMenuItem mi17 = new MyMenuItem("Test Item");
			mi17.ItemImage = images.Images[4];
			MyMenuItem mi18 = new MyMenuItem("Test Item");
			mi18.ItemImage = images.Images[5];

			Menu.MenuItems[2].MenuItems.AddRange(new MenuItem[]
											{mi13,mi14,mi15,mi31,mi16,mi17,mi18});
		}

		#endregion

		[STAThread]
		static void Main() 
		{
			Application.Run(new Form1());
		}
	}
}
