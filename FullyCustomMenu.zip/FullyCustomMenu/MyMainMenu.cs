using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using System.Runtime.InteropServices;
using System.Reflection;//Required for module class
using System.Security.Permissions;//Required for permissions

namespace FullyCustomMenu
{
	public class MyMainMenu : MainMenu
	{
		delegate int MyWndProc(IntPtr hwnd, int msg, IntPtr wparam, IntPtr lparam);
		delegate void MyWndProc1(ref Message m);
		delegate int HookProc(int code, IntPtr wparam, IntPtr lparam);

		[DllImport("User32.dll",CharSet = CharSet.Auto, SetLastError = true)]
		static extern IntPtr GetWindowDC(IntPtr handle);

		[DllImport("User32.dll",CharSet = CharSet.Auto, SetLastError = true)]
		static extern bool GetWindowRect(IntPtr handle);

		[DllImport("User32.dll",CharSet = CharSet.Auto, SetLastError = true)]
		static extern MyWndProc SetWindowLong(IntPtr hwnd, int index, MyWndProc my);

		[DllImport("User32.dll",CharSet = CharSet.Auto, SetLastError = true)]
		static extern IntPtr GetWindowLong(IntPtr hwnd, int index);

		[DllImport("User32.dll",CharSet = CharSet.Auto, SetLastError = true)]
		static extern IntPtr ReleaseDC(IntPtr handle, IntPtr hDC);

		[DllImport("User32.dll",CharSet = CharSet.Auto, SetLastError = true)]
		static extern int CallWindowProc(MyWndProc my, IntPtr hwnd, 
											int msg, IntPtr wparam,	IntPtr lparam);

		[DllImport("User32.dll",CharSet = CharSet.Auto, SetLastError = true)]
		static extern IntPtr SetWindowsHookEx(int type, HookProc hook, IntPtr instance, int threadID);

		[DllImport("User32.dll",CharSet = CharSet.Auto, SetLastError = true)]
		static extern bool UnhookWindowsHookEx(IntPtr hookHandle);

		[DllImport("Kernel32.dll",CharSet = CharSet.Auto, SetLastError = true)]
		static extern int GetCurrentThreadId();

		MyWndProc defaultWndProc;
		MyWndProc subWndProc;
		HookProc hp;
		IntPtr hookHandle = IntPtr.Zero;
		
		public MyMainMenu()
		{
			//sec = new SecurityPermission(PermissionState.Unrestricted);

			hp = new HookProc(Hooked);
			subWndProc = new MyWndProc(SubclassWndProc);
			//Current Module
			Assembly main = Assembly.GetExecutingAssembly();
			Module[] m = main.GetModules();	
	
			SecurityPermission sec = new SecurityPermission(SecurityPermissionFlag.UnmanagedCode);
			sec.Assert();

			int id = GetCurrentThreadId();
			MessageBox.Show(id.ToString());
			
			hookHandle = SetWindowsHookEx(12, hp, Marshal.GetHINSTANCE(m[0]),GetCurrentThreadId());
			MessageBox.Show("Last error : "+Marshal.GetLastWin32Error().ToString());			

			defaultWndProc = SetWindowLong(this.Handle, (-4), subWndProc);
			MessageBox.Show("Last error : "+Marshal.GetLastWin32Error().ToString());
		}
		~MyMainMenu()
		{
			UnhookWindowsHookEx(hookHandle);
		}

		#region Hooked & subclassed menu

		int Hooked(int code, IntPtr wparam, IntPtr lparam)
		{
			return 0;
		}

		int SubclassWndProc(IntPtr hwnd, int msg, IntPtr wparam, IntPtr lparam)
		{
			switch(msg)
			{
				case 0x0085://WM_NCPAINT
					//IntPtr hDC = GetWindowDC(Handle);
					//Graphics g = Graphics.FromHdc(hDC);

					MessageBox.Show("Finally");

					//ReleaseDC(Handle, hDC);
					//g.Dispose();
					//g.FillRectangle(Brushes.Black,g.ClipBounds);
					return 1;
				default:
					CallWindowProc(defaultWndProc,Handle,msg,wparam,lparam);					
					return 1;
			}			
		}

		#endregion

		
	}
}
