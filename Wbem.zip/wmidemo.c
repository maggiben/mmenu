/*
strComputer = "."
Set objSWbemLocator = CreateObject("WbemScripting.SWbemLocator")
Set objSWbemServices = objSWbemLocator.ConnectServer(strComputer, "root\cimv2")
Set colSWbemObjectSet = objSWbemServices.InstancesOf("Win32_Service")
For Each objSWbemObject In colSWbemObjectSet
    Wscript.Echo "Name: " & objSWbemObject.Name
Next
*/
#include <windows.h>
#include <tchar.h>
#include <oleauto.h>
#include <stdio.h>
#include <wbemdisp.h>

#ifdef __LCC__
#pragma lib <oleaut32.lib>
#pragma lib <ole32.lib>
#pragma lib <uuid.lib>
#endif


LPTSTR _stdcall ErrorString(DWORD errno)
{

	static TCHAR szMsgBuf[0x1000];

	DWORD msglen = FormatMessage(FORMAT_MESSAGE_FROM_SYSTEM
		    , NULL
		    , errno
		    , MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT)
		    , (LPTSTR) &szMsgBuf
		    , 0x1000 * sizeof(TCHAR)
		    , NULL);

	do { if ( (msglen) != (msglen) ); } while(0);

	return szMsgBuf;

}

#define ERROROUT(r, msg) \
	do { _tprintf(_T("%s - %s - %08X\n"), (LPTSTR)(msg), ErrorString((DWORD)(r)), (DWORD)(r)); } while(0)


int main(void)
{
	int retval = 0;
	HRESULT hr = S_OK;

// declare interfaces
	ISWbemLocator *pISWbemLocator = NULL;
	ISWbemServices *pISWbemServices = NULL;
	ISWbemObjectSet *pISWbemObjectSet = NULL;
	ISWbemObject *pISWbemObject = NULL;
	IEnumVARIANT *pIEnumVARIANT = NULL;
	VARIANT varISWbemObject;

// get the clsid for the ProgId
	CLSID clsid;
	WCHAR *lpszProgID  = L"WbemScripting.SWbemLocator";

// establish connection parameters
	BSTR strComputer = SysAllocString(L"."); // use localhost for services
	BSTR strNameSpace = SysAllocString(L"root\\cimv2");
	BSTR strUser = SysAllocString(L"");
	BSTR strPassword = SysAllocString(L"");
	BSTR strLocale = SysAllocString(L"");
	BSTR strAuthority = SysAllocString(L"");

// wbemConnectFlagUseMaxWait throws wbemErrInvalidParameter
// probably because target host is local not remote
	long iSecurityFlags = 0;

// establish InstancesOf parameters
	BSTR strClass = SysAllocString(L"Win32_Service");
//	BSTR strClass = SysAllocString(L"Win32_OperatingSystem");
	long iFlags = wbemFlagReturnImmediately; // 0x10

// parameters for GetObjectText_
	BSTR strMofText = NULL;
	DWORD cbDest = 0;
	WCHAR *pString = NULL;

// loop counter
	int i = 0;

// initialize com
//	hr = CoInitializeEx(0, COINIT_MULTITHREADED); // this bombs
	hr = CoInitialize(NULL);
	if ( FAILED(hr) ) {
		ERROROUT(hr, _T("CoInitialize"));
		retval = 1;
		goto string_exit;
	}

// get the clsid for the ProgId
	hr = CLSIDFromProgID(lpszProgID, &clsid);
	if ( FAILED(hr) ) {
		ERROROUT(hr, _T("CLSIDFromProgID"));
		retval = 1;
		goto init_exit;
	}

#if 0
// dump the clsid for examination
	WCHAR szGUID[64];
	StringFromGUID2(&clsid,szGUID,64);

#ifdef UNICODE
	_tprintf(_T("%s\n"), szGUID);
#else
	_tprintf(_T("%S\n"), szGUID);
#endif

#endif

// create a single object of the ISWbemLocator class
	hr = CoCreateInstance(&clsid, NULL, CLSCTX_INPROC_SERVER,
			(REFIID)&IID_ISWbemLocator, (void **)&pISWbemLocator);
	if ( FAILED(hr) ) {
		ERROROUT(hr, _T("CoCreateInstance"));
		retval = 1;
		goto init_exit;
	}

// connect to host computer
	hr = pISWbemLocator->lpVtbl->ConnectServer(pISWbemLocator,
                                      strComputer, strNameSpace,
									  strUser, strPassword,
									  strLocale, strAuthority,
									  iSecurityFlags, NULL,
		                              &pISWbemServices);
	if ( FAILED(hr) ) {
		ERROROUT(hr, _T("pISWbemLocator->lpVtbl->ConnectServer"));
		retval = 1;
		goto locator_exit;
	}

// acquire class object set
	hr = pISWbemServices->lpVtbl->InstancesOf(pISWbemServices, strClass, iFlags, NULL, &pISWbemObjectSet);
	if ( FAILED(hr) ) {
		ERROROUT(hr, _T("pISWbemServices->lpVtbl->InstancesOf"));
		retval = 1;
		goto services_exit;
	}

// acquire object set enumerator
	hr = pISWbemObjectSet->lpVtbl->get__NewEnum(pISWbemObjectSet, (IUnknown**)&pIEnumVARIANT);
	if ( FAILED(hr) ) {
		ERROROUT(hr, _T("pISWbemObjectSet->lpVtbl->get__NewEnum"));
		retval = 1;
		goto services_exit;
	}

// begin enumeration
	VariantInit(&varISWbemObject);

	hr = pIEnumVARIANT->lpVtbl->Next(pIEnumVARIANT, 1, &varISWbemObject, NULL);
	if ( FAILED(hr) ) {
		ERROROUT(hr, _T("pIEnumVARIANT->lpVtbl->Next"));
		retval = 1;
		goto variant_exit;
	}

	while ( S_OK == hr ) {

		// display iteration count
		_tprintf(_T("%2d\n"), i++);

		// check for IDispatch interface
		if ( VT_DISPATCH == varISWbemObject.vt ) {

			// cast IDispatch to ISWbemObject
			pISWbemObject = (ISWbemObject*)varISWbemObject.pdispVal;

			// acquire reference - required
			pISWbemObject->lpVtbl->AddRef(pISWbemObject);

			// get the textual representation of the ISWbemObject
			hr = pISWbemObject->lpVtbl->GetObjectText_(pISWbemObject, 0, &strMofText);
			if ( FAILED(hr)) {
				ERROROUT(hr, _T("pISWbemObject->lpVtbl->GetObjectText_"));
				pISWbemObject->lpVtbl->Release(pISWbemObject);
				retval = 1;
				goto variant_exit;
			}

			// copy BSTR to WCHAR string for output
			cbDest = ( 1 + SysStringLen(strMofText) ) * sizeof(WCHAR);
			pString = malloc(cbDest);
			if ( NULL == pString ) {
				ERROROUT(hr, _T("malloc"));
				retval = 1;
				// system supplies this string - it probably needs to be freed
				SysFreeString(strMofText);
				pISWbemObject->lpVtbl->Release(pISWbemObject);
				goto variant_exit;
			}

			memcpy(pString, strMofText, cbDest);

#ifdef UNICODE
			_tprintf(_T("%s\n"), pString);
#else
			_tprintf(_T("%S\n"), pString);
#endif

			// cleanup
			free(pString);
			cbDest = 0;

			// system supplies this string - it probably needs to be freed
			SysFreeString(strMofText);
			strMofText = NULL;

			// release reference
			pISWbemObject->lpVtbl->Release(pISWbemObject);

		}

		// clear the variant
		VariantClear(&varISWbemObject);

		// reinitialize the variant
		VariantInit(&varISWbemObject);

		// acquire next item in enumeration
		hr = pIEnumVARIANT->lpVtbl->Next(pIEnumVARIANT, 1, &varISWbemObject, NULL);
		if ( FAILED(hr) ) {
			ERROROUT(hr, _T("pIEnumVARIANT->lpVtbl->Next"));
			retval = 1;
			goto variant_exit;
		}
	}

variant_exit:
	VariantClear(&varISWbemObject);
	pIEnumVARIANT->lpVtbl->Release(pIEnumVARIANT);

services_exit:
	pISWbemServices->lpVtbl->Release(pISWbemServices);

locator_exit:
	pISWbemLocator->lpVtbl->Release(pISWbemLocator);

init_exit:
	CoUninitialize();

string_exit:
	SysFreeString(strComputer);
	SysFreeString(strNameSpace);
	SysFreeString(strUser);
	SysFreeString(strPassword);
	SysFreeString(strLocale);
	SysFreeString(strAuthority);

	SysFreeString(strClass);

	return retval;

}
