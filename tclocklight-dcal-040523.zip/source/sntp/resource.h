// icons
#define IDI_TCSNTP                      101
#define IDI_TCLOCK                      102
#define IDI_PLAY                        103
#define IDI_STOP                        104

// dialog
#define IDD_DIALOG                      101

// dialog controls
#define IDC_NTPSERVER                   1001
#define IDC_SYNCNOW                     1002
#define IDC_DELSERVER                   1003
#define IDC_TIMEOUT                     1004
#define IDC_TIMEOUTSPIN                 1005
#define IDC_SNTPLOG                     1006
#define IDC_SYNCSOUND                   1007
#define IDC_SYNCSOUNDBROWSE             1008
#define IDC_SNTPLOGRESULT               1009
#define IDC_MYHELP                      1010

#define IDC_STATIC                      -1

// strings

