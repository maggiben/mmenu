This custom control is a font selection combo box similar to the font selection
control in Word 2000.

Creating the control:
Use the SELECT_FONT_CLASS macro as the window class name. 
The height provided to CreateWindow is ignored. Like a normal combo box the font
control will resize its height to fit the font. No items are added at creation.

	hwndFont = CreateWindowEx(0, SELECT_FONT_CLASS, TEXT(""), WS_CHILD | WS_VISIBLE,
	                          50, 20, 200, 0,
	                          hwnd, (HMENU) NULL, GetModuleHandle(NULL), NULL);


-- Messages:

FCM_ADD_ALL_FONTS:
This will enumerate the available fonts on the system and add them to the control.

	SendMessage(hwndFont, FCM_ADD_ALL_FONTS, 0, 0);

WM_SETFONT:
This message will set the font that is used to render the combo box edit field.

	SendMessage(hwndFont, WM_SETFONT, (WPARAM) hFont, FALSE);

Other messages:
Other messages can be sent directly to the contained combo box. The identifier 
of the combo box is FC_COMBO.

	SendDlgItemMessage(hwndFont, FC_COMBO, CB_SELECTSTRING, (WPARAM) -1, (LPARAM) TEXT("Comic Sans MS"));
	SendDlgItemMessage(hwndFont, FC_COMBO, CB_INSERTSTRING, (WPARAM)  0, (LPARAM) TEXT("Terminal"));


-- Notifications:

The font control passes through WM_COMMAND notifications from the contained combo box.
The notification of most interest is CBN_SELENDOK which specifies a new item has been
selected. The currently selected item can be retrieved using GetWindowText().


-- Dialog Boxes:

The font control can be used in a dialog box. A typical entry in a resource script
would look like:

	CONTROL "", ID_FONT, SELECT_FONT_CLASS, WS_CHILD | WS_VISIBLE | WS_TABSTOP, 50, 50, 200, 0


-- Ideas:

The control currently creates each font every time an item needs to be rendered.
It would improve speed to cache the font handles using CB_SETITEMDATA. The control
does not render a true-type glyph next to true-type fonts like the Word version does.
If you decide to make these or other additions to the code please consider contributing
back to the site.


-- Author and acknowledgements:
This code is by tmouse (tmouse a!t bigfoot d!o!t com). It is based loosely
on MFC code by Chris Losinger and Dave Schumann at
http://www.thecodeproject.com/combobox/fontcombo.asp


Version 1, August 2004.
