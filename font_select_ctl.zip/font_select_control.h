#ifndef FONT_SELECT_CONTROL_H
#define FONT_SELECT_CONTROL_H

#include <windows.h>

#ifdef __cplusplus
extern "C" {
#endif

#define SELECT_FONT_CLASS TEXT("xSelectFontCtrl")
#define FCM_ADD_ALL_FONTS (WM_USER + 10)
#define FC_COMBO          (1)


BOOL xRegisterFontControl(void);

#ifdef __cplusplus
}
#endif


#endif /* FONT_SELECT_CONTROL_H */

