#include <windows.h>

#include "font_select_control.h"

static HFONT hFont;


static LRESULT CALLBACK WndProc(HWND Window, UINT Message, WPARAM wParam, LPARAM lParam)
{
	switch(Message)
	{
		case WM_CLOSE:
		{
			break;
		}

		case WM_COMMAND:
		{
			WORD wCtrlID = LOWORD(wParam);
			WORD wCmdID  = HIWORD(wParam);

			switch (wCmdID)
			{
				// Handle notifications from our font controls.
				case CBN_SELENDOK:
				{
					// An item has been selected. Just show it in a message box.
					TCHAR szFont[512];
					
					if (GetWindowText((HWND) lParam, szFont, 512))
						MessageBox(NULL, szFont, TEXT("Selected Font"), 0);

					break;
				}
			}
			break;
		}

		case WM_DESTROY:
		{
			DeleteObject(hFont);
			PostQuitMessage(0);
			return 0;
		}
	}
	return DefWindowProc(Window, Message, wParam, lParam);
}

//+-----------------------------------------------------------------------------

BOOL Setup(void)
{
	WNDCLASSEX wc = { 0 };
	HWND       hwnd, hwndCombo, hwndFont;
	int        i;
	
	wc.cbSize          = sizeof(WNDCLASSEX);
	wc.style           = CS_HREDRAW | CS_VREDRAW;
	wc.hInstance       = GetModuleHandle(NULL);
	wc.hCursor         = LoadCursor(NULL, IDC_ARROW);
	wc.hIconSm         = NULL;
	wc.hIcon           = LoadIcon(NULL, IDI_APPLICATION);
	wc.lpfnWndProc     = WndProc;
	wc.hbrBackground   = (HBRUSH) (COLOR_APPWORKSPACE + 1);
	wc.lpszMenuName    = NULL;
	wc.lpszClassName   = TEXT("MainClass");

	if(!RegisterClassEx(&wc)) return FALSE;

	// Create main window.
	hwnd = CreateWindowEx(0, TEXT("MainClass"), TEXT("Font Control Sample"), WS_OVERLAPPEDWINDOW | WS_VISIBLE,
	                      100, 100, 500, 400,
	                      NULL, NULL, GetModuleHandle(NULL), NULL);

	if(!hwnd) return FALSE;

	// Register font control class.
	if (!xRegisterFontControl()) return FALSE;


// --- Sample font control 1 --- //
	// Create font control.
	hwndFont = CreateWindowEx(0, SELECT_FONT_CLASS, TEXT(""), WS_CHILD | WS_VISIBLE,
	                          50, 20, 200, 0,
	                          hwnd, (HMENU) NULL, GetModuleHandle(NULL), NULL);
	// Add all available fonts.
	SendMessage(hwndFont, FCM_ADD_ALL_FONTS, 0, 0);

	// Start with "Comic Sans MS" selected.
	SendDlgItemMessage(hwndFont, FC_COMBO, CB_SELECTSTRING, (WPARAM) -1, (LPARAM) TEXT("Comic Sans MS"));	


// --- Sample font control 2 --- //
	// Create font control.
	hwndFont = CreateWindowEx(0, SELECT_FONT_CLASS, TEXT(""), WS_CHILD | WS_VISIBLE,
	                          50, 60, 200, 0,
	                          hwnd, (HMENU) NULL, GetModuleHandle(NULL), NULL);

	// Add only a few fonts.
	SendDlgItemMessage(hwndFont, FC_COMBO, CB_ADDSTRING, 0, (LPARAM) TEXT("Comic Sans MS"));
	SendDlgItemMessage(hwndFont, FC_COMBO, CB_ADDSTRING, 0, (LPARAM) TEXT("Arial"));
	SendDlgItemMessage(hwndFont, FC_COMBO, CB_ADDSTRING, 0, (LPARAM) TEXT("Courier"));
	SendDlgItemMessage(hwndFont, FC_COMBO, CB_ADDSTRING, 0, (LPARAM) TEXT("Times New Roman"));
	SendDlgItemMessage(hwndFont, FC_COMBO, CB_ADDSTRING, 0, (LPARAM) TEXT("Wingdings"));

	// Use a large Arial font for the edit field.
	hFont = CreateFont(35, 0, 0, 0, FW_NORMAL, FALSE, FALSE, FALSE, DEFAULT_CHARSET, OUT_DEFAULT_PRECIS,
		               CLIP_DEFAULT_PRECIS, DEFAULT_QUALITY, DEFAULT_PITCH | FF_DONTCARE, TEXT("Arial"));
	SendMessage(hwndFont, WM_SETFONT, (WPARAM) hFont, FALSE);


// --- Sample font control 3 --- //
	// Create font control.
	hwndFont = CreateWindowEx(0, SELECT_FONT_CLASS, TEXT(""), WS_CHILD | WS_VISIBLE,
	                          50, 150, 200, 0,
	                          hwnd, (HMENU) NULL, GetModuleHandle(NULL), NULL);

	// Add all available fonts.
	SendMessage(hwndFont, FCM_ADD_ALL_FONTS, 0, 0);

	// Now we will create a most recently used (MRU) list at the top.
	// First, insert a divider.
	SendDlgItemMessage(hwndFont, FC_COMBO, CB_INSERTSTRING, 0, (LPARAM) TEXT("----------"));

	// Now insert the most recently used fonts.
	SendDlgItemMessage(hwndFont, FC_COMBO, CB_INSERTSTRING, 0, (LPARAM) TEXT("Comic Sans MS"));
	SendDlgItemMessage(hwndFont, FC_COMBO, CB_INSERTSTRING, 0, (LPARAM) TEXT("Terminal"));
	SendDlgItemMessage(hwndFont, FC_COMBO, CB_INSERTSTRING, 0, (LPARAM) TEXT("MS Sans Serif"));

	// Use the default GUI font for the edit field.
	SendMessage(hwndFont, WM_SETFONT, (WPARAM) GetStockObject(DEFAULT_GUI_FONT), FALSE);


// -- Normal combo box - to compare behaviour --- //
	hwndCombo = CreateWindowEx(0, TEXT("COMBOBOX"), TEXT(""), CBS_DROPDOWNLIST | WS_CHILD | WS_VISIBLE | WS_VSCROLL,
	                           280, 20, 200, 150,
	                           hwnd, (HMENU) NULL, GetModuleHandle(NULL), NULL);
	// Add some items.
	for (i = 0;i < 100;i++)
	{
		SendMessage(hwndCombo, CB_ADDSTRING, 0, (LPARAM) TEXT("Normal Combo Box"));
		SendMessage(hwndCombo, CB_ADDSTRING, 0, (LPARAM) TEXT("Not a font control"));
		SendMessage(hwndCombo, CB_ADDSTRING, 0, (LPARAM) TEXT("I have ran out of things to say"));
	}

	return TRUE;
}

//+-----------------------------------------------------------------------------

INT WINAPI WinMain(HINSTANCE hInstance, HINSTANCE reserved, LPSTR lpCommand, INT nCmdShow)
{
	MSG msg;

	if(!Setup()) return -1;

	while(GetMessage(&msg, NULL, 0, 0))
	{
		TranslateMessage(&msg);
		DispatchMessage(&msg);
	}
	return msg.wParam;
}

