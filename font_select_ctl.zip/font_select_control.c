#include <windows.h>
#include <tchar.h>
#include "font_select_control.h"

#ifdef _MSC_VER
#pragma comment(lib, "gdi32.lib")
#pragma comment(lib, "user32.lib")
#endif

#define SAMPLE_TEXT    TEXT(" abXY12")
#define ARRAYSIZE(arr) (sizeof(arr)/sizeof((arr)[0]))
static const int ID_COMBO           = FC_COMBO;
static const int GWL_FONT_HEIGHT    = 0;
static const int GWL_MAX_ITEM_WIDTH = 4;
static const int GWL_DEFAULT_FONT   = 8;
static const int ITEM_POINT_SIZE    = 14;


/* 
 * Font enumeration callback procedure.
 */
static int CALLBACK EnumFontProc (ENUMLOGFONTEX* lpelfe,
             NEWTEXTMETRICEX* lpntme, int iFontType, LPARAM lParam)
{
	SendMessage((HWND) lParam, CB_ADDSTRING, 0, (LPARAM) lpelfe->elfLogFont.lfFaceName);
	return TRUE;
}


/*
 * Enumerates fonts that support the current input locale as well as
 * symbol fonts such as wingdings.
 * http://www.microsoft.com/globaldev/getwr/steps/wrg_font.mspx
 */
static BOOL WINAPI sAddFonts(HWND hwndCombo)
{
	DWORD   dwCodePage;
	HKL     hkl = GetKeyboardLayout(0);
	LOGFONT lf;
	HDC     hDc;
	CHARSETINFO cs;
	TCHAR   szLocaleData[10];

	// Initialize the LOGFONT to be used.
	lf.lfFaceName[0] = TEXT('\0');
	lf.lfCharSet     = DEFAULT_CHARSET;

	// This is a workaround for Hindi and Tamil, since they
	//    don't have charsets. Just enumerate all fonts in that case.
	if (LOWORD(hkl) != MAKELANGID(/* LANG_HINDI */ 0x39, SUBLANG_DEFAULT) &&
	    LOWORD(hkl) != MAKELANGID(/* LANG_TAMIL */ 0x49, SUBLANG_DEFAULT))
	{
		// Find out what Charset the new kbd wants.
		GetLocaleInfo (LOWORD(hkl), LOCALE_IDEFAULTANSICODEPAGE, szLocaleData, ARRAYSIZE(szLocaleData));
		dwCodePage = _ttol (szLocaleData);
		if (TranslateCharsetInfo ((DWORD*) dwCodePage, &cs, TCI_SRCCODEPAGE))
			lf.lfCharSet = (BYTE) cs.ciCharset;
	}

	SendMessage(hwndCombo, CB_INITSTORAGE, 100, 50 * sizeof(TCHAR));

	hDc = GetDC (hwndCombo);

	// Get list of fonts that support this charset.
	EnumFontFamiliesEx (hDc, &lf, (FONTENUMPROC) EnumFontProc, (LPARAM) hwndCombo, 0);

	// Get list of symbol fonts.
	lf.lfFaceName[0] = TEXT('\0');
	lf.lfCharSet     = SYMBOL_CHARSET;
	EnumFontFamiliesEx (hDc, &lf, (FONTENUMPROC) EnumFontProc, (LPARAM) hwndCombo, 0);

	ReleaseDC (hwndCombo, hDc);
	return TRUE;
}


/*
// Use this instead if you want all fonts.
static int CALLBACK sEnumFontsProc(
  CONST LOGFONT *lplf,     // logical-font data
  CONST TEXTMETRIC *lptm,  // physical-font data
  DWORD dwType,            // font type
  LPARAM lpData            // application-defined data
)
{
	SendMessage((HWND) lpData, CB_ADDSTRING, 0, (LPARAM) lplf->lfFaceName);
	return TRUE;
}

static BOOL WINAPI sAddFonts(HWND hwndCombo)
{
	HDC hdc = GetDC(hwndCombo);
	SendMessage(hwndCombo, CB_INITSTORAGE, 100, 50 * sizeof(TCHAR));
	EnumFonts(hdc, NULL, sEnumFontsProc, (LPARAM) hwndCombo);
	ReleaseDC(hwndCombo, hdc);
	return TRUE;
}
*/


/*
 * Get text for combo box item. Fails if text won't fit in buffer.
 */
static BOOL sGetComboItemText(HWND hwndDlg, int ctlID, int itemID, LPTSTR szText, INT cchText)
{
	LRESULT nRet = SendDlgItemMessage(hwndDlg, ctlID, CB_GETLBTEXTLEN, itemID, 0);

	if (nRet != CB_ERR && nRet < cchText)
	{
		return (CB_ERR != SendDlgItemMessage(hwndDlg, ID_COMBO, CB_GETLBTEXT, itemID, (LPARAM) szText));
	}
	return FALSE;
}


/*
 * Provides width and height for an item.
 */
static BOOL WINAPI sMeasureItem(HWND hwnd, LPMEASUREITEMSTRUCT lpMeasure)
{
	TCHAR    szFont[512];
	SIZE     size;
	HDC      hdc;
	HFONT    hFont, hFontOld;
	LONG     nFontHeight  = GetWindowLong(hwnd, GWL_FONT_HEIGHT);
	LONG     nMaxWidth    = GetWindowLong(hwnd, GWL_MAX_ITEM_WIDTH);
	LPCTSTR  szText;
	
	if (lpMeasure->itemID == -1) 
	{
		// Combo box edit field - use default measurements.
		return TRUE;
	}

	// Get item text.
	if (!sGetComboItemText(hwnd, ID_COMBO, lpMeasure->itemID, szFont, ARRAYSIZE(szFont))) return TRUE;

	if ((hdc = GetDC(hwnd)) != NULL) 
	{
		hFont = CreateFont(nFontHeight, 0, 0, 0, FW_NORMAL, FALSE, FALSE, FALSE, DEFAULT_CHARSET, OUT_DEFAULT_PRECIS,
		                   CLIP_DEFAULT_PRECIS, DEFAULT_QUALITY, DEFAULT_PITCH | FF_DONTCARE, szFont);

		if (hFont != NULL) 
		{
			hFontOld = (HFONT) SelectObject(hdc, hFont);

			// Check the charset of the font. If it is not ansi we will render
			// the font name in the default font and only a sample in the target font.
			szText = ((GetTextCharset(hdc) == ANSI_CHARSET) ? szFont : SAMPLE_TEXT);

			// Measure the text.
			if (GetTextExtentPoint32(hdc, szText, lstrlen(szText), &size))
			{
				lpMeasure->itemWidth  = size.cx + 2;
				lpMeasure->itemHeight = max(size.cy, nFontHeight) + 2;
			}

			SelectObject(hdc, hFontOld);
			DeleteObject(hFont);

			if (szText == SAMPLE_TEXT)
			{
				// If this is a non-ansi font add the width of the font name in the default font.
				hFont = (HFONT) GetWindowLongPtr(hwnd, GWL_DEFAULT_FONT);
				if (hFont) hFontOld = (HFONT) SelectObject(hdc, hFont);

				if (GetTextExtentPoint32(hdc, szFont, lstrlen(szFont), &size))
					lpMeasure->itemWidth += size.cx;

				if (hFont) SelectObject(hdc, hFontOld);
			}
		}

		ReleaseDC(hwnd, hdc);
	}

	// If this is the widest item, store it so we can use it to set the width of the dropdown list.
	if (lpMeasure->itemWidth > (UINT) nMaxWidth) SetWindowLong(hwnd, GWL_MAX_ITEM_WIDTH, lpMeasure->itemWidth);

	return TRUE;
}


/*
 * Draw an item.
 */
static BOOL WINAPI sDrawItem(HWND hwnd, LPDRAWITEMSTRUCT lpdis)
{
	TCHAR      szFont[512];
	COLORREF   clrBackground;
	COLORREF   clrForeground;
	int        y;
	TEXTMETRIC tm;
	HFONT      hFont        = NULL;
	HFONT      hFontOld     = NULL;
	LONG       nFontHeight  = GetWindowLong(hwnd, GWL_FONT_HEIGHT);

 	// If the item has the focus, draw focus rectangle. 
	if (lpdis->itemState & ODS_FOCUS) DrawFocusRect(lpdis->hDC, &lpdis->rcItem); 

	// Check for empty item.
	if (lpdis->itemID == -1) return TRUE;
 
	// Get the text for the item we are drawing.
	if (!sGetComboItemText(hwnd, ID_COMBO, lpdis->itemID, szFont, ARRAYSIZE(szFont))) return TRUE;

	// The colors depend on whether the item is selected. 
 	clrForeground = SetTextColor(lpdis->hDC, 
	                    GetSysColor(lpdis->itemState & ODS_SELECTED ? COLOR_HIGHLIGHTTEXT : COLOR_WINDOWTEXT));

 	clrBackground = SetBkColor(lpdis->hDC, 
	                    GetSysColor(lpdis->itemState & ODS_SELECTED ? COLOR_HIGHLIGHT : COLOR_WINDOW));

	if (lpdis->itemState & ODS_COMBOBOXEDIT)
	{
		// The edit field of our combo box.
		hFont = (HFONT) SendMessage(lpdis->hwndItem, WM_GETFONT, 0, 0);
		if (hFont) hFontOld = (HFONT) SelectObject(lpdis->hDC, hFont);

		// Get vertical center position.
		GetTextMetrics(lpdis->hDC, &tm);
		y = (lpdis->rcItem.bottom + lpdis->rcItem.top - tm.tmHeight) / 2; 

		// Output font name.
		ExtTextOut(lpdis->hDC, 5, y, 
		           ETO_CLIPPED | ETO_OPAQUE, &lpdis->rcItem, 
		           szFont, lstrlen(szFont), NULL);

		hFont = NULL;
		goto cleanup;
	}

	// Create our target font and select it in.
	hFont = CreateFont(nFontHeight, 0, 0, 0, FW_NORMAL, FALSE, FALSE, FALSE, DEFAULT_CHARSET, OUT_DEFAULT_PRECIS,
		               CLIP_DEFAULT_PRECIS, DEFAULT_QUALITY, DEFAULT_PITCH | FF_DONTCARE, szFont);

	if (hFont != NULL) hFontOld = (HFONT) SelectObject(lpdis->hDC, hFont);

	// Get information on our target font.
	if (!GetTextMetrics(lpdis->hDC, &tm) ||
	    tm.tmCharSet != ANSI_CHARSET)
	{
		HFONT  hFontDefault = (HFONT) GetWindowLongPtr(hwnd, GWL_DEFAULT_FONT);
		POINT  ptCurrent;
		DWORD  dwAlignOrig;

		// If this is not an ansi font we will render
		// the font name in the default font and only a sample in the target font.
		if (hFontDefault) SelectObject(lpdis->hDC, hFontDefault);

		// Tell ExtTextOut to use and update the current position.
		if (!((dwAlignOrig = GetTextAlign(lpdis->hDC)) & TA_UPDATECP))
			SetTextAlign(lpdis->hDC, dwAlignOrig | TA_UPDATECP);

		// Calculate the vertical center point and move to the start point.
		y = (lpdis->rcItem.bottom + lpdis->rcItem.top - nFontHeight) / 2;
		MoveToEx(lpdis->hDC, lpdis->rcItem.left + 5, y, NULL);

		// Output the font name in the default font.
		ExtTextOut(lpdis->hDC, 5, y, 
		           ETO_CLIPPED | ETO_OPAQUE, &lpdis->rcItem, 
		           szFont, lstrlen(szFont), NULL);

		// Move into position to output the sample text.		
		GetCurrentPositionEx(lpdis->hDC, &ptCurrent);
		lpdis->rcItem.left = ptCurrent.x;
		y = (lpdis->rcItem.bottom + lpdis->rcItem.top - tm.tmHeight) / 2; 
		MoveToEx(lpdis->hDC, lpdis->rcItem.left + 5, y, NULL);

		// Output some sample text in our font.
		SelectObject(lpdis->hDC, hFont);
		ExtTextOut(lpdis->hDC, 5, y, 
		     ETO_CLIPPED | ETO_OPAQUE, &lpdis->rcItem, 
		     SAMPLE_TEXT, ARRAYSIZE(SAMPLE_TEXT) - 1, NULL);

		// Restore the text align mode.
		SetTextAlign(lpdis->hDC, dwAlignOrig);
	}
	else
	{
		// Calculate the vertical center position.
		y = (lpdis->rcItem.bottom + lpdis->rcItem.top - tm.tmHeight) / 2; 

		// Output the font name in the target font.
		ExtTextOut(lpdis->hDC, 5, y, 
		           ETO_CLIPPED | ETO_OPAQUE, &lpdis->rcItem, 
		           szFont, lstrlen(szFont), NULL);
	}

cleanup:
	if (hFontOld != NULL) SelectObject(lpdis->hDC, hFontOld);
	if (hFont != NULL)    DeleteObject(hFont);
 
	// Restore the previous colors. 
 	SetTextColor(lpdis->hDC, clrForeground); 
	SetBkColor(lpdis->hDC, clrBackground); 

	return TRUE;
}


/*
 * Create our default font and store the default font size.
 */
static BOOL WINAPI sInit(HWND hwnd, HWND hwndCombo)
{
	HDC hdc = GetDC(hwndCombo);
	INT nFontHeight = MulDiv(ITEM_POINT_SIZE, GetDeviceCaps(hdc, LOGPIXELSY), 72);
	HFONT hFont = CreateFont(nFontHeight, 0, 0, 0, FW_NORMAL, FALSE, FALSE, FALSE, DEFAULT_CHARSET, OUT_DEFAULT_PRECIS,
	                         CLIP_DEFAULT_PRECIS, DEFAULT_QUALITY, DEFAULT_PITCH | FF_DONTCARE, TEXT("Arial"));

	ReleaseDC(hwndCombo, hdc);
	SetWindowLong(hwnd, GWL_FONT_HEIGHT, nFontHeight);
	SetWindowLongPtr(hwnd, GWL_DEFAULT_FONT, (LONG_PTR) hFont);
	
	return TRUE;
}


/*
 * The window procedure for our container control.
 */
static LRESULT CALLBACK sFontWndProc(HWND hwnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	switch (uMsg)
	{
		case WM_CREATE:
		{
			LPCREATESTRUCT lpCreate   = (LPCREATESTRUCT) lParam;
			HWND           hwndCombo;
			RECT           rc;

			hwndCombo = CreateWindowEx(0, TEXT("COMBOBOX"), TEXT(""),
			               WS_VSCROLL | CBS_DROPDOWNLIST | WS_CHILD |
			               CBS_SORT | WS_VISIBLE | CBS_HASSTRINGS | CBS_OWNERDRAWVARIABLE,
			               0, 0, lpCreate->cx, HIWORD(GetDialogBaseUnits()) * 20,
			               hwnd, (HMENU) ID_COMBO, GetModuleHandle(NULL), NULL);

			if (hwndCombo == NULL) return -1;

			// Resize ourselves to accomodate the combo box.
			if (GetWindowRect(hwndCombo, &rc))
				MoveWindow(hwnd, lpCreate->x, lpCreate->y, lpCreate->cx, rc.bottom - rc.top, TRUE);

			return (sInit(hwnd, hwndCombo) ? 0 : -1);
		}

		case WM_MEASUREITEM:
		{
			return sMeasureItem(hwnd, (LPMEASUREITEMSTRUCT) lParam);
		}

		case WM_DRAWITEM:
		{
			return sDrawItem(hwnd, (LPDRAWITEMSTRUCT) lParam); 
		}

		case WM_SETFONT:
		{
			LOGFONT lf;
			HFONT   hFont;
			RECT    rcContainer, rcCombo;

			// Pass on font change to combo box.
			SendDlgItemMessage(hwnd, ID_COMBO, uMsg, wParam, lParam);

			// Resize the combo box edit field to fit the new font.
			hFont = (wParam ? (HFONT) wParam : (HFONT) GetStockObject(SYSTEM_FONT));
			if (GetObject(hFont, sizeof(LOGFONT), &lf))
				SendDlgItemMessage(hwnd, ID_COMBO, CB_SETITEMHEIGHT, (WPARAM) -1, lf.lfHeight);

			// Resize ourselves to accomodate the new size of the combo box.
			if (GetWindowRect(GetDlgItem(hwnd, ID_COMBO), &rcCombo) &&
			    GetWindowRect(hwnd, &rcContainer))
			{
				POINT pt = *((LPPOINT) &rcContainer);
				if (ScreenToClient(GetParent(hwnd), &pt))
				{
					MoveWindow(hwnd, pt.x, pt.y,
					           rcContainer.right - rcContainer.left, rcCombo.bottom - rcCombo.top, TRUE);
				}
			}
			return 0;
		}

		case FCM_ADD_ALL_FONTS:
		{
			return sAddFonts(GetDlgItem(hwnd, ID_COMBO));
		}
		
		case WM_DESTROY:
		{
			HFONT hFont = (HFONT) GetWindowLongPtr(hwnd, GWL_DEFAULT_FONT);
			if (hFont) DeleteObject(hFont);
			break;
		}

		case WM_SETFOCUS:
		{
			return !SetFocus(GetDlgItem(hwnd, ID_COMBO));
		}

		case WM_GETDLGCODE:
		case WM_GETFONT:
		case WM_SETTEXT:
		case WM_GETTEXT:
		case WM_GETTEXTLENGTH:
		{
			return SendDlgItemMessage(hwnd, ID_COMBO, uMsg, wParam, lParam);
		}

		case WM_COMMAND:
		{
			if (HIWORD(wParam) == CBN_DROPDOWN)
			{
				// Set the drop down width to be as wide as the longest item.
				LONG nWidth = GetWindowLong(hwnd, GWL_MAX_ITEM_WIDTH);
				SendMessage((HWND) lParam, CB_SETDROPPEDWIDTH, nWidth + 10, 0);
			}
			// Pass on the notification to our parent window.
			return SendMessage(GetParent(hwnd), uMsg, MAKELONG(GetDlgCtrlID(hwnd), HIWORD(wParam)), (LPARAM) hwnd);
		}
	}

	return DefWindowProc(hwnd, uMsg, wParam, lParam);
}


/*
 * Register the window class for our font control.
 */
BOOL xRegisterFontControl(void)
{
	WNDCLASSEX wc = { 0 };

	wc.cbSize        = sizeof(wc);
	wc.lpfnWndProc   = sFontWndProc;
	wc.hInstance     = GetModuleHandle(NULL);
	wc.lpszClassName = SELECT_FONT_CLASS;
	wc.cbWndExtra    = sizeof(LONG) + sizeof(LONG) + sizeof(HFONT);
	
	return (RegisterClassEx(&wc) != 0);
}

