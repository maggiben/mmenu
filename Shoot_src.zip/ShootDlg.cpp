// ShootDlg.cpp : implementation file
//

#include "stdafx.h"
#include "Shoot.h"
#include "ShootDlg.h"
#include "mmsystem.h"
#include "AboutDlg.h"

/////////////////////////////////////////////////////////////////////////////
// CShootDlg dialog

CShootDlg::CShootDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CShootDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CShootDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);

    m_hCursor   = NULL;
    m_pBMP      = NULL;
    m_pProcDC   = NULL;
    m_pShotDC   = NULL;
    m_pShotBmp  = NULL;

    CaptureDesktop();
}

void CShootDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CShootDlg)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CShootDlg, CDialog)
	//{{AFX_MSG_MAP(CShootDlg)
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_WM_SETCURSOR()
	ON_WM_LBUTTONDOWN()
	ON_WM_DESTROY()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CShootDlg message handlers

BOOL CShootDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
    //  =======================================================================
    //  Cover the whole window with the mouse pointer
    //  =======================================================================
	::SetWindowPos ( this->GetSafeHwnd(), HWND_TOPMOST, 0, 0, 
                     GetSystemMetrics(SM_CXSCREEN), GetSystemMetrics(SM_CYSCREEN), 
                     SWP_SHOWWINDOW);

    //  =======================================================================
    //  Set gun target finder cursor
    //  =======================================================================
	HINSTANCE hInstResource = AfxFindResourceHandle(MAKEINTRESOURCE(IDC_TF), RT_GROUP_CURSOR);
    m_hCursor = ::LoadCursor( hInstResource, MAKEINTRESOURCE(IDC_TF) );

    return TRUE;  // return TRUE  unless you set the focus to a control
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CShootDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}

    DisplayDesktop();
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CShootDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

BOOL CShootDlg::OnSetCursor(CWnd* pWnd, UINT nHitTest, UINT message) 
{
    if (m_hCursor)
    {
        ::SetCursor(m_hCursor);
		return TRUE;
    }

    return CDialog::OnSetCursor(pWnd, nHitTest, message);
}

CShootDlg::~CShootDlg()
{
    if ( m_hCursor  ) ::DestroyCursor (m_hCursor);
    if ( m_pBMP     ) delete m_pBMP;
    if ( m_pProcDC  ) delete m_pProcDC;
    if ( m_pShotDC  ) delete m_pShotDC;
    if ( m_pShotBmp ) delete m_pShotBmp;
}

void CShootDlg::CaptureDesktop()
{
    //  =======================================================================
    //  Get Desktop DC and size
    //  =======================================================================
    CDC *pDesktopDC = CDC::FromHandle ( ::GetDCEx(NULL, NULL, 0));
    int screenMaxX = GetSystemMetrics(SM_CXSCREEN);
    int screenMaxY = GetSystemMetrics(SM_CYSCREEN);
    
    //  =======================================================================
    //  Create DC in memory with a bitmap to store the desktop
    //  =======================================================================
    if (m_pProcDC) delete m_pProcDC;
    m_pProcDC = new CDC;
    m_pProcDC->CreateCompatibleDC (pDesktopDC);

    if ( m_pBMP ) delete m_pBMP;
    m_pBMP = new CBitmap;
    m_pBMP->CreateCompatibleBitmap (pDesktopDC, screenMaxX, screenMaxY);
    m_pProcDC->SelectObject (m_pBMP);

    //  =======================================================================
    //  Copy desktop to memory DC
    //  =======================================================================
    m_pProcDC->BitBlt (0, 0, screenMaxX, screenMaxY, pDesktopDC, 0, 0, SRCCOPY );


    //  =======================================================================
    //  Copy shot mark to DC in memory
    //  =======================================================================
    if ( m_pShotDC ) delete m_pShotDC;
    m_pShotDC = new CDC;
    m_pShotDC->CreateCompatibleDC(pDesktopDC);

    if ( m_pShotBmp ) delete m_pShotBmp;
    m_pShotBmp = new CBitmap;
    m_pShotBmp->LoadBitmap ( IDB_SHOTMARK );
    m_pShotDC->SelectObject ( m_pShotBmp );

}

void CShootDlg::DisplayDesktop()
{
    int screenMaxX = GetSystemMetrics(SM_CXSCREEN);
    int screenMaxY = GetSystemMetrics(SM_CYSCREEN);

    //  =======================================================================
    //  Get the dialogs DC
    //  =======================================================================
    CDC *pDC = GetDC();

    //  =======================================================================
    //  Copy desktop to memory DC
    //  =======================================================================
    pDC->BitBlt (0, 0, screenMaxX, screenMaxY, m_pProcDC, 0, 0, SRCCOPY );

    ReleaseDC(pDC);
}

void CShootDlg::OnLButtonDown(UINT nFlags, CPoint point) 
{	
    //  =======================================================================
    //  Show gunshot hole
    //  =======================================================================
    CDC *pDC = GetDC();
    pDC->BitBlt (point.x - 10, point.y - 10, 48, 48, m_pShotDC, 0, 0, SRCAND);
    ReleaseDC(pDC);

    //  =======================================================================
    //  Play gunshot sound
    //  =======================================================================
    //  locate the path of the sound file to play
    char fname[_MAX_PATH];
    ::GetModuleFileName(NULL, fname, sizeof (fname));
    CString applicationPath = fname;
    applicationPath.MakeLower();
    CString soundFile = applicationPath.Left(applicationPath.ReverseFind('\\') + 1) + "gunshot.wav";
    
    //  play the sound file
    ::PlaySound( (LPCTSTR)soundFile, NULL, SND_FILENAME | SND_ASYNC | SND_NODEFAULT | SND_PURGE );


	CDialog::OnLButtonDown(nFlags, point);
}

void CShootDlg::OnDestroy() 
{
	CDialog::OnDestroy();
	
    CAboutDlg *dlg = new CAboutDlg;

    dlg->DoModal();

}
