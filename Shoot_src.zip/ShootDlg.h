// ShootDlg.h : header file
//

#if !defined(AFX_SHOOTDLG_H__065FDD2A_CA49_4310_9B07_0DBBEDF2CC5C__INCLUDED_)
#define AFX_SHOOTDLG_H__065FDD2A_CA49_4310_9B07_0DBBEDF2CC5C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

/////////////////////////////////////////////////////////////////////////////
// CShootDlg dialog

class CShootDlg : public CDialog
{
// Construction
public:
	~CShootDlg();
	HCURSOR m_hCursor;
	CShootDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	//{{AFX_DATA(CShootDlg)
	enum { IDD = IDD_SHOOT_DIALOG };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CShootDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	//{{AFX_MSG(CShootDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg BOOL OnSetCursor(CWnd* pWnd, UINT nHitTest, UINT message);
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnDestroy();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
private:
	CBitmap * m_pShotBmp;
	CDC * m_pShotDC;
	void DisplayDesktop();
	CBitmap * m_pBMP;
	CDC * m_pProcDC;
	void CaptureDesktop();
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_SHOOTDLG_H__065FDD2A_CA49_4310_9B07_0DBBEDF2CC5C__INCLUDED_)
