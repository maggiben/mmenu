/**************************************************************************\
*
* All files in GdiPlusLib have been modified from the Microsoft
* GdiPlus C++ header files.
*
* Module Name:
*
*   GdiPlusImageAttributes.c
*
* Abstract:
*
*   Class for color adjustment object passed to GpGraphics_DrawImage()
*
\**************************************************************************/

#include "GdiPlusImageAttributes.h"
#include "GdiPlusColor.h"

GP_IMAGEATTRIBUTES GpImageAttributes(VOID)
{
    GP_IMAGEATTRIBUTES this;
    this.nativeImageAttr = NULL;
    this.lastResult = GdipCreateImageAttributes(&(this.nativeImageAttr));
	return this;
}

void GpImageAttributes_Delete(GP_IMAGEATTRIBUTES * this)
{
    GdipDisposeImageAttributes(this->nativeImageAttr);
}

GP_IMAGEATTRIBUTES GpImageAttributes_Clone(GP_IMAGEATTRIBUTES * this)
{
    GP_GPIMAGEATTRIBUTES* clone;

    (this->lastResult = GdipCloneImageAttributes(this->nativeImageAttr, &clone));

    // return new ImageAttributes(clone, lastResult);
    return GpImageAttributes_ImageAttributes(clone, this->lastResult);

}

// Set to identity, regardless of what the default color adjustment is.
//GpStatus GpImageAttributes_SetToIdentity(GP_IMAGEATTRIBUTES * this, GpColorAdjustType type = eColorAdjustTypeDefault)
GpStatus GpImageAttributes_SetToIdentity(GP_IMAGEATTRIBUTES * this, GpColorAdjustType type)
{
    return (this->lastResult = GdipSetImageAttributesToIdentity(this->nativeImageAttr,type));
}

// Remove any individual color adjustments, and go back to using the default
//GpStatus GpImageAttributes_Reset(GP_IMAGEATTRIBUTES * this,  GpColorAdjustType type = eColorAdjustTypeDefault)
GpStatus GpImageAttributes_Reset(GP_IMAGEATTRIBUTES * this, GpColorAdjustType type)
{
    return (this->lastResult = GdipResetImageAttributes(this->nativeImageAttr, type));
}

//GpStatus GpImageAttributes_SetColorMatrix( GP_IMAGEATTRIBUTES * this, const COLORMATRIX *colorMatrix, GpColorMatrixFlags mode, GpColorAdjustType type = eColorAdjustTypeDefault)
GpStatus GpImageAttributes_SetColorMatrix( GP_IMAGEATTRIBUTES * this,
    const COLORMATRIX *colorMatrix, GpColorMatrixFlags mode,
    GpColorAdjustType type)
{
    return (this->lastResult = GdipSetImageAttributesColorMatrix(this->nativeImageAttr,
                                   type, TRUE, colorMatrix, NULL, mode));
}

//GpStatus GpImageAttributes_ClearColorMatrix(GP_IMAGEATTRIBUTES * this, GpColorAdjustType type = eColorAdjustTypeDefault)
GpStatus GpImageAttributes_ClearColorMatrix(GP_IMAGEATTRIBUTES * this,
    GpColorAdjustType type)
{
    return (this->lastResult = GdipSetImageAttributesColorMatrix(this->nativeImageAttr,
                   type, FALSE, NULL, NULL, eColorMatrixFlagsDefault));
}

//GpStatus GpImageAttributes_SetColorMatrices(GP_IMAGEATTRIBUTES * this, const COLORMATRIX *colorMatrix, const COLORMATRIX *grayMatrix, GpColorMatrixFlags mode, GpColorAdjustType type = eColorAdjustTypeDefault)
GpStatus GpImageAttributes_SetColorMatrices(GP_IMAGEATTRIBUTES * this,
    const COLORMATRIX *colorMatrix, const COLORMATRIX *grayMatrix,
    GpColorMatrixFlags mode, GpColorAdjustType type)
{
    return (this->lastResult = GdipSetImageAttributesColorMatrix(this->nativeImageAttr,
                           type, TRUE, colorMatrix, grayMatrix, mode));
}

//GpStatus GpImageAttributes_ClearColorMatrices(GP_IMAGEATTRIBUTES * this, GpColorAdjustType type = eColorAdjustTypeDefault)
GpStatus GpImageAttributes_ClearColorMatrices(GP_IMAGEATTRIBUTES * this,
    GpColorAdjustType type)
{
    return (this->lastResult = GdipSetImageAttributesColorMatrix(this->nativeImageAttr,
                           type, FALSE, NULL, NULL, eColorMatrixFlagsDefault));
}

//GpStatus GpImageAttributes_SetThreshold(GP_IMAGEATTRIBUTES * this, REAL threshold, GpColorAdjustType type = eColorAdjustTypeDefault)
GpStatus GpImageAttributes_SetThreshold(GP_IMAGEATTRIBUTES * this,
    REAL threshold, GpColorAdjustType type)
{
    return (this->lastResult = GdipSetImageAttributesThreshold(this->nativeImageAttr,
                                        type, TRUE, threshold));
}

//GpStatus GpImageAttributes_ClearThreshold(GP_IMAGEATTRIBUTES * this,GpColorAdjustType type = eColorAdjustTypeDefault)
GpStatus GpImageAttributes_ClearThreshold(GP_IMAGEATTRIBUTES * this,
    GpColorAdjustType type)
{
    return (this->lastResult = GdipSetImageAttributesThreshold(this->nativeImageAttr,
                                            type, FALSE, 0.0f));
}

//GpStatus GpImageAttributes_SetGamma(GP_IMAGEATTRIBUTES * this, REAL gamma, GpColorAdjustType type = eColorAdjustTypeDefault)
GpStatus GpImageAttributes_SetGamma(GP_IMAGEATTRIBUTES * this,
    REAL gamma, GpColorAdjustType type)
{
    return (this->lastResult = GdipSetImageAttributesGamma(this->nativeImageAttr,
                                            type, TRUE, gamma));
}

//GpStatus GpImageAttributes_ClearGamma(GP_IMAGEATTRIBUTES * this, GpColorAdjustType type = eColorAdjustTypeDefault)
GpStatus GpImageAttributes_ClearGamma(GP_IMAGEATTRIBUTES * this,
    GpColorAdjustType type)
{
    return (this->lastResult = GdipSetImageAttributesGamma(this->nativeImageAttr,
                                            type, FALSE, 0.0f));
}

//GpStatus GpImageAttributes_SetNoOp(GP_IMAGEATTRIBUTES * this, GpColorAdjustType type = eColorAdjustTypeDefault)
GpStatus GpImageAttributes_SetNoOp(GP_IMAGEATTRIBUTES * this,
    GpColorAdjustType type)
{
    return (this->lastResult = GdipSetImageAttributesNoOp(this->nativeImageAttr,
                                            type, TRUE));
}

//GpStatus GpImageAttributes_ClearNoOp(GP_IMAGEATTRIBUTES * this, GpColorAdjustType type = eColorAdjustTypeDefault)
GpStatus GpImageAttributes_ClearNoOp(GP_IMAGEATTRIBUTES * this,
    GpColorAdjustType type)
{
    return (this->lastResult = GdipSetImageAttributesNoOp(this->nativeImageAttr,
                                            type, FALSE));
}

//GpStatus GpImageAttributes_SetColorKey(GP_IMAGEATTRIBUTES * this, const COLOR * colorLow, const COLOR * colorHigh, GpColorAdjustType type = eColorAdjustTypeDefault)
GpStatus GpImageAttributes_SetColorKey(GP_IMAGEATTRIBUTES * this,
    const COLOR * colorLow, const COLOR * colorHigh,
    GpColorAdjustType type)
{
    return (this->lastResult = GdipSetImageAttributesColorKeys(this->nativeImageAttr,
      type, TRUE, GpColor_GetValue(colorLow), GpColor_GetValue(colorHigh)));
}

//GpStatus GpImageAttributes_ClearColorKey(GP_IMAGEATTRIBUTES * this, GpColorAdjustType type = eColorAdjustTypeDefault)
GpStatus GpImageAttributes_ClearColorKey(GP_IMAGEATTRIBUTES * this,
    GpColorAdjustType type)
{
    return (this->lastResult = GdipSetImageAttributesColorKeys(this->nativeImageAttr,
                                            type, FALSE, 0x0UL, 0x0UL));
}

//GpStatus GpImageAttributes_SetOutputChannel(GP_IMAGEATTRIBUTES * this, GpColorChannelFlags channelFlags, GpColorAdjustType type = eColorAdjustTypeDefault)
GpStatus GpImageAttributes_SetOutputChannel(GP_IMAGEATTRIBUTES * this,
    GpColorChannelFlags channelFlags, GpColorAdjustType type)
{
    return (this->lastResult = 	GdipSetImageAttributesOutputChannel(this->nativeImageAttr,
                                         type, TRUE, channelFlags));
}

//GpStatus GpImageAttributes_ClearOutputChannel(GP_IMAGEATTRIBUTES * this, GpColorAdjustType type = eColorAdjustTypeDefault)
GpStatus GpImageAttributes_ClearOutputChannel(GP_IMAGEATTRIBUTES * this,
    GpColorAdjustType type)
{
    return (this->lastResult = GdipSetImageAttributesOutputChannel(this->nativeImageAttr,
                                type, FALSE, eColorChannelFlagsLast));
}

//GpStatus GpImageAttributes_SetOutputChannelColorProfile(GP_IMAGEATTRIBUTES * this, const WCHAR *colorProfileFilename,  GpColorAdjustType type = eColorAdjustTypeDefault)
GpStatus GpImageAttributes_SetOutputChannelColorProfile(GP_IMAGEATTRIBUTES * this,
    const WCHAR *colorProfileFilename, GpColorAdjustType type)
{
    return (this->lastResult = GdipSetImageAttributesOutputChannelColorProfile(this->nativeImageAttr,
                               type, TRUE, colorProfileFilename));
}

//GpStatus GpImageAttributes_ClearOutputChannelColorProfile(GP_IMAGEATTRIBUTES * this, GpColorAdjustType type = eColorAdjustTypeDefault)
GpStatus GpImageAttributes_ClearOutputChannelColorProfile(GP_IMAGEATTRIBUTES * this,
    GpColorAdjustType type)
{
    return (this->lastResult =
                GdipSetImageAttributesOutputChannelColorProfile(
                                            this->nativeImageAttr,
                                            type, FALSE, NULL));
}

//GpStatus GpImageAttributes_SetRemapTable(GP_IMAGEATTRIBUTES * this, UINT mapSize, const COLOR_MAP *map, GpColorAdjustType type = eColorAdjustTypeDefault)
GpStatus GpImageAttributes_SetRemapTable(GP_IMAGEATTRIBUTES * this,
    UINT mapSize, const COLOR_MAP *map, GpColorAdjustType type)
{
    return (this->lastResult =
                GdipSetImageAttributesRemapTable(this->nativeImageAttr,
                                            type, TRUE, mapSize, map));
}

//GpStatus GpImageAttributes_ClearRemapTable(GP_IMAGEATTRIBUTES * this, GpColorAdjustType type = eColorAdjustTypeDefault)
GpStatus GpImageAttributes_ClearRemapTable(GP_IMAGEATTRIBUTES * this,
    GpColorAdjustType type)
{
    return (this->lastResult =
                GdipSetImageAttributesRemapTable(this->nativeImageAttr,
                                            type, FALSE, 0, NULL));
}

GpStatus GpImageAttributes_SetBrushRemapTable(GP_IMAGEATTRIBUTES * this,
    UINT mapSize, const COLOR_MAP *map)
{
    return GpImageAttributes_SetRemapTable(this, mapSize, map, eColorAdjustTypeBrush);
}

GpStatus GpImageAttributes_ClearBrushRemapTable(GP_IMAGEATTRIBUTES * this)
{
    return GpImageAttributes_ClearRemapTable(this, eColorAdjustTypeBrush);
}

//GpStatus GpImageAttributes_SetWrapMode(GP_IMAGEATTRIBUTES * this,GpWrapMode wrap, const COLOR * color, BOOL clamp = FALSE)
GpStatus GpImageAttributes_SetWrapMode(GP_IMAGEATTRIBUTES * this,
    GpWrapMode wrap, const COLOR * color, BOOL clamp)
{

    ARGB argb = GpColor_GetValue(color);

    return (this->lastResult = GdipSetImageAttributesWrapMode(this->nativeImageAttr, 
					wrap, argb, clamp));
}

// The flags of the palette are ignored.
GpStatus GpImageAttributes_GetAdjustedPalette(GP_IMAGEATTRIBUTES * this,
    COLORPALETTE* colorPalette, GpColorAdjustType colorAdjustType)
{
    return (this->lastResult = GdipGetImageAttributesAdjustedPalette(this->nativeImageAttr, 
				colorPalette, colorAdjustType));
}

GpStatus GpImageAttributes_GetLastStatus(GP_IMAGEATTRIBUTES * this)
{
    GpStatus lastStatus = this->lastResult;
    this->lastResult = eOk;
    return lastStatus;
}

GP_IMAGEATTRIBUTES GpImageAttributes_ImageAttributes(GP_GPIMAGEATTRIBUTES* imageAttr,
    GpStatus status)
{
    GP_IMAGEATTRIBUTES this;
    this.nativeImageAttr = imageAttr;
    this.lastResult = status;
    return this;
}




