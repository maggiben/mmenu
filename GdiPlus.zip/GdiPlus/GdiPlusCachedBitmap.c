/**************************************************************************
*
* All files in GdiPlusLib have been modified from the Microsoft
* GdiPlus C++ header files.
*
* Module Name:
*
*   GdiPlusCachedBitmap.c
*
* Abstract:
*
*   CachedBitmap is a representation of an accelerated drawing
*   that has restrictions on what operations are allowed in order
*   to accelerate the drawing to the destination.
*
**************************************************************************/

#include "GdiPlusCachedBitmap.h"
#include "GdiPlusBitmap.h"
#include "GdiPlusGraphics.h"

GP_CACHEDBITMAP GpCachedBitmap(GP_BITMAP *bitmap, GP_GRAPHICS *graphics)
{
    GP_CACHEDBITMAP this;
    this.nativeCachedBitmap = NULL;
    this.lastResult = GdipCreateCachedBitmap((GP_GPBITMAP *)bitmap->nativeImage,
        graphics->nativeGraphics, &this.nativeCachedBitmap);
    return this;
}

VOID GpCachedBitmap_Delete(GP_CACHEDBITMAP * this)
{
    GdipDeleteCachedBitmap(this->nativeCachedBitmap);
}

GpStatus GpCachedBitmap_GetLastStatus(GP_CACHEDBITMAP * this)
{
	GpStatus lastStatus = this->lastResult;
    this->lastResult = eOk;
    return (lastStatus);
}
