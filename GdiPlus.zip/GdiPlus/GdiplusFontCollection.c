// GdiplusFontCollection.c

#include <stdlib.h>
#include "GdiplusFontCollection.h"
#include "GdiplusFontFamily.h"

GP_FONTCOLLECTION GpFontCollection(void)
{
    GP_FONTCOLLECTION this;
    this.nativeFontCollection = NULL;
    return this;
}

VOID GpFontCollection_Delete(GP_FONTCOLLECTION * this)
{
	return;
}

INT GpFontCollection_GetFamilyCount(GP_FONTCOLLECTION * this)
{
    INT numFound = 0;
    this->lastResult = GdipGetFontCollectionFamilyCount(
                            this->nativeFontCollection, &numFound);
    return numFound;
}

GpStatus GpFontCollection_GetFamilies(GP_FONTCOLLECTION * this,
    INT numSought, GP_FONTFAMILY * gpfamilies, INT * numFound)
{
    if (numSought <= 0 || gpfamilies == NULL || numFound == NULL)
    {
        return (this->lastResult = eInvalidParameter);
    }
    *numFound = 0;
    // GpFontFamily **nativeFamilyList = new GpFontFamily*[numSought];
    GP_GPFONTFAMILY **nativeFamilyList = GpAlloc(numSought * sizeof(GP_GPFONTFAMILY*));

    if (nativeFamilyList == NULL)
    {
        return (this->lastResult = eOutOfMemory);
    }

    GpStatus status = (this->lastResult = GdipGetFontCollectionFamilyList(
                                    this->nativeFontCollection,
                                    numSought, nativeFamilyList, numFound));

    if (status == eOk)
    {
        for (INT i = 0; i < *numFound; i++)
        {
            GdipCloneFontFamily(nativeFamilyList[i], &gpfamilies[i].nativeFamily);
        }
    }

    GpFree(nativeFamilyList);

    return status;
}

GpStatus GpFontCollection_GetLastStatus(GP_FONTCOLLECTION * this)
{
    return this->lastResult;
}

GpStatus GpFontCollection_SetStatus(GP_FONTCOLLECTION * this, GpStatus status)
{
    this->lastResult = status;
    return this->lastResult;
}

GP_INSTALLEDFONTCOLLECTION GpInstalledFontCollection_InstalledFontCollection(VOID)
{
    GP_INSTALLEDFONTCOLLECTION this;
    this.nativeFontCollection = NULL;
    this.lastResult = GdipNewInstalledFontCollection(&this.nativeFontCollection);
    return this;
}

VOID GpInstalledFontCollection_Delete(GP_INSTALLEDFONTCOLLECTION * this)
{
	return;
}

GP_PRIVATEFONTCOLLECTION GpPrivateFontCollection_PrivateFontCollection(VOID)
{
    GP_PRIVATEFONTCOLLECTION this;
    this.nativeFontCollection = NULL;
    this.lastResult = GdipNewPrivateFontCollection(&this.nativeFontCollection);
    return this;
}

VOID GpPrivateFontCollection_PrivateFontCollection_Dtor(GP_PRIVATEFONTCOLLECTION * this)
{
    GdipDeletePrivateFontCollection(&this->nativeFontCollection);
}

GpStatus GpPrivateFontCollection_AddFontFile(GP_PRIVATEFONTCOLLECTION * this,
    WCHAR* filename)
{
    return (this->lastResult = GdipPrivateAddFontFile(
                    this->nativeFontCollection, filename));
}

GpStatus GpPrivateFontCollection_AddMemoryFont(GP_PRIVATEFONTCOLLECTION * this,
    VOID * memory,INT length)
{
    return (this->lastResult = GdipPrivateAddMemoryFont(this->nativeFontCollection,
                    memory, length));
}

