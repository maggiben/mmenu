// GdiPlusLineCaps.c

#include "GdiPlusLineCaps.h"
#include "GdiPlusPath.h"
 
GP_CUSTOMLINECAP GpCustomLineCap(GP_GRAPHICSPATH* fillPath,
    GP_GRAPHICSPATH * strokePath, GpLineCap baseCap, REAL baseInset)
{
    GP_CUSTOMLINECAP this;
    this.nativeCap = NULL;
    GP_GPPATH* nativeFillPath = NULL;
    GP_GPPATH* nativeStrokePath = NULL;

    if(fillPath)
        nativeFillPath = (GP_GPPATH*)fillPath->nativePath;

    if(strokePath)
        nativeStrokePath = (GP_GPPATH *)strokePath->nativePath;

    this.lastResult = GdipCreateCustomLineCap(nativeFillPath,
                            nativeStrokePath, baseCap,
                            baseInset, &this.nativeCap);
    return this;
}

/*
GP_CUSTOMLINECAP GpCustomLineCap(GP_CUSTOMLINECAP * this)
{
    // This is used for default constructor for subclasses.
    // So don't create a nativeCap.
    GP_CUSTOMLINECAP this;
    this.nativeCap = NULL;
    this.lastResult = eOk;
    return this;
}
*/

VOID GpCustomLineCap_Delete(GP_CUSTOMLINECAP * this)
{
    GdipDeleteCustomLineCap(this->nativeCap);
}

GpStatus  GpCustomLineCap_SetStrokeCaps(GP_CUSTOMLINECAP * this,
    GpLineCap startCap, GpLineCap endCap)
{
    return (this->lastResult =
                GdipSetCustomLineCapStrokeCaps(this->nativeCap, startCap, endCap));
}

GpStatus GpCustomLineCap_GetStrokeCaps(GP_CUSTOMLINECAP * this, GpLineCap* startCap, GpLineCap* endCap)
{
    return (this->lastResult = GdipGetCustomLineCapStrokeCaps(this->nativeCap,
                    startCap, endCap));
}


GpStatus GpCustomLineCap_SetStrokeJoin(GP_CUSTOMLINECAP * this, GpLineJoin lineJoin)
{
    return (this->lastResult = GdipSetCustomLineCapStrokeJoin(this->nativeCap,
                    lineJoin));
}


GpLineJoin GpCustomLineCap_GetStrokeJoin(GP_CUSTOMLINECAP * this)
{
    GpLineJoin lineJoin;
    (this->lastResult = GdipGetCustomLineCapStrokeJoin(this->nativeCap,&lineJoin));
    return lineJoin;
}

GpStatus GpCustomLineCap_SetBaseCap(GP_CUSTOMLINECAP * this, GpLineCap baseCap)
{
    return (this->lastResult = GdipSetCustomLineCapBaseCap(this->nativeCap,baseCap));
}

GpLineCap GpCustomLineCap_GetBaseCap(GP_CUSTOMLINECAP * this)
{
    GpLineCap baseCap;
    (this->lastResult = GdipGetCustomLineCapBaseCap(this->nativeCap, &baseCap));
    return baseCap;
}

GpStatus GpCustomLineCap_SetBaseInset(GP_CUSTOMLINECAP * this, REAL inset)
{
    return (this->lastResult = GdipSetCustomLineCapBaseInset(this->nativeCap,
                    inset));
}

REAL GpCustomLineCap_GetBaseInset(GP_CUSTOMLINECAP * this)
{
    REAL inset;
    (this->lastResult = GdipGetCustomLineCapBaseInset(this->nativeCap,
            &inset));
    return inset;
}

GpStatus GpCustomLineCap_SetWidthScale(GP_CUSTOMLINECAP * this, REAL widthScale)
{
    return (this->lastResult = GdipSetCustomLineCapWidthScale(this->nativeCap,
                    widthScale));
}

REAL GpCustomLineCap_GetWidthScale(GP_CUSTOMLINECAP * this)
{
    REAL widthScale;
    (this->lastResult = GdipGetCustomLineCapWidthScale(this->nativeCap,
            &widthScale));
    return widthScale;
}

GP_CUSTOMLINECAP GpCustomLineCap_Clone(GP_CUSTOMLINECAP * this)
{
    GP_CUSTOMLINECAP NewLineCap;
    (this->lastResult = GdipCloneCustomLineCap(this->nativeCap, &NewLineCap.nativeCap));
	return NewLineCap;
}

GP_ADJUSTABLEARROWCAP GpAdjustableArrowCap_AdjustableArrowCap(GP_GPADJUSTABLEARROWCAP* nativeCap,
    GpStatus status)
{
    GP_ADJUSTABLEARROWCAP this;
    this.lastResult = status;
	this.nativeCap = nativeCap;
    return this;
}

//GP_ADJUSTABLEARROWCAP Gp_AdjustableArrowCap(REAL height, REAL width, BOOL isFilled = TRUE)
GP_ADJUSTABLEARROWCAP Gp_AdjustableArrowCap(REAL height, REAL width, BOOL isFilled)
{
    GP_ADJUSTABLEARROWCAP this;
    GP_GPADJUSTABLEARROWCAP* cap = NULL;
    this.lastResult = GdipCreateAdjustableArrowCap(height, width, isFilled, &cap);
	this.nativeCap = cap;
    return this;
}

GpStatus GpAdjustableArrowCap_SetHeight(GP_ADJUSTABLEARROWCAP * this, REAL height)
{
    GP_GPADJUSTABLEARROWCAP* cap = (GP_GPADJUSTABLEARROWCAP*)this->nativeCap;
    return (this->lastResult = GdipSetAdjustableArrowCapHeight(cap, height));
}

REAL GpAdjustableArrowCap_GetHeight(GP_ADJUSTABLEARROWCAP * this)
{
    GP_GPADJUSTABLEARROWCAP* cap = (GP_GPADJUSTABLEARROWCAP*)this->nativeCap;
    REAL height;
    (this->lastResult = GdipGetAdjustableArrowCapHeight(cap, &height));
    return height;
}

GpStatus GpAdjustableArrowCap_SetWidth(GP_ADJUSTABLEARROWCAP * this, REAL width)
{
    GP_GPADJUSTABLEARROWCAP* cap = (GP_GPADJUSTABLEARROWCAP*)this->nativeCap;
    return (this->lastResult = GdipSetAdjustableArrowCapWidth(cap,width));
}

REAL GpAdjustableArrowCap_GetWidth(GP_ADJUSTABLEARROWCAP * this)
{
    GP_GPADJUSTABLEARROWCAP* cap = (GP_GPADJUSTABLEARROWCAP*)this->nativeCap;
    REAL width;
    (this->lastResult = GdipGetAdjustableArrowCapWidth(cap, &width));
    return width;
}

GpStatus GpAdjustableArrowCap_SetMiddleInset(GP_ADJUSTABLEARROWCAP * this,
    REAL middleInset)
{
    GP_GPADJUSTABLEARROWCAP* cap = (GP_GPADJUSTABLEARROWCAP*)this->nativeCap;
    return (this->lastResult = GdipSetAdjustableArrowCapMiddleInset(cap, middleInset));
}

REAL GpAdjustableArrowCap_GetMiddleInset(GP_ADJUSTABLEARROWCAP * this)
{
    GP_GPADJUSTABLEARROWCAP* cap = (GP_GPADJUSTABLEARROWCAP*)this->nativeCap;
    REAL middleInset;
    (this->lastResult = GdipGetAdjustableArrowCapMiddleInset(cap,&middleInset));
    return middleInset;
}

GpStatus GpAdjustableArrowCap_SetFillState(GP_ADJUSTABLEARROWCAP * this, BOOL isFilled)
{
    GP_GPADJUSTABLEARROWCAP* cap = (GP_GPADJUSTABLEARROWCAP*)this->nativeCap;
    return (this->lastResult = GdipSetAdjustableArrowCapFillState(cap, isFilled));
}

BOOL GpAdjustableArrowCap_IsFilled(GP_ADJUSTABLEARROWCAP * this)
{
    GP_GPADJUSTABLEARROWCAP* cap = (GP_GPADJUSTABLEARROWCAP*)this->nativeCap;
    BOOL isFilled;
    (this->lastResult = GdipGetAdjustableArrowCapFillState(cap, &isFilled));
    return isFilled;
}

