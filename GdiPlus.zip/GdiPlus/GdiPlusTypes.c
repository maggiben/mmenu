/**************************************************************************\
*
* All files in GdiPlusLib have been modified from the Microsoft
* GdiPlus C++ header files.
*
* Module Name:
*
*   GplusTypes.c
*
* Abstract:
*
*   Functions for basic types used by GdiPlus
*
\**************************************************************************/

#include "GdiPlusTypes.h"
#include "GdiPlusEnums.h"

// SizeF
SIZEF GpSizeF(REAL w, REAL h)
{
	SIZEF this;
	this.Width  = w;
	this.Height = h;
	return this;
}

VOID GpSizeF_Cpy(SIZEF * this, SIZEF * size)
{
	this->Width  = size->Width;
	this->Height = size->Height;
}

VOID GpSizeF_Set(SIZEF * this, REAL width, REAL height)
{
	this->Width  = width;
	this->Height = height;
}

SIZEF GpSizeF_Add(SIZEF * this, SIZEF * sz)
{
	SIZEF sf;
	sf.Width  = this->Width + sz->Width;
	sf.Height = this->Height + sz->Height;
	return sf;
}

SIZEF GpSizeF_Sub(SIZEF * this, SIZEF * sz)
{
	SIZEF sf;
	sf.Width  = this->Width - sz->Width;
	sf.Height = this->Height - sz->Height;
	return sf;
}

BOOL GpSizeF_IsEqual(SIZEF * this, SIZEF * sz)
{
	return (this->Width == sz->Width) && (this->Height == sz->Height);
}

BOOL GpSizeF_IsEmpty(SIZEF * this)
{
	return (this->Width == 0.0f && this->Height == 0.0f);
}

// Size
GP_SIZEI GpSizeI(INT w, INT h)
{
	GP_SIZEI this;
	this.Width  = w;
	this.Height = h;
	return this;
}

VOID GpSizeI_Cpy(GP_SIZEI * this, GP_SIZEI * sz)
{
	this->Width  = sz->Width;
	this->Height = sz->Height;
}

VOID GpSizeI_Set(GP_SIZEI * this, INT width, INT height)
{
	this->Width  = width;
	this->Height = height;
}

GP_SIZEI GpSizeI_Add(GP_SIZEI * this, GP_SIZEI * sz)
{
	GP_SIZEI si;
	si.Width  = this->Width + sz->Width;
	si.Height = this->Height + sz->Height;
	return si;
}

GP_SIZEI GpSizeI_Sub(GP_SIZEI * this, GP_SIZEI * sz)
{
	GP_SIZEI si;
	si.Width  = this->Width - sz->Width;
	si.Height = this->Height - sz->Height;
	return si;
}

BOOL GpSizeI_IsEqual(GP_SIZEI * this, GP_SIZEI * sz)
{
	return (this->Width == sz->Width) && (this->Height == sz->Height);
}

BOOL GpSizeI_IsEmpty(GP_SIZEI * this)
{
	return (this->Width == 0 && this->Height == 0);
}

// PointF
POINTF GpPointF(REAL x, REAL y)
{
	POINTF this;
	this.X = x;
	this.Y = y;
	return this;
}

VOID GpPointF_Cpy(POINTF * this, POINTF * pointf)
{
	this->X = pointf->X;
	this->Y = pointf->Y;
}

VOID GpPointF_Size(POINTF * this, SIZEF * size)
{
	this->X = size->Width;
	this->Y = size->Height;
}

VOID GpPointF_Set(POINTF * this, REAL x, REAL y)
{
	this->X = x;
	this->Y = y;
}

POINTF GpPointF_Add(POINTF * this, POINTF * pointf)
{
	POINTF pf;
	pf.X = this->X + pointf->X;
	pf.Y = this->Y + pointf->Y;
	return pf;
}

POINTF GpPointF_Sub(POINTF * this, POINTF * pointf)
{
	POINTF pf;
	pf.X = this->X - pointf->X;
	pf.Y = this->Y - pointf->Y;
	return pf;
}

BOOL GpPointF_IsEqual(POINTF * this, POINTF * pointf)
{
	return (this->X == pointf->X) && (this->Y == pointf->Y);
}

// Point
POINTI GpPointI(INT x, INT y)
{
	POINTI this;
	this.X = x;
	this.Y = y;
	return this;
}

VOID GpPointI_Cpy(POINTI * this, POINTI * point)
{
	this->X = point->X;
	this->Y = point->Y;
}

VOID GpPointI_Size(POINTI * this, GP_SIZEI *size)
{
	this->X = size->Width;
	this->Y = size->Height;
}

VOID GpPointI_Set(POINTI * this, INT x, INT y)
{
	this->X = x;
	this->Y = y;
}

POINTI GpPointI_Add(POINTI * this, POINTI * point)
{
	POINTI pt;
	pt.X = this->X + point->X;
	pt.Y = this->Y + point->Y;
	return pt;
}

POINTI GpPointI_Sub(POINTI * this, POINTI * point)
{
	POINTI pt;
	pt.X = this->X - point->X;
	pt.Y = this->Y - point->Y;
	return pt;
}

BOOL GpPointI_IsEqual(POINTI * this, POINTI * point)
{
	 return (this->X == point->X) && (this->Y == point->Y);
}

// RectF
RECTF GpRectF(REAL x, REAL y, REAL width, REAL height)
{
	RECTF this;
	this.X = x;
	this.Y = y;
	this.Width = width;
	this.Height = height;
	return this;
}

VOID GpRectF_Set(RECTF * this, REAL x, REAL y, REAL width, REAL height)
{
	this->X 	   = x;
	this->Y 	   = y;
	this->Width  = width;
	this->Height = height;
}


RECTF GpRectF_Clone(RECTF * this)
{
	RECTF rf = *this;
	return rf;
}

VOID GpRectF_GetLocation(RECTF * this, POINTF * pointf)
{
	pointf->X = this->X;
	pointf->Y = this->Y;
}

VOID GpRectF_GetSize(RECTF * this, SIZEF * size)
{
	size->Width  = this->Width;
	size->Height = this->Height;
}

VOID GpRectF_GetBounds(RECTF * this, RECTF * rect)
{
	rect->X      = this->X;
	rect->Y      = this->Y;
	rect->Width  = this->Width;
	rect->Height = this->Height;
}

REAL GpRectF_GetLeft(RECTF * this)
{
	return this->X;
}

REAL GpRectF_GetTop(RECTF * this)
{
	return this->Y;
}

REAL GpRectF_GetRight(RECTF * this)
{
	return this->X + this->Width;
}

REAL GpRectF_GetBottom(RECTF * this)
{
	return this->Y + this->Height;
}

BOOL GpRectF_IsEmptyArea(RECTF * this)
{
	return (this->Width <= REAL_EPSILON) || (this->Height <= REAL_EPSILON);
}

BOOL GpRectF_IsEqual(RECTF * this, RECTF * rect)
{
	return this->X == (rect->X && this->Y == rect->Y && this->Width == rect->Width && this->Height == rect->Height);
}

BOOL GpRectF_Contains(RECTF * this, REAL x, REAL y)
{
	return (x >= this->X && x < this->X + this->Width && y >= this->Y && y < this->Y + this->Height);
}

BOOL GpRectF_ContainsPtF(RECTF* this, const POINTF* pt)
{
    return GpRectF_Contains(this, pt->X, pt->Y);
}

VOID GpRectF_Inflate(RECTF * this, REAL dx, REAL dy)
{
	this->X -= dx;
	this->Y -= dy;
	this->Width += 2*dx;
	this->Height += 2*dy;
}

BOOL GpRectF_Intersect(RECTF * c, RECTF * a, RECTF * b)
{
	REAL right  = min(GpRectF_GetRight(a), GpRectF_GetRight(b));
	REAL bottom = min(GpRectF_GetBottom(a), GpRectF_GetBottom(b));
	REAL left   = max(GpRectF_GetLeft(a), GpRectF_GetLeft(b));
	REAL top    = max(GpRectF_GetTop(a), GpRectF_GetTop(b));

	c->X = left;
	c->Y = top;
	c->Width = right - left;
	c->Height = bottom - top;
	return !GpRectF_IsEmptyArea(c);
}

BOOL GpRectF_IntersectsWith(RECTF * this, RECTF* rect)
{
	return (GpRectF_GetLeft(this) < GpRectF_GetRight(rect) && GpRectF_GetTop(this) < GpRectF_GetBottom(rect) &&
			 GpRectF_GetRight(this) > GpRectF_GetLeft(rect) && GpRectF_GetBottom(this) > GpRectF_GetTop(rect));
}

BOOL GpRectF_Union(RECTF * c, RECTF * a, RECTF * b)
{
	REAL right  = max(GpRectF_GetRight(a), GpRectF_GetRight(b));
	REAL bottom = max(GpRectF_GetBottom(a), GpRectF_GetBottom(b));
	REAL left   = min(GpRectF_GetLeft(a), GpRectF_GetLeft(b));
	REAL top    = min(GpRectF_GetTop(a), GpRectF_GetTop(b));

	c->X = left;
	c->Y = top;
	c->Width = right - left;
	c->Height = bottom - top;
	return !GpRectF_IsEmptyArea(c);
}

VOID GpRectF_Offset(RECTF * this, REAL dx, REAL dy)
{
	this->X += dx;
	this->Y += dy;
}

VOID GpRectF_OffsetRcF(RECTF* this, const RECTF* point)
{
    GpRectF_Offset(this, point->X, point->Y);
}

// Rect
RECTI GpRectI(INT x, INT y, INT width, INT height)
{
	RECTI this;
	this.X = x;
	this.Y = y;
	this.Width = width;
	this.Height = height;
	return this;
}

VOID GpRectI_Set(RECTI * this, INT x, INT y, INT width, INT height)
{
	this->X 	   = x;
	this->Y 	   = y;
	this->Width  = width;
	this->Height = height;
}

RECTI GpRectI_Clone(RECTI * this)
{
	RECTI rf = *this;
	return rf;
}

VOID GpRectI_GetLocationPt(RECTI * this, POINTI * point)
{
	point->X = this->X;
	point->Y = this->Y;
}

VOID GpRectI_GetSize(RECTI * this, GP_SIZEI * size)
{
	size->Width  = this->Width;
	size->Height = this->Height;
}

VOID GpRectI_GetBounds(RECTI * this, RECTI * rect)
{
	rect->X      = this->X;
	rect->Y      = this->Y;
	rect->Width  = this->Width;
	rect->Height = this->Height;
}

REAL GpRectI_GetLeft(RECTI * this)
{
	return this->X;
}

REAL GpRectI_GetTop(RECTI * this)
{
	return this->Y;
}

REAL GpRectI_GetRight(RECTI * this)
{
	return this->X + this->Width;
}

REAL GpRectI_GetBottom(RECTI * this)
{
	return this->Y + this->Height;
}

BOOL GpRectI_IsEmptyArea(RECTI * this)
{
	return (this->Width <= REAL_EPSILON) || (this->Height <= REAL_EPSILON);
}

BOOL GpRectI_IsEqual(RECTI * this, RECTI * rect)
{
	return this->X == (rect->X && this->Y == rect->Y && this->Width == rect->Width && this->Height == rect->Height);
}

BOOL GpRectI_Contains(RECTI * this, INT x, INT y)
{
	return (x >= this->X && x < this->X + this->Width && y >= this->Y && y < this->Y + this->Height);
}

BOOL GpRectI_ContainsPt(RECTI * this, POINTI * pt)
{
	return GpRectI_Contains(this, pt->X, pt->Y);
}

VOID GpRectI_Inflate(RECTI * this, INT dx, INT dy)
{
	this->X -= dx;
	this->Y -= dy;
	this->Width += 2*dx;
	this->Height += 2*dy;
}

BOOL GpRectI_Intersect(RECTI * c, RECTI * a, RECTI * b)
{
	REAL right  = min(GpRectI_GetRight(a), GpRectI_GetRight(b));
	REAL bottom = min(GpRectI_GetBottom(a), GpRectI_GetBottom(b));
	REAL left   = max(GpRectI_GetLeft(a), GpRectI_GetLeft(b));
	REAL top    = max(GpRectI_GetTop(a), GpRectI_GetTop(b));

	c->X = left;
	c->Y = top;
	c->Width = right - left;
	c->Height = bottom - top;
	return !GpRectI_IsEmptyArea(c);
}

BOOL GpRectI_IntersectsWith(RECTI * this, RECTI * rect)
{
	return (GpRectI_GetLeft(this) < GpRectI_GetRight(rect) && GpRectI_GetTop(this) < GpRectI_GetBottom(rect) &&
			 GpRectI_GetRight(this) > GpRectI_GetLeft(rect) && GpRectI_GetBottom(this) > GpRectI_GetTop(rect));
}

BOOL GpRectI_Union(RECTI * c, RECTI * a, RECTI * b)
{
	REAL right  = max(GpRectI_GetRight(a), GpRectI_GetRight(b));
	REAL bottom = max(GpRectI_GetBottom(a), GpRectI_GetBottom(b));
	REAL left   = min(GpRectI_GetLeft(a), GpRectI_GetLeft(b));
	REAL top    = min(GpRectI_GetTop(a), GpRectI_GetTop(b));

	c->X = left;
	c->Y = top;
	c->Width = right - left;
	c->Height = bottom - top;
	return !GpRectI_IsEmptyArea(c);
}

VOID GpRectI_Offset(RECTI * this, INT dx, INT dy)
{
	this->X += dx;
	this->Y += dy;
}

VOID GpRectI_OffsetPt(RECTI * this, POINTI * point)
{
	GpRectI_Offset(this, point->X, point->Y);
}

BOOL ObjectTypeIsValid(GpObjectType type)
{
	return ((type >= eObjectTypeMin) && (type <= eObjectTypeMax));
}
