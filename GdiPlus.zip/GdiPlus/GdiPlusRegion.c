/**************************************************************************\
*
* All files in GdiPlusLib have been modified from the Microsoft
* GdiPlus C++ header files.
*
* Module Name:
*
*   GdiPlusRegion.c
*
* Abstract:
*
*   Region related functions
*
\**************************************************************************/

#include "GdiPlusRegion.h"
#include "GdiPlusPath.h"
#include "GdiPlusMatrix.h"
#include "GdiPlusGraphics.h"

GP_REGION GpRegion(VOID)
{
    GP_REGION this;
    GP_GPREGION *region = NULL;
    this.lastResult = GdipCreateRegion(&region);
	this.nativeRegion = region;
    return this;
}

GP_REGION GpRegion_RcF(RECTF * rect)
{
    GP_REGION this;
    GP_GPREGION *region = NULL;
    this.lastResult = GdipCreateRegionRect(rect, &region);
	this.nativeRegion = region;
    return this;
}

GP_REGION GpRegion_RcI(const RECTI * rect)
{
    GP_REGION this;
    GP_GPREGION *region = NULL;
    this.lastResult = GdipCreateRegionRectI(rect, &region);
	this.nativeRegion = region;
    return this;
}

GP_REGION GpRegion_GraphPath(const GP_GRAPHICSPATH* path)
{
    GP_REGION this;
    GP_GPREGION *region = NULL;
    this.lastResult = GdipCreateRegionPath((GP_GPPATH*)path->nativePath, &region);
	this.nativeRegion = region;
    return this;
}

GP_REGION GpRegion_RgnData(const BYTE* regionData, INT size)
{
    GP_REGION this;
    GP_GPREGION *region = NULL;
    this.lastResult = GdipCreateRegionRgnData(regionData, size, &region);
	this.nativeRegion = region;
    return this;
}

GP_REGION GpRegion_Hrgn(HRGN hRgn)
{
    GP_REGION this;
    GP_GPREGION *region = NULL;
    this.lastResult = GdipCreateRegionHrgn(hRgn, &region);
	this.nativeRegion = region;
    return this;
}

VOID GpRegion_Delete(GP_REGION * this)
{
    GdipDeleteRegion(this->nativeRegion);
}

GP_REGION GpRegion_Clone(GP_REGION * this)
{
    GP_GPREGION *region = NULL;
    (this->lastResult = GdipCloneRegion(this->nativeRegion, &region));
	GP_REGION that;
	that.nativeRegion = region;
	that.lastResult  = this->lastResult;
    return that;
}

GpStatus GpRegion_MakeInfinite(GP_REGION * this)
{
    return (this->lastResult = GdipSetInfinite(this->nativeRegion));
}

GpStatus GpRegion_MakeEmpty(GP_REGION * this)
{
    return (this->lastResult = GdipSetEmpty(this->nativeRegion));
}

GpStatus GpRegion_Intersect(GP_REGION * this, const RECTF * rect)
{
    return (this->lastResult = GdipCombineRegionRect(this->nativeRegion, rect, eCombineModeIntersect));
}

GpStatus GpRegion_IntersectRcI(GP_REGION * this, const RECTI * rect)
{
    return (this->lastResult = GdipCombineRegionRectI(this->nativeRegion, rect, eCombineModeIntersect));
}

GpStatus GpRegion_IntersectGraphPath(GP_REGION * this, const GP_GRAPHICSPATH* path)
{
    return (this->lastResult = GdipCombineRegionPath(this->nativeRegion, (GP_GPPATH*)path->nativePath, eCombineModeIntersect));
}

GpStatus GpRegion_IntersectRegion(GP_REGION * this, const GP_REGION* region)
{
    return (this->lastResult = GdipCombineRegionRegion(this->nativeRegion, region->nativeRegion, eCombineModeIntersect));
}

GpStatus GpRegion_UnionRcF(GP_REGION * this, const RECTF * rect)
{
    return (this->lastResult = GdipCombineRegionRect(this->nativeRegion, rect, eCombineModeUnion));
}

GpStatus GpRegion_UnionRcI(GP_REGION * this, const RECTI * rect)
{
    return (this->lastResult = GdipCombineRegionRectI(this->nativeRegion, rect, eCombineModeUnion));
}

GpStatus GpRegion_UnionGraphPath(GP_REGION * this, const GP_GRAPHICSPATH* path)
{
    return (this->lastResult = GdipCombineRegionPath(this->nativeRegion, (GP_GPPATH*)path->nativePath, eCombineModeUnion));
}

GpStatus GpRegion_UnionRegion(GP_REGION * this, const GP_REGION* region)
{
    return (this->lastResult = GdipCombineRegionRegion(this->nativeRegion, region->nativeRegion, eCombineModeUnion));
}

GpStatus GpRegion_XorRcF(GP_REGION * this, const RECTF * rect)
{
    return (this->lastResult = GdipCombineRegionRect(this->nativeRegion, rect, eCombineModeXor));
}

GpStatus GpRegion_XorRcI(GP_REGION * this, const RECTI * rect)
{
    return (this->lastResult = GdipCombineRegionRectI(this->nativeRegion, rect, eCombineModeXor));
}

GpStatus GpRegion_XorGraphPath(GP_REGION * this, const GP_GRAPHICSPATH* path)
{
    return (this->lastResult = GdipCombineRegionPath(this->nativeRegion, (GP_GPPATH*)path->nativePath, eCombineModeXor));
}

GpStatus GpRegion_XorRegion(GP_REGION * this, const GP_REGION* region)
{ 
    return (this->lastResult = GdipCombineRegionRegion(this->nativeRegion, region->nativeRegion, eCombineModeXor));
}

GpStatus GpRegion_ExcludeRcF(GP_REGION * this, const RECTF * rect)
{
    return (this->lastResult = GdipCombineRegionRect(this->nativeRegion, rect, eCombineModeExclude));
}

GpStatus GpRegion_ExcludeRcI(GP_REGION * this, const RECTI * rect)
{
    return (this->lastResult = GdipCombineRegionRectI(this->nativeRegion, rect, eCombineModeExclude));
}

GpStatus GpRegion_ExcludeGraphPath(GP_REGION * this, const GP_GRAPHICSPATH* path)
{
    return (this->lastResult = GdipCombineRegionPath(this->nativeRegion,
                    (GP_GPPATH*)path->nativePath, eCombineModeExclude));
}

GpStatus GpRegion_ExcludeRegion(GP_REGION * this, const GP_REGION* region)
{
    return (this->lastResult = GdipCombineRegionRegion(this->nativeRegion,
                    region->nativeRegion, eCombineModeExclude));
}

GpStatus GpRegion_ComplementRcF(GP_REGION * this, const RECTF * rect)
{
    return (this->lastResult = GdipCombineRegionRect(
                    this->nativeRegion, rect, eCombineModeComplement));
}

GpStatus GpRegion_ComplementRcI(GP_REGION * this, const RECTI * rect)
{
    return (this->lastResult = GdipCombineRegionRectI(this->nativeRegion,
                    rect, eCombineModeComplement));
}

GpStatus GpRegion_ComplementGraphPath(GP_REGION * this, const GP_GRAPHICSPATH* path)
{
    return (this->lastResult = GdipCombineRegionPath(this->nativeRegion,
                    (GP_GPPATH*)path->nativePath, eCombineModeComplement));
}

GpStatus GpRegion_ComplementRegion(GP_REGION * this, const GP_REGION* region)
{
    return (this->lastResult = GdipCombineRegionRegion(this->nativeRegion,
                    region->nativeRegion, eCombineModeComplement));
}

GpStatus GpRegion_TranslateF(GP_REGION * this, REAL dx, REAL dy)
{
    return (this->lastResult = GdipTranslateRegion(this->nativeRegion, dx, dy));
}

GpStatus GpRegion_TranslateI(GP_REGION * this, INT dx, INT dy)
{
    return (this->lastResult = GdipTranslateRegionI(this->nativeRegion, dx, dy));
}

GpStatus GpRegion_Transform(GP_REGION * this, const GP_MATRIX* matrix)
{
    return (this->lastResult = GdipTransformRegion(this->nativeRegion, matrix->nativeMatrix));
}

GpStatus GpRegion_GetBoundsRcF(GP_REGION * this, RECTF* rect, const GP_GRAPHICS* g)
{
    return (this->lastResult = GdipGetRegionBounds(this->nativeRegion, g->nativeGraphics, rect));
}

GpStatus GpRegion_GetBoundsRcI(GP_REGION * this, RECTI* rect, const GP_GRAPHICS* g)
{
    return (this->lastResult = GdipGetRegionBoundsI(this->nativeRegion, 
						g->nativeGraphics, rect));
}

HRGN GpRegion_GetHRGN(GP_REGION * this, const GP_GRAPHICS* g)
{
    HRGN hrgn;
    (this->lastResult = GdipGetRegionHRgn(this->nativeRegion, g->nativeGraphics, &hrgn));
    return hrgn;
}

BOOL GpRegion_IsEmpty(GP_REGION * this, const GP_GRAPHICS *g)
{
    BOOL booln = FALSE;
    (this->lastResult = GdipIsEmptyRegion(this->nativeRegion, g->nativeGraphics, &booln));
    return booln;
}

BOOL GpRegion_IsInfinite(GP_REGION * this,  const GP_GRAPHICS *g)
{
    BOOL booln = FALSE;
    (this->lastResult = GdipIsInfiniteRegion(this->nativeRegion, g->nativeGraphics, &booln));
    return booln;
}

BOOL GpRegion_Equals(GP_REGION * this, const GP_REGION* region, const GP_GRAPHICS* g)
{
    BOOL booln = FALSE;
    (this->lastResult = GdipIsEqualRegion(this->nativeRegion,region->nativeRegion,
			g->nativeGraphics, &booln));
    return booln;
}

UINT GpRegion_GetDataSize(GP_REGION * this)
{
    UINT bufferSize = 0;
    (this->lastResult = GdipGetRegionDataSize(this->nativeRegion,&bufferSize));
    return bufferSize;
}

// buffer     - where to put the data
// bufferSize - how big the buffer is (should be at least as big as GetDataSize())
// sizeFilled - if not NULL, this is an OUT param that says how many bytes
//              of data were written to the buffer.
GpStatus GpRegion_GetData(GP_REGION * this, BYTE* buffer, UINT bufferSize, 
			UINT* sizeFilled)
{
    return (this->lastResult = GdipGetRegionData(this->nativeRegion,
                    buffer,bufferSize,sizeFilled));
}

// Hit testing operations
BOOL GpRegion_IsVisiblePtF(GP_REGION * this, const POINTF * point,
    const GP_GRAPHICS* g)
{
    BOOL booln = FALSE;
    (this->lastResult = GdipIsVisibleRegionPoint(this->nativeRegion, 
			point->X, point->Y, (g == NULL) ? NULL : g->nativeGraphics, &booln));
    return booln;
}

BOOL GpRegion_IsVisibleRcF(GP_REGION * this,  const RECTF * rect,
    const GP_GRAPHICS* g)
{
    BOOL booln = FALSE;
    (this->lastResult = GdipIsVisibleRegionRect(this->nativeRegion, 
			rect->X, rect->Y, rect->Width, rect->Height, 
			(g == NULL) ? NULL : g->nativeGraphics, &booln));
    return booln;
}

BOOL GpRegion_IsVisiblePtI(GP_REGION * this, const POINTI * point, const GP_GRAPHICS* g)
{
    BOOL booln = FALSE;
    (this->lastResult = GdipIsVisibleRegionPointI(this->nativeRegion, 
			point->X, point->Y, (g == NULL) ? NULL : g->nativeGraphics, &booln));
    return booln;
}

BOOL GpRegion_IsVisibleRcI(GP_REGION * this, const RECTI * rect, const GP_GRAPHICS* g)
{
    BOOL booln = FALSE;
    (this->lastResult = GdipIsVisibleRegionRectI(this->nativeRegion, 
			rect->X, rect->Y, rect->Width, rect->Height, 
			(g == NULL) ? NULL : g->nativeGraphics, &booln));
    return booln;
}

UINT GpRegion_GetRegionScansCount(GP_REGION * this, const GP_MATRIX* matrix)
{
    UINT count = 0;
    (this->lastResult = GdipGetRegionScansCount(this->nativeRegion,
            &count, matrix->nativeMatrix));
    return count;
}

GpStatus GpRegion_GetRegionScansRcF(GP_REGION * this,
    const GP_MATRIX* matrix, RECTF* rects, INT* count)
{
    return (this->lastResult = GdipGetRegionScans(this->nativeRegion,
                    rects, count, matrix->nativeMatrix));
}

// If rects is NULL, return the count of rects in the region.
// Otherwise, assume rects is big enough to hold all the region rects
// and fill them in and return the number of rects filled in.
// The rects are returned in the units specified by the matrix
// (which is typically a world-to-device transform).
// Note that the number of rects returned can vary, depending on the
// matrix that is used.
GpStatus GpRegion_GetRegionScansRcI(GP_REGION * this,
    const GP_MATRIX* matrix, RECTI* rects, INT* count)
{
    return (this->lastResult = GdipGetRegionScansI(this->nativeRegion,
                    rects, count, matrix->nativeMatrix));
}

