/**************************************************************************\
*
* All files in GdiPlusLib have been modified from the Microsoft
* GdiPlus C++ header files.
*
* Module Name:
*
*   GdiPlusPen.c
*
* Abstract:
*
*   Pen related functions
*
\**************************************************************************/

#include "GdiPlusEnums.h"
#include "GdiPlusPen.h"
#include "GdiPlusColor.h"
#include "GdiPlusBrush.h"
#include "GdiPlusMatrix.h"
#include "GdiplusLineCaps.h"

VOID GpPen_Delete(GP_PEN * this)
{
	GdipDeletePen(this->nativePen);
}

GP_PEN GpPen_Color(COLOR * color, REAL width)
{
    GP_PEN this;
    GpUnit unit = eUnitWorld;
    this.nativePen = NULL;
    this.lastResult = GdipCreatePen1(color->Argb, width, unit, &this.nativePen);
    return this;
}

GP_PEN GpPen_Brush(GP_BRUSH * brush, REAL width)
{
    GP_PEN this;
    GpUnit unit = eUnitWorld;
    this.nativePen = NULL;
    this.lastResult = GdipCreatePen2(brush->nativeBrush,
                                    width, unit, &this.nativePen);
    return this;
}

static GP_PEN GpPenPen(GP_GPPEN * nativePen, GpStatus status)
{
    GP_PEN this;
    this.lastResult = status;
	this.nativePen = nativePen;
    return this;
}

GP_PEN GpPen_Clone(GP_PEN * this)
{
    GP_GPPEN * clonePen = NULL;
    this->lastResult = GdipClonePen(this->nativePen, &clonePen);
    return GpPenPen(clonePen, this->lastResult);
}

GpStatus GpPen_SetWidth(GP_PEN * this, REAL width)
{
	return (this->lastResult = GdipSetPenWidth(this->nativePen, width));
}

REAL GpPen_GetWidth(GP_PEN * this)
{
    REAL width;
    this->lastResult = GdipGetPenWidth(this->nativePen, &width);
    return width;
}

GpStatus GpPen_SetStartCap(GP_PEN * this,GpLineCap startCap)
{
    return (this->lastResult = GdipSetPenStartCap(this->nativePen, startCap));
}

GpStatus GpPen_SetEndCap(GP_PEN * this,GpLineCap endCap)
{
    return (this->lastResult = GdipSetPenEndCap(this->nativePen, endCap));
}

GpLineCap GpPen_GetStartCap(GP_PEN * this)
{
	GpLineCap startCap;
	this->lastResult = GdipGetPenStartCap(this->nativePen, &startCap);
	return startCap;
}

GpLineCap GpPen_GetEndCap(GP_PEN * this)
{
	GpLineCap endCap;
	this->lastResult = GdipGetPenEndCap(this->nativePen, &endCap);
	return endCap;
}

GpStatus GpPen_SetLineJoin(GP_PEN * this, GpLineJoin lineJoin)
{
    return (this->lastResult = GdipSetPenLineJoin(this->nativePen, lineJoin));
}

GpLineJoin GpPen_GetLineJoin(GP_PEN * this)
{
    GpLineJoin lineJoin;
    this->lastResult = GdipGetPenLineJoin(this->nativePen, &lineJoin);
    return lineJoin;
}

GpStatus GpPen_SetCustomStartCap(GP_PEN * this, GP_CUSTOMLINECAP * customCap)
{
    GP_GPCUSTOMLINECAP * nativeCap = NULL;
    if(customCap)
        nativeCap = customCap->nativeCap;
    return (this->lastResult = GdipSetPenCustomStartCap(this->nativePen, nativeCap));
}

GpStatus GpPen_GetCustomStartCap(GP_PEN * this, GP_CUSTOMLINECAP* customCap)
{
    if(!customCap)
        return (this->lastResult = eInvalidParameter);
    return (this->lastResult = GdipGetPenCustomStartCap(this->nativePen, &(customCap->nativeCap)));
}

GpStatus GpPen_SetCustomEndCap(GP_PEN * this, const GP_CUSTOMLINECAP* customCap)
{
    GP_GPCUSTOMLINECAP* nativeCap = NULL;
    if(customCap)
        nativeCap = customCap->nativeCap;
    return (this->lastResult = GdipSetPenCustomEndCap(this->nativePen, nativeCap));
}

GpStatus GpPen_GetCustomEndCap(GP_PEN * this, GP_CUSTOMLINECAP* customCap)
{
    if(!customCap)
        return (this->lastResult = eInvalidParameter);

    return (this->lastResult = GdipGetPenCustomEndCap(this->nativePen, &(customCap->nativeCap)));
}

GpStatus GpPen_SetMiterLimit(GP_PEN * this, REAL miterLimit)
{
    return (this->lastResult = GdipSetPenMiterLimit(this->nativePen, miterLimit));
}

REAL GpPen_GetMiterLimit(GP_PEN * this)
{
    REAL miterLimit;
    this->lastResult = GdipGetPenMiterLimit(this->nativePen, &miterLimit);
    return miterLimit;
}

GpStatus GpPen_SetAlignment(GP_PEN * this, GpPenAlignment penAlignment)
{
    return (this->lastResult = GdipSetPenMode(this->nativePen, penAlignment));
}

GpPenAlignment GpPen_GetAlignment(GP_PEN * this)
{
    GpPenAlignment penAlignment;
    this->lastResult = GdipGetPenMode(this->nativePen, &penAlignment);
    return penAlignment;
}

GpStatus GpPen_SetTransform(GP_PEN * this, GP_MATRIX * matrix)
{
    return (this->lastResult = GdipSetPenTransform(this->nativePen, matrix->nativeMatrix));
}

GpStatus GpPen_GetTransform(GP_PEN * this, GP_MATRIX* matrix)
{
    return (this->lastResult = GdipGetPenTransform(this->nativePen, matrix->nativeMatrix));
}

GpStatus GpPen_ResetTransform(GP_PEN * this)
{
    return (this->lastResult = GdipResetPenTransform(this->nativePen));
}

GpStatus GpPen_MultiplyTransform(GP_PEN * this, const GP_MATRIX* matrix, GpMatrixOrder order)
{
    return (this->lastResult = GdipMultiplyPenTransform(this->nativePen,
                                      matrix->nativeMatrix, order));
}

GpStatus GpPen_TranslateTransform(GP_PEN * this, REAL dx, REAL dy, GpMatrixOrder order)
{
    return (this->lastResult = GdipTranslatePenTransform(this->nativePen, dx, dy, order));
}

GpStatus GpPen_ScaleTransform(GP_PEN * this, REAL sx, REAL sy, GpMatrixOrder order)
{
    return (this->lastResult = GdipScalePenTransform(this->nativePen,
                                                             sx, sy, order));
}

GpStatus GpPen_RotateTransform(GP_PEN * this,REAL angle, GpMatrixOrder order)
{
    return (this->lastResult = GdipRotatePenTransform(this->nativePen,
                                                              angle, order));
}

GpPenType GpPen_GetPenType(GP_PEN * this)
{
    GpPenType type;
    this->lastResult = GdipGetPenFillType(this->nativePen, &type);
    return type;
}

GpStatus GpPen_SetColor(GP_PEN * this, const COLOR * color)
{
    return (this->lastResult = GdipSetPenColor(this->nativePen, color->Argb));
}

GpStatus GpPen_SetBrush(GP_PEN * this, const GP_BRUSH* brush)
{
    return (this->lastResult = GdipSetPenBrushFill(this->nativePen,
                                       brush->nativeBrush));
}

GpStatus GpPen_GetColor( GP_PEN * this, COLOR * color)
{
    if (color == NULL)
    {
        return (this->lastResult = eInvalidParameter);
    }

    GpPenType type = GpPen_GetPenType(this);

    if (type != ePenTypeSolidColor)
    {
        return eWrongState;
    }

    ARGB argb;

    this->lastResult = GdipGetPenColor(this->nativePen, &argb);
    if (this->lastResult == eOk)
    {
        GpColor_SetValue(color, argb);
    }

    return this->lastResult;
}

// THIS NEEDS WORK

GP_BRUSH * GpPen_GetBrush(GP_PEN * this)
{
    GpPenType type = GpPen_GetPenType(this);

    GP_BRUSH * brush = NULL;

    switch(type)
    {
        case ePenTypeSolidColor:
           // brush = new SolidBrush();
		   // brush = &(GP_BRUSH)GP_SolidBrush();
           break;

        case ePenTypeHatchFill:
           // brush = new HatchBrush();
		   // brush = (GP_BRUSH*)GP_HatchBrush();
           break;

        case ePenTypeTextureFill:
           // brush = new TextureBrush();
		   // brush = (GP_BRUSH*)GP_TextureBrush();
           break;

        case ePenTypePathGradient:
           // brush = new Brush();
		   // brush = (GP_BRUSH*)GP_Brush();
           break;

        case ePenTypeLinearGradient:
           // brush = new LinearGradientBrush();
		   // brush = (GP_BRUSH*)GP_LinearGradientBrush();
           break;

        default:
           break;
    }

    if(brush)
    {
        GP_GPBRUSH* nativeBrush;
        this->lastResult = GdipGetPenBrushFill(this->nativePen, &nativeBrush);
    }

    return brush;
}

GpDashStyle GpPen_GetDashStyle(GP_PEN * this)
{
    GpDashStyle dashStyle;
    this->lastResult = GdipGetPenDashStyle(this->nativePen, &dashStyle);
    return dashStyle;
}

GpStatus GpPen_SetDashStyle(GP_PEN * this, GpDashStyle dashStyle)
{
    return (this->lastResult = GdipSetPenDashStyle(this->nativePen, dashStyle));
}

REAL GpPen_GetDashOffset(GP_PEN * this)
{
    REAL dashOffset;
    this->lastResult = GdipGetPenDashOffset(this->nativePen, &dashOffset);
    return dashOffset;
}

GpStatus GpPen_SetDashOffset(GP_PEN * this, REAL dashOffset)
{
    return (this->lastResult = GdipSetPenDashOffset(this->nativePen, dashOffset));
}

GpStatus GpPen_SetDashPattern(GP_PEN * this, const REAL* dashArray, INT count)
{
    return (this->lastResult = GdipSetPenDashArray(this->nativePen, dashArray,
                                                    count));
}

INT GpPen_GetDashPatternCount(GP_PEN * this)
{
    INT count = 0;
    this->lastResult = GdipGetPenDashCount(this->nativePen, &count);
    return count;
}

GpStatus GpPen_GetDashPattern(GP_PEN * this, REAL * dashArray, INT count)
{
    if (dashArray == NULL || count <= 0)
            return (this->lastResult = eInvalidParameter);

    return (this->lastResult = GdipGetPenDashArray(this->nativePen, dashArray, count));
}

GpStatus GpPen_SetCompoundArray(GP_PEN * this, const REAL* compoundArray, INT count)
{
    return (this->lastResult = GdipSetPenCompoundArray(this->nativePen, compoundArray, count));
}

INT GpPen_GetCompoundArrayCount(GP_PEN * this)
{
    INT count = 0;
    this->lastResult = GdipGetPenCompoundCount(this->nativePen, &count);
    return count;
}

GpStatus GpPen_GetCompoundArray(GP_PEN * this, REAL* compoundArray, INT count)
{
    if (compoundArray == NULL || count <= 0)
        return (this->lastResult = eInvalidParameter);
	else
        return (this->lastResult = GdipGetPenCompoundArray(this->nativePen, compoundArray, count));
}

GpStatus GpPen_GetLastStatus(GP_PEN * this)
{
    GpStatus lastStatus = this->lastResult;
    this->lastResult = eOk;
    return lastStatus;
}

