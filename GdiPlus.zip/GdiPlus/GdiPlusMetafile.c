/**************************************************************************\
*
* All files in GdiPlusLib have been modified from the Microsoft
* GdiPlus C++ header files.
*
* Module Name:
*
*   GdiPlusMetafile.c
*
* Abstract:
*
*   Metafile related functions
*
\**************************************************************************/

#include "GdiPlusMetafile.h"
#include "GdiPlusMetaHeader.h"

// Playback a metafile from a HMETAFILE
// If deleteWmf is TRUE, then when the metafile is deleted,
// the hWmf will also be deleted.  Otherwise, it won't be.
//GP_METAFILE GpMetafile(HMETAFILE hWmf, const GP_APMFILEHEADER * apmFileHeader,  BOOL deleteWmf = FALSE)
GP_METAFILE GpMetafile(HMETAFILE hWmf, const GP_APMFILEHEADER * apmFileHeader,
    BOOL deleteWmf)
{
    GP_METAFILE this;
    GP_GPMETAFILE * metafile = NULL;
    this.lastResult = GdipCreateMetafileFromWmf(hWmf, deleteWmf,
                            apmFileHeader, &metafile);

    this.nativeImage = metafile;
    return this;
}

// Playback a metafile from a file
GP_METAFILE GpMetafile_FileName(const WCHAR* filename)
{
    GP_METAFILE this;
    GP_GPMETAFILE * metafile = NULL;
    this.lastResult = GdipCreateMetafileFromFile(filename, &metafile);

    this.nativeImage = metafile;
    return this;
}

    // Playback a WMF metafile from a file
GP_METAFILE GpMetafile_Name(const WCHAR* filename, const GP_APMFILEHEADER * apmFileHeader)
{
    GP_METAFILE this;
    GP_GPMETAFILE * metafile = NULL;
    this.lastResult = GdipCreateMetafileFromWmfFile(filename,
                            apmFileHeader, &metafile);

    this.nativeImage = metafile;
    return this;
}

// Playback a metafile from a stream
GP_METAFILE GpMetafile_IStream(IStream* stream)
{
    GP_METAFILE this;
    GP_GPMETAFILE * metafile = NULL;
    this.lastResult = GdipCreateMetafileFromStream(stream, &metafile);

    this.nativeImage = metafile;
    return this;
}

// Record a metafile to memory
//GP_METAFILE GpMetafile_ToMem(HDC referenceHdc, GpEmfType type, const WCHAR * description = NULL)
GP_METAFILE GpMetafile_ToMem(HDC referenceHdc, GpEmfType type, const WCHAR * description)
{
    GP_METAFILE this;
    GP_GPMETAFILE * metafile = NULL;
    this.lastResult = GdipRecordMetafile(referenceHdc, type, NULL,
                            eMetafileFrameUnitGdi, description, &metafile);

    this.nativeImage = metafile;
    return this;
}

// Record a metafile to memory
//GP_METAFILE GpMetafile_ToMemRcF(HDC referenceHdc, const RECTF * frameRect, GpMetafileFrameUnit frameUnit, GpEmfType type, const WCHAR * description = NULL)
GP_METAFILE GpMetafile_ToMemRcF(HDC referenceHdc, const RECTF * frameRect,
	GpMetafileFrameUnit frameUnit, GpEmfType type, const WCHAR * description)
{
    GP_METAFILE this;
    GP_GPMETAFILE * metafile = NULL;
    this.lastResult = GdipRecordMetafile(referenceHdc, type, frameRect,
                            frameUnit, description, &metafile);

    this.nativeImage = metafile;
    return this;
}

// Record a metafile to memory
//GP_METAFILE Gp_Metafile_ToMemRcI(HDC referenceHdc, const RECTI * frameRect, GpMetafileFrameUnit frameUnit, GpEmfType type, const WCHAR * description = NULL)
GP_METAFILE GpMetafile_ToMemRcI(HDC referenceHdc, const RECTI * frameRect,
    GpMetafileFrameUnit frameUnit, GpEmfType type, const WCHAR * description = NULL)
{
    GP_METAFILE this;
    GP_GPMETAFILE * metafile = NULL;
    this.lastResult = GdipRecordMetafileI(referenceHdc, type, frameRect,
                            frameUnit, description, &metafile);

    this.nativeImage = metafile;
    return this;
}

// Record a metafile to a file
//GP_METAFILE GpMetafile_ToFile(const WCHAR* fileName, HDC referenceHdc, GpEmfType type, const WCHAR * description = NULL)
GP_METAFILE GpMetafile_ToFile(const WCHAR* fileName, HDC referenceHdc,
	GpEmfType type, const WCHAR * description)
{
    GP_METAFILE this;
    GP_GPMETAFILE * metafile = NULL;
    this.lastResult = GdipRecordMetafileFileName(fileName, referenceHdc, 
				type, NULL, eMetafileFrameUnitGdi, description, &metafile);

    this.nativeImage = metafile;
    return this;
}

// Record a metafile to a file
//GP_METAFILE Gp_Metafile_ToFileRcF(const WCHAR* fileName, HDC referenceHdc,  const RECTF * frameRect, GpMetafileFrameUnit frameUnit,  GpEmfType type, const WCHAR * description = NULL)
GP_METAFILE Gp_Metafile_ToFileRcF(const WCHAR* fileName, HDC referenceHdc,
    const RECTF * frameRect, GpMetafileFrameUnit frameUnit,
    GpEmfType type, const WCHAR * description)
{
    GP_METAFILE this;
    GP_GPMETAFILE * metafile = NULL;
    this.lastResult = GdipRecordMetafileFileName(fileName, referenceHdc,
                            type, frameRect, frameUnit,
                            description, &metafile);

    this.nativeImage = metafile;
    return this;
}

// Record a metafile to a file
//GP_METAFILE Gp_Metafile_ToFileRcI(const WCHAR* fileName, HDC referenceHdc, const RECTI * frameRect, GpMetafileFrameUnit frameUnit, GpEmfType type, const WCHAR * description = NULL)
GP_METAFILE Gp_Metafile_ToFileRcI(const WCHAR* fileName, HDC referenceHdc,
    const RECTI * frameRect, GpMetafileFrameUnit frameUnit,
    GpEmfType type, const WCHAR * description)
{
    GP_METAFILE this;
    GP_GPMETAFILE * metafile = NULL;
    this.lastResult = GdipRecordMetafileFileNameI(fileName, referenceHdc,
                            type, frameRect, frameUnit,
                            description, &metafile);

    this.nativeImage = metafile;
    return this;
}

// Record a metafile to a stream
//GP_METAFILE GpMetafile_ToStream(IStream * stream, HDC referenceHdc, GpEmfType type, const WCHAR * description = NULL)
GP_METAFILE GpMetafile_ToStream(IStream * stream, HDC referenceHdc,
    GpEmfType type, const WCHAR * description)
{
    GP_METAFILE this;
    GP_GPMETAFILE * metafile = NULL;
    this.lastResult = GdipRecordMetafileStream( stream, referenceHdc,
                            type, NULL, eMetafileFrameUnitGdi,
                            description, &metafile);

    this.nativeImage = metafile;
    return this;
}

// Record a metafile to a stream
//GP_METAFILE GpMetafile_ToStreamRcF(IStream * stream, HDC referenceHdc, const RECTF * frameRect, GpMetafileFrameUnit frameUnit,  GpEmfType type, const WCHAR * description = NULL)
GP_METAFILE GpMetafile_ToStreamRcF(IStream * stream, HDC referenceHdc,
    const RECTF * frameRect, GpMetafileFrameUnit frameUnit,
    GpEmfType type, const WCHAR * description)
{
    GP_METAFILE this;
    GP_GPMETAFILE * metafile = NULL;

    this.lastResult = GdipRecordMetafileStream(stream, referenceHdc,
                            type, frameRect, frameUnit,
                            description, &metafile);

    this.nativeImage = metafile;
    return this;
}

// Write a metafile to a stream with down-level GDI records
//GP_METAFILE Gp_Metafile_ToStreamRcI(IStream * stream, HDC referenceHdc, const RECTI * frameRect, GpMetafileFrameUnit frameUnit,  GpEmfType type, const WCHAR * description = NULL)
GP_METAFILE Gp_Metafile_ToStreamRcI(IStream * stream, HDC referenceHdc,
    const RECTI * frameRect, GpMetafileFrameUnit frameUnit,
    GpEmfType type, const WCHAR * description)
{
    GP_METAFILE this;
    GP_GPMETAFILE * metafile = NULL;
    this.lastResult = GdipRecordMetafileStreamI(stream, referenceHdc,
                            type, frameRect, frameUnit,
                            description, &metafile);

    this.nativeImage = metafile;
    return this;
}

GpStatus GpMetafile_GetMetafileHeader(HENHMETAFILE hEmf, GP_METAFILEHEADER * header)
{
    return GdipGetMetafileHeaderFromEmf(hEmf, header);
}

GpStatus GpMetafile_GetMetafileHeader_File(const WCHAR* filename, GP_METAFILEHEADER * header)
{
    return GdipGetMetafileHeaderFromFile(filename, header);
}

// static
GpStatus GpMetafile_GetMetafileHeaderStream(IStream * stream,
    GP_METAFILEHEADER * header)
{
    return GdipGetMetafileHeaderFromStream(stream, header);
}

GpStatus GpMetafile_GetMetafileHeaderHead(GP_METAFILE * this,
    GP_METAFILEHEADER * header)
{
    return (this->lastResult = GdipGetMetafileHeaderFromMetafile((GP_GPMETAFILE *)this->nativeImage, header));
}

// Once this method is called, the Metafile object is in an invalid state
// and can no longer be used.  It is the responsiblity of the caller to
// invoke DeleteEnhMetaFile to delete this hEmf.

HENHMETAFILE  GpMetafile_GethEmFHMETAFILE(GP_METAFILE * this)
{
    HENHMETAFILE hEmf;

    (this->lastResult = GdipGetHemfFromMetafile((GP_GPMETAFILE *)this->nativeImage, &hEmf));

    return hEmf;
}

// Used in conjuction with Graphics::EnumerateMetafile to play an EMF+
// The data must be DWORD aligned if it's an EMF or EMF+.  It must be
// WORD aligned if it's a WMF.
GpStatus GpMetafile_PlayRecord(GP_METAFILE * this, GpEmfPlusRecordType recordType,
    UINT flags, UINT dataSize, const BYTE * data)
{
    return (this->lastResult = GdipPlayMetafileRecord((GP_GPMETAFILE *)this->nativeImage,
                    recordType, flags, dataSize, data));
}


