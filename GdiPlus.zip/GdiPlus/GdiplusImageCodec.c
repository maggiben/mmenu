// GdiplusImageCodec.c

#include "GdiplusImageCodec.h"

//--------------------------------------------------------------------------
// Codec Management APIs
//--------------------------------------------------------------------------
GpStatus GpImageDecoders_GetSize(UINT *numDecoders, UINT *size)
{
    return GdipGetImageDecodersSize(numDecoders, size);
}

GpStatus GpImageDecoders_Get(UINT numDecoders, UINT size, IMAGECODECINFO *decoders)
{
    return GdipGetImageDecoders(numDecoders, size, decoders);
}

GpStatus GpImageEncoders_GetSize(UINT *numEncoders, UINT *size)
{
    return GdipGetImageEncodersSize(numEncoders, size);
}

GpStatus GpImageEncoders_Get(UINT numEncoders, UINT size, IMAGECODECINFO *encoders)
{
    return GdipGetImageEncoders(numEncoders, size, encoders);
}
