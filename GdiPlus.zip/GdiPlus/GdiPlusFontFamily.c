/**************************************************************************\
*
* All files in GdiPlusLib have been modified from the Microsoft
* GdiPlus C++ header files.
*
* Module Name:
*
*   GdiplusFontFamily.c
*
* Abstract:
*
*   FontFamily related functions
*
\**************************************************************************/


#include "GdiPlusFontFamily.h"

static GP_FONTFAMILY *GpGenericSansSerifFontFamily = NULL;
static GP_FONTFAMILY *GpGenericSerifFontFamily     = NULL;
static GP_FONTFAMILY *GpGenericMonospaceFontFamily = NULL;

static BYTE GpGenericSansSerifFontFamilyBuffer[sizeof(GP_FONTFAMILY)] = {0};
static BYTE GpGenericSerifFontFamilyBuffer    [sizeof(GP_FONTFAMILY)] = {0};
static BYTE GpGenericMonospaceFontFamilyBuffer[sizeof(GP_FONTFAMILY)] = {0};

GpStatus GpFontFamily_GetLastStatus(GP_FONTFAMILY * this)
{
    GpStatus lastStatus = this->lastResult;
    this->lastResult = eOk;
    return lastStatus;
}

BOOL GpFontFamily_IsAvailable(const GP_FONTFAMILY* this)
{
    return (this->nativeFamily != NULL);
}

GP_FONTFAMILY GpFontFamily(VOID)
{
    GP_FONTFAMILY this;
    this.nativeFamily = NULL;
    this.lastResult = eOk;
    return this;
}

GP_FONTFAMILY GpFontFamily_Name(const WCHAR* name, const GP_FONTCOLLECTION* fontCollection)
{
    GP_FONTFAMILY this;
    this.nativeFamily = NULL;
    this.lastResult = GdipCreateFontFamilyFromName(name,
                            fontCollection ? fontCollection->nativeFontCollection : NULL,
                            &this.nativeFamily);
    return this;

}

GP_FONTFAMILY GpFontFamily_FontFamily(GP_GPFONTFAMILY *nativeOrig, GpStatus status)
{
    GP_FONTFAMILY this;
    this.lastResult = status;
    this.nativeFamily = nativeOrig;
    return this;
}

const GP_FONTFAMILY * GpFontFamily_GenericSansSerif(VOID)
{
    if (GpGenericSansSerifFontFamily != NULL)
    {
        return GpGenericSansSerifFontFamily;
    }

    GpGenericSansSerifFontFamily =
        (GP_FONTFAMILY*) GpGenericSansSerifFontFamilyBuffer;

    GpGenericSansSerifFontFamily->lastResult =
        GdipGetGenericFontFamilySansSerif(
            &(GpGenericSansSerifFontFamily->nativeFamily)
        );

    return GpGenericSansSerifFontFamily;
}

const GP_FONTFAMILY * GpFontFamily_GenericSerif(void)
{
    if (GpGenericSerifFontFamily != NULL)
    {
        return GpGenericSerifFontFamily;
    }

    GpGenericSerifFontFamily =
        (GP_FONTFAMILY*) GpGenericSerifFontFamilyBuffer;

    GpGenericSerifFontFamily->lastResult =
        GdipGetGenericFontFamilySerif(
            &(GpGenericSerifFontFamily->nativeFamily)
        );

    return GpGenericSerifFontFamily;
}

const GP_FONTFAMILY * GpFontFamily_GenericMonospace(VOID)
{
    if (GpGenericMonospaceFontFamily != NULL)
    {
        return GpGenericMonospaceFontFamily;
    }

    GpGenericMonospaceFontFamily =
        (GP_FONTFAMILY*) GpGenericMonospaceFontFamilyBuffer;

    GpGenericMonospaceFontFamily->lastResult =
        GdipGetGenericFontFamilyMonospace(
            &(GpGenericMonospaceFontFamily->nativeFamily)
        );


    return GpGenericMonospaceFontFamily;
}

void GpFontFamily_Delete(GP_FONTFAMILY * this)
{
    GdipDeleteFontFamily(this->nativeFamily);
}

GP_FONTFAMILY GpFontFamily_Clone(GP_FONTFAMILY * this)
{
    GP_GPFONTFAMILY * clonedFamily = NULL;
    (this->lastResult = GdipCloneFontFamily(this->nativeFamily,
            &clonedFamily));

    return GpFontFamily_FontFamily(clonedFamily, this->lastResult);
}

GpStatus GpFontFamily_GetFamilyName(GP_FONTFAMILY * this,
    WCHAR name[LF_FACESIZE], LANGID language)
{
    return (this->lastResult =
                GdipGetFamilyName(this->nativeFamily, name,language));
}

BOOL GpFontFamily_IsStyleAvailable(GP_FONTFAMILY * this, INT style)
{
    BOOL    StyleAvailable;
    GpStatus  status;

    status = (this->lastResult = GdipIsStyleAvailable(this->nativeFamily,
                        style, &StyleAvailable));

    if (status != eOk)
        StyleAvailable = FALSE;

    return StyleAvailable;
}


UINT16 GpFontFamily_GetEmHeight(GP_FONTFAMILY * this, INT style)
{
    UINT16  EmHeight;
    (this->lastResult = GdipGetEmHeight(this->nativeFamily,
            style, &EmHeight));

    return EmHeight;
}

UINT16 GpFontFamily_GetCellAscent(GP_FONTFAMILY * this, INT style)
{
    UINT16  CellAscent;
    (this->lastResult = GdipGetCellAscent(this->nativeFamily,
            style, &CellAscent));
    return CellAscent;
}

UINT16 GpFontFamily_GetCellDescent(GP_FONTFAMILY * this, INT style)
{
    UINT16  CellDescent;
    (this->lastResult = GdipGetCellDescent(this->nativeFamily,
            style, &CellDescent));
    return CellDescent;
}

UINT16 GpFontFamily_GetLineSpacing(GP_FONTFAMILY * this, INT style)
{
    UINT16  LineSpacing;
    (this->lastResult =  GdipGetLineSpacing(this->nativeFamily,
            style, &LineSpacing));
    return LineSpacing;
}

