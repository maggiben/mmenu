/**************************************************************************\
*
* All files in GdiPlusLib have been modified from the Microsoft
* GdiPlus C++ header files.
*
* Module Name:
*
*   GdiPlusBitmap.c
*
* Abstract:
*
*   Bitmap and Image related functions
*
\**************************************************************************/

#include <stdlib.h>
#include "GdiPlusBitmap.h"
#include "GdiPlusGraphics.h"
#include "GdiPlusColor.h"

GP_IMAGE GpImage_FromFile(const WCHAR * filename, BOOL useEmbeddedColorManagement)
{
	GP_IMAGE this;
	this.nativeImage = NULL;
	if (useEmbeddedColorManagement)
	{
		this.lastResult = GdipLoadImageFromFileICM(filename, &this.nativeImage);
	}
	else
	{
		this.lastResult = GdipLoadImageFromFile(filename, &this.nativeImage);
	}
	return this;
}

GP_IMAGE GpImage_FromIStream(IStream * stream, BOOL useEmbeddedColorManagement)
{
	GP_IMAGE this;
	this.nativeImage = NULL;
	if (useEmbeddedColorManagement)
	{
		this.lastResult = GdipLoadImageFromStreamICM(stream, &this.nativeImage);
	}
	else
	{
		this.lastResult = GdipLoadImageFromStream(stream, &this.nativeImage);
	}
	return this;
}

VOID GpImage_Delete(GP_IMAGE * this)
{
	GdipDisposeImage(this->nativeImage);
}

GP_IMAGE GpImage_Clone(GP_IMAGE * this)
{
	GP_GPIMAGE *cloneimage = NULL;
	(this->lastResult = GdipCloneImage(this->nativeImage, &cloneimage));
	GP_IMAGE image;
	image.nativeImage = cloneimage;
	image.lastResult = this->lastResult;
	return image;
}

UINT GpImage_GetEncoderParameterListSize(GP_IMAGE * this, const CLSID * clsidEncoder)
{
	UINT size = 0;
	(this->lastResult = GdipGetEncoderParameterListSize(this->nativeImage, clsidEncoder, &size));
	return size;
}

GpStatus GpImage_GetEncoderParameterList(GP_IMAGE * this, const CLSID * clsidEncoder, UINT size, ENCODERPARAMETERS * buffer)
{
	return (this->lastResult = GdipGetEncoderParameterList(this->nativeImage, clsidEncoder, size, buffer));
}

// Save images
GpStatus GpImage_SaveFile(GP_IMAGE * this, const WCHAR * filename,
	const CLSID * clsidEncoder, const ENCODERPARAMETERS * encoderParams)
{
	return (this->lastResult = GdipSaveImageToFile(this->nativeImage, filename, clsidEncoder, encoderParams));
}

GpStatus GpImage_SaveIStream(GP_IMAGE * this, IStream * stream,
	const CLSID * clsidEncoder, const ENCODERPARAMETERS * encoderParams)
{
	return (this->lastResult = GdipSaveImageToStream(this->nativeImage, stream, clsidEncoder, encoderParams));
}

GpStatus GpImage_SaveAdd(GP_IMAGE * this, const ENCODERPARAMETERS * encoderParams)
{
	return (this->lastResult = GdipSaveAdd(this->nativeImage, encoderParams));
}

GpStatus GpImage_SaveAddImage(GP_IMAGE * this, GP_IMAGE * newImage,
	const ENCODERPARAMETERS * encoderParams)
{
	if (newImage == NULL)
	{
		return (this->lastResult = eInvalidParameter);
	}

	return (this->lastResult = GdipSaveAddImage(this->nativeImage, newImage->nativeImage, encoderParams));
}

// Get size and type information
GpImageType GpImage_GetType(GP_IMAGE * this)
{
	GpImageType type = eImageTypeUnknown;
	(this->lastResult = GdipGetImageType(this->nativeImage, &type));
	return type;
}

GpStatus GpImage_GetPhysicalDimension(GP_IMAGE * this, SIZEF * size)
{
	if (size == NULL)
	{
		return (this->lastResult = eInvalidParameter);
	}

	REAL width, height;
	GpStatus status;

	status = (this->lastResult = GdipGetImageDimension(this->nativeImage, &width, &height));

	size->Width = width;
	size->Height = height;

	return status;
}

GpStatus GpImage_GetBounds(GP_IMAGE * this, RECTF * srcRect, GpUnit * srcUnit)
{
	return (this->lastResult = GdipGetImageBounds(this->nativeImage, srcRect, srcUnit));
}

UINT GpImage_GetWidth(GP_IMAGE * this)
{
	UINT width = 0;
	(this->lastResult = GdipGetImageWidth(this->nativeImage, &width));
	return width;
}

UINT GpImage_GetHeight(GP_IMAGE * this)
{
	UINT height = 0;
	(this->lastResult = GdipGetImageHeight(this->nativeImage, &height));
	return height;
}

REAL GpImage_GetHorizontalResolution(GP_IMAGE * this)
{
	REAL resolution = 0.0f;
	(this->lastResult = GdipGetImageHorizontalResolution(this->nativeImage, &resolution));
	return resolution;
}

REAL GpImage_GetVerticalResolution(GP_IMAGE * this)
{
	REAL resolution = 0.0f;
	(this->lastResult = GdipGetImageVerticalResolution(this->nativeImage, &resolution));
	return resolution;
}

UINT GpImage_GetFlags(GP_IMAGE * this)
{
	UINT flags = 0;
	(this->lastResult = GdipGetImageFlags(this->nativeImage, &flags));
	return flags;
}

GpStatus GpImage_GetRawFormat(GP_IMAGE * this, GUID * format)
{
	return (this->lastResult = GdipGetImageRawFormat(this->nativeImage, format));
}

GpPixelFormat GpImage_GetPixelFormat(GP_IMAGE * this)
{
	GpPixelFormat format;
	(this->lastResult = GdipGetImagePixelFormat(this->nativeImage, &format));
	return format;
}

INT GpImage_GetPaletteSize(GP_IMAGE * this)
{
	INT size = 0;
	(this->lastResult = GdipGetImagePaletteSize(this->nativeImage, &size));
	return size;
}

GpStatus GpImage_GetPalette(GP_IMAGE * this, COLORPALETTE * palette, INT size)
{
	return (this->lastResult = GdipGetImagePalette(this->nativeImage, palette, size));
}

GpStatus GpImage_SetPalette(GP_IMAGE * this, const COLORPALETTE * palette)
{
	return (this->lastResult = GdipSetImagePalette(this->nativeImage, palette));
}

// Thumbnail support
GP_IMAGE GpImage_GetThumbnailImage(GP_IMAGE * this, UINT thumbWidth, UINT thumbHeight, GetThumbnailImageAbort callback, VOID * callbackData)
{
	GP_GPIMAGE *thumbimage = NULL;
	(this->lastResult = GdipGetImageThumbnail(this->nativeImage, thumbWidth, thumbHeight, &thumbimage, callback, callbackData));

	GP_IMAGE newImage;
	newImage.nativeImage = thumbimage;
	newImage.lastResult = this->lastResult;
	return newImage;
}

// Multi-frame support
UINT GpImage_GetFrameDimensionsCount(GP_IMAGE * this)
{
	UINT count = 0;
	(this->lastResult = GdipImageGetFrameDimensionsCount(this->nativeImage, &count));
	return count;
}

GpStatus GpImage_GetFrameDimensionsList(GP_IMAGE * this, GUID * dimensionIDs, UINT count)
{
	return (this->lastResult = GdipImageGetFrameDimensionsList(this->nativeImage, dimensionIDs, count));
}

UINT GpImage_GetFrameCount(GP_IMAGE * this, const GUID * dimensionID)
{
	UINT count = 0;
	(this->lastResult = GdipImageGetFrameCount(this->nativeImage, dimensionID, &count));
	return count;
}

GpStatus GpImage_SelectActiveFrame(GP_IMAGE * this, const GUID * dimensionID, UINT frameIndex)
{
	return (this->lastResult = GdipImageSelectActiveFrame(this->nativeImage, dimensionID, frameIndex));
}

GpStatus GpImage_RotateFlip(GP_IMAGE * this, GpRotateFlipType rotateFlipType)
{
	return (this->lastResult = GdipImageRotateFlip(this->nativeImage, rotateFlipType));
}

// Image property related functions
UINT GpImage_GetPropertyCount(GP_IMAGE * this)
{
	UINT numProperty = 0;
	(this->lastResult = GdipGetPropertyCount(this->nativeImage, &numProperty));
	return numProperty;
}

GpStatus GpImage_GetPropertyIdList(GP_IMAGE * this, UINT numOfProperty, PROPID * list)
{
	return (this->lastResult = GdipGetPropertyIdList(this->nativeImage, numOfProperty, list));
}

UINT GpImage_GetPropertyItemSize(GP_IMAGE * this, PROPID propId)
{
	UINT size = 0;
	(this->lastResult = GdipGetPropertyItemSize(this->nativeImage, propId, &size));
	return size;
}

GpStatus GpImage_GetPropertyItem(GP_IMAGE * this, PROPID propId, UINT propSize, PROPERTYITEM * buffer)
{
	return (this->lastResult = GdipGetPropertyItem(this->nativeImage, propId, propSize, buffer));
}

GpStatus GpImage_GetPropertySize(GP_IMAGE * this, UINT * totalBufferSize, UINT * numProperties)
{
	return (this->lastResult = GdipGetPropertySize(this->nativeImage, totalBufferSize, numProperties));
}

GpStatus GpImage_GetAllPropertyItems(GP_IMAGE * this, UINT totalBufferSize, UINT numProperties, PROPERTYITEM * allItems)
{
	if (allItems == NULL)
	{
		return (this->lastResult = eInvalidParameter);
	}
	return (this->lastResult = GdipGetAllPropertyItems(this->nativeImage, totalBufferSize, numProperties, allItems));
}

GpStatus GpImage_RemovePropertyItem(GP_IMAGE * this, PROPID propId)
{
	return (this->lastResult = GdipRemovePropertyItem(this->nativeImage, propId));
}

GpStatus GpImage_SetPropertyItem(GP_IMAGE * this, const PROPERTYITEM * item)
{
	return (this->lastResult = GdipSetPropertyItem(this->nativeImage, item));
}

GpStatus GpImage_GetLastStatus(GP_IMAGE * this)
{
	GpStatus lastStatus = this->lastResult;
	this->lastResult = eOk;
	return lastStatus;
}

GP_IMAGE GpImage_Image(GP_GPIMAGE * nativeImage, GpStatus status)
{
	GP_IMAGE this;
	this.nativeImage = nativeImage;
	this.lastResult = status;
	return this;
}

GP_BITMAP GpBitmap_Stream(IStream * stream, BOOL useEmbeddedColorManagement)
{
	GP_BITMAP this;
	GP_GPBITMAP *bitmap = NULL;
	if (useEmbeddedColorManagement)
	{
		this.lastResult = GdipCreateBitmapFromStreamICM(stream, &bitmap);
	}
	else
	{
		this.lastResult = GdipCreateBitmapFromStream(stream, &bitmap);
	}
	this.nativeImage = bitmap;
	return this;
}


GP_BITMAP GpBitmap_Bytes(INT width, INT height, INT stride, GpPixelFormat format, BYTE * scan0)
{
	GP_BITMAP this;
	GP_GPBITMAP *bitmap = NULL;
	this.lastResult = GdipCreateBitmapFromScan0(width, height, stride, format, scan0, &bitmap);
	this.nativeImage = bitmap;
	return this;
}

GP_BITMAP GpBitmap_PixFmt(INT width, INT height, GpPixelFormat format)
{
	GP_BITMAP this;
	GP_GPBITMAP *bitmap = NULL;
	this.lastResult = GdipCreateBitmapFromScan0(width, height, 0, format, NULL, &bitmap);
	this.nativeImage = bitmap;
	return this;
}


GP_BITMAP GpBitmap_Graphics(INT width, INT height, GP_GRAPHICS * target)
{
	GP_BITMAP this;
	GP_GPBITMAP *bitmap = NULL;
	this.lastResult = GdipCreateBitmapFromGraphics(width, height, target->nativeGraphics, &bitmap);
	this.nativeImage = bitmap;
	return this;
}

GP_BITMAP GpBitmap_DDraw(IDirectDrawSurface7 * surface)
{
	GP_BITMAP this;
	GP_GPBITMAP *bitmap = NULL;
	this.lastResult = GdipCreateBitmapFromDirectDrawSurface(surface, &bitmap);
	this.nativeImage = bitmap;
	return this;
}

GP_BITMAP GpBitmap_BITMAPINFO(const BITMAPINFO * gdiBitmapInfo, VOID * gdiBitmapData)
{
	GP_BITMAP this;
	GP_GPBITMAP *bitmap = NULL;
	this.lastResult = GdipCreateBitmapFromGdiDib(gdiBitmapInfo, gdiBitmapData, &bitmap);
	this.nativeImage = bitmap;
	return this;
}

GP_BITMAP GpBitmap_Pal(HBITMAP hbm, HPALETTE hpal)
{
	GP_BITMAP this;
	GP_GPBITMAP *bitmap = NULL;
	this.lastResult = GdipCreateBitmapFromHBITMAP(hbm, hpal, &bitmap);
	this.nativeImage = bitmap;
	return this;
}

GP_BITMAP GpBitmap_Icon(HICON hicon)
{
	GP_BITMAP this;
	GP_GPBITMAP *bitmap = NULL;
	this.lastResult = GdipCreateBitmapFromHICON(hicon, &bitmap);
	this.nativeImage = bitmap;
	return this;
}


GP_BITMAP GpBitmap_Resource(HINSTANCE hInstance, const WCHAR * bitmapName)
{
	GP_BITMAP this;
	GP_GPBITMAP *bitmap = NULL;
	this.lastResult = GdipCreateBitmapFromResource(hInstance, bitmapName, &bitmap);
	this.nativeImage = bitmap;
	return this;
}

GP_BITMAP GpBitmap_FromFile(const WCHAR * filename, BOOL useEmbeddedColorManagement)
{
	GP_BITMAP this;
	GP_GPBITMAP *bitmap = NULL;
	if (useEmbeddedColorManagement)
	{
		this.lastResult = GdipCreateBitmapFromFileICM(filename, &bitmap);
	}
	else
	{
		this.lastResult = GdipCreateBitmapFromFile(filename, &bitmap);
	}

	this.nativeImage = bitmap;
	return this;
}

GP_BITMAP GpBitmap_FromStream(IStream * stream, BOOL useEmbeddedColorManagement)
{
	return GpBitmap_Stream(stream, useEmbeddedColorManagement);
}

GP_BITMAP GpBitmap_FromDirectDrawSurface7(IDirectDrawSurface7 * surface)
{
	return GpBitmap_DDraw(surface);
}

GP_BITMAP GpBitmap_FromBITMAPINFO(const BITMAPINFO * gdiBitmapInfo, VOID * gdiBitmapData)
{
	return GpBitmap_BITMAPINFO(gdiBitmapInfo, gdiBitmapData);
}

GP_BITMAP GpBitmap_FromHBITMAP(HBITMAP hbm, HPALETTE hpal)
{
	return GpBitmap_Pal(hbm, hpal);
}

GP_BITMAP GpBitmap_FromHICON(HICON hicon)
{
	return GpBitmap_Icon(hicon);
}

GP_BITMAP GpBitmap_FromResource(HINSTANCE hInstance, const WCHAR * bitmapName)
{
	return GpBitmap_Resource(hInstance, bitmapName);
}

GpStatus GpBitmap_GetHBITMAP(GP_BITMAP * this, const COLOR * colorBackground, HBITMAP * hbmReturn)
{
	return (this->lastResult = GdipCreateHBITMAPFromBitmap(this->nativeImage, hbmReturn, GpColor_GetValue(colorBackground)));
}

GpStatus GpBitmap_GetHICON(GP_BITMAP * this, HICON * hiconReturn)
{
	return (this->lastResult = GdipCreateHICONFromBitmap(this->nativeImage, hiconReturn));
}

GP_BITMAP GpBitmap_Bitmap(GP_GPBITMAP * nativeBitmap)
{
	GP_BITMAP this;
	this.lastResult = eOk;
	this.nativeImage = nativeBitmap;
	return this;
}

GP_BITMAP GpBitmap_Clone4I(GP_BITMAP * this, INT x, INT y, INT width, INT height, GpPixelFormat format)
{
	GP_GPBITMAP *gpdstBitmap = NULL;
	GP_BITMAP bitmap;
	this->lastResult = GdipCloneBitmapAreaI(x, y, width, height, format, this->nativeImage, &gpdstBitmap);

	if (this->lastResult == eOk)
	{
		return GpBitmap_Bitmap(gpdstBitmap);
	}
	else
	{	bitmap.lastResult = eGenericError;
		bitmap.nativeImage = NULL;
		return bitmap;
	}
}

GP_BITMAP GpBitmap_ClonePixFmt(const RECTI * rect, GpPixelFormat format)
{
	GP_BITMAP bitmap;
	return GpBitmap_Clone4I(&bitmap, rect->X, rect->Y, rect->Width, rect->Height, format);
}

GP_BITMAP GpBitmap_Clone4F(GP_BITMAP * this, REAL x, REAL y, REAL width, REAL height, GpPixelFormat format)
{
	GP_GPBITMAP *gpdstBitmap = NULL;
	GP_BITMAP bitmap;

	(this->lastResult = GdipCloneBitmapArea(x, y, width, height, format, this->nativeImage, &gpdstBitmap));
	if (this->lastResult == eOk)
	{
		return GpBitmap_Bitmap(gpdstBitmap);
	}
	// Problem here, as it returns a struct cannot return error condition
	else
	{	bitmap.lastResult = eGenericError;
		bitmap.nativeImage = NULL;
		return bitmap;
	}
}

GpStatus GpBitmap_LockBits(GP_BITMAP * this, const RECTI * rect, UINT flags, GpPixelFormat format, BITMAPDATA * lockedBitmapData)
{
	return (this->lastResult = GdipBitmapLockBits(this->nativeImage, rect, flags, format, lockedBitmapData));
}


GpStatus GpBitmap_UnlockBits(GP_BITMAP * this, BITMAPDATA * lockedBitmapData)
{
	return (this->lastResult = GdipBitmapUnlockBits(this->nativeImage, lockedBitmapData));
}

GpStatus GpBitmap_GetPixel(GP_BITMAP * this, INT x, INT y, COLOR * color)
{
	ARGB argb;
	GpStatus status = (this->lastResult = GdipBitmapGetPixel(this->nativeImage, x, y, &argb));

	if (status == eOk)
	{
		GpColor_SetValue(color, argb);
	}
	return status;
}

GpStatus GpBitmap_SetPixel(GP_BITMAP * this, INT x, INT y, const COLOR * color)
{
	return (this->lastResult = GdipBitmapSetPixel(this->nativeImage, x, y, GpColor_GetValue(color)));
}

GpStatus GpBitmap_SetResolution(GP_BITMAP * this, REAL xdpi, REAL ydpi)
{
	return (this->lastResult = GdipBitmapSetResolution(this->nativeImage, xdpi, ydpi));
}
