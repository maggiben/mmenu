/****************************************************************************
 *                                                                          *
 * File    : main.c                                                         *
 *                                                                          *
 * Purpose : Generic Win32 application.                                     *
 *                                                                          *
 * History : Date      Reason                                               *
 *           00/00/00  Created                                              *
 *                                                                          *
 ****************************************************************************/

#define WIN32_LEAN_AND_MEAN  /* speed up compilations */
#include <windows.h>
#include <windowsx.h>
#include <tchar.h>
#define __MT__        // For beginthread()
#include <process.h>  //
#include "main.h"
#include "GdiPlus.h"

/** Prototypes **************************************************************/

static LRESULT WINAPI MainWndProc(HWND, UINT, WPARAM, LPARAM);
static void Main_OnPaint(HWND);
static void Main_OnCommand(HWND, int, HWND, UINT);
static void Main_OnDestroy(HWND);
static BOOL Main_OnCreate(HWND hwnd, CREATESTRUCT *);
static LRESULT WINAPI AboutDlgProc(HWND, UINT, WPARAM, LPARAM);

/** Global variables ********************************************************/

static HANDLE ghInstance;

// Vars for animated gif
int nFrameCount;
int nFramePosition;
PROPERTYITEM * pPropertyItem;
HANDLE hExitEvent;
HANDLE hPause;
DWORD hThread;
HWND g_hwnd;
GP_IMAGE g_image;

BOOL TestForAnimatedGIF(GP_IMAGE * image)
{
	UINT count = 0;
	count = GpImage_GetFrameDimensionsCount(image);
	GUID * pDimensionIDs = malloc(count * sizeof(GUID));

	// Get the list of frame dimensions from the Image object.
	GpImage_GetFrameDimensionsList(image, pDimensionIDs, count);

	// Get the number of frames in the first dimension.
	nFrameCount = GpImage_GetFrameCount(image, &pDimensionIDs[0]);

	// Assume that the image has a property item of type PropertyItemEquipMake.
	// Get the size of that property item.
	int nSize = GpImage_GetPropertyItemSize(image, GpPropertyTagFrameDelay);

	// Allocate a buffer to receive the property item.
	pPropertyItem = malloc(nSize * sizeof(PROPERTYITEM));

	GpImage_GetPropertyItem(image, GpPropertyTagFrameDelay, nSize, pPropertyItem);

	GpFree(pDimensionIDs);

	return (nFrameCount > 1);
}

BOOL DrawFrameGIF(HWND hwnd, GP_IMAGE * image)
{
	WaitForSingleObject(hPause, INFINITE);

	GUID pageGuid = FrameDimensionTime;

	long nWidth = GpImage_GetWidth(image);
	long nHeight = GpImage_GetHeight(image);

	HDC hdc = GetDC(hwnd);
	if (hdc)
	{
		GP_GRAPHICS graphics = GpGraphics_FromHDC(hdc);
		GpGraphics_DrawImage4I(&graphics, image, 0, 250, nWidth, nHeight);
		ReleaseDC(hwnd, hdc);
		GpGraphics_Delete(&graphics);
	}

	GpImage_SelectActiveFrame(image, &pageGuid, nFramePosition++);

	if (nFramePosition == nFrameCount)
		nFramePosition = 0;

	long lPause = ((long*) pPropertyItem->value)[nFramePosition] * 15;

	DWORD dwErr = WaitForSingleObject(hExitEvent, lPause);

	return (dwErr == WAIT_OBJECT_0);
}

void __cdecl ThreadAnimation(void * image)
{
	nFramePosition = 0;
	Sleep(200);             // give the window time to initialize
	BOOL bExit = FALSE;
	while (bExit == FALSE)
	{
		bExit = DrawFrameGIF(g_hwnd, image);
	}
}

BOOL LoadAnimGif(const WCHAR * filename)
{
	g_image = GpImage_FromFile(filename, FALSE);
	if(g_image.lastResult != eOk)
	{
		return FALSE;
	}
	if(!TestForAnimatedGIF(&g_image))
	{
		return FALSE;
	}

	hThread = _beginthread(ThreadAnimation, 0, (void *)&g_image);

	if (!hThread)
	{
		return FALSE;
	} 

	hExitEvent = CreateEvent(NULL,TRUE,FALSE,NULL);
	hPause = CreateEvent(NULL,TRUE,TRUE,NULL);
	return TRUE;
}

void DrawImage(HDC hdc, const WCHAR * filename)
{
	GP_IMAGE image = GpImage_FromFile(filename, FALSE);
	if(image.lastResult != eOk)
	{
		return;
	}
	GP_GRAPHICS graphics = GpGraphics_FromHDC(hdc);
	GpGraphics_DrawImage4I(&graphics, &image, 400, 0, GpImage_GetWidth(&image), GpImage_GetHeight(&image));
	GpImage_Delete(&image);
	GpGraphics_Delete(&graphics);
}

void DrawSphere(HDC hdc)
{
	// First Sphere coordinates
	int x = 200;
	int y = 0;
	int size = 200;

	GP_GRAPHICS graphics = GpGraphics_FromHDC(hdc);

	// BRUSH EFFECT
	// Create a GraphicsPath object
	GP_GRAPHICSPATH path1 = GpGraphicsPath(eFillModeAlternate);

	// Add an ellipse to the path
	GpGraphicsPath_AddEllipse4I(&path1, x, y, size, size);

	// Create a path gradient based on the ellipse
	GP_PATHGRADIENTBRUSH brush1 = GpPathGradientBrush(&path1);

	// Set the middle color of the path
	COLOR MiddleColorToOpaque = GpColorA(eMediumAquamarine, 0);
	GpPathGradientBrush_SetCenterColor(&brush1, &MiddleColorToOpaque);


	// Set the entire path boundary to Alpha Black using 50% translucency
	COLOR BlackFullTranslucent = GpColorA(eBlack, 128);
	int count = 1;
	GpPathGradientBrush_SetSurroundColors(&brush1, &BlackFullTranslucent, &count);

	// Draw the ellipse, keeping the exact coords we defined for the path
	// I want to use AntiAlias drawing mode
	GpGraphics_SetSmoothingMode(&graphics, eSmoothingModeAntiAlias);
	GpGraphics_FillEllipseI(&graphics, (GP_BRUSH*)&brush1, x + 2, y + 2, size - 4, size - 4);
	// + 2 and - 4 are used to better achieve the AntiAlias

	// Second Sphere coordinates
	x = 200; y = 100; size = 150;

	// Create a GraphicsPath object
	GP_GRAPHICSPATH path2 = GpGraphicsPath(eFillModeAlternate);

	// Add an ellipse to the path
	GpGraphicsPath_AddEllipse4I(&path2, x, y, size, size);

	// Create a path gradient based on the ellipse
	GP_PATHGRADIENTBRUSH brush2 = GpPathGradientBrush(&path2);

	// Set the middle color of the path
	MiddleColorToOpaque = GpColorA(eYellow, 64);
	GpPathGradientBrush_SetCenterColor(&brush2, &MiddleColorToOpaque);

	// Set the entire path boundary to Alpha Black using 50% translucency
	BlackFullTranslucent = GpColorA(eRed, 128);
	GpPathGradientBrush_SetSurroundColors(&brush2, &BlackFullTranslucent, &count);

	// Draw the ellipse, keeping the exact coords we defined for the path
	GpGraphics_FillEllipseI(&graphics, (GP_BRUSH*)&brush2, x + 2, y + 2, size - 4, size - 4);
	// + 2 and - 4 are used to better achieve the AntiAlias

	// Cleanup
	GpGraphicsPath_Delete(&path1);
	GpGraphicsPath_Delete(&path2);
	GpBrush_Delete((GP_BRUSH*)&brush1);
	GpBrush_Delete((GP_BRUSH*)&brush2);
	GpGraphics_Delete(&graphics);
}

void DrawGradient(HDC hdc)
{
	// Create colors, pens, brush and graphics
	COLOR color  = GpColor_4(255, 255, 0, 0);
	COLOR color1 = GpColor_4(255, 0, 0, 255);
	COLOR color2 = GpColor_3(0, 255, 255);
	GP_PEN pen   = GpPen_Color(&color, 7.0);
	GP_PEN pen1  = GpPen_Color(&color2, 7.0);
	POINTF pt1   = GpPointF(0.0f, 0.0f);
	POINTF pt2   = GpPointF(200.0f, 200.0f);
	GP_BRUSH linGradBrush = GpLinearGradientBrush(&pt1,&pt2, &color, &color1);

	GP_GRAPHICS graphics = GpGraphics_FromHDC(hdc);

	// Draw graphics
	GpGraphics_DrawLineF(&graphics, &pen1, 225.0f, 15.0f, 360.0f, 190.0f);
	GpGraphics_DrawEllipseF(&graphics, &pen, 230.0f, 10.0f, 110.0f, 180.0f);
	GpGraphics_FillRectangleI(&graphics, &linGradBrush, 0, 0, 200, 200);

	// Cleanup
	GpPen_Delete(&pen);
	GpPen_Delete(&pen1);
	GpBrush_Delete(&linGradBrush);
	GpGraphics_Delete(&graphics);
}

/****************************************************************************
 *                                                                          *
 * Function: Main_OnCreate                                                  *
 *                                                                          *
 * Purpose : Process a WM_CREATE message.                                   *
 *                                                                          *
 * History : Date      Reason                                               *
 *           00/00/00  Created                                              *
 *                                                                          *
 ****************************************************************************/
static BOOL Main_OnCreate(HWND hwnd, CREATESTRUCT * cs)
{
	g_hwnd = hwnd;
	BOOL agif = LoadAnimGif(L"movingwizard.gif");
	return TRUE;
}

/****************************************************************************
 *                                                                          *
 * Function: Main_OnPaint                                                   *
 *                                                                          *
 * Purpose : Process a WM_PAINT message.                                    *
 *                                                                          *
 * History : Date      Reason                                               *
 *           00/00/00  Created                                              *
 *                                                                          *
 ****************************************************************************/
static void Main_OnPaint(HWND hwnd)
{
	PAINTSTRUCT ps;
	BeginPaint(hwnd, &ps);
	DrawImage(ps.hdc, L"GLMDA.PNG");
	DrawSphere(ps.hdc);
	DrawGradient(ps.hdc);
    EndPaint(hwnd, &ps);

}

/****************************************************************************
 *                                                                          *
 * Function: WinMain                                                        *
 *                                                                          *
 * Purpose : Initialize the application.  Register a window class,          *
 *           create and display the main window and enter the               *
 *           message loop.                                                  *
 *                                                                          *
 * History : Date      Reason                                               *
 *           00/00/00  Created                                              *
 *                                                                          *
 ****************************************************************************/
int PASCAL WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpszCmdLine, int nCmdShow)
{
    WNDCLASS wc;
    HWND hwnd;
    MSG msg;

    ghInstance = hInstance;

	ULONG_PTR gdiplusToken;

	// Initialize GDI+.
	GdiplusStartup(&gdiplusToken, &g_GdiplusStartupInput, NULL);

    // Register the main window class.
    wc.lpszClassName 	= _T("GdiPlusClass");
    wc.lpfnWndProc 		= MainWndProc;
    wc.style 			= CS_OWNDC|CS_VREDRAW|CS_HREDRAW;
    wc.hInstance 		= ghInstance;
    wc.hIcon 			= LoadIcon(ghInstance, MAKEINTRESOURCE(IDR_ICO_MAIN));
    wc.hCursor 			= LoadCursor(NULL, IDC_ARROW);
    wc.hbrBackground 	= (HBRUSH)(COLOR_WINDOW+1);
    wc.lpszMenuName 	= MAKEINTRESOURCE(IDR_MNU_MAIN);
    wc.cbClsExtra 		= 0;
    wc.cbWndExtra 		= 0;
    //
    if (!RegisterClass(&wc))
        return 1;

    // Create the main window.
    hwnd = CreateWindow(_T("GdiPlusClass"),
        _T("GdiPlus Program"),
        WS_OVERLAPPEDWINDOW|WS_HSCROLL|WS_VSCROLL,
        0,
        0,
        CW_USEDEFAULT,
        CW_USEDEFAULT,
        NULL,
        NULL,
        ghInstance,
        NULL
    );
    if (!hwnd) return 1;

    // Show and paint the main window.
    ShowWindow(hwnd, nCmdShow);
    UpdateWindow(hwnd);

    // Pump messages until we are done.
    while (GetMessage(&msg, NULL, 0, 0))
    {
        TranslateMessage(&msg);
        DispatchMessage(&msg);
    }
	GdiplusShutdown(gdiplusToken);
    return msg.wParam;
}

/****************************************************************************
 *                                                                          *
 * Function: MainWndProc                                                    *
 *                                                                          *
 * Purpose : Process application messages.                                  *
 *                                                                          *
 * History : Date      Reason                                               *
 *           00/00/00  Created                                              *
 *                                                                          *
 ****************************************************************************/
static LRESULT CALLBACK MainWndProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
    switch (msg)
    {
		HANDLE_MSG(hwnd, WM_CREATE, Main_OnCreate);
        HANDLE_MSG(hwnd, WM_PAINT, Main_OnPaint);
        HANDLE_MSG(hwnd, WM_COMMAND, Main_OnCommand);
        HANDLE_MSG(hwnd, WM_DESTROY, Main_OnDestroy);
        /* TODO: enter more messages here */
        default:
            return DefWindowProc(hwnd, msg, wParam, lParam);
    }
}

/****************************************************************************
 *                                                                          *
 * Function: Main_OnCommand                                                 *
 *                                                                          *
 * Purpose : Process a WM_COMMAND message.                                  *
 *                                                                          *
 * History : Date      Reason                                               *
 *           00/00/00  Created                                              *
 *                                                                          *
 ****************************************************************************/
static void Main_OnCommand(HWND hwnd, int id, HWND hwndCtl, UINT codeNotify)
{
    switch (id)
    {
        case IDM_ABOUT:
            DialogBox(ghInstance, MAKEINTRESOURCE(DLG_ABOUT), hwnd, (DLGPROC)AboutDlgProc);

        /* TODO: Enter more commands here */
    }
}

/****************************************************************************
 *                                                                          *
 * Function: Main_OnDestroy                                                 *
 *                                                                          *
 * Purpose : Process a WM_DESTROY message.                                  *
 *                                                                          *
 * History : Date      Reason                                               *
 *           00/00/00  Created                                              *
 *                                                                          *
 ****************************************************************************/
static void Main_OnDestroy(HWND hwnd)
{
	if(g_image.nativeImage) GpImage_Delete(&g_image);
	if(hExitEvent) CloseHandle(hExitEvent);
	if(hExitEvent) CloseHandle(hPause);
	if(pPropertyItem) GpFree(pPropertyItem);
    PostQuitMessage(0);
}

/****************************************************************************
 *                                                                          *
 * Function: AboutDlgProc                                                   *
 *                                                                          *
 * Purpose : Process messages for the About dialog.  The dialog is          *
             shown when the user selects "About" in the "Help" menu.        *
 *                                                                          *
 * History : Date      Reason                                               *
 *           00/00/00  Created                                              *
 *                                                                          *
 ****************************************************************************/

static LRESULT CALLBACK AboutDlgProc(HWND hDlg, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
    switch (uMsg)
    {
        case WM_INITDIALOG:
            /*
             * Nothing special to initialize.
             */
            return TRUE;

        case WM_COMMAND:
            switch (wParam)
            {
                case IDOK:
                case IDCANCEL:
                    /*
                     * OK or Cancel was clicked, close the dialog.
                     */
                    EndDialog(hDlg, TRUE);
                    return TRUE;
            }
            break;
    }

    return FALSE;
}

