/**************************************************************************\
*
* All files in GdiPlusLib have been modified from the Microsoft
* GdiPlus C++ header files.
*
* Module Name:
*
*   GdiPlusPath.c
*
* Abstract:
*
*   Path related functions
*
\**************************************************************************/

#include <stdlib.h>
#include "GdiPlusPath.h"
#include "GdiPlusTypes.h"
#include "GdiPlusFont.h"
#include "GdiPlusStringFormat.h"
#include "GdiPlusMatrix.h"
#include "GdiPlusPen.h"
#include "GdiPlusGraphics.h"
#include "GdiPlusBrush.h"
#include "GdiPlusColor.h"
#include "GdiplusFontFamily.h"

GP_GRAPHICSPATH GpGraphicsPath(GpFillMode fillMode)
{
    GP_GRAPHICSPATH this;
    this.nativePath = NULL;
    this.lastResult = GdipCreatePath(fillMode, (GP_GPPATH**)&this.nativePath);
    return this;
}

//GP_GRAPHICSPATH GpGraphicsPath_2(const POINTF* points, const BYTE* types,INT count, GpFillMode fillMode = eFillModeAlternate)
GP_GRAPHICSPATH GpGraphicsPath_2(const POINTF* points, const BYTE* types,INT count, GpFillMode fillMode)
{
    GP_GRAPHICSPATH this;
    this.nativePath = NULL;
    this.lastResult = GdipCreatePath2(points, types, count, fillMode, (GP_GPPATH**)&this.nativePath);
    return this;
}

//GP_GRAPHICSPATH GpGraphicsPath_2I(const POINTI* points,  const BYTE* types, INT count, GpFillMode fillMode = FillModeAlternate)
GP_GRAPHICSPATH GpGraphicsPath_2I(const POINTI* points,  const BYTE* types,
			INT count, GpFillMode fillMode)
{
    GP_GRAPHICSPATH this;
    this.nativePath = NULL;
    this.lastResult = GdipCreatePath2I(points,types, count, fillMode,(GP_GPPATH**)&this.nativePath);
    return this;
}

GP_GRAPHICSPATH GpGraphicsPath_Clone(GP_GRAPHICSPATH * this)
{
	GP_GRAPHICSPATH path;
    GP_GPPATH * clonepath = NULL;
	path.lastResult = GdipClonePath((GP_GPPATH*)this->nativePath, &clonepath);
	path.nativePath = (GP_GPGRAPHICSPATH*)clonepath;
    return path;
}

GpStatus GpGraphicsPath_Reset(GP_GRAPHICSPATH * this)
{
    return (this->lastResult = GdipResetPath((GP_GPPATH*)this->nativePath));
}

GpFillMode GpGraphicsPath_GetFillMode(GP_GRAPHICSPATH * this)
{
    GpFillMode fillmode = eFillModeAlternate;
    this->lastResult = GdipGetPathFillMode((GP_GPPATH*)this->nativePath, &fillmode);
    return fillmode;
}

GpStatus GpGraphicsPath_SetFillMode(GP_GRAPHICSPATH * this, GpFillMode fillmode)
{
    return (this->lastResult = GdipSetPathFillMode((GP_GPPATH*)this->nativePath, fillmode));
}

INT GpGraphicsPath_GetPointCount(GP_GRAPHICSPATH * this)
{
    INT count = 0;
    this->lastResult = GdipGetPointCount((GP_GPPATH*)this->nativePath, &count);
    return count;
}

GpStatus GpGraphicsPath_GetPathData(GP_GRAPHICSPATH * this, GP_PATHDATA* pathData)
{
    if (pathData == NULL)
    {
        return (this->lastResult = eInvalidParameter);
    }

    INT count = GpGraphicsPath_GetPointCount(this);

    if ((count <= 0) || (pathData->Count > 0 && pathData->Count < count))
    {
        pathData->Count = 0;
        if (pathData->Points)
        {
            GpFree(pathData->Points);
            pathData->Points = NULL;
        }

        if (pathData->Types)
        {
            GpFree(pathData->Types);
            pathData->Types = NULL;
        }

        if (count <= 0)
        {
            return this->lastResult;
        }
    }

    if (pathData->Count == 0)
    {
        pathData->Points = GpAlloc(count * sizeof(POINTF));
        if (pathData->Points == NULL)
        {
            return (this->lastResult = eOutOfMemory);

        }

        pathData->Types = GpAlloc(count);

        if (pathData->Types == NULL)
        {
            GpFree(pathData->Points);
            pathData->Points = NULL;
            return (this->lastResult = eOutOfMemory);
        }
        pathData->Count = count;
    }
    return (this->lastResult = GdipGetPathData((GP_GPPATH*)this->nativePath, (GP_GPPATHDATA*)pathData));
}

GpStatus GpGraphicsPath_StartFigure(GP_GRAPHICSPATH * this)
{
    return (this->lastResult = GdipStartPathFigure((GP_GPPATH*)this->nativePath));
}

GpStatus GpGraphicsPath_CloseFigure(GP_GRAPHICSPATH * this)
{
    return (this->lastResult =	GdipClosePathFigure((GP_GPPATH*)this->nativePath));
}

GpStatus GpGraphicsPath_CloseAllFigures( GP_GRAPHICSPATH * this )
{
    return (this->lastResult = GdipClosePathFigures((GP_GPPATH*)this->nativePath));
}

GpStatus GpGraphicsPath_SetMarker(GP_GRAPHICSPATH * this)
{
    return (this->lastResult = GdipSetPathMarker((GP_GPPATH*)this->nativePath));
}

GpStatus GpGraphicsPath_ClearMarkers(GP_GRAPHICSPATH * this)
{
    return (this->lastResult = GdipClearPathMarkers((GP_GPPATH*)this->nativePath));
}

GpStatus GpGraphicsPath_Reverse(GP_GRAPHICSPATH * this)
{
    return (this->lastResult = GdipReversePath((GP_GPPATH*)this->nativePath));
}

GpStatus GpGraphicsPath_GetLastPoint(GP_GRAPHICSPATH * this, POINTF* lastPoint)
{
    return (this->lastResult = GdipGetPathLastPoint((GP_GPPATH*)this->nativePath, lastPoint));
}

GpStatus GpGraphicsPath_AddLine4F(GP_GRAPHICSPATH * this, REAL x1, REAL y1, REAL x2, REAL y2)
{
    return (this->lastResult = GdipAddPathLine((GP_GPPATH*)this->nativePath, x1, y1, x2, y2));
}

GpStatus GpGraphicsPath_AddLinePtsF(GP_GRAPHICSPATH * this,  const POINTF * pt1, const POINTF * pt2)
{
    return GpGraphicsPath_AddLine4F(this, pt1->X, pt1->Y, pt2->X, pt2->Y);
}

GpStatus GpGraphicsPath_AddLinesPtF(GP_GRAPHICSPATH * this, const POINTF* points, INT count)
{
    return (this->lastResult = GdipAddPathLine2((GP_GPPATH*)this->nativePath, points, count));
}

// integer version
GpStatus GpGraphicsPath_AddLine4I(GP_GRAPHICSPATH * this, INT x1, INT y1, INT x2, INT y2)
{
    return (this->lastResult = GdipAddPathLineI((GP_GPPATH*)this->nativePath, x1, y1, x2, y2));
}

GpStatus GpGraphicsPath_AddLinePtI( GP_GRAPHICSPATH * this, const POINTI * pt1, const POINTI * pt2)
{
    return GpGraphicsPath_AddLine4I(this, pt1->X, pt1->Y, pt2->X, pt2->Y);
}

GpStatus GpGraphicsPath_AddLinesPtI(GP_GRAPHICSPATH * this, const POINTI* points, INT count)
{
    return (this->lastResult = GdipAddPathLine2I((GP_GPPATH*)this->nativePath,points,count));
}

GpStatus GpGraphicsPath_AddArc4F(GP_GRAPHICSPATH * this, REAL x, REAL y,
		REAL width,	REAL height, REAL startAngle, REAL sweepAngle)
{
    return (this->lastResult = GdipAddPathArc((GP_GPPATH*)this->nativePath,
                    x, y, width, height, startAngle, sweepAngle));
}

GpStatus GpGraphicsPath_AddArc(GP_GRAPHICSPATH * this, const RECTF * rect,
    REAL startAngle, REAL sweepAngle)
{
    return GpGraphicsPath_AddArc4F(this, rect->X, rect->Y, rect->Width,
				rect->Height, startAngle, sweepAngle);
}

GpStatus GpGraphicsPath_AddArc4I(GP_GRAPHICSPATH * this,
    INT x, INT y, INT width, INT height, REAL startAngle, REAL sweepAngle)
{
    return (this->lastResult = GdipAddPathArcI((GP_GPPATH*)this->nativePath, x, y,
                    width, height, startAngle, sweepAngle));
}

GpStatus GpGraphicsPath_AddArcRcI(GP_GRAPHICSPATH * this, const RECTI * rect, REAL startAngle, REAL sweepAngle)
{
    return GpGraphicsPath_AddArc4I(this, rect->X, rect->Y,
                rect->Width, rect->Height, startAngle, sweepAngle);
}

GpStatus GpGraphicsPath_AddBezier8F(GP_GRAPHICSPATH * this, REAL x1, REAL y1,
    REAL x2, REAL y2, REAL x3, REAL y3, REAL x4, REAL y4)
{
    return (this->lastResult = GdipAddPathBezier((GP_GPPATH*)this->nativePath,
                    x1, y1, x2, y2, x3, y3, x4, y4));
}

GpStatus GpGraphicsPath_AddBezierPtsF( GP_GRAPHICSPATH * this, const POINTF * pt1,
    const POINTF * pt2, const POINTF * pt3, const POINTF * pt4)
{
    return GpGraphicsPath_AddBezier8F(this, pt1->X, pt1->Y, pt2->X, pt2->Y,
                pt3->X, pt3->Y, pt4->X, pt4->Y);
}

GpStatus GpGraphicsPath_AddBeziersPtF(GP_GRAPHICSPATH * this, const POINTF* points, INT count)
{
    return (this->lastResult = GdipAddPathBeziers((GP_GPPATH*)this->nativePath,
                    points, count));
}

GpStatus GpGraphicsPath_AddBezier8I(GP_GRAPHICSPATH * this, INT x1, INT y1,
    INT x2, INT y2, INT x3, INT y3, INT x4, INT y4)
{
    return (this->lastResult = GdipAddPathBezierI((GP_GPPATH*)this->nativePath, x1, y1,
                    x2, y2, x3, y3, x4, y4));
}

GpStatus GpGraphicsPath_AddBezier(GP_GRAPHICSPATH * this, const POINTI * pt1,
		const POINTI * pt2, const POINTI * pt3, const POINTI * pt4)
{
    return GpGraphicsPath_AddBezier8I(this, pt1->X, pt1->Y,
                pt2->X, pt2->Y, pt3->X, pt3->Y, pt4->X, pt4->Y);
}

GpStatus GpGraphicsPath_AddBeziersI(GP_GRAPHICSPATH * this, const POINTI* points, INT count)
{
    return (this->lastResult = GdipAddPathBeziersI((GP_GPPATH*)this->nativePath,
			points, count));
}

GpStatus GpGraphicsPath_AddCurveF(GP_GRAPHICSPATH * this, const POINTF* points, INT count)
{
    return (this->lastResult = GdipAddPathCurve((GP_GPPATH*)this->nativePath,
			points, count));
}

GpStatus GpGraphicsPath_AddCurve2F(GP_GRAPHICSPATH * this, const POINTF* points, INT count, REAL tension)
{
    return (this->lastResult = GdipAddPathCurve2((GP_GPPATH*)this->nativePath,
			points, count, tension));
}

GpStatus GpGraphicsPath_AddCurve3F( GP_GRAPHICSPATH * this, const POINTF* points,
    INT count, INT offset, INT numberOfSegments, REAL tension)
{
    return (this->lastResult = GdipAddPathCurve3((GP_GPPATH*)this->nativePath,
                    points, count, offset, numberOfSegments, tension));
}

GpStatus GpGraphicsPath_AddCurveI( GP_GRAPHICSPATH * this, const POINTI* points, INT count)
{
    return (this->lastResult = GdipAddPathCurveI((GP_GPPATH*)this->nativePath, points, count));
}

GpStatus GpGraphicsPath_AddCurve2I(GP_GRAPHICSPATH * this, const POINTI* points, INT count, REAL tension)
{
    return (this->lastResult = GdipAddPathCurve2I((GP_GPPATH*)this->nativePath,
                    points, count, tension));
}

GpStatus GpGraphicsPath_AddCurve3I(GP_GRAPHICSPATH * this, const POINTI* points,
    INT count, INT offset, INT numberOfSegments, REAL tension)
{
    return (this->lastResult = GdipAddPathCurve3I((GP_GPPATH*)this->nativePath,
                    points, count, offset, numberOfSegments, tension));
}

// float version
GpStatus GpGraphicsPath_AddClosedCurve( GP_GRAPHICSPATH * this, const POINTF* points, INT count)
{
    return (this->lastResult = GdipAddPathClosedCurve((GP_GPPATH*)this->nativePath,
                    points, count));
}

GpStatus GpGraphicsPath_AddClosedCurve2( GP_GRAPHICSPATH * this, const POINTF* points,
    INT count, REAL tension )
{
    return (this->lastResult = GdipAddPathClosedCurve2((GP_GPPATH*)this->nativePath,
                    points, count, tension));
}

// integer version
GpStatus GpGraphicsPath_AddClosedCurveI( GP_GRAPHICSPATH * this, const POINTI* points, INT count)
{
    return (this->lastResult = GdipAddPathClosedCurveI((GP_GPPATH*)this->nativePath,
                    points, count));
}

GpStatus GpGraphicsPath_AddClosedCurve2I( GP_GRAPHICSPATH * this, const POINTI* points, INT count, REAL tension)
{
    return (this->lastResult = GdipAddPathClosedCurve2I((GP_GPPATH*)this->nativePath,
                    points, count, tension));
}

// Add closed shapes to the path object
// float version
GpStatus GpGraphicsPath_AddRectangle(GP_GRAPHICSPATH * this, const RECTF * rect)
{
    return (this->lastResult = GdipAddPathRectangle((GP_GPPATH*)this->nativePath,
                    rect->X, rect->Y, rect->Width, rect->Height));
}

GpStatus GpGraphicsPath_AddRectangles(GP_GRAPHICSPATH * this, const RECTF* rects, INT count)
{
    return (this->lastResult = GdipAddPathRectangles((GP_GPPATH*)this->nativePath,
                    rects, count));
}

// integer version
GpStatus GpGraphicsPath_AddRectangleRcI(GP_GRAPHICSPATH * this, const RECTI * rect)
{
    return (this->lastResult = GdipAddPathRectangleI((GP_GPPATH*)this->nativePath,
                    rect->X, rect->Y, rect->Width, rect->Height));
}

GpStatus GpGraphicsPath_AddRectanglesRcsI(GP_GRAPHICSPATH * this, const RECTI* rects, INT count)
{
    return (this->lastResult = GdipAddPathRectanglesI((GP_GPPATH*)this->nativePath,
                    rects, count));
}

// float version
GpStatus GpGraphicsPath_AddEllipse4F( GP_GRAPHICSPATH * this, REAL x, REAL y,
    REAL width, REAL height)
{
    return (this->lastResult = GdipAddPathEllipse((GP_GPPATH*)this->nativePath,
                    x, y, width, height));
}

GpStatus GpGraphicsPath_AddEllipseRcF( GP_GRAPHICSPATH * this,  const RECTF * rect)
{
    return GpGraphicsPath_AddEllipse4F(this, rect->X, rect->Y,
                rect->Width, rect->Height);
}

// integer version
GpStatus GpGraphicsPath_AddEllipse4I(GP_GRAPHICSPATH * this, INT x, INT y,
    INT width, INT height)
{
    return (this->lastResult = GdipAddPathEllipseI((GP_GPPATH*)this->nativePath,
                    x, y, width, height));
}

GpStatus GpGraphicsPath_AddEllipse( GP_GRAPHICSPATH * this, const RECTI * rect)
{
    return GpGraphicsPath_AddEllipse4I(this, rect->X, rect->Y,
                rect->Width, rect->Height);
}

// float version
GpStatus GpGraphicsPath_AddPie4F(GP_GRAPHICSPATH * this, REAL x, REAL y,
    REAL width, REAL height, REAL startAngle, REAL sweepAngle)
{
    return (this->lastResult = GdipAddPathPie((GP_GPPATH*)this->nativePath,
                    x, y, width, height, startAngle, sweepAngle));
}

GpStatus GpGraphicsPath_AddPieRcF(GP_GRAPHICSPATH * this,
    const RECTF * rect, REAL startAngle, REAL sweepAngle)
{
    return GpGraphicsPath_AddPie4F(this, rect->X, rect->Y,
                rect->Width, rect->Height, startAngle, sweepAngle);
}

GpStatus GpGraphicsPath_AddPieI( GP_GRAPHICSPATH * this, INT x, INT y,
    INT width, INT height, REAL startAngle, REAL sweepAngle)
{
    return (this->lastResult = GdipAddPathPieI((GP_GPPATH*)this->nativePath,
                    x, y, width, height, startAngle, sweepAngle));
}

GpStatus GpGraphicsPath_AddPieRc( GP_GRAPHICSPATH * this, const RECTI * rect,
		REAL startAngle, REAL sweepAngle)
{
    return GpGraphicsPath_AddPieI(this, rect->X, rect->Y, rect->Width,
				rect->Height, startAngle, sweepAngle);
}

GpStatus GpGraphicsPath_AddPolygonF(GP_GRAPHICSPATH * this, const POINTF* points, INT count)
{
    return (this->lastResult = GdipAddPathPolygon((GP_GPPATH*)this->nativePath,
                    points, count));
}

// integer version
GpStatus GpGraphicsPath_AddPolygon(GP_GRAPHICSPATH * this, const POINTI* points, INT count)
{
    return (this->lastResult = GdipAddPathPolygonI((GP_GPPATH*)this->nativePath,
                    points, count));
}

GpStatus GpGraphicsPath_AddPath(GP_GRAPHICSPATH * this,
    const GP_GRAPHICSPATH* addingPath,  BOOL connect )
{
    GP_GPGRAPHICSPATH * nativePath2 = NULL;
    if(addingPath)
        nativePath2 = addingPath->nativePath;

    return (this->lastResult = GdipAddPathPath((GP_GPPATH*)this->nativePath,
                    (GP_GPPATH*)nativePath2, connect));
}

GpStatus GpGraphicsPath_AddStringPtF(GP_GRAPHICSPATH * this, const WCHAR *string,
    INT length, const GP_FONTFAMILY *family, INT style, REAL emSize,  // In world units
    const POINTF * origin, const GP_STRINGFORMAT  *format)
{

    RECTF rect = GpRectF(origin->X, origin->Y, 0.0f, 0.0f);

    return (this->lastResult = GdipAddPathString((GP_GPPATH*)this->nativePath,
                    string,
					length,
                    family ? family->nativeFamily : NULL,
                    style,
					emSize,
                    &rect,
                    format ? format->nativeFormat : NULL));
}

GpStatus GpGraphicsPath_AddStringRcF(GP_GRAPHICSPATH * this, const WCHAR *string,
    INT length, const GP_FONTFAMILY *family, INT style, REAL emSize,
	const RECTF * layoutRect, const GP_STRINGFORMAT *format)
{
    return (this->lastResult = GdipAddPathString((GP_GPPATH*)this->nativePath,
                    string,
                    length,
                    family ? family->nativeFamily : NULL,
                    style,
                    emSize,
                    layoutRect,
                    format ? format->nativeFormat : NULL));
}

GpStatus GpGraphicsPath_AddStringPtI(GP_GRAPHICSPATH * this, const WCHAR *string,
    INT length, const GP_FONTFAMILY *family, INT style,
    REAL emSize, const POINTI * origin, const GP_STRINGFORMAT *format)
{
    RECTI rect = GpRectI(origin->X, origin->Y, 0, 0);

    return (this->lastResult = GdipAddPathStringI((GP_GPPATH*)this->nativePath,
                    string,
                    length,
                    family ? family->nativeFamily : NULL,
                    style,
                    emSize,
                    &rect,
                    format ? format->nativeFormat : NULL));
}

GpStatus GpGraphicsPath_AddStringRcI(GP_GRAPHICSPATH * this, const WCHAR *string,
    INT length, const GP_FONTFAMILY *family, INT style, REAL emSize,  // In world units
    const RECTI * layoutRect, const GP_STRINGFORMAT *format)
{
    return (this->lastResult = GdipAddPathStringI((GP_GPPATH*)this->nativePath,
                    string,
                    length,
                    family ? family->nativeFamily : NULL,
                    style,
                    emSize,
                    layoutRect,
                    format ? format->nativeFormat : NULL));
}

GpStatus GpGraphicsPath_Transform(GP_GRAPHICSPATH * this, const GP_MATRIX* matrix)
{
    if(matrix)
	{
        return (this->lastResult = GdipTransformPath((GP_GPPATH*)this->nativePath,
                        matrix->nativeMatrix));
    }
    else
	{
        return eOk;  // No need to transform.
    }
}

//GpStatus GpGraphicsPath_Flatten( GP_GRAPHICSPATH * this, const GP_MATRIX* matrix = NULL,  REAL flatness = FlatnessDefault)
GpStatus GpGraphicsPath_Flatten(GP_GRAPHICSPATH * this, const GP_MATRIX* matrix, REAL flatness)
{
    GP_GPMATRIX * nativeMatrix = NULL;
    if(matrix)
    {
        nativeMatrix = matrix->nativeMatrix;
    }

    return (this->lastResult = GdipFlattenPath((GP_GPPATH*)this->nativePath,
                    nativeMatrix, flatness));
}

//GpStatus GpGraphicsPath_Widen(GP_GRAPHICSPATH * this, const GP_PEN* pen, const GP_MATRIX* matrix = NULL, REAL flatness = FlatnessDefault)
GpStatus GpGraphicsPath_Widen(GP_GRAPHICSPATH * this, const GP_PEN* pen,
    const GP_MATRIX* matrix, REAL flatness)
{
    GP_GPMATRIX * nativeMatrix = NULL;
    if(matrix)
        nativeMatrix = matrix->nativeMatrix;

    return (this->lastResult = GdipWidenPath((GP_GPPATH*)this->nativePath,
                    pen->nativePen, nativeMatrix, flatness));
}

//GpStatus GpGraphicsPath_Outline(GP_GRAPHICSPATH * this, const GP_MATRIX *matrix = NULL, REAL flatness = FlatnessDefault)
GpStatus GpGraphicsPath_Outline(GP_GRAPHICSPATH * this, const GP_MATRIX *matrix, REAL flatness)
{
    GP_GPMATRIX* nativeMatrix = NULL;
    if(matrix)
    {
        nativeMatrix = matrix->nativeMatrix;
    }

    return (this->lastResult = GdipWindingModeOutline((GP_GPPATH*)this->nativePath,
                    nativeMatrix, flatness));
}

//GpStatus GpGraphicsPath_Warp(GP_GRAPHICSPATH * this, const POINTF* destPoints,  INT count, const RECTF * srcRect, const GP_MATRIX* matrix = NULL, GpWarpMode warpMode = eWarpModePerspective, REAL flatness = FlatnessDefault)
GpStatus GpGraphicsPath_Warp(GP_GRAPHICSPATH * this, const POINTF* destPoints,
    INT count, const RECTF * srcRect, const GP_MATRIX* matrix,
    GpWarpMode warpMode, REAL flatness)
{
    GP_GPMATRIX* nativeMatrix = NULL;
    if(matrix)
        nativeMatrix = matrix->nativeMatrix;

    return (this->lastResult = GdipWarpPath((GP_GPPATH*)this->nativePath,
                    nativeMatrix,
                    destPoints,
                    count,
                    srcRect->X, srcRect->Y,
                    srcRect->Width, srcRect->Height,
                    warpMode,
                    flatness));
}

GpStatus GpGraphicsPath_GetPathTypes(GP_GRAPHICSPATH * this, BYTE* types, INT count)
{
    return (this->lastResult = GdipGetPathTypes((GP_GPPATH*)this->nativePath,
                    types, count));
}

GpStatus GpGraphicsPath_GetPathPointsF(GP_GRAPHICSPATH * this,
		POINTF* points, INT count)
{
    return (this->lastResult = GdipGetPathPoints((GP_GPPATH*)this->nativePath,
                    points, count));
}

GpStatus GpGraphicsPath_GetPathPointsI(GP_GRAPHICSPATH * this, POINTI* points, INT count)
{
    return (this->lastResult = GdipGetPathPointsI((GP_GPPATH*)this->nativePath,
                    points, count));
}

GpStatus GpGraphicsPath_GetLastStatus(GP_GRAPHICSPATH * this)
{
    GpStatus lastStatus = this->lastResult;
    this->lastResult = eOk;
    return lastStatus;
}

BOOL GpGraphicsPath_IsVisibleF(const GP_GRAPHICSPATH * this, const POINTF * point, GP_GRAPHICS* g)
{
    return GpGraphics_IsVisibleF(g, point->X, point->Y);
}

BOOL GpGraphicsPath_IsVisibleI(const GP_GRAPHICSPATH * this, const POINTI * point, GP_GRAPHICS* g)
{
    return GpGraphics_IsVisibleI(g, point->X, point->Y);
}

BOOL GpGraphicsPath_IsOutlineVisibleF(GP_GRAPHICSPATH * this,
    const POINTF * point, const GP_PEN* pen, const GP_GRAPHICS* g)
{
    return GpGraphics_PathIsOutlineVisibleF(this, point->X, point->Y, pen, g);
}

BOOL GpGraphicsPath_IsOutlineVisibleI(GP_GRAPHICSPATH * this,
    const POINTI * point,  const GP_PEN* pen, const GP_GRAPHICS* g)
{
    return GpGraphics_PathIsOutlineVisibleI(this, point->X, point->Y, pen, g);
}

GP_GRAPHICSPATH GpGraphicsPath_GraphicsPath(GP_GRAPHICSPATH * this)
{
    GP_GRAPHICSPATH path;
    GP_GPPATH *clonepath = NULL;
    path.lastResult = GdipClonePath((GP_GPPATH*)this->nativePath, &clonepath);
	path.nativePath = (GP_GPGRAPHICSPATH*)clonepath;
    return path;
}

GP_GRAPHICSPATHITERATOR GpGraphics_PathIterator(const GP_GRAPHICSPATH* path)
{
    GP_GPPATH * nativePath = NULL;
    if(path)
        nativePath = (GP_GPPATH*)path->nativePath;

	GP_GRAPHICSPATHITERATOR iter;
    iter.nativeIterator = NULL;
    iter.lastResult = GdipCreatePathIter(&iter.nativeIterator, nativePath);
    return iter;
}

VOID GpGraphicsPathIterator_Delete(GP_GRAPHICSPATHITERATOR * this)
{
	GdipDeletePathIter(this->nativeIterator);
}

INT GpGraphicsPathIterator_NextSubpath(GP_GRAPHICSPATHITERATOR * this,
    INT* startIndex, INT* endIndex, BOOL* isClosed)
{
    INT resultCount;
    (this->lastResult = GdipPathIterNextSubpath(this->nativeIterator,
            &resultCount, startIndex, endIndex, isClosed));
    return resultCount;
}

INT GpGraphicsPathIterator_NextSubpathGp(GP_GRAPHICSPATHITERATOR * this,
    const GP_GRAPHICSPATH* path, BOOL* isClosed)
{
    GP_GPGRAPHICSPATH * nativePath = NULL;
    INT resultCount;
    if(path)
        nativePath = path->nativePath;

    (this->lastResult = GdipPathIterNextSubpathPath(this->nativeIterator,
            &resultCount, (GP_GPPATH*)nativePath, isClosed));
    return resultCount;
}

INT GpGraphicsPathIterator_NextPathType(GP_GRAPHICSPATHITERATOR * this,
    BYTE* pathType, INT* startIndex, INT* endIndex)
{
    INT resultCount;
    (this->lastResult = GdipPathIterNextPathType(this->nativeIterator,
            &resultCount, pathType,  startIndex, endIndex));
    return resultCount;
}

INT GpGraphicsPathIterator_NextMarker(GP_GRAPHICSPATHITERATOR * this,
    INT* startIndex, INT* endIndex)
{
    INT resultCount;
    (this->lastResult = GdipPathIterNextMarker(this->nativeIterator,
            &resultCount, startIndex, endIndex));
    return resultCount;
}

INT GpGraphicsPathIterator_NextMarkerGp(GP_GRAPHICSPATHITERATOR * this,
    const GP_GRAPHICSPATH* path)
{
    GP_GPGRAPHICSPATH* nativePath = NULL;
    INT resultCount;
    if(path)
        nativePath= path->nativePath;

    (this->lastResult = GdipPathIterNextMarkerPath(this->nativeIterator,
            &resultCount, (GP_GPPATH*)nativePath)
    );
    return resultCount;
}

INT GpGraphicsPathIterator_GetCount(GP_GRAPHICSPATHITERATOR * this)
{
    INT resultCount;
    (this->lastResult = GdipPathIterGetCount(this->nativeIterator,
            &resultCount));
    return resultCount;
}

INT GpGraphicsPathIterator_GetSubpathCount(GP_GRAPHICSPATHITERATOR * this)
{
    INT resultCount;
    (this->lastResult = GdipPathIterGetSubpathCount(this->nativeIterator,
            &resultCount));
    return resultCount;
}

BOOL GpGraphicsPathIterator_HasCurve(GP_GRAPHICSPATHITERATOR * this)
{
    BOOL hasCurve;
    (this->lastResult = GdipPathIterHasCurve(this->nativeIterator,
            &hasCurve));
    return hasCurve;
}

VOID GpGraphicsPathIterator_Rewind(GP_GRAPHICSPATHITERATOR * this)
{
    (this->lastResult = GdipPathIterRewind(this->nativeIterator));
}

INT GpGraphicsPathIterator_Enumerate(GP_GRAPHICSPATHITERATOR * this,
    POINTF *points, BYTE *types, INT count)
{
    INT resultCount;
    (this->lastResult = GdipPathIterEnumerate(this->nativeIterator,
            &resultCount, points, types, count));
    return resultCount;
}

INT GpGraphicsPathIterator_CopyData( GP_GRAPHICSPATHITERATOR * this,
    POINTF* points, BYTE* types, INT startIndex, INT endIndex)
{
    INT resultCount;
    (this->lastResult = GdipPathIterCopyData(this->nativeIterator,
            &resultCount, points, types, startIndex, endIndex));
    return resultCount;
}

GpStatus GpGraphicsPathIterator_GetLastStatus(GP_GRAPHICSPATHITERATOR * this)
{
    GpStatus lastStatus = this->lastResult;
	this->lastResult = eOk;
    return lastStatus;
}

//GP_BRUSH GpPathGradient_Brush(const POINTF* points, INT count, WrapMode wrapMode = WrapModeClamp)
GP_BRUSH GpPathGradientBrush_PtF(const POINTF * points, INT count, GpWrapMode wrapMode)
{
    GP_BRUSH this;
    GP_GPPATHGRADIENTBRUSH * brush = NULL;
    this.lastResult = GdipCreatePathGradient(points, count, wrapMode, &brush);
    this.nativeBrush = (GP_GPBRUSH*)brush;
    return this;
}

//GP_PATHGRADIENTBRUSH GpPathGradient_BrushPtI(const POINTI* points, INT count, GpWrapMode wrapMode = WrapModeClamp)
GP_PATHGRADIENTBRUSH GpPathGradientBrush_PtI(const POINTI* points, INT count,
    GpWrapMode wrapMode)
{
    GP_PATHGRADIENTBRUSH this;
    GP_GPPATHGRADIENTBRUSH *brush = NULL;
    this.lastResult = GdipCreatePathGradientI(points, count, wrapMode, &brush);
    this.nativeBrush = brush;
    return this;
}

GP_PATHGRADIENTBRUSH GpPathGradientBrush(const GP_GRAPHICSPATH* path)
{
    GP_PATHGRADIENTBRUSH this;
    GP_GPPATHGRADIENTBRUSH *brush = NULL;
    this.lastResult = GdipCreatePathGradientFromPath((GP_GPPATH*)path->nativePath, &brush);
	this.nativeBrush = brush;
    return this;
}

GpStatus GpPathGradientBrush_GetCenterColor(GP_PATHGRADIENTBRUSH * this, COLOR * color)
{
    ARGB argb;
    if (color == NULL)
    {
        return (this->lastResult = eInvalidParameter);
    }

    (this->lastResult = GdipGetPathGradientCenterColor((GP_GPPATHGRADIENTBRUSH*) this->nativeBrush, &argb));

    GpColor_SetValue(color, argb);
    return this->lastResult;
}

GpStatus GpPathGradientBrush_SetCenterColor(GP_PATHGRADIENTBRUSH * this, COLOR * color)
{
    (this->lastResult = GdipSetPathGradientCenterColor((GP_GPPATHGRADIENTBRUSH*) this->nativeBrush, GpColor_GetValue(color)));
    return this->lastResult;
}

INT GpPathGradientBrush_GetPointCount(GP_PATHGRADIENTBRUSH * this)
{
    INT count;
    (this->lastResult = GdipGetPathGradientPointCount((GP_GPPATHGRADIENTBRUSH*) this->nativeBrush, &count));
    return count;
}

INT GpPathGradientBrush_GetSurroundColorCount(GP_PATHGRADIENTBRUSH * this)
{
    INT count;
    this->lastResult = GdipGetPathGradientSurroundColorCount((GP_GPPATHGRADIENTBRUSH*) this->nativeBrush, &count);
    return count;
}

GpStatus GpPathGradientBrush_GetSurroundColors(GP_PATHGRADIENTBRUSH * this,  COLOR* colors, INT* count)
{
    if( colors == NULL || count == NULL)
    {
        return (this->lastResult = eInvalidParameter);
    }

    INT count1;

    this->lastResult = GdipGetPathGradientSurroundColorCount((GP_GPPATHGRADIENTBRUSH*) this->nativeBrush, &count1);

    if(this->lastResult != eOk)
        return this->lastResult;

    if((*count < count1) || (count1 <= 0))
        return (this->lastResult = eInsufficientBuffer);

    // ARGB* argbs = (ARGB*) new ARGB[count1];
    ARGB * argbs = GpAlloc(count1 * sizeof(ARGB));

    if(argbs == NULL)
        return (this->lastResult = eOutOfMemory);

    this->lastResult = GdipGetPathGradientSurroundColorsWithCount((GP_GPPATHGRADIENTBRUSH*) this->nativeBrush, argbs, &count1);

	if(this->lastResult == eOk)
	{
		for(INT i = 0; i < count1; i++)
		{
			GpColor_SetValue(&colors[i], argbs[i]);
		}
		*count = count1;
	}

    GpFree(argbs);
    return this->lastResult;
}

GpStatus GpPathGradientBrush_SetSurroundColors(GP_PATHGRADIENTBRUSH * this, const COLOR* colors, INT* count)
{
    if(colors == NULL || count == NULL)
    {
        return (this->lastResult = eInvalidParameter);
    }

    INT count1 = GpPathGradientBrush_GetPointCount(this);

    if((*count > count1) || (count1 <= 0))
        return (this->lastResult = eInvalidParameter);

    count1 = *count;

    ARGB* argbs = GpAlloc(count1*sizeof(ARGB));
    if(argbs == NULL)
        return (this->lastResult = eOutOfMemory);

    for(INT i = 0; i < count1; i++)
    {
        argbs[i] = GpColor_GetValue(&colors[i]);
    }

    this->lastResult = GdipSetPathGradientSurroundColorsWithCount((GP_GPPATHGRADIENTBRUSH*) this->nativeBrush,  argbs, &count1);

	if(this->lastResult == eOk)
		*count = count1;

    GpFree(argbs);
    return this->lastResult;
}

GpStatus GpPathGradientBrush_GetGraphicsPath(GP_PATHGRADIENTBRUSH * this, GP_GRAPHICSPATH* path)
{
    if(path == NULL)
        return (this->lastResult = eInvalidParameter);

    return (this->lastResult = GdipGetPathGradientPath((GP_GPPATHGRADIENTBRUSH*) this->nativeBrush, (GP_GPPATH*)path->nativePath));
}

GpStatus GpPathGradientBrush_SetGraphicsPath(GP_PATHGRADIENTBRUSH * this, GP_GRAPHICSPATH* path)
{
    if(path == NULL)
        return (this->lastResult = eInvalidParameter);

    return (this->lastResult = GdipSetPathGradientPath((GP_GPPATHGRADIENTBRUSH*) this->nativeBrush, (GP_GPPATH*)path->nativePath));
}

GpStatus GpPathGradientBrush_GetCenterPointF(GP_PATHGRADIENTBRUSH * this, POINTF* point)
{
    return (this->lastResult = GdipGetPathGradientCenterPoint((GP_GPPATHGRADIENTBRUSH*) this->nativeBrush, point));
}

GpStatus GpPathGradientBrush_GetCenterPointI(GP_PATHGRADIENTBRUSH * this, POINTI* point)
{
    return (this->lastResult = GdipGetPathGradientCenterPointI((GP_GPPATHGRADIENTBRUSH*) this->nativeBrush, point));
}

GpStatus GpPathGradientBrush_SetCenterPointF(GP_PATHGRADIENTBRUSH * this, const POINTF * point)
{
    return (this->lastResult = GdipSetPathGradientCenterPoint((GP_GPPATHGRADIENTBRUSH*) this->nativeBrush, point));
}

GpStatus GpPathGradientBrush_SetCenterPointI(GP_PATHGRADIENTBRUSH * this, const POINTI * point)
{
    return (this->lastResult = GdipSetPathGradientCenterPointI((GP_GPPATHGRADIENTBRUSH*) this->nativeBrush, point));
}

GpStatus GpPathGradientBrush_GetRectangleF(GP_PATHGRADIENTBRUSH * this, RECTF* rect)
{
    return (this->lastResult = GdipGetPathGradientRect((GP_GPPATHGRADIENTBRUSH*) this->nativeBrush, rect));
}

GpStatus GpPathGradientBrush_GetRectangleI(GP_PATHGRADIENTBRUSH * this, RECTI* rect)
{
    return (this->lastResult = GdipGetPathGradientRectI((GP_GPPATHGRADIENTBRUSH*) this->nativeBrush, rect));
}

GpStatus GpPathGradientBrush_SetGammaCorrection(GP_PATHGRADIENTBRUSH * this, BOOL useGammaCorrection)
{
    return (this->lastResult = GdipSetPathGradientGammaCorrection((GP_GPPATHGRADIENTBRUSH*) this->nativeBrush, useGammaCorrection));
}

BOOL GpPathGradientBrush_GetGammaCorrection(GP_PATHGRADIENTBRUSH * this)
{
    BOOL useGammaCorrection;
    this->lastResult = GdipGetPathGradientGammaCorrection((GP_GPPATHGRADIENTBRUSH*) this->nativeBrush, &useGammaCorrection);
    return useGammaCorrection;
}


INT GpPathGradientBrush_GetBlendCount(GP_PATHGRADIENTBRUSH * this)
{
    INT count = 0;
    this->lastResult = GdipGetPathGradientBlendCount((GP_GPPATHGRADIENTBRUSH*) this->nativeBrush, &count);
    return count;
}

GpStatus GpPathGradientBrush_GetBlend(GP_PATHGRADIENTBRUSH * this,
    REAL* blendFactors, REAL* blendPositions, INT count)
{
    return (this->lastResult = GdipGetPathGradientBlend((GP_GPPATHGRADIENTBRUSH*) this->nativeBrush,
                    blendFactors, blendPositions, count));
}

GpStatus GpPathGradientBrush_SetBlend(GP_PATHGRADIENTBRUSH * this,
    const REAL* blendFactors, const REAL* blendPositions, INT count)
{
    return (this->lastResult = GdipSetPathGradientBlend((GP_GPPATHGRADIENTBRUSH*) this->nativeBrush,
                    blendFactors, blendPositions, count));
}

INT  GpPathGradientBrush_GetInterpolationColorCount(GP_PATHGRADIENTBRUSH * this)
{
    INT count = 0;
    (this->lastResult = GdipGetPathGradientPresetBlendCount((GP_GPPATHGRADIENTBRUSH*) this->nativeBrush, &count));
    return count;
}


GpStatus GpPathGradientBrush_SetInterpolationColors(GP_PATHGRADIENTBRUSH * this,
	const COLOR* presetColors, const REAL* blendPositions, INT count)
{
    if ((count <= 0) || !presetColors)
    {
        return (this->lastResult = eInvalidParameter);
    }

    ARGB* argbs = GpAlloc(count * sizeof(ARGB));
    if(argbs)
    {
        for(INT i = 0; i < count; i++)
        {
            argbs[i] = GpColor_GetValue(&presetColors[i]);
        }

        GpStatus status = (this->lastResult = GdipSetPathGradientPresetBlend(
                                        (GP_GPPATHGRADIENTBRUSH*) this->nativeBrush,
                                        argbs, blendPositions, count));
        GpFree(argbs);
        return status;
    }
    else
    {
        return (this->lastResult = eOutOfMemory);
    }
}

GpStatus GpPathGradientBrush_GetInterpolationColors(GP_PATHGRADIENTBRUSH * this,
	COLOR* presetColors, REAL* blendPositions, INT count)
{
    if ((count <= 0) || !presetColors)
    {
        return (this->lastResult = eInvalidParameter);
    }

    ARGB* argbs = GpAlloc(count * sizeof(ARGB));

    if (!argbs)
    {
        return (this->lastResult = eOutOfMemory);
    }

    GpStatus  status = (this->lastResult = GdipGetPathGradientPresetBlend(
                                        (GP_GPPATHGRADIENTBRUSH*) this->nativeBrush,
                                        argbs, blendPositions, count));

    for(INT i = 0; i < count; i++)
    {
        presetColors[i] = GpColor(argbs[i]);
    }

    GpFree(argbs);

    return status;
}

//GpStatus GpPathGradientBrush_SetBlendBellShape(GP_PATHGRADIENTBRUSH * this, REAL focus, REAL scale = 1.0f)
GpStatus GpPathGradientBrush_SetBlendBellShape(GP_PATHGRADIENTBRUSH * this,
    REAL focus, REAL scale)
{
    return (this->lastResult = GdipSetPathGradientSigmaBlend(
                    (GP_GPPATHGRADIENTBRUSH*) this->nativeBrush,
                    focus, scale));
}

//GpStatus GpPathGradientBrush_SetBlendTriangularShape(GP_PATHGRADIENTBRUSH * this, REAL focus, REAL scale = 1.0f)
GpStatus GpPathGradientBrush_SetBlendTriangularShape(GP_PATHGRADIENTBRUSH * this,
    REAL focus, REAL scale)
{
    return (this->lastResult = GdipSetPathGradientLinearBlend(
                    (GP_GPPATHGRADIENTBRUSH*) this->nativeBrush,
                    focus, scale));
}

GpStatus GpPathGradientBrush_GetTransform(GP_PATHGRADIENTBRUSH * this, GP_MATRIX *matrix)
{
    return (this->lastResult = GdipGetPathGradientTransform(
                    (GP_GPPATHGRADIENTBRUSH*) this->nativeBrush,
                    matrix->nativeMatrix));
}

GpStatus GpPathGradientBrush_SetTransform(GP_PATHGRADIENTBRUSH * this, GP_MATRIX* matrix)
{
    return (this->lastResult = GdipSetPathGradientTransform(
                    (GP_GPPATHGRADIENTBRUSH*) this->nativeBrush,
                    matrix->nativeMatrix));
}

GpStatus GpPathGradientBrush_ResetTransform(GP_PATHGRADIENTBRUSH * this)
{
    return (this->lastResult = GdipResetPathGradientTransform((GP_GPPATHGRADIENTBRUSH*) this->nativeBrush));
}

//GpStatus GpPathGradientBrush_MultiplyTransformM(GP_PATHGRADIENTBRUSH * this, GP_MATRIX* matrix, GpMatrixOrder order = eMatrixOrderPrepend)
GpStatus GpPathGradientBrush_MultiplyTransformM(GP_PATHGRADIENTBRUSH * this,
    const GP_MATRIX* matrix, GpMatrixOrder order)
{
    return (this->lastResult = GdipMultiplyPathGradientTransform(
                    (GP_GPPATHGRADIENTBRUSH*) this->nativeBrush,
                    matrix->nativeMatrix, order));
}

//GpStatus GpPathGradientBrush_TranslateTransformF(GP_PATHGRADIENTBRUSH * this, REAL dx,REAL dy, GpMatrixOrder order = eMatrixOrderPrepend)
GpStatus GpPathGradientBrush_TranslateTransformF(GP_PATHGRADIENTBRUSH * this,
    REAL dx, REAL dy, GpMatrixOrder order)
{
    return (this->lastResult = GdipTranslatePathGradientTransform(
                    (GP_GPPATHGRADIENTBRUSH*) this->nativeBrush,
                    dx, dy, order));
}


//GpStatus GpPathGradientBrush_ScaleTransform(GP_PATHGRADIENTBRUSH * this, REAL sx, REAL sy, GpMatrixOrder order = eMatrixOrderPrepend)
GpStatus GpPathGradientBrush_ScaleTransform(GP_PATHGRADIENTBRUSH * this,
    REAL sx, REAL sy, GpMatrixOrder order)
{
    return (this->lastResult = GdipScalePathGradientTransform(
                    (GP_GPPATHGRADIENTBRUSH*) this->nativeBrush,
                    sx, sy, order));
}

//GpStatus GpPathGradientBrush_RotateTransform(GP_PATHGRADIENTBRUSH * this,REAL angle, GpMatrixOrder order = eMatrixOrderPrepend)
GpStatus GpPathGradientBrush_RotateTransform(GP_PATHGRADIENTBRUSH * this,
    REAL angle, GpMatrixOrder order)
{
    return (this->lastResult = GdipRotatePathGradientTransform(
                    (GP_GPPATHGRADIENTBRUSH*) this->nativeBrush,
                    angle, order));
}

GpStatus GpPathGradientBrush_GetFocusScales(GP_PATHGRADIENTBRUSH * this,
    REAL* xScale, REAL* yScale)
{
    return (this->lastResult = GdipGetPathGradientFocusScales(
                    (GP_GPPATHGRADIENTBRUSH*) this->nativeBrush,
                    xScale, yScale));
}

GpStatus GpPathGradientBrush_SetFocusScales(GP_PATHGRADIENTBRUSH * this,
    REAL xScale, REAL yScale)
{
    return (this->lastResult = GdipSetPathGradientFocusScales(
                    (GP_GPPATHGRADIENTBRUSH*) this->nativeBrush,
                    xScale, yScale));
}

GpWrapMode GpPathGradientBrush_GetWrapMode(GP_PATHGRADIENTBRUSH * this)
{
    GpWrapMode wrapMode;

    this->lastResult = GdipGetPathGradientWrapMode((GP_GPPATHGRADIENTBRUSH*) this->nativeBrush, &wrapMode);
    return wrapMode;
}

GpStatus GpPathGradientBrush_SetWrapMode(GP_PATHGRADIENTBRUSH * this, GpWrapMode wrapMode)
{
    return (this->lastResult = GdipSetPathGradientWrapMode(
                    (GP_GPPATHGRADIENTBRUSH*) this->nativeBrush, wrapMode));
}

VOID GpGraphicsPath_Delete(GP_GRAPHICSPATH * this)
{
    GdipDeletePath((GP_GPPATH*)this->nativePath);
}

