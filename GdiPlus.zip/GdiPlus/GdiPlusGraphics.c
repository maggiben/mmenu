/**************************************************************************\
*
* All files in GdiPlusLib have been modified from the Microsoft
* GdiPlus C++ header files.
*
* Module Name:
*
*   GdiPlusGraphics.c
*
* Abstract:
*
*   Graphics related functions
*
\**************************************************************************/

#include <stdlib.h>
#include "GdiPlusGraphics.h"
#include "GdiPlusBitmap.h"
#include "GdiPlusPen.h"
#include "GdiPlusBrush.h"
#include "GdiPlusPath.h"
#include "GdiPlusRegion.h"
#include "GdiPlusFont.h"
#include "GdiPlusMatrix.h"
#include "GdiPlusColor.h"
#include "GdiPlusStringFormat.h"
#include "GdiPlusCachedBitmap.h"
#include "GdiPlusImageAttributes.h"
#include "GdiPlusMetaFile.h"

GP_GRAPHICS GpGraphics_FromHDC(HDC hdc)
{
	GP_GRAPHICS this;
	GP_GPGRAPHICS *graphics = NULL;
	this.lastResult = GdipCreateFromHDC(hdc, &graphics);
	this.nativeGraphics = graphics;
	return this;
}

GP_GRAPHICS GpGraphics_FromDEV(HDC hdc, HANDLE hdevice)
{
	GP_GRAPHICS this;
	GP_GPGRAPHICS *graphics = NULL;
	this.lastResult = GdipCreateFromHDC2(hdc, hdevice, &graphics);
	this.nativeGraphics = graphics;
	return this;
}

GP_GRAPHICS GpGraphics_FromHWND(HWND hwnd, BOOL icm)
{
	GP_GRAPHICS this;
	GP_GPGRAPHICS *graphics = NULL;
	if (icm)
	{
		this.lastResult = GdipCreateFromHWNDICM(hwnd, &graphics);
	}
	else
	{
		this.lastResult = GdipCreateFromHWND(hwnd, &graphics);
	}
	this.nativeGraphics = graphics;
	return this;
}

GP_GRAPHICS GpGraphics_FromIMG(GP_IMAGE * image)
{
	GP_GRAPHICS this;
	GP_GPGRAPHICS *graphics = NULL;
	if (image != NULL)
	{
		this.lastResult = GdipGetImageGraphicsContext(image->nativeImage, &graphics);
	}
	this.nativeGraphics = graphics;
	return this;
}

GpStatus GpGraphics_DrawLineF(GP_GRAPHICS * this, GP_PEN * pen, REAL x1, REAL y1, REAL x2, REAL y2)
{
	return GdipDrawLine(this->nativeGraphics, pen->nativePen, x1, y1, x2,  y2);
}

GpStatus GpGraphics_DrawLinePtF(GP_GRAPHICS * this, GP_PEN * pen, const POINTF * pt1, const POINTF * pt2)
{
	return GdipDrawLine(this->nativeGraphics, pen->nativePen, pt1->X, pt1->Y, pt2->X, pt2->Y);
}

VOID GpGraphics_Delete(GP_GRAPHICS * this)
{
	GdipDeleteGraphics(this->nativeGraphics);
}

VOID GpGraphics_Flush(GP_GRAPHICS * this, GpFlushIntention intention)
{
	GdipFlush(this->nativeGraphics, intention);
}

// Locks the graphics until ReleaseDC is called
HDC GpGraphics_GetHDC(GP_GRAPHICS * this)
{
	HDC hdc = NULL;
	this->lastResult = GdipGetDC(this->nativeGraphics, &hdc);
	return hdc;
}

VOID GpGraphics_ReleaseHDC(GP_GRAPHICS * this, HDC hdc)
{
	this->lastResult = GdipReleaseDC(this->nativeGraphics, hdc);
}

//------------------------------------------------------------------------
// Rendering modes
//------------------------------------------------------------------------
GpStatus GpGraphics_SetRenderingOrigin(GP_GRAPHICS * this, INT x, INT y)
{
	return (this->lastResult = GdipSetRenderingOrigin(this->nativeGraphics, x, y));
}

GpStatus GpGraphics_GetRenderingOrigin(GP_GRAPHICS * this, INT *x, INT *y)
{
	return (this->lastResult = GdipGetRenderingOrigin(this->nativeGraphics, x, y));
}

GpStatus GpGraphics_SetCompositingMode(GP_GRAPHICS * this, GpCompositingMode compositingMode)
{
	return (this->lastResult = GdipSetCompositingMode(this->nativeGraphics,compositingMode));
}

GpCompositingMode GpGraphics_GetCompositingMode(GP_GRAPHICS * this)
{
	GpCompositingMode mode;
	this->lastResult = GdipGetCompositingMode(this->nativeGraphics,&mode);
	return mode;
}

GpStatus GpGraphics_SetCompositingQuality(GP_GRAPHICS * this, GpCompositingQuality compositingQuality)
{
	return (this->lastResult = GdipSetCompositingQuality(this->nativeGraphics,compositingQuality));
}

GpCompositingQuality GpGraphics_GetCompositingQuality(GP_GRAPHICS * this)
{
	GpCompositingQuality quality;
	this->lastResult = GdipGetCompositingQuality(this->nativeGraphics,&quality);
	return quality;
}

GpStatus GpGraphics_SetTextRenderingHint(GP_GRAPHICS * this, GpTextRenderingHint newMode)
{
	return (this->lastResult = GdipSetTextRenderingHint(this->nativeGraphics, newMode));
}

GpTextRenderingHint GpGraphics_GetTextRenderingHint(GP_GRAPHICS * this)
{
	GpTextRenderingHint hint;
	this->lastResult = GdipGetTextRenderingHint(this->nativeGraphics,&hint);
	return hint;
}

GpStatus GpGraphics_SetTextContrast(GP_GRAPHICS * this, UINT contrast)
{
	return (this->lastResult = GdipSetTextContrast(this->nativeGraphics,contrast));
}

UINT GpGraphics_GetTextContrast(GP_GRAPHICS * this)
{
	UINT contrast;
	this->lastResult = GdipGetTextContrast(this->nativeGraphics,&contrast);
	return contrast;
}

GpInterpolationMode GpGraphics_GetInterpolationMode(GP_GRAPHICS * this)
{
	GpInterpolationMode mode = eInterpolationModeInvalid;
	this->lastResult = GdipGetInterpolationMode(this->nativeGraphics,&mode);
	return mode;
}

GpStatus GpGraphics_SetInterpolationMode(GP_GRAPHICS * this, GpInterpolationMode interpolationMode)
{
	return (this->lastResult = GdipSetInterpolationMode(this->nativeGraphics,interpolationMode));
}

GpSmoothingMode GpGraphics_GetSmoothingMode(GP_GRAPHICS * this)
{
	GpSmoothingMode smoothingMode = eSmoothingModeInvalid;
	(this->lastResult = GdipGetSmoothingMode(this->nativeGraphics, &smoothingMode));
	return smoothingMode;
}

GpStatus GpGraphics_SetSmoothingMode(GP_GRAPHICS * this, GpSmoothingMode smoothingMode)
{
	return (this->lastResult = GdipSetSmoothingMode(this->nativeGraphics,  smoothingMode));
}

GpPixelOffsetMode GpGraphics_GetPixelOffsetMode(GP_GRAPHICS * this)
{
	GpPixelOffsetMode pixelOffsetMode = ePixelOffsetModeInvalid;
	(this->lastResult = GdipGetPixelOffsetMode(this->nativeGraphics,&pixelOffsetMode));
	return pixelOffsetMode;
}

GpStatus GpGraphics_SetPixelOffsetMode(GP_GRAPHICS * this, GpPixelOffsetMode pixelOffsetMode)
{
	return (this->lastResult = GdipSetPixelOffsetMode(this->nativeGraphics,pixelOffsetMode));
}

//------------------------------------------------------------------------
// Manipulate current world transform
//------------------------------------------------------------------------
GpStatus GpGraphics_SetTransform(GP_GRAPHICS * this, const GP_MATRIX * matrix)
{
	return (this->lastResult = GdipSetWorldTransform(this->nativeGraphics,matrix->nativeMatrix));
}

GpStatus GpGraphics_ResetTransform(GP_GRAPHICS * this)
{
	return (this->lastResult = GdipResetWorldTransform(this->nativeGraphics));
}

//GpStatus 	GpGraphics_MultiplyTransform(GP_GRAPHICS * this, const GP_MATRIX * matrix, GpMatrixOrder order = eMatrixOrderPrepend);
GpStatus GpGraphics_MultiplyTransform(GP_GRAPHICS * this, const GP_MATRIX * matrix, GpMatrixOrder order)
{
	return (this->lastResult = GdipMultiplyWorldTransform(this->nativeGraphics,matrix->nativeMatrix,order));
}

//GpStatus 	GpGraphics_TranslateTransform(GP_GRAPHICS * this, REAL dx,REAL dy, GpMatrixOrder order = eMatrixOrderPrepend);
GpStatus GpGraphics_TranslateTransform(GP_GRAPHICS * this, REAL dx,REAL dy, GpMatrixOrder order)
{
	return (this->lastResult = GdipTranslateWorldTransform(this->nativeGraphics,dx, dy, order));
}

//GpStatus GpGraphics_ScaleTransform(GP_GRAPHICS * this, REAL sx,REAL sy, GpMatrixOrder order = eMatrixOrderPrepend);
GpStatus GpGraphics_ScaleTransform(GP_GRAPHICS * this, REAL sx,REAL sy, GpMatrixOrder order)
{
	return (this->lastResult = GdipScaleWorldTransform(this->nativeGraphics,sx, sy, order));
}

//GpStatus GpGraphics_RotateTransform(GP_GRAPHICS * this, REAL angle, GpMatrixOrder order = eMatrixOrderPrepend);
GpStatus GpGraphics_RotateTransform(GP_GRAPHICS * this, REAL angle, GpMatrixOrder order)
{
	return (this->lastResult = GdipRotateWorldTransform(this->nativeGraphics, angle, order));
}

GpStatus GpGraphics_GetTransform(GP_GRAPHICS * this, GP_MATRIX * matrix)
{
	return (this->lastResult = GdipGetWorldTransform(this->nativeGraphics,  matrix->nativeMatrix));
}

GpStatus GpGraphics_SetPageUnit(GP_GRAPHICS * this, GpUnit unit)
{
	return (this->lastResult = GdipSetPageUnit(this->nativeGraphics,unit));
}

GpStatus GpGraphics_SetPageScale(GP_GRAPHICS * this, REAL scale)
{
	return (this->lastResult = GdipSetPageScale(this->nativeGraphics,scale));
}

GpUnit GpGraphics_GetPageUnit(GP_GRAPHICS * this)
{
	GpUnit unit;
	(this->lastResult = GdipGetPageUnit(this->nativeGraphics, &unit));
	return unit;
}

REAL GpGraphics_GetPageScale(GP_GRAPHICS * this)
{
	REAL scale;
	(this->lastResult = GdipGetPageScale(this->nativeGraphics, &scale));
	return scale;
}

REAL GpGraphics_GetDpiX(GP_GRAPHICS * this)
{
	REAL dpi;
	(this->lastResult = GdipGetDpiX(this->nativeGraphics, &dpi));
	return dpi;
}

REAL GpGraphics_GetDpiY(GP_GRAPHICS * this)
{
	REAL dpi;
	(this->lastResult = GdipGetDpiY(this->nativeGraphics, &dpi));
	return dpi;
}

GpStatus GpGraphics_TransformPointsF(GP_GRAPHICS * this, GpCoordinateSpace destSpace, GpCoordinateSpace srcSpace, POINTF * pts, INT count)
{
	return (this->lastResult = GdipTransformPoints(this->nativeGraphics, destSpace, srcSpace, pts, count));
}

GpStatus GpGraphics_TransformPointsI(GP_GRAPHICS * this, GpCoordinateSpace destSpace, GpCoordinateSpace srcSpace, POINTI * pts,INT count)
{
	return (this->lastResult = GdipTransformPointsI(this->nativeGraphics,destSpace,srcSpace,pts,count));
}

//------------------------------------------------------------------------
// GetNearestColor (for <= 8bpp surfaces).  Note: Alpha is ignored.
//------------------------------------------------------------------------
GpStatus GpGraphics_GetNearestColor(GP_GRAPHICS * this, COLOR * color)
{
	if (color == NULL)
	{
		return (this->lastResult = eInvalidParameter);
	}

	ARGB argb = GpColor_GetValue(color);
	GpStatus status = (this->lastResult = GdipGetNearestColor(this->nativeGraphics, &argb));
	GpColor_SetValue(color, argb);
	return status;
}

GpStatus GpGraphics_DrawLineI(GP_GRAPHICS * this, const GP_PEN* pen,INT x1,INT y1,INT x2,INT y2)
{
	return (this->lastResult = GdipDrawLineI(this->nativeGraphics, pen->nativePen, x1, y1, x2, y2));
}

GpStatus GpGraphics_DrawLinePtI(GP_GRAPHICS * this, const GP_PEN* pen,const POINTI * pt1,const POINTI * pt2)
{
	return GdipDrawLineI(this->nativeGraphics, pen->nativePen, pt1->X, pt1->Y, pt2->X, pt2->Y);
}

GpStatus GpGraphics_DrawLinesPtF(GP_GRAPHICS * this, const GP_PEN* pen, const POINTF * points, INT count)
{
	return (this->lastResult = GdipDrawLines(this->nativeGraphics, pen->nativePen,points, count));
}

GpStatus GpGraphics_DrawLinesPtI(GP_GRAPHICS * this, const GP_PEN* pen, const POINTI * points, INT count)
{
	return (this->lastResult = GdipDrawLinesI(this->nativeGraphics,pen->nativePen, points, count));
}

GpStatus GpGraphics_DrawArcF(GP_GRAPHICS * this, const GP_PEN* pen, REAL x, REAL y, REAL width, REAL height, REAL startAngle, REAL sweepAngle)
{
	return (this->lastResult = GdipDrawArc(this->nativeGraphics, pen->nativePen, x, y, width, height, startAngle, sweepAngle));
}

GpStatus GpGraphics_DrawArcRcF(GP_GRAPHICS * this, const GP_PEN* pen, const RECTF * rect, REAL startAngle, REAL sweepAngle)
{
	return (this->lastResult = GdipDrawArc(this->nativeGraphics, pen->nativePen, rect->X, rect->Y, rect->Width, rect->Height, startAngle, sweepAngle));
}

GpStatus GpGraphics_DrawArcI(GP_GRAPHICS * this, const GP_PEN* pen, INT x, INT y, INT width, INT height, REAL startAngle, REAL sweepAngle)
{
	return (this->lastResult = GdipDrawArcI(this->nativeGraphics, pen->nativePen, x, y, width, height, startAngle, sweepAngle));
}

GpStatus GpGraphics_DrawArcRcI(GP_GRAPHICS * this, const GP_PEN* pen, const RECTI * rect,REAL startAngle,REAL sweepAngle)
{
	return (this->lastResult = GdipDrawArcI(this->nativeGraphics, pen->nativePen,rect->X,rect->Y,rect->Width,rect->Height,startAngle,sweepAngle));
}

GpStatus GpGraphics_DrawBezierF(GP_GRAPHICS * this, const GP_PEN* pen,REAL x1,REAL y1,REAL x2,REAL y2,REAL x3,REAL y3,REAL x4,REAL y4)
{
	return (this->lastResult = GdipDrawBezier(this->nativeGraphics,pen->nativePen,x1,y1,x2,y2,x3,y3,x4,y4));
}

GpStatus GpGraphics_DrawBezierPtF(GP_GRAPHICS * this, const GP_PEN* pen, const POINTF * pt1, const POINTF * pt2, const POINTF * pt3, const POINTF * pt4)
{
	return (this->lastResult = GdipDrawBezier(this->nativeGraphics,pen->nativePen,pt1->X,pt1->Y,pt2->X,pt2->Y,pt3->X,pt3->Y,pt4->X,pt4->Y));
}

GpStatus GpGraphics_DrawBeziersPtF(GP_GRAPHICS * this, const GP_PEN* pen, const POINTF * points, INT count)
{
	return (this->lastResult = GdipDrawBeziers(this->nativeGraphics, pen->nativePen, points, count));
}

GpStatus GpGraphics_DrawBezierI(GP_GRAPHICS * this, const GP_PEN* pen, INT x1,INT y1,INT x2,INT y2,INT x3,INT y3,INT x4,INT y4)
{
	return (this->lastResult = GdipDrawBezierI(this->nativeGraphics,pen->nativePen,x1,y1,x2,y2,x3,y3,x4,y4));
}

GpStatus GpGraphics_DrawBezierPtI(GP_GRAPHICS * this, const GP_PEN* pen,const POINTI * pt1,const POINTI * pt2,const POINTI * pt3,const POINTI * pt4)
{
	return (this->lastResult = GdipDrawBezierI(this->nativeGraphics,pen->nativePen,pt1->X,pt1->Y,pt2->X,pt2->Y,pt3->X,pt3->Y,pt4->X,pt4->Y));
}

GpStatus GpGraphics_DrawBeziers(GP_GRAPHICS * this, const GP_PEN* pen, const POINTI * points, INT count)
{
	return (this->lastResult = GdipDrawBeziersI(this->nativeGraphics,pen->nativePen,points,count));
}

GpStatus GpGraphics_DrawRectangleRcF(GP_GRAPHICS * this, const GP_PEN* pen, const RECTF * rect)
{
	return (this->lastResult = GdipDrawRectangle(this->nativeGraphics,pen->nativePen, rect->X, rect->Y, rect->Width, rect->Height));
}

GpStatus GpGraphics_DrawRectangleF(GP_GRAPHICS * this, const GP_PEN* pen, REAL x, REAL y, REAL width, REAL height)
{
	return (this->lastResult = GdipDrawRectangle(this->nativeGraphics, pen->nativePen, x, y, width, height));
}

GpStatus GpGraphics_DrawRectangles(GP_GRAPHICS * this, const GP_PEN* pen,const RECTF * rects,INT count)
{
	return (this->lastResult = GdipDrawRectangles(this->nativeGraphics,pen->nativePen,rects, count));
}

GpStatus GpGraphics_DrawRectangleRcI(GP_GRAPHICS * this, const GP_PEN* pen, const RECTI * rect)
{
	return (this->lastResult = GdipDrawRectangleI(this->nativeGraphics,pen->nativePen, rect->X, rect->Y, rect->Width, rect->Height));
}

GpStatus GpGraphics_DrawRectangleI(GP_GRAPHICS * this, const GP_PEN* pen, INT x, INT y, INT width, INT height)
{
	return (this->lastResult = GdipDrawRectangleI(this->nativeGraphics,pen->nativePen,x,y,width,height));
}

GpStatus GpGraphics_DrawRectanglesRcI(GP_GRAPHICS * this, const GP_PEN* pen,const RECTI * rects, INT count)
{
	return (this->lastResult = GdipDrawRectanglesI(this->nativeGraphics, pen->nativePen, rects, count));
}

GpStatus GpGraphics_DrawEllipseRcF(GP_GRAPHICS * this, const GP_PEN* pen, const RECTF * rect)
{
	return (this->lastResult = GdipDrawEllipse(this->nativeGraphics, pen->nativePen, rect->X, rect->Y, rect->Width, rect->Height));
}

GpStatus GpGraphics_DrawEllipseF(GP_GRAPHICS * this, const GP_PEN* pen, REAL x, REAL y, REAL width, REAL height)
{
	return (this->lastResult = GdipDrawEllipse(this->nativeGraphics, pen->nativePen, x, y, width, height));
}

GpStatus GpGraphics_DrawEllipseRcI(GP_GRAPHICS * this, const GP_PEN* pen, const RECTI * rect)
{
	return (this->lastResult = GdipDrawEllipseI(this->nativeGraphics,pen->nativePen, rect->X, rect->Y, rect->Width, rect->Height));
}

GpStatus GpGraphics_DrawEllipseI(GP_GRAPHICS * this, const GP_PEN* pen, INT x, INT y, INT width, INT height)
{
	return (this->lastResult = GdipDrawEllipseI(this->nativeGraphics,pen->nativePen,x,y,width,height));
}

GpStatus GpGraphics_DrawPieRcF(GP_GRAPHICS * this, const GP_PEN* pen, const RECTF * rect, REAL startAngle, REAL sweepAngle)
{
	return (this->lastResult = GdipDrawPie(this->nativeGraphics, pen->nativePen, rect->X, rect->Y, rect->Width, rect->Height, startAngle, sweepAngle));
}

GpStatus GpGraphics_DrawPieF(GP_GRAPHICS * this, const GP_PEN* pen, REAL x, REAL y, REAL width, REAL height, REAL startAngle, REAL sweepAngle)
{
	return (this->lastResult = GdipDrawPie(this->nativeGraphics, pen->nativePen, x, y, width, height, startAngle, sweepAngle));
}

GpStatus GpGraphics_DrawPieRcI(GP_GRAPHICS * this, const GP_PEN* pen, const RECTI * rect, REAL startAngle, REAL sweepAngle)
{
	return (this->lastResult = GdipDrawPieI(this->nativeGraphics, pen->nativePen, rect->X, rect->Y, rect->Width, rect->Height, startAngle, sweepAngle));
}

GpStatus GpGraphics_DrawPieI(GP_GRAPHICS * this, const GP_PEN* pen, INT x, INT y, INT width, INT height, REAL startAngle, REAL sweepAngle)
{
	return (this->lastResult = GdipDrawPieI(this->nativeGraphics,pen->nativePen,x,y,width,height,startAngle,sweepAngle));
}

GpStatus GpGraphics_DrawPolygonRcF(GP_GRAPHICS * this, const GP_PEN* pen, const POINTF * points, INT count)
{
	return (this->lastResult = GdipDrawPolygon(this->nativeGraphics, pen->nativePen, points, count));
}

GpStatus GpGraphics_DrawPolygonRcI(GP_GRAPHICS * this, const GP_PEN* pen, const POINTI * points, INT count)
{
	return (this->lastResult = GdipDrawPolygonI(this->nativeGraphics,pen->nativePen,points,count));
}

GpStatus GpGraphics_DrawPath(GP_GRAPHICS * this, const GP_PEN* pen, const GP_GRAPHICSPATH * path)
{
	return (this->lastResult = GdipDrawPath(this->nativeGraphics, pen ? pen->nativePen : NULL, path ? path->nativePath : NULL));
}

GpStatus GpGraphics_DrawCurvePtF(GP_GRAPHICS * this, const GP_PEN* pen, const POINTF * points, INT count)
{
	return (this->lastResult = GdipDrawCurve(this->nativeGraphics, pen->nativePen, points, count));
}

GpStatus GpGraphics_DrawCurve2PtF(GP_GRAPHICS * this, const GP_PEN* pen, const POINTF * points, INT count, REAL tension)
{
	return (this->lastResult = GdipDrawCurve2(this->nativeGraphics,pen->nativePen, points,count, tension));
}

//GpStatus GpGraphics_DrawCurve3PtF(GP_GRAPHICS * this, const GP_PEN* pen, const POINTF * points, INT count, INT offset, INT numberOfSegments, REAL tension = 0.5f);
GpStatus GpGraphics_DrawCurve3PtF(GP_GRAPHICS * this, const GP_PEN* pen, const POINTF * points, INT count, INT offset, INT numberOfSegments, REAL tension)
{
	return (this->lastResult = GdipDrawCurve3(this->nativeGraphics,pen->nativePen, points,count, offset,numberOfSegments, tension));
}

GpStatus GpGraphics_DrawCurvePtI(GP_GRAPHICS * this, const GP_PEN* pen, const POINTI * points, INT count)
{
	return (this->lastResult = GdipDrawCurveI(this->nativeGraphics,pen->nativePen,points,count));
}

GpStatus GpGraphics_DrawCurve2PtI(GP_GRAPHICS * this, const GP_PEN* pen, const POINTI * points, INT count, REAL tension)
{
	return (this->lastResult = GdipDrawCurve2I(this->nativeGraphics, pen->nativePen, points, count, tension));
}

GpStatus GpGraphics_DrawCurve3PtI(GP_GRAPHICS * this, const GP_PEN* pen, const POINTI * points, INT count, INT offset, INT numberOfSegments, REAL tension)
{
	return (this->lastResult = GdipDrawCurve3I(this->nativeGraphics, pen->nativePen, points, count, offset, numberOfSegments, tension));
}

GpStatus GpGraphics_DrawClosedCurvePtF(GP_GRAPHICS * this, const GP_PEN* pen, const POINTF * points, INT count)
{
	return (this->lastResult = GdipDrawClosedCurve(this->nativeGraphics, pen->nativePen, points, count));
}

GpStatus GpGraphics_DrawClosedCurve2PtF(GP_GRAPHICS * this, const GP_PEN *pen, const POINTF * points, INT count, REAL tension)
{
	return (this->lastResult = GdipDrawClosedCurve2(this->nativeGraphics,pen->nativePen,points, count,tension));
}

GpStatus GpGraphics_DrawClosedCurvePtI(GP_GRAPHICS * this, const GP_PEN* pen, const POINTI * points, INT count)
{
	return (this->lastResult = GdipDrawClosedCurveI(this->nativeGraphics,pen->nativePen,points,count));
}

GpStatus GpGraphics_DrawClosedCurve2PtI(GP_GRAPHICS * this, const GP_PEN *pen, const POINTI * points, INT count, REAL tension)
{
	return (this->lastResult = GdipDrawClosedCurve2I(this->nativeGraphics, pen->nativePen, points, count, tension));
}

GpStatus GpGraphics_Clear(GP_GRAPHICS * this, const COLOR * color)
{
	return (this->lastResult = GdipGraphicsClear(this->nativeGraphics, GpColor_GetValue(color)));
}

GpStatus GpGraphics_FillRectangleRcF(GP_GRAPHICS * this, const GP_BRUSH * brush, const RECTF * rect)
{
	return (this->lastResult = GdipFillRectangle(this->nativeGraphics, brush->nativeBrush, rect->X, rect->Y, rect->Width, rect->Height));
}

GpStatus GpGraphics_FillRectangleF(GP_GRAPHICS * this, const GP_BRUSH* brush, REAL x, REAL y, REAL width, REAL height)
{
	return (this->lastResult = GdipFillRectangle(this->nativeGraphics, brush->nativeBrush, x, y, width, height));
}

GpStatus GpGraphics_FillRectanglesRcF(GP_GRAPHICS * this, const GP_BRUSH* brush,const RECTF * rects,INT count)
{
	return (this->lastResult = GdipFillRectangles(this->nativeGraphics,brush->nativeBrush,rects, count));
}

GpStatus GpGraphics_FillRectangleRcI(GP_GRAPHICS * this, const GP_BRUSH* brush, const RECTI * rect)
{
	return (this->lastResult = GdipFillRectangleI(this->nativeGraphics,brush->nativeBrush, rect->X, rect->Y, rect->Width, rect->Height));
}

GpStatus GpGraphics_FillRectangleI(GP_GRAPHICS * this, const GP_BRUSH* brush, INT x, INT y, INT width, INT height)
{
	return (this->lastResult = GdipFillRectangleI(this->nativeGraphics,brush->nativeBrush,x,y,width,height));
}

GpStatus GpGraphics_FillRectanglesRcI(GP_GRAPHICS * this, const GP_BRUSH* brush,const RECTI * rects,INT count)
{
	return (this->lastResult = GdipFillRectanglesI(this->nativeGraphics, brush->nativeBrush, rects, count));
}

GpStatus GpGraphics_FillPolygonPtF(GP_GRAPHICS * this, const GP_BRUSH* brush, const POINTF * points, INT count)
{
	return (this->lastResult = GdipFillPolygon(this->nativeGraphics, brush->nativeBrush, points, count, eFillModeAlternate));
}

GpStatus GpGraphics_FillPolygon1PtF(GP_GRAPHICS * this, const GP_BRUSH* brush, const POINTF * points, INT count, GpFillMode fillMode)
{
	return (this->lastResult = GdipFillPolygon(this->nativeGraphics, brush->nativeBrush, points, count, fillMode));
}

GpStatus GpGraphics_FillPolygonPtI(GP_GRAPHICS * this, const GP_BRUSH* brush, const POINTI * points, INT count)
{
	return (this->lastResult = GdipFillPolygonI(this->nativeGraphics,brush->nativeBrush, points, count, eFillModeAlternate));
}

GpStatus GpGraphics_FillPolygon1PtI(GP_GRAPHICS * this, const GP_BRUSH* brush, const POINTI * points, INT count, GpFillMode fillMode)
{
	return (this->lastResult = GdipFillPolygonI(this->nativeGraphics,brush->nativeBrush,points, count,fillMode));
}

GpStatus GpGraphics_FillEllipseRcF(GP_GRAPHICS * this, const GP_BRUSH* brush, const RECTF * rect)
{
	return (this->lastResult = GdipFillEllipse(this->nativeGraphics, brush->nativeBrush, rect->X, rect->Y, rect->Width, rect->Height));
}

GpStatus GpGraphics_FillEllipseF(GP_GRAPHICS * this, const GP_BRUSH* brush, REAL x, REAL y, REAL width, REAL height)
{
	return (this->lastResult = GdipFillEllipse(this->nativeGraphics, brush->nativeBrush, x, y, width, height));
}

GpStatus GpGraphics_FillEllipseRcI(GP_GRAPHICS * this, const GP_BRUSH* brush, const RECTI * rect)
{
	return (this->lastResult = GdipFillEllipseI(this->nativeGraphics, brush->nativeBrush, rect->X, rect->Y, rect->Width, rect->Height));
}

GpStatus GpGraphics_FillEllipseI(GP_GRAPHICS * this, const GP_BRUSH* brush, INT x, INT y, INT width, INT height)
{
	return (this->lastResult = GdipFillEllipseI(this->nativeGraphics,brush->nativeBrush,x,y,width,height));
}

GpStatus GpGraphics_FillPieRcF(GP_GRAPHICS * this, const GP_BRUSH* brush, const RECTF * rect, REAL startAngle, REAL sweepAngle)
{
	return (this->lastResult = GdipFillPie(this->nativeGraphics, brush->nativeBrush, rect->X, rect->Y, rect->Width, rect->Height, startAngle, sweepAngle));
}

GpStatus GpGraphics_FillPieF(GP_GRAPHICS * this, const GP_BRUSH* brush, REAL x, REAL y, REAL width, REAL height, REAL startAngle, REAL sweepAngle)
{
	return (this->lastResult = GdipFillPie(this->nativeGraphics, brush->nativeBrush, x, y, width, height, startAngle, sweepAngle));
}

GpStatus GpGraphics_FillPieRcI(GP_GRAPHICS * this, const GP_BRUSH* brush, const RECTI * rect, REAL startAngle, REAL sweepAngle)
{
	return (this->lastResult = GdipFillPieI(this->nativeGraphics,brush->nativeBrush, rect->X, rect->Y, rect->Width, rect->Height, startAngle, sweepAngle));
}

GpStatus GpGraphics_FillPieI(GP_GRAPHICS * this, const GP_BRUSH* brush, INT x, INT y, INT width, INT height, REAL startAngle, REAL sweepAngle)
{
	return (this->lastResult = GdipFillPieI(this->nativeGraphics,brush->nativeBrush,x,y,width,height,startAngle,sweepAngle));
}

GpStatus GpGraphics_FillPath(GP_GRAPHICS * this, const GP_BRUSH * brush, const GP_GRAPHICSPATH * path)
{
	return (this->lastResult = GdipFillPath(this->nativeGraphics,brush->nativeBrush,path->nativePath));
}

GpStatus GpGraphics_FillClosedCurve(GP_GRAPHICS * this, const GP_BRUSH* brush, const POINTF * points, INT count)
{
	return (this->lastResult = GdipFillClosedCurve(this->nativeGraphics, brush->nativeBrush, points, count));
}

GpStatus GpGraphics_FillClosedCurve2PtF(GP_GRAPHICS * this, const GP_BRUSH* brush, const POINTF * points, INT count, GpFillMode fillMode, REAL tension)
{
	return (this->lastResult = GdipFillClosedCurve2(this->nativeGraphics,brush->nativeBrush,points, count,tension, fillMode));
}

GpStatus GpGraphics_FillClosedCurvePtI(GP_GRAPHICS * this, const GP_BRUSH* brush, const POINTI * points, INT count)
{
	return (this->lastResult = GdipFillClosedCurveI(this->nativeGraphics,brush->nativeBrush,points,count));
}

GpStatus GpGraphics_FillClosedCurve2PtI(GP_GRAPHICS * this, const GP_BRUSH* brush, const POINTI * points, INT count, GpFillMode fillMode, REAL tension)
{
	return (this->lastResult = GdipFillClosedCurve2I(this->nativeGraphics, brush->nativeBrush, points, count, tension, fillMode));
}

GpStatus GpGraphics_FillRegion(GP_GRAPHICS * this, const GP_BRUSH* brush,const GP_REGION * region)
{
	return (this->lastResult = GdipFillRegion(this->nativeGraphics,brush->nativeBrush,region->nativeRegion));
}

GpStatus GpGraphics_DrawStringRcF(GP_GRAPHICS * this, const WCHAR * string,
	INT length, const GP_FONT * font, const RECTF * layoutRect,
	const GP_STRINGFORMAT * stringFormat, const GP_BRUSH * brush)
{
	return (this->lastResult = GdipDrawString(this->nativeGraphics,string,
		length,font ? font->nativeFont : NULL,
		layoutRect,
		stringFormat ? stringFormat->nativeFormat : NULL,
		brush ? brush->nativeBrush : NULL));
}

GpStatus GpGraphics_DrawStringPtF(GP_GRAPHICS * this, const WCHAR * string,
	INT length, const GP_FONT *font, const POINTF * origin,
	const GP_BRUSH * brush)
{
	RECTF rect;
	GpRectF_Set(&rect, origin->X, origin->Y, 0.0f, 0.0f);
	return (this->lastResult = GdipDrawString(this->nativeGraphics,string,length,font ? font->nativeFont : NULL,&rect,NULL,brush ? brush->nativeBrush : NULL));
}

GpStatus GpGraphics_DrawString(GP_GRAPHICS * this, const WCHAR * string,
	INT length, const GP_FONT *font, const POINTF * origin,
	const GP_STRINGFORMAT * stringFormat, const GP_BRUSH * brush)
{
	RECTF rect;
	GpRectF_Set(&rect, origin->X, origin->Y, 0.0f, 0.0f);
	return (this->lastResult = GdipDrawString(this->nativeGraphics,string,length,font ? font->nativeFont : NULL,&rect,stringFormat ? stringFormat->nativeFormat : NULL,brush ? brush->nativeBrush : NULL));
}

//GpStatus GpGraphics_MeasureString(GP_GRAPHICS * this, const WCHAR*string,INT length,const GP_FONT *font, const RECTF *layoutRect, const GP_STRINGFORMAT *stringFormat, RECTF *boundingBox, INT *codepointsFitted = 0,INT *linesFilled= 0);
GpStatus GpGraphics_MeasureString(GP_GRAPHICS * this, const WCHAR * string, INT length, const GP_FONT * font, const RECTF *layoutRect, const GP_STRINGFORMAT *stringFormat, RECTF * boundingBox, INT *codepointsFitted, INT *linesFilled)
{
	return (this->lastResult = GdipMeasureString(this->nativeGraphics,string,length,font ? font->nativeFont : NULL, layoutRect, stringFormat ? stringFormat->nativeFormat : NULL, boundingBox, codepointsFitted, linesFilled));
}

//GpStatus GpGraphics_MeasureString(GP_GRAPHICS * this, const WCHAR * string, INT length, const GP_FONT *font, const SIZEF * layoutRectSize, const GP_STRINGFORMAT *stringFormat, SIZEF *size, INT *codepointsFitted = 0,INT *linesFilled = 0);
GpStatus GpGraphics_MeasureString1(GP_GRAPHICS * this, const WCHAR * string,
	INT length, const GP_FONT *font, const SIZEF * layoutRectSize,
	const GP_STRINGFORMAT *stringFormat, SIZEF *size,
	INT *codepointsFitted,INT *linesFilled)
{
	RECTF layoutRect = GpRectF(0, 0, layoutRectSize->Width, layoutRectSize->Height);
	RECTF boundingBox;
	GpStatus status;
	if (size == NULL)
	{
		return (this->lastResult = eInvalidParameter);
	}

	status = (this->lastResult = GdipMeasureString(this->nativeGraphics,string,length,font ? font->nativeFont : NULL, &layoutRect, stringFormat ? stringFormat->nativeFormat : NULL,size ? &boundingBox : NULL,codepointsFitted,linesFilled));

	if (size && status == eOk)
	{
		size->Width= boundingBox.Width;
		size->Height = boundingBox.Height;
	}

	return status;
}

GpStatus GpGraphics_MeasureString2(GP_GRAPHICS * this, const WCHAR * string,
	INT length, const GP_FONT *font, const POINTF * origin,
	const GP_STRINGFORMAT *stringFormat, RECTF *boundingBox)
{
	RECTF rect = GpRectF(origin->X, origin->Y, 0.0f, 0.0f);
	return (this->lastResult = GdipMeasureString(this->nativeGraphics,string,length,font ? font->nativeFont : NULL,&rect,stringFormat ? stringFormat->nativeFormat : NULL,boundingBox,NULL,NULL));
}

GpStatus GpGraphics_MeasureString3(GP_GRAPHICS * this, const WCHAR * string,
	INT length, const GP_FONT *font, const RECTF *layoutRect,
	RECTF *boundingBox)
{
	return (this->lastResult = GdipMeasureString(this->nativeGraphics,string,length,font ? font->nativeFont : NULL, layoutRect, NULL, boundingBox, NULL, NULL));
}

GpStatus GpGraphics_MeasureString4(GP_GRAPHICS * this, const WCHAR * string,
	INT length, const GP_FONT *font, const POINTF *origin, RECTF *boundingBox)
{
	RECTF rect = GpRectF(origin->X, origin->Y, 0.0f, 0.0f);
	return (this->lastResult = GdipMeasureString(this->nativeGraphics,string,length,font ? font->nativeFont : NULL,&rect,NULL,boundingBox,NULL,NULL));
}

GpStatus GpGraphics_MeasureCharacterRanges(GP_GRAPHICS * this,
	const WCHAR * string, INT length, const GP_FONT *font,
	const RECTF *layoutRect, const GP_STRINGFORMAT *stringFormat,
	INT regionCount, GP_REGION * regions)
{
	if (!regions || regionCount <= 0)
	{
		return eInvalidParameter;
	}

	GP_GPREGION ** nativeRegions = GpAlloc(sizeof(GP_GPREGION) * regionCount);

	if (!nativeRegions)
	{
		return eOutOfMemory;
	}

	for (INT i = 0; i < regionCount; i++)
	{
		nativeRegions[i] = regions[i].nativeRegion;
	}

	(this->lastResult =	GdipMeasureCharacterRanges(this->nativeGraphics,
			string, length, font ? font->nativeFont : NULL, layoutRect, 
			stringFormat ? stringFormat->nativeFormat : NULL, regionCount, 
			nativeRegions));

	GpFree(nativeRegions);

	return this->lastResult;
}

GpStatus GpGraphics_DrawDriverString(GP_GRAPHICS * this, const UINT16 * text,
	INT length, const GP_FONT * font, const GP_BRUSH * brush,
	const POINTF * positions, INT flags, const GP_MATRIX * matrix)
{
	return (this->lastResult = GdipDrawDriverString(this->nativeGraphics,text,length,font ? font->nativeFont : NULL,brush ? brush->nativeBrush : NULL,positions,flags,matrix ? matrix->nativeMatrix : NULL));
}

GpStatus GpGraphics_MeasureDriverString(GP_GRAPHICS * this,
	const UINT16 * text, INT length, const GP_FONT * font,
	const POINTF * positions, INT flags, const GP_MATRIX * matrix,
	RECTF * boundingBox)
{
	return (this->lastResult = GdipMeasureDriverString(this->nativeGraphics,text,length,font ? font->nativeFont : NULL,positions,flags,matrix ? matrix->nativeMatrix : NULL,boundingBox));
}

// Draw a cached bitmap on this graphics destination offset by
// x, y. Note this will fail with eWrongState if the CachedBitmap
// native format differs from this Graphics.
GpStatus GpGraphics_DrawCachedBitmap(GP_GRAPHICS * this, GP_CACHEDBITMAP * cb, INT x, INT y)
{
	return (this->lastResult = GdipDrawCachedBitmap(this->nativeGraphics, cb->nativeCachedBitmap, x, y));
}
// 1
GpStatus GpGraphics_DrawImagePtF(GP_GRAPHICS * this, GP_IMAGE * image, const POINTF * point)
{
	return (this->lastResult = GdipDrawImage(this->nativeGraphics, image->nativeImage, point->X, point->Y));
}
// 2
GpStatus GpGraphics_DrawImage2F(GP_GRAPHICS * this, GP_IMAGE * image, REAL x, REAL y)
{
	return (this->lastResult = GdipDrawImage(this->nativeGraphics,
			image ? image->nativeImage : NULL, x, y));
}
// 3
GpStatus GpGraphics_DrawImageRcF(GP_GRAPHICS * this, GP_IMAGE * image, const RECTF * rect)
{
	return (this->lastResult = GdipDrawImageRect(this->nativeGraphics,
			image->nativeImage, rect->X, rect->Y, rect->Width, rect->Height));
}
// 4
GpStatus GpGraphics_DrawImage4F(GP_GRAPHICS * this, GP_IMAGE * image, REAL x, REAL y, REAL width, REAL height)
{
	return (this->lastResult = GdipDrawImageRect(this->nativeGraphics, image ? image->nativeImage : NULL, x, y, width, height));
}
// 5
GpStatus GpGraphics_DrawImagePtI(GP_GRAPHICS * this, GP_IMAGE * image, const POINTI * point)
{
	return (this->lastResult = GdipDrawImageI(this->nativeGraphics, image->nativeImage, point->X, point->Y));
}
// 6
GpStatus GpGraphics_DrawImage2I(GP_GRAPHICS * this, GP_IMAGE * image, INT x, INT y)
{
	return (this->lastResult = GdipDrawImageI(this->nativeGraphics,image ? image->nativeImage: NULL, x, y));
}
// 7
GpStatus GpGraphics_DrawImageRcI(GP_GRAPHICS * this, GP_IMAGE * image, const RECTI * rect)
{
	return (this->lastResult = GdipDrawImageRectI(this->nativeGraphics, image ? image->nativeImage: NULL, rect->X, rect->Y, rect->Width, rect->Height));
}
// 8
GpStatus GpGraphics_DrawImage4I(GP_GRAPHICS * this, GP_IMAGE * image, INT x, INT y, INT width, INT height)
{
	return (this->lastResult = GdipDrawImageRectI(this->nativeGraphics,image ? image->nativeImage: NULL,x,y,width,height));
}

// Affine Draw Image
// destPoints.length = 3: rect => parallelogram
// destPoints[0] <=> top-left corner of the source rectangle
// destPoints[1] <=> top-right corner
// destPoints[2] <=> bottom-left corner
// destPoints.length = 4: rect => quad
// destPoints[3] <=> bottom-right corner

// 9
GpStatus GpGraphics_DrawImagePtsF(GP_GRAPHICS * this, GP_IMAGE * image, const POINTF * destPoints, INT count)
{
	if (count != 3 && count != 4)
		return (this->lastResult = eInvalidParameter);

	return (this->lastResult = GdipDrawImagePoints(this->nativeGraphics, image ? image->nativeImage : NULL, destPoints, count));
}

// 10
GpStatus GpGraphics_DrawImagePtsI(GP_GRAPHICS * this, GP_IMAGE * image, const POINTI * destPoints, INT count)
{
	if (count != 3 && count != 4)
		return (this->lastResult = eInvalidParameter);

	return (this->lastResult = GdipDrawImagePointsI(this->nativeGraphics,image ? image->nativeImage: NULL,destPoints,count));
}

// 11
GpStatus GpGraphics_DrawImagePtRcF(GP_GRAPHICS * this, GP_IMAGE * image, REAL x, REAL y, REAL srcx, REAL srcy, REAL srcwidth, REAL srcheight, GpUnit srcUnit)
{
	return (this->lastResult = GdipDrawImagePointRect(this->nativeGraphics,image ? image->nativeImage: NULL,x, y,srcx, srcy,srcwidth, srcheight, srcUnit));
}

// 12
//GpStatus GpGraphics_DrawImageRcRcF(GP_GRAPHICS * this, GP_IMAGE * image, const RECTF * destRect, REAL srcx, REAL srcy, REAL srcwidth, REAL srcheight, Unit srcUnit, const GP_IMAGEATTRIBUTES* imageAttributes = NULL, DrawImageAbort callback = NULL, VOID* callbackData = NULL);
GpStatus GpGraphics_DrawImageRcRcF(GP_GRAPHICS * this, GP_IMAGE * image,
	const RECTF * destRect, REAL srcx, REAL srcy, REAL srcwidth,
	REAL srcheight, GpUnit srcUnit, const GP_IMAGEATTRIBUTES * imageAttributes,
	DrawImageAbort callback, VOID* callbackData)
{
	return (this->lastResult = GdipDrawImageRectRect(this->nativeGraphics, image ? image->nativeImage : NULL,
		destRect->X, destRect->Y, destRect->Width, destRect->Height, srcx, srcy, srcwidth, srcheight,
 		srcUnit, imageAttributes? imageAttributes->nativeImageAttr: NULL, callback, callbackData));
}

// 13
//GpStatus GpGraphics_DrawImagePtsRcF(GP_GRAPHICS * this, GP_IMAGE * image, const POINTF * destPoints, INT count, REAL srcx, REAL srcy, REAL srcwidth, REAL srcheight, GpUnit srcUnit, const GP_IMAGEATTRIBUTES * imageAttributes = NULL, DrawImageAbort callback = NULL, VOID * callbackData = NULL);
GpStatus GpGraphics_DrawImagePtsRcF(GP_GRAPHICS * this, GP_IMAGE * image, const POINTF * destPoints, INT count, REAL srcx, REAL srcy, REAL srcwidth,
		REAL srcheight, GpUnit srcUnit,
		const GP_IMAGEATTRIBUTES * imageAttributes,
		DrawImageAbort callback, VOID * callbackData)
{
	return (this->lastResult = GdipDrawImagePointsRect(this->nativeGraphics, image ? image->nativeImage : NULL,
 			destPoints, count, srcx, srcy, srcwidth, srcheight, srcUnit, imageAttributes? imageAttributes->nativeImageAttr: NULL,
 			callback, callbackData));
}

// 14
GpStatus GpGraphics_DrawImagePtRcI(GP_GRAPHICS * this, GP_IMAGE * image, INT x, INT y, INT srcx, INT srcy, INT srcwidth, INT srcheight, GpUnit srcUnit)
{
	return (this->lastResult = GdipDrawImagePointRectI(this->nativeGraphics, image ? image->nativeImage : NULL,
		 x, y, srcx, srcy, srcwidth, srcheight, srcUnit));
}

// 15
GpStatus GpGraphics_DrawImageRcRcI(GP_GRAPHICS * this, GP_IMAGE * image, const RECTI * destRect, INT srcx, INT srcy, INT srcwidth, INT srcheight,
		 GpUnit srcUnit, const GP_IMAGEATTRIBUTES * imageAttributes, DrawImageAbort callback, VOID* callbackData)
{
	return (this->lastResult = GdipDrawImageRectRectI(this->nativeGraphics,image ? image->nativeImage: NULL,
		destRect->X,destRect->Y,destRect->Width,destRect->Height,srcx,srcy,srcwidth,srcheight,
		srcUnit,imageAttributes? imageAttributes->nativeImageAttr: NULL,callback,callbackData));
}

// 16
GpStatus GpGraphics_DrawImagePtsRcI(GP_GRAPHICS * this, GP_IMAGE * image,
	const POINTI * destPoints, INT count, INT srcx, INT srcy,
	INT srcwidth, INT srcheight, GpUnit srcUnit, const GP_IMAGEATTRIBUTES * imageAttributes,
	DrawImageAbort callback, VOID* callbackData)
{
	return (this->lastResult = GdipDrawImagePointsRectI(this->nativeGraphics,image ? image->nativeImage: NULL,
			destPoints,count,srcx,srcy,srcwidth,srcheight,srcUnit,imageAttributes ? imageAttributes->nativeImageAttr : NULL,
			callback,callbackData));
}

// The following methods are for playing an EMF+ to a graphics
// via the enumeration interface.Each record of the EMF+ is
// sent to the callback (along with the callbackData).Then
// the callback can invoke the Metafile::PlayRecord method
// to play the particular record.
GpStatus GpGraphics_EnumerateMetafilePtF(GP_GRAPHICS * this,
	const GP_METAFILE * metafile, const POINTF *destPoint,
	EnumerateMetafileProc callback, VOID *callbackData,
	const GP_IMAGEATTRIBUTES * imageAttributes)
{
	return (this->lastResult = GdipEnumerateMetafileDestPoint(this->nativeGraphics,
		metafile ? metafile->nativeImage: NULL, destPoint, callback, 
		callbackData, imageAttributes ? imageAttributes->nativeImageAttr : NULL));
}

GpStatus GpGraphics_EnumerateMetafilePtI(GP_GRAPHICS * this,
	const GP_METAFILE *metafile, const POINTI * destPoint,
	EnumerateMetafileProc callback,	VOID *callbackData,
	const GP_IMAGEATTRIBUTES * imageAttributes)
{
	return (this->lastResult = GdipEnumerateMetafileDestPointI(this->nativeGraphics,
			metafile ? metafile->nativeImage:NULL, destPoint, callback,
			callbackData, imageAttributes ? imageAttributes->nativeImageAttr : NULL));
}

GpStatus GpGraphics_EnumerateMetafileRcF(GP_GRAPHICS * this,
		const GP_METAFILE * metafile, const RECTF * destRect,
		EnumerateMetafileProc callback, VOID *callbackData,
		const GP_IMAGEATTRIBUTES * imageAttributes)
{
	return (this->lastResult = GdipEnumerateMetafileDestRect(this->nativeGraphics,
			metafile ? metafile->nativeImage:NULL, destRect, callback,
			callbackData, imageAttributes ? imageAttributes->nativeImageAttr : NULL));
}

GpStatus GpGraphics_EnumerateMetafileRcI(GP_GRAPHICS * this,
		const GP_METAFILE *metafile, const RECTI * destRect,
		EnumerateMetafileProc callback, VOID *callbackData,
		const GP_IMAGEATTRIBUTES * imageAttributes)
{
	return (this->lastResult = GdipEnumerateMetafileDestRectI(this->nativeGraphics,
			metafile ? metafile->nativeImage:NULL, destRect, callback,
			callbackData, imageAttributes ? imageAttributes->nativeImageAttr : NULL));
}

GpStatus GpGraphics_EnumerateMetafilePtsF(GP_GRAPHICS * this,
		const GP_METAFILE *metafile, const POINTF * destPoints, INT count,
		EnumerateMetafileProc callback, VOID *callbackData,
		const GP_IMAGEATTRIBUTES * imageAttributes)
{
	return (this->lastResult = GdipEnumerateMetafileDestPoints(this->nativeGraphics,
			metafile ? metafile->nativeImage:NULL, destPoints, count,
			callback, callbackData,
			imageAttributes ? imageAttributes->nativeImageAttr : NULL));
}

GpStatus GpGraphics_EnumerateMetafilePtsI(GP_GRAPHICS * this,
	const GP_METAFILE *metafile, const POINTI * destPoints, INT count,
	EnumerateMetafileProc callback, VOID *callbackData,
	const GP_IMAGEATTRIBUTES * imageAttributes)
{
	return (this->lastResult = GdipEnumerateMetafileDestPointsI(this->nativeGraphics,
			metafile ? metafile->nativeImage:NULL, destPoints, count,
			callback, callbackData, imageAttributes ? imageAttributes->nativeImageAttr : NULL));
}

GpStatus GpGraphics_EnumerateMetafileRcPtF(GP_GRAPHICS * this,
	const GP_METAFILE *metafile, const POINTF *destPoint,
	const RECTF * srcRect, GpUnit srcUnit, EnumerateMetafileProc callback,
	VOID *callbackData, const GP_IMAGEATTRIBUTES * imageAttributes)
{
	return (this->lastResult = GdipEnumerateMetafileSrcRectDestPoint(this->nativeGraphics,
			metafile ? metafile->nativeImage:NULL, destPoint, srcRect,
			srcUnit, callback, callbackData,
			imageAttributes ? imageAttributes->nativeImageAttr : NULL));
}

GpStatus GpGraphics_EnumerateMetafileRcPtI(GP_GRAPHICS * this,
	const GP_METAFILE *metafile, const POINTI * destPoint,
	const RECTI * srcRect, GpUnit srcUnit, EnumerateMetafileProc callback,
	VOID *callbackData, const GP_IMAGEATTRIBUTES * imageAttributes)
{
	return (this->lastResult = GdipEnumerateMetafileSrcRectDestPointI(this->nativeGraphics,
		metafile ? metafile->nativeImage:NULL, destPoint, srcRect, srcUnit,
		callback, callbackData, imageAttributes ? imageAttributes->nativeImageAttr : NULL));
}

GpStatus GpGraphics_EnumerateMetafileRcRcF(GP_GRAPHICS * this,
	const GP_METAFILE *metafile, const RECTF * destRect,
	const RECTF * srcRect, GpUnit srcUnit, EnumerateMetafileProc callback,
	VOID *callbackData, const GP_IMAGEATTRIBUTES * imageAttributes)
{
	return (this->lastResult = GdipEnumerateMetafileSrcRectDestRect(this->nativeGraphics,
		metafile ? metafile->nativeImage:NULL, destRect, srcRect, srcUnit,
		callback, callbackData, imageAttributes ? imageAttributes->nativeImageAttr : NULL));
}

GpStatus GpGraphics_EnumerateMetafileRcRcI(GP_GRAPHICS * this,
	const GP_METAFILE *metafile, const RECTI * destRect,
	const RECTI * srcRect, GpUnit srcUnit, EnumerateMetafileProc callback,
	VOID *callbackData, const GP_IMAGEATTRIBUTES * imageAttributes)
{
	return (this->lastResult = GdipEnumerateMetafileSrcRectDestRectI(this->nativeGraphics,
		metafile ? metafile->nativeImage:NULL, destRect, srcRect, srcUnit,
		callback, callbackData, imageAttributes ? imageAttributes->nativeImageAttr : NULL));
}

GpStatus GpGraphics_EnumerateMetafileRcPtsF(GP_GRAPHICS * this,
	const GP_METAFILE *metafile, const POINTF * destPoints, INT count,
	const RECTF * srcRect, GpUnit srcUnit, EnumerateMetafileProc callback,
	VOID *callbackData, const GP_IMAGEATTRIBUTES * imageAttributes)
{
	return (this->lastResult = GdipEnumerateMetafileSrcRectDestPoints(this->nativeGraphics,
		metafile ? metafile->nativeImage:NULL, destPoints, count, srcRect,
		srcUnit, callback, callbackData, imageAttributes ? imageAttributes->nativeImageAttr : NULL));
}

GpStatus GpGraphics_EnumerateMetafileRcPtsI(GP_GRAPHICS * this,
	const GP_METAFILE *metafile, const POINTI * destPoints,INT count,
	const RECTI * srcRect, GpUnit srcUnit, EnumerateMetafileProc callback,
	VOID *callbackData, const GP_IMAGEATTRIBUTES * imageAttributes)
{
	return (this->lastResult = GdipEnumerateMetafileSrcRectDestPointsI(this->nativeGraphics,
		metafile ? metafile->nativeImage:NULL, destPoints, count, srcRect,
		srcUnit, callback, callbackData, imageAttributes ? imageAttributes->nativeImageAttr : NULL));
}

GpStatus GpGraphics_SetClip(GP_GRAPHICS * this, const GP_GRAPHICS * g,
	GpCombineMode combineMode)
{
	return (this->lastResult = GdipSetClipGraphics(this->nativeGraphics, g->nativeGraphics, combineMode));
}

GpStatus GpGraphics_SetClipRcF(GP_GRAPHICS * this, const RECTF * rect,
	GpCombineMode combineMode)
{
	return (this->lastResult = GdipSetClipRect(this->nativeGraphics, rect->X, rect->Y, rect->Width, rect->Height, combineMode));
}

GpStatus GpGraphics_SetClipRcI(GP_GRAPHICS * this, const RECTI * rect, GpCombineMode combineMode)
{
	return (this->lastResult = GdipSetClipRectI(this->nativeGraphics,rect->X, rect->Y,rect->Width, rect->Height,combineMode));
}

GpStatus GpGraphics_SetClipPath(GP_GRAPHICS * this, const GP_GRAPHICSPATH * path,
		GpCombineMode combineMode)
{
	return (this->lastResult = GdipSetClipPath(this->nativeGraphics, path->nativePath, combineMode));
}

GpStatus GpGraphics_SetClipRegion(GP_GRAPHICS * this, const GP_REGION* region,
	GpCombineMode combineMode)
{
	return (this->lastResult = GdipSetClipRegion(this->nativeGraphics, region->nativeRegion, combineMode));
}

// This is different than the other SetClip methods because it assumes
// that the HRGN is already in device units, so it doesn't transform
// the coordinates in the HRGN.
GpStatus GpGraphics_SetClipHrgn(GP_GRAPHICS * this, HRGN hRgn, GpCombineMode combineMode)
{
	return (this->lastResult = GdipSetClipHrgn(this->nativeGraphics, hRgn, combineMode));
}

GpStatus GpGraphics_IntersectClipRcF(GP_GRAPHICS * this, const RECTF * rect)
{
	return (this->lastResult = GdipSetClipRect(this->nativeGraphics, rect->X, rect->Y, rect->Width, rect->Height, eCombineModeIntersect));
}

GpStatus GpGraphics_IntersectClipRc(GP_GRAPHICS * this, const RECTI * rect)
{
	return (this->lastResult = GdipSetClipRectI(this->nativeGraphics,rect->X, rect->Y,rect->Width, rect->Height, eCombineModeIntersect));
}

GpStatus GpGraphics_IntersectClipRegion(GP_GRAPHICS * this, const GP_REGION* region)
{
	return (this->lastResult = GdipSetClipRegion(this->nativeGraphics, region->nativeRegion, eCombineModeIntersect));
}

GpStatus  GpGraphics_ExcludeClipRcF(GP_GRAPHICS * this, const RECTF * rect)
{
	return (this->lastResult = GdipSetClipRect(this->nativeGraphics, rect->X, rect->Y, rect->Width, rect->Height, eCombineModeExclude));
}

GpStatus GpGraphics_ExcludeClipRcI(GP_GRAPHICS * this, const RECTI * rect)
{
	return (this->lastResult = GdipSetClipRectI(this->nativeGraphics,rect->X, rect->Y,rect->Width, rect->Height, eCombineModeExclude));
}

GpStatus GpGraphics_ExcludeClipRegion(GP_GRAPHICS * this, const GP_REGION* region)
{
	return (this->lastResult = GdipSetClipRegion(this->nativeGraphics, region->nativeRegion, eCombineModeExclude));
}

GpStatus GpGraphics_ResetClip(GP_GRAPHICS * this)
{
	return (this->lastResult = GdipResetClip(this->nativeGraphics));
}

GpStatus GpGraphics_TranslateClipF(GP_GRAPHICS * this, REAL dx, REAL dy)
{
	return (this->lastResult = GdipTranslateClip(this->nativeGraphics, dx, dy));
}

GpStatus GpGraphics_TranslateClipI(GP_GRAPHICS * this, INT dx, INT dy)
{
	return (this->lastResult = GdipTranslateClipI(this->nativeGraphics,dx, dy));
}

GpStatus GpGraphics_GetClip(GP_GRAPHICS * this, GP_REGION* region)
{
	return (this->lastResult = GdipGetClip(this->nativeGraphics, region->nativeRegion));
}

GpStatus GpGraphics_GetClipBoundsF(GP_GRAPHICS * this, RECTF * rect)
{
	return (this->lastResult = GdipGetClipBounds(this->nativeGraphics, rect));
}

GpStatus GpGraphics_GetClipBoundsI(GP_GRAPHICS * this, RECTI * rect)
{
	return (this->lastResult = GdipGetClipBoundsI(this->nativeGraphics, rect));
}

BOOL GpGraphics_IsClipEmpty(GP_GRAPHICS * this)
{
	BOOL booln = FALSE;
	(this->lastResult = GdipIsClipEmpty(this->nativeGraphics, &booln));
	return booln;
}

GpStatus GpGraphics_GetVisibleClipBoundsF(GP_GRAPHICS * this, RECTF *rect)
{
	return (this->lastResult = GdipGetVisibleClipBounds(this->nativeGraphics,rect));
}

GpStatus GpGraphics_GetVisibleClipBoundsI(GP_GRAPHICS * this, RECTI *rect)
{
	return (this->lastResult = GdipGetVisibleClipBoundsI(this->nativeGraphics,rect));
}

BOOL GpGraphics_IsVisibleClipEmpty(GP_GRAPHICS * this, BOOL booln)
{
	(this->lastResult = GdipIsVisibleClipEmpty(this->nativeGraphics, &booln));
	return booln;
}

BOOL GpGraphics_IsVisibleI(GP_GRAPHICS * this, INT x, INT y)
{
	BOOL booln = FALSE;
	(this->lastResult = GdipIsVisiblePointI(this->nativeGraphics, x, y, &booln));
	return booln;
}

BOOL GpGraphics_IsVisiblePtI(GP_GRAPHICS * this, const POINTI * point)
{
	BOOL booln = FALSE;
	(this->lastResult = GdipIsVisiblePointI(this->nativeGraphics, point->X, point->Y, &booln));
	return booln;
}

BOOL GpGraphics_IsVisible4I(GP_GRAPHICS * this, INT x, INT y, INT width, INT height)
{
	BOOL booln = TRUE;
	(this->lastResult = GdipIsVisibleRectI(this->nativeGraphics, x, y, width, height, &booln));
	return booln;
}

BOOL GpGraphics_IsVisibleRcI(GP_GRAPHICS * this, const RECTI * rect)
{
	BOOL booln = TRUE;
	(this->lastResult = GdipIsVisibleRectI(this->nativeGraphics, rect->X, rect->Y, rect->Width, rect->Height, &booln));
	return booln;
}

BOOL GpGraphics_IsVisibleF(GP_GRAPHICS * this, REAL x, REAL y)
{
	BOOL booln = FALSE;
	(this->lastResult = GdipIsVisiblePoint(this->nativeGraphics, x, y, &booln));
	return booln;
}

BOOL GpGraphics_IsVisiblePtF(GP_GRAPHICS * this, const POINTF * point)
{
	BOOL booln = FALSE;
	(this->lastResult = GdipIsVisiblePoint(this->nativeGraphics, point->X, point->Y, &booln));
	return booln;
}

BOOL GpGraphics_IsVisible4F(GP_GRAPHICS * this, REAL x, REAL y, REAL width, REAL height)
{
	BOOL booln = FALSE;
	(this->lastResult = GdipIsVisibleRect(this->nativeGraphics, x, y, width, height, &booln));
	return booln;
}

BOOL GpGraphics_IsVisibleRcF(GP_GRAPHICS * this, const RECTF * rect)
{
	BOOL booln = TRUE;
	(this->lastResult = GdipIsVisibleRect(this->nativeGraphics,rect->X,rect->Y,rect->Width,rect->Height,&booln));
	return booln;
}

GpGraphicsState GpGraphics_Save(GP_GRAPHICS * this)
{
	GpGraphicsState gstate;
	(this->lastResult = GdipSaveGraphics(this->nativeGraphics, &gstate));
	return gstate;
}

GpStatus GpGraphics_Restore(GP_GRAPHICS * this, GpGraphicsState gstate)
{
	return (this->lastResult = GdipRestoreGraphics(this->nativeGraphics,gstate));
}

GpGraphicsContainer GpGraphics_BeginContainerF(GP_GRAPHICS * this, const RECTF * dstrect, const RECTF * srcrect, GpUnit unit)
{
	GpGraphicsContainer state;
	(this->lastResult = GdipBeginContainer(this->nativeGraphics, dstrect, srcrect, unit, &state));
	return state;
}

GpGraphicsContainer GpGraphics_BeginContainerI(GP_GRAPHICS * this, const RECTI *dstrect,const RECTI * srcrect, GpUnit unit)
{
	GpGraphicsContainer state;
	(this->lastResult = GdipBeginContainerI(this->nativeGraphics, dstrect, srcrect, unit, &state));
	return state;
}

GpGraphicsContainer GpGraphics_BeginContainer(GP_GRAPHICS * this)
{
	GpGraphicsContainer state;
	(this->lastResult = GdipBeginContainer2(this->nativeGraphics, &state));
	return state;
}

GpStatus GpGraphics_EndContainer(GP_GRAPHICS * this, GpGraphicsContainer state)
{
	return (this->lastResult = GdipEndContainer(this->nativeGraphics, state));
}

// Only valid when recording metafiles.
GpStatus GpGraphics_AddMetafileComment(GP_GRAPHICS * this, const BYTE * data, UINT sizeData)
{
	return (this->lastResult = GdipComment(this->nativeGraphics, sizeData, data));
}

HPALETTE GpGraphics_GetHalftonePalette(VOID)
{
	return GdipCreateHalftonePalette();
}

//----------------------------------------------------------------------------
// Implementation of GraphicsPath methods that use Graphics
//----------------------------------------------------------------------------
// The GetBounds rectangle may not be the tightest bounds.
GpStatus GpGraphics_PathGetBoundsRcF(GP_GRAPHICSPATH * this, RECTF * bounds,
	const GP_MATRIX * matrix, const GP_PEN * pen)
{
	GP_GPMATRIX* nativeMatrix = NULL;
	GP_GPPEN * nativePen = NULL;
	if (matrix)
		nativeMatrix = matrix->nativeMatrix;

	if (pen)
		nativePen = pen->nativePen;

	return (this->lastResult = GdipGetPathWorldBounds(this->nativePath,
			bounds, nativeMatrix, nativePen));
}

GpStatus GpGraphics_PathGetBoundsRcI(GP_GRAPHICSPATH * this, RECTI * bounds,
	const GP_MATRIX* matrix, const GP_PEN * pen)
{
	GP_GPMATRIX * nativeMatrix = NULL;
	GP_GPPEN * nativePen = NULL;

	if (matrix)
		nativeMatrix = matrix->nativeMatrix;

	if (pen)
		nativePen = pen->nativePen;

	return (this->lastResult = GdipGetPathWorldBoundsI(this->nativePath,
			bounds,nativeMatrix, nativePen));
}

BOOL GpGraphics_PathIsVisibleF(GP_GRAPHICSPATH * this, REAL x, REAL y,
	const GP_GRAPHICS * g)
{
	BOOL booln = FALSE;
	GP_GPGRAPHICS * nativeGraphics = NULL;
	if (g)
		nativeGraphics = g->nativeGraphics;

	(this->lastResult = GdipIsVisiblePathPoint(this->nativePath, x, y, nativeGraphics, &booln));
 	return booln;
}

BOOL GpGraphics_PathIsVisibleI(GP_GRAPHICSPATH * this, INT x,INT y,
	const GP_GRAPHICS * g)
{
	BOOL booln = FALSE;
	GP_GPGRAPHICS * nativeGraphics = NULL;
	if (g)
		nativeGraphics = g->nativeGraphics;

	(this->lastResult = GdipIsVisiblePathPointI(this->nativePath, x, y, nativeGraphics, &booln));
 	return booln;
}

BOOL GpGraphics_PathIsOutlineVisibleF(GP_GRAPHICSPATH * this, REAL x, REAL y,
	const GP_PEN * pen, const GP_GRAPHICS * g)
{
	BOOL booln = FALSE;

	GP_GPGRAPHICS* nativeGraphics = NULL;
	GP_GPPEN * nativePen = NULL;

	if(g)
		nativeGraphics = g->nativeGraphics;
	if(pen)
		nativePen = pen->nativePen;

	(this->lastResult = GdipIsOutlineVisiblePathPoint(this->nativePath, x, y, nativePen, nativeGraphics,&booln));
	return booln;
}

BOOL GpGraphics_PathIsOutlineVisibleI(GP_GRAPHICSPATH * this, INT x, INT y,
	const GP_PEN * pen, const GP_GRAPHICS * g)
{
	BOOL booln = FALSE;

	GP_GPGRAPHICS* nativeGraphics = NULL;
	GP_GPPEN * nativePen = NULL;

	if(g)
		nativeGraphics = g->nativeGraphics;
	if(pen)
		nativePen = pen->nativePen;

	(this->lastResult = GdipIsOutlineVisiblePathPointI(this->nativePath, x, y, nativePen, nativeGraphics, &booln));
	return booln;
}

