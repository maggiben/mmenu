/**************************************************************************\
*
* All files in GdiPlusLib have been modified from the Microsoft
* GdiPlus C++ header files.
*
* Module Name:
*
*   GdiPlusStringFormat.c
*
* Abstract:
*
*   String format specification for DrawString and text APIs
*
\**************************************************************************/

#include "GdiPlusEnums.h"
#include "GdiPlusStringFormat.h"

//GP_STRINGFORMAT GpStringFormatLANGID(INT formatFlags = 0, LANGID  language = LANG_NEUTRAL)
GP_STRINGFORMAT GpStringFormatLANGID(INT formatFlags, LANGID language)
{
    GP_STRINGFORMAT this;
    this.nativeFormat = NULL;
    this.lastResult = GdipCreateStringFormat(formatFlags, language, &this.nativeFormat);
    return this;
}

// Constructor based on existing string format
GP_STRINGFORMAT GpStringFormat(const GP_STRINGFORMAT *format)
{
    GP_STRINGFORMAT this;
    this.nativeFormat = NULL;
    this.lastResult = GdipCloneStringFormat(format ? format->nativeFormat : NULL,
                            &this.nativeFormat);
    return this;
}

GP_STRINGFORMAT GpStringFormat_Clone(GP_STRINGFORMAT * this)
{
    GP_GPSTRINGFORMAT * clonedStringFormat = NULL;
    this->lastResult = GdipCloneStringFormat(
            this->nativeFormat,
            &clonedStringFormat);

	return GpStringFormat_StringFormat(clonedStringFormat, this->lastResult);
}

VOID GpStringFormat_Delete(GP_STRINGFORMAT * this)
{
    GdipDeleteStringFormat(this->nativeFormat);
}

GpStatus GpStringFormat_SetFormatFlags(GP_STRINGFORMAT * this,INT flags)
{
    return (this->lastResult =
                GdipSetStringFormatFlags(this->nativeFormat, flags));
}

INT GpStringFormat_GetFormatFlags(GP_STRINGFORMAT * this)
{
    INT flags;
    (this->lastResult = GdipGetStringFormatFlags(this->nativeFormat, &flags));
    return flags;
}

GpStatus GpStringFormat_SetAlignment(GP_STRINGFORMAT * this, GpStringAlignment align)
{
    return (this->lastResult = GdipSetStringFormatAlign(this->nativeFormat, align));
}

GpStringAlignment GpStringFormat_GetAlignment(GP_STRINGFORMAT * this)
{
    GpStringAlignment alignment;
    (this->lastResult = GdipGetStringFormatAlign(this->nativeFormat, &alignment));
    return alignment;
}

GpStatus  GpStringFormat_SetLineAlignment(GP_STRINGFORMAT * this, GpStringAlignment align)
{
    return (this->lastResult = GdipSetStringFormatLineAlign(this->nativeFormat,align));
}

GpStringAlignment GpStringFormat_GetLineAlignment(GP_STRINGFORMAT * this)
{
    GpStringAlignment alignment;
    (this->lastResult = GdipGetStringFormatLineAlign(this->nativeFormat, &alignment));
    return alignment;
}

GpStatus GpStringFormat_SetHotkeyPrefix(GP_STRINGFORMAT * this, GpHotkeyPrefix hotkeyPrefix)
{
    return (this->lastResult = GdipSetStringFormatHotkeyPrefix(this->nativeFormat,
                    (INT)hotkeyPrefix));
}

GpHotkeyPrefix GpStringFormat_GetHotkeyPrefix(GP_STRINGFORMAT * this)
{
    GpHotkeyPrefix hotkeyPrefix;
    (this->lastResult = GdipGetStringFormatHotkeyPrefix(this->nativeFormat,
            (INT*)&hotkeyPrefix));
    return hotkeyPrefix;
}

GpStatus GpStringFormat_SetTabStops(GP_STRINGFORMAT * this,
    REAL firstTabOffset, INT count, const REAL *tabStops)
{
    return (this->lastResult = GdipSetStringFormatTabStops(this->nativeFormat,
                    firstTabOffset, count, tabStops));
}

INT GpStringFormat_GetTabStopCount(GP_STRINGFORMAT * this)
{
    INT count;
    (this->lastResult = GdipGetStringFormatTabStopCount(this->nativeFormat,  &count));
    return count;
}

GpStatus GpStringFormat_GetTabStops(GP_STRINGFORMAT * this,
    INT count, REAL *firstTabOffset, REAL *tabStops)
{
    return (this->lastResult = GdipGetStringFormatTabStops(this->nativeFormat,
                    count,firstTabOffset, tabStops));
}

GpStatus GpStringFormat_SetDigitSubstitution(GP_STRINGFORMAT * this,
    LANGID language, GpStringDigitSubstitute substitute)
{
    return (this->lastResult = GdipSetStringFormatDigitSubstitution(this->nativeFormat,
                    language, substitute));
}

LANGID GpStringFormat_GetDigitSubstitutionLanguage(GP_STRINGFORMAT * this)
{
    LANGID language;
    (this->lastResult = GdipGetStringFormatDigitSubstitution(this->nativeFormat,
            &language, NULL));
    return language;
}

GpStringDigitSubstitute GpStringFormat_GetDigitSubstitutionMethod(GP_STRINGFORMAT * this)
{
    GpStringDigitSubstitute substitute;
    (this->lastResult = GdipGetStringFormatDigitSubstitution(this->nativeFormat,
            NULL, &substitute));
    return substitute;
}

// String trimming. How to handle more text than can be displayed
// in the limits available.
GpStatus GpStringFormat_SetTrimming(GP_STRINGFORMAT * this, GpStringTrimming trimming)
{
    return (this->lastResult = GdipSetStringFormatTrimming(this->nativeFormat, trimming));
}

GpStringTrimming GpStringFormat_GetTrimming(GP_STRINGFORMAT * this)
{
    GpStringTrimming trimming;
    (this->lastResult = GdipGetStringFormatTrimming(this->nativeFormat, &trimming));
    return trimming;
}

GpStatus GpStringFormat_SetMeasurableCharacterRanges(
    GP_STRINGFORMAT * this,
    INT rangeCount,
    const CHARACTERRANGE *ranges
    )
{
    return (this->lastResult = GdipSetStringFormatMeasurableCharacterRanges(
                    this->nativeFormat, rangeCount, ranges));
}

INT GpStringFormat_GetMeasurableCharacterRangeCount(GP_STRINGFORMAT * this)
{
    INT count;
    (this->lastResult = GdipGetStringFormatMeasurableCharacterRangeCount(this->nativeFormat, &count));
    return count;
}

// GetLastStatus - return last error code and clear error code
GpStatus GpStringFormat_GetLastStatus(GP_STRINGFORMAT * this)
{
    GpStatus lastStatus = this->lastResult;
    this->lastResult = eOk;
    return lastStatus;
}

// private constructor for copy
GP_STRINGFORMAT GpStringFormat_StringFormat(GP_GPSTRINGFORMAT * clonedStringFormat,
    GpStatus status)
{
    GP_STRINGFORMAT this;
    this.lastResult = status;
    this.nativeFormat = clonedStringFormat;
    return this;
}

static BYTE GenericTypographicStringFormatBuffer[sizeof(GP_STRINGFORMAT)] = {0};
static BYTE GenericDefaultStringFormatBuffer[sizeof(GP_STRINGFORMAT)] = {0};
static GP_STRINGFORMAT *GenericTypographicStringFormat = NULL;
static GP_STRINGFORMAT *GenericDefaultStringFormat     = NULL;

// Define the generic string formats
GP_STRINGFORMAT * GpStringFormat_GenericDefault(VOID)
{
    if (GenericDefaultStringFormat != NULL)
    {
        return GenericDefaultStringFormat;
    }

    GenericDefaultStringFormat =
        (GP_STRINGFORMAT*)GenericDefaultStringFormatBuffer;

	GenericDefaultStringFormat->lastResult =
			GdipStringFormatGetGenericDefault(
           &(GenericDefaultStringFormat->nativeFormat));

    return GenericDefaultStringFormat;
}

const GP_STRINGFORMAT * GpStringFormat_GenericTypographic(VOID)
{
    if (GenericTypographicStringFormat != NULL)
    {
        return GenericTypographicStringFormat;
    }

    GenericTypographicStringFormat =
        (GP_STRINGFORMAT*)GenericTypographicStringFormatBuffer;

    GenericTypographicStringFormat->lastResult =
        GdipStringFormatGetGenericTypographic(
            &GenericTypographicStringFormat->nativeFormat
        );

    return GenericTypographicStringFormat;
}


