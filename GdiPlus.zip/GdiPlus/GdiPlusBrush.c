/**************************************************************************\
*
* All files in GdiPlusLib have been modified from the Microsoft
* GdiPlus C++ header files.
*
* Module Name:
*
*   GdiPlusBrush.c
*
* Abstract:
*
*   Brush related functions
*
\**************************************************************************/

//--------------------------------------------------------------------------
// Abstract base class for various brush types
//--------------------------------------------------------------------------
#include "GdiPlusBrush.h"
#include "GdiPlusColor.h"
#include "GdiPlusBitmap.h"
#include "GdiPlusImageAttributes.h"
#include "GdiPlusMatrix.h"

VOID GpBrush_Delete(GP_BRUSH * this)
{
	GdipDeleteBrush(this->nativeBrush);
}

GP_BRUSH GpBrush_Brush(GP_GPBRUSH * nativeBrush, GpStatus status)
{
    GP_BRUSH this;
    this.lastResult = status;
	this.nativeBrush = nativeBrush;
    return this;
}

GP_BRUSH GpBrush_Clone(GP_BRUSH * this)
{
	GP_GPBRUSH * cloneBrush = NULL;
	this->lastResult = GdipCloneBrush(this->nativeBrush, &cloneBrush);
	return GpBrush_Brush(cloneBrush, this->lastResult);
}

GpBrushType GpBrush_GetType(GP_BRUSH * this)
{
	GpBrushType type = -1;
	this->lastResult = GdipGetBrushType(this->nativeBrush, &type);
	return type;
}

//--------------------------------------------------------------------------
// Solid Fill Brush Object
//--------------------------------------------------------------------------
GP_BRUSH GpSolidBrush(COLOR * color)
{
	GpStatus lastResult;
	GP_GPSOLIDFILL * brush = NULL;

	lastResult = GdipCreateSolidFill(color->Argb, &brush);

	return GpBrush_Brush((GP_GPBRUSH*)brush, lastResult);
}

GpStatus GpSolidBrush_GetColor(GP_BRUSH * this, COLOR * color)
{
	ARGB argb;

	if (color == NULL)
	{
		return (this->lastResult = eInvalidParameter);
	}

	this->lastResult = GdipGetSolidFillColor(
				(GP_GPSOLIDFILL*)this->nativeBrush, &argb);

	color->Argb = argb;

	return this->lastResult;
}

GpStatus GpSolidBrush_SetColor(GP_BRUSH * this, COLOR * color)
{
	return (this->lastResult = GdipSetSolidFillColor((GP_GPSOLIDFILL*)this->nativeBrush, color->Argb));
}

//--------------------------------------------------------------------------
// Texture Brush Fill Object
//--------------------------------------------------------------------------
//GP_BRUSH  GpTextureBrush(GP_IMAGE * image, GpWrapMode wrapMode = eWrapModeTile);
GP_BRUSH GpTextureBrush(GP_IMAGE * image, GpWrapMode wrapMode)
{
	GpStatus lastResult;
	GP_GPTEXTURE * texture = NULL;
	lastResult = GdipCreateTexture(image->nativeImage, wrapMode, &texture);
	return GpBrush_Brush((GP_GPBRUSH*)texture, lastResult);
}

// When creating a texture brush from a metafile image, the dstRect
// is used to specify the size that the metafile image should be
// rendered at in the device units of the destination graphics.
// It is NOT used to crop the metafile image, so only the width
// and height values matter for metafiles.
GP_BRUSH GpTextureBrush_RcF(GP_IMAGE * image, GpWrapMode wrapMode, const RECTF * dstRect)
{
	GP_BRUSH this;
	GP_GPTEXTURE * texture = NULL;
	this.lastResult = GdipCreateTexture2(image->nativeImage, wrapMode, dstRect->X, dstRect->Y, dstRect->Width, dstRect->Height, &texture);
	this.nativeBrush = (GP_GPBRUSH*)texture;
	return this;
}

//GP_BRUSH GpTextureBrush_IA(GP_IMAGE * image, const RECTF * dstRect, const GP_IMAGEATTRIBUTES * imageAttributes = NULL);
GP_BRUSH GpTextureBrush_IA(GP_IMAGE * image, const RECTF * dstRect, const GP_IMAGEATTRIBUTES * imageAttributes)
{
	GP_BRUSH this;
	GP_GPTEXTURE * texture = NULL;
	this.lastResult = GdipCreateTextureIA(image->nativeImage, (imageAttributes) ? imageAttributes->nativeImageAttr : NULL, dstRect->X, dstRect->Y, dstRect->Width, dstRect->Height, &texture);
	this.nativeBrush = (GP_GPBRUSH*)texture;
	return this;
}

GP_BRUSH GpTextureBrush_IAI(GP_IMAGE * image, const RECTI * dstRect,
	const GP_IMAGEATTRIBUTES * imageAttributes)
{
	GP_BRUSH this;
	GP_GPTEXTURE * texture = NULL;
	this.lastResult = GdipCreateTextureIAI(image->nativeImage, (imageAttributes) ? imageAttributes->nativeImageAttr : NULL, dstRect->X, dstRect->Y, dstRect->Width, dstRect->Height, &texture);
	this.nativeBrush = (GP_GPBRUSH*)texture;
	return this;
}

GP_BRUSH GpTextureBrush_2RcI(GP_IMAGE * image, GpWrapMode wrapMode, const RECTI * dstRect)
{
	GP_BRUSH this;
	GP_GPTEXTURE * texture = NULL;
	this.lastResult = GdipCreateTexture2I(image->nativeImage, wrapMode, dstRect->X, dstRect->Y, dstRect->Width, dstRect->Height, &texture);
	this.nativeBrush = (GP_GPBRUSH*)texture;
	return this;
}

GP_BRUSH GpTextureBrush_2(GP_IMAGE * image, GpWrapMode wrapMode, REAL dstX, REAL dstY, REAL dstWidth, REAL dstHeight)
{
	GP_BRUSH this;
	GP_GPTEXTURE * texture = NULL;
	this.lastResult = GdipCreateTexture2(image->nativeImage, wrapMode, dstX, dstY, dstWidth, dstHeight, &texture);
	this.nativeBrush = (GP_GPBRUSH*)texture;
	return this;
}

GP_BRUSH GpTextureBrush_2I(GP_IMAGE * image, GpWrapMode wrapMode, INT dstX, INT dstY, INT dstWidth, INT dstHeight)
{
	GP_BRUSH this;
	GP_GPTEXTURE * texture = NULL;
	this.lastResult = GdipCreateTexture2I(image->nativeImage, wrapMode, dstX, dstY, dstWidth, dstHeight, &texture);
	this.nativeBrush = (GP_GPBRUSH*)texture;
	return this;
}

GpStatus GpTextureBrush_SetTransform(GP_BRUSH * this, const GP_MATRIX * matrix)
{
  return (this->lastResult = GdipSetTextureTransform((GP_GPTEXTURE*)this->nativeBrush, matrix->nativeMatrix));
}

GpStatus GpTextureBrush_GetTransform(GP_BRUSH * this, GP_MATRIX * matrix)
{
	return (this->lastResult = GdipGetTextureTransform((GP_GPTEXTURE *)this->nativeBrush, matrix->nativeMatrix));
}

GpStatus GpTextureBrush_ResetTransform(GP_BRUSH * this)
{
  return (this->lastResult = GdipResetTextureTransform((GP_GPTEXTURE*)this->nativeBrush));
}

//GpStatus GpTextureBrush_MultiplyTransform(GP_BRUSH * this, const GP_MATRIX * matrix, GpMatrixOrder order = eMatrixOrderPrepend);
GpStatus GpTextureBrush_MultiplyTransform(GP_BRUSH * this, const GP_MATRIX * matrix, GpMatrixOrder order)
{
  return (this->lastResult = GdipMultiplyTextureTransform((GP_GPTEXTURE *)this->nativeBrush, matrix->nativeMatrix, order));
}

//GpStatus GpTextureBrush_TranslateTransform(GP_BRUSH * this, REAL dx, REAL dy, GpMatrixOrder order = eMatrixOrderPrepend);
GpStatus GpTextureBrush_TranslateTransform(GP_BRUSH * this, REAL dx, REAL dy, GpMatrixOrder order)
{
  return (this->lastResult = GdipTranslateTextureTransform((GP_GPTEXTURE *)this->nativeBrush, dx, dy, order));
}

//GpStatus GpTextureBrush_ScaleTransform(GP_BRUSH * this, REAL sx, REAL sy, GpMatrixOrder order = eMatrixOrderPrepend);
GpStatus GpTextureBrush_ScaleTransform(GP_BRUSH * this, REAL sx, REAL sy, GpMatrixOrder order)
{
  return (this->lastResult = GdipScaleTextureTransform((GP_GPTEXTURE *)this->nativeBrush, sx, sy, order));
}

//GpStatus GpTextureBrush_RotateTransform(GP_BRUSH * this, REAL angle, GpMatrixOrder order = eMatrixOrderPrepend);
GpStatus GpTextureBrush_RotateTransform(GP_BRUSH * this, REAL angle, GpMatrixOrder order)
{
  return (this->lastResult = GdipRotateTextureTransform((GP_GPTEXTURE *)this->nativeBrush, angle, order));
}

GpStatus GpTextureBrush_SetWrapMode(GP_BRUSH * this, GpWrapMode wrapMode)
{
  return (this->lastResult = GdipSetTextureWrapMode((GP_GPTEXTURE *)this->nativeBrush, wrapMode));
}

GpWrapMode GpTextureBrush_GetWrapMode(GP_BRUSH * this)
{
	GpWrapMode wrapMode;
	(this->lastResult = GdipGetTextureWrapMode((GP_GPTEXTURE *)this->nativeBrush, &wrapMode));
	return wrapMode;
}

GP_IMAGE GpTextureBrush_GetImage(GP_BRUSH * this)
{
	GP_IMAGE img;
	GP_GPIMAGE * image = NULL;
	this->lastResult = GdipGetTextureImage((GP_GPTEXTURE *)this->nativeBrush, &image);
	img.lastResult = this->lastResult;
	img.nativeImage = image;
	return img;
}

GP_BRUSH GpLinearGradientBrush(const POINTF * point1,
	const POINTF * point2, const COLOR * color1,
	const COLOR * color2)
{
	GP_BRUSH brsh;
	GP_GPLINEGRADIENT *brush = NULL;

	brsh.lastResult = GdipCreateLineBrush(point1, point2, GpColor_GetValue(color1), GpColor_GetValue(color2),
							eWrapModeTile, &brush);
	brsh.nativeBrush = (GP_GPBRUSH*)brush;
	return brsh;
}

GP_BRUSH GpLinearGradientBrush_PtsI(const POINTI * point1, const POINTI * point2, 
		const COLOR * color1, const COLOR * color2)
{
	GP_BRUSH brsh;
	GP_GPLINEGRADIENT *brush = NULL;

	brsh.lastResult = GdipCreateLineBrushI(point1, point2, GpColor_GetValue(color1), GpColor_GetValue(color2),
            				eWrapModeTile, &brush);
	brsh.nativeBrush = (GP_GPBRUSH*)brush;
	return brsh;
}

GP_BRUSH GpLinearGradientBrush_RcF(const RECTF * rect,
	const COLOR * color1, const COLOR * color2,
	GpLinearGradientMode mode)
{
	GP_BRUSH brsh;
	GP_GPLINEGRADIENT *brush = NULL;
	brsh.lastResult = GdipCreateLineBrushFromRect(rect, GpColor_GetValue(color1),
		GpColor_GetValue(color2), mode, eWrapModeTile, &brush);
	brsh.nativeBrush = (GP_GPBRUSH*)brush;
	return brsh;
}

GP_BRUSH GpLinearGradientBrush_RcI(const RECTI * rect,
	const COLOR * color1, const COLOR * color2,
	GpLinearGradientMode mode)
{
	GP_BRUSH brsh;
	GP_GPLINEGRADIENT *brush = NULL;
	brsh.lastResult = GdipCreateLineBrushFromRectI(rect, GpColor_GetValue(color1),
		GpColor_GetValue(color2), mode, eWrapModeTile, &brush);
	brsh.nativeBrush = (GP_GPBRUSH*)brush;
	return brsh;
}

//GP_BRUSH GpLinearGradientBrush_RcFA(const RECTF * rect, const COLOR * color1, const COLOR * color2, REAL angle, BOOL isAngleScalable = FALSE)
GP_BRUSH GpLinearGradientBrush_RcFA(const RECTF * rect,
	const COLOR * color1, const COLOR * color2,
	REAL angle, BOOL isAngleScalable)
{
	GP_BRUSH brsh;
	GP_GPLINEGRADIENT *brush = NULL;
	brsh.lastResult = GdipCreateLineBrushFromRectWithAngle(rect, GpColor_GetValue(color1),
		GpColor_GetValue(color2), angle, isAngleScalable, eWrapModeTile, &brush);
	brsh.nativeBrush = (GP_GPBRUSH*)brush;
	return brsh;
}

//GP_BRUSH GpLinearGradientBrush_RcIA(const RECTI * rect, const COLOR * color1, const COLOR * color2, REAL angle, BOOL isAngleScalable = FALSE)
GP_BRUSH GpLinearGradientBrush_RcIA(const RECTI * rect,
	const COLOR * color1, const COLOR * color2,
	REAL angle, BOOL isAngleScalable)
{
	GP_BRUSH brsh;
	GP_GPLINEGRADIENT *brush = NULL;
	brsh.lastResult = GdipCreateLineBrushFromRectWithAngleI(rect, GpColor_GetValue(color1),
		GpColor_GetValue(color2), angle, isAngleScalable, eWrapModeTile, &brush);
	brsh.nativeBrush = (GP_GPBRUSH*)brush;
	return brsh;
}

GpStatus GpLinearGradientBrush_SetLinearColors(GP_BRUSH * brush, const COLOR * color1, const COLOR * color2)
{
  return (brush->lastResult = GdipSetLineColors((GP_GPLINEGRADIENT*)brush->nativeBrush,
			GpColor_GetValue(color1), GpColor_GetValue(color2)));
}

GpStatus GpLinearGradientBrush_GetLinearColors(GP_BRUSH * this, COLOR * colors)
{
	ARGB argb[2];

	if (colors == NULL)
	{
		return (this->lastResult = eInvalidParameter);
	}
	(this->lastResult = GdipGetLineColors((GP_GPLINEGRADIENT *)this->nativeBrush, argb));

	if (this->lastResult == eOk)
	{
		colors[0].Argb = argb[0];
		colors[1].Argb = argb[1];
	}

	return this->lastResult;
}

GpStatus GpLinearGradientBrush_GetRectangleRcF(GP_BRUSH * this, RECTF * rect)
{
	return (this->lastResult = GdipGetLineRect((GP_GPLINEGRADIENT *)this->nativeBrush, rect));
}

GpStatus GpLinearGradientBrush_GetRectangleRcI(GP_BRUSH * this, RECTI * rect)
{
	return (this->lastResult = GdipGetLineRectI((GP_GPLINEGRADIENT*)this->nativeBrush, rect));
}

GpStatus GpLinearGradientBrush_SetGammaCorrection(GP_BRUSH * this, BOOL useGammaCorrection)
{
	return (this->lastResult = GdipSetLineGammaCorrection((GP_GPLINEGRADIENT *)this->nativeBrush, useGammaCorrection));
}

BOOL GpLinearGradientBrush_GetGammaCorrection(GP_BRUSH * this)
{
	BOOL useGammaCorrection;
	this->lastResult = GdipGetLineGammaCorrection((GP_GPLINEGRADIENT*)this->nativeBrush, &useGammaCorrection);
	return useGammaCorrection;
}

INT GpLinearGradientBrush_GetBlendCount(GP_BRUSH * this)
{
	INT count = 0;
	this->lastResult = GdipGetLineBlendCount((GP_GPLINEGRADIENT*)this->nativeBrush, &count);
	return count;
}

GpStatus GpLinearGradientBrush_SetBlend(GP_BRUSH * this, const REAL * blendFactors, const REAL * blendPositions, INT count)
{
  return (this->lastResult = GdipSetLineBlend((GP_GPLINEGRADIENT*)this->nativeBrush, blendFactors, blendPositions, count));
}

GpStatus GpLinearGradientBrush_GetBlend(GP_BRUSH * this, REAL * blendFactors, REAL * blendPositions, INT count)
{
	return (this->lastResult = GdipGetLineBlend((GP_GPLINEGRADIENT *)this->nativeBrush, blendFactors, blendPositions, count));
}

INT GpLinearGradientBrush_GetInterpolationColorCount(GP_BRUSH * this)
{
	INT count = 0;
	this->lastResult = GdipGetLinePresetBlendCount((GP_GPLINEGRADIENT*)this->nativeBrush, &count);
	return count;
}

GpStatus GpLinearGradientBrush_SetInterpolationColors(GP_BRUSH * this, const COLOR * presetColors, const REAL * blendPositions, INT count)
{
	if ((count <= 0) || !presetColors)
		return (this->lastResult = eInvalidParameter);

	ARGB *argbs = GpAlloc(count * sizeof(ARGB));

	if (argbs)
	{
		for (INT i = 0; i < count; i++)
		{
			argbs[i] = GpColor_GetValue(&presetColors[i]);
		}

		GpStatus status = (this->lastResult = GdipSetLinePresetBlend((GP_GPLINEGRADIENT*)this->nativeBrush,
						argbs, blendPositions, count));
		GpFree(argbs);
		return status;
	}
	else
	{
		return (this->lastResult = eOutOfMemory);
	}
}

GpStatus GpLinearGradientBrush_GetInterpolationColors(GP_BRUSH * this, COLOR * presetColors, REAL * blendPositions, INT count)
{
	if ((count <= 0) || !presetColors)
		return (this->lastResult = eInvalidParameter);

	ARGB * argbs = GpAlloc(count * sizeof(ARGB));

	if (!argbs)
	{
		return (this->lastResult = eOutOfMemory);
	}

	GpStatus status = (this->lastResult = GdipGetLinePresetBlend((GP_GPLINEGRADIENT*)this->nativeBrush,
				argbs, blendPositions,	count));
	if (status == eOk)
	{
		for (INT i = 0; i < count; i++)
		{
			presetColors[i].Argb = argbs[i];
		}
	}

	GpFree(argbs);
	return status;
}

//GpStatus GpLinearGradientBrush_SetBlendBellShape(GP_BRUSH * this, REAL focus, REAL scale = 1.0f)
GpStatus GpLinearGradientBrush_SetBlendBellShape(GP_BRUSH * this, REAL focus, REAL scale)
{
  return (this->lastResult = GdipSetLineSigmaBlend((GP_GPLINEGRADIENT *)this->nativeBrush, focus, scale));
}

GpStatus GpLinearGradientBrush_SetBlendTriangularShape(GP_BRUSH * this, REAL focus, REAL scale)
{
  return (this->lastResult = GdipSetLineLinearBlend((GP_GPLINEGRADIENT *)this->nativeBrush, focus, scale));
}

GpStatus GpLinearGradientBrush_SetTransform(GP_BRUSH * this, const GP_MATRIX * matrix)
{
  return (this->lastResult = GdipSetLineTransform((GP_GPLINEGRADIENT *)this->nativeBrush, matrix->nativeMatrix));
}

GpStatus GpLinearGradientBrush_GetTransform(GP_BRUSH * this, GP_MATRIX * matrix)
{
	return (this->lastResult = GdipGetLineTransform((GP_GPLINEGRADIENT *)this->nativeBrush, matrix->nativeMatrix));
}

GpStatus GpLinearGradientBrush_ResetTransform(GP_BRUSH * this)
{
  return (this->lastResult = GdipResetLineTransform((GP_GPLINEGRADIENT *)this->nativeBrush));
}

//GpStatus GpLinearGradientBrush_MultiplyTransform(GP_BRUSH * this, const GP_MATRIX * matrix, GpMatrixOrder order = MatrixOrderPrepend)
GpStatus GpLinearGradientBrush_MultiplyTransform(GP_BRUSH * this, const GP_MATRIX * matrix, GpMatrixOrder order)
{
  return (this->lastResult = GdipMultiplyLineTransform((GP_GPLINEGRADIENT *)this->nativeBrush, matrix->nativeMatrix, order));
}

//GpStatus GpLinearGradientBrush_TranslateTransform(GP_BRUSH * this, REAL dx, REAL dy, GpMatrixOrder order = MatrixOrderPrepend)
GpStatus GpLinearGradientBrush_TranslateTransform(GP_BRUSH * this, REAL dx, REAL dy, GpMatrixOrder order)
{
  return (this->lastResult = GdipTranslateLineTransform((GP_GPLINEGRADIENT *)this->nativeBrush, dx, dy, order));
}

//GpStatus GpLinearGradientBrush_ScaleTransform(GP_BRUSH * this, REAL sx, REAL sy, GpMatrixOrder order = MatrixOrderPrepend)
GpStatus GpLinearGradientBrush_ScaleTransform(GP_BRUSH * this, REAL sx, REAL sy, GpMatrixOrder order)
{
  return (this->lastResult = GdipScaleLineTransform((GP_GPLINEGRADIENT *)this->nativeBrush, sx, sy, order));
}

//GpStatus GpLinearGradientBrush_RotateTransform(GP_BRUSH * this, REAL angle, GpMatrixOrder order = MatrixOrderPrepend)
GpStatus GpLinearGradientBrush_RotateTransform(GP_BRUSH * this, REAL angle, GpMatrixOrder order)
{
	return (this->lastResult = GdipRotateLineTransform((GP_GPLINEGRADIENT *) this->nativeBrush, angle, order));
}

GpStatus GpLinearGradientBrush_SetWrapMode(GP_BRUSH * this, GpWrapMode wrapMode)
{
	return (this->lastResult = GdipSetLineWrapMode((GP_GPLINEGRADIENT *)this->nativeBrush, wrapMode));
}

GpWrapMode GpLinearGradientBrush_GetWrapMode(GP_BRUSH * this)
{
	GpWrapMode wrapMode;
	(this->lastResult = GdipGetLineWrapMode((GP_GPLINEGRADIENT *)this->nativeBrush, &wrapMode));
	return wrapMode;
}

//GP_BRUSH GpHatchBrush(GpHatchStyle hatchStyle, const COLOR * foreColor, const COLOR * backColor = 0);
GP_BRUSH GpHatchBrush(GpHatchStyle hatchStyle, const COLOR * foreColor, const COLOR * backColor)
{
	GP_BRUSH this;
	GP_GPHATCH *brush = NULL;
	this.lastResult = GdipCreateHatchBrush(hatchStyle,
		GpColor_GetValue(foreColor), GpColor_GetValue(backColor), &brush);
	this.nativeBrush = (GP_GPBRUSH*)brush;
	return this;
}

GpHatchStyle GpHatchBrush_GetHatchStyle(GP_BRUSH * this)
{
	GpHatchStyle hatchStyle;
	this->lastResult = GdipGetHatchStyle(
		(GP_GPHATCH*)this->nativeBrush, &hatchStyle);
	return hatchStyle;
}

GpStatus GpHatchBrush_GetForegroundColor(GP_BRUSH * this, COLOR * color)
{
	ARGB argb;

	if (color == NULL)
	{
		return (this->lastResult = eInvalidParameter);
	}
	GpStatus status = (this->lastResult = GdipGetHatchForegroundColor(
			(GP_GPHATCH*)this->nativeBrush, &argb));
	GpColor_SetValue(color, argb);
	return status;
}

GpStatus GetBackgroundColor(GP_BRUSH * this, COLOR *color)
{
	ARGB argb;

	if (color == NULL)
	{
		return (this->lastResult = eInvalidParameter);
	}

	GpStatus status = (this->lastResult = GdipGetHatchBackgroundColor(
						(GP_GPHATCH*)this->nativeBrush, &argb));

	GpColor_SetValue(color, argb);

	return status;
}

