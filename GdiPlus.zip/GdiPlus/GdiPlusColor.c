/**************************************************************************
*
* All files in GdiPlusLib have been modified from the Microsoft
* GdiPlus C++ header files.
*
* Module Name:
*
* GdiPlusColor.c
*
*   COLOR related functions
*
**************************************************************************/

#include "GdiPlusColor.h"

// Assemble A, R, G, B values into a 32-bit integer
static ARGB MakeARGB(BYTE a, BYTE r, BYTE g, BYTE b)
{
	return (((ARGB) (b) <<  eBlueShift) | ((ARGB) (g) << eGreenShift) |
				((ARGB) (r) << eRedShift) | ((ARGB) (a) << eAlphaShift));
}

COLOR GpColorA(ARGB argb, BYTE alpha)
{
	COLOR color;
	color.Argb = argb | ((ARGB) (alpha) << eAlphaShift);
	return color;
}

COLOR GpColor(ARGB argb)
{
	COLOR color;
	color.Argb = argb;
	return color;
}

// MakeArgb with full alpha
COLOR GpColor_3(BYTE r, BYTE g, BYTE b)
{
	COLOR color;
	color.Argb = MakeARGB(255, r, g, b);
	return color;
}

VOID GpColor_3Set(COLOR * color, BYTE r, BYTE g, BYTE b)
{
	color->Argb = MakeARGB(255, r, g, b);
}

COLOR GpColor_4(BYTE a, BYTE r, BYTE g, BYTE b)
{
	COLOR color;
	color.Argb = MakeARGB(a, r, g, b);
	return color;
}

VOID GpColor_4Set(COLOR * color, BYTE a, BYTE r, BYTE g, BYTE b)
{
	color->Argb = MakeARGB(a, r, g, b);
}

BYTE GpColor_GetAlpha(const COLOR * color)
{
	return (BYTE) (color->Argb >> eAlphaShift);
}

BYTE GpColor_GetRed(const COLOR * color)
{
	return (BYTE) (color->Argb >> eRedShift);
}

BYTE GpColor_GetGreen(const COLOR * color)
{
	return (BYTE) (color->Argb >> eGreenShift);
}

BYTE GpColor_GetBlue(const COLOR * color)
{
	return (BYTE) (color->Argb >> eBlueShift);
}

ARGB GpColor_GetValue(const COLOR * color)
{
	return color->Argb;
}

VOID GpColor_SetValue(COLOR * color, const ARGB argb)
{
	color->Argb = argb;
}

VOID GpColor_SetFromCOLORREF(COLOR * color, const COLORREF rgb)
{
	color->Argb = MakeARGB(255, GetRValue(rgb), GetGValue(rgb), GetBValue(rgb));
}

