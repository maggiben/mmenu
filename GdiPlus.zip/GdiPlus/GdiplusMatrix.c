/**************************************************************************\
*
* All files in GdiPlusLib have been modified from the Microsoft
* GdiPlus C++ header files.
*
* Module Name:
*
*   GdiPlusMatrix.c
*
* Abstract:
*
*   Matrix related functions
*
\**************************************************************************/

#include "GdiplusMatrix.h"

GP_MATRIX GpMatrix_Matrix(GP_GPMATRIX *nativeMatrix);

// Default constructor - set to identity matrix
GP_MATRIX GpMatrix(VOID)
{
    GP_MATRIX this;
    GP_GPMATRIX *matrix = NULL;

    this.lastResult = GdipCreateMatrix(&matrix);

	this.nativeMatrix = matrix;
    return this;
}

GP_MATRIX GpMatrix_2(REAL m11, REAL m12, REAL m21, REAL m22, REAL dx, REAL dy)
{
    GP_MATRIX this;
    GP_GPMATRIX *matrix = NULL;
    this.lastResult = GdipCreateMatrix2(m11, m12, m21, m22, dx, dy, &matrix);
	this.nativeMatrix = matrix;
    return this;
}

GP_MATRIX GpMatrix_3(const RECTF * rect, const POINTF* dstplg)
{
    GP_MATRIX this;
    GP_GPMATRIX *matrix = NULL;
    this.lastResult = GdipCreateMatrix3(rect, dstplg, &matrix);
	this.nativeMatrix = matrix;
    return this;
}

GP_MATRIX GpMatrix_3I(const RECTI * rect, const POINTI* dstplg)
{
    GP_MATRIX this;
    GP_GPMATRIX *matrix = NULL;
    this.lastResult = GdipCreateMatrix3I(rect, dstplg, &matrix);
	this.nativeMatrix = matrix;
    return this;
}

VOID GpMatrix_Delete(GP_MATRIX * this)
{
    GdipDeleteMatrix(this->nativeMatrix);
}

GP_MATRIX GpMatrix_Clone(GP_MATRIX * this)
{
    GP_GPMATRIX *cloneMatrix = NULL;
    (this->lastResult = GdipCloneMatrix(this->nativeMatrix, &cloneMatrix));
    return GpMatrix_Matrix(cloneMatrix);
}

GpStatus GpMatrix_GetElements(GP_MATRIX * this, REAL *m)
{
    return (this->lastResult = GdipGetMatrixElements(this->nativeMatrix, m));
}

GpStatus GpMatrix_SetElements(GP_MATRIX * this,
    REAL m11, REAL m12, REAL m21, REAL m22, REAL dx, REAL dy)
{
    return (this->lastResult = GdipSetMatrixElements(this->nativeMatrix,
                            m11, m12, m21, m22, dx, dy));
}

REAL GpMatrix_OffsetX(GP_MATRIX * this)
{
    REAL elements[6];

    if (GpMatrix_GetElements(this, &elements[0]) == eOk)
        return elements[4];
    else
        return 0.0f;
}

REAL GpMatrix_OffsetY(GP_MATRIX * this)
{
    REAL elements[6];

    if (GpMatrix_GetElements(this, &elements[0]) == eOk)
        return elements[5];
    else
        return 0.0f;
}

GpStatus GpMatrix_Reset(GP_MATRIX * this)
{
    // set identity matrix elements
    return (this->lastResult = GdipSetMatrixElements(this->nativeMatrix,
                                    1.0f, 0.0f, 0.0f, 1.0f, 0.0f, 0.0f));
}

//GpStatus GpMatrix_Multiply(GP_MATRIX * this, GP_MATRIX *matrix, GpMatrixOrder order = eMatrixOrderPrepend)
GpStatus GpMatrix_Multiply(GP_MATRIX * this, GP_MATRIX *matrix,
    GpMatrixOrder order)
{
    return (this->lastResult = GdipMultiplyMatrix(this->nativeMatrix,
                                          matrix->nativeMatrix,
                                          order));
}

//GpStatus GpMatrix_Translate(GP_MATRIX * this, REAL offsetX, REAL offsetY,GpMatrixOrder order = eMatrixOrderPrepend)
GpStatus GpMatrix_Translate(GP_MATRIX * this, REAL offsetX, REAL offsetY,
    GpMatrixOrder order)
{
    return (this->lastResult = GdipTranslateMatrix(this->nativeMatrix, offsetX, offsetY, order));
}

//GpStatus GpMatrix_Scale(GP_MATRIX * this, REAL scaleX, REAL scaleY, GpMatrixOrder order = eMatrixOrderPrepend)
GpStatus GpMatrix_Scale(GP_MATRIX * this, REAL scaleX, REAL scaleY,
    GpMatrixOrder order)
{
    return (this->lastResult = GdipScaleMatrix(this->nativeMatrix, scaleX, scaleY, order));
}

//GpStatus GpMatrix_Rotate(GP_MATRIX * this, REAL angle, GpMatrixOrder order = eMatrixOrderPrepend)
GpStatus GpMatrix_Rotate(GP_MATRIX * this, REAL angle, GpMatrixOrder order)
{
    return (this->lastResult = GdipRotateMatrix(this->nativeMatrix, angle, order));
}

//GpStatus GpMatrix_RotateAt(GP_MATRIX * this, REAL angle, const POINTF * center, GpMatrixOrder order = eMatrixOrderPrepend)
GpStatus GpMatrix_RotateAt(GP_MATRIX * this, REAL angle,
    const POINTF * center, GpMatrixOrder order)
{
    if(order == eMatrixOrderPrepend)
    {
        (this->lastResult = GdipTranslateMatrix(this->nativeMatrix, center->X, center->Y, order));
        (this->lastResult = GdipRotateMatrix(this->nativeMatrix, angle, order));
        return (this->lastResult = GdipTranslateMatrix(this->nativeMatrix, - center->X, - center->Y, order));
    }
    else
    {
        (this->lastResult = GdipTranslateMatrix(this->nativeMatrix, - center->X, - center->Y, order));
        (this->lastResult = GdipRotateMatrix(this->nativeMatrix, angle, order));
        return (this->lastResult = GdipTranslateMatrix(this->nativeMatrix, center->X, center->Y, order));
    }
}

//GpStatus GpMatrix_Shear(GP_MATRIX * this, REAL shearX, REAL shearY, GpMatrixOrder order = eMatrixOrderPrepend)
GpStatus GpMatrix_Shear(GP_MATRIX * this, REAL shearX, REAL shearY, GpMatrixOrder order)
{
    return (this->lastResult = GdipShearMatrix(this->nativeMatrix, shearX, shearY, order));
}

GpStatus GpMatrix_Invert(GP_MATRIX * this)
{
    return (this->lastResult = GdipInvertMatrix(this->nativeMatrix));
}

// float version
//GpStatus GpMatrix_TransformPointsF(GP_MATRIX * this, POINTF* pts, INT count = 1)
GpStatus GpMatrix_TransformPointsF(GP_MATRIX * this, POINTF* pts, INT count)
{
    return (this->lastResult = GdipTransformMatrixPoints(this->nativeMatrix, pts, count));
}

//GpStatus GpMatrix_TransformPointsI(GP_MATRIX * this, POINTI* pts, INT count = 1)
GpStatus GpMatrix_TransformPointsI(GP_MATRIX * this, POINTI* pts, INT count)
{
    return (this->lastResult = GdipTransformMatrixPointsI(this->nativeMatrix, pts, count));
}

//GpStatus GpMatrix_TransformVectorsF(GP_MATRIX * this, POINTF* pts, INT count = 1)
GpStatus GpMatrix_TransformVectorsF(GP_MATRIX * this, POINTF* pts, INT count)
{
    return (this->lastResult = GdipVectorTransformMatrixPoints(this->nativeMatrix, pts, count));
}

GpStatus GpMatrix_TransformVectorsI(GP_MATRIX * this, POINTI* pts, INT count)
{
    return (this->lastResult = GdipVectorTransformMatrixPointsI(this->nativeMatrix, pts, count));
}

BOOL GpMatrix_IsInvertible(GP_MATRIX * this)
{
    BOOL result = FALSE;
    (this->lastResult = GdipIsMatrixInvertible(this->nativeMatrix, &result));
    return result;
}

BOOL GpMatrix_IsIdentity(GP_MATRIX * this)
{
    BOOL result = FALSE;
    (this->lastResult = GdipIsMatrixIdentity(this->nativeMatrix, &result));
    return result;
}

BOOL GpMatrix_Equals(GP_MATRIX * this, GP_MATRIX *matrix)
{
    BOOL result = FALSE;
    (this->lastResult = GdipIsMatrixEqual(this->nativeMatrix, matrix->nativeMatrix, &result));
    return result;
}

GpStatus GpMatrix_GetLastStatus(GP_MATRIX * this)
{
    GpStatus lastStatus = this->lastResult;
    this->lastResult = eOk;
    return lastStatus;
}

GP_MATRIX GpMatrix_Matrix(GP_GPMATRIX *nativeMatrix )
{
    GP_MATRIX this;
    this.lastResult = eOk;
	this.nativeMatrix = nativeMatrix;
    return this;
}

