/**************************************************************************\
*
* All files in GdiPlusLib have been modified from the Microsoft
* GdiPlus C++ header files.
*
* Module Name:
*
*   GdiPlusMetafileHeader.c
*
* Abstract:
*
*   MetafileHeader related functions
*
\**************************************************************************/

#include "GdiPlusMetaHeader.h"

// Get the metafile type
GpMetafileType GpMetafileHeader_GetType(const GP_METAFILEHEADER*  this)
{
    return this->Type;
}

// Get the size of the metafile in BYTEs
UINT GpMetafileHeader_GetMetafileSize(const GP_METAFILEHEADER*  this)
{
    return this->Size;
}

// If IsEmfPlus, this is the EMF+ version; else it is the WMF or EMF version
UINT GpMetafileHeader_GetVersion(const GP_METAFILEHEADER*  this)
{
    return this->Version;
}

// Get the EMF+ flags associated with the metafile
UINT GpMetafileHeader_GetEmfPlusFlags(const GP_METAFILEHEADER*  this)
{
    return this->EmfPlusFlags;
}

// Get the X Dpi of the metafile
REAL GpMetafileHeader_GetDpiX(const GP_METAFILEHEADER*  this)
{
    return this->DpiX;
}

// Get the Y Dpi of the metafile
REAL GpMetafileHeader_GetDpiY(const GP_METAFILEHEADER*  this)
{
    return this->DpiY;
}

// Get the bounds of the metafile in device units
VOID GpMetafileHeader_GetBounds (const GP_METAFILEHEADER*  this, RECTI *rect)
{
    rect->X = this->X;
    rect->Y = this->Y;
    rect->Width = this->Width;
    rect->Height = this->Height;
}

// Is it any type of WMF (standard or Aldus Placeable Metafile)?
BOOL GpMetafileHeader_IsWmf(const GP_METAFILEHEADER*  this)
{
    return ((this->Type == eMetafileTypeWmf) || (this->Type == eMetafileTypeWmfAldus));
}

// Is this an Aldus Placeable Metafile?
BOOL GpMetafileHeader_IsWmfAldus(const GP_METAFILEHEADER*  this)
{
    return (this->Type == eMetafileTypeWmf);
}

// Is this an EMF (not an EMF+)?
BOOL GpMetafileHeader_IsEmf(const GP_METAFILEHEADER*  this)
{
    return (this->Type == eMetafileTypeEmf);
}

// Is this an EMF or EMF+ file?
BOOL GpMetafileHeader_IsEmfOrEmfPlus(const GP_METAFILEHEADER*  this)
{
    return (this->Type >= eMetafileTypeEmf);
}

// Is this an EMF+ file?
BOOL GpMetafileHeader_IsEmfPlus(const GP_METAFILEHEADER*  this)
{
    return (this->Type >= eMetafileTypeEmfPlusOnly);
}

// Is this an EMF+ dual (has dual, down-level records) file?
BOOL GpMetafileHeader_IsEmfPlusDual(const GP_METAFILEHEADER*  this)
{
    return (this->Type == eMetafileTypeEmfPlusDual);
}

// Is this an EMF+ only (no dual records) file?
BOOL GpMetafileHeader_IsEmfPlusOnly(const GP_METAFILEHEADER*  this)
{
    return (this->Type == eMetafileTypeEmfPlusOnly);
}

// If it's an EMF+ file, was it recorded against a display Hdc?
BOOL GpMetafileHeader_IsDisplay(const GP_METAFILEHEADER*  this)
{
    return (GpMetafileHeader_IsEmfPlus(this) && ((this->EmfPlusFlags & GP_EMFPLUSFLAGS_DISPLAY) != 0));
}

// Get the WMF header of the metafile (if it is a WMF)
const METAHEADER * GpMetafileHeader_GetWmfHeader(const GP_METAFILEHEADER*  this)
{
    if (GpMetafileHeader_IsWmf(this))
    {
        return &this->WmfHeader;
    }
    return NULL;
}

// Get the EMF header of the metafile (if it is an EMF)
const GP_ENHMETAHEADER3 * GpMetafileHeader_GetEmfHeader(const GP_METAFILEHEADER *  this)
{
    if (GpMetafileHeader_IsEmfOrEmfPlus(this))
    {
        return &this->EmfHeader;
    }
    return NULL;
}

