/**************************************************************************\
*
* All files in GdiPlusLib have been modified from the Microsoft
* GdiPlus C++ header files.
*
* Module Name:
*
*   GdiPlusFont.c
*
* Abstract:
*
*   Font related functions
*
\**************************************************************************/

#include "GdiPlusFont.h"
#include "GdiPlusFontFamily.h"
#include "GdiPlusGraphics.h"

GP_FONT GpFont_Font(GP_GPFONT* font, GpStatus status)
{
    GP_FONT this;
    this.lastResult = status;
    this.nativeFont = font;
    return this;
}

GP_FONT GpFont(HDC hdc)
{
    GP_FONT this;
    GP_GPFONT *font = NULL;
    this.lastResult = GdipCreateFontFromDC(hdc, &font);
	this.nativeFont = font;
    return this;
}

GP_FONT GpFontHFont(HDC hdc, const HFONT hfont)
{
    GP_FONT this;
    GP_GPFONT *font = NULL;

    if (hfont)
    {
        LOGFONTA lf;

        if(GetObjectA(hfont, sizeof(LOGFONTA), &lf))
            this.lastResult = GdipCreateFontFromLogfontA(hdc, &lf, &font);
        else
            this.lastResult = GdipCreateFontFromDC(hdc, &font);
    }
    else
    {
        this.lastResult = GdipCreateFontFromDC(hdc, &font);
    }
	this.nativeFont = font;
    return this;
}


GP_FONT GpFontLOGFW(HDC hdc, LOGFONTW* logfont)
{
    GP_FONT this;
    GP_GPFONT *font = NULL;
    if (logfont)
    {
        this.lastResult = GdipCreateFontFromLogfontW(hdc, logfont, &font);
    }
    else
    {
        this.lastResult = GdipCreateFontFromDC(hdc, &font);
    }

    this.nativeFont = font;
    return this;
}

GP_FONT GpFontLOGFA(HDC hdc, LOGFONTA* logfont)
{
    GP_FONT this;
    GP_GPFONT *font = NULL;

    if (logfont)
    {
        this.lastResult = GdipCreateFontFromLogfontA(hdc, logfont, &font);
    }
    else
    {
        this.lastResult = GdipCreateFontFromDC(hdc, &font);
    }

    this.nativeFont = font;
	return this;
}

GP_FONT GpFontFam(const GP_FONTFAMILY * family, REAL emSize, INT style, GpUnit unit)
{
    GP_FONT this;
    GP_GPFONT *font = NULL;
    this.lastResult = GdipCreateFont(family ? family->nativeFamily : NULL,
                            emSize, style, unit, &font);
    this.nativeFont = font;
    return this;
}

GpStatus GpFont_GetFamily(GP_FONT * this, GP_FONTFAMILY *family)
{
    if (family == NULL)
    {
        return (this->lastResult = eInvalidParameter);
    }

    GpStatus status = GdipGetFamily((GP_GPFONT*)this->nativeFont, &(family->nativeFamily));
    family->lastResult = status;

    return (this->lastResult = status);

}

GP_FONT GpFontCOLL(const WCHAR * familyName, REAL emSize, INT style, GpUnit unit, const GP_FONTCOLLECTION * fontCollection)
{
    GP_FONT this;
    GP_FONTFAMILY family = GpFontFamily_Name(familyName, fontCollection);
    GP_GPFONT * font = NULL;

    this.lastResult = GpFontFamily_GetLastStatus(&family);
    if (this.lastResult == eOk)
    {
        this.lastResult = GdipCreateFont(family.nativeFamily,
                                emSize, style, unit, &font);
    }

    this.nativeFont = font;
    return this;
}

GpStatus GpFont_GetLogFontA(GP_FONT * this, const GP_GRAPHICS *g, LOGFONTA *logfontA)
{
    return (this->lastResult =
                GdipGetLogFontA(this->nativeFont,
                    g ? g->nativeGraphics : NULL, logfontA));
}


GpStatus GpFont_GetLogFontW(GP_FONT * this, const GP_GRAPHICS *g, LOGFONTW *logfontW)
{
    return (this->lastResult = GdipGetLogFontW(this->nativeFont,
                    g ? g->nativeGraphics : NULL, logfontW));
}

GP_FONT GpFont_Clone(GP_FONT * this)
{
    GP_GPFONT *cloneFont = NULL;
    (this->lastResult = GdipCloneFont(this->nativeFont, &cloneFont));
    return GpFont_Font(cloneFont, this->lastResult);
}

VOID GpFont_Delete(GP_FONT * this)
{
    GdipDeleteFont(this->nativeFont);
}

BOOL GpFont_IsAvailable(GP_FONT * this)
{
    return (this->nativeFont ? TRUE : FALSE);
}

INT GpFont_GetStyle(GP_FONT * this)
{
    INT style;
    (this->lastResult = GdipGetFontStyle(this->nativeFont, &style));
    return style;
}

REAL GpFont_GetSize(GP_FONT * this)
{
    REAL size;
    (this->lastResult = GdipGetFontSize(this->nativeFont, &size));
    return size;
}

GpUnit GpFont_GetUnit(GP_FONT * this)
{
    GpUnit unit;
    (this->lastResult = GdipGetFontUnit(this->nativeFont, &unit));
    return unit;
}

REAL GpFont_GetHeightGraph(GP_FONT * this, const GP_GRAPHICS *graphics)
{
    REAL height;
    (this->lastResult = GdipGetFontHeight(this->nativeFont,
            graphics ? graphics->nativeGraphics : NULL, &height));
    return height;
}

//REAL GpFont_GetHeight(GP_FONT * this, REAL dpi = 0)
REAL GpFont_GetHeight(GP_FONT * this, REAL dpi)
{
    REAL height;
    (this->lastResult = GdipGetFontHeightGivenDPI(this->nativeFont, dpi, &height));
    return height;
}


