#include <windows.h>
#include <stdio.h>
#include <GdiPlus.h>

int main(void)
{
	// Initialize GDI+.
	ULONG_PTR gdiplusToken;
	GdiplusStartup(&gdiplusToken, &g_GdiplusStartupInput, NULL);

	UINT num;	// number of image decoders
	UINT size;	// size, in bytes, of the image decoder array

	IMAGECODECINFO *pImageCodecInfo;

	// How many decoders are there?
	// How big (in bytes) is the array of all ImageCodecInfo objects?
	GpGetImageDecodersSize(&num, &size);

	// Create a buffer large enough to hold the array of ImageCodecInfo
	// objects that will be returned by GetImageDecoders.
	pImageCodecInfo = malloc(size);

	// GetImageDecoders creates an array of ImageCodecInfo objects
	// and copies that array into a previously allocated buffer. 
	// The third argument, imageCodecInfo, is a pointer to that buffer. 
	GpGetImageDecoders(num, size, pImageCodecInfo);

	// Display the graphics file format (MimeType)
	// for each ImageCodecInfo object.
	for (UINT j = 0; j < num; ++j)
	{
		wprintf(L"%ls\n", pImageCodecInfo[j].MimeType);
	}

	free(pImageCodecInfo);
	GdiplusShutdown(gdiplusToken);
	return 0;
}
