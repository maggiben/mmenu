// GdiplusImageCodec.c

#include "GdiplusImageCodec.h"

//--------------------------------------------------------------------------
// Codec Management APIs
//--------------------------------------------------------------------------
GpStatus GpGetImageDecodersSize(UINT *numDecoders, UINT *size)
{
    return GdipGetImageDecodersSize(numDecoders, size);
}

GpStatus GpGetImageDecoders(UINT numDecoders, UINT size, IMAGECODECINFO *decoders)
{
    return GdipGetImageDecoders(numDecoders, size, decoders);
}

GpStatus GpGetImageEncodersSize(UINT *numEncoders, UINT *size)
{
    return GdipGetImageEncodersSize(numEncoders, size);
}

GpStatus GpGetImageEncoders(UINT numEncoders, UINT size, IMAGECODECINFO *encoders)
{
    return GdipGetImageEncoders(numEncoders, size, encoders);
}
