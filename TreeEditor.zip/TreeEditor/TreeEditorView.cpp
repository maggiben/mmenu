// TreeEditorView.cpp : implementation of the CTreeEditorView class
//

#include "stdafx.h"
#include "TreeEditor.h"

#include "TreeEditorDoc.h"
#include "TreeEditorView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CTreeEditorView

IMPLEMENT_DYNCREATE(CTreeEditorView, CView)

BEGIN_MESSAGE_MAP(CTreeEditorView, CView)
	//{{AFX_MSG_MAP(CTreeEditorView)
	ON_WM_CREATE()
	ON_WM_SETFOCUS()
	ON_WM_SIZE()
	ON_WM_DROPFILES()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CTreeEditorView construction/destruction

CTreeEditorView::CTreeEditorView()
{
	// TODO: add construction code here

}

CTreeEditorView::~CTreeEditorView()
{
}

BOOL CTreeEditorView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return CView::PreCreateWindow(cs);
}

/////////////////////////////////////////////////////////////////////////////
// CTreeEditorView drawing

void CTreeEditorView::OnDraw(CDC* pDC)
{
	CTreeEditorDoc* pDoc = (CTreeEditorDoc*)GetDocument();
	ASSERT_VALID(pDoc);
	// TODO: add draw code for native data here
}

/////////////////////////////////////////////////////////////////////////////
// CTreeEditorView diagnostics

#ifdef _DEBUG
void CTreeEditorView::AssertValid() const
{
	CView::AssertValid();
}

void CTreeEditorView::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}

CTreeEditorDoc* CTreeEditorView::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CTreeEditorDoc)));
	return (CTreeEditorDoc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CTreeEditorView message handlers

void CTreeEditorView::OnInitialUpdate() 
{
	CView::OnInitialUpdate();
	m_etc.SetLimitText(100);
	m_etc.InitializeImageList();
}

void CTreeEditorView::OnUpdate(CView* pSender, LPARAM lHint, CObject* pHint) 
{
	if (m_etc.m_pted == NULL)
		m_etc.m_pted = (CTreeEditorDoc *)GetDocument();

	switch(lHint)
	{
	case HINT_NEW:
		m_etc.DeleteAllItems();	
		break;
	case HINT_LOAD_DIRECTORY:
		m_etc.DeleteAllItems();	
		m_etc.OnLoadEntireTree(FF_DIRECTORY_TYPE, m_etc.m_pted->m_tt);
		break;
	case HINT_LOAD_TREE_TYPE:
		m_etc.DeleteAllItems();	
		m_etc.OnLoadEntireTree(FF_TREE_TYPE, m_etc.m_pted->m_tt);
		break;
	case HINT_LOAD_IDENT_TYPE:
		m_etc.DeleteAllItems();	
		m_etc.OnLoadEntireTree(FF_INDENT_TYPE, m_etc.m_pted->m_tt);
		break;
	case HINT_LOAD_CSV_TYPE:
		m_etc.DeleteAllItems();	
		m_etc.OnLoadEntireTree(FF_CSV_TYPE, m_etc.m_pted->m_tt);
		break;
	case HINT_SAVE_TREE_TYPE:
		m_etc.OnSaveEntireTree(FF_TREE_TYPE, m_etc.m_pted->m_tt);
		break;
	case HINT_SAVE_IDENT_TYPE:
		m_etc.OnSaveEntireTree(FF_INDENT_TYPE, m_etc.m_pted->m_tt);
		break;
	case HINT_SAVE_CSV_TYPE:
		m_etc.OnSaveEntireTree(FF_CSV_TYPE, m_etc.m_pted->m_tt);
		break;
	}
}

int CTreeEditorView::OnCreate(LPCREATESTRUCT lpCreateStruct) 
{
	if (CView::OnCreate(lpCreateStruct) == -1)
		return -1;

	//Create the tree view
	CRect r;
	DWORD newstyle = TVS_SHOWSELALWAYS | TVS_EDITLABELS | TVS_HASBUTTONS | 
		TVS_LINESATROOT | TVS_HASLINES;
	if (!m_etc.Create(WS_VISIBLE | WS_CHILD | newstyle, r, this, 100))
		return -1;	      
	return 0;
}

void CTreeEditorView::OnSetFocus(CWnd* pOldWnd) 
{
	CView::OnSetFocus(pOldWnd);
	m_etc.SetFocus();
}

void CTreeEditorView::OnSize(UINT nType, int cx, int cy) 
{
	//Let the tree control occupy all the space of the client area
	CRect r;  
	GetClientRect(&r);
	m_etc.MoveWindow(r);
}
