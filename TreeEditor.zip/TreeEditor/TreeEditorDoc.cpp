// TreeEditorDoc.cpp : implementation of the CTreeEditorDoc class
//

#include "stdafx.h"
#include "TreeEditor.h"

#include "TreeEditorDoc.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CTreeEditorDoc

IMPLEMENT_DYNCREATE(CTreeEditorDoc, CDocument)

BEGIN_MESSAGE_MAP(CTreeEditorDoc, CDocument)
	//{{AFX_MSG_MAP(CTreeEditorDoc)
	ON_COMMAND(ID_FILE_SAVE, OnFileSave)
	ON_COMMAND(ID_FILE_SAVE_AS, OnFileSaveAs)
	ON_COMMAND(ID_FILE_OPEN, OnFileOpen)
	ON_COMMAND(IDC_DISPLAY_DIRECTORY_TREE, OnDisplayDirectoryTree)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

EXTENSION CTreeEditorDoc::m_apszExtension[] =
{
	EXTENSION("tre", "Tree Files"),
	EXTENSION("idt", "Indent Files"),
	EXTENSION("csv", "Comma Delimited Files"),
};

HINT_EXT CTreeEditorDoc::m_aheSave[] =
{
	HINT_EXT(HINT_SAVE_TREE_TYPE,  FF_TREE_TYPE),
	HINT_EXT(HINT_SAVE_IDENT_TYPE, FF_INDENT_TYPE),
	HINT_EXT(HINT_SAVE_CSV_TYPE,   FF_CSV_TYPE),
};

HINT_EXT CTreeEditorDoc::m_aheLoad[] =
{
	HINT_EXT(HINT_LOAD_TREE_TYPE,  FF_TREE_TYPE),
	HINT_EXT(HINT_LOAD_IDENT_TYPE, FF_INDENT_TYPE),
	HINT_EXT(HINT_LOAD_CSV_TYPE,   FF_CSV_TYPE),
};

/////////////////////////////////////////////////////////////////////////////
// CTreeEditorDoc construction/destruction

CTreeEditorDoc::CTreeEditorDoc()
{
	ASSERT(ARRAY_SIZE(m_aheLoad) == FF_MAX_TYPES);
	ASSERT(ARRAY_SIZE(m_aheSave) == FF_MAX_TYPES);
	ASSERT(ARRAY_SIZE(m_apszExtension) == FF_MAX_TYPES);

	GetCurrentDirectory(_MAX_PATH, m_ExamplesPath);
	strcat(m_ExamplesPath, "\\Examples");
	strcpy(m_szDelimiter, ",");	// Default delimiter for *.csv type
}

CTreeEditorDoc::~CTreeEditorDoc()
{
}

BOOL CTreeEditorDoc::OnNewDocument()
{
	UpdateAllViews(NULL, HINT_NEW);
	return TRUE;
}

/////////////////////////////////////////////////////////////////////////////
// CTreeEditorDoc diagnostics

#ifdef _DEBUG
void CTreeEditorDoc::AssertValid() const
{
	CDocument::AssertValid();
}

void CTreeEditorDoc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CTreeEditorDoc commands

void CTreeEditorDoc::OnFileSave() 
{
	if (m_strFileName.IsEmpty())
		OnFileSaveAs();
	else
		SaveFile();
}

void CTreeEditorDoc::GetFilter(char sFilter[], HINT_EXT ahe[])
{
	int k;
	char *name[FF_MAX_TYPES];
	char *text[FF_MAX_TYPES];

	for (k = 0; k < FF_MAX_TYPES; k++)
	{
		name[k] = m_apszExtension[ahe[k].m_ff].m_name;
		text[k] = m_apszExtension[ahe[k].m_ff].m_text;
	}

	sprintf(sFilter, 
		"%s (*.%s)|*.%s|"
		"%s (*.%s)|*.%s|"
		"%s (*.%s)|*.%s|"
		"All Files (*.*)|*.*||", 
		name[FF_TREE_TYPE],  text[FF_TREE_TYPE],  text[FF_TREE_TYPE], 
		name[FF_INDENT_TYPE], text[FF_INDENT_TYPE], text[FF_INDENT_TYPE],
		name[FF_CSV_TYPE],   text[FF_CSV_TYPE],   text[FF_CSV_TYPE]);

	for (k = 0; sFilter[k] != 0; k++)
		sFilter[k] = sFilter[k] == '|' ? '\0' : sFilter[k];
}

void CTreeEditorDoc::SaveFile()
{
	char dir[_MAX_DIR];
	char drive[_MAX_DRIVE];
	char ext[_MAX_EXT];
	char fname[_MAX_FNAME];
	int k;
	long lHint = HINT_LOAD_TREE_TYPE;

	if (!m_strFileName.IsEmpty())
	{
		_splitpath(m_strFileName, drive, dir, fname, ext);

		for(k = 0; k < ARRAY_SIZE(m_aheSave); k++)
		{
			if (strcmp(m_apszExtension[m_aheSave[k].m_ff].m_text, ext + 1) == 0)
			{
				lHint = m_aheSave[k].m_hint;
				break;
			}
		}
		SetTitle((LPCTSTR)m_strFileName);
		UpdateAllViews(NULL, lHint);
	}
}

// Checks if the modified flag is on. If so, it displays a warning message
// (The file was changed. Do you want to save or to discard the modifications?)

BOOL CTreeEditorDoc::SaveModified() 
{
	if (!IsModified())
		return TRUE;        // ok to continue

	CString prompt, sTitle;

	sTitle = GetTitle();
	prompt.Format("File %s has changed.\nDo you want to save the changes?",
		sTitle);
	switch (AfxMessageBox(prompt, MB_YESNOCANCEL))
	{
	case IDCANCEL:
		return FALSE;       // don't continue

	case IDYES:
		// If so, either Save or Update, as appropriate
		OnFileSave();
		break;

	case IDNO:
		// If not saving changes, revert the document
		SetModifiedFlag(false);
		break;

	default:
		ASSERT(FALSE);
		break;
	}
	return TRUE;    // keep going
}

void CTreeEditorDoc::OpenFile()
{
	char dir[_MAX_DIR];
	char drive[_MAX_DRIVE];
	char ext[_MAX_EXT];
	char fname[_MAX_FNAME];
	int k;
	long lHint = HINT_LOAD_TREE_TYPE;

	if(!m_strFileName.IsEmpty())
	{
		_splitpath(m_strFileName, drive, dir, fname, ext);

		for(k = 0; k < ARRAY_SIZE(m_aheLoad); k++)
		{
			if (strcmp(m_apszExtension[m_aheLoad[k].m_ff].m_text, ext + 1) == 0)
			{
				lHint = m_aheLoad[k].m_hint;
				break;
			}
		}
		SetTitle((LPCTSTR)m_strFileName);
		UpdateAllViews(NULL, lHint);
	}
}

void CTreeEditorDoc::OnFileSaveAs() 
{
	OPENFILENAME   ofn;
	char szFile[MAX_PATH] = TEXT("");
	char sFilter[256];

	GetFilter(sFilter, m_aheLoad);

	ZeroMemory(&ofn, sizeof(ofn));
	ofn.lStructSize         = sizeof(ofn);
	ofn.hwndOwner           = NULL;
	ofn.hInstance           = GetModuleHandle(NULL);
	ofn.lpstrFilter         = sFilter;
	ofn.lpstrCustomFilter   = NULL;
	ofn.nMaxCustFilter      = 0;
	ofn.nFilterIndex        = 1;
	ofn.nMaxFile            = _MAX_PATH;
	ofn.lpstrFileTitle      = NULL;
	ofn.nMaxFileTitle       = 0;
	ofn.lpstrInitialDir     = m_ExamplesPath;
	ofn.lpstrDefExt			= m_apszExtension[m_aheSave[0].m_ff].m_text;
	ofn.lpstrTitle          = "Save As";
	ofn.lpTemplateName      = MAKEINTRESOURCE(IDD_OPEN_DELIM_DIALOG);
	ofn.lpfnHook            = (LPOFNHOOKPROC)DelimiterHookProc;
	ofn.lCustData           = (DWORD)this;
	ofn.Flags               = OFN_EXPLORER | OFN_OVERWRITEPROMPT | OFN_HIDEREADONLY | 
									OFN_ENABLEHOOK | OFN_ENABLETEMPLATE | 0;
	ofn.lpstrFile = szFile;

	if (GetSaveFileName(&ofn))
	{
		m_strFileName = ofn.lpstrFile;
		SaveFile();
	}
}

void CTreeEditorDoc::OnFileOpen() 
{
	// Customize the common dialog: CFileDialog with a hook procedure to be able to ask
	// about the suitable delimiter.

	OPENFILENAME   ofn;
	char sFilter[256];
	char szFile[MAX_PATH] = TEXT("");

	if (!SaveModified())
		return;
	GetFilter(sFilter, m_aheLoad);

	ZeroMemory(&ofn, sizeof(ofn));
	ofn.lStructSize         = sizeof(ofn);
	ofn.hwndOwner           = NULL;
	ofn.hInstance           = GetModuleHandle(NULL);
	ofn.lpstrFilter         = sFilter;
	ofn.lpstrCustomFilter   = NULL;
	ofn.nMaxCustFilter      = 0;
	ofn.nFilterIndex        = 1;
	ofn.nMaxFile            = _MAX_PATH;
	ofn.lpstrFileTitle      = NULL;
	ofn.nMaxFileTitle       = 0;
	ofn.lpstrInitialDir     = m_ExamplesPath;
	ofn.lpstrDefExt			= m_apszExtension[m_aheLoad[0].m_ff].m_text;
	ofn.lpstrTitle          = "Open";
	ofn.lpTemplateName      = MAKEINTRESOURCE(IDD_OPEN_DELIM_DIALOG);
	ofn.lpfnHook            = (LPOFNHOOKPROC)DelimiterHookProc;
	ofn.lCustData           = (DWORD)this;
	ofn.Flags               = OFN_EXPLORER | OFN_OVERWRITEPROMPT | OFN_FILEMUSTEXIST |
								OFN_HIDEREADONLY | OFN_ENABLEHOOK | OFN_ENABLETEMPLATE | 0;
	ofn.lpstrFile = szFile;

	if (GetOpenFileName(&ofn))
	{
		m_strFileName = ofn.lpstrFile;
		OpenFile();
	}
}

BOOL CALLBACK DelimiterHookProc(HWND hWnd, UINT uMessage, WPARAM wParam, LPARAM lParam)
{
	static CTreeEditorDoc *pted = NULL;
	LPOFNOTIFY lpon;
	BOOL bIsCsvSelected;

	static int aid[] =
	{
		IDC_STATIC_GROUP,
		IDC_TAB,
		IDC_COMMA,
		IDC_OTHER,
		IDC_DELIMITER,
	}, k;
	static HWND ahCtrl[ARRAY_SIZE(aid)];

	switch(uMessage)
	{
	case WM_INITDIALOG:
		for (k = 0; k < ARRAY_SIZE(aid); k++)
		{
			ahCtrl[k] = GetDlgItem(hWnd, aid[k]);
			EnableWindow(ahCtrl[k], false);
		}

		pted = (CTreeEditorDoc *)((LPOPENFILENAME)(lParam))->lCustData;
		SendDlgItemMessage(hWnd, IDC_DELIMITER, EM_LIMITTEXT, 1, 0);
		SendDlgItemMessage(hWnd, IDC_DELIMITER, WM_SETTEXT, 0,(LPARAM) pted->m_szDelimiter); 
		CheckRadioButton(hWnd, IDC_TAB, IDC_OTHER, IDC_COMMA);
		break;

	case WM_COMMAND: 
		if(HIWORD (wParam) == EN_CHANGE && LOWORD(wParam) == IDC_DELIMITER)
		{
			// Get the character
			SendDlgItemMessage(hWnd, IDC_DELIMITER, EM_GETLINE,0,(LPARAM) pted->m_szDelimiter); 
			pted->m_szDelimiter[1] = 0;
		}
		if (HIWORD (wParam) == BN_CLICKED)
			EnableWindow(ahCtrl[4], LOWORD(wParam) == IDC_OTHER);
		break;

	case WM_NOTIFY:
		lpon = (LPOFNOTIFY) lParam; 
		if (lpon->hdr.code == CDN_FILEOK)
		{
			if (IsDlgButtonChecked(hWnd, IDC_TAB))
				strcpy(pted->m_szDelimiter, "\t");
			else if (IsDlgButtonChecked(hWnd, IDC_COMMA))
				strcpy(pted->m_szDelimiter, ",");
		}
		if (lpon->hdr.code == CDN_TYPECHANGE)
		{
			bIsCsvSelected = lpon->lpOFN->nFilterIndex == FF_CSV_TYPE + 1;
			for (k = 0; aid[k] != IDC_DELIMITER; k++)
				EnableWindow(ahCtrl[k], bIsCsvSelected);
		}
		break;
	}
	return FALSE;
}

BOOL CTreeEditorDoc::OnOpenDocument(LPCTSTR lpszPathName) 
{
	if (SaveModified())
	{
		m_strFileName = lpszPathName;
		OpenFile();
	}
	return TRUE;
}


void CTreeEditorDoc::OnDisplayDirectoryTree() 
{
	// Customize the common dialog: CFileDialog with a hook procedure to be able to ask
	// about the suitable delimiter.
	BROWSEINFO bi;
	LPMALLOC pMalloc = NULL;
	LPITEMIDLIST pidl = NULL;
	char szFileName[MAX_PATH];
	long lHint = HINT_LOAD_DIRECTORY;
	BOOL bRC;
	CString str;

	ZeroMemory(&bi, sizeof(BROWSEINFO));
	bi.ulFlags = BIF_RETURNONLYFSDIRS;
	
	if (!SaveModified())
		return;
	pidl = SHBrowseForFolder(&bi);
	if (pidl != NULL)
	{
		bRC = SHGetPathFromIDList(pidl, szFileName);
		if (!bRC)
		{
			AfxMessageBox("Invalid selection!");
			return;
		}
		m_strFileName = szFileName;
		SHGetMalloc(&pMalloc);
		pMalloc->Free(pidl);  
		pMalloc->Release(); 

		// When we read a directory, we dwr paths of the form:
		// X:\Subdirectory_1\...Subdirectory_n". Reading that is similar to reading CSV
		// files, where the delimiter is "\".
		strcpy(m_szDelimiter, "\\");

// Title is "Untitled"
//		>m_strFileName is used as the default file name , when the Save 
//		function (Ctrl+S) is called. If Ctrl+D was called, we cannot, of course, 
//		giving the tree name we built, the name of an existing directory. So, we reset
//		m_strFileName as soon as the directory is loaded, to force the user to choose a name, 
//		when he saves the tree. See last instructions of function:
//		void CEditTreeCtrl::OnLoadEntireTree(FILE_FORMAT ff, CTreeType &tt) after
//		......................
//		    if (ff == FF_DIRECTORY_TYPE)
//			{
//			}
		SetTitle("Untitled");
		UpdateAllViews(NULL, lHint);
	}
}

