//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by TreeEditor.rc
//
#define IDD_ABOUTBOX                    100
#define IDR_POPUP_MENU                  103
#define IDD_OPEN_DELIM_DIALOG           104
#define IDR_MAINFRAME                   128
#define IDR_TREEEDTYPE                  129
#define IDC_DROP_COPY_ROOT              130
#define IDC_DROP_MOVE_ABOVE             131
#define IDC_DROP_COPY_ABOVE             132
#define IDB_TREE                        138
#define IDC_NODROP                      140
#define IDC_DROP_MOVE_ROOT              142
#define IDC_DROP_COPY_SON               144
#define IDC_DROP_MOVE_SON               146
#define IDC_DELIMITER                   1000
#define IDC_STATIC_GROUP                1001
#define IDC_TAB                         2001
#define IDC_COMMA                       2002
#define IDC_OTHER                       2003
#define ID_RENAME                       32771
#define ID_CALCULATE_LEVEL              32772
#define IDC_DISPLAY_DIRECTORY_TREE      32773
#define ID_ADD_CHILD                    32775
#define ID_ADD_SIBLING                  32776
#define ID_SORT_SUBTREE_ALPHABETIC      32779
#define ID_SORT_SUBTREE_NUMERIC         32780
#define ID_DELETE_ITEM                  32786
#define ID_DELETE_ALL_ITEMS             32787
#define IDC_EXPAND_ALL_TREE             32799
#define ID_COLLAPSE_ALL_ENTIRE_TREE     32806
#define IDC_COUNT_SUBTREE               32808
#define IDC_COUNT_ENTIRE_TREE           32809

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        133
#define _APS_NEXT_COMMAND_VALUE         32781
#define _APS_NEXT_CONTROL_VALUE         1002
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
