#include "stdafx.h"
#include "TestIJL.h"
#include "TestIJLDoc.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

IMPLEMENT_DYNCREATE(CTestIJLDoc, CDocument)

BEGIN_MESSAGE_MAP(CTestIJLDoc, CDocument)
	//{{AFX_MSG_MAP(CTestIJLDoc)
	ON_UPDATE_COMMAND_UI(ID_FILE_SAVE_AS, OnUpdateFileSaveAs)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

CTestIJLDoc::CTestIJLDoc()
{
}

CTestIJLDoc::~CTestIJLDoc()
{
}

BOOL CTestIJLDoc::OnNewDocument()
{
	if (!CDocument::OnNewDocument())
		return FALSE;

	return TRUE;
}

void CTestIJLDoc::Serialize(CArchive& /*ar*/)
{
  ASSERT(FALSE); //Serialization is handled at a higher level
}

#ifdef _DEBUG
void CTestIJLDoc::AssertValid() const
{
	CDocument::AssertValid();
}

void CTestIJLDoc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif //_DEBUG


BOOL CTestIJLDoc::OnOpenDocument(LPCTSTR lpszPathName) 
{
  return m_Bitmap.Load(lpszPathName);
}

void CTestIJLDoc::DeleteContents() 
{
  //Free up the Memory used by the bitmap
	m_Bitmap.DeleteObject();

  //Let the parent do its thing
	CDocument::DeleteContents();
}

BOOL CTestIJLDoc::OnSaveDocument(LPCTSTR lpszPathName) 
{
  return m_Bitmap.Save(lpszPathName);	
}

void CTestIJLDoc::OnUpdateFileSaveAs(CCmdUI* pCmdUI) 
{
  pCmdUI->Enable(m_Bitmap.m_hObject != NULL);	
}

