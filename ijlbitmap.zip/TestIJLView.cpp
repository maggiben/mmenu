#include "stdafx.h"
#include "TestIJL.h"
#include "TestIJLDoc.h"
#include "TestIJLView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

IMPLEMENT_DYNCREATE(CTestIJLView, CScrollView)

BEGIN_MESSAGE_MAP(CTestIJLView, CScrollView)
	//{{AFX_MSG_MAP(CTestIJLView)
	ON_WM_ERASEBKGND()
	//}}AFX_MSG_MAP
	ON_COMMAND(ID_FILE_PRINT, CScrollView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_DIRECT, CScrollView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_PREVIEW, CScrollView::OnFilePrintPreview)
END_MESSAGE_MAP()

CTestIJLView::CTestIJLView()
{
}

CTestIJLView::~CTestIJLView()
{
}

BOOL CTestIJLView::PreCreateWindow(CREATESTRUCT& cs)
{
	return CScrollView::PreCreateWindow(cs);
}

void CTestIJLView::OnDraw(CDC* pDC)
{
	CTestIJLDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

  pDoc->m_Bitmap.Draw(pDC);
}

BOOL CTestIJLView::OnPreparePrinting(CPrintInfo* pInfo)
{
	// default preparation
	return DoPreparePrinting(pInfo);
}

void CTestIJLView::OnBeginPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
}

void CTestIJLView::OnEndPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
}

#ifdef _DEBUG
void CTestIJLView::AssertValid() const
{
	CScrollView::AssertValid();
}

void CTestIJLView::Dump(CDumpContext& dc) const
{
	CScrollView::Dump(dc);
}

CTestIJLDoc* CTestIJLView::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CTestIJLDoc)));
	return (CTestIJLDoc*)m_pDocument;
}
#endif //_DEBUG


BOOL CTestIJLView::OnEraseBkgnd(CDC* pDC) 
{
  CBrush br;
  br.CreateHatchBrush(HS_DIAGCROSS, RGB(0, 0, 0));

  if (GetDocument()->m_Bitmap.operator HBITMAP())
    FillOutsideRect(pDC, &br);
  else
  {
    CRect rClient;
    GetClientRect(&rClient);
    pDC->FillRect(&rClient, &br);
  }
  return TRUE;
}

void CTestIJLView::OnUpdate(CView* /*pSender*/, LPARAM /*lHint*/, CObject* /*pHint*/) 
{
  //Set the scroll sizes & force a redraw
	SetScrollSizes(MM_TEXT, GetDocument()->m_Bitmap.Size());
  Invalidate();
}

BOOL CTestIJLView::RealizePalette(BOOL bBackground)
{
  // We are going active, so realize our palette.
  CDC* pDC = GetDC();

  //Do the realization
  CPalette& palette = GetDocument()->m_Bitmap.Palette();
  CPalette* pOldPal = pDC->SelectPalette(&palette, bBackground);
  UINT nRemapped = pDC->RealizePalette();
  pDC->SelectPalette(pOldPal, TRUE);
  pDC->RealizePalette();
  palette.Detach();

  //Tidy up the DC
  ReleaseDC(pDC);

  // If any colors have changed or we are in the
  // background, repaint the lot.
  if (nRemapped || bBackground) 
    Invalidate(); // Repaint.
  
  return (nRemapped > 0); // TRUE if some colors changed.
}
