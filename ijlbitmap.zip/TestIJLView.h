class CTestIJLView : public CScrollView
{
protected: // create from serialization only
	CTestIJLView();
	DECLARE_DYNCREATE(CTestIJLView)

// Attributes
public:
	CTestIJLDoc* GetDocument();

public:
	//{{AFX_VIRTUAL(CTestIJLView)
	virtual void OnDraw(CDC* pDC);  // overridden to draw this view
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	virtual BOOL OnPreparePrinting(CPrintInfo* pInfo);
	virtual void OnBeginPrinting(CDC* pDC, CPrintInfo* pInfo);
	virtual void OnEndPrinting(CDC* pDC, CPrintInfo* pInfo);
	virtual void OnUpdate(CView* pSender, LPARAM lHint, CObject* pHint);
	//}}AFX_VIRTUAL

public:
	virtual ~CTestIJLView();
  BOOL RealizePalette(BOOL bBackground);

#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:
	//{{AFX_MSG(CTestIJLView)
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

#ifndef _DEBUG  // debug version in TestIJLView.cpp
inline CTestIJLDoc* CTestIJLView::GetDocument()
   { return (CTestIJLDoc*)m_pDocument; }
#endif
