#include "stdafx.h"
#include "TestIJL.h"
#include "MainFrm.h"
#include "TestIJLDoc.h"
#include "TestIJLView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


BOOL CMyDocManager::DoPromptFileName(CString& fileName, UINT nIDSTitle, DWORD lFlags, 
                                    BOOL bOpenFileDialog, CDocTemplate* pTemplate)
{
  //bring up the correct dialog
  if (bOpenFileDialog)
  {
    //Let the base class do its thing
    return CDocManager::DoPromptFileName(fileName, nIDSTitle, lFlags, bOpenFileDialog, pTemplate);
  }
  else
  {
    //Form a bmp version of the path name
    TCHAR pszPath[_MAX_PATH];
    TCHAR pszDrive[_MAX_DRIVE];
    TCHAR pszDir[_MAX_DIR];
    TCHAR pszFname[_MAX_FNAME];
    _tsplitpath(fileName, pszDrive, pszDir, pszFname, NULL);
    _tmakepath(pszPath, pszDrive, pszDir, pszFname, _T("bmp"));
    fileName = pszPath;

    CString sBmpFilter;
    VERIFY(sBmpFilter.LoadString(IDS_BMP_FILTER));  

    //We have to override the standard MFC save as dialog as
    //we can only save in BMP format
    CFileDialog dlg(FALSE, _T(".bmp"), fileName, OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT, sBmpFilter);
  	CString title;
  	VERIFY(title.LoadString(nIDSTitle));
    dlg.m_ofn.lpstrTitle = title;
    dlg.m_ofn.Flags |= lFlags;
    dlg.m_ofn.lpstrFile = fileName.GetBuffer(_MAX_PATH);
    BOOL bResult = dlg.DoModal() == IDOK ? TRUE : FALSE;
	  fileName.ReleaseBuffer();
	  return bResult;
  }
}





BEGIN_MESSAGE_MAP(CTestIJLApp, CWinApp)
	//{{AFX_MSG_MAP(CTestIJLApp)
	ON_COMMAND(ID_APP_ABOUT, OnAppAbout)
	//}}AFX_MSG_MAP
	ON_COMMAND(ID_FILE_NEW, CWinApp::OnFileNew)
	ON_COMMAND(ID_FILE_OPEN, CWinApp::OnFileOpen)
	ON_COMMAND(ID_FILE_PRINT_SETUP, CWinApp::OnFilePrintSetup)
END_MESSAGE_MAP()

CTestIJLApp::CTestIJLApp()
{
}

CTestIJLApp theApp;

BOOL CTestIJLApp::InitInstance()
{
  if (!AfxOleInit())
    return FALSE;
#ifdef _AFXDLL
	Enable3dControls();			// Call this when using MFC in a shared DLL
#else
	Enable3dControlsStatic();	// Call this when linking to MFC statically
#endif
	SetRegistryKey(_T("PJ Naughter"));

  //Use our version of the derived document manager
  m_pDocManager = new CMyDocManager;

	LoadStdProfileSettings();
    
	// Register document templates
	CSingleDocTemplate* pDocTemplate;
	pDocTemplate = new CSingleDocTemplate(
		IDR_MAINFRAME,
		RUNTIME_CLASS(CTestIJLDoc),
		RUNTIME_CLASS(CMainFrame),       // main SDI frame window
		RUNTIME_CLASS(CTestIJLView));
	AddDocTemplate(pDocTemplate);

	// Parse command line for standard shell commands, DDE, file open
	CCommandLineInfo cmdInfo;
	ParseCommandLine(cmdInfo);

	// Dispatch commands specified on the command line
	if (!ProcessShellCommand(cmdInfo))
		return FALSE;
	m_pMainWnd->ShowWindow(SW_SHOW);
	m_pMainWnd->UpdateWindow();
  m_pMainWnd->DragAcceptFiles();

	return TRUE;
}

void CTestIJLApp::OnAppAbout()
{
	CAboutDlg aboutDlg;
	aboutDlg.DoModal();
}





CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


