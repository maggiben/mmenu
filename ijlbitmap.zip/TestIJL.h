#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"       // main symbols

class CTestIJLApp : public CWinApp
{
public:
	CTestIJLApp();

	//{{AFX_VIRTUAL(CTestIJLApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

	//{{AFX_MSG(CTestIJLApp)
	afx_msg void OnAppAbout();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

protected:
	//{{AFX_MSG(CAboutDlg)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

class CMyDocManager : public CDocManager
{
public:
  CMyDocManager() {};
  virtual ~CMyDocManager() {};

  virtual BOOL DoPromptFileName(CString& fileName, UINT nIDSTitle, DWORD lFlags, 
                                BOOL bOpenFileDialog, CDocTemplate* pTemplate);
};
