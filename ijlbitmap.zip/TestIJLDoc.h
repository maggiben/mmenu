#include "IJLBitmap.h"

class CTestIJLDoc : public CDocument
{
protected: // create from serialization only
	CTestIJLDoc();
	DECLARE_DYNCREATE(CTestIJLDoc)

// Attributes
public:
  CIJLBitmap m_Bitmap;


	//{{AFX_VIRTUAL(CTestIJLDoc)
	virtual BOOL OnNewDocument();
	virtual void Serialize(CArchive& ar);
	virtual BOOL OnOpenDocument(LPCTSTR lpszPathName);
	virtual void DeleteContents();
	virtual BOOL OnSaveDocument(LPCTSTR lpszPathName);
	//}}AFX_VIRTUAL

public:
	virtual ~CTestIJLDoc();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(CTestIJLDoc)
	afx_msg void OnUpdateFileSaveAs(CCmdUI* pCmdUI);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

