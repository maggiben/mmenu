#include "stdafx.h"
#include "TestIJL.h"
#include "MainFrm.h"
#include "TestIJLDoc.h"
#include "TestIJLView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

IMPLEMENT_DYNCREATE(CMainFrame, CFrameWnd)

BEGIN_MESSAGE_MAP(CMainFrame, CFrameWnd)
	//{{AFX_MSG_MAP(CMainFrame)
	ON_WM_CREATE()
	ON_WM_PALETTECHANGED()
	ON_WM_QUERYNEWPALETTE()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

static UINT indicators[] =
{
	ID_SEPARATOR,           // status line indicator
};

CMainFrame::CMainFrame()
{
}

CMainFrame::~CMainFrame()
{
}

int CMainFrame::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
	if (CFrameWnd::OnCreate(lpCreateStruct) == -1)
		return -1;
	
	if (!m_wndToolBar.Create(this) ||
		!m_wndToolBar.LoadToolBar(IDR_MAINFRAME))
	{
		TRACE0("Failed to create toolbar\n");
		return -1;      // fail to create
	}

	if (!m_wndStatusBar.Create(this) ||
		!m_wndStatusBar.SetIndicators(indicators,
		  sizeof(indicators)/sizeof(UINT)))
	{
		TRACE0("Failed to create status bar\n");
		return -1;      // fail to create
	}

	m_wndToolBar.SetBarStyle(m_wndToolBar.GetBarStyle() |
		CBRS_TOOLTIPS | CBRS_FLYBY | CBRS_SIZE_DYNAMIC);

	m_wndToolBar.EnableDocking(CBRS_ALIGN_ANY);
	EnableDocking(CBRS_ALIGN_ANY);
	DockControlBar(&m_wndToolBar);

	return 0;
}

BOOL CMainFrame::PreCreateWindow(CREATESTRUCT& cs)
{
	return CFrameWnd::PreCreateWindow(cs);
}

#ifdef _DEBUG
void CMainFrame::AssertValid() const
{
	CFrameWnd::AssertValid();
}

void CMainFrame::Dump(CDumpContext& dc) const
{
	CFrameWnd::Dump(dc);
}

#endif //_DEBUG

void CMainFrame::OnPaletteChanged(CWnd* pFocusWnd) 
{
  if (pFocusWnd != this)
  {
    //Get a pointer to the main view and ask it to realize its palette in the background
    CWinApp* pApp = AfxGetApp();
    POSITION posTemplate = pApp->GetFirstDocTemplatePosition();
    CDocTemplate* pDocTemplate = pApp->GetNextDocTemplate(posTemplate);
    ASSERT(pDocTemplate);
    POSITION posDoc = pDocTemplate->GetFirstDocPosition();
    CDocument* pDoc = pDocTemplate->GetNextDoc(posDoc);
    ASSERT(pDoc);
    POSITION posView = pDoc->GetFirstViewPosition();
    CTestIJLView* pView = (CTestIJLView*) pDoc->GetNextView(posView);
    ASSERT(pView);
    ASSERT(pView->IsKindOf(RUNTIME_CLASS(CTestIJLView)));
    pView->RealizePalette(TRUE); 
  }
}

BOOL CMainFrame::OnQueryNewPalette() 
{
  //Get a pointer to the main view and ask it to realize its palette in the foreground
  CWinApp* pApp = AfxGetApp();
  POSITION posTemplate = pApp->GetFirstDocTemplatePosition();
  CDocTemplate* pDocTemplate = pApp->GetNextDocTemplate(posTemplate);
  ASSERT(pDocTemplate);
  POSITION posDoc = pDocTemplate->GetFirstDocPosition();
  CDocument* pDoc = pDocTemplate->GetNextDoc(posDoc);
  ASSERT(pDoc);
  POSITION posView = pDoc->GetFirstViewPosition();
  CTestIJLView* pView = (CTestIJLView*) pDoc->GetNextView(posView);
  ASSERT(pView);
  ASSERT(pView->IsKindOf(RUNTIME_CLASS(CTestIJLView)));
  return pView->RealizePalette(FALSE); 
}
