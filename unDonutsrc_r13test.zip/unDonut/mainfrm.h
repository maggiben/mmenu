// MainFrm.h : interface of the CMainFrame class
// �{�C�ŏ������������Ȃ��Ă���(minit)
/////////////////////////////////////////////////////////////////////////////
#pragma once

#include "MenuControl.h"
//#include "MainFrameFileDropTarget.h"
#include "CmbboxPrxy.h"
#include "AccelManager.h"
#include "stdafx.h"
#include "resource.h"
#include <math.h>

#include <DockingFrame.h>
#include <sstate.h>
#include <dwstate.h>
#include <dbstate.h>
#include "DockingPluginManager.h"

#include "DonutExplorerBar.h"
#include "PluginBar.h"

#include "DonutPFunc.h"


#include "dialog/DebugWindow.h"
#include "dialog/OpenURLDialog.h"
#include "PropertySheet.h" 
#include "MenuEncode.h"
#include "RebarSupport.h" 
#include "StyleSheetOption.h"
#include "ExStyle.h"
#include "DialogHook.h"
#include "MenuDropTargetWindow.h"
#include "WindowCloseChecker.h"


#define CWM_INITIALIZE	(WMDF_LAST+1)

#ifdef _DEBUG
	const bool _Donut_MainFrame_traceOn = false;
	#define dmfTRACE if (_Donut_MainFrame_traceOn) ATLTRACE
#else
	#define dmfTRACE
#endif

static const CLSID CLSID_IEnumPrivacyRecords =
	{ 0x3050f844, 0x98b5, 0x11cf, { 0xbb, 0x82, 0x00, 0xaa, 0x00, 0xbd, 0xce, 0x0b } };

#define ENT_READ_ACCEL 2

#ifndef WM_XBUTTONDOWN
#define WM_XBUTTONDOWN                  0x020B
#define WM_XBUTTONUP                    0x020C
#define GET_KEYSTATE_WPARAM(wParam)     (LOWORD(wParam))
#define GET_XBUTTON_WPARAM(wParam)      (HIWORD(wParam))
#define MK_XBUTTON1         0x0020
#define MK_XBUTTON2         0x0040
#define XBUTTON1      0x0001
#define XBUTTON2      0x0002
#endif

const UINT STDBAR_ID[] = 
{ATL_IDW_COMMAND_BAR, ATL_IDW_TOOLBAR, IDC_ADDRESSBAR, IDC_MDITAB, IDC_LINKBAR, IDC_SEARCHBAR};
const UINT STDBAR_STYLE[] =
{RBBS_USECHEVRON, RBBS_USECHEVRON|RBBS_BREAK, RBBS_BREAK, RBBS_BREAK, RBBS_USECHEVRON|RBBS_BREAK, RBBS_BREAK}; 
const LPTSTR STDBAR_TEXT[] = 
//{NULL, NULL, _T("�A�h���X"), NULL, _T("�����N"), _T("����")};
{_T(""), _T(""), _T("�A�h���X"), NULL, _T("�����N"), _T("����")}; // memo. NULL���ƈ�ԍ��̃{�^�����V�F�u�����Ɋ܂߂邱�Ƃ��ł��Ȃ�
#define STDBAR_COUNT	6

void _PrivateTerm();

class CMainFrame : 
		//public CMDIFrameWindowImpl<CMainFrame>,
		public dockwins::CMDIDockingFrameImpl<CMainFrame>,
		public CMessageFilter, public CIdleHandler,
		public CAppCommandHandler<CMainFrame>,
		public CUpdateCmdUI<CMainFrame>,
		public CWindowMenuCommandHandler<CMainFrame>,
		public CDDEMessageHandler<CMainFrame>,
		public CMDIFrameTitleUpsideDownMessageHandlerWeb<CMainFrame>,
		public CHelpMessageLine<CMainFrame>,
		public CMSMouseWheelMessageHandler<CMainFrame>,
		public CMainFrameFileDropTarget<CMainFrame>,
		public CReBarVerticalBorder<CMainFrame>
{
public:
// Declarelations
	DECLARE_FRAME_WND_CLASS(_T("WTL:Donut"), IDR_MAINFRAME)
	//DECLARE_MTL_REBAR_UPDATELAYOUT() //����͔p�~����UpdateLayout�֐�������������
	//typedef CMDIFrameWindowImpl<CMainFrame> baseClass;
	typedef dockwins::CMDIDockingFrameImpl<CMainFrame> baseClass;

// Constants
	enum { _nPosFavoriteMenu = 3, _nPosFavGroupMenu = 2, _nPosViewMenu = 2,
		_nPosFavoriteMenuOfTab = 2, _nPosMRU = 12, _nPosWindowMenu = 5, _nWindowMenuItemCount = 14,
		_nPosCssMenu = 4, _nPosSubCssMenu = 14 , _nPosEncodeMenu = 2 ,_nPosEncodeMenuSub = 18};

// Daba members
	CCommandBarCtrl2 m_CmdBar;
	CDonutToolBar m_ToolBar;
	CDonutLinksBarCtrl<CMainFrame> m_LinkBar;
	CDonutAddressBar m_AddressBar;
	CMDITabCtrl	m_MDITab;
	CDonutSearchBar m_SearchBar;

	CDonutReBarCtrl m_ReBar;

//	CMultiPaneStatusBarCtrl m_wndStatusBar;
	CDonutStatusBarCtrl m_wndStatusBar;
	CProgressBarCtrl		m_wndProgress;
	CComboBoxPrxyR			m_cmbBox;

	CMainOption m_MainOption;
	CDonutSecurityZone m_secZone;

	CDonutExplorerBar m_ExplorerBar;

	CDonutFavoritesMenu<CMainFrame>		m_FavoriteMenu;
	CFavoriteGroupMenu<CMainFrame>		m_FavGroupMenu;
	CExplorerMenuImpl<CStyleSheetMenu>	m_styleSheetMenu;
	CExplorerMenuImpl<CExplorerMenu>	m_ScriptMenu;
	CMenu								m_ScriptMenuMst;

	//added by minit
	//for Custom Context Dropmenu
	CDonutFavoritesMenu<CMainFrame>		m_DropFavoriteMenu;
	CFavoriteGroupMenu<CMainFrame>		m_DropFavGroupMenu;
	CExplorerMenuImpl<CExplorerMenu>	m_DropScriptMenu;
	//for EncodeMenu
	CMenuEncode		m_MenuEncode;
	

	CMenuControl m_mcCmdBar;
	CMenuControl m_mcToolBar;

	CContainedWindow m_wndMDIClient;
	CFont		m_font;

	// FullScreen support
	BOOL m_bStatusBarVisibleUnlessFullScreen;

	UINT m_nBackUpTimerID;
	CMenuHandle m_menuWindow;

	HWND m_hWndFocus;

	CSimpleMap<UINT, BOOL>				m_mapToolbarOldVisible;

	BOOL m_bShow;

	CMenuDropTargetWindow m_wndMenuDropTarget;

	HANDLE m_hGroupThread;
	CDebugWindow m_wndDebug;

	CDonutClipBoardBarContainer m_ClipBar;
	CDonutPanelBar m_PanelBar;
	CPluginBar m_PluginBar;
	CDockingPluginManager m_DockingPluginManager;
	//CSampleDockingWindow m_wndDocking;
	sstate::CWindowStateMgr	m_stateMgr;

	void SetStdRebarBandInfo( CReBarBandInfo* pRbis );

	// Constructor/Destructor
	CMainFrame() :
		m_FavoriteMenu(this, ID_INSERTPOINT_FAVORITEMENU),
		m_FavGroupMenu(this, ID_INSERTPOINT_GROUPMENU),
		m_styleSheetMenu(ID_INSERTPOINT_CSSMENU, _T("(empty)"), ID_INSERTPOINT_CSSMENU, ID_INSERTPOINT_CSSMENU_END),
		m_LinkBar(this, ID_INSERTPOINT_FAVORITEMENU),
		m_nBackUpTimerID(0), /*m_FavTree(this), */m_wndMDIClient(this, 1),
		CDDEMessageHandler<CMainFrame>(_T("Donut")), m_hWndFocus(NULL),
		m_ScriptMenu(ID_INSERTPOINT_SCRIPTMENU, _T("(empty)"), ID_INSERTPOINT_SCRIPTMENU, ID_INSERTPOINT_SCRIPTMENU_END),

		m_DropFavoriteMenu(this, ID_INSERTPOINT_FAVORITEMENU),
		m_DropFavGroupMenu(this, ID_INSERTPOINT_GROUPMENU),
		m_DropScriptMenu(ID_INSERTPOINT_SCRIPTMENU, _T("(empty)"), ID_INSERTPOINT_SCRIPTMENU, ID_INSERTPOINT_SCRIPTMENU_END),

		m_bShow(FALSE),
		m_hGroupThread(NULL)
	{
	}

	~CMainFrame()
	{
		if (m_wndMDIClient.IsWindow())
			m_wndMDIClient.UnsubclassWindow();
	}

// Overrides
	//�e�E�B���h�E��(��ɃL�[)���b�Z�[�W��]������
	virtual BOOL PreTranslateMessage(MSG* pMsg)
	{
		//�R�}���h�o�[(���j���[)
		if (m_CmdBar.PreTranslateMessage(pMsg))	return TRUE;

		//�A�h���X�o�[
		BYTE ptFlag = m_AddressBar.PreTranslateMessage(pMsg);
		if (ptFlag == _MTL_TRANSLATE_HANDLE)	return TRUE;
		else if (ptFlag == _MTL_TRANSLATE_WANT)	return FALSE;

		//�����o�[
		ptFlag = m_SearchBar.PreTranslateMessage(pMsg);
		if (ptFlag == _MTL_TRANSLATE_HANDLE)	return TRUE;
		else if (ptFlag == _MTL_TRANSLATE_WANT) return FALSE;

		//���N���X �v���O�C������ɏ�������
		if (baseClass::PreTranslateMessage(pMsg)) return TRUE;

		//�v���O�C���o�[
		if (m_PluginBar.PreTranslateMessage(pMsg)) return TRUE;

		//�v���O�C���}�l�[�W��
		if (m_DockingPluginManager.PreTranslateMessage(pMsg)) return TRUE;

		//�G�N�X�v���[���o�[
		if (m_ExplorerBar.PreTranslateMessage(pMsg)) return TRUE;

		//�A�N�e�B�u�E�`���h�E�E�B���h�E
		HWND hWndActive = MDIGetActive();
		if (pMsg->message==WM_MBUTTONDOWN && hWndActive!=NULL && ::IsChild(hWndActive, pMsg->hwnd))
		{
			CString strKey;
			strKey = _T("LinkOpenBtnM");

			DWORD dwLinkOpenBtnM=0;
			CIniSection pr;
			pr.Open(_GetFilePath(_T("MouseEdit.ini")), _T("MouseCtrl"));
			pr.QueryValue(dwLinkOpenBtnM, strKey);
			if (dwLinkOpenBtnM)
			{
				::SendMessage(pMsg->hwnd, WM_LBUTTONDOWN, 0, pMsg->lParam);

				int nTabCnt = m_MDITab.GetItemCount();
				LRESULT res = ::SendMessage(pMsg->hwnd, WM_COMMAND, dwLinkOpenBtnM, 0);
				if (m_MDITab.GetItemCount()!=nTabCnt)
					return TRUE;

				::SendMessage(pMsg->hwnd, WM_LBUTTONUP, 0, pMsg->lParam);
			}
		}

		//�}�E�X�W�F�X�`���[��
		if (pMsg->message==WM_RBUTTONDOWN && OnRButtonHook(pMsg)) return TRUE;

		//�^�񒆃{�^��
		if (pMsg->message == WM_XBUTTONUP)
		{
			if (OnXButtonUp(GET_KEYSTATE_WPARAM(pMsg->wParam), GET_XBUTTON_WPARAM(pMsg->wParam), CPoint(GET_X_LPARAM(pMsg->lParam), GET_Y_LPARAM(pMsg->lParam))))
				return TRUE;
		}

		//BHO
		if (TranslateMessageToBHO(pMsg)) return TRUE;

		HWND hWnd = MDIGetActive();
		if (hWnd != NULL && (BOOL)::SendMessage(hWnd, WM_FORWARDMSG, 0, (LPARAM)pMsg))
			return TRUE;

		return FALSE;// IsDialogMessage(pMsg);
	}

	void UpdateLayout(BOOL bResizeBars = TRUE)
	{
		CRect rc;
		GetClientRect(&rc);
		if (bResizeBars) {
			_UpdateReBarPosition(rc);
		}
		CClientDC dc(m_hWnd);
		_DoPaintReBarBorders(dc.m_hDC);
		UpdateBarsPosition(rc, bResizeBars);
		_InflateReBarBordersRect(rc);
#ifdef DF_AUTO_HIDE_FEATURES
		m_ahManager.UpdateLayout(dc,rc);
#endif
		m_vPackage.UpdateLayout(rc);
		Draw(dc);
	}

	BOOL OnXButtonUp(WORD wKeys, WORD wButton, CPoint point)
	{
		CIniSection pr;
		pr.Open(_GetFilePath(_T("MouseEdit.ini")), _T("MouseCtrl"));

		CString strKey;
		switch(wButton)
		{
		case XBUTTON1: strKey = _T("Side1");	break;
		case XBUTTON2: strKey = _T("Side2");	break;
		}

		DWORD dwCommand=0;
		pr.QueryValue(dwCommand, strKey);
		if (dwCommand==0)
			return FALSE;

		::SendMessage(m_hWnd, WM_COMMAND, dwCommand, 0);
		return TRUE;
	}


	// Mouse Gesture
	BOOL OnRButtonHook(MSG* pMsg)
	{
		HWND hChildWnd = MDIGetActive();
		if (hChildWnd)
		{
			BOOL bUsedMouseGesture = (BOOL)::SendMessage(hChildWnd, WM_USER_USED_MOUSE_GESTURE, 0, 0);
			if (bUsedMouseGesture==FALSE)
				return FALSE;
		}


		::SetCapture(m_hWnd);
		
		CPoint ptDown, ptUp, ptBefor;
		ptDown.x = GET_X_LPARAM(pMsg->lParam); 
		ptDown.y = GET_Y_LPARAM(pMsg->lParam);
		::ClientToScreen(pMsg->hwnd, &ptDown);

		ptUp = ptBefor = ptDown;
		int nAng1=-1, nAng2=-1;

		CIniSection pr;
		pr.Open(_GetFilePath(_T("MouseEdit.ini")), _T("MouseCtrl"));

		CString strMove, strMark1, strMark2;
		CString strMsg;

		DWORD dwTime=-1;

		HWND hWndHist=m_hWnd;
		HWND hWnd=NULL;
		BOOL bNoting=TRUE;
		MSG msg;
		do {
			if (::GetCapture() != hWndHist)	break;
			if (m_hWnd != hWndHist)	break;
			if (::GetMessage(&msg, NULL, 0, 0)==FALSE) continue;

			int nDiff=0;
			long lRet=0;
			DWORD dwCommand=0;
			BOOL bNeedFresh=FALSE, bBreak=FALSE;
			switch (msg.message)
			{
			case WM_MOUSEWHEEL:
				dwCommand = GetMouseWheelCmd((short)HIWORD(msg.wParam));
				break;

			case WM_LBUTTONUP:
			case WM_MBUTTONUP:
				dwCommand = GetMouseButtonUpCmd(msg.message);
				break;

			case WM_XBUTTONUP:
				dwCommand = GetMouseButtonUpCmd(msg.message, GET_XBUTTON_WPARAM(msg.wParam));
				break;

			case WM_MOUSEMOVE:
				ptUp.x = GET_X_LPARAM(msg.lParam); 
				ptUp.y = GET_Y_LPARAM(msg.lParam);
				::ClientToScreen(msg.hwnd, &ptUp);

				nDiff=(int)(sqrt(pow(ptBefor.x-ptUp.x, 2) + pow(ptBefor.y-ptUp.y, 2)));
				if (nDiff<10) break;
				nAng1 = (int)_GetAngle(ptBefor, ptUp);
				ptBefor = ptUp;

				if (nAng1<45 || nAng1>315) 			strMark1 = _T("��");
				else if (nAng1>=45 && nAng1<=135)	strMark1 = _T("��");
				else if (nAng1>135 && nAng1<225)	strMark1 = _T("��");
				else if (nAng1>=225 && nAng1<=315)	strMark1 = _T("��");

				if (strMark1==strMark2)
				{
					DWORD dwTimeNow = ::GetTickCount();
					if ((dwTimeNow-dwTime)>300)
					{
						strMark2 = _T("");
						dwTime = dwTimeNow;
					}
				}

				if (strMark1!=strMark2)
				{
					strMove += strMark1;
					strMark2 = strMark1;

					DWORD dwCommand=0;
					pr.QueryValue(dwCommand, strMove);
					CString strCmdName;
					if (dwCommand!=0)
					{
						CString strTemp;
						CToolTipManager::LoadToolTipText(dwCommand, strTemp);
						strCmdName.Format("[ %s ]", strTemp);
					}

					strMsg.Format("�W�F�X�`���[ : %s %s", strMove, strCmdName);
					::SetWindowText(m_hWndStatusBar, strMsg);
				}
				dwTime = ::GetTickCount();
				break;

			case WM_KEYDOWN:
				hWnd = MDIGetActive();
				if (hWnd != NULL) SendMessage(hWnd, WM_FORWARDMSG, 0, (LPARAM)&msg);
				break;
			default:
				DispatchMessage(&msg);
				break;
			}

			switch (dwCommand)
			{
			case ID_FILE_CLOSE:
				hWnd = MDIGetActive();
				if (hWnd==NULL) break;

				::PostMessage(hWnd, WM_COMMAND, ID_FILE_CLOSE, 0);
				//::PostMessage(hWnd, WM_CLOSE, 0, 0);
				bNoting = FALSE;
				bNeedFresh = TRUE;
				//goto NEXT;
				break;

			case ID_GET_OUT:				// �ޔ�
			case ID_VIEW_FULLSCREEN:		// �S�̕\��
			case ID_VIEW_UP:				// ���
			case ID_VIEW_BACK:				// �O�ɖ߂�
			case ID_VIEW_FORWARD:			// ���ɐi��
			case ID_VIEW_STOP_ALL:			// ���ׂĒ��~
			case ID_VIEW_REFRESH_ALL:		// ���ׂčX�V
			case ID_WINDOW_CLOSE_ALL:		// ���ׂĕ���
			case ID_WINDOW_CLOSE_EXCEPT:	// ����ȊO����
				::PostMessage(m_hWnd, WM_COMMAND, dwCommand, 0);
				bNoting = FALSE;
				bBreak = TRUE;
				break;

			case 0:
				break;
			default:
				::PostMessage(m_hWnd, WM_COMMAND, dwCommand, 0);
				bNoting = FALSE;
				bNeedFresh = TRUE;
				break;
			}

			if (bNeedFresh)
			{
				hWnd = MDIGetActive();
				if (hWnd) ::RedrawWindow(hWnd, NULL, NULL, RDW_UPDATENOW);
			}

			if(!(GetAsyncKeyState(VK_RBUTTON) & 0x80000000) && msg.message!=WM_RBUTTONUP)
			{
				MSG msgR;
				if(::PeekMessage(&msgR,NULL,0,0,PM_NOREMOVE)==0){
					break;
				}
			}

		} while (msg.message!=WM_RBUTTONUP);

		::ReleaseCapture();
		
		if (bNoting)
		{
			ptUp.x = GET_X_LPARAM(msg.lParam); 
			ptUp.y = GET_Y_LPARAM(msg.lParam);
			::ClientToScreen(msg.hwnd, &ptUp);

			::SetWindowText(m_hWndStatusBar, _T(""));

			DWORD dwCommand=0;
			pr.QueryValue(dwCommand, strMove);
			
			if (dwCommand!=0)
			{
				::SendMessage(m_hWnd, WM_COMMAND, dwCommand, 0);
				bNoting = FALSE;
			}
			else if (dwCommand==-1)
				return TRUE;

		}

		if (bNoting && strMove.IsEmpty())
		{
			::ScreenToClient(pMsg->hwnd, &ptUp);
			pMsg->lParam = MAKELONG(ptUp.x, ptUp.y);

			::PostMessage(pMsg->hwnd, WM_RBUTTONUP, pMsg->wParam, pMsg->lParam);
		}

		return !bNoting;
	}

	DWORD GetMouseWheelCmd(short nWheel)
	{
		CIniSection pr;
		pr.Open(_GetFilePath(_T("MouseEdit.ini")), _T("MouseCtrl"));

		DWORD dwCommand=0;
		CString strKey;
		if (nWheel>0)
			strKey = _T("WHEEL_UP");
		else
			strKey = _T("WHEEL_DOWN");
		pr.QueryValue(dwCommand, strKey);
		return dwCommand;
	}

	DWORD GetMouseButtonUpCmd(UINT uMsg, UINT nXButton=0)
	{
		CIniSection pr;
		pr.Open(_GetFilePath(_T("MouseEdit.ini")), _T("MouseCtrl"));

		DWORD dwCommand=0;
		CString strKey;
		switch(uMsg)
		{
		case WM_LBUTTONUP:
			strKey = _T("LButtonUp");
			break;
		case WM_MBUTTONUP:
			strKey = _T("MButtonUp");
			break;
		case WM_XBUTTONUP:
			strKey.Format("XButtonUp%d", nXButton);
			break;
		}

		pr.QueryValue(dwCommand, strKey);
		return dwCommand;
	}

	virtual BOOL OnIdle()
	{
		// Note. under 0.01 sec (in dbg-mode on 330mhz cpu)
		CmdUIUpdateToolBars();
		CmdUIUpdateStatusBar(m_hWndStatusBar, ID_DEFAULT_PANE);
		CmdUIUpdateStatusBar(m_hWndStatusBar, ID_SECURE_PANE);
		CmdUIUpdateStatusBar(m_hWndStatusBar, ID_PRIVACY_PANE);
		CmdUIUpdateChildWindow(m_hWndStatusBar, IDC_PROGRESS);
		m_mcCmdBar.UpdateMDIMenuControl();
		_FocusChecker();

		if (_check_flag(MAIN_EX_KILLDIALOG, CMainOption::s_dwMainExtendedStyle))
			CDialogKiller2::KillDialog();

		return FALSE;
	}

	void _OnIdleCritical()
	{
		if (MtlIsApplicationActive(m_hWnd)) {
			CmdUIUpdateToolBars();
			CmdUIUpdateChildWindow(m_hWndStatusBar, IDC_PROGRESS);
		}

		_FocusChecker();

		if (_check_flag(MAIN_EX_KILLDIALOG, CMainOption::s_dwMainExtendedStyle))
			CDialogKiller2::KillDialog();
	}

	bool OnDDEOpenFile(const CString& strFileName)
	{
		dmfTRACE(_T("CMainFrame::OnDDEOpenFile(%s)\n"), strFileName);
		OnUserOpenFile(strFileName, DonutGetStdOpenFlag());
		if (CStartUpOption::s_dwActivate) MtlSetForegroundWindow(m_hWnd); // UDT DGSTR ( added by dai
		return true;
	}

#define RELECT_STATUSBAR_DRAWITEM_MESSAGE() \
	{ \
		LPDRAWITEMSTRUCT lpdis = (LPDRAWITEMSTRUCT)lParam; \
		if(uMsg == WM_DRAWITEM && lpdis->hwndItem == m_wndStatusBar.m_hWnd){ \
			bHandled = TRUE; \
			lResult = ReflectNotifications(uMsg, wParam, lParam, bHandled); \
			if(bHandled) \
				return TRUE; \
		} \
	}

// Message map
BEGIN_MSG_MAP(CMainFrame)
	COMMAND_EXMENU_RANGE(EXMENU_FIRST,EXMENU_LAST)
	RELECT_STATUSBAR_DRAWITEM_MESSAGE()	

	

	PASS_MSG_MAP_MENUOWNER_TO_EXPMENU_DEFAULT(m_FavGroupMenu)
	PASS_MSG_MAP_MENUOWNER_TO_EXPMENU_DEFAULT(m_FavoriteMenu)
	PASS_MSG_MAP_MENUOWNER_TO_EXPMENU_DEFAULT(m_styleSheetMenu)
	PASS_MSG_MAP_MENUOWNER_TO_EXPMENU_DEFAULT(m_ScriptMenu)

	PASS_MSG_MAP_MENUOWNER_TO_EXPMENU(m_DropFavGroupMenu)
	PASS_MSG_MAP_MENUOWNER_TO_EXPMENU(m_DropFavoriteMenu)
	PASS_MSG_MAP_MENUOWNER_TO_EXPMENU(m_DropScriptMenu)
	
	CHAIN_MSG_MAP_MEMBER(m_MenuEncode)

	CHAIN_MSG_MAP(CUpdateCmdUI<CMainFrame>)

	MESSAGE_HANDLER(WM_CREATE, OnCreate)
	MESSAGE_HANDLER(CWM_INITIALIZE, OnFrameWorkInitialized)
	MSG_WM_CLOSE(OnClose)
	MSG_WM_DESTROY(OnDestroy)
	MSG_WM_ENDSESSION(OnEndSession)
	USER_MSG_WM_NEWINSTANCE(OnNewInstance)
	MSG_WM_USER_MDICHILD(OnMDIChild)
	
	

	MSG_WM_USER_OPENFILE(OnUserOpenFile)
	MSG_WM_USER_GET_ACTIVE_IWEBBROWSER()

	USER_MSG_WM_UPDATE_TITLEBAR(UpdateTitleBar)			// UDT DGSTR

	MESSAGE_HANDLER(MYWM_NOTIFYICON, OnMyNotifyIcon)	// UDT DGSTR ( SystemTrayIcon Handler )
	COMMAND_ID_HANDLER_EX(ID_GET_OUT, OnGetOut)			// UDT DGSTR
	USER_MSG_WM_UPDATE_EXPBAR(UpdateExpBar)				// UDT DGSTR

	MSG_WM_USER_GET_ACTIVE_WINDOW()
	MSG_WM_USER_BROWSER_CAN_SETFOCUS(OnBrowserCanSetFocus)
	MSG_WM_ACTIVATE(OnActivate)

	
	
	MESSAGE_HANDLER(WM_MENUDRAG,OnMenuDrag)
	MESSAGE_HANDLER(WM_MENUGETOBJECT,OnMenuGetObject)
	
	// map custom draw notifycation to addressbar
	MESSAGE_HANDLER(WM_NOTIFY, OnNotify)

	HANDLE_MESSAGE(WM_MDISETMENU)
	HANDLE_MESSAGE(WM_SETFOCUS)							// default handler will set focus to server window

	MSG_WM_TIMER(OnTimer)
	MSG_WM_MOUSEWHEEL(OnMouseWheel)
	DEBUG_CHECK_FOCUS_COMMAND_ID_HANDLER_EX()


	COMMAND_ID_HANDLER(ID_APP_ABOUT, OnAppAbout)
	COMMAND_RANGE_HANDLER(ID_RECENTDOCUMENT_FIRST, ID_RECENTDOCUMENT_LAST, OnFileRecent)
	COMMAND_RANGE_HANDLER(ID_FILE_MRU_FIRST, ID_FILE_MRU_LAST, OnFileRecent)
	COMMAND_ID_HANDLER(ID_FILE_NEW, OnFileNew)
	COMMAND_ID_HANDLER(ID_FILE_OPEN, OnFileOpen)
	COMMAND_ID_HANDLER_EX(ID_FILE_NEW_HOME, OnFileNewHome)
	COMMAND_ID_HANDLER_EX(ID_FILE_NEW_CLIPBOARD, OnFileNewClipBoard)
	COMMAND_ID_HANDLER_EX(ID_FILE_NEW_CLIPBOARD2, OnFileNewClipBoard2)
	COMMAND_ID_HANDLER_EX(ID_FILE_NEW_CLIPBOARD_EX, OnFileNewClipBoardEx)
	COMMAND_ID_HANDLER_EX(ID_FILE_NEW_BLANK, OnFileNewBlank)
	COMMAND_ID_HANDLER_EX(ID_FILE_NEW_COPY, OnFileNewCopy)
	COMMAND_ID_HANDLER_EX(ID_FILE_WORKOFFLINE, OnFileWorkOffline)

	COMMAND_ID_HANDLER_EX(ID_EDIT_CUT, OnEditCut)
	COMMAND_ID_HANDLER_EX(ID_EDIT_COPY, OnEditCopy)
	COMMAND_ID_HANDLER_EX(ID_EDIT_PASTE, OnEditPaste)
	COMMAND_ID_HANDLER_EX(ID_EDIT_SELECT_ALL, OnEditSelectAll)
		
	COMMAND_ID_HANDLER_EX(ID_FAVORITE_GROUP_SAVE, OnFavoriteGroupSave)
	COMMAND_ID_HANDLER_EX(ID_FAVORITE_GROUP_ORGANIZE, OnFavoriteGroupOrganize)

	COMMAND_ID_HANDLER_EX(ID_VIEW_REFRESH_ALL, OnViewRefreshAll)
	COMMAND_ID_HANDLER_EX(ID_VIEW_STOP_ALL, OnViewStopAll)
	COMMAND_ID_HANDLER_EX(ID_VIEW_FULLSCREEN, OnViewFullScreen)

	COMMAND_ID_HANDLER_EX(ID_BACKUPOPTION_CHANGED, OnBackUpOptionChanged)

	COMMAND_ID_HANDLER_EX(ID_TAB_LEFT, OnTabLeft)
	COMMAND_ID_HANDLER_EX(ID_TAB_RIGHT, OnTabRight)

	COMMAND_ID_HANDLER(ID_VIEW_SEARCHBAR, OnViewSearchBar)		// U.H
	COMMAND_ID_HANDLER(ID_VIEW_COMMANDBAR, OnViewCommandBar)	// U.H
	COMMAND_ID_HANDLER(ID_VIEW_TOOLBAR, OnViewToolBar)
	COMMAND_ID_HANDLER(ID_VIEW_ADDRESSBAR, OnViewAddressBar)
	COMMAND_ID_HANDLER(ID_VIEW_LINKBAR, OnViewLinkBar)
	COMMAND_ID_HANDLER(ID_VIEW_TABBAR, OnViewTabBar)
	COMMAND_ID_HANDLER(ID_VIEW_STATUS_BAR, OnViewStatusBar)
	COMMAND_ID_HANDLER(ID_VIEW_GOBUTTON, OnViewGoButton)
	COMMAND_ID_HANDLER(ID_VIEW_TOOLBAR_CUST, OnViewToolBarCust)
	COMMAND_ID_HANDLER(ID_VIEW_TABBAR_MULTI, OnViewTabBarMulti)
	COMMAND_ID_HANDLER(ID_VIEW_ADDBAR_DROPDOWN, OnViewAddBarDropDown)
	COMMAND_ID_HANDLER(ID_VIEW_TOOLBAR_LOCK, OnViewToolBarLock)	// minit
	COMMAND_ID_HANDLER(ID_VIEW_SEARCHBUTTON, OnViewSearchButton)// minit

	COMMAND_ID_HANDLER_EX(ID_VIEW_OPTION_DONUT, OnViewOptionDonut)
	COMMAND_ID_HANDLER_EX(ID_FAVORITE_ORGANIZE, OnFavoriteOrganize)

	COMMAND_ID_HANDLER_EX(ID_SETFOCUS_ADDRESSBAR, OnSetFocusAddressBar)
	COMMAND_ID_HANDLER_EX(ID_SETFOCUS_SEARCHBAR, OnSetFocusSearchBar)

	COMMAND_ID_HANDLER(ID_WINDOW_CLOSE_ALL, OnWindowCloseAll)

	COMMAND_ID_HANDLER(ID_VIEW_REFRESH_FAVBAR, OnViewRefreshFavBar)
	COMMAND_ID_HANDLER(ID_VIEW_IDLE, OnViewIdle)
	COMMAND_ID_HANDLER_EX(ID_VIEW_HOME, OnViewHome)

	// UH
	USER_MEG_WM_MENU_GET_FAV(OnMenuGetFav)
	USER_MEG_WM_MENU_GET_FAV_GROUP(OnMenuGetFavGroup)
	USER_MEG_WM_MENU_GET_SCRIPT(OnMenuGetScript)
	USER_MSG_WM_MENU_GOBACK(OnMenuGoBack)
	USER_MSG_WM_MENU_GOFORWARD(OnMenuGoForward)
	COMMAND_ID_HANDLER_EX(ID_RESIZED, OnResized);			
	COMMAND_ID_HANDLER_EX(ID_FILE_NEW_SELECTED, OnFileNewSelectText)
	MSG_WM_USER_SHOW_TEXT_CHG(OnShowTextChg)
	COMMAND_ID_HANDLER_EX(ID_GO_ADDRESBAR, OnGoAddresbar)
	MSG_WM_SYSCOMMAND(OnSysCommand)
	MSG_WM_INITMENUPOPUP(OnInitMenuPopup)
	COMMAND_ID_HANDLER_EX(ID_POPUP_CLOSE, OnPopupClose)						
	COMMAND_ID_HANDLER_EX(ID_TITLE_CLOSE, OnTitleClose)						
	COMMAND_ID_HANDLER_EX(ID_DOUBLE_CLOSE, OnDoubleClose)						
	COMMAND_ID_HANDLER_EX(ID_URLACTION_COOKIES_BLOCK, OnCookiesIE6)
	COMMAND_ID_HANDLER_EX(ID_URLACTION_COOKIES_HI, OnCookiesIE6)
	COMMAND_ID_HANDLER_EX(ID_URLACTION_COOKIES_MIDHI, OnCookiesIE6)
	COMMAND_ID_HANDLER_EX(ID_URLACTION_COOKIES_MID, OnCookiesIE6)
	COMMAND_ID_HANDLER_EX(ID_URLACTION_COOKIES_LOW, OnCookiesIE6)
	COMMAND_ID_HANDLER_EX(ID_URLACTION_COOKIES_ALL, OnCookiesIE6)
	MSG_WM_USER_HILIGHT(OnHilight);
	MSG_WM_USER_FIND_KEYWORD(OnFindKeyWord);
	MSG_WM_USER_WINDOWS_CLOSE_CMP(OnWindowCloseCmp);
	COMMAND_ID_HANDLER(ID_SERACHBAR_SEL_DOWN, OnSearchBarCmd)
	COMMAND_ID_HANDLER(ID_SERACHBAR_SEL_UP, OnSearchBarCmd)
	COMMAND_ID_HANDLER(ID_SERACHBAR_HILIGHT, OnSearchBarCmd)
	MSG_WM_USER_CHANGE_CSS(OnChangeCSS)
	COMMAND_ID_HANDLER(ID_PRIVACYREPORT, OnPrivacyReport)
	
	// ^^^

	//minit

	COMMAND_ID_HANDLER(ID_SPECIAL_HOME, OnSpecialKeys)
	COMMAND_ID_HANDLER(ID_SPECIAL_END, OnSpecialKeys)
	COMMAND_ID_HANDLER(ID_SPECIAL_PAGEUP, OnSpecialKeys)
	COMMAND_ID_HANDLER(ID_SPECIAL_PAGEDOWN, OnSpecialKeys)
	COMMAND_ID_HANDLER(ID_SPECIAL_UP, OnSpecialKeys)
	COMMAND_ID_HANDLER(ID_SPECIAL_DOWN, OnSpecialKeys)
	COMMAND_ID_HANDLER(ID_SECURITYREPORT, OnSecurityReport)
	COMMAND_ID_HANDLER_EX(ID_SETFOCUS_SEARCHBAR_ENGINE,OnSetFocusSearchBarEngine)
	USER_MEG_WM_MENU_REFRESH_FAV(OnMenuRefreshFav)
	USER_MEG_WM_MENU_REFRESH_FAV_GROUP(OnMenuRefreshFavGroup)
	USER_MEG_WM_MENU_REFRESH_SCRIPT(OnMenuRefreshScript)
	USER_MSG_WM_MENU_RESTRICT_MESSAGE(OnRestrictMessage)
	COMMAND_ID_HANDLER(ID_WINDOW_THUMBNAIL,OnWindowThumbnail)
	COMMAND_ID_HANDLER(ID_SPECIAL_REFRESH_SEARCHENGIN,OnSpecialRefreshSearchEngin) //�����Ȃ�
	COMMAND_ID_HANDLER(ID_RECENT_DOCUMENT,OnMenuRecentLast)
	USER_MSG_WM_MENU_RECENTDOCUMENT(OnMenuRecentDocument)
	COMMAND_ID_HANDLER(ID_STYLESHEET_USE_USERS,OnUseUserStyleSheet)
	COMMAND_ID_HANDLER(ID_STYLESHEET_SET_USERS,OnSetUserStyleSheet)
	USER_MSG_WM_CHANGE_SKIN(OnSkinChange)
	USER_MSG_WM_COMMAND_DIRECT(OnCommandDirect)
	USER_MSG_WM_REFRESH_EXPBAR(OnRefreshExpBar)
	USER_MSG_WM_SEARCH_WEB_SELTEXT(OnSearchWebSelText)
	USER_MSG_WM_SET_EXPROPERTY(OnSetExProperty)
	COMMAND_ID_HANDLER(ID_TABLIST_DEFAULT,OnTabListDefault)
	COMMAND_ID_HANDLER(ID_TABLIST_VISIBLE,OnTabListVisible)
	COMMAND_ID_HANDLER(ID_TABLIST_ALPHABET,OnTabListAlphabet)
	COMMAND_ID_HANDLER(ID_MAINFRAME_MINIMIZE,OnMainFrameMinimize)
	COMMAND_ID_HANDLER(ID_MAINFRAME_MAXIMIZE,OnMainFrameMaximize)
	COMMAND_ID_HANDLER(ID_SHOW_EXMENU,OnShowExMenu)
	COMMAND_ID_HANDLER(ID_SELECT_USERFOLDER,OnSelectUserFolder)
	COMMAND_ID_HANDLER(ID_SEARCH_HISTORY,OnSearchHistory)
	COMMAND_ID_HANDLER(ID_JUMP_WEBSITE,OnJumpToWebSite)
#define WM_PLUGIN_COMMAND	ID_PLUGIN_COMMAND
	MESSAGE_HANDLER(WM_PLUGIN_COMMAND,OnPluginCommand)
	USER_MSG_WM_OPEN_WITHEXPROP(OnOpenWithExProp)
	USER_MSG_WM_GET_SEARCHBAR(OnGetSearchBar)
	USER_MSG_WM_SHOW_TOOLBARMENU(OnShowToolBarMenu)
	COMMAND_ID_HANDLER(ID_SHOW_ACTIVEMENU,OnShowActiveMenu)
	COMMAND_TOGGLE_MEMBER_HANDLER(ID_VIEW_PLUGINBAR,m_PluginBar)
	COMMAND_TOGGLE_MEMBER_HANDLER(ID_VIEW_PANELBAR,m_PanelBar)
	COMMAND_TOGGLE_MEMBER_HANDLER(ID_VIEW_CLIPBOARDBAR,m_ClipBar)

	// UDT DGSTR //����������Ȃ̂ň�̊֐��ɂ܂Ƃ߂܂���(minit)
	COMMAND_ID_HANDLER(ID_FAVTREE_BAR_STANDARD, OnFavoriteExpBar)
	COMMAND_ID_HANDLER(ID_FAVTREE_BAR_GROUP, OnFavoriteExpBar)
	COMMAND_ID_HANDLER(ID_FAVTREE_BAR_SCRIPT, OnFavoriteExpBar)
	COMMAND_ID_HANDLER(ID_FAVTREE_BAR_USER, OnFavoriteExpBar)
	COMMAND_ID_HANDLER(ID_FAVTREE_BAR_MYCOMPUTER, OnFavoriteExpBar)
	COMMAND_ID_HANDLER(ID_FAVTREE_BAR_HISTORY, OnFavoriteExpBar)
	COMMAND_ID_HANDLER(ID_FILE_OPEN_DEF, OnFileOpenDef)
	// UDT DGSTR

	COMMAND_ID_HANDLER_EX(ID_REGISTER_AS_BROWSER, OnRegisterAsBrowser)	

	CHAIN_COMMANDS_MEMBER(m_ReBar)
	CHAIN_COMMANDS_MEMBER(m_MainOption)
	CHAIN_COMMANDS_MEMBER(m_secZone)
	CHAIN_COMMANDS(CWindowMenuCommandHandler<CMainFrame>)
	CHAIN_COMMANDS(CAppCommandHandler<CMainFrame>)
	CHAIN_COMMANDS_MEMBER(m_ExplorerBar)
	CHAIN_COMMANDS_MEMBER(m_DockingPluginManager)

	CHAIN_MDI_CHILD_COMMANDS()
	COMMAND_ID_HANDLER_EX(ID_VIEW_OPTION, OnViewOption)

	CHAIN_MSG_MAP(CDDEMessageHandler<CMainFrame>)
	CHAIN_MSG_MAP(CMDIFrameTitleUpsideDownMessageHandlerWeb<CMainFrame>)
	CHAIN_MSG_MAP(CHelpMessageLine<CMainFrame>)
	CHAIN_MSG_MAP(CMSMouseWheelMessageHandler<CMainFrame>)

	
	CHAIN_MSG_MAP(CReBarVerticalBorder<CMainFrame>)
	CHAIN_MSG_MAP(baseClass)

	REFLECT_CHEVRONPUSHED_NOTIFICATION()
	//CHAIN_MSG_MAP(baseClass)
	REFLECT_NOTIFICATIONS()// must be last
ALT_MSG_MAP(1)
	MESSAGE_HANDLER(WM_ERASEBKGND, OnMDIClientEraseBkgnd)
	MESSAGE_HANDLER(WM_SIZE, OnMDIClientSize)
END_MSG_MAP()

// UDT DGSTR
	LRESULT UpdateTitleBar(LPCTSTR lpszStatusBar, DWORD dwReserved)
	{
		if (!::IsWindowVisible(m_hWndStatusBar))
			UpdateTitleBarUpsideDown(lpszStatusBar);
		return 0;
	}
// ENDE

	// UH -  minit
	LRESULT OnMenuGetFav()
	{
		if(!m_DropFavoriteMenu.m_menu.IsMenu()){
			CMenuHandle menu;
			menu.LoadMenu(IDR_DROPDOWN_FAV);
			m_DropFavoriteMenu.InstallExplorerMenu(menu);
			ATLTRACE("menu loaded\n");
		}
		return (LRESULT)m_DropFavoriteMenu.m_menu.m_hMenu;
		//return (LRESULT)m_FavoriteMenu.m_menu.m_hMenu;
	}

	LRESULT OnMenuGetFavGroup()
	{
		if(!m_DropFavGroupMenu.m_menu.IsMenu()){
			CMenuHandle menu;
			menu.LoadMenu(IDR_DROPDOWN_FAVGROUP);
			m_DropFavGroupMenu.InstallExplorerMenu(menu);
		}
		return (LRESULT)m_DropFavGroupMenu.m_menu.m_hMenu;
		//return (LRESULT)m_FavGroupMenu.m_menu.m_hMenu;
	}

	LRESULT OnMenuGetScript()
	{
		if(!m_DropScriptMenu.m_menu.IsMenu()){
			CMenuHandle menu;
			menu.LoadMenu(IDR_DROPDOWN_SCRIPT);
			m_DropScriptMenu.SetRootDirectoryPath(_GetDonutPath()+_T("Script"));
			m_DropScriptMenu.SetTargetWindow(m_hWnd);
			m_DropScriptMenu.ResetIDCount(TRUE);
			m_DropScriptMenu.InstallExplorerMenu(menu);
		}
		return (LRESULT)m_DropScriptMenu.m_menu.m_hMenu;
		//return (LRESULT)m_ScriptMenu.m_menu.m_hMenu;
	}

	LRESULT OnMenuGoBack(HMENU hMenu)
	{
		HWND hMDIActive = MDIGetActive();
		return ::SendMessage(hMDIActive, WM_MENU_GOBACK, (WPARAM)(HMENU)hMenu, (LPARAM)0);
	}
	LRESULT OnMenuGoForward(HMENU hMenu)
	{
		HWND hMDIActive = MDIGetActive();
		return ::SendMessage(hMDIActive, WM_MENU_GOFORWARD, (WPARAM)(HMENU)hMenu, (LPARAM)0);
	}

	LRESULT OnMenuRefreshFav(BOOL bInit)
	{
		ATLTRACE("menu refreshed\n");
		if(m_DropFavoriteMenu.m_menu.IsMenu()){
			if(bInit == FALSE){
				ATLTRACE("menu terminated\n");
				m_DropFavoriteMenu.m_menu.DestroyMenu();
				m_bShow = FALSE;
			}else{
				ATLTRACE("menu initialized\n");
				m_bShow = TRUE;
			}
		}
		return S_OK;
	}

	LRESULT OnMenuRefreshFavGroup(BOOL bInit)
	{
		if(m_DropFavGroupMenu.m_menu.IsMenu()){
			if(bInit == FALSE){
				m_DropFavGroupMenu.m_menu.DestroyMenu();
				m_bShow = FALSE;
			}else{
				m_bShow = TRUE;
			}
		}
		return S_OK;
	}

	LRESULT OnMenuRefreshScript(BOOL bInit)
	{
		if(m_DropScriptMenu.m_menu.IsMenu()){
			if(bInit == FALSE){
				m_DropScriptMenu.m_menu.DestroyMenu();
				m_bShow = FALSE;
			}else{
				m_bShow = TRUE;
			}
		}
		return S_OK;
	}

	LRESULT OnRestrictMessage(BOOL bOn)
	{
		m_bShow = bOn;
		return S_OK;
	}

	void DestroyCustomDropDownMenu()
	{
		OnMenuRefreshFav(FALSE);
		OnMenuRefreshFavGroup(FALSE);
		OnMenuRefreshScript(FALSE);
	}

// UDT DGSTR
	void OnGetOut(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/)
	{
		static int nShow = SW_SHOWNORMAL;

		if (IsWindowVisible()){
			WINDOWPLACEMENT wp;
			wp.length = sizeof(WINDOWPLACEMENT);
			::GetWindowPlacement(m_hWnd,&wp);
			nShow = wp.showCmd;

			TrayMessage(m_hWnd, NIM_ADD, TM_TRAY, IDR_MAINFRAME, _T("unDonut")); 
			ShowWindow(SW_HIDE);
			Sleep(100); // UDT TODO
		}
		else{ // just db F9 press , come here :p
			ShowWindow(SW_SHOW);
			//ShowWindow(nShow); 
			TrayMessage(m_hWnd, NIM_DELETE, TM_TRAY, 0, NULL);
			
		}
	}
// ENDE
// UDT DGSTR ( hide window & display icon )
	LRESULT OnMyNotifyIcon(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& /*bHandled*/)
	{
		if(IsWindowVisible())
			return -1;
		else{
			switch(lParam)
			{
			case WM_LBUTTONUP:
				ShowWindow(SW_SHOW);
				TrayMessage(m_hWnd, NIM_DELETE, TM_TRAY, 0, NULL);
				return 0;
				break;

			case WM_RBUTTONUP:
				TrayMessage(m_hWnd, NIM_DELETE, TM_TRAY, 0, NULL);
				PostMessage(WM_CLOSE, 0, 0);
				break;
			}
			return -1;
		}
	}
// ENDE
// UDT DGSTR
	LRESULT UpdateExpBar(LPCTSTR lpszExpBar, DWORD dwReserved)
	{
		if(lpszExpBar == NULL) return 0;
		//m_ExplorerBar.SetTitle(lpszExpBar);
		return 0;
	}
// ENDE

	//minit
	LRESULT OnRefreshExpBar(int nType)
	{
		if(::IsWindow(m_ExplorerBar.m_FavBar.m_hWnd)){
			if(nType == 0 && m_ExplorerBar.IsFavBarVisibleNormal())
				m_ExplorerBar.m_FavBar.m_view.RefreshRootTree();
			else if(nType == 1 && m_ExplorerBar.IsFavBarVisibleGroup())
				m_ExplorerBar.m_FavBar.m_view.RefreshRootTree();
		}
		return 0;
	}

// Message handlers
	// alternates OpenFile
	HWND OnUserOpenFile(LPCTSTR lpszFile, DWORD openFlag)
	{
		CString strFile(lpszFile);

		MtlRemoveStringHeaderAndFooter(strFile);
		
		if ( !MtlIsProtocol(strFile, _T("http")) &&
			 !MtlIsProtocol(strFile, _T("https")) )
		{
			if (MtlPreOpenFile(strFile))
				return NULL;// handled
		}
		
		DWORD dwExProp=0;
		if(MtlIsExt(strFile,_T(".url"))){
			return OpenInternetShortcut(strFile,openFlag);
		}
		//MtlParseIntenetShortcutFile(strFile);

		if (strFile.GetLength() > INTERNET_MAX_PATH_LENGTH)
			return NULL;

		if (strFile == _T("javascript:location.reload()"))
			return NULL;

		// UH (JavaScript dont create window)
		CString strJava = strFile.Left(11);
		strJava.MakeUpper();
		if (strJava==_T("JAVASCRIPT:"))
			openFlag |= D_OPENFILE_NOCREATE;

		// dfg files
		if (MtlIsExt(strFile, _T(".dfg"))) {
			if (!(CMainOption::s_dwMainExtendedStyle & MAIN_EX_NOCLOSEDFG))
				_LoadGroupOption(strFile, true);
			else
				_LoadGroupOption(strFile, false);
			return NULL;
		}

		// minit(about:* pages)
        {
			CString strAbout = strFile.Left(6);
			if(strAbout == _T("about:") && strFile != _T("about:blank")){
				HWND hWndAbout =  _OpenAboutFile(strFile);
				if(hWndAbout)
					return hWndAbout;
			}
		}

		HWND hWndActive = MDIGetActive();

		int nCmdShow = _check_flag(D_OPENFILE_ACTIVATE, openFlag) ? -1 : SW_SHOWNOACTIVATE;

		if (hWndActive == NULL) {	// no window yet
			nCmdShow = -1;			// always default
		}

		if (hWndActive != NULL && _check_flag(D_OPENFILE_NOCREATE, openFlag)) {
			CWebBrowser2 browser = DonutGetIWebBrowser2(hWndActive);
			if (!browser.IsBrowserNull()) {
				browser.Navigate2(strFile);

				if (!_check_flag(D_OPENFILE_NOSETFOCUS, openFlag)) {
					// reset focus
					::SetFocus(NULL);
					MtlSendCommand(hWndActive, ID_VIEW_SETFOCUS);
				}

				return NULL;
				//return hWndActive;
			}
		}

		CChildFrame* pChild = CChildFrame::NewWindow(m_hWndMDIClient, m_MDITab, m_AddressBar);
		if (pChild == NULL)
			return NULL;

		pChild->ActivateFrame(nCmdShow);

		if (!strFile.IsEmpty())
			pChild->Navigate2(strFile);

		if (!_check_flag(D_OPENFILE_NOSETFOCUS, openFlag)) {
			if (MDIGetActive() == pChild->m_hWnd) {// a new window activated, so automatically set focus
				// reset focus
				::SetFocus(NULL);
				MtlSendCommand(pChild->m_hWnd, ID_VIEW_SETFOCUS);
			}
			else {
				// It's reasonable not to touch a current focus.
			}
		}

		

		return pChild->m_hWnd;
	}

	LRESULT OnGetSearchBar()
	{
		return (LRESULT)&m_SearchBar;
	}

	LRESULT OnOpenWithExProp(_EXPROP_ARGS *pArgs)
	{
		if(!pArgs) return 0;
		HWND hWndNew = OpenUrlWithExProp(pArgs->strUrl,pArgs->dwOpenFlag,pArgs->strIniFile,pArgs->strSection);
		if(!hWndNew) hWndNew = MDIGetActive();
		CChildFrame *pChild = GetChildFrame(hWndNew);
		if(pChild){
			pChild->m_strSearchWord = pArgs->strSearchWord;
		}
		return (LRESULT)hWndNew;
	}

	HWND OpenInternetShortcut(CString strUrlFile, DWORD dwOpenFlag)
	{
		CString strUrl = strUrlFile;
		if(!MtlParseIntenetShortcutFile(strUrl)) return NULL;
		
		return OpenUrlWithExProp(strUrl,dwOpenFlag,strUrlFile);
	}

	HWND OpenUrlWithExProp(CString strUrl, DWORD dwOpenFlag, DWORD dwExProp)
	{
		if(_check_flag(D_OPENFILE_NOCREATE, dwOpenFlag)){
			return OpenExPropertyActive(strUrl,dwExProp,dwOpenFlag); //�����̃^�u�ŊJ��
		}else{
			return OpenExPropertyNew(strUrl,dwExProp,dwOpenFlag); //�V�K�ɊJ��
		}
	}

	HWND OpenUrlWithExProp(CString strUrl, DWORD dwOpenFlag, CString strIniFile, CString strSection = DONUT_SECTION)
	{	
		DWORD dwExProp;
		if(CExProperty::CheckExPropertyFlag(dwExProp,strIniFile,strSection)){
			if(_check_flag(D_OPENFILE_NOCREATE, dwOpenFlag)){
				return OpenExPropertyActive(strUrl,dwExProp,dwOpenFlag); //�����̃^�u�ŊJ��
			}else{
				return OpenExPropertyNew(strUrl,dwExProp,dwOpenFlag); //�V�K�ɊJ��
			}
		}else{
			return OpenExPropertyNot(strUrl,dwOpenFlag); //�W���I�v�V�����ŊJ��
		}
	}

	//�����^�u�Ƀi�r�Q�[�g�����̂��Ɋg���ݒ��K�p����
	HWND OpenExPropertyActive(CString& strUrl, DWORD dwExProp, DWORD dwOpenFlag)
	{
		dwOpenFlag |= D_OPENFILE_NOCREATE;

		//�A�N�e�B�u�ȃ^�u���i�r�Q�[�g���b�N����Ă��邩���m�F
		HWND hWndActive = MDIGetActive();
		if(::IsWindow(hWndActive)){
			CChildFrame *pChild = GetChildFrame(hWndActive);
			if(pChild){
				DWORD dwExFlag = pChild->m_view.m_ViewOption.m_dwExStyle;
				if(dwExFlag&DVS_EX_OPENNEWWIN)
					return OpenExPropertyNew(strUrl,dwExProp,dwOpenFlag);
			}
		}

		//�擾����URL���A�N�e�B�u�ȃ^�u�ŊJ������i�W�������ɔC����j
		BOOL bOpened = FALSE;
		HWND hWndNew = OnUserOpenFile(strUrl,dwOpenFlag);
		if(hWndNew && !hWndActive){
			hWndActive = hWndNew; //�E�B���h�E�����������̂ŐV�K�ɊJ����
			bOpened = TRUE;
		}

		//�g���v���p�e�B��K�p����
		CChildFrame *pChild = GetChildFrame(hWndActive);
		if(!pChild) return NULL;

		CExProperty ExProp(CDLControlOption::s_dwDLControlFlags,_dwViewStyle,0,dwExProp);
		
		pChild->m_view.PutDLControlFlags(ExProp.GetDLControlFlags());
		pChild->SetViewExStyle(ExProp.GetExtendedStyleFlags(),TRUE);
		pChild->m_view.m_ViewOption.SetAutoRefreshStyle(ExProp.GetAutoRefreshFlag());
		
		if(bOpened)
			return hWndActive;
		return NULL;
	}

	//�V�K�^�u���J�����̂��g���ݒ��K�p����
	HWND OpenExPropertyNew(CString& strUrl, DWORD dwExProp, DWORD dwOpenFlag)
	{
		dwOpenFlag &= ~D_OPENFILE_NOCREATE;

		//URL�ŐV�K�^�u���J��
		HWND hWndNew = OnUserOpenFile(strUrl,dwOpenFlag);
		if(!::IsWindow(hWndNew)) return NULL;

		//�g���v���p�e�B��K�p����
		CChildFrame *pChild = GetChildFrame(hWndNew);
		if(!pChild) return NULL;

		CExProperty ExProp(CDLControlOption::s_dwDLControlFlags,_dwViewStyle,0,dwExProp);
		
		pChild->m_view.PutDLControlFlags(ExProp.GetDLControlFlags());
		pChild->SetViewExStyle(ExProp.GetExtendedStyleFlags(),TRUE);
		pChild->m_view.m_ViewOption.SetAutoRefreshStyle(ExProp.GetAutoRefreshFlag());

		return hWndNew;
	}

	//�^�u���J�����̂��A�W���̐ݒ��K�p����
	HWND OpenExPropertyNot(CString& strUrl, DWORD dwOpenFlag)
	{
		//�A�N�e�B�u�ȃ^�u���i�r�Q�[�g���b�N����Ă��邩���m�F
		HWND hWndActive = MDIGetActive();
		if(::IsWindow(hWndActive)){
			CChildFrame *pChild = GetChildFrame(hWndActive);
			if(pChild){
				DWORD dwExFlag = pChild->m_view.m_ViewOption.m_dwExStyle;
				if(dwExFlag&DVS_EX_OPENNEWWIN)
					dwOpenFlag &= ~D_OPENFILE_NOCREATE; //�V�K�^�u�ŊJ���悤��
			}
		}

		//�擾����URL���J������
		HWND hWndNew = OnUserOpenFile(strUrl,dwOpenFlag);

		if(hWndNew){
			//�V�K�ɊJ�����^�u�Ȃ̂ŉ������Ȃ��Ă悢
			return hWndNew;
		}else{
			//�I�v�V������W���̂��̂ŏ㏑��
			CChildFrame *pChild = GetChildFrame(MDIGetActive());
			if(!pChild) return NULL;
			pChild->m_view.PutDLControlFlags(CDLControlOption::s_dwDLControlFlags);
			pChild->SetViewExStyle(_dwViewStyle,TRUE);
			pChild->m_view.m_ViewOption.SetAutoRefreshStyle(0);
		}
		return NULL;
	}

	LRESULT OnMenuDrag(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
	{
		return m_wndMenuDropTarget.OnMenuDrag(uMsg,wParam,lParam,bHandled);
	}

	LRESULT OnMenuGetObject(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
	{
		return m_wndMenuDropTarget.OnMenuGetObject(uMsg,wParam,lParam,bHandled);
	}

//////////////////////////////////////////////////////////////////
// to avoid the flicker on resizing
	LRESULT OnMDIClientEraseBkgnd(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
	{
		HWND hWndActive = MDIGetActive();
		if (CMainOption::s_bTabMode && hWndActive != NULL)
			return 1;// no need to erase it

		bHandled = FALSE;
		return 0;
	}

	LRESULT OnMDIClientSize(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
	{
		PostMessage(WM_COMMAND, MAKEWPARAM(ID_RESIZED, 0), 0);

		BOOL bMaximized = FALSE;
		HWND hWndActive = MDIGetActive(&bMaximized);
		if (CMainOption::s_bTabMode || hWndActive == NULL || bMaximized == FALSE) {// pass to default
			bHandled = FALSE;
			return 1;
		}

		// NOTE. If you do the following, you can avoid the flicker on resizing.
		//       I can't understand why it is effective...
		//
		//       But still you can get a glimpse of other mdi child window's frames.
		//       I guess it's MDI's bug, but I can't get the way MFC fixed.
		CWindow wndActive(hWndActive);
		CWindow wndView = wndActive.GetDlgItem(ID_DONUTVIEW);
		wndActive.ModifyStyle(0, WS_CLIPCHILDREN);// add WS_CLIPCHILDREN
		wndView.ModifyStyle(0, WS_CLIPCHILDREN);
		LRESULT lRet = m_wndMDIClient.DefWindowProc(uMsg, wParam, lParam);
		m_wndMDIClient.UpdateWindow();
		wndActive.ModifyStyle(WS_CLIPCHILDREN, 0);
		wndView.ModifyStyle(WS_CLIPCHILDREN, 0);

		bHandled = FALSE;
		return lRet;
	}
//////////////////////////////////////////////////////////////////
// custom draw of addressbar
	LRESULT OnNotify(UINT /*uMsg*/, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
	{
		bHandled = FALSE;

		LPNMHDR lpnmh = (LPNMHDR)lParam;
		LRESULT lRet = 0;

		if ( lpnmh->code==NM_CUSTOMDRAW && lpnmh->hwndFrom==m_hWndToolBar )
		{	// from rebar
			lRet = m_AddressBar.OnCustomDraw(0, lpnmh, bHandled);
		}

		if ( lpnmh->code==TBN_DROPDOWN )
		{
			int nCount = CPluginManager::GetCount(PLT_TOOLBAR);
			for ( int nIndex=0; nIndex<nCount; nIndex++)
			{
				HWND hWndBar = CPluginManager::GetHWND(PLT_TOOLBAR,nIndex);
				if ( lpnmh->hwndFrom!=hWndBar ) continue;

				CPluginManager::Call_ShowToolBarMenu(PLT_TOOLBAR,nIndex,((LPNMTOOLBAR)lpnmh)->iItem);

				bHandled = TRUE;
				break;
			}
		}

		return lRet;
	}

//////////////////////////////////////////////////////////////////
// the custom message from MDI child
	void OnMDIChild(HWND hWnd, UINT nCode)
	{
		SetMsgHandled(FALSE);
		if (nCode ==  MDICHILD_USER_ALLCLOSED) {
			m_AddressBar.SetWindowText(_T(""));
			::SetWindowText(m_hWndStatusBar, _T("���f�B"));
			m_CmdBar.EnableButton(_nPosWindowMenu, false);
		}
		else if (nCode == MDICHILD_USER_FIRSTCREATED) {
			m_CmdBar.EnableButton(_nPosWindowMenu, true);
		}
		else if (nCode == MDICHILD_USER_ACTIVATED) {
			_OnMDIActivate(hWnd);
			OnIdle();		// make sure when cpu is busy
		}
		else if (nCode == MDICHILD_USER_TITLECHANGED) {
			//OnTitleChanged();
		}
	}

	BOOL OnBrowserCanSetFocus()
	{// asked by browser
		HWND hWndFocus = ::GetFocus();
		if (hWndFocus == NULL)
			return TRUE;

		if (::IsChild(m_hWndToolBar, hWndFocus))
			return FALSE;

		if (m_ExplorerBar.IsChild(hWndFocus))
			return FALSE;

		return TRUE;
	}

	void OnParentNotify(UINT fwEvent, UINT idChild, LPARAM lParam)
	{
		if (fwEvent != WM_RBUTTONDOWN)
			return;

		CPoint pt(GET_X_LPARAM(lParam), GET_Y_LPARAM(lParam));
		ClientToScreen(&pt);	
		
		CRect rc;
		::GetClientRect(m_hWndToolBar, &rc);
		CPoint ptRebar = pt; ::ScreenToClient(m_hWndToolBar, &ptRebar);
		if (!rc.PtInRect(ptRebar))			// not on rebar
			return;

		HWND hWnd = ::WindowFromPoint(pt);
		if (hWnd == m_MDITab.m_hWnd) {	// on tab bar
			CPoint ptTab = pt; m_MDITab.ScreenToClient(&ptTab);
			if (m_MDITab.HitTest(ptTab) != -1)
				return;
		}

/*		if (idChild == IDC_MDITAB) {
			CPoint pt2 = pt;
			ClientToScreen(&pt2);
			m_MDITab.ScreenToClient(&pt2);

			if (m_MDITab.HitTest(pt2) != -1)
				return;
		}
*/
		CMenuHandle menuView = ::GetSubMenu(m_CmdBar.GetMenu(), _nPosViewMenu);
		CMenuHandle menu = menuView.GetSubMenu(0);
	
//		CPoint ptCursor; ::GetCursorPos(&ptCursor);
		menu.TrackPopupMenu(TPM_LEFTALIGN|TPM_LEFTBUTTON|TPM_RIGHTBUTTON, pt.x, pt.y, m_hWnd, NULL);
	}

	void OnDestroy()
	{
		SetMsgHandled(FALSE);
		MtlSendCommand(m_hWnd, ID_VIEW_STOP_ALL);// added by DOGSTORE

		//CSearchBoxHook::UninstallSearchHook();
		CDialogHook::UninstallHook();

		//�f�o�b�O�E�B���h�E�폜
		m_wndDebug.Destroy();

		//�S�v���O�C�����
		CPluginManager::Term();

		m_ReBar.UnsubclassWindow();

		//�o�b�N�A�b�v�X���b�h�̊J��
		if(m_hGroupThread){
			DWORD dwResult = ::WaitForSingleObject(m_hGroupThread,DONUT_THREADWAIT);
			if(dwResult == WAIT_TIMEOUT) ::TerminateThread(m_hGroupThread,1);
			CloseHandle(m_hGroupThread);
		}
		
		// Note. The script error dialog makes the app hung up.
		//       I can't find the reason, but I can avoid it by closing
		//       windows explicitly.
		MtlCloseAllMDIChildren(m_hWndMDIClient);

		CCriticalIdleTimer::UninstallCriticalIdleTimer();

		// what can I trust?
		ATLASSERT(::IsMenu(m_hMenu));
		::DestroyMenu(m_hMenu);

		_RemoveTmpDirectory();
		DestroyCustomDropDownMenu();

		RevokeDragDrop();

	}

	void OnEndSession(BOOL wParam, UINT lParam) //ShutDown minit
	{
		if(wParam == TRUE){
			OnDestroy();
			_PrivateTerm();
		}
	}

	void OnActivate(UINT nState, BOOL bMinimized, HWND hWndOther)
	{
		if (nState == WA_INACTIVE) {
			m_hWndFocus = ::GetFocus();
		}
		else {
			if (m_hWndFocus)
				::SetFocus(m_hWndFocus);
		}
	}

	LRESULT OnCreate(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& /*bHandled*/)
	{
		//LRESULT lRet = DefWindowProc(uMsg,wParam,lParam);

		CFavoritesMenuOption::Add(m_hWnd);

		//vvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvv
		// �t�H���g
		CIniSection prFont;
		prFont.Open(_szIniFileName, _T("Main"));

		MTL::CLogFont lf;
		lf.InitDefault();
		if (lf.GetProfile(prFont))
		{
			CFontHandle font;
			MTLVERIFY(font.CreateFontIndirect(&lf));
			if (font.m_hFont) {
				if(m_font.m_hFont != NULL)
					m_font.DeleteObject();
				m_font.Attach(font.m_hFont);
				SetFont(m_font);
			}
		}
		prFont.Close();
		//^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

		//�f�o�b�O�E�B���h�E�̍쐬
		m_wndDebug.Create();

		//////////////////////////////////////////////////////////////////
		// initialize menus' infomation
		CMenuHandle menu = m_hMenu;
		CMenuHandle menuFav = menu.GetSubMenu(_nPosFavoriteMenu);
		m_FavoriteMenu.InstallExplorerMenu(menuFav);
		m_FavoriteMenu.SetTargetWindow(m_hWnd);

		CMenuHandle menuGroup = menuFav.GetSubMenu(_nPosFavGroupMenu);
		m_FavGroupMenu.InstallExplorerMenu(menuGroup);
		m_FavGroupMenu.SetTargetWindow(m_hWnd);

		CMenuHandle menuCss = menu.GetSubMenu(_nPosCssMenu);
		CMenuHandle menuCssSub = menuCss.GetSubMenu(_nPosSubCssMenu);
		m_styleSheetMenu.SetRootDirectoryPath(_GetDonutPath()+_T("CSS"));
		m_styleSheetMenu.SetTargetWindow(m_hWnd);
		m_styleSheetMenu.ResetIDCount(TRUE);
		m_styleSheetMenu.InstallExplorerMenu(menuCssSub);

		m_ScriptMenuMst.LoadMenu(IDR_SCRIPT);
		m_ScriptMenu.SetRootDirectoryPath(_GetDonutPath()+_T("Script"));
		m_ScriptMenu.SetTargetWindow(m_hWnd);
		m_ScriptMenu.ResetIDCount(TRUE);
		m_ScriptMenu.InstallExplorerMenu(m_ScriptMenuMst);

		OnMenuGetFav();  //initialize custom context dropdown
		OnMenuGetFavGroup();
		OnMenuGetScript();

		CMenuHandle menuEncode = menu.GetSubMenu(_nPosEncodeMenu);
		m_MenuEncode.Init(menuEncode,m_hWnd,_nPosEncodeMenuSub);

		// MRU list
		CMainOption::SetMRUMenuHandle(menu, _nPosMRU);

		//MenuDropTaget
		m_wndMenuDropTarget.Create(m_hWnd,rcDefault,_T("MenuDropTargetWindow"),WS_POPUP,0);
		m_wndMenuDropTarget.SetTargetMenu(menu);

		//////////////////////////////////////////////////////////////////
		// create command bar window
		SetMenu(NULL);// remove menu
		HWND hWndCmdBar = m_CmdBar.Create(m_hWnd, rcDefault, NULL, MTL_SIMPLE_CMDBAR2_PANE_STYLE, 0, ATL_IDW_COMMAND_BAR);
		if (m_font.m_hFont)
		{
			LOGFONT lf;
			m_font.GetLogFont(lf);
			m_CmdBar.SetMenuLogFont(lf);
		}

		m_CmdBar.AttachMenu(m_hMenu);
		m_CmdBar.EnableButton(_nPosWindowMenu, false);

		//////////////////////////////////////////////////////////////////
		// create toolbar
		HWND hWndToolBar = m_ToolBar.DonutToolBar_Create(m_hWnd);
		ATLASSERT(::IsWindow(hWndToolBar));
		m_ToolBar.DonutToolBar_SetFavoritesMenu(menuFav, menuGroup, menuCssSub);
		if (m_CmdBar.m_fontMenu.m_hFont) m_ToolBar.SetFont(m_CmdBar.m_fontMenu.m_hFont);

		//////////////////////////////////////////////////////////////////
		// create addressbar
		HWND hWndAddressBar = m_AddressBar.Create(m_hWnd, IDC_ADDRESSBAR, ID_VIEW_GO,
			IDB_GOBUTTON, IDB_GOBUTTON_HOT, 16, 16, RGB(255, 0, 255));
		ATLASSERT(::IsWindow(hWndAddressBar));
		if (m_CmdBar.m_fontMenu.m_hFont) m_AddressBar.SetFont(m_CmdBar.m_fontMenu.m_hFont);
		m_AddressBar.m_comboFlat.SetDrawStyle(CSkinOption::s_nComboStyle);
		
		//////////////////////////////////////////////////////////////////
		// create searchbar
		HWND hWndSearchBar = m_SearchBar.Create(m_hWnd);
		if (m_CmdBar.m_fontMenu.m_hFont) m_SearchBar.SetFont(m_CmdBar.m_fontMenu.m_hFont);
		m_SearchBar.SetDlgCtrlID(IDC_SEARCHBAR);
		m_SearchBar.SetComboStyle(CSkinOption::s_nComboStyle);

		//////////////////////////////////////////////////////////////////
		// create tabctrl
		HWND hWndMDITab = m_MDITab.Create(m_hWnd, CRect(0, 0, 200, 20), _T("Donut MDITab"),
			WS_CHILD | WS_VISIBLE, NULL, IDC_MDITAB);
		m_MDITab.LoadMenu(IDR_MENU_TAB);
		m_MDITab.LoadConnectingAndDownloadingImageList(IDB_MDITAB, 6, 6, RGB(255, 0, 255));

		//////////////////////////////////////////////////////////////////
		// create link bar
		{
			DWORD dwStyle = 0;
			CIniSection prLnk;
			prLnk.Open(_szIniFileName, _T("LinkBar"));
			prLnk.QueryValue(dwStyle, _T("ExtendedStyle"));
			m_LinkBar.SetOptionalStyle(dwStyle);
		}
		HWND hWndLinkBar = m_LinkBar.Create(m_hWnd, rcDefault, NULL, ATL_SIMPLE_TOOLBAR_PANE_STYLE, 0, IDC_LINKBAR);

		//////////////////////////////////////////////////////////////////
		CIniSection pr;

		//////////////////////////////////////////////////////////////////
		// create rebar
		DWORD dwNoBoader=0;
		DWORD dwRebarStyle = MTL_SIMPLE_REBAR_STYLE | RBS_DBLCLKTOGGLE;
		
		pr.Open(_szIniFileName, _T("ReBar"));
		pr.QueryValue(dwNoBoader, _T("NoBoader"));
		pr.Close();
		if(dwNoBoader)
			dwRebarStyle &= ~RBS_BANDBORDERS;
		CreateSimpleReBar(dwRebarStyle);
		m_ReBar.SubclassWindow(m_hWndToolBar);

		//CreateSimpleReBar(MTL_SIMPLE_REBAR_STYLE | RBS_DBLCLKTOGGLE);

		if (m_CmdBar.m_fontMenu.m_hFont)
		{
			::SendMessage(m_hWndToolBar, WM_SETFONT, (WPARAM)m_CmdBar.m_fontMenu.m_hFont, MAKELPARAM(TRUE, 0));
			m_LinkBar.SetFont(m_CmdBar.m_fontMenu.m_hFont);
		}

		//////////////////////////////////////////////////////////////////
		// create statusbar //CreateSimpleStatusBar();
		m_wndStatusBar.Create(m_hWnd);
		m_hWndStatusBar = m_wndStatusBar.m_hWnd;
//		int nPanes[] = { ID_DEFAULT_PANE, ID_PROGRESS_PANE, ID_COMBOBOX_PANE};
		int nPanes[] = { ID_DEFAULT_PANE, ID_PROGRESS_PANE, ID_PRIVACY_PANE, ID_SECURE_PANE, ID_COMBOBOX_PANE};
		m_wndStatusBar.SetPanes( nPanes, 5, false );
		m_wndStatusBar.SetCommand( ID_PRIVACY_PANE, ID_PRIVACYREPORT );
		m_wndStatusBar.SetCommand( ID_SECURE_PANE, ID_SECURITYREPORT);
		m_wndStatusBar.SetIcon( ID_PRIVACY_PANE, 1 ); //minit
		m_wndStatusBar.SetIcon( ID_SECURE_PANE, 0 );  //minit
		m_wndStatusBar.SetOwnerDraw(m_wndStatusBar.IsValidBmp());

		// UH
		InitStatusBar();

		//////////////////////////////////////////////////////////////////
		// create prgress bar
		RECT rect;
		m_wndProgress.Create(m_hWndStatusBar, NULL, NULL, WS_CHILD | WS_CLIPSIBLINGS    
			| PBS_SMOOTH, 0, IDC_PROGRESS);
		m_wndProgress.ModifyStyleEx(WS_EX_STATICEDGE, 0);

		// �R���{�{�b�N�X
		m_cmbBox.Create(m_hWndStatusBar, rect, NULL, WS_CHILD | WS_CLIPSIBLINGS    
			| PBS_SMOOTH|CBS_DROPDOWNLIST| WS_VSCROLL | WS_TABSTOP, 0, IDC_COMBBOX);

		m_cmbBox.SetFont(m_wndStatusBar.GetFont());
		m_cmbBox.SetDrawStyle(CSkinOption::s_nComboStyle);
		m_cmbBox.ShowWindow(SW_SHOWNORMAL);
		m_cmbBox.ResetProxyList();

		// Plugin Toolbar Load
		CPluginManager::Init();
		CPluginManager::ReadPluginData(PLT_TOOLBAR,m_hWnd);
		CPluginManager::LoadAllPlugin(PLT_TOOLBAR,m_hWnd,true); //�c�[���o�[�v���O�C����S�����[�h
		{
			int nCount = CPluginManager::GetCount(PLT_TOOLBAR);
			for(int i=0; i<nCount; i++){
				HWND hWnd = CPluginManager::GetHWND(PLT_TOOLBAR,i);
				if(::IsWindow(hWnd))
					::SetProp(hWnd,_T("Donut_Plugin_ID"),(HANDLE)(IDC_PLUGIN_TOOLBAR+i));
			}
		}
		//LoadPluginToolbars();

		//////////////////////////////////////////////////////////////////
		// load band position
		int nToolbarPluginCount = CPluginManager::GetCount(PLT_TOOLBAR);
		CReBarBandInfo* pRbis = new CReBarBandInfo[STDBAR_COUNT+nToolbarPluginCount];

		CSimpleArray<HWND> aryHWnd;
		aryHWnd.Add( hWndCmdBar );			// Menubar
		aryHWnd.Add( hWndToolBar );			// Toolbar
		aryHWnd.Add( hWndAddressBar );		// Addressbar
		aryHWnd.Add( hWndMDITab );			// Tabbar
		aryHWnd.Add( hWndLinkBar );			// Linkbar
		aryHWnd.Add( hWndSearchBar );		// Searchbar

		for ( int nIndex=0; nIndex<aryHWnd.GetSize(); nIndex++)
		{
			pRbis[nIndex].nIndex				= nIndex;
			pRbis[nIndex].hWnd					= aryHWnd		[ nIndex ];
			pRbis[nIndex].nID					= STDBAR_ID		[ nIndex ];
			pRbis[nIndex].fStyle				= STDBAR_STYLE	[ nIndex ];
			pRbis[nIndex].lpText				= STDBAR_TEXT	[ nIndex ];
			pRbis[nIndex].cx					= 0;
		}

		for ( nIndex=0; nIndex<nToolbarPluginCount; nIndex++ )
		{
			pRbis[STDBAR_COUNT+nIndex].nIndex	= STDBAR_COUNT+nIndex;
			pRbis[STDBAR_COUNT+nIndex].hWnd		= CPluginManager::GetHWND(PLT_TOOLBAR,nIndex);
			pRbis[STDBAR_COUNT+nIndex].nID		= IDC_PLUGIN_TOOLBAR+nIndex;
			pRbis[STDBAR_COUNT+nIndex].fStyle	= RBBS_BREAK;
			pRbis[STDBAR_COUNT+nIndex].lpText	= NULL;
			pRbis[STDBAR_COUNT+nIndex].cx		= 0;
		}

		pr.Open(_szIniFileName, _T("ReBar"));
		MtlGetProfileReBarBandsState( pRbis, pRbis + STDBAR_COUNT+nToolbarPluginCount, pr, *this);
		pr.Close();

		delete [] pRbis; //memory leak bug Fix  minit

		m_CmdBar.RefreshBandIdealSize(m_hWndToolBar);
		m_AddressBar.InitReBarBandInfo(m_hWndToolBar);// if you dislike a header, remove this.
		ShowLinkText(m_AddressBar.m_dwAddressBarExtendedStyle&ABR_EX_TEXTVISIBLE);

		//////////////////////////////////////////////////////////////////
		// load status bar state
		pr.Open(_szIniFileName, _T("Main"));
		BOOL bStatusBarVisible = TRUE;
		MtlGetProfileStatusBarState(pr, m_hWndStatusBar, bStatusBarVisible);
		m_bStatusBarVisibleUnlessFullScreen = bStatusBarVisible;
		pr.Close();

		//////////////////////////////////////////////////////////////////
		// create mdi client window
		m_menuWindow = ::GetSubMenu(m_hMenu, _nPosWindowMenu);
		CreateMDIClient(m_menuWindow.m_hMenu);
		m_wndMDIClient.SubclassWindow(m_hWndMDIClient);

		// NOTE: If WS_CLIPCHILDREN not set, MDI Client will try erase background over MDI child window,
		//       but as OnEraseBkgnd does nothing, it goes well.
		if (CMainOption::s_bTabMode)
			m_wndMDIClient.ModifyStyle(WS_CLIPCHILDREN, 0);// to avoid flicker, but scary

		//////////////////////////////////////////////////////////////////
		// Docking Window
		InitializeDockingFrame(dockwins::CDWStyle::sNoAnimation|dockwins::CDWStyle::sFullDrag|dockwins::CDWStyle::sIgnoreSysSettings);
		CRect rcDockingBar(0,0,200,400);

		//�v���O�C���o�[
		m_PluginBar.Create(m_hWnd,rcDockingBar,_T("�v���O�C���o�["));
		DockWindow(m_PluginBar,dockwins::CDockingSide(dockwins::CDockingSide::sLeft),
						0/*nBar*/,float(0.0)/*fPctPos*/,200/*nWidth*/,100/* nHeight*/);

		//�N���b�v�{�[�h�o�[
		m_ClipBar.Create(m_hWnd,rcDockingBar,_T("�N���b�v�{�[�h"));
		m_ClipBar.DockTo(m_PluginBar,0);

		//�p�l���o�[
		m_PanelBar.CreatePanelBar(m_hWnd);
		m_PanelBar.DockTo(m_PluginBar,1);

		//�G�N�X�v���[���o�[
		m_ExplorerBar.Create(m_hWnd,rcDockingBar,_T("�G�N�X�v���[���o�["));
		m_ExplorerBar.Init();
		m_ExplorerBar.DockTo(m_PluginBar,2);

		//////////////////////////////////////////////////////////////////
		// MDIClient misc
		m_mcCmdBar.InstallAsMDICmdBar(hWndCmdBar, m_hWndMDIClient, CMainOption::s_bTabMode);
		m_mcToolBar.InstallAsStandard(hWndToolBar, m_hWnd, true, ID_VIEW_FULLSCREEN);
		DWORD dwNoButton=0;
		pr.Open(_GetFilePath(_T("Menu.ini")),_T("Option"));
		pr.QueryValue(dwNoButton,_T("NoButton"));
		pr.Close();
		bool bNoButton = dwNoButton ? true : false;
		m_mcCmdBar.ShowButton(!bNoButton);
		//m_mcToolBar.ShowButton(!bNoButton);

		m_MDITab.SetMDIClient(m_hWndMDIClient);

		//////////////////////////////////////////////////////////////////
		// set up UI
		CmdUIAddToolBar(hWndToolBar);

		// UDT DGSTR ( set User Agent )
		::UrlMkSetSessionOption(URLMON_OPTION_USERAGENT , 
			(void *)CDLControlOption::s_szUserAgent , lstrlen(CDLControlOption::s_szUserAgent) , 0);
		// ENDE

		// message loop	
		CMessageLoop* pLoop = _Module.GetMessageLoop();
		pLoop->AddMessageFilter(this);
		pLoop->AddIdleHandler(this);

		// read general settings
		_ReadProfile();
		// for dragging files
		RegisterDragDrop();// DragAcceptFiles();

		CCriticalIdleTimer::InstallCriticalIdleTimer(m_hWnd, ID_VIEW_IDLE);

		// �V�X�e�����j���[�ɒǉ�
		HMENU hSysMenu = ::GetSystemMenu(m_hWnd, FALSE);
//		::AppendMenu(hSysMenu, MF_ENABLED|MF_STRING, ID_VIEW_COMMANDBAR, _T("���j���[��\��")); 

		char cText[] = "���j���[��\��";
		MENUITEMINFO menuInfo;
		memset(&menuInfo, 0, sizeof(MENUITEMINFO));
		menuInfo.cbSize = sizeof(MENUITEMINFO);
		menuInfo.fMask = MIIM_ID|MIIM_TYPE;
		menuInfo.fType = MFT_STRING;
		menuInfo.wID = ID_VIEW_COMMANDBAR;
		menuInfo.dwTypeData = cText;
		menuInfo.cch = sizeof(cText);

		::InsertMenuItem(hSysMenu, 0, MF_BYPOSITION, &menuInfo);
		::SetTimer(m_hWnd, ENT_READ_ACCEL, 200, NULL);

		//�X�L����������
		InitSkin();

		CDonutSimpleEventManager::RaiseEvent(EVENT_INITIALIZE_COMPLETE);

		//Hook InputDialogMessage (javascript prompt())
		CDialogHook::InstallHook(m_hWnd);
		//CSearchBoxHook::InstallSearchHook(m_hWnd);

		//�v���O�C���̃A�[���[���[�f�B���O
		CPluginManager::LoadAllPlugin(PLT_EXPLORERBAR,m_PluginBar);
		//�I�y���[�V�����v���O�C���̃��[�h
		CPluginManager::ReadPluginData(PLT_OPERATION);

		//�h�b�L���O�E�B���h�E�̏�����
		PostMessage(CWM_INITIALIZE);
		
		

		return 0;
		//return lRet;
	}

	LRESULT OnFrameWorkInitialized(UINT /*uMsg*/, WPARAM /*wParam*/, LPARAM /*lParam*/, BOOL& /*bHandled*/)
	{
		//�h�b�L���O�v���O�C���̃��[�h
		m_DockingPluginManager.Init(m_hWnd,m_CmdBar.GetMenu());

		//�h�b�L���O�E�B���h�E�ʒu�̃��[�h
		sstate::CDockWndMgrEx mgrDockWnds(m_hWnd);
		mgrDockWnds.Add(sstate::CDockingWindowStateAdapter<CDonutExplorerBar>(m_ExplorerBar));
		mgrDockWnds.Add(sstate::CDockingWindowStateAdapter<CDonutClipBoardBarContainer>(m_ClipBar));
		mgrDockWnds.Add(sstate::CDockingWindowStateAdapter<CDonutPanelBar>(m_PanelBar));
		mgrDockWnds.Add(sstate::CDockingWindowStateAdapter<CPluginBar>(m_PluginBar));
		int nPluginCount = m_DockingPluginManager.GetCount();
		for(int i=0; i<nPluginCount; i++){
			CDockingPluginWindow* pWindow = m_DockingPluginManager.GetWindow(i);
			DockWindow(*pWindow,dockwins::CDockingSide(dockwins::CDockingSide::sLeft),
						0/*nBar*/,float(0.0)/*fPctPos*/,100/*nWidth*/,100/* nHeight*/);
			mgrDockWnds.Add(sstate::CDockingWindowStateAdapter<CDockingPluginWindow>(*m_DockingPluginManager.GetWindow(i)));
		}
		CString strStateFile = _GetFilePath(_T("windowstate.dat"));
		m_stateMgr.Initialize((LPCTSTR)strStateFile ,_T("unDonut"),m_hWnd);
		m_stateMgr.Add(mgrDockWnds);
		m_stateMgr.Restore();
		//UpdateLayout();

		//���łɃv���O�C���ɏ�����������񂹂�
		CPluginManager::BroadCast_PluginEvent(DEVT_INITIALIZE_COMPLETE,0,0);

		return 0;
	}


	//minit
	BOOL _IsRebarBandLocked()
	{
		CReBarCtrl rebar(m_hWndToolBar);
		REBARBANDINFO rbbi = {0};
		rbbi.cbSize = sizeof(REBARBANDINFO);
		rbbi.fMask = RBBIM_STYLE;
		if(!rebar.GetBandInfo(0,&rbbi)) return FALSE;
		return (rbbi.fStyle & RBBS_NOGRIPPER);
	}
	LRESULT OnViewToolBarLock(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/, BOOL& /*bHandled*/)
	{
		CReBarSupport RebarSup(m_hWndToolBar);
		
		RebarSup.SetBandsLock(!_IsRebarBandLocked());
		return 0;
	}

	//minit
	LRESULT OnViewSearchButton(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/, BOOL& /*bHandled*/)
	{
		m_SearchBar.ShowToolBarIcon(!m_SearchBar.GetToolIconState());
		return 0;
	}

	LRESULT OnMouseWheel(UINT fwKeys, short zDelta, CPoint point)
	{
		// I don't have a wheel mouse...
		if ( (m_MDITab.GetMDITabExtendedStyle() & MTB_EX_WHEEL) &&
			  MtlIsBandVisible(m_hWndToolBar, IDC_MDITAB) ) {
			CRect rcTab;
			m_MDITab.GetWindowRect(&rcTab);
			if (rcTab.PtInRect(point)) {
				if (zDelta > 0) {
					m_MDITab.LeftTab();
				}
				else {
					m_MDITab.RightTab();
				}
				SetMsgHandled(TRUE);
				return 0;
			}
		}

		SetMsgHandled(FALSE);
		return 1;
	}

	LRESULT OnFileRecent(WORD /*wNotifyCode*/, WORD wID, HWND /*hWndCtl*/, BOOL& /*bHandled*/)
	{
		// get file name from the MRU list
		//TCHAR szFile[INTERNET_MAX_PATH_LENGTH];
		//if(CMainOption::s_pMru->GetFromList(wID, szFile))

		if(ID_FILE_MRU_FIRST <= wID && wID <= ID_FILE_MRU_LAST) //���͈�ID����V�͈�ID�֕ϊ�
			wID = wID - ID_FILE_MRU_FIRST + ID_RECENTDOCUMENT_FIRST; 

		CRecentDocumentListFixed::RecentDocEntry Entry;
		if(CMainOption::s_pMru->GetFromList(wID, &Entry))
		{
			DWORD dwOpenFlag = DonutGetStdOpenCreateFlag(); /*DonutGetStdOpenFlag()*/ // Force New Window // UDT DGSTR
			HWND hWndNew = OnUserOpenFile(Entry.szDocName, dwOpenFlag); 
			if(::IsWindow(hWndNew)){
				if(CMainOption::s_bTravelLogClose){
					CChildFrame *pChild= GetChildFrame(hWndNew);
					if(pChild){
						_Load_OptionalData2(pChild,Entry.arrFore,Entry.arrBack);
					}
				}
			}

			CMainOption::s_pMru->RemoveFromList(wID); // UDT DGSTR
		}
		else
		{
			::MessageBeep(MB_ICONERROR);
		}

		return 0;
	}

	LRESULT OnViewRefreshFavBar(WORD /*wNotifyCode*/, WORD wID, HWND /*hWndCtl*/, BOOL& /*bHandled*/)
	{
		m_FavoriteMenu.RefreshMenu();
		m_FavGroupMenu.RefreshMenu();
		m_styleSheetMenu.RefreshMenu();

		return 0;
	}

	LRESULT OnViewIdle(WORD /*wNotifyCode*/, WORD wID, HWND /*hWndCtl*/, BOOL& /*bHandled*/)
	{
		_OnIdleCritical();

		return 0;
	}

	void OnClose()
	{
		SetMsgHandled(FALSE);

		CWindowCloseChecker::Close();

		m_stateMgr.Store();

		if (!CDonutConfirmOption::OnDonutExit(m_hWnd)) {
			SetMsgHandled(TRUE);

			if (IsWindowVisible()==FALSE)
			{
				TrayMessage(m_hWnd, NIM_ADD, TM_TRAY, IDR_MAINFRAME, _T("unDonut")); 
				ShowWindow(SW_HIDE);
				Sleep(100);
			}
			return;
		}

		if (_IsFullScreen()) {
			CMainOption::s_dwMainExtendedStyle |= MAIN_EX_FULLSCREEN;// save style
			_ShowBandsFullScreen(FALSE);// restore bands position
		}
		else {
			CMainOption::s_dwMainExtendedStyle &= ~MAIN_EX_FULLSCREEN;
		}
		
		if (m_nBackUpTimerID != 0)
			KillTimer(m_nBackUpTimerID);

		m_mcCmdBar.Uninstall();
		m_mcToolBar.Uninstall();

		_WriteProfile();

		CMainOption::s_bAppClosing = true;

		// delete cash
		DelTempFiles();
		// delete history
		DelHistory();
	}

	void DelTempFiles()
	{
		BOOL bDelCash = CMainOption::s_dwMainExtendedStyle2 & MAIN_EX2_DEL_CASH ? TRUE:FALSE;
		BOOL bDelCookie = CMainOption::s_dwMainExtendedStyle2 & MAIN_EX2_DEL_COOKIE ? TRUE:FALSE;
//		if (bDelCash==FALSE) return;
		if (bDelCash==FALSE && bDelCookie==FALSE) return;

		BOOL bResult = FALSE;
		BOOL bDone = FALSE;
		LPINTERNET_CACHE_ENTRY_INFO lpCacheEntry = NULL;  
 
		DWORD  dwTrySize, dwEntrySize = 4096; // start buffer size    
		HANDLE hCacheDir = NULL;    
		DWORD  dwError = ERROR_INSUFFICIENT_BUFFER;
    
		do 
		{                               
			switch (dwError)
			{
				// need a bigger buffer
				case ERROR_INSUFFICIENT_BUFFER: 
					delete [] lpCacheEntry;            
					lpCacheEntry = (LPINTERNET_CACHE_ENTRY_INFO) new char[dwEntrySize];
					lpCacheEntry->dwStructSize = dwEntrySize;
					dwTrySize = dwEntrySize;
					BOOL bSuccess;
					if (hCacheDir == NULL)                
                  
						bSuccess = (hCacheDir 
						  = FindFirstUrlCacheEntry(NULL, lpCacheEntry,
						  &dwTrySize)) != NULL;
					else
						bSuccess = FindNextUrlCacheEntry(hCacheDir, lpCacheEntry, &dwTrySize);

					if (bSuccess)
						dwError = ERROR_SUCCESS;    
					else
					{
						dwError = GetLastError();
						dwEntrySize = dwTrySize; // use new size returned
					}
					break;

				 // we are done
				case ERROR_NO_MORE_ITEMS:
					bDone = TRUE;
					bResult = TRUE;                
					break;

				 // we have got an entry
				case ERROR_SUCCESS:                       
					if (bDelCookie && lpCacheEntry->CacheEntryType&COOKIE_CACHE_ENTRY)
						DeleteUrlCacheEntry(lpCacheEntry->lpszSourceUrlName);

//					if (bDelCash && !(lpCacheEntry->CacheEntryType&COOKIE_CACHE_ENTRY))
//						 DeleteUrlCacheEntry(lpCacheEntry->lpszSourceUrlName);

					// Fixed by zzZ(thx
					if (bDelCash && !(lpCacheEntry->CacheEntryType&(COOKIE_CACHE_ENTRY|URLHISTORY_CACHE_ENTRY)))
						DeleteUrlCacheEntry(lpCacheEntry->lpszSourceUrlName);

					// get ready for next entry
					dwTrySize = dwEntrySize;
					if (FindNextUrlCacheEntry(hCacheDir, lpCacheEntry, &dwTrySize))
						dwError = ERROR_SUCCESS;          
					else
					{
						dwError = GetLastError();
						dwEntrySize = dwTrySize; // use new size returned
					}                    
					break;

				// unknown error
				default:
					bDone = TRUE;                
					break;
			}

			if (bDone)
			{   
				delete [] lpCacheEntry; 
				if (hCacheDir)
					FindCloseUrlCache(hCacheDir);         
                                  
			}
		} while (!bDone);
	}

	void DelHistory()
	{
		BOOL bDelHistory = CMainOption::s_dwMainExtendedStyle2 & MAIN_EX2_DEL_HISTORY ? TRUE:FALSE;
		if (bDelHistory==FALSE) return;

		IUrlHistoryStg2* pUrlHistoryStg2 = NULL;
		HRESULT hr = CoCreateInstance(CLSID_CUrlHistory,
			NULL, CLSCTX_INPROC, IID_IUrlHistoryStg2,
			(void**)&pUrlHistoryStg2);
		if (SUCCEEDED(hr))
		{         
			hr = pUrlHistoryStg2->ClearHistory(); 
			pUrlHistoryStg2->Release();
		}
	}

	void OnNewInstance(ATOM nAtom)
	{
		TCHAR szBuff[4096];
		if (::GlobalGetAtomName(nAtom, szBuff, 4096) != 0) {
			dmfTRACE(_T("CMainFrame::OnNewInstance: %s\n"), szBuff);
			OnUserOpenFile(szBuff, DonutGetStdOpenFlag());
			::GlobalDeleteAtom(nAtom);
			if (!(CMainOption::s_dwMainExtendedStyle & MAIN_EX_NOACTIVATE))
				MtlSetForegroundWindow(m_hWnd);
		}
	}


////////////////////////////////////////////////////////////////////////////////
//�t�@�C�����j���[
//�@�R�}���h�n���h��
////////////////////////////////////////////////////////////////////////////////

////�V�K�쐬

//�|�[���y�[�W
	void OnFileNewHome(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/)
	{
		HWND hWndChild = OnUserOpenFile(NULL, DonutGetStdOpenActivateFlag());
		if (hWndChild) {
			CWebBrowser2 browser = DonutGetIWebBrowser2(hWndChild);
			if (browser.m_spBrowser != NULL)
				browser.GoHome();
		}
	}

//���݂̃y�[�W
	void OnFileNewCopy(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/)
	{
		HWND hWndActive = MDIGetActive();
		if (hWndActive) {
			CWebBrowser2 browser = DonutGetIWebBrowser2(hWndActive);
			if (browser.m_spBrowser != NULL) {
				CString strURL = browser.GetLocationURL();
				if (!strURL.IsEmpty())
					OnUserOpenFile(strURL, DonutGetStdOpenActivateFlag());
			}
		}
	}

	LRESULT OnFileNew(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/, BOOL& /*bHandled*/)
	{
		if (CFileNewOption::s_dwFlags == FILENEW_BLANK)
			OnFileNewBlank(0, 0, 0);
		else if (CFileNewOption::s_dwFlags == FILENEW_COPY) {
			if (MDIGetActive() != NULL)
				SendMessage(WM_COMMAND, MAKEWPARAM(ID_FILE_NEW_COPY, 0), 0);
			else
				OnFileNewBlank(0, 0, 0);
		}
		else if (CFileNewOption::s_dwFlags == FILENEW_HOME)
			OnFileNewHome(0, 0, 0);
		else
			ATLASSERT(FALSE);

		return 0;
	}

//�󔒃y�[�W
	void OnFileNewBlank(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/)
	{
		OnUserOpenFile(_T("about:blank"), DonutGetStdOpenActivateFlag());
		SendMessage(WM_COMMAND, ID_SETFOCUS_ADDRESSBAR, 0);
	}

//�N���b�v�{�[�h
	void OnFileNewClipBoard(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/)
	{
		CString strText = MtlGetClipboardText();
		if (strText.IsEmpty())
			return;

		OnUserOpenFile(strText, DonutGetStdOpenActivateFlag());
	}

//Default.dfg
	// UDT DGSTR
	LRESULT OnFileOpenDef(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/, BOOL& /*bHandled*/)
	{	
		CString strPath = MtlGetModuleFileName();

		strPath = strPath.Left(strPath.ReverseFind('\\')) + _T("\\Default.dfg");

		ATLTRACE2(atlTraceGeneral, 4, _T("CMainFrame::OnFileOpenDef\n"));
		OnUserOpenFile(strPath, DonutGetStdOpenCreateFlag());
		return 0;
	}
	// ENDE

	void OnViewHome(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/)
	{
/*		static bSts=TRUE;
		RebarLock(bSts);
		bSts = !bSts;
		return;
*/
		bool bNew = ::GetAsyncKeyState(VK_CONTROL) < 0 || ::GetAsyncKeyState(VK_SHIFT) < 0;
		if (bNew || MDIGetActive() == NULL) {
			OnFileNewHome(0, 0, 0);
		}
		else {
			SetMsgHandled(FALSE);
		}
	}
	
	void OnResized(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/)
	{
		if (m_wndStatusBar.m_hWnd==NULL)
			return;

		CRect rcComboPart;
		if (_bSwapProxy==false)
			m_wndStatusBar.GetRect(4, rcComboPart);
		else
			m_wndStatusBar.GetRect(1, rcComboPart);

		rcComboPart.top -= 1;
		rcComboPart.bottom = rcComboPart.top + rcComboPart.Height()*10;
		m_cmbBox.MoveWindow(rcComboPart, TRUE);

		{
			//�v���O�C���C�x���g - ���T�C�Y
			CPluginManager::BroadCast_PluginEvent(DEVT_CHANGESIZE,0,0);
		}
	}

	// U.H
	void ShowLinkText(BOOL bShow)
	{
		REBARBANDINFO rbBand; 
		memset(&rbBand, 0, sizeof(REBARBANDINFO));
		rbBand.cbSize = sizeof(REBARBANDINFO);

		int nCount = ::SendMessage(m_hWndToolBar,RB_GETBANDCOUNT,0,0);
		for (int ii=0; ii<nCount; ii++)
		{
			rbBand.fMask = RBBIM_ID;
			::SendMessage(m_hWndToolBar, RB_GETBANDINFO, (WPARAM)ii, (LPARAM)(LPREBARBANDINFO)&rbBand);
			if (rbBand.wID!=IDC_LINKBAR && rbBand.wID!=IDC_SEARCHBAR && rbBand.wID!=IDC_ADDRESSBAR) continue; // UDT JOBBY

			rbBand.fMask = RBBIM_TEXT;
			if (bShow)
			{
				// UDT JOBBY
				if (rbBand.wID==IDC_ADDRESSBAR)
					rbBand.lpText = _T("�A�h���X");
				else if (rbBand.wID==IDC_LINKBAR)
					rbBand.lpText = _T("�����N");
				else
					rbBand.lpText = _T("����");
				// ENDE
			}

			::SendMessage(m_hWndToolBar, RB_SETBANDINFO, (WPARAM)ii, (LPARAM)(LPREBARBANDINFO)&rbBand);
		}
	}
	// END

	// U.H
	void OnFileNewSelectText(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/)
	{
		SendMessage(WM_COMMAND, MAKEWPARAM(ID_EDIT_COPY, 0), 0);
		SendMessage(WM_COMMAND, MAKEWPARAM(ID_FILE_NEW_CLIPBOARD, 0), 0);
	}

	// U.H
	void OnShowTextChg(BOOL bShow)
	{
		ShowLinkText(bShow);
		m_AddressBar.ShowAddresText(m_hWndToolBar, bShow);
	}
	
	// U.H
	void OnGoAddresbar(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/)
	{
		m_AddressBar.SetFocus();
	}

	// U.H
	LRESULT OnSysCommand(UINT nID, CPoint point)
	{
		switch(nID)
		{
		case ID_VIEW_COMMANDBAR:
			SendMessage(m_hWnd, WM_COMMAND, ID_VIEW_COMMANDBAR, 0);
			SetMsgHandled(TRUE);
			break;

		default:
			SetMsgHandled(FALSE);
			break;
		}
		return 0;
	}

	LRESULT OnPopupClose(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/)
	{
		CIgnoredURLsOption::s_bValid = !CIgnoredURLsOption::s_bValid;
		return 0;
	}

	LRESULT OnTitleClose(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/)
	{
		CCloseTitlesOption::s_bValid = !CCloseTitlesOption::s_bValid;
		return 0;
	}

	LRESULT OnDoubleClose(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/)
	{
		CIgnoredURLsOption::s_bValid = !CIgnoredURLsOption::s_bValid;
		CCloseTitlesOption::s_bValid = !CCloseTitlesOption::s_bValid;
		return 0;
	}

	LRESULT OnPrivacyReport(WORD /*wNotifyCode*/, WORD wID, HWND /*hWndCtl*/, BOOL& /*bHandled*/)
	{
		HWND hWndActive = MDIGetActive();
		if (hWndActive==NULL) return 0;
		
		CWebBrowser2 browser = DonutGetIWebBrowser2(hWndActive);
		CString strURL = browser.GetLocationURL();
//		COLESTR lpURL = OLESTR(strURL);
		CComBSTR bstrURL(strURL);

		CComPtr<IServiceProvider>  spSP;
		browser.m_spBrowser->QueryInterface(IID_IServiceProvider, (void**) &spSP);
		if (spSP==NULL) return 0;


		CComPtr<IEnumPrivacyRecords>  spEnumRecords;
		spSP->QueryService(CLSID_IEnumPrivacyRecords, &spEnumRecords);		// UH
//		spSP->QueryInterface(IID_IEnumPrivacyRecords, (void**) &spEnumRecords);
//		spSP->QueryInterface(CLSID_IEnumPrivacyRecords, (void**) &spEnumRecords);
		if (spEnumRecords==NULL) return 0;

		HINSTANCE hInstDLL;
		DWORD (WINAPI *__DoPrivacyDlg)(HWND, LPOLESTR, IEnumPrivacyRecords*, BOOL)=NULL;
		if((hInstDLL=LoadLibrary("shdocvw.dll"))==NULL) return 0;
		__DoPrivacyDlg=(DWORD(WINAPI *)(HWND, LPOLESTR, IEnumPrivacyRecords*, BOOL))
			GetProcAddress(hInstDLL, "DoPrivacyDlg");
		
		if (__DoPrivacyDlg==NULL) return 0;
		BOOL bPrivacyImpacted=FALSE;
		spEnumRecords->GetPrivacyImpacted(&bPrivacyImpacted);
		__DoPrivacyDlg(m_hWnd, bstrURL, spEnumRecords, !bPrivacyImpacted);

		return 1;
	}

	// UH
	LRESULT OnCookiesIE6(WORD /*wNotifyCode*/, WORD wID, HWND /*hWndCtl*/)
	{
		DWORD dwLv = 0;
		switch(wID)
		{
		case ID_URLACTION_COOKIES_BLOCK:
			dwLv = PRIVACY_TEMPLATE_NO_COOKIES;			break;
		case ID_URLACTION_COOKIES_HI:
			dwLv=PRIVACY_TEMPLATE_HIGH;					break;
		case ID_URLACTION_COOKIES_MIDHI:
			dwLv = PRIVACY_TEMPLATE_MEDIUM_HIGH;		break;
		case ID_URLACTION_COOKIES_MID:
			dwLv = PRIVACY_TEMPLATE_MEDIUM;				break;
		case ID_URLACTION_COOKIES_LOW:
			dwLv=PRIVACY_TEMPLATE_MEDIUM_LOW;			break;
		case ID_URLACTION_COOKIES_ALL:
			dwLv=PRIVACY_TEMPLATE_LOW;					break;
		}

		HINSTANCE hInstDLL;
		DWORD (WINAPI *__PrivacySetZonePreferenceW)(DWORD, DWORD, DWORD, LPCWSTR)=NULL;
		if((hInstDLL=LoadLibrary("wininet.dll"))==NULL) return 0;
		__PrivacySetZonePreferenceW=(DWORD(WINAPI *)(DWORD, DWORD, DWORD, LPCWSTR))
			GetProcAddress(hInstDLL, "PrivacySetZonePreferenceW");
	
		if (__PrivacySetZonePreferenceW==NULL)
			return 0;

		__PrivacySetZonePreferenceW(URLZONE_INTERNET, PRIVACY_TYPE_FIRST_PARTY, dwLv, NULL);
		__PrivacySetZonePreferenceW(URLZONE_INTERNET, PRIVACY_TYPE_THIRD_PARTY, dwLv, NULL);
		return 0;
	}

	LRESULT OnHilight(LPCTSTR lpszKeyWord)
	{
		HWND hWndActive = MDIGetActive();
		if (hWndActive==NULL) return 0;

		return SendMessage(hWndActive, WM_USER_HILIGHT, (WPARAM)lpszKeyWord, 0);
	}
	LRESULT OnFindKeyWord(LPCTSTR lpszKeyWord, BOOL bBack)
	{
		HWND hWndActive = MDIGetActive();
		if (hWndActive==NULL) return 0;

		return SendMessage(hWndActive, WM_USER_FIND_KEYWORD, (WPARAM)lpszKeyWord, (LPARAM)bBack);
	}

	LRESULT OnWindowCloseCmp(int nTarIndex, BOOL bLeft)
	{
		HWND hWndActive = MDIGetActive();
		if (hWndActive==NULL) return 0;

		CSimpleArray<HWND> arrWnd;
		for (int ii=0; ii<m_MDITab.GetItemCount(); ii++)
		{
			HWND hWnd = m_MDITab.GetTabHwnd(ii);
			if (bLeft && ii<nTarIndex)
				arrWnd.Add(hWnd);
			else if (bLeft==FALSE && ii>nTarIndex)
				arrWnd.Add(hWnd);
		}

		for (ii=0; ii<arrWnd.GetSize(); ii++)
		{
			SendMessage(arrWnd[ii], WM_CLOSE, 0, 0);
		}

		return 1;
	}

	LRESULT OnChangeCSS(LPCTSTR lpszStyleSheet)
	{
		if(CStyleSheetOption::s_bSetUserSheet)
			CStyleSheetOption::SetUserSheetName(lpszStyleSheet);  //minit

		HWND hWndActive = MDIGetActive();
		if (hWndActive==NULL) return 0;

		return SendMessage(hWndActive, WM_USER_CHANGE_CSS, (WPARAM)lpszStyleSheet, 0);
	}

	LRESULT OnSearchBarCmd(WORD /*wNotifyCode*/, WORD wID, HWND /*hWndCtl*/, BOOL& /*bHandled*/)
	{	
		HWND hWndActive = MDIGetActive();
		if (hWndActive==NULL) return 0;

		CEdit edit = m_SearchBar.GetEditCtrl();
		CString str = MtlGetWindowText(edit);
		str = _GetSelectText(edit);
		if (str.IsEmpty()) return 0;

		switch(wID)
		{
		case ID_SERACHBAR_SEL_UP:
			m_SearchBar.SearchPage(FALSE);
			//SendMessage(hWndActive, WM_USER_FIND_KEYWORD, (WPARAM)str.GetBuffer(0), (LPARAM)FALSE);
			break;

		case ID_SERACHBAR_SEL_DOWN:
			m_SearchBar.SearchPage(TRUE);
			//SendMessage(hWndActive, WM_USER_FIND_KEYWORD, (WPARAM)str.GetBuffer(0), (LPARAM)TRUE);
			break;

		case ID_SERACHBAR_HILIGHT:
			m_SearchBar.SearchHilight();
			//SendMessage(hWndActive, WM_USER_HILIGHT, (WPARAM)str.GetBuffer(0), (LPARAM)0);
			break;
		}

		return 0;
	}

	// U.H
	LRESULT OnInitMenuPopup(HMENU hMenuPopup, UINT uPos, BOOL bSystemMenu)
	{
		// �V�X�e�����j���[�́A�������Ȃ�
		if (bSystemMenu) return 0;
		if (m_FavoriteMenu.m_menu==hMenuPopup) return 0;
		if (m_FavGroupMenu.m_menu==hMenuPopup) return 0;
		if (m_styleSheetMenu.m_menu==hMenuPopup) return 0;

		CMenuHandle menu=hMenuPopup;
		CAccelerManager accel(m_hAccel);

		// ��Ԗڂ̃��j���[������Ȃ����́A�����������
		// �ҏW���Ȃ�
		CString strCmd;
		if (menu.GetMenuString(0, strCmd, MF_BYPOSITION) == 0)
		{
			menu.RemoveMenu(0, MF_BYPOSITION);
			return 0;
		}

		if (CMainOption::s_dwMainExtendedStyle2 & MAIN_EX2_NOCSTMMENU)
			return 0;

		for (int ii=0; ii<menu.GetMenuItemCount(); ii++)
		{
			strCmd = _T("");
			UINT nID = menu.GetMenuItemID(ii);
			menu.GetMenuString(nID, strCmd, MF_BYCOMMAND);
			if (strCmd.IsEmpty())
			{	
				// NT4�p����
				if (strCmd.LoadString(nID)==FALSE)
					continue;
			}

			CString strShorCut;
			if ( !accel.FindAccelerator(nID, strShorCut) ) //�t�ɂȂ��Ă��̂ŏC�� minit
				continue;

			if (strCmd.Find("\t")!=-1)
			{
				strCmd = strCmd.Left(strCmd.Find("\t"));
			}
			if (strShorCut.IsEmpty()==FALSE)
				strCmd = strCmd + _T("\t") + strShorCut;

			UINT uState = menu.GetMenuState(nID, MF_BYCOMMAND);
			menu.ModifyMenu(nID, MF_BYCOMMAND, nID, strCmd);
			if (uState&MF_CHECKED)
				menu.CheckMenuItem(nID, MF_CHECKED);
			if (uState&MF_GRAYED)
				menu.EnableMenuItem(nID, MF_GRAYED);
		}
		return 0;
	}

	// UDT DGSTR //Update minit
	LRESULT OnFavoriteExpBar(WORD /*wNotifyCode*/, WORD wID, HWND /*hWndCtl*/, BOOL& /*bHandled*/)
	{
		m_ExplorerBar.ShowBar(true);
		MtlSendCommand(m_ExplorerBar.m_FavBar.m_hWnd, wID);
		return 0;
	}

	

	void OnRegisterAsBrowser(WORD wNotifyCode, WORD /*wID*/, HWND /*hWndCtl*/)
	{
		if (wNotifyCode == NM_ON) {
			MtlForEachMDIChild(m_hWndMDIClient, CSendCommand(ID_REGISTER_AS_BROWSER, NM_ON));
		}
		else if (wNotifyCode == NM_OFF) {
			MtlForEachMDIChild(m_hWndMDIClient, CSendCommand(ID_REGISTER_AS_BROWSER, NM_OFF));
		}
		else if (!_check_flag(MAIN_EX_REGISTER_AS_BROWSER, CMainOption::s_dwMainExtendedStyle)) {
			CMainOption::s_dwMainExtendedStyle |= MAIN_EX_REGISTER_AS_BROWSER;
			MtlForEachMDIChild(m_hWndMDIClient, CSendCommand(ID_REGISTER_AS_BROWSER, NM_ON));
		}
		else {
			CMainOption::s_dwMainExtendedStyle &= ~MAIN_EX_REGISTER_AS_BROWSER;
			MtlForEachMDIChild(m_hWndMDIClient, CSendCommand(ID_REGISTER_AS_BROWSER, NM_OFF));
		}
	}

	

	void OnFileNewClipBoard2(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/)
	{
		CString strText = MtlGetClipboardText();
		if (strText.IsEmpty())
			return;

		OnUserOpenFile(strText, DonutGetStdOpenFlag());// allow the option
	}

	void OnFileNewClipBoardEx(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/)
	{
		m_ClipBar.OpenClipboardUrl();
	}

	

	void OnFileWorkOffline(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/)
	{
		MtlSetGlobalOffline(!MtlIsGlobalOffline());
		UpdateTitleBarUpsideDown();
	}


	LRESULT OnFileOpen(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/, BOOL& /*bHandled*/)
	{
		dmfTRACE(_T("CMainFrame::OnFileOpen\n"));
		COpenURLDlg dlg;
		if (dlg.DoModal() == IDOK && !dlg.m_strEdit.IsEmpty()) {
			OnUserOpenFile(dlg.m_strEdit, DonutGetStdOpenFlag());
		}
		return 0;
	}
	LRESULT OnFileExit(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/, BOOL& /*bHandled*/)
	{
		PostMessage(WM_CLOSE);
		return 0;
	}

	void OnEditCut(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/)
	{	
		CEdit editAddress = m_AddressBar.GetEditCtrl();
		CEdit editSearch = m_SearchBar.GetEditCtrl();
		if (::GetFocus()==editAddress)
		{
			editAddress.Cut();
		}
		else if (::GetFocus()==editSearch)
		{
			editSearch.Cut();
		}
		else
		{
			SetMsgHandled(FALSE);
			return;
		}
	}

	void OnEditCopy(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/)
	{
		CEdit editAddress = m_AddressBar.GetEditCtrl();
		CEdit editSearch = m_SearchBar.GetEditCtrl();
		if (::GetFocus()==editAddress)
		{
			editAddress.Copy();
		}
		else if (::GetFocus()==editSearch)
		{
			editSearch.Copy();
		}
		else
		{
			SetMsgHandled(FALSE);
			return;
		}
	}

	void OnEditPaste(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/)
	{
		CEdit editAddress = m_AddressBar.GetEditCtrl();
		CEdit editSearch = m_SearchBar.GetEditCtrl();
		if (::GetFocus()==editAddress)
		{
			editAddress.Paste();
		}
		else if (::GetFocus()==editSearch)
		{
			editSearch.Paste();
		}
		else
		{
			SetMsgHandled(FALSE);
			return;
		}
	}

	void OnEditSelectAll(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/)
	{
		CEdit edit = m_AddressBar.GetEditCtrl();
		if (::GetFocus() != edit) {
			SetMsgHandled(FALSE);
			return;
		}

		edit.SetSel(0, -1);

	}

	// U.H
	LRESULT OnViewSearchBar(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/, BOOL& /*bHandled*/)
	{
		MtlToggleBandVisible(m_hWndToolBar, IDC_SEARCHBAR);
		UpdateLayout();
		return 0;
	}

	// U.H
	LRESULT OnViewCommandBar(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/, BOOL& /*bHandled*/)
	{
		MtlToggleBandVisible(m_hWndToolBar, ATL_IDW_COMMAND_BAR);
		UpdateLayout();
		return 0;
	}

	LRESULT OnViewToolBar(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/, BOOL& /*bHandled*/)
	{
		// It sucks, band index is dynamic.
		// ::SendMessage(m_hWndToolBar, RB_SHOWBAND, 0, bNew);	// toolbar is band #0
		MtlToggleBandVisible(m_hWndToolBar, ATL_IDW_TOOLBAR);
		UpdateLayout();
		return 0;
	}
	LRESULT OnViewAddressBar(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/, BOOL& /*bHandled*/)
	{
		MtlToggleBandVisible(m_hWndToolBar, IDC_ADDRESSBAR);
		UpdateLayout();
		return 0;
	}
	LRESULT OnViewLinkBar(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/, BOOL& /*bHandled*/)
	{
		MtlToggleBandVisible(m_hWndToolBar, IDC_LINKBAR);
		UpdateLayout();
		return 0;
	}

	LRESULT OnViewGoButton(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/, BOOL& /*bHandled*/)
	{
		if (_check_flag(ABR_EX_GOBTNVISIBLE, m_AddressBar.GetAddressBarExtendedStyle()))
			m_AddressBar.ModifyAddressBarExtendedStyle(ABR_EX_GOBTNVISIBLE, 0);
		else
			m_AddressBar.ModifyAddressBarExtendedStyle(0, ABR_EX_GOBTNVISIBLE);

		return 0;
	}
	LRESULT OnViewTabBar(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/, BOOL& /*bHandled*/)
	{
		MtlToggleBandVisible(m_hWndToolBar, IDC_MDITAB);
		UpdateLayout();
		return 0;
	}
	
	LRESULT OnViewTabBarMulti(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/, BOOL& /*bHandled*/)
	{
		DWORD dwOldStyle = m_MDITab.GetMDITabExtendedStyle();
		if (dwOldStyle & MTB_EX_MULTILINE)
			dwOldStyle &= ~MTB_EX_MULTILINE;
		else
			dwOldStyle |= MTB_EX_MULTILINE;

		m_MDITab.SetMDITabExtendedStyle(dwOldStyle);
		return 0;
	}

	LRESULT OnViewAddBarDropDown(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/, BOOL& /*bHandled*/)
	{
		if (m_AddressBar.GetDroppedStateEx())
			m_AddressBar.ShowDropDown(FALSE);
		else
			m_AddressBar.ShowDropDown(TRUE);

		return 0;
	}

	LRESULT OnViewStatusBar(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/, BOOL& /*bHandled*/)
	{
		BOOL bNew = !::IsWindowVisible(m_hWndStatusBar);
		m_bStatusBarVisibleUnlessFullScreen = bNew;// save
		::ShowWindow(m_hWndStatusBar, bNew ? SW_SHOWNOACTIVATE : SW_HIDE);
		UpdateLayout();
		return 0;
	}
	LRESULT OnViewToolBarCust(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/, BOOL& /*bHandled*/)
	{
		m_ToolBar.StdToolBar_Customize();
		return 0;
	}

	

	void OnFavoriteOrganize(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/)
	{
		bool bOldShell = _check_flag(MAIN_EX_ORGFAVORITEOLDSHELL, CMainOption::s_dwMainExtendedStyle);
//		CString strPath = DonutGetFavoritesFolder();
//		MtlOrganizeFavorite(m_hWnd, bOldShell, strPath);
		MtlOrganizeFavorite(m_hWnd, bOldShell, DonutGetFavoritesFolder());
	}

	void OnBackUpOptionChanged(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/)
	{
		if (m_nBackUpTimerID != 0) {
			KillTimer(m_nBackUpTimerID);
			m_nBackUpTimerID = 0;
		}

		if (CMainOption::s_dwMainExtendedStyle & MAIN_EX_BACKUP)
			m_nBackUpTimerID = SetTimer(1, 1000*60*CMainOption::s_dwBackUpTime);
	}

	void OnTimer(UINT nIDEvent, TIMERPROC)
	{
		switch(nIDEvent)
		{
		case ENT_READ_ACCEL:
			if (m_hAccel==NULL) break;
			{
				CAccelerManager accelManager(m_hAccel);
				m_hAccel = accelManager.LoadAccelaratorState(m_hAccel);
				::KillTimer(m_hWnd, nIDEvent);
			}
			break;
		default:
			if (m_nBackUpTimerID != nIDEvent)
			{
				SetMsgHandled(FALSE);
				return;
			}

			//�X���b�h���g�p����default.dfg��ۑ�����
			if(m_hGroupThread == NULL){
				DWORD dwThreadID = 0;
				m_hGroupThread = ::CreateThread(NULL,0,_GroupThread,(LPVOID)this,0,&dwThreadID);
				::SetThreadPriority(m_hGroupThread,THREAD_PRIORITY_IDLE);
				
			}else{
				DWORD dwReturnCode = 0;
				::GetExitCodeThread(m_hGroupThread,&dwReturnCode);
				if(dwReturnCode == STILL_ACTIVE){
					::TerminateThread(m_hGroupThread,1);
				}

				::CloseHandle(m_hGroupThread);
				m_hGroupThread = NULL;
				OnTimer(nIDEvent,NULL);
			}
			break;
		}
	}

	static DWORD WINAPI _GroupThread(LPVOID param)
	{
		CMainFrame *pMainFrame = (CMainFrame*)param;
		pMainFrame->_SaveGroupOption(CStartUpOption::GetDefaultDFGFilePath());
		return 0;
	}


	void OnViewOptionDonut(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/)
	{
		ShowNewStyleDonutOption();
		return;
	}

	void ShowNewStyleDonutOption()
	{
		BOOL bSkinChange = FALSE;

		//CMenu menu = menuMng.LoadFullMenu();
		CMenu menu = CExMenuManager::LoadFullMenu();

		CMainPropertyPage pageMain(m_hWnd);
		CMainPropertyPage2 pageMain2(m_hWnd);
		CDLControlPropertyPage pageDLC(m_hWnd);
		CMDITabPropertyPage pageTab(&m_MDITab,menu.m_hMenu);
		CDonutAddressBarPropertyPage pageAddress(m_AddressBar,m_SearchBar);
		CDonutFavoritesMenuPropertyPage pageFav;
		CFileNewPropertyPage pageFileNew;
		CStartUpPropertyPage pageStartUp;
		CProxyPropertyPage pageProxy;
		CKeyBoardPropertyPage pageKeyBoard(m_hAccel, menu.m_hMenu);
		CToolBarPropertyPage pageToolBar(menu.m_hMenu, &m_ToolBar.m_arrStdBtn, &bSkinChange);
		CMousePropertyPage pageMouse(menu.m_hMenu);
		CMouseGesturePropertyPage pageGesture(menu.m_hMenu);
		CSearchPropertyPage pageSearch;
		CMenuPropertyPage pageMenu(menu.m_hMenu);
		CExplorerPropertyPage pageExplorer;
		CDestroyPropertyPage pageDestroy;
		CSkinPropertyPage pageSkin(m_hWnd,&bSkinChange);

		CString strURL, strTitle;
		HWND hWndActive = MDIGetActive();
		if (hWndActive) {
			CWebBrowser2 browser = DonutGetIWebBrowser2(hWndActive);
			if (browser.m_spBrowser != NULL) {
				strURL = browser.GetLocationURL();
				strTitle = MtlGetWindowText(hWndActive);// pChild->get_LocationName();
			}
		}

		CIgnoredURLsPropertyPage pageURLs(strURL);
		CCloseTitlesPropertyPage		pageTitles( strTitle );
		//CDeterrentPropertyPage			pageDeterrent( strURL, strTitle );
		CDonutExecutablePropertyPage	pageExe;
		CDonutConfirmPropertyPage		pageCnf;
		CPluginPropertyPage				pagePlugin;

		CTreeViewPropertySheet sheet( _T("Donut�̃I�v�V����") );
		//CCenterPropertySheet sheet( _T("Donut�̃I�v�V����") );
		sheet.AddPage( pageMain			);
		sheet.AddPage( pageMain2	 ,1	);
		sheet.AddPage( pageToolBar		);
		sheet.AddPage( pageTab		 ,1	);
		sheet.AddPage( pageAddress	 ,0	);
		sheet.AddPage( pageSearch	 ,0	);
		sheet.AddPage( pageExplorer  ,0 );
		sheet.AddPage( pageMenu			);
		sheet.AddPage( pageFav		 ,1	);
		sheet.AddPage( pageKeyBoard	 	);
		sheet.AddPage( pageMouse	 	);
		sheet.AddPage( pageGesture   ,1 );
		sheet.AddPage( pageFileNew	 	);
		sheet.AddPage( pageStartUp		);
		sheet.AddPage( pageDestroy      );
		sheet.AddPage( pageDLC		 	);
		sheet.AddPage( pageURLs		 ,1 );
		sheet.AddPage( pageTitles	 ,0	);
		//sheet.AddPage( pageDeterrent	);
		
		sheet.AddPage( pageExe			);
		sheet.AddPage( pageCnf			);
		sheet.AddPage( pageProxy		);
		sheet.AddPage( pageSkin         );
		sheet.AddPage( pagePlugin		);

		sheet.DoModal();
//			m_LinkBar.m_ExpMenu.SetStyle(m_FavoriteMenu.GetStyle());
//		}
		m_cmbBox.ResetProxyList();
	
		// �L�[�̌ďo
		CAccelerManager accelManager(m_hAccel);
		m_hAccel = accelManager.LoadAccelaratorState(m_hAccel);


	}

	void OnViewOption(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/)
	{
		if (MDIGetActive() == NULL)
			MtlShowInternetOptions();
	}

	LRESULT OnWindowCloseAll(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/, BOOL& /*bHandled*/)
	{
		if (!CDonutConfirmOption::OnCloseAll(m_hWnd))
			return 0;

		CWaitCursor cur;
		CLockRedrawMDIClient lock(m_hWndMDIClient);
		CLockRedraw lock2(m_MDITab);
		MtlCloseAllMDIChildren(m_hWndMDIClient);
		return 0;
	}

	bool _IsFullScreen()
	{
		if (GetStyle() & WS_CAPTION)
			return false;
		else
			return true;
	}

	struct _Function_FullScreen
	{
		CMainFrame& _wndMain;
		_Function_FullScreen(CMainFrame& wndMain) : _wndMain(wndMain) { }
		bool operator()()
		{
			if (CMainOption::s_dwMainExtendedStyle & MAIN_EX_FULLSCREEN) {
				_wndMain._FullScreen(TRUE);
				return true;
			}

			return false;
		}
	};

	void _ShowBandsFullScreen(BOOL bOn, bool bInit = false)
	{
		static BOOL /*bOldVisibleToolBar, bOldVisibleAddressBar,
			bOldVisibleGoButton, bOldVisibleMDITab, bOldVisibleLinkBar, 
			bOldVisibleSearchBar, bOldVisibleCommandBar, */bOldVisibleStatusBar;

		int nIndex=0;
/*		if (bInit) {
			m_mapToolbarOldVisible.RemoveAll();
			for ( nIndex=0; nIndex<_countof(STDBAR_ID); nIndex++ )
				m_mapToolbarOldVisible.Add( STDBAR_ID[nIndex], MtlIsBandVisible( m_hWndToolBar, STDBAR_ID[nIndex] ));
			for ( nIndex=0; nIndex<m_mapToolbarPlugin.GetSize(); nIndex++ )
				m_mapToolbarOldVisible.Add( IDC_PLUGIN_TOOLBAR+nIndex, MtlIsBandVisible( m_hWndToolBar, IDC_PLUGIN_TOOLBAR+nIndex ));

// 			bOldVisibleToolBar		= MtlIsBandVisible(m_hWndToolBar, ATL_IDW_TOOLBAR);
//			bOldVisibleAddressBar	= MtlIsBandVisible(m_hWndToolBar, IDC_ADDRESSBAR);
//			bOldVisibleMDITab		= MtlIsBandVisible(m_hWndToolBar, IDC_MDITAB);
//			bOldVisibleLinkBar		= MtlIsBandVisible(m_hWndToolBar, IDC_LINKBAR);
//			bOldVisibleSearchBar	= MtlIsBandVisible(m_hWndToolBar, IDC_SEARCHBAR);
//			bOldVisibleCommandBar	= MtlIsBandVisible(m_hWndToolBar, ATL_IDW_COMMAND_BAR);
			bOldVisibleStatusBar	= ::IsWindowVisible(m_hWndStatusBar);
			return;
		}
*/	
		if (bOn) {// remove caption
			// save prev visible
			int nToolbarPluginCount = CPluginManager::GetCount(PLT_TOOLBAR);
			m_mapToolbarOldVisible.RemoveAll();
			for (nIndex=0; nIndex<_countof(STDBAR_ID); nIndex++)
				m_mapToolbarOldVisible.Add( STDBAR_ID[nIndex], MtlIsBandVisible( m_hWndToolBar, STDBAR_ID[nIndex] ));
			for ( nIndex=0; nIndex<nToolbarPluginCount; nIndex++ )
				m_mapToolbarOldVisible.Add( IDC_PLUGIN_TOOLBAR+nIndex, MtlIsBandVisible( m_hWndToolBar, IDC_PLUGIN_TOOLBAR+nIndex ));
// 			bOldVisibleToolBar = MtlIsBandVisible(m_hWndToolBar, ATL_IDW_TOOLBAR);
//			bOldVisibleAddressBar = MtlIsBandVisible(m_hWndToolBar, IDC_ADDRESSBAR);
//			bOldVisibleMDITab = MtlIsBandVisible(m_hWndToolBar, IDC_MDITAB);
//			bOldVisibleLinkBar = MtlIsBandVisible(m_hWndToolBar, IDC_LINKBAR);
//			bOldVisibleSearchBar = MtlIsBandVisible(m_hWndToolBar, IDC_SEARCHBAR);
//			bOldVisibleCommandBar = MtlIsBandVisible(m_hWndToolBar, ATL_IDW_COMMAND_BAR);
			bOldVisibleStatusBar = ::IsWindowVisible(m_hWndStatusBar);

			DWORD dwVal=0;
			CIniSection pr;
			pr.Open(_szIniFileName, _T("FullScreen"));

			dwVal = FALSE;	pr.QueryValue(dwVal, _T("ShowMenu"));
			MtlShowBand(m_hWndToolBar, ATL_IDW_COMMAND_BAR, dwVal);

			dwVal = FALSE;	pr.QueryValue(dwVal, _T("ShowToolBar"));
			MtlShowBand(m_hWndToolBar, ATL_IDW_TOOLBAR, dwVal);
			
			dwVal = FALSE;	pr.QueryValue(dwVal, _T("ShowAdress"));
			MtlShowBand(m_hWndToolBar, IDC_ADDRESSBAR, dwVal);
	
			dwVal = FALSE;	pr.QueryValue(dwVal, _T("ShowTab"));
			MtlShowBand(m_hWndToolBar, IDC_MDITAB, dwVal);
			
			dwVal = FALSE;	pr.QueryValue(dwVal, _T("ShowLink"));
			MtlShowBand(m_hWndToolBar, IDC_LINKBAR, dwVal);
			
			dwVal = FALSE;	pr.QueryValue(dwVal, _T("ShowSearch"));
			MtlShowBand(m_hWndToolBar, IDC_SEARCHBAR, dwVal);
			
			dwVal = FALSE;	pr.QueryValue(dwVal, _T("ShowStatus"));
			if (dwVal==FALSE)
				::ShowWindow(m_hWndStatusBar, SW_HIDE);
			else
				::ShowWindow(m_hWndStatusBar, SW_SHOWNOACTIVATE);
			pr.Close();

			for ( nIndex=0; nIndex<nToolbarPluginCount; nIndex++ )
				MtlShowBand(m_hWndToolBar, IDC_PLUGIN_TOOLBAR+nIndex, FALSE);
		}
		else {
			// restore prev visible
//			MtlShowBand(m_hWndToolBar, ATL_IDW_COMMAND_BAR, bOldVisibleCommandBar);// show it.
//			MtlShowBand(m_hWndToolBar, ATL_IDW_TOOLBAR, bOldVisibleToolBar);// show it.
//			MtlShowBand(m_hWndToolBar, IDC_ADDRESSBAR, bOldVisibleAddressBar);
//			MtlShowBand(m_hWndToolBar, IDC_MDITAB, bOldVisibleMDITab);// show it
//			MtlShowBand(m_hWndToolBar, IDC_LINKBAR, bOldVisibleLinkBar);
//			MtlShowBand(m_hWndToolBar, IDC_SEARCHBAR, bOldVisibleSearchBar);
			for ( nIndex=0; nIndex<m_mapToolbarOldVisible.GetSize(); nIndex++ )
				MtlShowBand(m_hWndToolBar, m_mapToolbarOldVisible.GetKeyAt(nIndex), m_mapToolbarOldVisible.GetValueAt(nIndex));

			::ShowWindow(m_hWndStatusBar, bOldVisibleStatusBar ? SW_SHOWNOACTIVATE : SW_HIDE);
		}
	}

	void _FullScreen(BOOL bOn)
	{
		static BOOL bOldMaximized;

		_ShowBandsFullScreen(bOn);

		if (bOn) {// remove caption
			// save prev visible
			CWindowPlacement wndpl;
			GetWindowPlacement(&wndpl);
			bOldMaximized = (wndpl.showCmd == SW_SHOWMAXIMIZED);

			ModifyStyle(WS_CAPTION, 0);

			ShowWindow(SW_HIDE);
			SetMenu(NULL);

			m_mcToolBar.m_bVisible = true;
			if (!bOldMaximized)
				ShowWindow(SW_MAXIMIZE);
			else {
				ShowWindow(SW_MAXIMIZE);
				SetWindowPos(NULL, 0, 0, 0, 0,
					SWP_NOSIZE|SWP_NOMOVE|SWP_NOACTIVATE|SWP_NOZORDER|SWP_FRAMECHANGED);
			}
		}
		else {
			m_mcToolBar.m_bVisible = false;
			// restore prev visible
			ModifyStyle(0, WS_CAPTION);

			if (!bOldMaximized)
				ShowWindow(SW_RESTORE);
			else {
				SetWindowPos(NULL, 0, 0, 0, 0,
					SWP_NOSIZE|SWP_NOMOVE|SWP_NOACTIVATE|SWP_NOZORDER|SWP_FRAMECHANGED);
			}
		}
	}

	void OnViewFullScreen(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/)
	{
		if (GetStyle() & WS_CAPTION) {// remove caption
			_FullScreen(TRUE);
		}
		else {
			_FullScreen(FALSE);
		}

//		SetWindowPos(NULL, 0, 0, 0, 0,
//			SWP_NOSIZE|SWP_NOMOVE|SWP_NOACTIVATE|SWP_NOZORDER|SWP_FRAMECHANGED);
	}

	void OnFavoriteGroupSave(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/)
	{
		if (MDIGetActive() == NULL)
			return;

		TCHAR szOldPath[MAX_PATH];// save current directory
		::GetCurrentDirectory(MAX_PATH, szOldPath);

		const TCHAR szFilter[] = _T("Donut Favorite Group�t�@�C��(*.dfg)\0*.dfg\0\0");

		::SetCurrentDirectory(DonutGetFavoriteGroupFolder());

		CFileDialog fileDlg(FALSE, _T("dfg"), NULL, OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT, szFilter);
		fileDlg.m_ofn.lpstrInitialDir = DonutGetFavoriteGroupFolder();
		fileDlg.m_ofn.lpstrTitle = _T("���C�ɓ���O���[�v�̕ۑ�");
		if (fileDlg.DoModal() == IDOK) {
			_SaveGroupOption(fileDlg.m_szFileName);
			::SendMessage(m_hWnd,WM_REFRESH_EXPBAR,1,0);
		}

		// restore current directory
		::SetCurrentDirectory(szOldPath);
	}

	void OnFavoriteGroupOrganize(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/)
	{
		::ShellExecute(m_hWnd, NULL, DonutGetFavoriteGroupFolder(), NULL, NULL, SW_SHOWNORMAL);
	}

	void OnViewRefreshAll(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/)
	{
		MtlForEachMDIChild(m_hWndMDIClient, CPostCommand(ID_VIEW_REFRESH));
	}

	void OnViewStopAll(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/)
	{
		MtlForEachMDIChild(m_hWndMDIClient, CPostCommand(ID_VIEW_STOP));
	}

	void OnSetFocusAddressBar(WORD /*wNotifyCode*/, WORD /*wID*/, HWND hWndCtl)
	{
		::SetFocus(m_AddressBar.GetEditCtrl());
	}

	void OnSetFocusSearchBar(WORD /*wNotifyCode*/, WORD /*wID*/, HWND hWndCtl)
	{
		::SetFocus(m_SearchBar.GetEditCtrl());
	}

	void OnSetFocusSearchBarEngine(WORD /*wNotifyCode*/, WORD /*wID*/, HWND hWndCtl)
	{ //minit
		m_SearchBar.SetFocusToEngine();
	}

	void OnTabLeft(WORD /*wNotifyCode*/, WORD /*wID*/, HWND hWndCtl)
	{
		m_MDITab.LeftTab();
	}

	void OnTabRight(WORD /*wNotifyCode*/, WORD /*wID*/, HWND hWndCtl)
	{
		m_MDITab.RightTab();
	}

	void __AddToAddressBoxUnique(const CString& strURL)
	{
		COMBOBOXEXITEM item;
		item.mask = CBEIF_TEXT;
		item.iItem = 0;
		item.pszText = (LPTSTR)(LPCTSTR)strURL;

		// search the same string
		int nCount = m_AddressBar.GetCount();
		for (int n = 0; n < nCount; ++n) {
			CString str;
			MtlGetLBTextFixed(m_AddressBar, n, str);
			if (strURL == str) {
				m_AddressBar.DeleteItem(n);
				break;
			}
		}

		m_AddressBar.InsertItem(&item);
	}
	
	void __MoveToTopAddressBox(const CString& strURL)
	{
		COMBOBOXEXITEM item;
		item.mask = CBEIF_TEXT;
		item.iItem = 0;
		item.pszText = (LPTSTR)(LPCTSTR)strURL;
		
		// search the same string
		int nCount = m_AddressBar.GetCount();
		for (int n = 0; n < nCount; ++n) {
			CString str;
			MtlGetLBTextFixed(m_AddressBar, n, str);
			if (strURL == str) {
				m_AddressBar.DeleteItem(n);
				m_AddressBar.InsertItem(&item);
				break;
			}
		}
	}

// Implementation
private:
	void _ReadProfile()
	{
		CIniSection pr;

		// read tab
		pr.Open(_szIniFileName, _T("MDITab"));
		MtlGetProfileMDITab(pr, m_MDITab);
		pr.Close();

		// �t�H���g
		MTL::CLogFont lf;
		if (m_font.m_hFont)
		{
			m_font.GetLogFont(lf);
			m_MDITab.SetMDITabLogFont(lf);
		}

		OnBackUpOptionChanged(0, 0, 0);
	}

	void _WriteProfile()
	{
		CIniSection pr;

		// save frame and status bar
		pr.Open(_szIniFileName, _T("Main"));
		MtlWriteProfileMainFrameState(pr, m_hWnd);
		MtlWriteProfileStatusBarState(pr, m_hWndStatusBar);
		pr.Close();

		// save MDI tab
		pr.Open(_szIniFileName, _T("MDITab"));
		MtlWriteProfileMDITab(pr, m_MDITab);
		pr.Close();

		// save rebar
		pr.Open(_szIniFileName, _T("ReBar"));
		MtlWriteProfileReBarBandsState(pr, m_hWndToolBar);
		pr.Close();

		// save group options
		_SaveGroupOption(CStartUpOption::GetDefaultDFGFilePath());
	}

// Overrides WTL sucks
public:
	static BOOL AddSimpleReBarBandCtrl(HWND hWndReBar, HWND hWndBand, int nID, LPTSTR lpstrTitle, UINT fStyle, int cxWidth, BOOL bFullWidthAlways, HBITMAP hBitmap = NULL)
	{
		dmfTRACE(_T("CMainFrame::AddSimpleReBarBandCtrl\n"));
		ATLASSERT(::IsWindow(hWndReBar));	// must be already created
		ATLASSERT(::IsWindow(hWndBand));	// must be already created
		MTLASSERT_KINDOF(REBARCLASSNAME, hWndReBar);

		// Set band info structure
		REBARBANDINFO rbBand;
		rbBand.cbSize = sizeof(REBARBANDINFO);
#if (_WIN32_IE >= 0x0400)
		rbBand.fMask = RBBIM_CHILD | RBBIM_CHILDSIZE | RBBIM_STYLE | RBBIM_ID | RBBIM_SIZE | RBBIM_IDEALSIZE;
#else
		rbBand.fMask = RBBIM_CHILD | RBBIM_CHILDSIZE | RBBIM_STYLE | RBBIM_ID | RBBIM_SIZE;
#endif //!(_WIN32_IE >= 0x0400)

		rbBand.fMask |= RBBIM_BACKGROUND | RBBIM_TEXT;
		rbBand.fStyle = fStyle;
		rbBand.lpText = lpstrTitle;
		rbBand.hwndChild = hWndBand;
		rbBand.wID = nID;

		rbBand.hbmBack = hBitmap;
		rbBand.fStyle |= RBBS_FIXEDBMP;

		// Calculate the size of the band
		BOOL bRet;
		RECT rcTmp;
		int nBtnCount = (int)::SendMessage(hWndBand, TB_BUTTONCOUNT, 0, 0L);
		if(nBtnCount > 0)
		{

			bRet = (BOOL)::SendMessage(hWndBand, TB_GETITEMRECT, nBtnCount - 1, (LPARAM)&rcTmp);
			ATLASSERT(bRet);
			rbBand.cx = (cxWidth != 0) ? cxWidth : rcTmp.right;
			rbBand.cyMinChild = rcTmp.bottom - rcTmp.top;

			if(bFullWidthAlways)
			{
				rbBand.cxMinChild = rbBand.cx;
			}
			else if(lpstrTitle == 0)
			{
				CRect rcTmp;// check!!
				bRet = (BOOL)::SendMessage(hWndBand, TB_GETITEMRECT, 0, (LPARAM)&rcTmp);
				ATLASSERT(bRet);
				rbBand.cxMinChild = rcTmp.right;
			}
			else
			{
				rbBand.cxMinChild = 0;
			}
		}
		else	// no buttons, either not a toolbar or really has no buttons
		{
			bRet = ::GetWindowRect(hWndBand, &rcTmp);
			ATLASSERT(bRet);
			rbBand.cx = (cxWidth != 0) ? cxWidth : (rcTmp.right - rcTmp.left);
			rbBand.cxMinChild = (bFullWidthAlways) ? rbBand.cx : 0;
			rbBand.cyMinChild = rcTmp.bottom - rcTmp.top;
		}

#if (_WIN32_IE >= 0x0400)
		// NOTE: cxIdeal used for CHEVRON, if MDI cxIdeal changed dynamically.
		rbBand.cxIdeal = rcTmp.right;//rbBand.cx is not good.
#endif //(_WIN32_IE >= 0x0400)

		// Add the band
		LRESULT lRes = ::SendMessage(hWndReBar, RB_INSERTBAND, (WPARAM)-1, (LPARAM)&rbBand);
		if(lRes == 0)
		{
			ATLTRACE2(atlTraceUI, 0, _T("Failed to add a band to the rebar.\n"));
			return FALSE;
		}

#if (_WIN32_IE >= 0x0501)
		if (nID == IDC_LINKBAR)
			::SendMessage(hWndBand, TB_SETEXTENDEDSTYLE, 0, TBSTYLE_EX_HIDECLIPPEDBUTTONS);
#endif //(_WIN32_IE >= 0x0501)

		return TRUE;
	}

	struct _Function_EnumChildSaveOption
	{
		CMainFrame *_pMainFrame;
		int _nIndex;
		CString _strFileName;
		HWND _hWndActive;
		int _nActiveIndex;
		BOOL _bSaveFB;
		_Function_EnumChildSaveOption(CMainFrame* pMainFrame, const CString& strFileName, HWND hWndActive, int nIndex = 0, BOOL bSaveFB = FALSE)
			: _nIndex(nIndex), _strFileName(strFileName),
			  _hWndActive(hWndActive), _nActiveIndex(-1), _bSaveFB(bSaveFB), _pMainFrame(pMainFrame)
		{
		}
		void operator()(HWND hWnd)
		{
			if (hWnd == _hWndActive)
				_nActiveIndex = _nIndex;				

			//3�ȏ�̈����𑗂�̂��ʓ|�Ȃ̂Œ���CChildFrame�𑀍�
			CChildFrame *pChild = _pMainFrame->GetChildFrame(hWnd);
			if(!pChild)
				return;

			CString strSection;
			strSection.Format("Window%d",_nIndex);
			pChild->m_view.m_ViewOption._WriteProfile(_strFileName,strSection,_bSaveFB);
			//::SendMessage(hWnd, WM_SAVE_OPTION, (WPARAM)(LPCTSTR)_strFileName,
			//									(LPARAM)(_nIndex + (((int)_bSaveFB) << 16)));
			++_nIndex;
		}
	};

	void _SaveGroupOption(const CString& strFileName) // modified by minit
	{
		CLockFileOperation lock; //�O�̂��߃N���e�B�J���Z�N�V�����ŕی�

		::DeleteFile(strFileName);// clean up

		BOOL bMaximized = FALSE;
		BOOL bSaveTravelLog = CMainOption::s_bTravelLogGroup ? TRUE : FALSE;
		HWND hWndActive = MDIGetActive(&bMaximized);
		_Function_EnumChildSaveOption f(this, strFileName, hWndActive, 0, bSaveTravelLog);
		f = m_MDITab.ForEachWindow(f);// MtlForEachMDIChild(m_hWndMDIClient, f);

		CIniSection pr;
		pr.Open(strFileName, _T("Header"));
		pr.SetValue(f._nIndex, _T("count"));
		pr.SetValue(f._nActiveIndex, _T("active"));// active index
		pr.SetValue(bMaximized ? 1 : 0, _T("maximized"));
		pr.Close();
	}

	void _LoadGroupOption(const CString& strFileName, bool bClose)
	{
		CLockFileOperation flock;

		dmfTRACE(_T("CMainFrame::_LoadGroupOption\n"));

		CLockRedrawMDIClient lock(m_hWndMDIClient);
		CMDITabCtrl::CLockRedraw lock2(m_MDITab);
		CWaitCursor cur;

		if (bClose)
			MtlCloseAllMDIChildren(m_hWndMDIClient);

		CIniSection pr;
		pr.Open(strFileName, _T("Header"));

		DWORD dwCount = 0;
		if (pr.QueryValue(dwCount, _T("count")) != ERROR_SUCCESS)
			return;

		DWORD dwActive = 0;
		pr.QueryValue(dwActive, _T("active"));

		DWORD dwMaximized = 0;
		pr.QueryValue(dwMaximized, _T("maximized"));

		bool bActiveChildExistAlready = (MDIGetActive() == NULL) ? false : true;

		m_MDITab.m_bInsertHere = true;
		m_MDITab.m_nInsertIndex = m_MDITab.GetItemCount();

		CChildFrame* pChildActive = NULL;
		for (DWORD dw = 0; dw < dwCount; ++dw)
		{
			CChildFrame* pChild =
				CChildFrame::NewWindow(m_hWndMDIClient, m_MDITab, m_AddressBar);
				// if no active child, as there is no client edge in MDI client window,
				// so GetClientRect is different a little and a resizing will occur when switching.
				// That is, only the first child window is activated.

			if (pChild == NULL)
				continue;

			++m_MDITab.m_nInsertIndex;

			// activate now!
			pChild->ActivateFrame(MDIGetActive() != NULL ? SW_SHOWNOACTIVATE : -1);

			// if tab mode, no need to load window placement.
			pChild->m_view.m_ViewOption.GetProfile(strFileName, dw, !CMainOption::s_bTabMode);

			// �߂�E�i�ނ̍��ڂ�ݒ肷��
			if(CMainOption::s_bTravelLogGroup){
				CString strSection;
				strSection.Format("Window%d",dw);
				_Load_OptionalData(pChild,strFileName,strSection);
			}

			if (dw == dwActive)
				pChildActive = pChild;
		}

		m_MDITab.m_bInsertHere = false;
		m_MDITab.m_nInsertIndex = -1;

		if (pChildActive == NULL)
			return;

		if (!bActiveChildExistAlready) {	// there was no active window
			MDIActivate(pChildActive->m_hWnd);
			if (CMainOption::s_bTabMode || dwMaximized == 1) {	// in tab mode
				MDIMaximize(pChildActive->m_hWnd);
			}
		}
		else {								// already an active window exists
			if (!(CMainOption::s_dwMainExtendedStyle & MAIN_EX_NOACTIVATE))
				MDIActivate(pChildActive->m_hWnd);
		}
	}

	BEGIN_UPDATE_COMMAND_UI_MAP(CMainFrame)
		CHAIN_UPDATE_COMMAND_UI_MEMBER(m_MainOption)
		CHAIN_UPDATE_COMMAND_UI_MEMBER(m_secZone)
		CHAIN_UPDATE_COMMAND_UI_MEMBER(m_ExplorerBar)
		CHAIN_MDI_CHILD_UPDATE_COMMAND_UI()				// first of all

		bool bActiveChild = (MDIGetActive() != NULL);
		// File menu
			UPDATE_COMMAND_UI_SETDEFAULT_FLAG(ID_FILE_NEW_HOME, FILENEW_HOME, CFileNewOption::s_dwFlags)
			UPDATE_COMMAND_UI_SETDEFAULT_FLAG_PASS(ID_FILE_NEW_COPY, FILENEW_COPY, CFileNewOption::s_dwFlags)
			UPDATE_COMMAND_UI_SETDEFAULT_FLAG(ID_FILE_NEW_BLANK, FILENEW_BLANK, CFileNewOption::s_dwFlags)
			UPDATE_COMMAND_UI_ENABLE_IF(ID_FILE_NEW_COPY, bActiveChild)
			UPDATE_COMMAND_UI_ENABLE_IF(ID_FILE_NEW_CLIPBOARD, _IsClipboardAvailable())
			UPDATE_COMMAND_UI_SETDEFAULT(ID_FILE_NEW_CLIPBOARD2)
			UPDATE_COMMAND_UI_ENABLE_IF(ID_FILE_NEW_CLIPBOARD2, _IsClipboardAvailable())
		UPDATE_COMMAND_UI_ENABLE_IF(ID_FILE_SAVE_AS, bActiveChild)
		UPDATE_COMMAND_UI_ENABLE_IF(ID_FILE_PAGE_SETUP, bActiveChild)
		UPDATE_COMMAND_UI_ENABLE_IF(ID_FILE_PRINT, bActiveChild)
		UPDATE_COMMAND_UI_ENABLE_IF(ID_FILE_PROPERTIES, bActiveChild)
		UPDATE_COMMAND_UI_SETCHECK_IF(ID_FILE_WORKOFFLINE, MtlIsGlobalOffline())
		UPDATE_COMMAND_UI_ENABLE_IF(ID_FILE_CLOSE, bActiveChild)
		//UPDATE_COMMAND_UI_POPUP_ENABLE_IF(ID_RECENT_DOCUMENT,CMainOption::s_pMru->m_arrDocs.GetSize())
		UPDATE_COMMAND_UI_ENABLE_IF_WITH_POPUP(ID_RECENT_DOCUMENT,_GetRecentCount(),_GetRecentCount())
		// Edit menu
//		UPDATE_COMMAND_UI_ENABLE_IF(ID_EDIT_CUT, bActiveChild)
//		UPDATE_COMMAND_UI_ENABLE_IF(ID_EDIT_COPY, bActiveChild)
//		UPDATE_COMMAND_UI_ENABLE_IF(ID_EDIT_PASTE, bActiveChild)
//		UPDATE_COMMAND_UI_ENABLE_IF(ID_EDIT_SELECT_ALL, bActiveChild)
		UPDATE_COMMAND_UI_ENABLE_IF(ID_EDIT_FIND, bActiveChild)
		UPDATE_COMMAND_UI_ENABLE_IF(ID_EDIT_OPEN_SELECTED_REF, bActiveChild)
		UPDATE_COMMAND_UI_ENABLE_IF(ID_EDIT_OPEN_SELECTED_TEXT, bActiveChild)
//		UPDATE_COMMAND_UI_ENABLE_IF(ID_VIEW_SETFOCUS, bActiveChild)
		// View menu
			UPDATE_COMMAND_UI_SETCHECK_IF(ID_VIEW_SEARCHBAR, MtlIsBandVisible(m_hWndToolBar, IDC_SEARCHBAR))
			UPDATE_COMMAND_UI_SETCHECK_IF(ID_VIEW_COMMANDBAR, MtlIsBandVisible(m_hWndToolBar, ATL_IDW_COMMAND_BAR))
			UPDATE_COMMAND_UI_SETCHECK_IF(ID_VIEW_TOOLBAR, MtlIsBandVisible(m_hWndToolBar, ATL_IDW_TOOLBAR))
			UPDATE_COMMAND_UI_SETCHECK_IF(ID_VIEW_ADDRESSBAR, MtlIsBandVisible(m_hWndToolBar, IDC_ADDRESSBAR))
			UPDATE_COMMAND_UI_SETCHECK_IF(ID_VIEW_LINKBAR, MtlIsBandVisible(m_hWndToolBar, IDC_LINKBAR))
			UPDATE_COMMAND_UI_SETCHECK_FLAG(ID_VIEW_GOBUTTON, ABR_EX_GOBTNVISIBLE, m_AddressBar.GetAddressBarExtendedStyle())
			UPDATE_COMMAND_UI_SETCHECK_IF(ID_VIEW_TABBAR, MtlIsBandVisible(m_hWndToolBar, IDC_MDITAB))
			UPDATE_COMMAND_UI_SETCHECK_FLAG(ID_VIEW_TABBAR_MULTI, MTB_EX_MULTILINE, m_MDITab.GetMDITabExtendedStyle())
			UPDATE_COMMAND_UI_SETCHECK_IF(ID_VIEW_TOOLBAR_LOCK, _IsRebarBandLocked())
			UPDATE_COMMAND_UI_SETCHECK_IF(ID_VIEW_SEARCHBUTTON, m_SearchBar.GetToolIconState())
			UPDATE_COMMAND_UI_SETCHECK_IF(ID_VIEW_PANELBAR, m_PanelBar.IsWindowVisible())
			UPDATE_COMMAND_UI_SETCHECK_IF(ID_VIEW_PLUGINBAR, m_PluginBar.IsWindowVisible())
			UPDATE_COMMAND_UI_SETCHECK_IF(ID_VIEW_CLIPBOARDBAR, m_ClipBar.IsWindowVisible())
			UPDATE_COMMAND_UI_ENABLE_IF(ID_PRIVACYREPORT, bActiveChild)
		UPDATE_COMMAND_UI_SETCHECK_IF(ID_VIEW_STATUS_BAR, ::IsWindowVisible(m_hWndStatusBar))

		UPDATE_COMMAND_UI_ENABLE_IF_WITH_POPUP(ID_VIEW_BACK, bActiveChild, bActiveChild)		// with popup
			UPDATE_COMMAND_UI_ENABLE_IF(ID_VIEW_FORWARD, bActiveChild)
			UPDATE_COMMAND_UI_ENABLE_IF(ID_VIEW_REFRESH, bActiveChild)

		UPDATE_COMMAND_UI_POPUP_ENABLE_IF(ID_VIEW_BACK1, bActiveChild)
		UPDATE_COMMAND_UI_POPUP_ENABLE_IF(ID_VIEW_FORWARD1, bActiveChild)

		UPDATE_COMMAND_UI_ENABLE_IF(ID_VIEW_STOP, bActiveChild)
		UPDATE_COMMAND_UI_ENABLE_IF(ID_VIEW_STOP_ALL, bActiveChild)
		UPDATE_COMMAND_UI_ENABLE_IF(ID_VIEW_REFRESH, bActiveChild)
		UPDATE_COMMAND_UI_ENABLE_IF(ID_VIEW_REFRESH_ALL, bActiveChild)
		UPDATE_COMMAND_UI_POPUP_ENABLE_IF(ID_AUTOREFRESH_NONE, bActiveChild)
		UPDATE_COMMAND_UI_POPUP_ENABLE_IF(ID_VIEW_FONT_LARGEST, bActiveChild)
		UPDATE_COMMAND_UI_ENABLE_IF(ID_VIEW_FONT_SIZE, bActiveChild)

		//UPDATE_COMMAND_UI_ENABLE_IF_WITH_POPUP(ID_VIEW_ENCODECONTAINER, bActiveChild, bActiveChild)		// minit
		

		UPDATE_COMMAND_UI_ENABLE_IF(ID_VIEW_SOURCE, bActiveChild)
		UPDATE_COMMAND_UI_SETCHECK_IF(ID_VIEW_FULLSCREEN, _IsFullScreen())

		// Favorite menu
		UPDATE_COMMAND_UI_ENABLE_IF(ID_FAVORITE_ADD, bActiveChild)
		UPDATE_COMMAND_UI_ENABLE_IF(ID_FAVORITE_GROUP_ADD, bActiveChild)
		UPDATE_COMMAND_UI_ENABLE_IF(ID_FAVORITE_GROUP_SAVE, bActiveChild)
		// Tool menu
		UPDATE_COMMAND_UI_ENABLE_IF_WITH_POPUP(ID_DLCTL_DLIMAGES, bActiveChild, bActiveChild)	// with poup
			UPDATE_COMMAND_UI_ENABLE_IF(ID_DLCTL_CHG_MULTI, bActiveChild) // UDT DGSTR
			UPDATE_COMMAND_UI_ENABLE_IF(ID_DLCTL_ON_OFF_MULTI, bActiveChild) // UDT UH
			UPDATE_COMMAND_UI_ENABLE_IF(ID_DLCTL_BGSOUNDS, bActiveChild)
			UPDATE_COMMAND_UI_ENABLE_IF(ID_DLCTL_VIDEOS, bActiveChild)
		UPDATE_COMMAND_UI_ENABLE_IF_WITH_POPUP(ID_DLCTL_RUNACTIVEXCTLS, bActiveChild, bActiveChild)// with popup
			UPDATE_COMMAND_UI_ENABLE_IF(ID_DLCTL_CHG_SECU, bActiveChild) // UDT DGSTR
			UPDATE_COMMAND_UI_ENABLE_IF(ID_DLCTL_ON_OFF_SECU, bActiveChild) // UDT UH
			UPDATE_COMMAND_UI_ENABLE_IF(ID_DLCTL_DLACTIVEXCTLS, bActiveChild)
			UPDATE_COMMAND_UI_ENABLE_IF(ID_DLCTL_SCRIPTS, bActiveChild)
			UPDATE_COMMAND_UI_ENABLE_IF(ID_DLCTL_JAVA, bActiveChild)
		UPDATE_COMMAND_UI_ENABLE_IF(ID_DOCHOSTUI_OPENNEWWIN, bActiveChild)
		UPDATE_COMMAND_UI_ENABLE_IF(ID_MESSAGE_FILTER, bActiveChild)	// UH
		UPDATE_COMMAND_UI_ENABLE_IF(ID_MOUSE_GESTURE, bActiveChild)		// UH
		UPDATE_COMMAND_UI_ENABLE_IF(ID_BLOCK_MAILTO, bActiveChild)		// UH
		UPDATE_COMMAND_UI_ENABLE_IF(ID_EDIT_IGNORE, bActiveChild)
		UPDATE_COMMAND_UI_ENABLE_IF(ID_TITLE_COPY, bActiveChild)
		UPDATE_COMMAND_UI_ENABLE_IF(ID_COPY_TITLEANDURL, bActiveChild) //minit
		UPDATE_COMMAND_UI_ENABLE_IF(ID_URL_COPY, bActiveChild)
		UPDATE_COMMAND_UI_ENABLE_IF(ID_EDIT_CLOSE_TITLE, bActiveChild) // UDT DGSTR

		UPDATE_COMMAND_UI_SETCHECK_IF(ID_STYLESHEET_USE_USERS, CStyleSheetOption::GetUseUserSheet())
		UPDATE_COMMAND_UI_SETCHECK_IF(ID_STYLESHEET_SET_USERS, CStyleSheetOption::s_bSetUserSheet)

		// Help
		UPDATE_COMMAND_UI_ENABLE_IF(ID_APP_HELP, _IsExistHTMLHelp()) // UDT DGSTR
		// Misc
                                                                             
		// Window menu
		UPDATE_COMMAND_UI_ENABLE_IF(ID_WINDOW_CLOSE_ALL, bActiveChild)
		UPDATE_COMMAND_UI_ENABLE_IF(ID_WINDOW_CLOSE_EXCEPT, bActiveChild)
		UPDATE_COMMAND_UI_ENABLE_IF(ID_WINDOW_REFRESH_EXCEPT, bActiveChild)	// U.H
		UPDATE_COMMAND_UI_ENABLE_IF(ID_TAB_LEFT, bActiveChild)
		UPDATE_COMMAND_UI_ENABLE_IF(ID_TAB_RIGHT, bActiveChild)
		UPDATE_COMMAND_UI_ENABLE_IF_WITH_POPUP(ID_WINDOW_RESTORE, bActiveChild, bActiveChild)// with popup
			UPDATE_COMMAND_UI_ENABLE_IF(ATL_IDS_SCPREVWINDOW, bActiveChild)
			UPDATE_COMMAND_UI_ENABLE_IF(ATL_IDS_SCNEXTWINDOW, bActiveChild)
			UPDATE_COMMAND_UI_ENABLE_IF(ID_WINDOW_CASCADE, bActiveChild && !CMainOption::s_bTabMode)
			UPDATE_COMMAND_UI_ENABLE_IF(ID_WINDOW_TILE_HORZ, bActiveChild && !CMainOption::s_bTabMode)
			UPDATE_COMMAND_UI_ENABLE_IF(ID_WINDOW_TILE_VERT, bActiveChild && !CMainOption::s_bTabMode)
			UPDATE_COMMAND_UI(ID_WINDOW_ARRANGE, OnUpdateWindowArrange) // to update Window Menu
			// UPDATE_COMMAND_UI_ENABLE_IF(ID_WINDOW_ARRANGE, bActiveChild && !CMainOption::s_bTabMode)
		// Misc
//		UPDATE_COMMAND_UI_SETTEXT(ID_DEFAULT_PANE, _T("���f�B"))
		UPDATE_COMMAND_UI(IDC_PROGRESS, OnUpdateProgressUI)
		UPDATE_COMMAND_UI(ID_SECURE_PANE, OnUpdateStautsIcon)
		UPDATE_COMMAND_UI(ID_PRIVACY_PANE, OnUpdateStautsIcon)

		// UH
		UPDATE_COMMAND_UI_SETCHECK_IF(ID_POPUP_CLOSE, CIgnoredURLsOption::s_bValid)
		UPDATE_COMMAND_UI_SETCHECK_IF(ID_TITLE_CLOSE, CCloseTitlesOption::s_bValid)
		UPDATE_COMMAND_UI_SETCHECK_IF(ID_DOUBLE_CLOSE, CIgnoredURLsOption::s_bValid&&CCloseTitlesOption::s_bValid)

		// UH
		UPDATE_COMMAND_UI_SETCHECK_IF(ID_URLACTION_COOKIES_BLOCK, ChkCookies(ID_URLACTION_COOKIES_BLOCK))
		UPDATE_COMMAND_UI_SETCHECK_IF(ID_URLACTION_COOKIES_HI, ChkCookies(ID_URLACTION_COOKIES_HI))
		UPDATE_COMMAND_UI_SETCHECK_IF(ID_URLACTION_COOKIES_MIDHI, ChkCookies(ID_URLACTION_COOKIES_MIDHI))
		UPDATE_COMMAND_UI_SETCHECK_IF(ID_URLACTION_COOKIES_MID, ChkCookies(ID_URLACTION_COOKIES_MID))
		UPDATE_COMMAND_UI_SETCHECK_IF(ID_URLACTION_COOKIES_LOW, ChkCookies(ID_URLACTION_COOKIES_LOW))
		UPDATE_COMMAND_UI_SETCHECK_IF(ID_URLACTION_COOKIES_ALL, ChkCookies(ID_URLACTION_COOKIES_ALL))
		UPDATE_COMMAND_UI_SETCHECK_IF(ID_URLACTION_COOKIES_CSTM, ChkCookies(ID_URLACTION_COOKIES_CSTM))

		UPDATE_COMMAND_UI_POPUP_ENABLE_IF(ID_STYLESHEET_BASE, bActiveChild)
		UPDATE_COMMAND_UI_ENABLE_IF(ID_CSS_DROPDOWN, bActiveChild)
		UPDATE_COMMAND_UI_ENABLE_IF(ID_VIEW_UP, bActiveChild)
		UPDATE_COMMAND_UI_ENABLE_IF(ID_EDIT_FIND_MAX, bActiveChild)
		UPDATE_COMMAND_UI_ENABLE_IF(ID_VIEW_SOURCE_SELECTED, bActiveChild)
		UPDATE_COMMAND_UI_ENABLE_IF(ID_FILE_PRINT_PREVIEW, bActiveChild)
		UPDATE_COMMAND_UI_ENABLE_IF(ID_SERACHBAR_SEL_UP, bActiveChild)
		UPDATE_COMMAND_UI_ENABLE_IF(ID_SERACHBAR_SEL_DOWN, bActiveChild)
		UPDATE_COMMAND_UI_ENABLE_IF(ID_SERACHBAR_HILIGHT, bActiveChild)

		//minit
		CHAIN_UPDATE_COMMAND_UI_MEMBER(m_DockingPluginManager)

	END_UPDATE_COMMAND_UI_MAP()

// UDT DGSTR
	bool _IsExistHTMLHelp(void)
	{
		return ( 0xFFFFFFFF != GetFileAttributes(MtlGetHTMLHelpPath()) ); 
	}
// ENDE

	bool ChkCookies(UINT nID)
	{
		bool bSts = false;
		DWORD dwCookie1, dwCookie2, BufLen, ret;

		HINSTANCE hInstDLL;
		DWORD (WINAPI *__PrivacyGetZonePreferenceW)(DWORD, DWORD, LPDWORD, LPWSTR, LPDWORD)=NULL;
		if((hInstDLL=LoadLibrary("wininet.dll"))==NULL) return false;
		__PrivacyGetZonePreferenceW=(DWORD(WINAPI *)(DWORD, DWORD, LPDWORD, LPWSTR, LPDWORD))
			GetProcAddress(hInstDLL, "PrivacyGetZonePreferenceW");
		
		if(__PrivacyGetZonePreferenceW==NULL)
			return false;


		BufLen=0;

		ret=__PrivacyGetZonePreferenceW(URLZONE_INTERNET, PRIVACY_TYPE_FIRST_PARTY, &dwCookie1, NULL, &BufLen);
		ret=__PrivacyGetZonePreferenceW(URLZONE_INTERNET, PRIVACY_TYPE_THIRD_PARTY, &dwCookie2, NULL, &BufLen);

		switch(nID)
		{
		case ID_URLACTION_COOKIES_BLOCK:
			if (dwCookie1==dwCookie2 && dwCookie1==PRIVACY_TEMPLATE_NO_COOKIES) bSts = true;
			break;
		case ID_URLACTION_COOKIES_HI:
			if (dwCookie1==dwCookie2 && dwCookie1==PRIVACY_TEMPLATE_HIGH) bSts = true;
			break;
		case ID_URLACTION_COOKIES_MIDHI:
			if (dwCookie1==dwCookie2 && dwCookie1==PRIVACY_TEMPLATE_MEDIUM_HIGH) bSts = true;
			break;
		case ID_URLACTION_COOKIES_MID:
			if (dwCookie1==dwCookie2 && dwCookie1==PRIVACY_TEMPLATE_MEDIUM) bSts = true;
			break;
		case ID_URLACTION_COOKIES_LOW:
			if (dwCookie1==dwCookie2 && dwCookie1==PRIVACY_TEMPLATE_MEDIUM_LOW) bSts = true;
			break;
		case ID_URLACTION_COOKIES_ALL:
			if (dwCookie1==dwCookie2 && dwCookie1==PRIVACY_TEMPLATE_LOW) bSts = true;
			break;
		case ID_URLACTION_COOKIES_CSTM:
			if (dwCookie1==PRIVACY_TEMPLATE_ADVANCED) bSts = true;
			if (dwCookie2==PRIVACY_TEMPLATE_ADVANCED) bSts = true;
			break;
		}

		return bSts;
	}

	void OnUpdateWindowArrange(CCmdUI* pCmdUI)
	{
		// toolbar has not this command button, called only on menu popuping
		MDIRefreshMenu();
		MtlCompactMDIWindowMenuDocumentList(m_menuWindow, _nWindowMenuItemCount,
			CFavoritesMenuOption::GetMaxMenuItemTextLength());

		pCmdUI->Enable(MDIGetActive() != NULL && !CMainOption::s_bTabMode);
	}

	void OnUpdateProgressUI(CCmdUI* pCmdUI)
	{
		CProgressBarCtrl progressbar = pCmdUI->m_wndOther;
		progressbar.ShowWindow(SW_HIDE);
	}

	void OnUpdateStautsIcon(CCmdUI* pCmdUI)
	{
		pCmdUI->m_wndOther.SendMessage(WM_STATUS_SETICON, MAKEWPARAM(pCmdUI->m_nID, -1), 0);
	}

	bool _IsClipboardAvailable()
	{
		return ::IsClipboardFormatAvailable(CF_TEXT) == TRUE;

/*		CComPtr<IDataObject> spDataObject;
		HRESULT hr = ::OleGetClipboard(&spDataObject);
		if (FAILED(hr))
			return false;

		FORMATETC formatetc = { CF_TEXT, NULL, DVASPECT_CONTENT, -1, TYMED_HGLOBAL };
		hr = spDataObject->QueryGetData(&formatetc);
		if (hr == NOERROR) {
			return true;
		}
	
		return false;
*/
	}

	void _FocusChecker()
	{
		// Note. On idle time, give focus back to browser window...
		dmfTRACE(_T("_FocusChecker\n"));

		HWND hWndActive = MDIGetActive();
		if (hWndActive == NULL)
			return;

		HWND hWndForeground = ::GetForegroundWindow();
		bool bMysteriousWindowForeground = MtlIsKindOf(hWndForeground, _T("Internet Explorer_Hidden"));
		if (bMysteriousWindowForeground && MtlIsWindowCurrentProcess(hWndForeground))
			MtlSetForegroundWindow(m_hWnd);

		if (!MtlIsApplicationActive(m_hWnd))
		{
			dmfTRACE(_T(" application is not active\n"), hWndForeground);
			return;
		}

		HWND hWndFocus = ::GetFocus();
		if (hWndFocus != NULL && !MtlIsFamily(m_hWnd, hWndFocus)) {
			dmfTRACE(_T(" not family(focus=%x)\n"), hWndFocus);
			return;
		}

		if (::IsChild(m_hWndToolBar, hWndFocus)) {
			dmfTRACE(_T(" on rebar\n"));
			return;
		}

		if (::IsChild(m_ExplorerBar, hWndFocus))
		{
			dmfTRACE(_T(" on explorer bar\n"));
			return;
		}

		if (hWndFocus == NULL || m_hWnd == hWndFocus || hWndActive == hWndFocus ||
			MtlIsKindOf(hWndFocus, _T("Shell DocObject View")))
		{
			dmfTRACE(_T(" Go!!!!!\n"));
			MtlSendCommand(hWndActive, ID_VIEW_SETFOCUS);
		}
	}

	// UH
	void InitStatusBar()
	{
		DWORD dwVal=0;
		WORD dwSzPain1=125, dwSzPain2=125;

		CIniSection pr;
		pr.Open(_szIniFileName, _T("StatusBar"));
		if (pr.QueryValue(dwVal, _T("SizePain"))==ERROR_SUCCESS)
		{
			dwSzPain1 = LOWORD(dwVal);
			dwSzPain2 = HIWORD(dwVal);
		}

		if (pr.QueryValue(dwVal, _T("SwapPain"))==ERROR_SUCCESS)
			_bSwapProxy = dwVal;

		m_wndStatusBar.SetPaneWidth(ID_PROGRESS_PANE, dwSzPain1);
		m_wndStatusBar.SetPaneWidth(ID_COMBOBOX_PANE, dwSzPain2);
	}


	//minit
	LRESULT OnSpecialKeys(WORD /*wNotifyCode*/, WORD wID, HWND /*hWndCtl*/, BOOL& /*bHandled*/)
	{
		int nCode = 0;
		switch(wID){
		case ID_SPECIAL_HOME:		nCode = VK_HOME;  break;
		case ID_SPECIAL_END:		nCode = VK_END;   break;
		case ID_SPECIAL_PAGEUP:		nCode = VK_PRIOR; break;
		case ID_SPECIAL_PAGEDOWN:	nCode = VK_NEXT;  break;
		case ID_SPECIAL_UP:			nCode = VK_UP;    break;
		case ID_SPECIAL_DOWN:		nCode = VK_DOWN;  break;
		default:
			ATLASSERT(FALSE);
		}

		PostMessage(WM_KEYDOWN,nCode,0);

		return S_OK;
	}

	LRESULT OnSecurityReport(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/, BOOL& /*bHandled*/)
	{
		HWND hWndActive = MDIGetActive();
		if (hWndActive==NULL) return 0;
		
		SendMessage(m_hWnd,WM_COMMAND,ID_FILE_PROPERTIES,0);
		
		return S_OK;
	}

	BOOL CMainFrame::TranslateMessageToBHO(MSG* pMsg)
	{
		if ((WM_KEYFIRST <= pMsg->message) && (pMsg->message <= WM_KEYLAST) ||
			(WM_IME_SETCONTEXT <= pMsg->message) && (pMsg->message <= WM_IME_KEYUP)){
			int nCount = CPluginManager::GetCount(PLT_TOOLBAR);
			for(int i=0; i<nCount; i++){
				if(CPluginManager::Call_PreTranslateMessage(PLT_TOOLBAR,i,pMsg))
					return TRUE;
			}
		}
		return FALSE;
	}

	

	void _RemoveTmpDirectory()
	{
		CString strTempPath = MtlGetModuleFileName();
		strTempPath = strTempPath.Left(strTempPath.ReverseFind('\\')) + _T("\\ShortcutTmp\\");
		if(::GetFileAttributes(strTempPath) != 0xFFFFFFFF){
			MtlForEachFile(strTempPath, CMainFrame::_Function_DeleteFile(0));
			::RemoveDirectory(strTempPath);
		}
	}

	struct _Function_DeleteFile
	{
		int m_dummy;
		_Function_DeleteFile(int ndummy) : m_dummy(ndummy)
		{
		}

		void operator()(const CString& strFile)
		{
			if (MtlIsExt(strFile, _T(".tmp")))
				::DeleteFile(strFile);
		}
	};

	/*
	struct _Function_RemoveFile
	{
		_Function_RemoveFile()
		{
		}

		void operator()(const CString& strFile)
		{
			if (MtlIsExt(strFile, _T(".tmp")))
				::DeleteFile(strFile);
		}
	};*/

	LRESULT OnWindowThumbnail(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/, BOOL& /*bHandled*/)
	{
		//CThumbnailDlg dlg;
		//dlg.DoModal(m_hWnd,(LPARAM)m_hWndMDIClient);
		return S_OK;
	}

	LRESULT OnSpecialRefreshSearchEngin(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/, BOOL& /*bHandled*/)
	{
		m_SearchBar.RefreshEngin();
		return 0;
	}
	
	BOOL _Load_OptionalData(CChildFrame* pChild,const CString& strFileName, CString& strSection)
	{
		pChild->m_strSection = strSection;
		pChild->m_strDfgFileName = strFileName;

		return TRUE;
	}

	BOOL _Load_OptionalData2(CChildFrame* pChild, 
								std::vector<std::pair<CString, CString> > &ArrayFore, 
								std::vector<std::pair<CString, CString> > &ArrayBack)
	{
		pChild->m_ArrayHistFore = ArrayFore;
		pChild->m_ArrayHistBack = ArrayBack;

		return TRUE;
	}

	LRESULT OnMenuRecentDocument(HMENU hMenu)
	{
		CRecentDocumentListFixed* pList;
		pList = CMainOption::s_pMru;
		CMenuHandle menu = hMenu;

		if(menu.m_hMenu == NULL) return 0;
		if(pList == NULL) return 0;
		
		//int ct = menu.GetMenuItemCount();
		if(menu.GetMenuItemCount() == 0)
			menu.AppendMenu(MF_ENABLED|MF_STRING,ID_RECENTDOCUMENT_FIRST,(LPCTSTR)NULL);
		else if(menu.GetMenuItemID(0) != ID_RECENTDOCUMENT_FIRST)
			return 0;
		//int id = menu.GetMenuItemID(0);

		HMENU hMenuT = pList->GetMenuHandle();
		pList->SetMenuHandle(menu);
		pList->UpdateMenu();
		pList->SetMenuHandle(hMenuT);
		
		return 1;
	}

	LRESULT OnMenuRecentLast(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/, BOOL& /*bHandled*/)
	{
		return ::SendMessage(m_hWnd,WM_COMMAND,ID_RECENTDOCUMENT_FIRST,0);
	}

	int _GetRecentCount()
	{
		return CMainOption::s_pMru->m_arrDocs.GetSize();
	}

	LRESULT _OnMDIActivate(HWND hWndActive)
	{

		//�v���O�C���Ƀ^�u���ύX���ꂽ���Ƃ�`����
		int nTabIndex;
		IWebBrowser2* pWB2;

		if(hWndActive == NULL){
			nTabIndex = -1;
			pWB2 = NULL;
		}else{
			nTabIndex = m_MDITab.GetTabIndex(hWndActive);
			pWB2 = DonutGetIWebBrowser2(hWndActive);
		}

		int nCount = CPluginManager::GetCount(PLT_TOOLBAR);
		for(int i=0; i<nCount; i++){
			if(CPluginManager::Call_Event_TabChanged(PLT_TOOLBAR,i,nTabIndex,pWB2))
				return TRUE;
		}
	
		return 0;	
	}

	LRESULT OnTabListDefault(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/, BOOL& /*bHandled*/)
	{
		CPoint pos; ::GetCursorPos(&pos);
		int nRet = m_MDITab.ShowTabListMenuDefault(pos.x,pos.y);
		if(nRet == -1) return 0;
		HWND hWnd = m_MDITab.GetTabHwnd(nRet);
		if(::IsWindow(hWnd))
			::SendMessage(m_wndMDIClient, WM_MDIACTIVATE, (WPARAM)hWnd, 0);
		return 0;
	}
	LRESULT OnTabListVisible(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/, BOOL& /*bHandled*/)
	{
		CPoint pos; ::GetCursorPos(&pos);
		int nRet = m_MDITab.ShowTabListMenuVisible(pos.x,pos.y);
		if(nRet == -1) return 0;
		HWND hWnd = m_MDITab.GetTabHwnd(nRet);
		if(::IsWindow(hWnd))
			::SendMessage(m_wndMDIClient, WM_MDIACTIVATE, (WPARAM)hWnd, 0);
		return 0;
	}
	LRESULT OnTabListAlphabet(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/, BOOL& /*bHandled*/)
	{
		CPoint pos; ::GetCursorPos(&pos);
		int nRet = m_MDITab.ShowTabListMenuAlphabet(pos.x,pos.y);
		if(nRet == -1) return 0;
		HWND hWnd = m_MDITab.GetTabHwnd(nRet);
		if(::IsWindow(hWnd))
			::SendMessage(m_wndMDIClient, WM_MDIACTIVATE, (WPARAM)hWnd, 0);
		return 0;
	}

	LRESULT OnShowActiveMenu(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/, BOOL& /*bHandled*/)
	{
		HWND hWndActive = MDIGetActive();
		if(!hWndActive) return 0;

		int nIndex = m_MDITab.GetTabIndex(hWndActive);
		m_MDITab.ShowTabMenu(nIndex);

		return 0;
	}

	LRESULT OnMainFrameMinimize(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/, BOOL& /*bHandled*/)
	{
		ShowWindow(SW_MINIMIZE);
		return 0;
	}
	LRESULT OnMainFrameMaximize(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/, BOOL& /*bHandled*/)
	{
		ShowWindow(SW_MAXIMIZE);
		return 0;
	}
	

	LRESULT OnUseUserStyleSheet(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/, BOOL& /*bHandled*/)
	{
		BOOL bNowFlag = !CStyleSheetOption::GetUseUserSheet();
		CStyleSheetOption::SetUseUserSheet(bNowFlag);
		return 0;
	}

	LRESULT OnSetUserStyleSheet(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/, BOOL& /*bHandled*/)
	{
		BOOL bNowFlag = !CStyleSheetOption::s_bSetUserSheet;
		CStyleSheetOption::s_bSetUserSheet = bNowFlag;
		return 0;
	}

	LRESULT OnShowExMenu(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/, BOOL& /*bHandled*/)
	{
		CMenu menu = CExMenuManager::LoadExMenu(EXMENU_ID_FIRST);
		POINT pos;
		GetCursorPos(&pos);
		menu.TrackPopupMenu(TPM_LEFTALIGN|TPM_TOPALIGN|TPM_LEFTBUTTON|TPM_RIGHTBUTTON,pos.x,pos.y,m_hWnd,NULL);
		return 0;
	}
	
	LRESULT OnSelectUserFolder(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/, BOOL& /*bHandled*/)
	{
		MtlSendCommand(m_ExplorerBar.m_FavBar.m_hWnd,ID_SELECT_USERFOLDER);
		return 0;
	}

	LRESULT OnSearchHistory(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/, BOOL& /*bHandled*/)
	{
		MtlSendCommand(m_ExplorerBar.m_FavBar.m_hWnd,ID_SEARCH_HISTORY);
		return 0;
	}

	LRESULT OnJumpToWebSite(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/, BOOL& /*bHandled*/)
	{
		CString strSite = _T("http://www5.ocn.ne.jp/~minute/tab/");
		OnUserOpenFile(strSite,DonutGetStdOpenFlag());
		return 0;
	}

	LRESULT OnCommandDirect(int nCommand, LPCTSTR lpstr)
	{
		CString str(lpstr);
		if(str.Find(_T("tp://")) != -1){
			DonutOpenFile(m_hWnd,str,DonutGetStdOpenFlag());
		}else{

			if(nCommand == ID_SEARCH_DIRECT){
				CEdit edit = m_SearchBar.GetEditCtrl();
				edit.SendMessage(WM_CHAR,'P');
				edit.SetWindowText(lpstr);
				m_SearchBar.SearchWeb();
			}
			else if(nCommand == ID_OPENLINK_DIRECT){
				SendMessage(WM_COMMAND,ID_EDIT_OPEN_SELECTED_REF,0);
			}
			/*else if(nCommand == ID_AUTO_DIRECT){
				if(str.Find(".") == -1){
					OnCommandDirect(ID_SEARCH_DIRECT,lpstr);
				}else{
					OnCommandDirect(ID_OPENLINK_DIRECT,lpstr);
				}
			}*/

		}
		return 0;
	}

	void InitSkin()
	{
		//�^�u
		m_MDITab.SetDrawStyle(CSkinOption::s_nTabStyle);

		//ReBar
		m_ReBar.RefreshSkinState();

		//�X�e�[�^�X�o�[
		m_wndStatusBar.ReloadSkin(CSkinOption::s_nStatusStyle);
	}

	HRESULT OnSkinChange()
	{
		//���b�Z�[�W���u���[�h�L���X�g����ׂ���
		CSkinOption::GetProfile();

		m_ReBar.RefreshSkinState();							//ReBar
		m_CmdBar.InvalidateRect(NULL,TRUE);					//���j���[�o�[
		m_MDITab.ReloadSkin(CSkinOption::s_nTabStyle);		//�^�u
		m_ToolBar.ReloadSkin();								//�c�[���o�[
		m_AddressBar.ReloadSkin(CSkinOption::s_nComboStyle);//�A�h���X�o�[
		m_SearchBar.ReloadSkin(CSkinOption::s_nComboStyle);	//�����o�[
		m_LinkBar.InvalidateRect(NULL,TRUE);				//�����N�o�[
		m_ExplorerBar.ReloadSkin();							//�G�N�X�v���[���o�[
		m_PanelBar.ReloadSkin();							//�p�l���o�[
		m_PluginBar.ReloadSkin();							//�v���O�C���o�[
		m_wndStatusBar.ReloadSkin(CSkinOption::s_nStatusStyle);	//�X�e�[�^�X�o�[

		//���t���b�V��
		InvalidateRect(NULL,TRUE);

		return 0;
	}

	CChildFrame* GetChildFrame(HWND hWndChild)
	{
		if(!::IsWindow(hWndChild)) return NULL;
		//�����@ChildFrame �|�C���^
		//���s�@NULL((BOOL)FALSE)
		return (CChildFrame*)::SendMessage(hWndChild,WM_GET_CHILDFRAME,0,0);
	}

	HWND _OpenAboutFile(CString strFile)
	{
		if(strFile == _T("about:saitama")){
			HWND hWndChild = OnUserOpenFile(_T("about:blank"),DonutGetStdOpenFlag());
			if(!::IsWindow(hWndChild)) return NULL;
			CChildFrame *pChild = GetChildFrame(hWndChild);
			if(!pChild) return hWndChild;
			CComPtr<IHTMLDocument2> pDoc;
			
			HRESULT hr;
			int ct=0;
			while(1){
				hr = pChild->m_spBrowser->get_Document((IDispatch**)&pDoc);
				if(SUCCEEDED(hr) && pDoc){
					break;
				}
				Sleep(100);

				ct++;
				if(ct > 50) return hWndChild;
			}

			HRSRC hRes = ::FindResource(_Module.GetModuleInstance(),MAKEINTRESOURCE(IDR_TEXT_SAITAMA),_T("TEXT"));
			HGLOBAL hMem = ::LoadResource(_Module.GetModuleInstance(),hRes);
			LPTSTR lpstr = (LPTSTR)::LockResource(hMem);

			CString strText = lpstr;
			HGLOBAL hHTMLText = GlobalAlloc(GPTR,strText.GetLength()+1);
			if(hHTMLText){
				CComPtr<IStream> pStream;
				CopyMemory(hHTMLText,strText,strText.GetLength()+1);
				hr = ::CreateStreamOnHGlobal(hHTMLText,TRUE,&pStream);
				if(SUCCEEDED(hr)){
					// Call the helper function to load the browser from the stream.
					LoadWebBrowserFromStream( pChild->m_spBrowser , pStream  );
				}
				GlobalFree( hHTMLText );
			}
			/*SAFEARRAY *psfArray;
			VARIANT *pparam;
			psfArray = SafeArrayCreateVector(VT_VARIANT, 0, 1);
			if(psfArray){
				hr = SafeArrayAccessData(psfArray,(LPVOID*) & pparam);
				pparam->vt = VT_BSTR;
				pparam->bstrVal = bstrSaitama;
				hr = SafeArrayUnaccessData(psfArray);
				hr = pDoc->write(psfArray);
				SafeArrayDestroy(psfArray);
			}*/

			//m_AddressBar.GetEditCtrl().SetWindowText(strFile);
			//int index = m_MDITab.GetTabIndex(hWndChild);
			//m_MDITab.SetItemText(index,strFile);
			return hWndChild;
		}
		return NULL;
	}

	HRESULT LoadWebBrowserFromStream(IWebBrowser* pWebBrowser, IStream* pStream)
	{
		HRESULT hr;
		IDispatch* pHtmlDoc = NULL;
		IPersistStreamInit* pPersistStreamInit = NULL;

		// Retrieve the document object.
		hr = pWebBrowser->get_Document( &pHtmlDoc );
		if ( SUCCEEDED(hr) )
		{
			// Query for IPersistStreamInit.
			hr = pHtmlDoc->QueryInterface( IID_IPersistStreamInit,  (void**)&pPersistStreamInit );
			if ( SUCCEEDED(hr) )
			{
				// Initialize the document.
				hr = pPersistStreamInit->InitNew();
				if ( SUCCEEDED(hr) )
				{
					// Load the contents of the stream.
					hr = pPersistStreamInit->Load( pStream );
				}
				pPersistStreamInit->Release();
			}
		}
		return S_OK;
	}

	LRESULT OnShowToolBarMenu()
	{
		POINT pt;
		::GetCursorPos(&pt);

		CMenuHandle submenu = ::GetSubMenu(::GetSubMenu(m_hMenu,2),0);
		if(submenu.IsMenu())
			submenu.TrackPopupMenu(TPM_LEFTALIGN|TPM_TOPALIGN|TPM_LEFTBUTTON|TPM_RIGHTBUTTON,pt.x,pt.y,m_hWnd);
		return 0;
	}

	HRESULT OnSearchWebSelText(LPCTSTR lpstrText, LPCTSTR lpstrEngin)
	{
		int nLoopCnt=0;
		BOOL bFirst = DonutGetStdOpenCreateFlag()&D_OPENFILE_ACTIVATE ? TRUE : FALSE;
		m_SearchBar.OpenSearch(lpstrText,lpstrEngin,nLoopCnt,bFirst);

		return S_OK;
	}

	LRESULT OnSetExProperty(LPCTSTR lpstrUrlFile)
	{
		CString strUrlFile = lpstrUrlFile;
		if(!MtlIsExt(strUrlFile,_T(".url")))
			return 0;

		CExPropertyDialog dlg(strUrlFile);
		dlg.DoModal();

		return 0;
	}

	

	/////////////////////////////////////////////
	// DonutP API
	/////////////////////////////////////////////
	
	IDispatch* ApiGetDocumentObject(int nTabIndex)
	{
		HWND hTabWnd = m_MDITab.GetTabHwnd(nTabIndex);
		if (hTabWnd==NULL) return NULL;
		CWebBrowser2 browser = DonutGetIWebBrowser2(hTabWnd);

		IDispatch* spDocument;
		browser.m_spBrowser->get_Document(&spDocument);
		return (IDispatch*)spDocument;
	}

	IDispatch* ApiGetWindowObject(int nTabIndex)
	{
		HWND hTabWnd = m_MDITab.GetTabHwnd(nTabIndex);
		if (hTabWnd==NULL) return NULL;
		CWebBrowser2 browser = DonutGetIWebBrowser2(hTabWnd);

		CComPtr<IDispatch> spDisp;
		HRESULT hr = browser.m_spBrowser->get_Document(&spDisp);
		CComQIPtr<IHTMLDocument2> spDoc = spDisp;

		IHTMLWindow2* spWnd;
		spDoc->get_parentWindow(&spWnd);
		return (IDispatch*)spWnd;
	}

	IDispatch* ApiGetWebBrowserObject(int nTabIndex)
	{
		HWND hTabWnd = m_MDITab.GetTabHwnd(nTabIndex);
		if (hTabWnd==NULL) return NULL;
		CWebBrowser2 browser = DonutGetIWebBrowser2(hTabWnd);

		IWebBrowser2* spBrowser;
 		browser.m_spBrowser->QueryInterface(IID_IWebBrowser2, (void**)&spBrowser);
		return (IDispatch*)spBrowser;
	}

	long ApiGetTabIndex()
	{
		return m_MDITab.GetCurSel();
	}

	void ApiSetTabIndex(int nTabIndex)
	{
		m_MDITab.SetCurSelEx(nTabIndex);
	}

	void ApiClose(int nTabIndex)
	{
		HWND hTabWnd = m_MDITab.GetTabHwnd(nTabIndex);
		::SendMessage(hTabWnd, WM_COMMAND, ID_FILE_CLOSE, 0);
	}

	long ApiGetTabCount()
	{
		return m_MDITab.GetItemCount();
	}

	void ApiMoveToTab(int nBeforIndex, int nAfterIndex)
	{
		CSimpleArray<int> aryBefor;
		aryBefor.Add(nBeforIndex);
		m_MDITab.MoveItems(nAfterIndex+1, aryBefor);
	}

	int ApiNewWindow(BSTR bstrURL, BOOL bActive)
	{
		CString strURL(bstrURL);

		int nCmdShow = bActive? -1:SW_SHOWNOACTIVATE;
		if (m_MDITab.GetItemCount()==0)
			nCmdShow = -1;

		CChildFrame* pChild = CChildFrame::NewWindow(m_hWndMDIClient, m_MDITab, m_AddressBar);
		if (pChild == NULL)	return -1;

		pChild->ActivateFrame(nCmdShow);

		if (strURL.IsEmpty())
			strURL = _T("about:blank");

		pChild->Navigate2(strURL);
		return m_MDITab.GetTabIndex(pChild->m_hWnd);
	}

	void ApiShowPanelBar()
	{
		if (m_ExplorerBar.IsWindowVisible())
			return;

		SendMessage(WM_COMMAND, ID_VIEW_PANELBAR, 0);
	}

	long ApiGetTabState(int nIndex)
	{
		BYTE bytData=0;
		if (m_MDITab.GetItemState(nIndex, bytData)==false)
			return -1;

		long nRet=0;
		if (bytData&TCISTATE_SELECTED) {
			nRet = 1;
		}
		else if (bytData&TCISTATE_MSELECTED) {
			nRet = 2;
		}
		return nRet;
	}

	IDispatch* ApiGetPanelWebBrowserObject()
	{
		if(!m_PanelBar.IsWindow()) m_PanelBar.CreatePanelBar(m_hWnd,FALSE);
		return m_PanelBar.GetPanelWebBrowserObject();
	}

	IDispatch* ApiGetPanelWindowObject()
	{
		if(!m_PanelBar.IsWindow()) m_PanelBar.CreatePanelBar(m_hWnd,FALSE);
		return m_PanelBar.GetPanelWindowObject();
	}

	IDispatch* ApiGetPanelDocumentObject()
	{
		if(!m_PanelBar.IsWindow()) m_PanelBar.CreatePanelBar(m_hWnd,FALSE);
		return m_PanelBar.GetPanelDocumentObject();
	}

	//IAPI2 by minit
	void ApiExecuteCommand(int nCommand)
	{
		::SendMessage(m_hWnd,WM_COMMAND,(WPARAM)(nCommand & 0xFFFF),0);
	}

	void ApiGetSearchText(/*[out, retval]*/BSTR *bstrText)
	{
		CString strBuf;
		CEdit edit = m_SearchBar.GetEditCtrl();
		int len = edit.GetWindowTextLength()+1;
		edit.GetWindowText(strBuf.GetBuffer(len),len);
		strBuf.ReleaseBuffer();
		*bstrText = CComBSTR(strBuf).Copy();
	}

	void ApiSetSearchText(BSTR bstrText)
	{
		CString strText = bstrText;
		CEdit edit = m_SearchBar.GetEditCtrl();
		edit.SendMessage(WM_CHAR,'P');
		edit.SetWindowText(strText);
	}

	void ApiGetAddressText(/*[out, retval]*/BSTR *bstrText)
	{
		CString strBuf;
		CEdit edit = m_AddressBar.GetEditCtrl();
		int len = edit.GetWindowTextLength()+1;
		edit.GetWindowText(strBuf.GetBuffer(len),len);
		strBuf.ReleaseBuffer();
		*bstrText = CComBSTR(strBuf).Copy();
	}

	void ApiSetAddressText(BSTR bstrText)
	{
		CString strText = bstrText;
		CEdit edit = m_AddressBar.GetEditCtrl();
		edit.SendMessage(WM_CHAR,'P');
		edit.SetWindowText(strText);
	}

	long ApiGetExtendedTabState(int nIndex)
	{
		HWND hWndChild = m_MDITab.GetTabHwnd(nIndex);
		if(!::IsWindow(hWndChild))
			return 0x80000000;
		return ::SendMessage(hWndChild,WM_GET_EXTENDED_TABSTYLE,0,0);
	}

	void ApiSetExtendedTabState(int nIndex, long nState)
	{
		HWND hWndChild = m_MDITab.GetTabHwnd(nIndex);
		if(!::IsWindow(hWndChild))
			return;
		::SendMessage(hWndChild,WM_SET_EXTENDED_TABSTYLE,(WPARAM)nState,0);
	}

	BOOL ApiGetKeyState(int nKey)
	{
		return (::GetAsyncKeyState(nKey) & 0x80000000);
	}

	long ApiGetProfileInt(BSTR bstrFile, BSTR bstrSection, BSTR bstrKey, int nDefault)
	{
		CString strFile = bstrFile;
		CString strSection = bstrSection;
		CString strKey = bstrKey;
		return ::GetPrivateProfileInt(strSection,strKey,nDefault,strFile);
	}

	void ApiWriteProfileInt(BSTR bstrFile, BSTR bstrSection, BSTR bstrKey, int nValue)
	{
		CString strFile = bstrFile;
		CString strSection = bstrSection;
		CString strKey = bstrKey;
		CIniSection pr;
		pr.Open(strFile,strSection);
		pr.SetValue(nValue,strKey);
		pr.Close();
	}

	void ApiGetProfileString(BSTR bstrFile, BSTR bstrSection, BSTR bstrKey, BSTR bstrDefault, /*[out, retval]*/BSTR *bstrText)
	{
		CString strFile = bstrFile;
		CString strSection = bstrSection;
		CString strKey = bstrKey;
		CString strDefault = bstrDefault;
		CString strBuf;
		DWORD BufSize = 1024;
		while(1){
			DWORD dwRet = ::GetPrivateProfileString(strSection,strKey,strDefault,
										strBuf.GetBufferSetLength(BufSize),BufSize,strFile);
			strBuf.ReleaseBuffer();
			if(dwRet == BufSize-1)
				BufSize <<= 1;
			else
				break;
		}
		*bstrText = CComBSTR(strBuf).Copy();
	}

	void ApiWriteProfileString(BSTR bstrFile, BSTR bstrSection, BSTR bstrKey, BSTR bstrText)
	{
		CString strFile = bstrFile;
		CString strSection = bstrSection;
		CString strKey = bstrKey;
		CString strText = bstrText;
		::WritePrivateProfileString(strSection,strKey,strText,strFile);
	}

	void ApiGetScriptFolder(/*[out, retval]*/BSTR *bstrFolder)
	{
		CString strBuf;
		::GetModuleFileName(_Module.GetModuleInstance(), strBuf.GetBuffer(MAX_PATH), MAX_PATH);
		strBuf.ReleaseBuffer();
		strBuf = strBuf.Left(strBuf.ReverseFind('\\')+1);
		strBuf += _T("Script\\");
		if(::GetFileAttributes(strBuf) == 0xFFFFFFFF) strBuf.Empty();
		*bstrFolder = CComBSTR(strBuf).Copy();
	}

	void ApiGetCSSFolder(/*[out, retval]*/BSTR *bstrFolder)
	{
		CString strBuf;
		::GetModuleFileName(_Module.GetModuleInstance(), strBuf.GetBuffer(MAX_PATH), MAX_PATH);
		strBuf.ReleaseBuffer();
		strBuf = strBuf.Left(strBuf.ReverseFind('\\')+1);
		strBuf += _T("CSS\\");
		if(::GetFileAttributes(strBuf) == 0xFFFFFFFF) strBuf.Empty();
		*bstrFolder = CComBSTR(strBuf).Copy();
	}

	void ApiGetBaseFolder(/*[out, retval]*/BSTR *bstrFolder)
	{
		CString strBuf;
		::GetModuleFileName(_Module.GetModuleInstance(), strBuf.GetBuffer(MAX_PATH), MAX_PATH);
		strBuf.ReleaseBuffer();
		strBuf = strBuf.Left(strBuf.ReverseFind('\\')+1);
		if(::GetFileAttributes(strBuf) == 0xFFFFFFFF) strBuf.Empty();
		*bstrFolder = CComBSTR(strBuf).Copy();
	}

	void ApiGetExePath(/*[out, retval]*/BSTR *bstrPath)
	{
		TCHAR Buf[MAX_PATH];
		::GetModuleFileName(_Module.GetModuleInstance(), Buf, MAX_PATH);
		*bstrPath = CComBSTR(Buf).Copy();
	}

	void ApiSetStyleSheet(int nIndex, BSTR bstrStyleSheet, BOOL bOff)
	{
		HWND hWndChild = m_MDITab.GetTabHwnd(nIndex);
		if(!::IsWindow(hWndChild)) return;
		CChildFrame* pChild = GetChildFrame(hWndChild);
		if(pChild == NULL) return;

		CString strStylePath(bstrStyleSheet);
		CString strStyleTitle;
		if(bOff || strStylePath.IsEmpty()){
			// Off or Default
		}else{
			// Set New StyleSheet
			strStyleTitle = strStylePath.Mid(strStylePath.ReverseFind('\\')+1);
		}
		pChild->StyleSheet(strStyleTitle,bOff,strStylePath);
	}

	//IAPI3
	void ApiSaveGroup(BSTR bstrGroupFile)
	{
		CString strFile = bstrGroupFile;
		_SaveGroupOption(strFile);
	}

	void ApiLoadGroup(BSTR bstrGroupFile, BOOL bClose)
	{
		CString strFile = bstrGroupFile;
		_LoadGroupOption(strFile,bClose ? true : false);
	}

	struct _ExtendProfileInfo {
		const LPCTSTR lpstrIniPath;
		const LPCTSTR lpstrSection;
		BOOL bGroup;
	};

	int ApiNewWindow3(BSTR bstrURL, BOOL bActive, long ExStyle, void *pExInfo)
	{

		CString strURL = bstrURL;

		int nCmdShow = bActive? -1:SW_SHOWNOACTIVATE;
		if (m_MDITab.GetItemCount()==0)
			nCmdShow = -1;

		CChildFrame* pChild = CChildFrame::NewWindow(m_hWndMDIClient, m_MDITab, m_AddressBar);
		if (pChild == NULL)	return -1;

		pChild->ActivateFrame(nCmdShow);

		if (strURL.IsEmpty())
			strURL = _T("about:blank");
		
		if(*(int *)pExInfo){
			_ExtendProfileInfo *_pExInfo = (_ExtendProfileInfo *)pExInfo;
			CString strPath = _pExInfo->lpstrIniPath;
			CString strSection = _pExInfo->lpstrSection;
			try{
				_Load_OptionalData(pChild,strPath,strSection);
			}catch(...){
				MessageBox(_T("��O�G���[���������܂����B(In NewWindow3 Function)\n"
								"���S�̂��߃v���O�������ċN�������Ă��������B"));
			}
			if(_pExInfo->bGroup){
				pChild->m_view.m_ViewOption._GetProfile(strPath,strSection,!CMainOption::s_bTabMode);
			}else{
				pChild->OnSetExtendedTabStyle(ExStyle|FLAG_SE_NOREFRESH);
			}
			
		}else{
			pChild->OnSetExtendedTabStyle(ExStyle|FLAG_SE_NOREFRESH);
		}

		pChild->Navigate2(strURL);
		return m_MDITab.GetTabIndex(pChild->m_hWnd);
	}

	long ApiAddGroupItem(BSTR bstrGroupFile, int nIndex)
	{
		HWND hWndChild = m_MDITab.GetTabHwnd(nIndex);
		if(!::IsWindow(hWndChild)) return -1;
		CChildFrame* pChild = GetChildFrame(hWndChild);
		if(pChild == NULL) return -1;

		return pChild->_AddGroupOption(bstrGroupFile);
	}

	long ApiDeleteGroupItem(BSTR bstrGroupFile, int nIndex)
	{
		CString strGroupFile = bstrGroupFile;
		CString strSection;

		strSection.Format(_T("Window%d"),nIndex);
		bool bRet = MtlIniDeleteSection(strGroupFile,strSection);
		if(!bRet) {
			MessageBox("Error1: �Z�N�V�����̍폜�Ɏ��s���܂����B");
			return 0;
		}

		std::list<CString> buf;
		bRet = FileReadString(strGroupFile,&buf);
		if(!bRet) {
			MessageBox("Error2: �t�@�C���̓ǂݍ��݂Ɏ��s���܂����B");	
			return 0;
		}

		std::list<CString>::iterator str;
		for(str = buf.begin(); str != buf.end(); str++){
			CString strCheck = str->Left(7);
			strCheck.MakeUpper();
			if(strCheck == _T("[WINDOW")){
				int nSecIndex = atoi(str->Mid(7,str->GetLength()-7-1));
				if(nSecIndex > nIndex){
					str->Format("[Window%d]", nSecIndex-1);
				}
			}
		}

		bRet = FileWriteString(strGroupFile,&buf);
		if(!bRet) {
			MessageBox("Error3: �t�@�C���̏������݂Ɏ��s���܂����B");	
			return 0;
		}

		DWORD dwCount=0,dwActive=0,dwMaximize=0;
		CIniSection pr;
		pr.Open(strGroupFile,_T("Header"));
		pr.QueryValue(dwCount,_T("count"));
		if(dwCount){
			dwCount--;
			pr.SetValue(dwCount,_T("Count"));
		}
		pr.QueryValue(dwActive,_T("active"));
		if(dwCount == 0)
			pr.DeleteValue(_T("active"));
		else if((int)dwActive > nIndex)
			pr.SetValue(dwActive-1,_T("active"));
		pr.QueryValue(dwMaximize,_T("maximized"));
		if(dwCount == 0)
			pr.DeleteValue(_T("maximized"));
		else if((int)dwMaximize > nIndex)
			pr.SetValue(dwMaximize-1,_T("maximized"));

		pr.Close();

		return 1;
	}

	//IAPI4
	HWND ApiGetHWND(long nType)
	{
		if(nType==0)
			return m_hWnd;
		return NULL;
	}
	
	
	LRESULT OnPluginCommand(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled); //PluginEventImpl.h�Ŏ���
};


#include "PluginEventImpl.h"
/////////////////////////////////////////////////////////////////////////////
