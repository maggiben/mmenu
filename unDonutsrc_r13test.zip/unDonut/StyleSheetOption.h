
#pragma once

#define CSS_SETUSERSHEET 0x1
#define KEY_IE_SETTING_USERSTYLESHEET _T("Software\\Microsoft\\Internet Explorer\\Styles")
#define FIELD_USE_MY_STYLESHEET	_T("Use My Stylesheet")
#define FIELD_USER_STYLESHEET _T("User Stylesheet")

class CStyleSheetOption
{
public:

	static BOOL s_bSetUserSheet;

	static void SetUserSheetName(LPCTSTR lpstrFile)
	{
		CString strFile(lpstrFile);
		if(strFile.IsEmpty())
			return;

		CRegKey key;
		key.Open(HKEY_CURRENT_USER, KEY_IE_SETTING_USERSTYLESHEET);
		key.SetStringValue(FIELD_USER_STYLESHEET,lpstrFile);
		//key.SetValue(lpstrFile, FIELD_USER_STYLESHEET);

		LRESULT lRet;
		::SendMessageTimeout(HWND_BROADCAST,WM_SETTINGCHANGE,NULL,NULL,SMTO_ABORTIFHUNG, 1000, (DWORD*)&lRet);
	}

	static void SetUseUserSheet(BOOL bOk)
	{
		CRegKey key;
		key.Open(HKEY_CURRENT_USER, KEY_IE_SETTING_USERSTYLESHEET);
		key.SetDWORDValue(FIELD_USE_MY_STYLESHEET, bOk ? 1 : 0);
		//key.SetValue(bOk ? 1 : 0, FIELD_USE_MY_STYLESHEET);

		CString strBuf;
		DWORD dwCount = MAX_PATH;
		LONG lRet = key.QueryStringValue(FIELD_USER_STYLESHEET, strBuf.GetBuffer(MAX_PATH+1), &dwCount);
		//LONG lRet = key.QueryValue(strBuf.GetBuffer(MAX_PATH+1), FIELD_USER_STYLESHEET, &dwCount);
		strBuf.ReleaseBuffer();
		if(lRet != ERROR_SUCCESS){ //�t�B�[���h�����݂��Ȃ��Ɨ�����댯����
			key.SetStringValue(strBuf, FIELD_USER_STYLESHEET);
			//key.SetValue(FIELD_USER_STYLESHEET, strBuf);
		}

		::SendMessageTimeout(HWND_BROADCAST,WM_SETTINGCHANGE,NULL,NULL,SMTO_ABORTIFHUNG, 1000, (DWORD*)&lRet);
	}

	static BOOL GetUseUserSheet()
	{
		CRegKey key;
		DWORD dwUseUserSheet;
		key.Open(HKEY_CURRENT_USER, KEY_IE_SETTING_USERSTYLESHEET);
		key.QueryDWORDValue(FIELD_USE_MY_STYLESHEET, dwUseUserSheet);
		//key.QueryValue(dwUseUserSheet, FIELD_USE_MY_STYLESHEET);
		return dwUseUserSheet ? TRUE : FALSE;
	}

	static void GetProfile()
	{
		CIniSection pr;
		DWORD dwSetUserSheet;
		pr.Open(_szIniFileName, _T("StyleSheet"));
		pr.QueryValue(dwSetUserSheet, _T("Style_Flag"));
		pr.Close();

		s_bSetUserSheet = dwSetUserSheet&CSS_SETUSERSHEET ? TRUE : FALSE; 
	}

	static void WriteProfile()
	{
		CIniSection pr;
		DWORD dwFlags = 0;
		pr.Open(_szIniFileName, _T("StyleSheet"));

		if(s_bSetUserSheet)
			dwFlags |= CSS_SETUSERSHEET;

		pr.SetValue(dwFlags, _T("Style_Flag"));

		pr.Close();
	}
};
__declspec(selectany) BOOL CStyleSheetOption::s_bSetUserSheet = FALSE;