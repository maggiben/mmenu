#pragma once 

#include "ExMenu.h"

class CToolTipManager
{
public:

	static bool LoadToolTipText(int nCmdID, CString& strText)
	{
		TCHAR szBuff[256];
		TCHAR szText[256];

		szBuff[0] = 0;
		int nRet = ::LoadString(_Module.GetResourceInstance(), nCmdID, szBuff, 256);
		for (int i = 0; i < nRet; i++)
		{
			if (szBuff[i] == _T('\n'))
			{
				lstrcpyn(szText, &szBuff[i + 1], 256);
				strText = szText;
				return true;
			}
		}

		CString strTip;
		strTip = CExMenuManager::GetToolTip(nCmdID);

		if(strTip.IsEmpty())
			return false;
		else{
			strText = strTip;
			return true;
		}
	}

};