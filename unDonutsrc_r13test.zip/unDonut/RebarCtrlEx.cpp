

#pragma once

class CRebarCtrlEx : CRebarCtrl
{
public:

	BEGIN_MSG_MAP(CRebarCtrlEx


};