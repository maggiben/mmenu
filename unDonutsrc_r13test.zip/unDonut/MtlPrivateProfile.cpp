#include "stdafx.h"
#include "MtlPrivateProfile.h"

namespace MTL {

CIniSection::CIniSection()
{
}

CIniSection::~CIniSection()
{
}
 
void CIniSection::Close()
{
	m_strFileName.Empty();
	m_strSectionName.Empty();
}
 
void CIniSection::Open(const CString& strFileName, const CString& strSectionName)
{
	ATLASSERT(!strFileName.IsEmpty());
	ATLASSERT(!strSectionName.IsEmpty());
	ATLASSERT(!IsOpen());

	m_strFileName = strFileName;
	m_strSectionName = strSectionName;
}

LONG CIniSection::QueryValue(DWORD& dwValue, LPCTSTR lpszValueName)
{
	ATLASSERT(IsOpen());
	
	UINT nValue = ::GetPrivateProfileInt(m_strSectionName, lpszValueName, cnt_nDefault, m_strFileName);
	if (nValue == cnt_nDefault)
		return ERROR_CANTREAD;

	dwValue = nValue;
	return ERROR_SUCCESS;
}

LONG CIniSection::QueryValue(LPTSTR szValue, LPCTSTR lpszValueName, DWORD* pdwCount)
{
	ATLASSERT(pdwCount != NULL);
	ATLASSERT(IsOpen());
	
	ATLASSERT(szValue != NULL);// Ini section can't determine dwCount.

	DWORD dw = ::GetPrivateProfileString(m_strSectionName, lpszValueName,
		_T(""), szValue, *pdwCount, m_strFileName);

	if (dw == 0)
		return ERROR_CANTREAD;

	return ERROR_SUCCESS;
}

LONG CIniSection::QueryString(CString& strBuf, LPCTSTR lpszValueName, DWORD dwBufSize)
{
	ATLASSERT(IsOpen());

	DWORD dw = ::GetPrivateProfileString(m_strSectionName, lpszValueName,
		_T(""), strBuf.GetBuffer(dwBufSize) , dwBufSize, m_strFileName);
	strBuf.ReleaseBuffer();

	if (dw == 0)
		return ERROR_CANTREAD;

	return ERROR_SUCCESS;
}

LONG CIniSection::SetValue(DWORD dwValue, LPCTSTR lpszValueName)
{
	ATLASSERT(lpszValueName != NULL);// don't make section deleted
	ATLASSERT(IsOpen());
	
	TCHAR szT[16];
	::wsprintf(szT, _T("%d"), dwValue);
	if (::WritePrivateProfileString(m_strSectionName, lpszValueName, szT, m_strFileName))
		return ERROR_SUCCESS;
	else
		return ERROR_CANTWRITE;
}

LONG CIniSection::SetValue(LPCTSTR lpszValue, LPCTSTR lpszValueName)
{
	ATLASSERT(lpszValue != NULL);
	ATLASSERT(IsOpen());
	
	ATLASSERT(m_strFileName.GetLength() < 4095); // can't read in bigger
	if (::WritePrivateProfileString(m_strSectionName, lpszValueName, lpszValue, m_strFileName))
		return ERROR_SUCCESS;
	else
		return ERROR_CANTWRITE;
}

LONG CIniSection::DeleteValue(LPCTSTR lpszValueName)
{
	if (::WritePrivateProfileString(m_strSectionName, lpszValueName, NULL, m_strFileName))
		return ERROR_SUCCESS;
	else
		return ERROR_CANTWRITE;
}

BOOL CIniSection::IsOpen()
{
	if (!m_strFileName.IsEmpty() && !m_strSectionName.IsEmpty())
		return TRUE;
	else
		return FALSE;
}

//inline 
bool MtlIniDeleteSection(const CString& strIniFileName, const CString& strSectionName)
{
	return ::WritePrivateProfileString(strSectionName, NULL, NULL, strIniFileName) ? true : false;
}

//inline 
bool MtlIniDeleteAllSection(const CString& strIniFileName, const CString& strSectionName)
{
	return true;
}

} //namespace MTL;
