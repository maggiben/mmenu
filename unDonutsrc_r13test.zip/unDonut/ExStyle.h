
#pragma once

#define DONUT_SECTION	_T("unDonut")
#define EXPROP_KEY		_T("ExProperty")
#define EXPROP_KEY_ENABLED	_T("Enabled")
	
#define EXPROP_DEFAULT	2
#define EXPROP_OFF		0
#define EXPROP_ON		1

#define EXPROP_DLIMAGE		0x00000003
#define EXPROP_VIDEO		0x0000000C
#define	EXPROP_SOUND		0x00000030
#define EXPROP_RUNACTIVEX	0x000000C0
#define EXPROP_DLACTIVEX	0x00000300
#define EXPROP_SCRIPT		0x00000C00
#define EXPROP_JAVA			0x00003000
#define EXPROP_NAVI			0x00030000
#define EXPROP_FILTER		0x000C0000
#define EXPROP_GETSTURE		0x00300000
#define EXPROP_MAILTO		0x00C00000			

#define EXPROP_REFRESH_NONE		0x01000000
#define EXPROP_REFRESH_15SEC	0x02000000
#define EXPROP_REFRESH_30SEC	0x04000000
#define EXPROP_REFRESH_1MIN		0x08000000
#define EXPROP_REFRESH_2MIN		0x10000000
#define EXPROP_REFRESH_5MIN		0x20000000
#define EXPROP_REFRESH_USER		0x40000000
#define EXPROP_REFRESH_DEFAULT	0x80000000


#define EXPROP_RELOAD_FLAGS		(EXPROP_REFRESH_NONE|EXPROP_REFRESH_15SEC|EXPROP_REFRESH_30SEC|EXPROP_REFRESH_1MIN|EXPROP_REFRESH_2MIN|EXPROP_REFRESH_5MIN|EXPROP_REFRESH_USER|EXPROP_REFRESH_DEFAULT)

/*
	�g���v���p�e�B�`���f�[�^��Donut�W���̃f�[�^�t���O�Ƃ̑��ݕϊ����s���N���X

	�g���v���p�e�B�`���f�[�^�̓t���O���Ƃ�On,Off,Default�̎O�Ԃ��Ƃ�
	Default�̓R���X�g���N�^�Ŏw�肵���f�t�H���g�̒l�𗘗p����

	release12���_�ł�Default�l�͗��p����Ă��Ȃ��iOn,Off�̂ݐݒ�j
 */

class CExProperty
{
private:
	DWORD m_dwExProp;
public:

	DWORD m_dwDefDLFlag, m_dwDefExStyle, m_dwDefReloadFlag;

	CExProperty(DWORD dwDefaultDLFlag, DWORD dwDefaultExStyle, DWORD dwDefaultReloadFlag, DWORD dwExProp) 
		: m_dwDefDLFlag(dwDefaultDLFlag), m_dwDefExStyle(dwDefaultExStyle), m_dwDefReloadFlag(dwDefaultReloadFlag),
			m_dwExProp(dwExProp)
	{
	}

	int GetPropFlag(DWORD dwExProp, DWORD dwFlag)
	{
		return (dwExProp&dwFlag)/(dwFlag/3);
	}

	//�Z�L�����e�B�֘A�̃t���O�ϐ����擾����
	int GetDLControlFlags()
	{
		DWORD dwDLFlags=0;
		DWORD dwExProp = m_dwExProp;

		switch(GetPropFlag(dwExProp,EXPROP_DLIMAGE)){
		case EXPROP_DEFAULT:	dwDLFlags |= (m_dwDefDLFlag&DLCTL_DLIMAGES); break;
		case EXPROP_ON:			dwDLFlags |= DLCTL_DLIMAGES; break;
		}
		switch(GetPropFlag(dwExProp,EXPROP_VIDEO)){
		case EXPROP_DEFAULT:	dwDLFlags |= (m_dwDefDLFlag&DLCTL_VIDEOS); break;
		case EXPROP_ON:			dwDLFlags |= DLCTL_VIDEOS; break;
		}
		switch(GetPropFlag(dwExProp,EXPROP_SOUND)){
		case EXPROP_DEFAULT:	dwDLFlags |= (m_dwDefDLFlag&DLCTL_BGSOUNDS); break;
		case EXPROP_ON:			dwDLFlags |= DLCTL_BGSOUNDS; break;
		}

		switch(GetPropFlag(dwExProp,EXPROP_RUNACTIVEX)){
		case EXPROP_DEFAULT:	dwDLFlags |= (m_dwDefDLFlag&DLCTL_NO_RUNACTIVEXCTLS); break;
		case EXPROP_OFF:		dwDLFlags |= DLCTL_NO_RUNACTIVEXCTLS; break;
		}
		switch(GetPropFlag(dwExProp,EXPROP_DLACTIVEX)){
		case EXPROP_DEFAULT:	dwDLFlags |= (m_dwDefDLFlag&DLCTL_NO_DLACTIVEXCTLS); break;
		case EXPROP_OFF:		dwDLFlags |= DLCTL_NO_DLACTIVEXCTLS; break;
		}
		switch(GetPropFlag(dwExProp,EXPROP_SCRIPT)){
		case EXPROP_DEFAULT:	dwDLFlags |= (m_dwDefDLFlag&DLCTL_NO_SCRIPTS); break;
		case EXPROP_OFF:		dwDLFlags |= DLCTL_NO_SCRIPTS; break;
		}
		switch(GetPropFlag(dwExProp,EXPROP_JAVA)){
		case EXPROP_DEFAULT:	dwDLFlags |= (m_dwDefDLFlag&DLCTL_NO_JAVA); break;
		case EXPROP_OFF:		dwDLFlags |= DLCTL_NO_JAVA; break;
		}

		return dwDLFlags;
	}
	
	//�^�u�̊g���X�^�C�����擾����
	int GetExtendedStyleFlags()
	{
		DWORD dwExFlag=0;
		DWORD dwExProp = m_dwExProp;

		switch(GetPropFlag(dwExProp,EXPROP_NAVI)){
		case EXPROP_DEFAULT:	dwExFlag |= (m_dwDefExStyle&DVS_EX_OPENNEWWIN); break;
		case EXPROP_ON:			dwExFlag |= DVS_EX_OPENNEWWIN; break;
		}
		switch(GetPropFlag(dwExProp,EXPROP_FILTER)){
		case EXPROP_DEFAULT:	dwExFlag |= (m_dwDefExStyle&DVS_EX_MESSAGE_FILTER); break;
		case EXPROP_ON:			dwExFlag |= DVS_EX_MESSAGE_FILTER; break;
		}
		switch(GetPropFlag(dwExProp,EXPROP_GETSTURE)){
		case EXPROP_DEFAULT:	dwExFlag |= (m_dwDefExStyle&DVS_EX_MOUSE_GESTURE); break;
		case EXPROP_ON:			dwExFlag |= DVS_EX_MOUSE_GESTURE; break;
		}
		switch(GetPropFlag(dwExProp,EXPROP_MAILTO)){
		case EXPROP_DEFAULT:	dwExFlag |= (m_dwDefExStyle&DVS_EX_BLOCK_MAILTO); break;
		case EXPROP_ON:			dwExFlag |= DVS_EX_BLOCK_MAILTO; break;
		}

		return dwExFlag;
	}

	//�����X�V�̃t���O�ϐ����擾����
	int GetAutoRefreshFlag()
	{
		DWORD dwRefreshFlag = m_dwExProp / (EXPROP_REFRESH_15SEC / DVS_AUTOREFRESH_15SEC);
		DWORD dwCurFlag = DVS_AUTOREFRESH_USER;
		while(dwCurFlag > 0){
			if(dwCurFlag & dwRefreshFlag){
				return  dwCurFlag;
			}
			dwCurFlag >>= 1;
		}
		return 0;
	}

	DWORD GetExProperty()
	{
		return m_dwExProp;
	}

	void SetExProperty(DWORD dwExProp)
	{
		m_dwExProp = dwExProp;
	}

	BOOL LoadExProperty(const CString& strIniFile, const CString& strSection = DONUT_SECTION)
	{
		DWORD dwExProp=0;
		CIniSection pr;
		pr.Open(strIniFile,strSection);
		pr.QueryValue(dwExProp,EXPROP_KEY);
		pr.Close();

		m_dwExProp = dwExProp;
	}

	static BOOL CheckExPropertyFlag(DWORD& dwFlags, CString& strIniFile, CString strSection = DONUT_SECTION)
	{
		DWORD dwExProp=0,dwEnabled=0;
		BOOL bEnabled = FALSE;
		CIniSection pr;
		pr.Open(strIniFile, strSection);
		pr.QueryValue(dwExProp,EXPROP_KEY);
		pr.QueryValue(dwEnabled,EXPROP_KEY_ENABLED);
		bEnabled = dwEnabled ? TRUE : FALSE;
		if(bEnabled) dwFlags = dwExProp;
		return bEnabled;
	}
};



//�g���v���p�e�B�f�[�^�ݒ�p�_�C�A���O
class CExPropertyDialog : public CDialogImpl<CExPropertyDialog>,
						public CWinDataExchange<CExPropertyDialog>
{
public:
	
	enum { IDD = IDD_DIALOG_EXPROPERTY };
	
	DWORD m_dwExProp;
	BOOL  m_bEnabled;

	CString m_strUrlFile;
	CString m_strSection;

	CString m_strTitle;

	int	m_nDLActiveX;
	int	m_nImage;
	int	m_nJava;
	int	m_nNaviLock;
	int	m_nRunActiveX;
	int	m_nScript;
	int	m_nScrollBar;
	int	m_nSound;
	int	m_nVideo;
	int	m_nBlockMailTo;
	int	m_nGesture;
	int	m_nFilter;
	int	m_nReload;

	CExPropertyDialog(const CString& strUrlFile,const CString strSection = DONUT_SECTION)
		: m_strUrlFile(strUrlFile), m_strSection(strSection)
	{

		DWORD dwExProp=0,dwEnabled=0;
		CIniSection pr;
		pr.Open(strUrlFile,strSection);
		pr.QueryValue(dwExProp, EXPROP_KEY);
		pr.QueryValue(dwEnabled, EXPROP_KEY_ENABLED);
		pr.Close();

		m_bEnabled = dwEnabled ? TRUE : FALSE;

		m_nImage =			(dwExProp&EXPROP_DLIMAGE) / (EXPROP_DLIMAGE/3);
		m_nVideo =			(dwExProp&EXPROP_VIDEO) / (EXPROP_VIDEO/3);
		m_nSound =			(dwExProp&EXPROP_SOUND) / (EXPROP_SOUND/3);
		m_nRunActiveX =		(dwExProp&EXPROP_RUNACTIVEX) / (EXPROP_RUNACTIVEX/3);
		m_nDLActiveX =		(dwExProp&EXPROP_DLACTIVEX) / (EXPROP_DLACTIVEX/3);
		m_nScript =			(dwExProp&EXPROP_SCRIPT) / (EXPROP_SCRIPT/3);
		m_nJava =			(dwExProp&EXPROP_JAVA) / (EXPROP_JAVA/3);
		
		m_nNaviLock =		(dwExProp&EXPROP_NAVI) / (EXPROP_NAVI/3);
		m_nFilter =			(dwExProp&EXPROP_FILTER) / (EXPROP_FILTER/3);
		m_nGesture =		(dwExProp&EXPROP_GETSTURE) / (EXPROP_GETSTURE/3);
		m_nBlockMailTo =	(dwExProp&EXPROP_MAILTO) / (EXPROP_MAILTO/3);

		int nFlag = dwExProp / EXPROP_REFRESH_NONE;
		m_nReload = 0;
		while((nFlag >>= 1) > 0)
			m_nReload++;

		
	}

	BEGIN_DDX_MAP(CExPropertyDialog)
		DDX_CHECK(IDC_CHECK_DLACTIVEXCTLS, m_nDLActiveX)
		DDX_CHECK(IDC_CHECK_IMAGE, m_nImage)
		DDX_CHECK(IDC_CHECK_JAVA, m_nJava)
		DDX_CHECK(IDC_CHECK_NAVILOCK, m_nNaviLock)
		DDX_CHECK(IDC_CHECK_RUNACTIVEXCTLS, m_nRunActiveX)
		DDX_CHECK(IDC_CHECK_SCRIPTS, m_nScript)
		DDX_CHECK(IDC_CHECK_SOUND, m_nSound)
		DDX_CHECK(IDC_CHECK_VIDEO, m_nVideo)
		DDX_CHECK(IDC_CHK_BLOCK_MAILTO, m_nBlockMailTo)
		DDX_CHECK(IDC_CHK_MOUSE_GESTURE, m_nGesture)
		DDX_CHECK(IDC_CHK_MSG_FILTER, m_nFilter)
		DDX_RADIO(IDC_RADIO_RELOAD_NONE, m_nReload)
		DDX_CHECK(IDC_CHECK_ENABLE, m_bEnabled)
	END_DDX_MAP()

	
	BEGIN_MSG_MAP(CExPropertyDialog)
		MSG_WM_INITDIALOG(OnInitDialog)
		COMMAND_ID_HANDLER_EX(IDOK,OnOK)
		COMMAND_ID_HANDLER_EX(IDCANCEL,OnCancel)
		COMMAND_ID_HANDLER_EX(IDC_BUTTON_DELETE,OnDelete)
		COMMAND_ID_HANDLER_EX(IDC_BUTTON_DEFAULT,OnDefault)
	END_MSG_MAP()

	
	LRESULT OnInitDialog(HWND hWnd, LPARAM lParam)
	{
		DWORD dwBufSize = 1024;
		CString strUrl;
		DWORD dwEnable=0;

		CIniSection pr;
		pr.Open(m_strUrlFile,_T("InternetShortcut"));
		pr.QueryValue(strUrl.GetBuffer(dwBufSize),_T("URL"),&dwBufSize);
		strUrl.ReleaseBuffer();
		pr.QueryValue(dwEnable, _T("Enable"));
		pr.Close();

		CStatic(GetDlgItem(IDC_STATIC_URL)).SetWindowText(strUrl);

		if(m_strTitle.IsEmpty()){
			CString strTitle = MtlGetFileName(m_strUrlFile);
			strTitle = strTitle.Left(strTitle.ReverseFind('.'));
			CStatic(GetDlgItem(IDC_STATIC_TITLE)).SetWindowText(strTitle);
		}else{
			CStatic(GetDlgItem(IDC_STATIC_TITLE)).SetWindowText(m_strTitle);
		}


		DoDataExchange(FALSE);
		return 1;
	}


	void OnOK(UINT uNotifyCode, int nID, HWND hWndCtl)
	{
		DoDataExchange(TRUE);

		// TODO: ���̈ʒu�ɂ��̑��̌��ؗp�̃R�[�h��ǉ����Ă�������
		DWORD dwExProp=0;

		dwExProp |= m_nImage * (EXPROP_DLIMAGE/3);
		dwExProp |= m_nVideo * (EXPROP_VIDEO/3);
		dwExProp |= m_nSound * (EXPROP_SOUND/3);
		dwExProp |= m_nRunActiveX * (EXPROP_RUNACTIVEX/3);
		dwExProp |= m_nDLActiveX * (EXPROP_DLACTIVEX/3);
		dwExProp |= m_nScript * (EXPROP_SCRIPT/3);
		dwExProp |= m_nJava * (EXPROP_JAVA/3);

		dwExProp |= m_nNaviLock * (EXPROP_NAVI/3);
		dwExProp |= m_nFilter * (EXPROP_FILTER/3);
		dwExProp |= m_nGesture * (EXPROP_GETSTURE/3);
		dwExProp |= m_nBlockMailTo * (EXPROP_MAILTO/3);

		if(m_nReload != -1)
			dwExProp |= (EXPROP_REFRESH_NONE << m_nReload);

		m_dwExProp = dwExProp;
		
		DWORD dwEnabled = m_bEnabled ? 1 : 0;
		CIniSection pr;
		pr.Open(m_strUrlFile,m_strSection);
		pr.SetValue(dwExProp,EXPROP_KEY);
		pr.SetValue(dwEnabled,EXPROP_KEY_ENABLED);

		EndDialog(nID);
	}

    void OnCancel(UINT uNotifyCode, int nID, HWND hWndCtl)
	{
        EndDialog(nID);
    }

	void OnDelete(UINT uNotifyCode, int nID, HWND hWndCtl)
	{
        m_nImage = m_nVideo = m_nSound = m_nRunActiveX = m_nDLActiveX = m_nScript = m_nJava = 0;
		m_nNaviLock = m_nFilter = m_nGesture = m_nBlockMailTo = 0;
		m_nReload = 0;

		if(m_strSection == DONUT_SECTION){
			MtlIniDeleteSection(m_strUrlFile, m_strSection);
		}else{
			CIniSection pr;
			pr.Open(m_strUrlFile,m_strSection);
			pr.DeleteValue(EXPROP_KEY);
			pr.DeleteValue(EXPROP_KEY_ENABLED);
		}
		m_bEnabled = FALSE;

		DoDataExchange(FALSE);
    }

	void OnDefault(UINT uNotifyCode, int nID, HWND hWndCtl)
	{
		DWORD dwDLFlag = CDLControlOption::s_dwDLControlFlags;
		DWORD dwExStyle = _dwViewStyle;
		
		m_nReload = 0;

		m_nImage =		dwDLFlag&DLCTL_DLIMAGES ? 1 : 0;
		m_nVideo =		dwDLFlag&DLCTL_VIDEOS ? 1 : 0;
		m_nSound =		dwDLFlag&DLCTL_BGSOUNDS ? 1 : 0;
		m_nRunActiveX = !(dwDLFlag&DLCTL_NO_RUNACTIVEXCTLS) ? 1 : 0;
		m_nDLActiveX =	!(dwDLFlag&DLCTL_NO_DLACTIVEXCTLS) ? 1 : 0;
		m_nScript =		!(dwDLFlag&DLCTL_NO_SCRIPTS) ? 1 : 0;
		m_nJava =		!(dwDLFlag&DLCTL_NO_JAVA) ? 1 : 0;

		m_nNaviLock =	dwExStyle&DVS_EX_OPENNEWWIN ? 1 : 0;
		m_nFilter =		dwExStyle&DVS_EX_MESSAGE_FILTER ? 1 : 0;
		m_nGesture =	dwExStyle&DVS_EX_MOUSE_GESTURE ? 1 : 0;
		m_nBlockMailTo =dwExStyle&DVS_EX_BLOCK_MAILTO ? 1 : 0;

		DoDataExchange(FALSE);
    }

	void SetTitle(CString strTitle)
	{
		m_strTitle = strTitle;
	}
	
};

