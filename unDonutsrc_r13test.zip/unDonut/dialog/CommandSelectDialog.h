#pragma once

#include "../resource.h"

class CCommandSelectDialog : 
	public CDialogImpl<CCommandSelectDialog >,
	public CWinDataExchange<CCommandSelectDialog >
{
public:
	enum { IDD = IDD_DIALOG_CMD_SELECT };

// Data members
	HMENU m_hMenu;
	CComboBox m_cmbCategory;
	CComboBox m_cmbCommand;
	DWORD m_dwCommandID;

	CCommandSelectDialog(HMENU hMenu);

	DWORD GetCommandID();

// Message map and handlers
	BEGIN_MSG_MAP(CCommandSelectDialog)
		MESSAGE_HANDLER(WM_INITDIALOG, OnInitDialog)

		COMMAND_HANDLER_EX(IDC_CMB_CATEGORY, CBN_SELCHANGE, OnSelChangeCate)
		COMMAND_HANDLER_EX(IDC_CMB_COMMAND, CBN_SELCHANGE, OnSelChangeCmd)

		COMMAND_ID_HANDLER(IDOK, OnCloseCmd)
		COMMAND_ID_HANDLER(IDCANCEL, OnCloseCmd)
	END_MSG_MAP()

	LRESULT OnInitDialog(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled);
	LRESULT OnCloseCmd(WORD wNotifyCode, WORD wID, HWND hWndCtl, BOOL& bHandled);
	void OnSelChangeCate(UINT code, int id, HWND hWnd);
	void OnSelChangeCmd(UINT code, int id, HWND hWnd);
	void SetGuideMsg();
};
