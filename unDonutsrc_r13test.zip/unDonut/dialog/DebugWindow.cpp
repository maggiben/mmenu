#include "stdafx.h"
#include "DebugWindow.h"

CDebugWindow *CDebugWindow::s_pThis = NULL;

void CDebugWindow::Create()
{
	if(cnt_b_use_debug_window){
		RECT rc = { 0,0,300,600 };
		baseclass::Create(m_hWnd,rc,_T("DebugWindow"),WS_OVERLAPPEDWINDOW|WS_VISIBLE,0);
		s_pThis = this;

		::DeleteFile("log.txt");
	}
}

void CDebugWindow::Destroy()
{
	if(cnt_b_use_debug_window){
		if(IsWindow())
			baseclass::DestroyWindow();
		s_pThis = NULL;
	}
}

void CDebugWindow::OutPutString(CString strText, bool bReturn)
{
	if(!s_pThis) return;
	if(!s_pThis->m_wndEdit.IsWindow()) return;
	if(!cnt_b_use_debug_window) return;
	
	FILE *fp = fopen("log.txt","a");
	if(fp){
		fprintf(fp,"%s\n",strText);
		fclose(fp);
	}

	if(bReturn)
		strText += _T("\r\n");
	s_pThis->m_wndEdit.ReplaceSel(strText);
}

LRESULT CDebugWindow::OnCreate(LPCREATESTRUCT lpcs)
{
	SetMsgHandled(FALSE);

	CRect rc; GetClientRect(&rc);
	::InflateRect(&rc,-4,-4);
	m_wndEdit.Create(m_hWnd,rc,NULL,ES_MULTILINE|WS_CHILD|WS_VISIBLE|WS_VSCROLL|WS_HSCROLL);
	return 0;
}

LRESULT CDebugWindow::OnSize(UINT,CSize size)
{
	SetMsgHandled(FALSE);

	CRect rc; GetClientRect(&rc);
	::InflateRect(&rc,-4,-4);
	m_wndEdit.MoveWindow(rc);
	return 0;
}
