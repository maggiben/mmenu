
#pragma once

// for debug
#ifdef _DEBUG
	const bool _Mtl_ScriptErrorCommandTargetImpl_traceOn = false;
	#define secTRACE if (_Mtl_ScriptErrorCommandTargetImpl_traceOn) ATLTRACE
#else
	#define secTRACE
#endif

template <class T>
class ATL_NO_VTABLE IScriptErrorCommandTargetImpl : public IOleCommandTarget
{
public:
	STDMETHOD(QueryStatus)( 
            /* [unique][in] */ const GUID __RPC_FAR *pguidCmdGroup,
            /* [in] */ ULONG cCmds,
            /* [out][in][size_is] */ OLECMD __RPC_FAR prgCmds[  ],
            /* [unique][out][in] */ OLECMDTEXT __RPC_FAR *pCmdText)
	{
		return E_FAIL;
	}

	STDMETHOD(Exec)( 
            /* [unique][in] */ const GUID __RPC_FAR *pguidCmdGroup,
            /* [in] */ DWORD nCmdID,
            /* [in] */ DWORD nCmdexecopt,
            /* [unique][in] */ VARIANT __RPC_FAR *pvaIn,
            /* [unique][out][in] */ VARIANT __RPC_FAR *pvaOut)
	{
		if (pguidCmdGroup == NULL || !::IsEqualGUID(*pguidCmdGroup, DONUT_CGID_DocHostCommandHandler))
			return OLECMDERR_E_UNKNOWNGROUP;

		if (nCmdID != OLECMDID_SHOWSCRIPTERROR)
			return OLECMDERR_E_NOTSUPPORTED;
		
		secTRACE(_T("IScriptErrorCommandTargetImpl::Exec\n"));

		T* pT = static_cast<T*>(this);
		CWindow wndFrame = pT->GetTopLevelParent();
		CWindow wndStatus = wndFrame.GetDlgItem(ATL_IDW_STATUS_BAR);
		wndStatus.SetWindowText(_T("�X�N���v�g�G���[���������܂���"));
/*
		IUnknown* pUnk = V_UNKNOWN(pvaIn);
		CComQIPtr<IHTMLDocument2> spDocument = pUnk;
		if (!spDocument)
			return hr;
		CComQIPtr<IHTMLWindow2> spWindow = spDocument;
		if (!spWindow)
			return hr;

		CComPtr<IHTMLEventObj> spEvent;
		HRESULT hr = spWindow->get_event(&spEvent);
		if (FAILED(hr))
			return hr;
*/

 		pvaOut->vt = VT_BOOL;
		V_BOOL(pvaOut) = VARIANT_TRUE;

		return S_OK;
	}
};