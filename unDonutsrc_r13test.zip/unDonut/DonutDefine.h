#ifndef __DONUTDEFINE_H__
#define __DONUTDEFINE_H__

#pragma once

#define MYWM_NOTIFYICON		(WM_APP+100)	// UDT DGSTR
#define TM_TRAY	0							// UDT DGSTR

#include <atlbase.h>
#include <atlapp.h>
#include <atlmisc.h>
#include <atlcrack.h>

// Don't change for saving rebar state
#define IDC_ADDRESSBAR					101
#define IDC_GOBUTTON					102
#define IDC_MDITAB						103
#define IDC_LINKBAR						104
#define IDC_SEARCHBAR					105
#define IDC_PLUGIN_TOOLBAR				151
#define IDC_PLUGIN_EXPLORERBAR			181 //minit

#define IDC_PROGRESS					201
#define IDC_COMBBOX						202

// #define DONUT_HAS_CMDBAR


#define D_OPENFILE_ACTIVATE		0x00000001
#define D_OPENFILE_NOCREATE		0x00000002
#define D_OPENFILE_NOSETFOCUS	0x00000004

// Dev studio doesn't know BEGIN_MSG_MAP_EX
#undef BEGIN_MSG_MAP
#define BEGIN_MSG_MAP BEGIN_MSG_MAP_EX

#ifndef WM_MOUSEWHEEL
	#define WM_MOUSEWHEEL 0x020A
#endif

#define DVS_EX_OPENNEWWIN		0x00000001L
#define DVS_EX_MESSAGE_FILTER	0x00000002L
#define DVS_EX_MOUSE_GESTURE	0x00000004L
#define DVS_EX_BLOCK_MAILTO		0x00000008L

#define DONUT_THREADWAIT	3000
//#define DONUT_THREADWAIT	INFINITE

static bool _bMozilla = false;

// UDT DGSTR ( dai
static bool _bFlatScrBar = false;

static const CLSID CLSID_MozillaBrowser =
{ 0x1339B54C, 0x3453, 0x11D2, { 0x93, 0xB9, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00 } };


static const CLSID DONUT_CGID_DocHostCommandHandler =
{ 0xf38bc242, 0xb950, 0x11d1, { 0x89, 0x18, 0x00, 0xc0, 0x4f, 0xc2, 0xc8, 0x36 } };

// UH
static BOOL _bSwapProxy = FALSE;	
static DWORD _dwViewStyle=DVS_EX_MOUSE_GESTURE;

// to emulate DDE.
#define WM_NEWINSTANCE WM_USER + 16
#define USER_MSG_WM_NEWINSTANCE(func) \
	if (uMsg == WM_NEWINSTANCE) \
	{ \
		SetMsgHandled(TRUE); \
		func((ATOM)wParam); \
		lResult = 0; \
		if(IsMsgHandled()) \
			return TRUE; \
	}

// to save child window options
#define WM_SAVE_OPTION WM_USER + 20
#define USER_MSG_WM_SAVE_OPTION(func) \
	if (uMsg == WM_SAVE_OPTION) \
	{ \
		SetMsgHandled(TRUE); \
		func((LPCTSTR)wParam, (int)lParam); \
		lResult = 0; \
		if(IsMsgHandled()) \
			return TRUE; \
	}

// UDT DGSTR 
#define WM_UPDATE_TITLEBAR WM_USER + 24
#define USER_MSG_WM_UPDATE_TITLEBAR(func) \
	if (uMsg == WM_UPDATE_TITLEBAR) \
	{ \
		SetMsgHandled(TRUE); \
		lResult = (LRESULT)func((LPCTSTR)wParam, (DWORD)lParam); \
		if(IsMsgHandled()) \
			return TRUE; \
	}
// ENDE

// UDT DGSTR 
#define WM_UPDATE_EXPBAR WM_USER + 28
#define USER_MSG_WM_UPDATE_EXPBAR(func) \
	if (uMsg == WM_UPDATE_EXPBAR) \
	{ \
		SetMsgHandled(TRUE); \
		lResult = (LRESULT)func((LPCTSTR)wParam, (DWORD)lParam); \
		if(IsMsgHandled()) \
			return TRUE; \
	}
// ENDE

// UH
#define WM_MENU_GOBACK WM_USER + 50
#define USER_MSG_WM_MENU_GOBACK(func) \
	if (uMsg == WM_MENU_GOBACK) \
	{ \
		SetMsgHandled(TRUE); \
		lResult = (LRESULT)func((HMENU)wParam); \
		if(IsMsgHandled()) \
			return TRUE; \
	}
#define WM_MENU_GOFORWARD WM_USER + 51
#define USER_MSG_WM_MENU_GOFORWARD(func) \
	if (uMsg == WM_MENU_GOFORWARD) \
	{ \
		SetMsgHandled(TRUE); \
		lResult = (LRESULT)func((HMENU)wParam); \
		if(IsMsgHandled()) \
			return TRUE; \
	}
#define WM_MENU_GET_FAV WM_USER + 52
#define USER_MEG_WM_MENU_GET_FAV(func) \
	if (uMsg == WM_MENU_GET_FAV) \
	{ \
		SetMsgHandled(TRUE); \
		lResult = (LRESULT)func(); \
		if(IsMsgHandled()) \
			return lResult; \
	}

#define WM_MENU_GET_FAV_GROUP WM_USER + 53
#define USER_MEG_WM_MENU_GET_FAV_GROUP(func) \
	if (uMsg == WM_MENU_GET_FAV_GROUP) \
	{ \
		SetMsgHandled(TRUE); \
		lResult = (LRESULT)func(); \
		if(IsMsgHandled()) \
			return lResult; \
	}

#define WM_USER_HILIGHT WM_USER + 54
#define MSG_WM_USER_HILIGHT(func) \
	if (uMsg == WM_USER_HILIGHT) \
	{ \
		SetMsgHandled(TRUE); \
		lResult = (LRESULT)func((LPCTSTR)wParam); \
		if(IsMsgHandled()) \
			return TRUE; \
	}

#define WM_USER_FIND_KEYWORD WM_USER + 55
#define MSG_WM_USER_FIND_KEYWORD(func) \
	if (uMsg == WM_USER_FIND_KEYWORD) \
	{ \
		SetMsgHandled(TRUE); \
		lResult = (LRESULT)func((LPCTSTR)wParam, (BOOL)lParam); \
		if(IsMsgHandled()) \
			return TRUE; \
	}

#define WM_USER_USED_MOUSE_GESTURE WM_USER + 56
#define MSG_WM_USER_USED_MOUSE_GESTURE(func) \
	if (uMsg == WM_USER_USED_MOUSE_GESTURE) \
	{ \
		SetMsgHandled(TRUE); \
		lResult = (LRESULT)func(); \
		if(IsMsgHandled()) \
			return lResult; \
	}

#define WM_USER_CHANGE_CSS WM_USER + 57
#define MSG_WM_USER_CHANGE_CSS(func) \
	if (uMsg == WM_USER_CHANGE_CSS) \
	{ \
		SetMsgHandled(TRUE); \
		lResult = (LRESULT)func((LPCTSTR)wParam); \
		if(IsMsgHandled()) \
			return lResult; \
	}

#define WM_MENU_GET_CSS WM_USER + 58

#define WM_MENU_GET_SCRIPT WM_USER + 59
#define USER_MEG_WM_MENU_GET_SCRIPT(func) \
	if (uMsg == WM_MENU_GET_SCRIPT) \
	{ \
		SetMsgHandled(TRUE); \
		lResult = (LRESULT)func(); \
		if(IsMsgHandled()) \
			return lResult; \
	}

#define WM_STATUS_SETICON	WM_USER + 60
//End UH


//minit
#define WM_MENU_REFRESH_FAV WM_USER + 80
#define USER_MEG_WM_MENU_REFRESH_FAV(func) \
	if (uMsg == WM_MENU_REFRESH_FAV) \
	{ \
		SetMsgHandled(TRUE); \
		lResult = (LRESULT)func((BOOL)wParam); \
		if(IsMsgHandled()) \
			return lResult; \
	}

#define WM_MENU_REFRESH_FAV_GROUP WM_USER + 81
#define USER_MEG_WM_MENU_REFRESH_FAV_GROUP(func) \
	if (uMsg == WM_MENU_REFRESH_FAV_GROUP) \
	{ \
		SetMsgHandled(TRUE); \
		lResult = (LRESULT)func((BOOL)wParam); \
		if(IsMsgHandled()) \
			return lResult; \
	}

#define WM_MENU_REFRESH_SCRIPT WM_USER + 82
#define USER_MEG_WM_MENU_REFRESH_SCRIPT(func) \
	if (uMsg == WM_MENU_REFRESH_SCRIPT) \
	{ \
		SetMsgHandled(TRUE); \
		lResult = (LRESULT)func((BOOL)wParam); \
		if(IsMsgHandled()) \
			return lResult; \
	}

#define WM_MENU_RESTRICT_MESSAGE WM_USER + 83
#define USER_MSG_WM_MENU_RESTRICT_MESSAGE(func) \
	if (uMsg == WM_MENU_RESTRICT_MESSAGE) \
	{ \
		SetMsgHandled(TRUE); \
		lResult = (LRESULT)func((BOOL)wParam); \
		if(IsMsgHandled()) \
			return lResult; \
	}

#define WM_RELEASE_CONTEXTMENU WM_USER + 84
#define USER_MSG_WM_RELEASE_CONTEXTMENU(func) \
	if (uMsg == WM_RELEASE_CONTEXTMENU) \
	{ \
		SetMsgHandled(TRUE); \
		lResult = (LRESULT)func(uMsg,wParam,lParam,bHandled); \
		if(IsMsgHandled()) \
			return lResult; \
	}

#define WM_MENU_RECENTDOCUMENT (WM_USER + 85)
#define USER_MSG_WM_MENU_RECENTDOCUMENT(func) \
	if (uMsg == WM_MENU_RECENTDOCUMENT) \
	{ \
		SetMsgHandled(TRUE); \
		lResult = (LRESULT)func((HMENU)wParam); \
		if(IsMsgHandled()) \
			return lResult; \
	}

#define WM_GET_EXTENDED_TABSTYLE (WM_USER + 86)
#define USER_MSG_WM_GET_EXTENDED_TABSTYLE(func) \
	if (uMsg == WM_GET_EXTENDED_TABSTYLE) \
	{ \
		SetMsgHandled(TRUE); \
		lResult = (LRESULT)func(); \
		if(IsMsgHandled()) \
			return lResult; \
	}

#define WM_SET_EXTENDED_TABSTYLE (WM_USER + 87)
#define USER_MSG_WM_SET_EXTENDED_TABSTYLE(func) \
	if (uMsg == WM_SET_EXTENDED_TABSTYLE) \
	{ \
		SetMsgHandled(TRUE); \
		func((DWORD)wParam); \
		if(IsMsgHandled()) \
			return TRUE; \
	}

#define WM_GET_CHILDFRAME (WM_USER + 88)
#define USER_MSG_WM_SET_CHILDFRAME(func) \
	if (uMsg == WM_GET_CHILDFRAME) \
	{ \
		SetMsgHandled(TRUE); \
		lResult = (LRESULT)func(); \
		if(IsMsgHandled()) \
			return lResult; \
	}

#define WM_CHANGE_SKIN (WM_USER + 89)
#define USER_MSG_WM_CHANGE_SKIN(func) \
	if (uMsg == WM_CHANGE_SKIN) \
	{ \
		SetMsgHandled(TRUE); \
		lResult = (LRESULT)func(); \
		if(IsMsgHandled()) \
			return lResult; \
	}

#define WM_OPEN_EXPFAVMENU (WM_USER + 90)
#define USER_MSG_WM_OPEN_EXPFAVMENU(func) \
	if (uMsg == WM_OPEN_EXPFAVMENU) \
	{ \
		SetMsgHandled(TRUE); \
		lResult = (LRESULT)func((int)wParam, (int)lParam); \
		if(IsMsgHandled()) \
			return lResult; \
	}

#define WM_COMMAND_DIRECT (WM_USER + 91)
#define USER_MSG_WM_COMMAND_DIRECT(func) \
	if (uMsg == WM_COMMAND_DIRECT) \
	{ \
		SetMsgHandled(TRUE); \
		lResult = (LRESULT)func((int)wParam, (LPCTSTR)lParam); \
		if(IsMsgHandled()) \
			return lResult; \
	}

#define WM_SEARCH_WEB_SELTEXT (WM_USER + 92)
#define USER_MSG_WM_SEARCH_WEB_SELTEXT(func) \
	if (uMsg == WM_SEARCH_WEB_SELTEXT) \
	{ \
		SetMsgHandled(TRUE); \
		lResult = (LRESULT)func((LPCTSTR)wParam, (LPCTSTR)lParam); \
		if(IsMsgHandled()) \
			return lResult; \
	}

#define WM_REFRESH_EXPBAR (WM_USER + 93)
#define USER_MSG_WM_REFRESH_EXPBAR(func) \
	if (uMsg == WM_REFRESH_EXPBAR) \
	{ \
		SetMsgHandled(TRUE); \
		lResult = (LRESULT)func((int)wParam); \
		if(IsMsgHandled()) \
			return TRUE; \
	}

#define WM_SET_EXPROPERTY (WM_USER + 94)
#define USER_MSG_WM_SET_EXPROPERTY(func) \
	if (uMsg == WM_SET_EXPROPERTY) \
	{ \
		SetMsgHandled(TRUE); \
		lResult = (LRESULT)func((LPCTSTR)wParam); \
		if(IsMsgHandled()) \
			return TRUE; \
	}

#define WM_GET_OWNERDRAWMODE (WM_USER + 95)
#define USER_MSG_WM_GET_OWNERDRAWMODE(func) \
	if (uMsg ==  WM_GET_OWNERDRAWMODE) \
	{ \
		SetMsgHandled(TRUE); \
		lResult = (LRESULT)func(); \
		if(IsMsgHandled()) \
			return TRUE; \
	} 



struct _EXPROP_ARGS
{
	CString strUrl;
	DWORD dwOpenFlag;
	CString strIniFile;
	CString strSection;
	CString strSearchWord;
};

#define WM_OPEN_WITHEXPROP (WM_USER + 96)
#define USER_MSG_WM_OPEN_WITHEXPROP(func) \
	if (uMsg == WM_OPEN_WITHEXPROP) \
	{ \
		SetMsgHandled(TRUE); \
		lResult = (LRESULT)func((_EXPROP_ARGS*)wParam); \
		if(IsMsgHandled()) \
			return TRUE; \
	} 

#define WM_GET_SEARCHBAR (WM_USER + 97)
#define USER_MSG_WM_GET_SEARCHBAR(func) \
	if (uMsg == WM_GET_SEARCHBAR) \
	{ \
		SetMsgHandled(TRUE); \
		lResult = (LRESULT)func(); \
		if(IsMsgHandled()) \
			return TRUE; \
	} 

#define WM_SHOW_TOOLBARMENU (WM_USER + 98)
#define USER_MSG_WM_SHOW_TOOLBARMENU(func) \
	if (uMsg == WM_SHOW_TOOLBARMENU) \
	{ \
		SetMsgHandled(TRUE); \
		lResult = (LRESULT)func(); \
		if(IsMsgHandled()) \
			return TRUE; \
	}

#endif // __DONUTDEFINE_H__