#pragma once

void MtlRefreshBandIdealSize(CReBarCtrl rebar, CToolBarCtrl toolbar);

HWND _CreateSimpleReBarCtrl(HWND hWndParent, DWORD dwStyle = ATL_SIMPLE_REBAR_STYLE, UINT nID = ATL_IDW_TOOLBAR);

