#include "stdafx.h"
#include "DonutToolBar.h"
#include "MtlProfile.h"
#include "DonutPFunc.h"

using namespace MTL;

CDonutToolBar::CDonutToolBar()
{
	m_strToolbarIniPath = GetToolBarFilePath();
}

// Ctor
void CDonutToolBar::DonutToolBar_SetFavoritesMenu(HMENU hMenu, HMENU hMenuUser, HMENU hMenuCSS)
{
	m_menuFavorites = hMenu;
	m_menuFavoritesUser = hMenuUser;
	m_menuCSS = hMenuCSS;
}

LRESULT CDonutToolBar::OnChevronPushed(int /*idCtrl*/, LPNMHDR pnmh, BOOL& bHandled)
{
	ATLASSERT( ((LPNMREBARCHEVRON)pnmh)->wID == GetDlgCtrlID() );
	if (!PushChevron(pnmh, GetTopLevelParent())) {
		bHandled = FALSE;
		return 1;
	}

	return 0;
}

LRESULT CDonutToolBar::OnRButtonUp(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
{
	::SendMessage(GetTopLevelParent(),WM_SHOW_TOOLBARMENU,0,0);
	return 0;
}

LRESULT CDonutToolBar::OnToolTipText(int idCtrl, LPNMHDR pnmh, BOOL& bHandled)
{
	
	CString strText = CExMenuManager::GetToolTip(idCtrl);
	if(strText.IsEmpty()){
		bHandled = FALSE;
		return 0;
	}
	LPNMTTDISPINFOA pDispInfo = (LPNMTTDISPINFOA)pnmh;
	lstrcpynA(pDispInfo->szText, strText, sizeof(pDispInfo->szText) / sizeof(pDispInfo->szText[0]));

	return 0;
}

// Implemantation
HMENU CDonutToolBar::_GetDropDownMenu(int nCmdID, bool& bDestroy, bool& bSubMenu)
{
	CMenuHandle menu;// handle
	bDestroy = bSubMenu = true;

	switch (nCmdID) {
	case ID_FILE_NEW:
		menu.LoadMenu(IDR_FILE_NEW);
		break;
	case ID_VIEW_FONT_SIZE:
		menu.LoadMenu(IDR_VIEW_FONT_SIZE);
		break;
	case ID_FILE_NEW_CLIPBOARD2:
		menu.LoadMenu(IDR_FILE_NEW_CLIPBOARD);
		break;
	case ID_VIEW_BACK:
		menu.LoadMenu(IDR_VIEW_BACK);
		{
			HWND hChildFrm = ::GetParent(GetParent());
			::SendMessage(hChildFrm, WM_MENU_GOBACK, (WPARAM)(HMENU)menu.m_hMenu, (LPARAM)0);
		}
		break;
	case ID_VIEW_FORWARD:
		menu.LoadMenu(IDR_VIEW_FORWARD);
		{
			HWND hChildFrm = ::GetParent(GetParent());
			::SendMessage(hChildFrm, WM_MENU_GOFORWARD, (WPARAM)(HMENU)menu.m_hMenu, (LPARAM)0);
		}
		break;
	case ID_FAVORITES_DROPDOWN:
		menu = m_menuFavorites;
		bDestroy = bSubMenu = false;// it's not mine.
		break;
//		case ID_MAIN_EX_NEWWINDOW:
//			menu.LoadMenu(IDR_MENU_FAVTREE_BAR);
//			break;

	case ID_MULTIMEDIA:
	case ID_DLCTL_CHG_MULTI:
		menu.LoadMenu(IDR_MULTIMEDIA);
		break;
	case ID_SECURITY:
	case ID_DLCTL_CHG_SECU:
		menu.LoadMenu(IDR_SECURITY);
		break;
	case ID_COOKIE:
	case ID_URLACTION_COOKIES_CHG:
		menu.LoadMenu(IDR_COOKIE);
		break;
	case ID_TOOLBAR:
		menu.LoadMenu(IDR_TOOLBAR);
		break;
	case ID_EXPLORERBAR:
		menu.LoadMenu(IDR_EXPLORERBAR);
		//menu.LoadMenu(IDR_MENU_FAVTREE_BAR);
		break;
	case ID_MOVE:
		menu.LoadMenu(IDR_MOVE);
		break;
	case ID_OPTION:
		menu.LoadMenu(IDR_OPTION);
		break;
	case ID_AUTO_REFRESH:
		menu.LoadMenu(IDR_AUTO_REFRESH);
		break;
	case ID_DOUBLE_CLOSE:
		menu.LoadMenu(IDR_DOUBLE_CLOSE);
		break;
	case ID_COOKIE_IE6:
		menu.LoadMenu(IDR_COOKIE_IE6);
		break;
	case ID_FAVORITES_GROUP_DROPDOWN:
		menu = m_menuFavoritesUser;
		bDestroy = bSubMenu = false;// it's not mine.
		break;
	case ID_CSS_DROPDOWN:
		menu = m_menuCSS;
		bDestroy = bSubMenu = false;// it's not mine.
		break;
	case ID_RECENT_DOCUMENT:
		menu.LoadMenu(IDR_RECENT_DOC);
		::SendMessage(GetTopLevelParent(),WM_MENU_RECENTDOCUMENT,(WPARAM)(HMENU)menu.GetSubMenu(0),(LPARAM)0);
		break;
	default:
		ATLASSERT(FALSE);
	}

	return menu.m_hMenu;
}

// Overrides
HMENU CDonutToolBar::ChevronHandler_OnGetChevronMenu(int nCmdID, HMENU& hMenuDestroy)
{
//		if (nCmdID == ID_VIEW_FAVEXPBAR)
//			return NULL;// give up.

	bool bDestroy, bSubMenu;
	CMenuHandle menu = _GetDropDownMenu(nCmdID, bDestroy, bSubMenu);

	if (bDestroy)
		hMenuDestroy = menu.m_hMenu;

	if (bSubMenu)
		return menu.GetSubMenu(0);
	else
		return menu;
}

void CDonutToolBar::Chevronhandler_OnCleanupChevronMenu()
{
//		m_menuFavorites.RemoveMenu(ID_FAVORITES_DROPDOWN, MF_BYCOMMAND);
}

LRESULT CDonutToolBar::StdToolBar_OnDropDown(int nCmdID)
{
	bool bDestroy, bSubMenu;
	CMenuHandle menu = _GetDropDownMenu(nCmdID, bDestroy, bSubMenu);

	if (menu.m_hMenu) {
		if (bSubMenu)
			StdToolBar_TrackDropDownMenu(nCmdID, menu.GetSubMenu(0), GetTopLevelParent());
		else
			StdToolBar_TrackDropDownMenu(nCmdID, menu, GetTopLevelParent());
	}

	if (bDestroy)
		menu.DestroyMenu();

	return TBDDRET_DEFAULT;
}

void CDonutToolBar::StdToolBar_WriteProfile()
{
	CIniSection pr;
	CString strFile;
	strFile = m_strToolbarIniPath;
	pr.Open(strFile, _T("ToolBar"));
	
	MtlWriteProfileTBBtns(pr, m_hWnd);
	pr.SetValue(m_dwStdToolBarStyle, _T("Std_ToolBar_Style"));
}

void CDonutToolBar::StdToolBar_GetProfile()
{
	CIniSection pr;
	CString strFile;
	strFile = m_strToolbarIniPath;
	pr.Open(strFile, _T("ToolBar"));
	
	CSimpleArray<int> arrBmpIndex;
	if (MtlGetProfileTBBtns(pr, arrBmpIndex))
		StdToolBar_InitButtons(_begin(arrBmpIndex), _end(arrBmpIndex));
	else
		StdToolBar_InitButtons(_begin(m_arrBmpDefaultIndex), _end(m_arrBmpDefaultIndex));

	DWORD dwStyle = STD_TBSTYLE_DEFAULT;
	pr.QueryValue(dwStyle, _T("Std_ToolBar_Style"));

	StdToolBar_SetStyle(dwStyle);
}

// Methods
HWND CDonutToolBar::DonutToolBar_Create(HWND hWndParent)
{
	STD_TBBUTTON* pBtns=NULL;
	int nBtnCnt = GetToolBarStatus(pBtns);
	int defaultBtns[] = { 0, 1, 2, 3, 4, 5, -1, 9, 10, 11, -1, 12 };

	StdToolBar_Init(pBtns, pBtns + nBtnCnt,
		defaultBtns, defaultBtns + _countof(defaultBtns),
		std::make_pair(IDB_MAINFRAME_TOOLBAR, IDB_MAINFRAME_TOOLBAR_HOT),
		std::make_pair(IDB_MAINFRAME_LARGE_TOOLBAR, IDB_MAINFRAME_LARGE_TOOLBAR_HOT),
		CSize(16, 16), CSize(20, 20), RGB(255, 0, 255));

	delete []pBtns;
	return StdToolBar_Create(hWndParent,
		ATL_SIMPLE_TOOLBAR_PANE_STYLE|  CCS_ADJUSTABLE | TBSTYLE_ALTDRAG,
		TBSTYLE_EX_MIXEDBUTTONS | TBSTYLE_EX_DRAWDDARROWS | TBSTYLE_EX_HIDECLIPPEDBUTTONS);
}

CString CDonutToolBar::GetToolBarFilePath()
{
	TCHAR cPathExe[MAX_PATH];
	::GetModuleFileName(_Module.GetModuleInstance(), cPathExe, MAX_PATH);

	TCHAR szPath[MAX_PATH];		memset(szPath, 0, sizeof(szPath));
	DWORD dwCount = MAX_PATH;

	CIniSection pr;
	pr.Open(_szIniFileName, _T("Path"));
	pr.QueryValue(szPath, _T("ToolbarPath"), &dwCount);
	pr.Close();

	CString strFile(szPath);
	CString strPath = _GetSkinDir() + _T("Toolbar.ini");
	if(::GetFileAttributes(strPath) == 0xFFFFFFFF){
		if (strFile.IsEmpty()){
			strFile.Format("%s", cPathExe);
			strPath = strFile.Left(strFile.ReverseFind('\\')+1) + _T("Toolbar\\Toolbar.ini");
		}else{
			strPath = strFile + _T("\\Toolbar.ini");
		}
	}
	
	return strPath;
}

int CDonutToolBar::GetToolBarStatus(STD_TBBUTTON* &pBtns)
{
	pBtns=NULL;

	// �c�[���o�[�t�@�C���p�X
	CString strFile;
	strFile = m_strToolbarIniPath;

	// �c�[���o�[�ԍ�
	DWORD dwCount = 0;
	CIniSection pr;
	pr.Open(strFile, _T("TOOLBAR"));
	pr.QueryValue(dwCount, _T("TOOLBAR_CNT"));
	pr.Close();
	
	if (dwCount==0)
		return GetToolBarStatusStd(pBtns);


	// �c�[���[�o�[�쐬
	pBtns = new STD_TBBUTTON[dwCount];
	//vvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvv
	// �c�[���o�[
	pr.Open(strFile, _T("TOOLBAR"));

	for (int ii=0; ii<(int)dwCount; ii++)
	{
		CString strKeyID, strKeyStyle;
		strKeyID.Format("ID_%d", ii);
		strKeyStyle.Format("STYLE_%d", ii);
		
		DWORD dwID=0, dwStyle=0;
		pr.QueryValue(dwID, strKeyID);
		pr.QueryValue(dwStyle, strKeyStyle);

		pBtns[ii].idCommand = dwID;
		pBtns[ii].fsStyle = dwStyle;
	}
	pr.Close();
	//^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

	return dwCount;
}

int CDonutToolBar::GetToolBarStatusStd(STD_TBBUTTON* &pBtns)
{
	STD_TBBUTTON btns[] = {
		{ID_FILE_NEW,		BTNS_BUTTON|BTNS_DROPDOWN},
		{ID_VIEW_BACK,		BTNS_BUTTON|BTNS_STD_LIST|BTNS_DROPDOWN},
		{ID_VIEW_FORWARD,	BTNS_BUTTON|BTNS_STD_LIST|BTNS_DROPDOWN},
		{ID_VIEW_STOP,		BTNS_BUTTON}, 
		{ID_VIEW_REFRESH,	BTNS_BUTTON}, 
		{ID_VIEW_HOME,		BTNS_BUTTON},
		{ID_FILE_NEW_CLIPBOARD2,	BTNS_BUTTON|BTNS_DROPDOWN}, 

		{ID_VIEW_STOP_ALL,		BTNS_BUTTON}, 
		{ID_VIEW_REFRESH_ALL,	BTNS_BUTTON},

		{ID_VIEW_FAVEXPBAR,		BTNS_BUTTON|BTNS_STD_LIST}, //BTNS_DROPDOWN}, 
		{ID_VIEW_FAVEXPBAR_HIST,	BTNS_BUTTON|BTNS_STD_LIST},
		{ID_VIEW_CLIPBOARDBAR,	BTNS_BUTTON|BTNS_STD_LIST},

		{ID_FILE_PRINT,		BTNS_BUTTON},

		{ID_VIEW_FULLSCREEN,	BTNS_BUTTON}, 
		{ID_WINDOW_CASCADE,		BTNS_BUTTON}, 
		{ID_WINDOW_TILE_HORZ,	BTNS_BUTTON}, 
		{ID_WINDOW_TILE_VERT,	BTNS_BUTTON},

		{ID_VIEW_TABBAR_MULTI,	BTNS_BUTTON}, 
		{ID_TAB_LEFT,			BTNS_BUTTON}, 
		{ID_TAB_RIGHT,			BTNS_BUTTON}, 

		{ID_EDIT_CUT,			BTNS_BUTTON}, 
		{ID_EDIT_COPY,			BTNS_BUTTON}, 
		{ID_EDIT_PASTE,			BTNS_BUTTON},

		{ID_VIEW_FONT_SIZE,			BTNS_BUTTON|BTNS_DROPDOWN|BTNS_WHOLEDROPDOWN}, 
		{ID_DOCHOSTUI_OPENNEWWIN,	BTNS_BUTTON},

		{ID_DLCTL_DLIMAGES,			BTNS_BUTTON}, 
		{ID_DLCTL_SCRIPTS,			BTNS_BUTTON},	
		{ID_DLCTL_JAVA,				BTNS_BUTTON}, 
		{ID_DLCTL_RUNACTIVEXCTLS,	BTNS_BUTTON},	
		{ID_DLCTL_DLACTIVEXCTLS,	BTNS_BUTTON}, 
		{ID_DLCTL_BGSOUNDS,			BTNS_BUTTON},	
		{ID_DLCTL_VIDEOS,			BTNS_BUTTON}, 

		{ID_FILE_CLOSE,			BTNS_BUTTON}, 
		{ID_WINDOW_CLOSE_ALL,	BTNS_BUTTON},	
		{ID_WINDOW_CLOSE_EXCEPT,BTNS_BUTTON}, 

		{ID_MAIN_EX_NEWWINDOW,			BTNS_BUTTON}, 
		{ID_MAIN_EX_NOACTIVATE,			BTNS_BUTTON},	
		{ID_MAIN_EX_NOACTIVATE_NEWWIN,	BTNS_BUTTON}, 
		{ID_REGISTER_AS_BROWSER,		BTNS_BUTTON}, 
		{ID_FAVORITES_DROPDOWN,			BTNS_BUTTON|BTNS_STD_LIST|BTNS_DROPDOWN|BTNS_WHOLEDROPDOWN},
		{ID_EDIT_OPEN_SELECTED_REF,		BTNS_BUTTON},
		{ID_EDIT_OPEN_SELECTED_TEXT,	BTNS_BUTTON},

		// U.H
		{ID_WINDOW_REFRESH_EXCEPT,	BTNS_BUTTON},
	};

	pBtns = new STD_TBBUTTON[_countof(btns)];
	memcpy(pBtns, btns, _countof(btns)*sizeof(STD_TBBUTTON));
	return _countof(btns);
}

void CDonutToolBar::ReloadSkin()
{
	StdToolBar_WriteProfile(); //��Ԃ�ۑ�

	//�C���[�W���X�g�y�у{�^���̍č\�z
	m_strToolbarIniPath = GetToolBarFilePath();
	StdToolBar_DestroyImageList();
	StdToolBar_UpdateImageList();
	InvalidateRect(NULL,TRUE);
	StdToolBar_GetProfile();
}
