
#pragma once

#include "MenuDefines.h"
#include "FavoriteOrder.h"

#define MNGOF_CENTERGAP	0


template <class T>
class ATL_NO_VTABLE CMenuDropTargetWindowImpl 
	: public CWindowImpl<T>,
	  public IDropTargetImpl<T>,
	  public IDropSourceImpl<T>
{
public:
	HMENU m_hDDMenu;
	bool m_bDragAccept;
	char	_text[MAX_PATH];

	typedef struct _DragMenuData
	{
		int nPos;
		DWORD dwPos;
		HMENU hMenu;
		CString strFilePath; 
		int nDir;
		BOOL bBottom;

		_DragMenuData()
			: bBottom(FALSE) , hMenu(NULL)
		{
		}
	} DragMenuData;
	
	DragMenuData m_SrcData, m_DstData;

	CMenuDropTargetWindowImpl() : m_hDDMenu(NULL)
	{
	}

	void SetTargetMenu(HMENU hMenu)
	{
		m_hDDMenu = hMenu;
		MENUINFO info = { sizeof(MENUINFO) };
		info.fMask = MIM_STYLE|MIM_APPLYTOSUBMENUS;
		info.dwStyle = MNS_DRAGDROP;

		HINSTANCE hInst = ::LoadLibrary(_T("user32.dll"));
		if(!hInst) return;
		LPFNSETMENUINFO lpfnSetMenuInfo = (LPFNSETMENUINFO)::GetProcAddress(hInst,_T("SetMenuInfo"));
		if(lpfnSetMenuInfo){
			lpfnSetMenuInfo(hMenu,&info);
			HMENU hSubMenu = ::GetSubMenu(hMenu,2);
			if(hSubMenu){
				info.dwStyle = 0;
				lpfnSetMenuInfo(hSubMenu,&info);
			}
		}
		::FreeLibrary(hInst);
	}

	BEGIN_MSG_MAP(CMenuDropTargetWindowImpl)
		MESSAGE_HANDLER(WM_CREATE,OnCreate)
		MESSAGE_HANDLER(WM_DESTROY,OnDestroy)
		MESSAGE_HANDLER(WM_MENUDRAG, OnMenuDrag)
		MESSAGE_HANDLER(WM_MENUGETOBJECT, OnMenuGetObject)
	END_MSG_MAP()

	DROPEFFECT OnDragEnter(IDataObject* pDataObject, DWORD dwKeyState, CPoint point)
	{
		m_bDragAccept = _MtlIsHlinkDataObject(pDataObject);
		return _MtlStandardDropEffect(dwKeyState);
	}
	DROPEFFECT OnDragOver(IDataObject* pDataObject, DWORD dwKeyState, CPoint point, DROPEFFECT dropOkEffect)
	{
		if (!m_bDragAccept)
			return DROPEFFECT_NONE;

		return _MtlStandardDropEffect(dwKeyState) | _MtlFollowDropEffect(dropOkEffect) | DROPEFFECT_COPY;
	}
	DROPEFFECT OnDrop(IDataObject* pDataObject,	DROPEFFECT dropEffect,
		DROPEFFECT dropEffectList, CPoint point)
	{

		CString strText;
		if ( MtlGetHGlobalText(pDataObject, strText) ||
			 MtlGetHGlobalText(pDataObject, strText, ::RegisterClipboardFormat(CFSTR_SHELLURL)) )
		{
			//�h���b�v����
			
			MoveItemOrder(); //���j���[���ڂ̈ړ�
			//CString strMsg;
			//strMsg.Format("[Dropped] src: %d , dst: %d , dir=%d\r\n",m_SrcData.nPos,m_DstData.nPos,m_DstData.nDir);
			//CDebugWindow::OutPutString(strMsg);
			
			return DROPEFFECT_NONE;
		}

		return DROPEFFECT_NONE;
	}

	LRESULT OnCreate(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
	{
		RegisterDragDrop();
		return 0;
	}

	LRESULT OnDestroy(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
	{
		RevokeDragDrop();
		return 0;
	}

	LRESULT OnMenuDrag(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
	{
		if(!_check_flag(CFavoritesMenuOption::GetStyle(),EMS_CUSTOMIZE_ORDER))
			return MND_ENDMENU;

		int nPos = (int)wParam;
		
		CComPtr<IDataObject> spDataObject;

		HRESULT hr = CHlinkDataObject::_CreatorClass::CreateInstance(NULL, IID_IDataObject, (void**)&spDataObject);
		if(FAILED(hr)) return MND_CONTINUE;

		CHlinkDataObject* pHlinkDataObject = NULL;	//�����[�X�̕K�v�Ȃ�
		hr = spDataObject->QueryInterface(IID_NULL, (void**)&pHlinkDataObject);
		if(FAILED(hr)) return MND_CONTINUE;

		HMENU hMenu = (HMENU)lParam;
		MENUITEMINFO mii = { sizeof(MENUITEMINFO) };
		mii.fMask = MIIM_DATA;
		if(!::GetMenuItemInfo(hMenu,nPos,TRUE,&mii)) return MND_CONTINUE;
		CMenuItem *pmi = (CMenuItem*)mii.dwItemData;
		if(!pmi) return MND_CONTINUE;
		CString strFileName = pmi->m_strText;
		CString strUrl = pmi->m_strPath;
		MtlParseIntenetShortcutFile(strUrl);

		pHlinkDataObject->m_arrNameAndUrl.Add(std::make_pair(strFileName,strUrl));

		if(PreDoDragDrop(m_hWnd) && CheckFolder(pmi->m_strPath)){
			//�ʒu�i���j��ۑ�
			HMENU hMenu = (HMENU)lParam;
			int nOffSet;
			if(!GetPosOffset(hMenu,nOffSet)) return MND_CONTINUE;
			m_SrcData.nPos = nPos;
			m_SrcData.dwPos = nPos - nOffSet;
			m_SrcData.hMenu = hMenu;
			m_SrcData.strFilePath = pmi->m_strPath;
			MtlRemoveTrailingBackSlash(m_SrcData.strFilePath);
			//�h���b�O�J�n
			DROPEFFECT dropEffect = DoDragDrop(spDataObject, DROPEFFECT_MOVE|DROPEFFECT_COPY|DROPEFFECT_LINK);
			if(dropEffect != DROPEFFECT_NONE)
				return MND_ENDMENU;
		}
		return MND_CONTINUE;
	}

	BOOL CheckFolder(CString strDirPath)
	{
		//���[�U�[��`�̏ꍇ�͓����Ȃ�
		if(_check_flag(CFavoritesMenuOption::s_dwStyle,EMS_USER_DEFINED_FOLDER))
			return FALSE;

		//���C�ɓ���t�H���_�ȉ��łȂ��ꍇ�������Ȃ�
		CString strFavRoot;
		if(!MtlGetFavoritesFolder(strFavRoot)) 
			return FALSE;

		if(strDirPath.Find(strFavRoot) == -1)
			return FALSE;

		//IE�̕��я��łȂ��ꍇ�������Ȃ�
		if(!_check_flag(CFavoritesMenuOption::s_dwStyle,EMS_ORDER_FAVORITES))
			return FALSE;

		return TRUE;
	}

	LRESULT OnMenuGetObject(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
	{
		MENUGETOBJECTINFO *pInfo = (MENUGETOBJECTINFO *)lParam;
		int nPosOffset = 0;
		//pInfo��dwFlags��MNGOF_CENTERCGAP(0)�̂Ƃ��̓��j���[�̒������ɃJ�[�\�������邱�Ƃ��Ӗ����邪
		//����ȊO�̎��̓��j���[�̏㕔�ɂ��邱�Ƃ������BMSDN�ɂ͗�ɂ���ĉR�������Ă���B

		if(CheckMenuPosition(pInfo->hmenu,pInfo->uPos) 
				&& pInfo->hmenu == m_SrcData.hMenu){ //�܂��t�H���_�Ԉړ��̓T�|�[�g���Ȃ�
			CComPtr<IDropTarget> pTarget;
			_LocDTQueryInterface(IID_IDropTarget,(void**)&pTarget);
			if(!pTarget) return MNGO_NOINTERFACE;


			//CString strMsg;
			//strMsg.Format("[GetObject] dst %d , dir = %d\r\n",pInfo->uPos, pInfo->dwFlags);
			//CDebugWindow::OutPutString(strMsg);
			//�������g�͎󂯕t���Ȃ�
			if(pInfo->uPos == m_SrcData.nPos && m_SrcData.hMenu == pInfo->hmenu)
				return MNGO_NOINTERFACE;
			if(pInfo->uPos == m_SrcData.nPos + 1 && pInfo->dwFlags != MNGOF_CENTERGAP)
				return MNGO_NOINTERFACE;
			if(pInfo->dwFlags != MNGOF_CENTERGAP){
				if(m_SrcData.nPos < (int)pInfo->uPos) pInfo->uPos--;
			}

			//�ʒu�i��j��ۑ�
			int nOffSet;
			if(!GetPosOffset(pInfo->hmenu,nOffSet)) return MNGO_NOINTERFACE;
			if((int)pInfo->uPos - nOffSet < 0) pInfo->uPos++;
			m_DstData.nPos = pInfo->uPos;
			m_DstData.dwPos = pInfo->uPos - nOffSet;
			m_DstData.hMenu = pInfo->hmenu;
			CMenuItem *pItem = GetMenuData(pInfo->hmenu,pInfo->uPos);
			if(pItem)	m_DstData.strFilePath = pItem->m_strPath;
			else		m_DstData.strFilePath = _T("");
			m_DstData.nDir = pInfo->dwFlags;
			if(::GetMenuItemCount(pInfo->hmenu) == pInfo->uPos){
				m_DstData.bBottom = TRUE;
				m_DstData.strFilePath = MtlGetDirectoryPath(GetDirPathForBottom(pInfo->hmenu,pInfo->uPos));
				//MtlMakeSureTrailingBackSlash(m_DstData.strFilePath);
			}else{
				m_DstData.bBottom = FALSE;
			}
			MtlRemoveTrailingBackSlash(m_DstData.strFilePath);
			
			pInfo->pvObj = pTarget;
			return MNGO_NOERROR;
		}
		return MNGO_NOINTERFACE;
	}

	CString GetDirPathForBottom(HMENU hMenu, UINT uPos)
	{
		MENUITEMINFO mii = { sizeof(MENUITEMINFO) };
		mii.fMask = MIIM_DATA;
		for(int i=uPos-1; i>=0; i--){
			if(!::GetMenuItemInfo(hMenu,i,TRUE,&mii)) return _T("");
			CMenuItem *pItem = (CMenuItem*)mii.dwItemData;
			if(pItem)
				return pItem->m_strPath;
		}
		return _T("");
	}

	CMenuItem *GetMenuData(HMENU hMenu, UINT uPos)
	{
		MENUITEMINFO mii = { sizeof(MENUITEMINFO) };
		mii.fMask = MIIM_TYPE|MIIM_DATA;
		if(!::GetMenuItemInfo(hMenu,uPos,TRUE,&mii))
			return NULL;
		return (CMenuItem*)mii.dwItemData;
	}

	BOOL GetPosOffset(HMENU hMenu, int& nPosOffset)
	{
		MENUITEMINFO mii = { sizeof(MENUITEMINFO) };
		mii.fMask = MIIM_TYPE|MIIM_DATA;
		int nCount = ::GetMenuItemCount(hMenu);

		for(int i=0; i<nCount; i++){
			if(!::GetMenuItemInfo(hMenu,i,TRUE,&mii)) return FALSE;
			CMenuItem *pItem = (CMenuItem*)mii.dwItemData;
			if(pItem){
				nPosOffset = i;
				return TRUE;
			}
		}
		return FALSE;
	}

	BOOL CheckMenuPosition(HMENU hMenu, UINT uPos)
	{
		MENUITEMINFO mii = { sizeof(MENUITEMINFO) };
		mii.fMask = MIIM_TYPE|MIIM_DATA;
		int nCount = ::GetMenuItemCount(hMenu);
		if(nCount == uPos) return TRUE;

		//uPos�Ԗڂ̍��ڂ��`�F�b�N:�Z�p���[�^�����ɂ���ꍇ��FALSE;
		if(!::GetMenuItemInfo(hMenu,uPos,TRUE,&mii)) return FALSE;
		CMenuItem *pItem = (CMenuItem*)mii.dwItemData;
		if(!pItem || mii.fType == MFT_SEPARATOR /*|| !MtlIsInternetFile(pItem->m_strPath)*/) return FALSE;
		return TRUE;
	}

	void MoveItemOrder()
	{
		CString strSrcDir = MtlGetDirectoryPath(m_SrcData.strFilePath);
		CString strDstDir = MtlGetDirectoryPath(m_DstData.strFilePath);

		//if(strSrcDir == strDstDir){
		if(m_SrcData.hMenu == m_DstData.hMenu){
			//���f�B���N�g�����ړ�
			CFavoriteOrderHandler order;
			order.ReadData(strSrcDir);
			//�f�[�^�̃`�F�b�N:������΍č\�z�����āA���������؂�m�F����
			if(GetOrderItemIndex(order,m_SrcData) == -1) return;
			if(!m_DstData.bBottom && GetOrderItemIndex(order,m_DstData) == -1) return;
			//�ړ����ĕۑ�
			if(m_DstData.bBottom) m_DstData.dwPos--;
			order.MoveData(m_SrcData.dwPos,m_DstData.dwPos);
			order.SaveData();

			//���\�����Ă��郁�j���[���̂̕��בւ�
			if(m_DstData.bBottom) m_DstData.nPos--;
			MoveMenuItems(m_SrcData.hMenu,m_SrcData.nPos,m_DstData.nPos);
			::InvalidateRect((HWND)m_DstData.hMenu,NULL,TRUE);
			::DrawMenuBar(GetParent());
			

		}else{
			//�قȂ�f�B���N�g���Ԃ̈ړ�

		}
	}

	int GetOrderItemIndex(CFavoriteOrderHandler& order,DragMenuData& data)
	{
		int nIndex;
		int dwPosition = data.dwPos;
		nIndex = order.FindPosition(dwPosition);
		if(nIndex == -1){
			order.ReConstructData(order.m_strDirPath);
			nIndex = order.FindPosition(dwPosition);
			if(nIndex == -1){
				nIndex = order.FindName(data.strFilePath);
				if(nIndex == -1)
					return -1;
				//�f�[�^����ꂿ����Ă�̂ŕ�C
				order.m_aryData[nIndex].dwPosition = dwPosition;
			}
		}
		return nIndex;
	}

	void MoveMenuItems(HMENU hMenu, int nSrcPos, int nDstPos)
	{
		if(nSrcPos == nDstPos) return;
		if(nSrcPos < 0 || nDstPos < 0 ) return;

		MENUITEMINFO mii = { sizeof(MENUITEMINFO) };
		TCHAR buf[MAX_PATH];
		mii.fMask = MIIM_TYPE|MIIM_STATE|MIIM_ID|MIIM_SUBMENU|MIIM_DATA;
		mii.dwTypeData = buf;
		mii.cch = MAX_PATH;
		::GetMenuItemInfo(hMenu,nSrcPos,TRUE,&mii);
		::RemoveMenu(hMenu,nSrcPos,MF_BYPOSITION);
		//if(nSrcPos < nDstPos) nDstPos--;
		::InsertMenuItem(hMenu,nDstPos,TRUE,&mii);

	}


};

class CMenuDropTargetWindow : public CMenuDropTargetWindowImpl<CMenuDropTargetWindow>
{
public:
	DECLARE_WND_SUPERCLASS(_T("Donut_MenuDDTarget"), GetWndClassName())
};

