#include "stdafx.h"
#include "DonutView.h"
#include "mshtmdid.h"
#include "option/DLControlOption.h"
#include "Donut.h"

// Constructor
CDonutView::CDonutView(DWORD dwDefaultDLControlFlags)
	: m_ViewOption(this), m_dwDefaultDLControlFlags(dwDefaultDLControlFlags),
		m_nDDCommand(0)
{
}

// Methods
DWORD CDonutView::GetDLControlFlags()
{
	DWORD dwDLControlFlags = DLCTL_DEFAULT;
	m_ExternalAmbientDispatch.get_DLControlFlags(&dwDLControlFlags);
	return dwDLControlFlags;
}

void CDonutView::PutDLControlFlags(DWORD dwDLControlFlags)
{
	m_ExternalAmbientDispatch.put_DLControlFlags(dwDLControlFlags);
}

void CDonutView::SetIeMenuNoCstm(int nStatus)
{
	m_ExternalUIDispatch.SetIEContextMenuCustom(!nStatus);
}

//�h���b�O�h���b�v���̑���𐧌䂷�邩IE�R���|�ɔC���邩
void CDonutView::SetOperateDragDrop(BOOL bOn, int nCommand)
{
	CComPtr<IAxWinHostWindow> spAxWindow;
	HRESULT hr = QueryHost(&spAxWindow);
	if(FAILED(hr))
		return;

	SetRegisterAsDropTarget(bOn ? true : false);
	if(bOn)
		m_ExternalUIDispatch.SetExternalDropTarget(this);
	else
		m_ExternalUIDispatch.SetExternalDropTarget(NULL);

	m_nDDCommand = nCommand;
}

// Overrides		
BOOL CDonutView::PreTranslateMessage(MSG* pMsg)
{
	if((pMsg->message < WM_KEYFIRST || pMsg->message > WM_KEYLAST) &&
		(pMsg->message < WM_MOUSEFIRST || pMsg->message > WM_MOUSELAST))
		return FALSE;

	// give HTML page a chance to translate this message
	return (BOOL)SendMessage(WM_FORWARDMSG, 0, (LPARAM)pMsg);
}


LRESULT CDonutView::OnMouseWheel(UINT fwKeys, short zDelta, CPoint point)
{
	SetMsgHandled(FALSE);
	return 1;
}

// UDT DGSTR
void CDonutView::OnMultiChg(WORD, WORD, HWND) 
{
	_ToggleFlag(ID_DLCTL_BGSOUNDS, DLCTL_BGSOUNDS);
	_ToggleFlag(ID_DLCTL_VIDEOS, DLCTL_VIDEOS);
	_ToggleFlag(ID_DLCTL_DLIMAGES, DLCTL_DLIMAGES);
	_LightRefresh();
}

void CDonutView::OnSecuChg(WORD, WORD, HWND) 
{
	_ToggleFlag(ID_DLCTL_SCRIPTS, DLCTL_NO_SCRIPTS,TRUE);
	_ToggleFlag(ID_DLCTL_JAVA, DLCTL_NO_JAVA, TRUE);
	_ToggleFlag(ID_DLCTL_DLACTIVEXCTLS, DLCTL_NO_DLACTIVEXCTLS, TRUE);
	_ToggleFlag(ID_DLCTL_RUNACTIVEXCTLS, DLCTL_NO_RUNACTIVEXCTLS, TRUE);
	_LightRefresh();
}

void CDonutView::OnAllOnOff(WORD /*wNotifyCode*/, WORD wID, HWND /*hWndCtl*/)
{
	switch(wID)
	{
	case ID_DLCTL_ON_OFF_MULTI:
		if ((GetDLControlFlags()&(DLCTL_DLIMAGES|DLCTL_BGSOUNDS|DLCTL_VIDEOS))==(DLCTL_DLIMAGES|DLCTL_BGSOUNDS|DLCTL_VIDEOS))
			_OffFlag(DLCTL_BGSOUNDS|DLCTL_VIDEOS|DLCTL_DLIMAGES);
		else
			_OnFlag(DLCTL_BGSOUNDS|DLCTL_VIDEOS|DLCTL_DLIMAGES);
		break;

	case ID_DLCTL_ON_OFF_SECU:
		if (((GetDLControlFlags()&(DLCTL_NO_RUNACTIVEXCTLS|DLCTL_NO_DLACTIVEXCTLS|DLCTL_NO_SCRIPTS|DLCTL_NO_JAVA))==0)){
			//�`�F�b�N�͑S�����Ă���
			_AddFlag(DLCTL_NO_SCRIPTS|DLCTL_NO_JAVA|DLCTL_NO_DLACTIVEXCTLS|DLCTL_NO_RUNACTIVEXCTLS);
			//_OnFlag(DLCTL_NO_SCRIPTS|DLCTL_NO_JAVA|DLCTL_NO_DLACTIVEXCTLS|DLCTL_NO_RUNACTIVEXCTLS);
		}else{
			//�`�F�b�N����Ă��Ȃ����ڂ�����
			_RemoveFlag(DLCTL_NO_SCRIPTS|DLCTL_NO_JAVA|DLCTL_NO_DLACTIVEXCTLS|DLCTL_NO_RUNACTIVEXCTLS);
			//_OffFlag(DLCTL_NO_SCRIPTS|DLCTL_NO_JAVA|DLCTL_NO_DLACTIVEXCTLS|DLCTL_NO_RUNACTIVEXCTLS);
		}
		break;
	}
	_LightRefresh();
}


LRESULT CDonutView::OnCreate(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL&)
{
	ATLTRACE2(atlTraceGeneral, 4, _T("CDonutView::OnCreate in\n"));
	// Let me initialize itself
	LRESULT lRet = DefWindowProc(uMsg, wParam, lParam);

	HRESULT hr = QueryControl(IID_IWebBrowser2, (void**)&m_spBrowser);
	if (FAILED(hr)) {
		ATLTRACE2(atlTraceGeneral, 4, _T(" failed to get IWebBrowser2\n"));
		return lRet;
	}

	BOOL bCheck = GetRegisterAsDropTarget();

	// Set flat scrollbar style
	CComPtr<IAxWinHostWindow> spAxWindow;
	hr = QueryHost(&spAxWindow);
	if (FAILED(hr))
		return lRet;
	m_spAxAmbient = spAxWindow;
	if (!m_spAxAmbient)
		return lRet;
	hr = m_spAxAmbient->put_DocHostFlags(_bFlatScrBar ? docHostUIFlagNotFlatScrBar : docHostUIFlagDEFAULT); // UDT DGSTR ( added by dai
	if (FAILED(hr)) {
		ATLTRACE2(atlTraceGeneral, 4, _T(" failed to put_DocHostFlags\n"));
		return lRet;
	}

	//�O��UI��IDispatch�C���^�[�t�F�C�X��ݒ肷��
	CComQIPtr<IDocHostUIHandler> pDefaultHandler = spAxWindow;
	m_ExternalUIDispatch.SetDefaultUIHandler(pDefaultHandler);
	spAxWindow->SetExternalUIHandler(&m_ExternalUIDispatch);

	//�O���A���r�G���gIDispatch�C���^�[�t�F�C�X��ݒ肷��
	CComQIPtr<IAxWinAmbientDispatchEx> pAmbient = spAxWindow;
	m_ExternalAmbientDispatch.SetHostWindow(spAxWindow);
	pAmbient->SetAmbientDispatch(&m_ExternalAmbientDispatch);

	_InitDLControlFlags();
	
	ATLASSERT(m_ViewOption.m_dwExStyle == 0);
	m_ViewOption.m_dwExStyle = _dwViewStyle;

	ATLTRACE2(atlTraceGeneral, 4, _T("CDonutView::OnCreate out\n"));
	return lRet;
}

void CDonutView::OnDestroy()
{
	SetMsgHandled(FALSE);

	m_ViewOption.Uninit();
}

void CDonutView::OnMultiBgsounds(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/)
{
	_ToggleFlag(ID_DLCTL_BGSOUNDS, DLCTL_BGSOUNDS);
	_LightRefresh();
}

void CDonutView::OnMultiVideos(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/)
{
	_ToggleFlag(ID_DLCTL_VIDEOS, DLCTL_VIDEOS);
	_LightRefresh();
}

void CDonutView::OnMultiDlImages(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/)
{
	ATLTRACE2(atlTraceGeneral, 4, _T("CDonutView::OnMultiDlImages\n"));
	if (_ToggleFlag(ID_DLCTL_DLIMAGES, DLCTL_DLIMAGES))
		_LightRefresh();
}

void CDonutView::OnSecurRunactivexctls(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/)
{
	_ToggleFlag(ID_DLCTL_RUNACTIVEXCTLS, DLCTL_NO_RUNACTIVEXCTLS, TRUE);
	_LightRefresh();
}

void CDonutView::OnSecurDlactivexctls(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/)
{
	if (!_ToggleFlag(ID_DLCTL_DLACTIVEXCTLS, DLCTL_NO_DLACTIVEXCTLS, TRUE))
		_LightRefresh();
}

void CDonutView::OnSecurScritps(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/)
{
	_ToggleFlag(ID_DLCTL_SCRIPTS, DLCTL_NO_SCRIPTS, TRUE);
	_LightRefresh();
}

void CDonutView::OnSecurJava(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/)
{
	_ToggleFlag(ID_DLCTL_JAVA, DLCTL_NO_JAVA, TRUE);
	_LightRefresh();
}

void CDonutView::_InitDLControlFlags()
{
	m_ExternalAmbientDispatch.put_DLControlFlags(m_dwDefaultDLControlFlags);
}

DWORD CDonutView::_GetDLControlFlags()
{
	DWORD dwDLControlFlags = DLCTL_DEFAULT;
	if (m_spAxAmbient)
		m_ExternalAmbientDispatch.get_DLControlFlags(&dwDLControlFlags);
	return dwDLControlFlags;
}

// Implementation
void CDonutView::_OnFlag(DWORD dwFlag)
{
	DWORD dwDLControlFlags = DLCTL_DEFAULT;
	m_ExternalAmbientDispatch.get_DLControlFlags(&dwDLControlFlags);

	if ((dwDLControlFlags&dwFlag)!=dwFlag)
		dwDLControlFlags |= dwFlag;

	m_ExternalAmbientDispatch.put_DLControlFlags(dwDLControlFlags);
}

void CDonutView::_OffFlag(DWORD dwFlag)
{
	DWORD dwDLControlFlags = DLCTL_DEFAULT;
	m_ExternalAmbientDispatch.get_DLControlFlags(&dwDLControlFlags);

	if ((dwDLControlFlags&dwFlag)==dwFlag)
		dwDLControlFlags &= ~dwFlag;

	m_ExternalAmbientDispatch.put_DLControlFlags(dwDLControlFlags);
}

bool CDonutView::_ToggleFlag(WORD wID, DWORD dwFlag, BOOL bReverse)
{
	bool bRet = false;
	DWORD dwDLControlFlags = DLCTL_DEFAULT;
	m_ExternalAmbientDispatch.get_DLControlFlags(&dwDLControlFlags);

	if (dwDLControlFlags & dwFlag) {
		dwDLControlFlags &= ~dwFlag;
	}
	else {
		dwDLControlFlags |= dwFlag;
		bRet = true;
	}

	m_ExternalAmbientDispatch.put_DLControlFlags(dwDLControlFlags);
	return bRet;
}

void CDonutView::_LightRefresh()
{
	if (::GetKeyState(VK_CONTROL) < 0)
		return;

	CString strURL = GetLocationURL();
	Navigate2(strURL);
}

void CDonutView::_AddFlag(DWORD dwFlag)	//minit
{
	DWORD dwDLControlFlags = DLCTL_DEFAULT;
	m_ExternalAmbientDispatch.get_DLControlFlags(&dwDLControlFlags);

	dwDLControlFlags |= dwFlag;

	m_ExternalAmbientDispatch.put_DLControlFlags(dwDLControlFlags);
}
void CDonutView::_RemoveFlag(DWORD dwFlag)	//minit
{
	DWORD dwDLControlFlags = DLCTL_DEFAULT;
	m_ExternalAmbientDispatch.get_DLControlFlags(&dwDLControlFlags);

	dwDLControlFlags &= ~dwFlag;

	m_ExternalAmbientDispatch.put_DLControlFlags(dwDLControlFlags);
}

void CDonutView::OnUpdateDLCTL_ChgMulti(CCmdUI* pCmdUI)
{
	if (pCmdUI->m_menuSub.m_hMenu) {// popup menu
		pCmdUI->m_menu.EnableMenuItem(pCmdUI->m_nIndex, MF_BYPOSITION | MF_ENABLED);
	}
	else {
		pCmdUI->Enable();
		pCmdUI->SetCheck(((GetDLControlFlags()&(DLCTL_DLIMAGES|DLCTL_BGSOUNDS|DLCTL_VIDEOS))==(DLCTL_DLIMAGES|DLCTL_BGSOUNDS|DLCTL_VIDEOS)) ? 1 : 0);
	}
}

void CDonutView::OnUpdateDLCTL_ChgSecu(CCmdUI* pCmdUI)
{
	if (pCmdUI->m_menuSub.m_hMenu) {// popup menu
		pCmdUI->m_menu.EnableMenuItem(pCmdUI->m_nIndex, MF_BYPOSITION | MF_ENABLED);
	}
	else {
		pCmdUI->Enable();
		BOOL bSts = TRUE;
		if (GetDLControlFlags()&DLCTL_NO_RUNACTIVEXCTLS) bSts = FALSE;
		if (GetDLControlFlags()&DLCTL_NO_DLACTIVEXCTLS) bSts = FALSE;
		if (GetDLControlFlags()&DLCTL_NO_SCRIPTS) bSts = FALSE;
		if (GetDLControlFlags()&DLCTL_NO_JAVA) bSts = FALSE;
		pCmdUI->SetCheck(bSts);
	}
}

void CDonutView::OnUpdateDLCTL_DLIMAGES(CCmdUI* pCmdUI)
{
	if (pCmdUI->m_menuSub.m_hMenu) {// popup menu
		pCmdUI->m_menu.EnableMenuItem(pCmdUI->m_nIndex, MF_BYPOSITION | MF_ENABLED);
	}
	else {
		pCmdUI->Enable();
		pCmdUI->SetCheck(GetDLControlFlags() & DLCTL_DLIMAGES ? 1 : 0);
	}
}

void CDonutView::OnUpdateDLCTL_RUNACTIVEXCTLS(CCmdUI* pCmdUI)
{
	if (pCmdUI->m_menuSub.m_hMenu) {// popup menu
		pCmdUI->m_menu.EnableMenuItem(pCmdUI->m_nIndex, MF_BYPOSITION | MF_ENABLED);
	}
	else {
		pCmdUI->Enable();
		pCmdUI->SetCheck(GetDLControlFlags() & DLCTL_NO_RUNACTIVEXCTLS ? 0 : 1);
	}
}

void CDonutView::OnUpdateDocHostUIOpenNewWinUI(CCmdUI* pCmdUI)
{
	DWORD dwDocHostFlags;
	m_spAxAmbient->get_DocHostFlags(&dwDocHostFlags);
	pCmdUI->Enable();
	pCmdUI->SetCheck(dwDocHostFlags & docHostUIFlagOPENNEWWIN ? 1 : 0);
}

bool CDonutView::OnScroll(UINT nScrollCode, UINT nPos, bool bDoScroll)
{
	return false;
}

// Overrides
/*
STDMETHOD(GetDropTarget)(IUnknown  *pDropTarget, IUnknown  **ppDropTarget)
{
	*ppDropTarget = (IUnknown*)(_IDropTargetLocator*)this;
	return S_OK;
}
DROPEFFECT OnDragEnter(IDataObject* pDataObject, DWORD dwKeyState, CPoint point)
{
	return _MtlStandardDropEffect(dwKeyState);
}
DROPEFFECT OnDragOver(IDataObject* pDataObject, DWORD dwKeyState, CPoint point, DROPEFFECT dropOkEffect)
//DROPEFFECT OnDragOver(IDataObject* pDataObject, DWORD dwKeyState, CPoint point)
{
	return DROPEFFECT_LINK | _MtlStandardDropEffect(dwKeyState);
}
DROPEFFECT OnDrop(IDataObject* pDataObject,	DROPEFFECT dropEffect,
	DROPEFFECT dropEffectList, CPoint point)
{
	return DROPEFFECT_NONE;
}
void OnDragLeave()
{
}
*/
HRESULT STDMETHODCALLTYPE CDonutView::GetHostInfo(DWORD  *pdwFlags,DWORD  *pdwDoubleClick)
{
	m_spAxAmbient->get_DocHostFlags(pdwFlags);
	m_spAxAmbient->get_DocHostDoubleClickFlags(pdwDoubleClick);
	return S_OK;
}

HRESULT STDMETHODCALLTYPE CDonutView::GetDropTarget(IUnknown  *pDropTarget, IUnknown  **ppDropTarget)
{
	*ppDropTarget = (IUnknown*)(_IDropTargetLocator*)this;
	return S_OK;
}

void CDonutView::OnDragLeave()
{
	//_DrawDragEffect(true);
}

void CDonutView::_DrawDragEffect(bool bRemove)
{
	CClientDC dc(m_hWnd);

	CRect rect;
	GetClientRect(rect);

	if (bRemove)
		MtlDrawDragRectFixed(dc.m_hDC, &rect, CSize(0, 0), &rect, CSize(2, 2), NULL, NULL);
	else
		MtlDrawDragRectFixed(dc.m_hDC, &rect, CSize(2, 2), NULL, CSize(2, 2),	NULL, NULL);
}

DROPEFFECT CDonutView::OnDrop(IDataObject* pDataObject,	DROPEFFECT dropEffect,
	DROPEFFECT dropEffectList, CPoint point)
{
	//_DrawDragEffect(true);

	CString strText;

	CSimpleArray<CString> arrFiles;
	if (MtlGetDropFileName(pDataObject, arrFiles)) {
		if (arrFiles.GetSize() == 1) {
			DonutOpenFile(m_hWnd, arrFiles[0], DonutGetStdOpenFlag());
			return DROPEFFECT_COPY;
		}

		for (int i = 0; i < arrFiles.GetSize(); ++i) {
			DonutOpenFile(m_hWnd, arrFiles[i]);
		}
		dropEffect = DROPEFFECT_COPY;
		return DROPEFFECT_COPY;
	}

	if (MtlGetHGlobalText(pDataObject, strText) ||	MtlGetHGlobalText(pDataObject, strText, ::RegisterClipboardFormat(CFSTR_SHELLURL)))
	{
		::SendMessage(GetTopLevelParent(),WM_COMMAND_DIRECT,m_nDDCommand,(LPARAM)(LPCTSTR)strText);
		return DROPEFFECT_NONE;
	}else{
		return CDonutViewFileDropTarget<CDonutView>::OnDrop(pDataObject,dropEffect,dropEffectList,point);
	}

	return DROPEFFECT_NONE;
}

