#pragma once

#include "MtlUpdateCmdUI.h"
#include "option/DLControlOption.h"
#include "resource.h"

#define DVS_AUTOREFRESH_15SEC	0x00000001L
#define DVS_AUTOREFRESH_30SEC	0x00000002L
#define DVS_AUTOREFRESH_1MIN	0x00000004L
#define DVS_AUTOREFRESH_2MIN	0x00000008L
#define DVS_AUTOREFRESH_5MIN	0x00000010L
#define DVS_AUTOREFRESH_USER	0x00000020L // UDT DGSTR ( dai

#define DVS_AUTOREFRESH_OR	(DVS_AUTOREFRESH_15SEC|DVS_AUTOREFRESH_30SEC|DVS_AUTOREFRESH_1MIN|DVS_AUTOREFRESH_2MIN|DVS_AUTOREFRESH_5MIN|DVS_AUTOREFRESH_USER)

//#define DVS_EX_OPENNEWWIN		0x00000001L
//#define DVS_EX_MESSAGE_FILTER	0x00000002L

template <class _DonutView>
class CDonutViewOption
{
public:
	DWORD m_dwAutoRefreshStyle;
	DWORD m_dwExStyle;
	CString m_strURL;

	_DonutView* __m_pDonutView;
	UINT m_nIDEvent;

	CDonutViewOption(_DonutView* __pDonutView);

	void Init();
	void Uninit();

	void SetAutoRefreshStyle(DWORD dwStyle);

// Message map and handlers
	BEGIN_MSG_MAP(CDonutViewOption)
		COMMAND_ID_HANDLER_EX(ID_AUTOREFRESH_NONE, OnAutoRefreshNone)
		COMMAND_ID_HANDLER_EX(ID_AUTOREFRESH_15SEC, OnAutoRefresh15sec)
		COMMAND_ID_HANDLER_EX(ID_AUTOREFRESH_30SEC, OnAutoRefresh30sec)
		COMMAND_ID_HANDLER_EX(ID_AUTOREFRESH_1MIN, OnAutoRefresh1min)
		COMMAND_ID_HANDLER_EX(ID_AUTOREFRESH_2MIN, OnAutoRefresh2min)
		COMMAND_ID_HANDLER_EX(ID_AUTOREFRESH_5MIN, OnAutoRefresh5min)
		COMMAND_ID_HANDLER_EX(ID_AUTOREFRESH_USER, OnAutoRefreshUser) // UDT DGSTR ( dai

//		COMMAND_ID_HANDLER_EX(ID_DOCHOSTUI_OPENNEWWIN, OnDocHostUIOpenNewWin)

		// UH
		COMMAND_ID_HANDLER_EX(ID_MESSAGE_FILTER, OnMessageFilter)
		COMMAND_ID_HANDLER_EX(ID_MOUSE_GESTURE, OnMouseGesture)
		COMMAND_ID_HANDLER_EX(ID_BLOCK_MAILTO, OnBlockMailto)

		MSG_WM_TIMER(OnTimer)
	END_MSG_MAP()

	void OnBlockMailto(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/);
	void OnMouseGesture(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/);
	void OnMessageFilter(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/);
	void OnDocHostUIOpenNewWin(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/);
	void OnAutoRefreshNone(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/);
	void OnAutoRefresh15sec(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/);
	void OnAutoRefresh30sec(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/);
	void OnAutoRefresh1min(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/);
	void OnAutoRefresh2min(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/);
	void OnAutoRefresh5min(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/);

	// UDT DGSTR ( dai
	void OnAutoRefreshUser(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/);
	// ENDE

	void OnTimer(UINT wTimerID, TIMERPROC);
	int _GetElapse();
	void _KillTimer();
	void _SetTimer();

	void WriteProfile(const CString& strFileName, int nIndex);
	void _WriteProfile(const CString& strFileName, LPCTSTR lpstrSection, BOOL bSaveFB = FALSE);
	void GetProfile(const CString& strFileName, int nIndex, bool bGetChildFrameState);
	void _GetProfile(const CString& strFileName, CString& strSection, bool bGetChildFrameState);

// Update command UI and handlers
	BEGIN_UPDATE_COMMAND_UI_MAP(CDonutViewOption)
		UPDATE_COMMAND_UI(ID_AUTOREFRESH_USER, OnUpdateAutoRefreshUser)	// UDT DGSTR ( dai
		UPDATE_COMMAND_UI_SETCHECK_IF_PASS(ID_AUTOREFRESH_NONE, m_dwAutoRefreshStyle == 0)
		UPDATE_COMMAND_UI_SETCHECK_FLAG(ID_AUTOREFRESH_15SEC, DVS_AUTOREFRESH_15SEC, m_dwAutoRefreshStyle)
		UPDATE_COMMAND_UI_SETCHECK_FLAG(ID_AUTOREFRESH_30SEC, DVS_AUTOREFRESH_30SEC, m_dwAutoRefreshStyle)
		UPDATE_COMMAND_UI_SETCHECK_FLAG(ID_AUTOREFRESH_1MIN, DVS_AUTOREFRESH_1MIN, m_dwAutoRefreshStyle)
		UPDATE_COMMAND_UI_SETCHECK_FLAG(ID_AUTOREFRESH_2MIN, DVS_AUTOREFRESH_2MIN, m_dwAutoRefreshStyle)
		UPDATE_COMMAND_UI_SETCHECK_FLAG(ID_AUTOREFRESH_5MIN, DVS_AUTOREFRESH_5MIN, m_dwAutoRefreshStyle)
		UPDATE_COMMAND_UI_ENABLE_SETCHECK_FLAG(ID_DOCHOSTUI_OPENNEWWIN, DVS_EX_OPENNEWWIN, m_dwExStyle)

		// UH
		UPDATE_COMMAND_UI_SETCHECK_IF_PASS(ID_AUTO_REFRESH, m_dwAutoRefreshStyle!=0)
		UPDATE_COMMAND_UI_ENABLE_SETCHECK_FLAG(ID_MESSAGE_FILTER, DVS_EX_MESSAGE_FILTER, m_dwExStyle)
		UPDATE_COMMAND_UI_ENABLE_SETCHECK_FLAG(ID_MOUSE_GESTURE, DVS_EX_MOUSE_GESTURE, m_dwExStyle)
		UPDATE_COMMAND_UI_ENABLE_SETCHECK_FLAG(ID_BLOCK_MAILTO, DVS_EX_BLOCK_MAILTO, m_dwExStyle)
	END_UPDATE_COMMAND_UI_MAP()

	// UDT DGSTR ( dai
	void OnUpdateAutoRefreshUser(CCmdUI* pCmdUI);
	// ENDE

	BOOL _Write_OptionalData(const CString& strFileName, CString& strSection);
	BOOL _OutPut_TravelLog(std::vector<std::pair<CString, CString> > &arrData, BOOL bFore);
	BOOL _Write_TravelLog(const CString& strFileName,const CString& strSection, std::vector<std::pair<CString, CString> > &arrData, BOOL bFore);
};

#define DONUTVIEWOPTION_CTOR() \
	template <class _DonutView> \
	CDonutViewOption<_DonutView>

#define DONUTVIEWOPTION(rettype) \
	template <class _DonutView> \
	rettype CDonutViewOption<_DonutView>

DONUTVIEWOPTION_CTOR()::CDonutViewOption(_DonutView* __pDonutView)
	: __m_pDonutView(__pDonutView), m_nIDEvent(0),
	  m_dwAutoRefreshStyle(0), m_dwExStyle(0)
{
	m_nIDEvent = 0;
}

DONUTVIEWOPTION(void)::Init()
{
	_SetTimer();
}

DONUTVIEWOPTION(void)::Uninit()
{
	_KillTimer();
}

DONUTVIEWOPTION(void)::SetAutoRefreshStyle(DWORD dwStyle)
{
	m_dwAutoRefreshStyle = 0;
	DWORD dwCurFlag = DVS_AUTOREFRESH_USER;
	while(dwCurFlag > 0){
		if(dwCurFlag & dwStyle){
			m_dwAutoRefreshStyle = dwCurFlag;
			break;
		}
		dwCurFlag >>= 1;
	}
	_KillTimer();
	_SetTimer();
}

DONUTVIEWOPTION(void)::OnBlockMailto(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/)
{
	if (m_dwExStyle&DVS_EX_BLOCK_MAILTO)
		m_dwExStyle &= ~DVS_EX_BLOCK_MAILTO;
	else
		m_dwExStyle |= DVS_EX_BLOCK_MAILTO;
}

DONUTVIEWOPTION(void)::OnMouseGesture(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/)
{
	if (m_dwExStyle&DVS_EX_MOUSE_GESTURE)
		m_dwExStyle &= ~DVS_EX_MOUSE_GESTURE;
	else
		m_dwExStyle |= DVS_EX_MOUSE_GESTURE;
}

DONUTVIEWOPTION(void)::OnMessageFilter(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/)
{
	if (m_dwExStyle&DVS_EX_MESSAGE_FILTER)
		m_dwExStyle &= ~DVS_EX_MESSAGE_FILTER;
	else
		m_dwExStyle |= DVS_EX_MESSAGE_FILTER;
}

DONUTVIEWOPTION(void)::OnDocHostUIOpenNewWin(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/)
{
	if (m_dwExStyle & DVS_EX_OPENNEWWIN)
		m_dwExStyle &= ~DVS_EX_OPENNEWWIN;
	else
		m_dwExStyle |= DVS_EX_OPENNEWWIN;
}

DONUTVIEWOPTION(void)::OnAutoRefreshNone(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/)
{
	m_dwAutoRefreshStyle = 0;
	_KillTimer();
}

DONUTVIEWOPTION(void)::OnAutoRefresh15sec(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/)
{
	m_dwAutoRefreshStyle = 0;
	m_dwAutoRefreshStyle |= DVS_AUTOREFRESH_15SEC;
	_KillTimer();
	_SetTimer();
}

DONUTVIEWOPTION(void)::OnAutoRefresh30sec(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/)
{
	m_dwAutoRefreshStyle = 0;
	m_dwAutoRefreshStyle |= DVS_AUTOREFRESH_30SEC;
	_KillTimer();
	_SetTimer();
}

DONUTVIEWOPTION(void)::OnAutoRefresh1min(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/)
{
	m_dwAutoRefreshStyle = 0;
	m_dwAutoRefreshStyle |= DVS_AUTOREFRESH_1MIN;
	_KillTimer();
	_SetTimer();
}

DONUTVIEWOPTION(void)::OnAutoRefresh2min(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/)
{
	m_dwAutoRefreshStyle = 0;
	m_dwAutoRefreshStyle |= DVS_AUTOREFRESH_2MIN;
	_KillTimer();
	_SetTimer();
}

DONUTVIEWOPTION(void)::OnAutoRefresh5min(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/)
{
	m_dwAutoRefreshStyle = 0;
	m_dwAutoRefreshStyle |= DVS_AUTOREFRESH_5MIN;
	_KillTimer();
	_SetTimer();
}

// UDT DGSTR ( dai
DONUTVIEWOPTION(void)::OnAutoRefreshUser(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/)
{
	m_dwAutoRefreshStyle = 0;
	m_dwAutoRefreshStyle |= DVS_AUTOREFRESH_USER;
	_KillTimer();
	_SetTimer();
}
// ENDE

DONUTVIEWOPTION(void)::OnTimer(UINT wTimerID, TIMERPROC)
{
	ATLTRACE2(atlTraceGeneral, 4, _T("CChildFrame::OnTimer\n"));
	if (wTimerID == m_nIDEvent)
		::PostMessage(__m_pDonutView->GetParent(), WM_COMMAND, (WPARAM)ID_VIEW_REFRESH, 0);
//			__m_pDonutView->m_spBrowser->Refresh();
	else
		SetMsgHandled(FALSE);
}

DONUTVIEWOPTION(int)::_GetElapse()
{
	if (m_dwAutoRefreshStyle == 0)
		return -1;
	else if (m_dwAutoRefreshStyle & DVS_AUTOREFRESH_15SEC)
		return 15*1000;
	else if (m_dwAutoRefreshStyle & DVS_AUTOREFRESH_30SEC)
		return 30*1000;
	else if (m_dwAutoRefreshStyle & DVS_AUTOREFRESH_1MIN)
		return 1*60*1000;
	else if (m_dwAutoRefreshStyle & DVS_AUTOREFRESH_2MIN)
		return 2*60*1000;
	else if (m_dwAutoRefreshStyle & DVS_AUTOREFRESH_5MIN)
		return 5*60*1000;
	// UDT DGSTR ( dai
	else if (m_dwAutoRefreshStyle & DVS_AUTOREFRESH_USER) 
		return CMainOption::s_dwAutoRefreshTime*1000;	  
	// ENDE

	return -1;
}

DONUTVIEWOPTION(void)::_KillTimer()
{
	if (m_nIDEvent != 0) {
		MTLVERIFY(::KillTimer(__m_pDonutView->m_hWnd, m_nIDEvent));
		m_nIDEvent = 0;
	}
}

DONUTVIEWOPTION(void)::_SetTimer()
{
	int nElapse = _GetElapse();
	if (nElapse != -1)
		m_nIDEvent = ::SetTimer(__m_pDonutView->m_hWnd, 1, _GetElapse(), NULL);
}

DONUTVIEWOPTION(void)::WriteProfile(const CString& strFileName, int nIndex)
{
	CString strSection;
	strSection.Format("Window%d",nIndex);
	_WriteProfile(strFileName, strSection);
}

DONUTVIEWOPTION(void)::_WriteProfile(const CString& strFileName, LPCTSTR lpstrSection, BOOL bSaveFB = FALSE)
{
	CIniSection pr;

	CString strSectionName = lpstrSection;
	pr.Open(strFileName, strSectionName);

	CComPtr<IHTMLDocument2> pDoc;
	__m_pDonutView->m_spBrowser->get_Document((IDispatch**)&pDoc);

	pr.SetValue(__m_pDonutView->GetLocationName(),_T("Title")); //minit
	pr.SetValue(__m_pDonutView->GetLocationURL(), _T("Location_URL"));
	pr.SetValue(__m_pDonutView->GetDLControlFlags(), _T("DL_Control_Flags"));
	pr.SetValue(m_dwAutoRefreshStyle, _T("Auto_Refresh_Style"));
	MtlWriteProfileChildFrameState(pr, __m_pDonutView->GetParent(), _T("child."));

	// save extended style
	pr.SetValue(m_dwExStyle, _T("Extended_Style"));

	// �i�ށE�߂闚����ۑ����� minit
	if(bSaveFB)
		_Write_OptionalData(strFileName,strSectionName);

	pr.Close();
}

DONUTVIEWOPTION(void)::GetProfile(const CString& strFileName, int nIndex, bool bGetChildFrameState)
{
	CString strSection;
	strSection.Format(_T("Window%d"),nIndex);
	_GetProfile(strFileName, strSection, bGetChildFrameState);
}

DONUTVIEWOPTION(void)::_GetProfile(const CString& strFileName, CString& strSection, bool bGetChildFrameState)
{
	CIniSection pr;

	CString strSectionName = strSection;
	//CString strSectionName = _T("Window");
	//strSectionName.Append(nIndex);
	pr.Open(strFileName, strSectionName);

	DWORD dwDLControlFlags = DLCTL_DEFAULT;
	if (pr.QueryValue(dwDLControlFlags, _T("DL_Control_Flags")) == ERROR_SUCCESS)
		__m_pDonutView->PutDLControlFlags(dwDLControlFlags);

	TCHAR sz[INTERNET_MAX_PATH_LENGTH];
	DWORD dwBytes = INTERNET_MAX_PATH_LENGTH;
	if (pr.QueryValue(sz, _T("Location_URL"), &dwBytes) == ERROR_SUCCESS) {
		// avoid endless loop
		CString strURL(sz);
		bool bMaybeEndless = (strURL == _T("javascript:location.reload()"));
		if (!bMaybeEndless)
			__m_pDonutView->Navigate2(sz);
	}

	pr.QueryValue(m_dwAutoRefreshStyle, _T("Auto_Refresh_Style"));
	_SetTimer();

	if (bGetChildFrameState)
		MtlGetProfileChildFrameState(pr, __m_pDonutView->GetParent(), SW_SHOWNORMAL, true, _T("child."));

	// load extended style
	pr.QueryValue(m_dwExStyle, _T("Extended_Style"));// never give up yeah.

	if (_check_flag(DVS_EX_OPENNEWWIN, m_dwExStyle)) {
		MtlSendOnCommand(__m_pDonutView->GetParent(), ID_DOCHOSTUI_OPENNEWWIN);
	}
	
	pr.Close();
}

// UDT DGSTR ( dai
DONUTVIEWOPTION(void)::OnUpdateAutoRefreshUser(CCmdUI* pCmdUI)
{ 
	DWORD dwRefreshTime = CMainOption::s_dwAutoRefreshTime;
	pCmdUI->Enable(!dwRefreshTime == 0 );
	pCmdUI->SetCheck(m_dwAutoRefreshStyle == DVS_AUTOREFRESH_USER ? 1 : 0);
	CString str;
	// NOTE: INUYA
	// if using StrFromTimeInterval , Load Shlwapi.dll...
	// dwRefreshTime is limited to 3599.
	if (dwRefreshTime %60 == 0)  	str.Format("%d��",dwRefreshTime/60);
	else if (dwRefreshTime >= 60)	str.Format("%d��%d�b", dwRefreshTime/60,dwRefreshTime%60);
	else							str.Format("%d�b",dwRefreshTime%60);
	str += "(���[�U�[�ݒ�)";
	pCmdUI->SetText(str);
}
// ENDE

DONUTVIEWOPTION(BOOL)::_Write_OptionalData(const CString& strFileName, CString& strSection) //minit
{
	std::vector<std::pair<CString, CString> > arrFore, arrBack;
	BOOL bRet1, bRet2;
	bRet1 = _OutPut_TravelLog(arrFore, TRUE);
	bRet2 = _OutPut_TravelLog(arrBack, FALSE);
	_Write_TravelLog(strFileName,strSection,arrFore,TRUE);
	_Write_TravelLog(strFileName,strSection,arrBack,FALSE);

	return (bRet1 && bRet2) ? TRUE : FALSE;
}

DONUTVIEWOPTION(BOOL)::_OutPut_TravelLog(std::vector<std::pair<CString, CString> > &arrData, BOOL bFore) //minit
{
	CIniSection pr;
	HRESULT hr;
	CComPtr<IWebBrowser2> pWB2;
	CComPtr<IServiceProvider> pISP;
	CComPtr<ITravelLogStg>    pTLStg;
	CComPtr<IEnumTravelLogEntry> pTLEnum;
	CString strDir;
	int nDir;

	strDir = bFore ? _T("Fore") : _T("Back");
	nDir   = bFore ? TLEF_RELATIVE_FORE : TLEF_RELATIVE_BACK;

	__m_pDonutView->QueryControl(IID_IWebBrowser2, (void**)&pWB2);
	if(pWB2 == NULL) return FALSE;
	hr = pWB2->QueryInterface(IID_IServiceProvider,(void**)&pISP);
	if(FAILED(hr) || pISP == NULL) return FALSE;
	hr = pISP->QueryService(SID_STravelLogCursor,IID_ITravelLogStg,(void**)&pTLStg);
	if(FAILED(hr) || pTLStg == NULL) return FALSE;
	hr = pTLStg->EnumEntries(nDir,&pTLEnum);
	if(FAILED(hr) || pTLEnum == NULL) return FALSE;

	int count = 0;
	while(1){
		CComPtr<ITravelLogEntry>  pTLEntry;
		LPOLESTR szURL, szTitle;

		hr = pTLEnum->Next(1, &pTLEntry, NULL);    
		if(FAILED(hr) || pTLEntry == NULL) break;

		if(SUCCEEDED(pTLEntry->GetTitle(&szTitle)) && szTitle &&
		   SUCCEEDED(pTLEntry->GetURL(&szURL)) && szURL)
		{
			CString strTitle(szTitle), strURL(szURL), strTmp;
			arrData.push_back(std::make_pair(strTitle,strURL));
			count++;
		}
		if (count>=10) break;
	}

	return TRUE;
}

DONUTVIEWOPTION(BOOL)::_Write_TravelLog(const CString& strFileName,const CString& strSection, std::vector<std::pair<CString, CString> > &arrData, BOOL bFore)
{
	CIniSection pr;
	pr.Open(strFileName, strSection);

	CString strDir = bFore ? "Fore" : "Back";

	for(int i=0; i<(int)arrData.size(); i++)
	{
		CString strTmp;
		strTmp.Format(_T("%s_Title%d"),strDir,i);
		pr.SetValue(arrData[i].first,strTmp);
		strTmp.Format(_T("%s_URL%d"),strDir,i);
		pr.SetValue(arrData[i].second,strTmp);
	}

	pr.Close();

	return TRUE;
}
