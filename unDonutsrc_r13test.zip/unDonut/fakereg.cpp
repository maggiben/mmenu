#include "stdafx.h"
#include "fakereg.h"

////////////////////////////////////////////////////////////////////////////////
//CFakeNode�̒�`
////////////////////////////////////////////////////////////////////////////////
CFakeNode::CFakeNode()
	: m_pData(NULL), m_dwDataLen(0)
{
}

CFakeNode::~CFakeNode()
{
	if(m_pData){
		Release();
	}
}

CFakeNode& CFakeNode::operator=(const CFakeNode& objSrc)
{
	m_bKey = objSrc.m_bKey;
	m_strName = objSrc.m_strName;
	
	m_pManager = objSrc.m_pManager;
	
	Release();
	m_dwDataLen = objSrc.m_dwDataLen;
	m_dwType = objSrc.m_dwType;
	if(objSrc.m_pData){
		m_pData = Alloc(m_dwDataLen);
		::CopyMemory(m_pData,objSrc.m_pData,m_dwDataLen);
	}
	return *this;
}

BYTE *CFakeNode::Alloc(DWORD dwSize)
{
	BYTE *pMem;
	try{
		pMem = new BYTE[dwSize];
	}catch(...){
		return NULL;
	}
	return pMem;
}

void CFakeNode::Release()
{
	if(m_pData){
		delete [] m_pData;
		m_pData = NULL;
		m_dwDataLen = 0;
		m_dwType = REG_NONE;
	}
}

bool CFakeNode::Write(FILE* fp)
{
	bool bRet;

	DWORD dwNodeType = m_bKey?1:0;
	bRet = fwrite(&dwNodeType,sizeof(DWORD),1,fp)==1;
	if(!bRet) return false;

	DWORD dwNameLen = m_strName.GetLength();
	bRet = fwrite(&dwNameLen,sizeof(DWORD),1,fp)==1;
	if(!bRet) return false;
	if(dwNameLen){
		bRet = fwrite((LPCTSTR)m_strName,sizeof(TCHAR),dwNameLen+1,fp)==dwNameLen+1;
		if(!bRet) return false;
	}

	bRet = fwrite(&m_dwDataLen,sizeof(DWORD),1,fp)==1;
	if(!bRet) return false;
	if(m_dwDataLen){
		bRet = fwrite(&m_dwType,sizeof(DWORD),1,fp)==1;
		if(!bRet) return false;
		bRet = fwrite(m_pData,1,m_dwDataLen,fp)==m_dwDataLen;
		if(!bRet) return false;
	}

	return true;
}

bool CFakeNode::Read(FILE* fp)
{
	if(m_pData){ //���Ƀf�[�^�����݂���̂ŉ������
		Release();
	}

	bool bRet;

	DWORD dwNodeType;
	bRet = fread(&dwNodeType,sizeof(DWORD),1,fp)==1;
	if(!bRet) return false;
	m_bKey = dwNodeType?true:false;

	DWORD dwNameLen;
	bRet = fread(&dwNameLen,sizeof(DWORD),1,fp)==1;
	if(!bRet) return false;
	if(dwNameLen){
		bRet = fread(m_strName.GetBuffer(dwNameLen+1),sizeof(TCHAR),dwNameLen+1,fp)==dwNameLen+1;
		if(!bRet) return false;
		m_strName.ReleaseBuffer();
	}else{
		m_strName.Empty();
	}

	bRet = fread(&m_dwDataLen,sizeof(DWORD),1,fp)==1;
	if(!bRet) return false;
	if(m_dwDataLen){
		bRet = fread(&m_dwType,sizeof(DWORD),1,fp)==1;
		if(!bRet) return false;
	
		m_pData = Alloc(m_dwDataLen); //�������̊m��
		if(!m_pData) return false;
		bRet = fread(m_pData,1,m_dwDataLen,fp)==m_dwDataLen;
		if(!bRet) return false;
	}

	return true;
}

CString CFakeNode::GetName()
{
	return m_strName;
}

void CFakeNode::SetName(const CString& strName)
{
	m_strName = strName;
}

CFakeRegManager *CFakeNode::GetManager()
{
	return m_pManager;
}

bool CFakeNode::IsKey()
{
	return m_bKey;
}

bool CFakeNode::SetData(const BYTE* pData, DWORD dwSize, DWORD dwType)
{
	if(!pData) return false;
	if(m_pData)
		Release();
	m_pData = Alloc(dwSize);
	if(!m_pData) return false;
	::CopyMemory(m_pData,pData,dwSize);
	m_dwType = dwType;
	m_dwDataLen = dwSize;
	
	return true;
}

DWORD CFakeNode::GetType()
{
	return m_dwType;
}

BYTE *CFakeNode::GetData()
{
	return m_pData;
}

DWORD CFakeNode::GetDataSize()
{
	return m_dwDataLen;
}


////////////////////////////////////////////////////////////////////////////////
//CFakeRegKey�̒�`
////////////////////////////////////////////////////////////////////////////////
CFakeRegKey::CFakeRegKey() throw()
	: m_hKey(NULL)
{
}

CFakeRegKey::CFakeRegKey(CFakeRegKey& key) throw()
{
	Attach(key.Detach());
}

CFakeRegKey::CFakeRegKey(HFAKEKEY hKey) throw()
	: m_hKey(hKey)
{
}

CFakeRegKey::~CFakeRegKey()
{
	Close();
}

CFakeRegKey& CFakeRegKey::operator=(CFakeRegKey& key) throw()
{
	Close();
	Attach(key.Detach());
	return *this;
}

CFakeRegKey::operator HFAKEKEY() const throw()
{
	return m_hKey;
}

void CFakeRegKey::Attach(HFAKEKEY hKey) throw()
{
	ATLASSERT(m_hKey == NULL);
	m_hKey = hKey;
}

HFAKEKEY CFakeRegKey::Detach() throw()
{
	HFAKEKEY hKey = m_hKey;
	m_hKey = NULL;
	return hKey;
}

HFAKEKEY CFakeRegKey::FindEntry(const CString& strEntryName)
{	//�w�肵�����O�̎q�m�[�h(�G���g��)��T��
	HFAKEKEY hKey = m_hKey->pFirstChild;
	while(hKey){
		if(!hKey->Self.IsKey() && strEntryName.CompareNoCase(hKey->Self.GetName())==0)
			return hKey;
		hKey = hKey->pNext;
	}
	return NULL;
}

HFAKEKEY CFakeRegKey::FindKey(const CString& strKeyName)
{	//�w�肵�����O�̎q�m�[�h(�L�[)��T��
	//�����K�w���̃L�[����������
	CString strLowLevelKey;
	CString strSearchName = strKeyName;
	int nPos = strKeyName.Find('\\');
	if(nPos>=1){
		strSearchName = strKeyName.Left(nPos);
		strLowLevelKey = strKeyName.Mid(nPos+1);
	}

	HFAKEKEY hKey = m_hKey->pFirstChild;
	while(hKey){
		if(hKey->Self.IsKey() && strSearchName.CompareNoCase(hKey->Self.GetName())==0){
			if(!strLowLevelKey.IsEmpty())
				return CFakeRegKey(hKey).FindKey(strLowLevelKey);
			return hKey;
		}
		hKey = hKey->pNext;
	}
	return NULL;
}

LONG CFakeRegKey::Create(HFAKEKEY hKeyParent, LPCTSTR lpszKeyName,
		LPTSTR lpszClass, DWORD dwOptions,
		REGSAM samDesired, LPSECURITY_ATTRIBUTES lpSecAttr,
		LPDWORD lpdwDisposition) throw()
{
	ATLASSERT(hKeyParent != NULL);
	if(!hKeyParent) return ERROR_INVALID_HANDLE; //�߂�l�͂���ł����H
	//������ - lpszClass�͖�������
	//������ - dwOptions����������
	//������ - samDesired����������
	//������ - lpSecAttr����������
	//���� : �߂�l�͐��������ꍇERROR_SUCCESS���Ԃ�Ƃ������ƈȊOCRegKey�Ɠ����l��
	//       ���邱�Ƃ͕ۏႵ�Ȃ�(�ł��Ȃ�)

	CFakeRegKey keyParent(hKeyParent);
	DWORD dwDisposition = REG_CREATED_NEW_KEY;

	//�Ƃ肠�������ɑ��݂��Ă��邩�m�F
	HFAKEKEY hKeyChild = keyParent.FindKey(lpszKeyName);
	if(hKeyChild){
		dwDisposition = REG_OPENED_EXISTING_KEY; //����
	}else{
		//�Ȃ��̂ō�� �}�l�[�W���C����
		hKeyChild = hKeyParent->Self.GetManager()->CreateKey(hKeyParent,lpszKeyName);
		if(!hKeyChild) return ERROR_CANTOPEN; //�R���ۂ��߂�l
	}

	LONG lRet = ERROR_SUCCESS;
	if(lpdwDisposition) *lpdwDisposition = dwDisposition;
	lRet = Close();
	m_hKey = hKeyChild;

	return lRet;
}

LONG CFakeRegKey::Open(HFAKEKEY hKeyParent, LPCTSTR lpszKeyName, REGSAM samDesired) throw()
{
	ATLASSERT(hKeyParent != NULL);
	if(!hKeyParent) return ERROR_INVALID_HANDLE;
	
	CString strKeyName;
	if(lpszKeyName==NULL || (strKeyName=lpszKeyName).IsEmpty()){
		m_hKey = hKeyParent; //����ȓ���ł����̂��ȁH
	}else{
		CFakeRegKey keyParent(hKeyParent);
		HFAKEKEY hChildKey = keyParent.FindKey(strKeyName);
		if(hChildKey){
			Close();
			m_hKey = hChildKey;
		}else{
			return ERROR_FILE_NOT_FOUND;
		}
	}

	return ERROR_SUCCESS;
}

LONG CFakeRegKey::Close() throw()
{
	m_hKey = NULL;
	return ERROR_SUCCESS;
}

LONG CFakeRegKey::Flush() throw()
{
	//�t�@�C���ۑ��̓}�l�[�W���N���X���ꊇ���ĊǗ�����̂ŁA
	//�L�[�P�ʂł̃t�@�C���A�N�Z�X�͂ł��Ȃ�
	return ERROR_SUCCESS;
}

LONG CFakeRegKey::EnumKey(DWORD iIndex, LPTSTR pszName,
		LPDWORD pnNameLength, FILETIME* pftLastWriteTime) throw()
{
	ATLASSERT(m_hKey && pszName && pnNameLength);
	if(!m_hKey) return ERROR_INVALID_HANDLE;
	if(!pszName || !pnNameLength) return ERROR_INVALID_PARAMETER;

	//������ - pftLastWriteTime : �������ݎ������L�^���Ă��Ȃ��̂Ō�������Ԃ����Ƃɂ���
	if(pftLastWriteTime){
		SYSTEMTIME st;
		::GetLocalTime(&st);
		::SystemTimeToFileTime(&st,pftLastWriteTime);
	}

	//�Ђǂ������ɂ��񋓏���(�S���񋓂���ƃI�[�_�[O(N^2)�Ƃ��΂���)
	//�K�v����������P���Ă�������
	HFAKEKEY hKey = m_hKey->pFirstChild;
	DWORD dwIndex = 0;
	while(hKey){
		if(dwIndex==iIndex){
			CString strName = hKey->Self.GetName();
			DWORD dwSize = strName.GetLength();
			::lstrcpyn(pszName,strName,*pnNameLength);
			*pnNameLength = *pnNameLength>dwSize?dwSize:*pnNameLength;
			return ERROR_SUCCESS;
		}
		hKey = hKey->pNext; //���X�g�\���̓C���f�b�N�X�񋓂Ɍ����Ȃ�
		dwIndex++;
	}
	return ERROR_NO_MORE_ITEMS;
}

bool CFakeRegKey::SetEntryValue(LPCTSTR lpszValueName, const BYTE* pData, DWORD dwSize, DWORD dwType)
{
	if(!m_hKey || !pData) return false;
	HFAKEKEY hEntry = FindEntry(lpszValueName);
	if(!hEntry){
		hEntry = m_hKey->Self.GetManager()->CreateEntry(m_hKey,lpszValueName);
		if(!hEntry) return false;
	}

	if(!hEntry->Self.SetData(pData,dwSize,dwType))
		return false;
	return true;

}

//#pragma warning(push)
//#pragma warning(disable: 4996)
LONG CFakeRegKey::SetValue(DWORD dwValue, LPCTSTR lpszValueName)
{
	bool bRet = SetEntryValue(lpszValueName,
		reinterpret_cast<const BYTE*>(&dwValue),sizeof(DWORD),REG_DWORD);
	return bRet?ERROR_SUCCESS:ERROR_CANTWRITE;
}

LONG CFakeRegKey::SetValue(LPCTSTR lpszValue, LPCTSTR lpszValueName, bool bMulti, int nValueLen)
{
	ATLASSERT(lpszValue);
	if(!lpszValue || (bMulti && nValueLen == -1))
		return ERROR_INVALID_PARAMETER;

	DWORD dwType = bMulti?REG_MULTI_SZ:REG_SZ;
	DWORD dwSize = (nValueLen==-1)?::lstrlen(lpszValue)+1:nValueLen;
	bool bRet = SetEntryValue(lpszValueName,
		reinterpret_cast<const BYTE*>(lpszValue),dwSize*sizeof(TCHAR),dwType);
	return bRet?ERROR_SUCCESS:ERROR_CANTWRITE;
}
//#pragma warning(pop)

LONG CFakeRegKey::SetValue(LPCTSTR pszValueName,DWORD dwType,const void* pValue,ULONG nBytes) throw()
{
	if(SetEntryValue(pszValueName,reinterpret_cast<const BYTE*>(pValue),nBytes,dwType))
		return ERROR_SUCCESS;
	return ERROR_CANTWRITE;
}


bool CFakeRegKey::QueryEntryValue(LPCTSTR lpszValueName, BYTE*& pData, DWORD* pdwSize, DWORD *pdwType)
{
	if(!m_hKey) return false;
	HFAKEKEY hEntry = FindEntry(lpszValueName);
	if(!hEntry) return false;

	if(pdwType){
		*pdwType = hEntry->Self.GetType();
	}

	if(!pdwSize){
		return pData?false:true;
	}
	if(pData){
		//�f�[�^�̃R�s�[
		DWORD dwDataSize = hEntry->Self.GetDataSize();
		DWORD dwCopySize;
		if(*pdwSize<dwDataSize){
			dwCopySize = *pdwSize;
		}else{
			dwCopySize = dwDataSize;
		}
		::CopyMemory(pData,hEntry->Self.GetData(),dwCopySize);
		*pdwSize = dwCopySize;
	}
	return true;
}

#pragma warning(push)
#pragma warning(disable: 4996)
LONG CFakeRegKey::QueryValue(DWORD& dwValue, LPCTSTR lpszValueName)
{
	BYTE* pData = reinterpret_cast<BYTE*>(&dwValue);
	DWORD dwSize = sizeof(DWORD);
	if(!QueryEntryValue(lpszValueName,pData,&dwSize,NULL))
		return ERROR_CANTREAD;
	if(dwSize!=sizeof(DWORD))
		return ERROR_INVALID_DATA;
	return ERROR_SUCCESS;
}

LONG CFakeRegKey::QueryValue(LPTSTR pszValue, LPCTSTR lpszValueName, DWORD* pdwCount)
{
	DWORD dwType;
	if(!QueryEntryValue(lpszValueName,reinterpret_cast<BYTE*&>(pszValue),pdwCount,&dwType))
		return ERROR_CANTREAD;

	//������̏ꍇ�̃f�[�^����͖ʓ|�Ȃ̂�atlbase.h����E���Ă���
	switch(dwType)
	{
		case REG_SZ:
		case REG_EXPAND_SZ:
			if ((*pdwCount) % sizeof(TCHAR) != 0 || pszValue[(*pdwCount) / sizeof(TCHAR) - 1] != 0)
		 		return ERROR_INVALID_DATA;
			break;
		case REG_MULTI_SZ:
			if ((*pdwCount) % sizeof(TCHAR) != 0 || (*pdwCount) / sizeof(TCHAR) < 2 || pszValue[(*pdwCount) / sizeof(TCHAR) -1] != 0 || pszValue[(*pdwCount) / sizeof(TCHAR) - 2] != 0 )
				return ERROR_INVALID_DATA;
			break;
		default:
			return ERROR_INVALID_DATA;
	}

	return ERROR_SUCCESS;
}
#pragma warning(pop)

LONG CFakeRegKey::QueryValue(LPCTSTR pszValueName, DWORD* pdwType, void* pData, ULONG* pnBytes) throw()
{
	if(QueryEntryValue(pszValueName,reinterpret_cast<BYTE*&>(pData),pnBytes,pdwType))
		return ERROR_SUCCESS;
	return ERROR_CANTREAD;
}

LONG CFakeRegKey::DeleteSubKey(LPCTSTR lpszSubKey) throw()
{
	ATLASSERT(m_hKey && lpszSubKey);
	if(!m_hKey) return ERROR_INVALID_HANDLE;
	if(!lpszSubKey) return ERROR_INVALID_PARAMETER;

	HFAKEKEY hSubKey = FindKey(lpszSubKey);
	if(!hSubKey) return ERROR_BADKEY;

	//
	//2000/NT�ł͍ċA�I�폜�͏o���Ȃ������Ȏd�l�����A���Ԃ��Ԃ��̂悤�Ɏ�������
	bool bRet;
	OSVERSIONINFO osi; //= {sizeof(OSVERSIONINFO)};
	::GetVersionEx(&osi);
	
	if(osi.dwPlatformId >= VER_PLATFORM_WIN32_NT){
		bRet = m_hKey->Self.GetManager()->RequestDelete(hSubKey,false);
	}else{
		bRet = m_hKey->Self.GetManager()->RequestDelete(hSubKey,true);
	}
	if(!bRet) return ERROR_REGISTRY_IO_FAILED; //���̖߂�l�͊Ԉ���Ă���Ǝv��
	return ERROR_SUCCESS;
}

LONG CFakeRegKey::RecurseDeleteKey(LPCTSTR lpszKey) throw()
{
	ATLASSERT(m_hKey && lpszKey);
	if(!m_hKey) return ERROR_INVALID_HANDLE;
	if(!lpszKey) return ERROR_INVALID_PARAMETER;

	HFAKEKEY hSubKey = FindKey(lpszKey);
	if(!hSubKey) return ERROR_BADKEY; //���̖߂�l��������

	if(!m_hKey->Self.GetManager()->RequestDelete(hSubKey,true))
		return ERROR_REGISTRY_IO_FAILED;
	return ERROR_SUCCESS;
}

LONG CFakeRegKey::DeleteValue(LPCTSTR lpszValue) throw()
{
	ATLASSERT(m_hKey && lpszValue);
	if(!m_hKey) return ERROR_INVALID_HANDLE;
	if(!lpszValue) return ERROR_INVALID_PARAMETER;

	HFAKEKEY hSubKey = FindEntry(lpszValue);
	if(!hSubKey) return ERROR_BADKEY;

	if(!m_hKey->Self.GetManager()->RequestDelete(hSubKey,false))
		return ERROR_REGISTRY_IO_FAILED;
	return ERROR_SUCCESS;
}


////////////////////////////////////////////////////////////////////////////////
//CFakeRegManager�̒�`
////////////////////////////////////////////////////////////////////////////////
CFakeRegManager::CFakeRegManager()
	: m_strSignature("fakereg")
{
	Clear();
}

void CFakeRegManager::Clear()
{
	m_Tree.Clear();

	CFakeNode& root = m_Tree.m_Root.Self;
	root.m_bKey = true;
	root.m_strName = "root";
	root.m_pManager = this;

	CFakeNode node;
	node.m_bKey = true;
	node.m_pManager = this;

	node.m_strName = "HKEY_CLASSES_ROOT";
	HFAKEKEY_CLASSES_ROOT = m_Tree.Insert(GetRoot(),node);
	node.m_strName = "HKEY_CURRENT_USER";
	HFAKEKEY_CURRENT_USER = m_Tree.Insert(GetRoot(),node);
	node.m_strName = "HKEY_LOCAL_MACHINE";
	HFAKEKEY_LOCAL_MACHINE = m_Tree.Insert(GetRoot(),node);
	node.m_strName = "HKEY_USERS";
	HFAKEKEY_USERS = m_Tree.Insert(GetRoot(),node);
}

bool CFakeRegManager::Load(const CString& strFileName)
{
	FILE *fp = fopen(strFileName,"rb");
	if(!fp) return false;

	bool bRet = true;
	try{
		//�V�O�l�`�����`�F�b�N
		CString strBuf;
		int nSigLen = m_strSignature.GetLength()+1;
		if(fread(strBuf.GetBuffer(nSigLen),1,nSigLen,fp)!=nSigLen)
			throw;
		strBuf.ReleaseBuffer();
		if(strBuf!=m_strSignature)
			throw;

		Clear();

		//�f�[�^�ǂݍ���
		if(!LoadRoot(fp))
			throw;
	}catch(...){
		bRet = false;
	}

	fclose(fp);
	return bRet;
}

bool CFakeRegManager::LoadRoot(FILE *fp)
{	//���[�g�Ɨ\��L�[�͎n�߂��瑶�݂���̂�insert�������s��Ȃ��悤�ɂ���K�v����������
	//�ǂ����@���v�����Ȃ������̂ŕʊ֐��ɂ���
	
	HFAKEKEY hRoot = m_Tree.GetRoot();

	//�\��L�[�̐��̎擾
	int nChildCount;
	if(fread(&nChildCount,sizeof(int),1,fp)!=1) return false;

	//�����̃f�[�^�ǂݍ���
	if(!hRoot->Self.Read(fp)) return false;

	//�\��L�[�̐������f�[�^�擾
	HFAKEKEY hReserved = hRoot->pFirstChild;
	for(int i=0; i<nChildCount; i++){
		if(!hReserved) return false;

		int nGrandChildCount;
		if(fread(&nGrandChildCount,sizeof(int),1,fp)!=1) return false;
		if(!hReserved->Self.Read(fp)) return false;

		//���L�[�̐������f�[�^�擾
		for(int j=0; j<nGrandChildCount; j++){
			if(!LoadSub(hReserved,fp)) return false;
		}
		
		hReserved = hReserved->pNext;
	}
	return true;
}

bool CFakeRegManager::LoadSub(HFAKEKEY hParentKey, FILE* fp)
{
	//�q�L�[�̐��̎擾
	int nChildCount;
	if(fread(&nChildCount,sizeof(int),1,fp)!=1) return false;

	//�����̃f�[�^�ǂݍ���
	CFakeNode node;
	if(!node.Read(fp)) false;
	//�c���[�ւ̓o�^
	HFAKEKEY hNewChild = m_Tree.Insert(hParentKey,node);
	if(!hNewChild) return false;

	//�q�L�[�̃f�[�^�ǂݍ���
	for(int i=0; i<nChildCount; i++){
		if(!LoadSub(hNewChild,fp)) return false;
	}
	return true;
}

bool CFakeRegManager::Save(const CString& strFileName)
{
	FILE *fp = fopen(strFileName,"wb");
	if(!fp) return false;

	bool bRet = true;
	try{
		//�V�O�l�`������������
		int nSigLen = m_strSignature.GetLength()+1;
		if(fwrite((LPCTSTR)m_strSignature,1,nSigLen,fp)!=nSigLen)
			throw;

		if(!SaveSub(m_Tree.GetRoot(),fp)) return false;
	}catch(...){
		bRet = false;
	}

	fclose(fp);
	return bRet;
}

bool CFakeRegManager::SaveSub(HFAKEKEY hParentKey, FILE* fp)
{
	//�q�L�[�̐��̏�������
	int nCount = 0;
	HFAKEKEY hChildKey = hParentKey->pFirstChild;
	while(hChildKey){
		nCount++;
		hChildKey = hChildKey->pNext;
	}
	if(fwrite(&nCount,sizeof(int),1,fp)!=1) return false;

	//�����̃f�[�^��������
	if(!hParentKey->Self.Write(fp)) false;

	//�q�L�[�̃f�[�^��������
	hChildKey = hParentKey->pFirstChild;
	while(hChildKey){
		if(!SaveSub(hChildKey,fp)) return false;
		hChildKey = hChildKey->pNext;
	}
	return true;
}

HFAKEKEY CFakeRegManager::GetRoot()
{
	return m_Tree.GetRoot();
}

HFAKEKEY CFakeRegManager::CreateKey(HFAKEKEY hParentKey, const CString& strKeyName)
{
	if(!hParentKey || strKeyName.IsEmpty()) return hParentKey;

	CString strSearch;
	CString strLowLevel; 
	int nPos = strKeyName.Find('\\');
	if(nPos==-1){
		strSearch = strKeyName;
	}else{
		strSearch = strKeyName.Left(nPos);
		strLowLevel = strKeyName.Mid(nPos+1);
	}

	CFakeRegKey key(hParentKey);
	HFAKEKEY hFoundKey = key.FindEntry(strSearch);
	if(!hFoundKey){
		CFakeNode node;
		node.m_bKey = true;
		node.m_strName = strSearch;
		node.m_pManager = this;
		HFAKEKEY hChildKey = m_Tree.Insert(hParentKey,node);
		if(hChildKey)
			return CreateKey(hChildKey,strLowLevel);
		else
			return NULL;
	}else{
		return CreateKey(hFoundKey,strLowLevel);
	}
}

HFAKEKEY CFakeRegManager::CreateEntry(HFAKEKEY hParentKey, const CString& strEntryName)
{
	CFakeRegKey key(hParentKey);
	HFAKEKEY hFoundEntry = key.FindEntry(strEntryName);
	if(hFoundEntry){
		return hFoundEntry;
	}else{
		CFakeNode node;
		node.m_bKey = false;
		node.m_strName = strEntryName;
		node.m_pManager = this;
		HFAKEKEY hChildEntry = m_Tree.Insert(hParentKey,node);
		return hChildEntry;
	}
}

bool CFakeRegManager::RequestDelete(HFAKEKEY hKey, bool bRecursive)
{
	ATLASSERT(hKey);
	if(!hKey) return false;
	if(bRecursive){
		//�ⓚ���p�ł��؂ď���
		m_Tree.Delete(hKey);
	}else{
		//�T�u�L�[��T���A���݂���Ύ��s�������Ƃɂ���
		HFAKEKEY hChild = hKey->pFirstChild;
		while(hChild){
			if(hChild->Self.IsKey()) return false;
			hChild = hChild->pNext;
		}
		m_Tree.Delete(hKey);
	}
	return true;
}


//
//���̑��@API�̃��b�p�[���ۂ�����
//

LONG RegQueryValueFake(HFAKEKEY hKey, LPCTSTR lpValueName, LPDWORD lpReserved,
					 LPDWORD lpType, LPBYTE lpData, LPDWORD lpcbData)
{
	CFakeRegKey key(hKey);
	return key.QueryValue(lpValueName,lpType,lpData,lpcbData);
}

LONG RegSetValueFake(HFAKEKEY hKey, LPCTSTR lpValueName, DWORD Reserved,
				   DWORD dwType, CONST BYTE *lpData, DWORD cbData)
{
	CFakeRegKey key(hKey);
	return key.SetValue(lpValueName,dwType,lpData,cbData);
}