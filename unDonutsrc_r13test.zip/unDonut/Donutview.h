// DonutView.h : interface of the CDonutView class
//
/////////////////////////////////////////////////////////////////////////////
#pragma once

#define docHostUIFlagDEFAULT docHostUIFlagFLAT_SCROLLBAR | docHostUIFlagNO3DBORDER | DOCHOSTUIFLAG_ENABLE_FORMS_AUTOCOMPLETE |DOCHOSTUIFLAG_THEME
#define docHostUIFlagNotFlatScrBar docHostUIFlagNO3DBORDER | DOCHOSTUIFLAG_ENABLE_FORMS_AUTOCOMPLETE// UDT DGSTR ( added by dai

#include "DonutViewOption.h"
#include "DocHostUIHandlerDispatch.h"
#include "AmbientDispatch.h"
#include "MtlBrowser.h"
#include "HLinkDataObject.h"

template <class T>
class CDonutViewFileDropTarget : public IDropTargetImpl<T>
{
public:
	bool m_bDragAccept;

	DROPEFFECT OnDragEnter(IDataObject* pDataObject, DWORD dwKeyState, CPoint point)
	{
		m_bDragAccept = _MtlIsHlinkDataObject(pDataObject);
		return _MtlStandardDropEffect(dwKeyState);
	}
	DROPEFFECT OnDragOver(IDataObject* pDataObject, DWORD dwKeyState, CPoint point, DROPEFFECT dropOkEffect)
	{
		if (!m_bDragAccept)
			return DROPEFFECT_NONE;

		return _MtlStandardDropEffect(dwKeyState) | _MtlFollowDropEffect(dropOkEffect) | DROPEFFECT_COPY;
	}
	DROPEFFECT OnDrop(IDataObject* pDataObject,	DROPEFFECT dropEffect,
		DROPEFFECT dropEffectList, CPoint point)
	{

		T* pT=static_cast<T*>(this);

		CString strText;
		if ( MtlGetHGlobalText(pDataObject, strText) ||
			 MtlGetHGlobalText(pDataObject, strText, ::RegisterClipboardFormat(CFSTR_SHELLURL)) )
		{
			DonutOpenFile(pT->m_hWnd, strText, DonutGetStdOpenFlag());
			return DROPEFFECT_COPY;
		}

		return DROPEFFECT_NONE;
	}
};



class CDonutView :
	public CWindowImpl<CDonutView, CAxWindow>,
	public CWebBrowser2,
	public CDonutViewFileDropTarget<CDonutView>
{
public:
// Declaration
	DECLARE_WND_SUPERCLASS(NULL, CAxWindow::GetWndClassName())

// Data members
	CComQIPtr<IAxWinAmbientDispatchEx> m_spAxAmbient;
	CDonutViewOption<CDonutView> m_ViewOption;
	DWORD m_dwDefaultDLControlFlags;

	CDocHostUIHandlerDispatch m_ExternalUIDispatch;
	CAmbientDispatch m_ExternalAmbientDispatch;

	int m_nDDCommand;
	
// Constructor
	CDonutView(DWORD dwDefaultDLControlFlags);
// Methods
	DWORD GetDLControlFlags();
	void PutDLControlFlags(DWORD dwDLControlFlags);
	void SetIeMenuNoCstm(int nStatus);

	//�h���b�O�h���b�v���̑���𐧌䂷�邩IE�R���|�ɔC���邩
	void SetOperateDragDrop(BOOL bOn, int nCommand);

// Overrides		
	BOOL PreTranslateMessage(MSG* pMsg);

// Message map and handlers
	BEGIN_MSG_MAP(CDonutView)
		
		MESSAGE_HANDLER(WM_CREATE, OnCreate)
		MSG_WM_DESTROY(OnDestroy)
		MSG_WM_MOUSEWHEEL(OnMouseWheel)
		COMMAND_ID_HANDLER_EX(ID_DLCTL_BGSOUNDS, OnMultiBgsounds)
		COMMAND_ID_HANDLER_EX(ID_DLCTL_VIDEOS, OnMultiVideos)
		COMMAND_ID_HANDLER_EX(ID_DLCTL_DLIMAGES, OnMultiDlImages)
		COMMAND_ID_HANDLER_EX(ID_DLCTL_RUNACTIVEXCTLS, OnSecurRunactivexctls)
		COMMAND_ID_HANDLER_EX(ID_DLCTL_DLACTIVEXCTLS, OnSecurDlactivexctls)
		COMMAND_ID_HANDLER_EX(ID_DLCTL_SCRIPTS, OnSecurScritps)
		COMMAND_ID_HANDLER_EX(ID_DLCTL_JAVA, OnSecurJava)
		CHAIN_MSG_MAP_MEMBER(m_ViewOption)
		COMMAND_ID_HANDLER_EX(ID_DLCTL_CHG_MULTI, OnMultiChg) // UDT DGSTR
		COMMAND_ID_HANDLER_EX(ID_DLCTL_CHG_SECU, OnSecuChg) // UDT DGSTR

		COMMAND_ID_HANDLER_EX(ID_DLCTL_ON_OFF_MULTI, OnAllOnOff)
		COMMAND_ID_HANDLER_EX(ID_DLCTL_ON_OFF_SECU, OnAllOnOff)
	END_MSG_MAP()
	

	LRESULT OnMouseWheel(UINT fwKeys, short zDelta, CPoint point);
	// UDT DGSTR
	void OnMultiChg(WORD, WORD, HWND);
	void OnSecuChg(WORD, WORD, HWND);
	void OnAllOnOff(WORD /*wNotifyCode*/, WORD wID, HWND /*hWndCtl*/);
	LRESULT OnCreate(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL&);
	void OnDestroy();
	void OnMultiBgsounds(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/);
	void OnMultiVideos(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/);
	void OnMultiDlImages(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/);
	void OnSecurRunactivexctls(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/);
	void OnSecurDlactivexctls(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/);
	void OnSecurScritps(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/);
	void OnSecurJava(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/);

	void _InitDLControlFlags();
	DWORD _GetDLControlFlags();
	
// Implementation
protected:
	void _OnFlag(DWORD dwFlag);
	void _OffFlag(DWORD dwFlag);
	bool _ToggleFlag(WORD wID, DWORD dwFlag, BOOL bReverse = FALSE);
	void _AddFlag(DWORD dwFlag);
	void _RemoveFlag(DWORD dwFlag);
	void _LightRefresh();

	BEGIN_UPDATE_COMMAND_UI_MAP(CDonutView)
		CHAIN_UPDATE_COMMAND_UI_MEMBER(m_ViewOption)

		UPDATE_COMMAND_UI(ID_DLCTL_DLIMAGES, OnUpdateDLCTL_DLIMAGES)				// with popup
		UPDATE_COMMAND_UI(ID_DLCTL_RUNACTIVEXCTLS, OnUpdateDLCTL_RUNACTIVEXCTLS)	// with popup

		UPDATE_COMMAND_UI_ENABLE_SETCHECK_FLAG(ID_DLCTL_BGSOUNDS, DLCTL_BGSOUNDS, GetDLControlFlags())
		UPDATE_COMMAND_UI_ENABLE_SETCHECK_FLAG(ID_DLCTL_VIDEOS, DLCTL_VIDEOS, GetDLControlFlags())

		UPDATE_COMMAND_UI_ENABLE_SETCHECK_FLAG_REV(ID_DLCTL_DLACTIVEXCTLS, DLCTL_NO_DLACTIVEXCTLS, GetDLControlFlags())
		UPDATE_COMMAND_UI_ENABLE_SETCHECK_FLAG_REV(ID_DLCTL_SCRIPTS, DLCTL_NO_SCRIPTS, GetDLControlFlags())
		UPDATE_COMMAND_UI_ENABLE_SETCHECK_FLAG_REV(ID_DLCTL_JAVA, DLCTL_NO_JAVA, GetDLControlFlags())

		// UH
		UPDATE_COMMAND_UI(ID_DLCTL_CHG_MULTI, OnUpdateDLCTL_ChgMulti)		// with popup
		UPDATE_COMMAND_UI(ID_DLCTL_CHG_SECU, OnUpdateDLCTL_ChgSecu)			// with popup

		UPDATE_COMMAND_UI_ENABLE_SETCHECK_IF(ID_DLCTL_ON_OFF_MULTI, ((GetDLControlFlags()&(DLCTL_DLIMAGES|DLCTL_BGSOUNDS|DLCTL_VIDEOS))==(DLCTL_DLIMAGES|DLCTL_BGSOUNDS|DLCTL_VIDEOS)) ? 1:0)
		UPDATE_COMMAND_UI_ENABLE_SETCHECK_IF(ID_DLCTL_ON_OFF_SECU, ((GetDLControlFlags()&(DLCTL_NO_RUNACTIVEXCTLS|DLCTL_NO_DLACTIVEXCTLS|DLCTL_NO_SCRIPTS|DLCTL_NO_JAVA))==0) ? 1:0)
	END_UPDATE_COMMAND_UI_MAP()

	void OnUpdateDLCTL_ChgMulti(CCmdUI* pCmdUI);
	void OnUpdateDLCTL_ChgSecu(CCmdUI* pCmdUI);
	void OnUpdateDLCTL_DLIMAGES(CCmdUI* pCmdUI);
	void OnUpdateDLCTL_RUNACTIVEXCTLS(CCmdUI* pCmdUI);
	void OnUpdateDocHostUIOpenNewWinUI(CCmdUI* pCmdUI);
	bool OnScroll(UINT nScrollCode, UINT nPos, bool bDoScroll = true);

// Overrides
	STDMETHOD(GetHostInfo)(DWORD  *pdwFlags,DWORD  *pdwDoubleClick);
	STDMETHOD(GetDropTarget)(IUnknown  *pDropTarget, IUnknown  **ppDropTarget);
	void OnDragLeave();
	void _DrawDragEffect(bool bRemove);
	DROPEFFECT OnDrop(IDataObject* pDataObject,	DROPEFFECT dropEffect,
		DROPEFFECT dropEffectList, CPoint point);

};

/////////////////////////////////////////////////////////////////////////////
