#pragma once

#include "OleDragDropExpTreeViewCtrl.h"
#include "MtlCtrls.h"
#include "ChevronHandler.h"
#include <URLHIST.H>
#include <shlguid.h> // needed for CLSID_CUrlHistory 
#include <atldef.h>
#include "comdef.h" 
#include "wtypes.h"
#include "SearchDialog.h"
#include "DonutFavoritesMenu.h"
#include "option/MainOption.h"

//GetUrlCacheEntryInfo

class CFavoritesTreeViewCtrl : 
	public COleDragDrogExplorerTreeViewCtrlImpl<CFavoritesTreeViewCtrl>
{
public:
	DECLARE_WND_SUPERCLASS(_T("Mtl_FavTreeViewCtrl"), GetWndClassName())
	typedef COleDragDrogExplorerTreeViewCtrlImpl<CFavoritesTreeViewCtrl> baseClass;
	typedef CFavoritesTreeViewCtrl thisClass;

// Constants
	enum { s_nIDOpenAll = 10, };

// Ctor/dtor

// Attributes
	bool _IsNeedFavoritesFix();

// Overrides
	void OnExplorerTreeViewInit();
	void OnExplorerTreeViewTerm();
	void OnChangeImageList();
	CItemIDList OnInitRootFolder();
	void OnFolderEmpty(); // U.H
	void OnInitialUpdateTreeItems(CSimpleArray<TV_INSERTSTRUCT>& items, LPCITEMIDLIST pidl);
	void OnTreeItemClicked(HTREEITEM hTreeItem, UINT uFlags);
	bool OnGetInfoToolTip(HTREEITEM hItem, CString& strTip, int cchTextMax);
	bool OnCmdContextMenu(HTREEITEM hTreeItem, int nID);
	bool OnCheckContextItem(HTREEITEM hTreeItem);
	UINT OnPrepareMenuForContext(HTREEITEM hTreeItem, CMenuHandle menu, int& nPos);
	void OnPrepareMenuForPopup(HTREEITEM hTreeItem, CMenuHandle menu);

	HTREEITEM AddItem(CString strText);

	void _GetProfile();
	void _WriteProfile();
};


template <class T, class TBase = CWindow, class TWinTraits = CControlWinTraits>
class CDonutFavoritesBarImpl : 
	public CWindowImpl< T, TBase, TWinTraits >,
	public CChevronHandler<CDonutFavoritesBarImpl>,
	public CUpdateCmdUI<CDonutFavoritesBarImpl>
{
public:
	DECLARE_WND_CLASS_EX(NULL, 0, -1)
	typedef CDonutFavoritesBarImpl<T, TBase, TWinTraits> thisClass;

// Constants
	enum
	{
		s_cxyBorder = 2,
		s_cxyBtnOffset = 1,
		s_cxyViewGap = 1,
	};

// Data members
	CToolBarCtrl m_wndToolBar;
	CReBarCtrl	m_wndReBar;
	//CTransparentToolBarCtrl m_wndToolBar;
	//CDonutExplorerReBarCtrl m_wndReBar;
	CFavoritesTreeViewCtrl m_view;
	int m_cxyHeader;
	CMenu m_menuPlacement;

	BOOL m_bShow;

// Ctor
	CDonutFavoritesBarImpl()
	{
		m_menuPlacement.LoadMenu(IDR_MENU_FAVTREE_BAR);
	}

// Overrides
	HMENU OnGetDropDownMenu(int nCmdID, HMENU& hMenuDestroy)
	{
		return m_menuPlacement.GetSubMenu(0);
	}

	BOOL OnToolbarReconstruct()
	{
	}

// Methods
	BYTE PreTranslateMessage(MSG* pMsg)
	{
		UINT msg = pMsg->message;
		int vKey =  pMsg->wParam;

		if (msg == WM_SYSKEYDOWN || msg == WM_SYSKEYUP || msg == WM_KEYDOWN) {

			if (m_view.m_hWnd && pMsg->hwnd == m_view.GetEditControl())
				return _MTL_TRANSLATE_WANT;// pass to rename edit ctrl

			if (pMsg->hwnd != m_view.m_hWnd || !m_view.IsWindowVisible())
				return _MTL_TRANSLATE_PASS;

			if (vKey == VK_LEFT || vKey == VK_RIGHT || vKey == VK_DOWN || vKey == VK_UP ||
				vKey == VK_RETURN || vKey == VK_SPACE) {
				return _MTL_TRANSLATE_WANT;// pass to control
			}
		}

		return _MTL_TRANSLATE_PASS;
	}

	// Message map and handlers
	BEGIN_MSG_MAP(CDonutFavoritesBarImpl)
		MESSAGE_HANDLER(WM_CREATE, OnCreate)
		MESSAGE_HANDLER(WM_SIZE, OnSize)
		MESSAGE_HANDLER(WM_SETFOCUS, OnSetFocus)
		MESSAGE_HANDLER(WM_DESTROY, OnDestroy)
		MESSAGE_HANDLER(WM_PAINT, OnPaint)
		MESSAGE_HANDLER(WM_ERASEBKGND, OnEraseBackground)
		MESSAGE_HANDLER(WM_SHOWWINDOW, OnShowWindow)

		COMMAND_ID_HANDLER(ID_FAVORITE_PLACEMENT, OnFavoritePlacement)
		COMMAND_ID_HANDLER(ID_VIEW_REFRESH_FAVBAR, OnFavoritePlacement)

		COMMAND_ID_HANDLER(ID_FAVTREE_BAR_SCRIPT, OnFavTreeScript)
		COMMAND_ID_HANDLER(ID_FAVTREE_BAR_STANDARD, OnFavTreeStandard)
		COMMAND_ID_HANDLER(ID_FAVTREE_BAR_GROUP, OnFavTreeGroup)
		COMMAND_ID_HANDLER(ID_FAVTREE_BAR_USER, OnFavTreeUser)
		COMMAND_ID_HANDLER(ID_FAVTREE_BAR_MYCOMPUTER, OnFavTreeMyComputer)
		COMMAND_ID_HANDLER(ID_FAVTREE_BAR_SHELLEXECUTE, OnFavTreeShellExecute)
		COMMAND_ID_HANDLER(ID_FAVTREE_BAR_LOADREMOTEICON, OnFavTreeLoadRemoteIcon)
		COMMAND_ID_HANDLER(ID_FAVTREE_BAR_SINGLEEXPAND, OnFavTreeSingleExpand)
		COMMAND_ID_HANDLER(ID_FAVTREE_BAR_HISTORY, OnFavTreeHistory) // UDT DGSTR ��ꂫ
		COMMAND_ID_HANDLER(ID_FAVTREE_BAR_HISTORY_TIME, OnFavTreeHistoryTime)

		NOTIFY_CODE_HANDLER(TBN_DROPDOWN, OnTbnDropDown)

		CHAIN_MSG_MAP_MEMBER(m_view);

		CHAIN_MSG_MAP(CChevronHandler<CDonutFavoritesBarImpl>)
		CHAIN_MSG_MAP(CUpdateCmdUI<CDonutFavoritesBarImpl>)
		//FORWARD_NOTIFICATIONS()
	END_MSG_MAP()

	LRESULT OnFavTreeStandard(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/, BOOL& /*bHandled*/)
	{
		BOOL bNowThis = _check_flag(ETV_EX_FAVORITES, m_view.GetExplorerTreeViewExtendedStyle()) ;
		m_view.ModifyExplorerTreeViewExtendedStyle(ETV_EX_FOLDERS, ETV_EX_FAVORITES);

		SendMessage(GetTopLevelParent(), WM_UPDATE_EXPBAR, (WPARAM)_T("���C�ɓ���"), (LPARAM)0); // UDT DGSTR ��ꂫ
		
		//m_wndToolBar.UpdateWindow();
		if (!bNowThis) m_view.RefreshRootTree();

		T *pT = static_cast<T*>(this);
		pT->OnToolbarReconstruct();

		return 0;
	}

	LRESULT OnFavTreeGroup(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/, BOOL& /*bHandled*/)
	{
		BOOL bNowThis = _check_flag(ETV_EX_FAVORITEGROUP, m_view.GetExplorerTreeViewExtendedStyle());
		m_view.ModifyExplorerTreeViewExtendedStyle(ETV_EX_FOLDERS, ETV_EX_FAVORITEGROUP);
		
		SendMessage(GetTopLevelParent(), WM_UPDATE_EXPBAR, (WPARAM)_T("���C�ɓ���O���[�v"), (LPARAM)0); // UDT DGSTR ��ꂫ
		
		m_wndToolBar.UpdateWindow();
		if (!bNowThis) m_view.RefreshRootTree();

		T *pT = static_cast<T*>(this);
		pT->OnToolbarReconstruct();

		return 0;
	}
	LRESULT OnFavTreeUser(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/, BOOL& /*bHandled*/)
	{
		BOOL bNowThis = _check_flag(ETV_EX_USERDEFINED, m_view.GetExplorerTreeViewExtendedStyle());
		m_view.ModifyExplorerTreeViewExtendedStyle(ETV_EX_FOLDERS, ETV_EX_USERDEFINED);

		SendMessage(GetTopLevelParent(), WM_UPDATE_EXPBAR, (WPARAM)_T("���[�U�[��`"), (LPARAM)0); // UDT DGSTR ��ꂫ
		
		m_wndToolBar.UpdateWindow();
		if (!bNowThis) m_view.RefreshRootTree();

		T *pT = static_cast<T*>(this);
		pT->OnToolbarReconstruct();

		return 0;
	}
	LRESULT OnFavTreeMyComputer(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/, BOOL& /*bHandled*/)
	{
		BOOL bNowThis = _check_flag(ETV_EX_MYCOMPUTER, m_view.GetExplorerTreeViewExtendedStyle());
		m_view.ModifyExplorerTreeViewExtendedStyle(ETV_EX_FOLDERS, ETV_EX_MYCOMPUTER);

		SendMessage(GetTopLevelParent(), WM_UPDATE_EXPBAR, (WPARAM)_T("�f�X�N�g�b�v"), (LPARAM)0); // UDT DGSTR ��ꂫ

		m_wndToolBar.UpdateWindow();
		if (!bNowThis) m_view.RefreshRootTree();

		T *pT = static_cast<T*>(this);
		pT->OnToolbarReconstruct();

		return 0;
	}
	// UDT DGSTR ��ꂫ
	LRESULT OnFavTreeHistory(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/, BOOL& /*bHandled*/)
	{
		BOOL bNowThis = _check_flag(ETV_EX_HISTORY, m_view.GetExplorerTreeViewExtendedStyle());
		m_view.ModifyExplorerTreeViewExtendedStyle(ETV_EX_FOLDERS, ETV_EX_HISTORY);

		SendMessage(GetTopLevelParent(), WM_UPDATE_EXPBAR, (WPARAM)_T("����"), (LPARAM)0); // UDT DGSTR

		m_wndToolBar.UpdateWindow();
		if (!bNowThis) m_view.RefreshRootTree();

		T *pT = static_cast<T*>(this);
		pT->OnToolbarReconstruct();

		return 0;
	}
	// ENDE

	// U.H
	LRESULT OnFavTreeHistoryTime(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/, BOOL& /*bHandled*/)
	{
		if (_check_flag(ETV_EX_HISTORY_TIME, m_view.GetExplorerTreeViewExtendedStyle()))
			m_view.ModifyExplorerTreeViewExtendedStyle(ETV_EX_HISTORY_TIME, 0);
		else
			m_view.ModifyExplorerTreeViewExtendedStyle(0, ETV_EX_HISTORY_TIME);

		m_wndToolBar.UpdateWindow();
		m_view.RefreshRootTree();

		T *pT = static_cast<T*>(this);
		pT->OnToolbarReconstruct();

		return 0;
	}

	LRESULT OnFavTreeScript(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/, BOOL& /*bHandled*/)
	{
		BOOL bNowThis = _check_flag(ETV_EX_SCRIPT, m_view.GetExplorerTreeViewExtendedStyle()) ;
		m_view.ModifyExplorerTreeViewExtendedStyle(ETV_EX_FOLDERS, ETV_EX_SCRIPT);

		SendMessage(GetTopLevelParent(), WM_UPDATE_EXPBAR, (WPARAM)_T("�X�N���v�g"), (LPARAM)0);
		
		m_wndToolBar.UpdateWindow();
		if (!bNowThis) m_view.RefreshRootTree();

		T *pT = static_cast<T*>(this);
		pT->OnToolbarReconstruct();

		return 0;
	}
	// ^^^

	LRESULT OnFavTreeShellExecute(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/, BOOL& /*bHandled*/)
	{
		if (_check_flag(ETV_EX_SHELLEXECUTE, m_view.GetExplorerTreeViewExtendedStyle()))
			m_view.ModifyExplorerTreeViewExtendedStyle(ETV_EX_SHELLEXECUTE, 0);
		else
			m_view.ModifyExplorerTreeViewExtendedStyle(0, ETV_EX_SHELLEXECUTE);

		return 0;
	}
	LRESULT OnFavTreeLoadRemoteIcon(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/, BOOL& /*bHandled*/)
	{
		if (_check_flag(ETV_EX_LOADREMOTEICON, m_view.GetExplorerTreeViewExtendedStyle()))
			m_view.ModifyExplorerTreeViewExtendedStyle(ETV_EX_LOADREMOTEICON, 0);
		else
			m_view.ModifyExplorerTreeViewExtendedStyle(0, ETV_EX_LOADREMOTEICON);

		m_wndToolBar.UpdateWindow();
		m_view.RefreshRootTree();

		return 0;
	}
	LRESULT OnFavoritePlacement(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/, BOOL& /*bHandled*/)
	{
		m_wndToolBar.UpdateWindow();
		m_view.RefreshRootTree();
		return 0;
	}
	LRESULT OnFavTreeSingleExpand(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/, BOOL& /*bHandled*/)
	{
		if (_check_flag(ETV_EX_SINGLEEXPAND, m_view.GetExplorerTreeViewExtendedStyle()))
			m_view.ModifyExplorerTreeViewExtendedStyle(ETV_EX_SINGLEEXPAND, 0);
		else
			m_view.ModifyExplorerTreeViewExtendedStyle(0, ETV_EX_SINGLEEXPAND);

		m_wndToolBar.UpdateWindow();
		m_view.RefreshRootTree();

		return 0;
	}

	LRESULT OnTbnDropDown(int /*idCtrl*/, LPNMHDR pnmh, BOOL& bHandled)
	{
		LPNMTOOLBAR lpnmtb = (LPNMTOOLBAR)pnmh;

		CRect rc; m_wndToolBar.GetItemRect(0, &rc);
		ClientToScreen(&rc);
		UINT uMenuFlags = TPM_LEFTBUTTON | TPM_RIGHTBUTTON | TPM_VERTICAL | TPM_LEFTALIGN | TPM_TOPALIGN | (!AtlIsOldWindows() ? TPM_VERPOSANIMATION : 0);
		TPMPARAMS TPMParams;
		TPMParams.cbSize = sizeof(TPMPARAMS);
		TPMParams.rcExclude = rc;

		::TrackPopupMenuEx(m_menuPlacement.GetSubMenu(0), uMenuFlags, rc.left + 1, rc.bottom + 2, m_hWnd, &TPMParams);

		return TBDDRET_DEFAULT;
	}

	LRESULT OnPaint(UINT /*uMsg*/, WPARAM /*wParam*/, LPARAM /*lParam*/, BOOL& /*bHandled*/)
	{
		CPaintDC dc(m_hWnd);

		T* pT = static_cast<T*>(this);
		pT->DrawPaneTitle(dc.m_hDC);

		return 0;
	}

	LRESULT OnEraseBackground(UINT /*uMsg*/, WPARAM wParam, LPARAM /*lParam*/, BOOL& /*bHandled*/)
	{
		return 1;	// no background needed
	}

	LRESULT OnShowWindow(UINT /*uMsg*/, WPARAM wParam, LPARAM /*lParam*/, BOOL& /*bHandled*/)
	{
		m_bShow = (BOOL)wParam;
		return 0;
	}

	LRESULT OnDestroy(UINT /*uMsg*/, WPARAM /*wParam*/, LPARAM /*lParam*/, BOOL& bHandled)
	{
		bHandled = FALSE;
		MtlDestroyImageLists(m_hWnd);
		return 0;
	}

	LRESULT OnCreate(UINT /*uMsg*/, WPARAM /*wParam*/, LPARAM /*lParam*/, BOOL& /*bHandled*/)
	{
		DWORD dwStyle = WS_CHILD | WS_VISIBLE | WS_CLIPSIBLINGS | WS_CLIPCHILDREN | 
			TVS_INFOTIP | TVS_EDITLABELS | TVS_SHOWSELALWAYS | TVS_SINGLEEXPAND | TVS_FULLROWSELECT | TVS_TRACKSELECT;

		if ((CMainOption::s_dwExplorerBarStyle&MAIN_EXPLORER_HSCROLL)!=MAIN_EXPLORER_HSCROLL)
			dwStyle |= TVS_NOHSCROLL;
		m_view.Create(m_hWnd, rcDefault, NULL, dwStyle, 0);//WS_EX_STATICEDGE);
		

		m_wndReBar = _CreateSimpleReBarCtrl(m_hWnd, ATL_SIMPLE_REBAR_NOBORDER_STYLE|CCS_NOPARENTALIGN);

		CFavoritesMenuOption::Add(m_hWnd);

		m_bShow = TRUE;
		return 0;
	}

	LRESULT OnSize(UINT /*uMsg*/, WPARAM /*wParam*/, LPARAM lParam, BOOL& /*bHandled*/)
	{
		UpdateLayout(GET_X_LPARAM(lParam), GET_Y_LPARAM(lParam));
		return 0;
	}

	LRESULT OnSetFocus(UINT /*uMsg*/, WPARAM /*wParam*/, LPARAM /*lParam*/, BOOL& /*bHandled*/)
	{
		if(m_view.m_hWnd != NULL)
			m_view.SetFocus();
		return 0;
	}

	CString GetSkinFavBarPath(BOOL bHot)
	{
		CString strBmp;
		if (bHot)	strBmp = _T("FavBarHot.bmp");
		else		strBmp = _T("FavBar.bmp");
		return _GetSkinDir()+strBmp;
	}

	void ReloadSkin()
	{
		if(!m_wndToolBar.IsWindow()) return;
		CImageList imgs, imgsHot;
		imgs = m_wndToolBar.GetImageList();
		imgsHot = m_wndToolBar.GetHotImageList();

		_ReplaceImageList(GetSkinFavBarPath(FALSE),imgs);
		_ReplaceImageList(GetSkinFavBarPath(TRUE),imgsHot);
		m_wndToolBar.InvalidateRect(NULL,TRUE);
	}

	void InitToolBar(int nIDAdd, int nIDOrganize, int nIDSpecial,
					 UINT nImageBmpID, UINT nHotImageBmpID, 
					 int cx, int cy, COLORREF clrMask, UINT nFlags = ILC_COLOR24)
	{
		CImageList imgs;
		MTLVERIFY(imgs.Create(cx, cy, nFlags | ILC_MASK, 1, 1));

		CBitmap bmp;
		//bmp.Attach(AtlLoadBitmapImage(GetSkinFavBarPath(FALSE).GetBuffer(0), LR_LOADFROMFILE));
		//if (bmp.m_hBitmap==NULL)
		//	bmp.LoadBitmap(nImageBmpID);
		imgs.Add(bmp, clrMask);

		CImageList imgsHot;
		MTLVERIFY(imgsHot.Create(cx, cy, nFlags | ILC_MASK, 1, 1));

		CBitmap bmpHot;
		//bmpHot.Attach(AtlLoadBitmapImage(GetSkinFavBarPath(TRUE).GetBuffer(0), LR_LOADFROMFILE));
		//if (bmpHot.m_hBitmap==NULL)
		//	bmpHot.LoadBitmap(nHotImageBmpID);
		imgsHot.Add(bmpHot, clrMask);

		m_wndToolBar.Create(m_hWnd, rcDefault, NULL, ATL_SIMPLE_TOOLBAR_PANE_STYLE | TBSTYLE_LIST, 0);
		m_wndToolBar.SetExtendedStyle(TBSTYLE_EX_DRAWDDARROWS);
		ATLASSERT(m_wndToolBar.IsWindow());
		m_wndToolBar.SetButtonStructSize(sizeof(TBBUTTON));

		m_wndToolBar.SetImageList(imgs);
		m_wndToolBar.SetHotImageList(imgsHot);

		T* pT = static_cast<T*>(this);
		pT->OnToolbarReconstruct();
		_AddSimpleReBarBandCtrl(m_wndReBar, m_wndToolBar);

		// add Add and Organize button
		/*TBBUTTON btnSp = { 2, nIDSpecial, TBSTATE_ENABLED, TBSTYLE_BUTTON | TBSTYLE_AUTOSIZE | TBSTYLE_DROPDOWN | BTNS_WHOLEDROPDOWN, 0, 0 };
		MTLVERIFY(m_wndToolBar.InsertButton(-1, &btnSp));
		TBBUTTON btnAdd = { 0, nIDAdd, TBSTATE_ENABLED, TBSTYLE_BUTTON | TBSTYLE_AUTOSIZE, 0, 0 };
		MTLVERIFY(m_wndToolBar.InsertButton(-1, &btnAdd));
		TBBUTTON btnOrg = { 1, nIDOrganize, TBSTATE_ENABLED, TBSTYLE_BUTTON | TBSTYLE_AUTOSIZE, 0, 0 };
		MTLVERIFY(m_wndToolBar.InsertButton(-1, &btnOrg));

		CVersional<TBBUTTONINFO> bi;
		bi.dwMask = TBIF_TEXT;
		bi.pszText = _T("�ǉ�...");
		MTLVERIFY(m_wndToolBar.SetButtonInfo(nIDAdd, &bi));
		bi.pszText = _T("����...");
		MTLVERIFY(m_wndToolBar.SetButtonInfo(nIDOrganize, &bi));
		bi.pszText = _T("�\��");
		MTLVERIFY(m_wndToolBar.SetButtonInfo(nIDSpecial, &bi));
		

		m_wndToolBar.AddStrings(_T("NS\0"));	// for proper item height
		_AddSimpleReBarBandCtrl(m_wndReBar, m_wndToolBar);

		CalcSize();
		*/
	}

	void UpdateLayout(int cxWidth, int cyHeight)
	{
		ATLASSERT(::IsWindow(m_hWnd));
		RECT rect;

		::SetRect(&rect, 0, 0, cxWidth, m_cxyHeader);
		if(m_wndReBar.m_hWnd != NULL)
			m_wndReBar.SetWindowPos(NULL, rect.left + s_cxyBorder, s_cxyBorder, rect.right - s_cxyBorder*2, rect.bottom, SWP_NOZORDER);

		if(m_view.m_hWnd != NULL) {
			CRect rc(rect.left, m_cxyHeader, cxWidth, cyHeight);
			rc.top += 1;
			rc.left += 1;
			rc.right -= 2;
			rc.bottom -= 2;
			m_view.SetWindowPos(NULL, rc, SWP_NOZORDER);
		}
		else
			rect.bottom = cyHeight;

		// I can't get the reason why I have to update now without InvalidateRect.
//		InvalidateRect(&rect); can't update a rect, correctly.
		CClientDC dc(m_hWnd);
		T* pT = static_cast<T*>(this);
		pT->DrawPaneTitle(dc.m_hDC);
	}

	void CalcSize()
	{
		CRect rcBtn;
		m_wndToolBar.GetItemRect(0, &rcBtn);
		m_cxyHeader = rcBtn.Height() + s_cxyBorder;
	}

	void DrawPaneTitle(CDCHandle dc)
	{
		CRect rect;
		GetClientRect(&rect);

//		CRect rc; m_view.GetWindowRect(&rc);
//		ScreenToClient(&rc);
		CPen pen; pen.CreatePen(PS_SOLID, 1, ::GetSysColor(COLOR_3DSHADOW));
		POINT pts[] = { { rect.right - 3, rect.top + m_cxyHeader }, { rect.left, rect.top + m_cxyHeader },
		{ rect.left, rect.bottom - 2 } };//, { rect.right - 3, rect.bottom - 1 } };

//		CRect rect_(rect);
//		rect_.top += m_cxyHeader;
//		dc.DrawEdge(&rect_, BDR_RAISEDINNER, BF_RECT | BF_FLAT);
		
//		POINT pts[] = { { rc.right - 1, rc.top - 1}, { rc.left, rc.top - 1},
//			{ rc.left, rc.bottom }, { rc.right - 1, rc.bottom } };
		HPEN hOldPen = dc.SelectPen(pen);
		dc.Polyline(pts, _countof(pts));
		dc.SelectPen(hOldPen);

		dc.DrawEdge(CRect(rect.left, rect.top + m_cxyHeader, rect.right, rect.bottom),
			EDGE_ETCHED, BF_RIGHT | BF_BOTTOM);

//		dc.DrawEdge(CRect(rect.left, rect.bottom - 2, rect.right - 2, rect.bottom + 10), EDGE_ETCHED, BF_TOP);

		rect.bottom = rect.top + m_cxyHeader;
		dc.DrawEdge(&rect, EDGE_ETCHED, BF_LEFT | BF_TOP | BF_RIGHT | BF_ADJUST);
		dc.FillRect(&rect, (HBRUSH)LongToPtr(COLOR_3DFACE + 1));
	}


/*	static HWND _CreateSimpleReBarCtrl(HWND hWndParent, DWORD dwStyle = ATL_SIMPLE_REBAR_STYLE, UINT nID = ATL_IDW_TOOLBAR)
	{
		// Ensure style combinations for proper rebar painting
		if(dwStyle & CCS_NODIVIDER && dwStyle & WS_BORDER)
			dwStyle &= ~WS_BORDER;
		else if(!(dwStyle & WS_BORDER) && !(dwStyle & CCS_NODIVIDER))
			dwStyle |= CCS_NODIVIDER;

		// Create rebar window
		HWND hWndReBar = ::CreateWindowEx(0, REBARCLASSNAME, NULL, dwStyle, 0, 0, 100, 100, hWndParent, (HMENU)LongToHandle(nID), _Module.GetModuleInstance(), NULL);
		if(hWndReBar == NULL)
		{
			ATLTRACE2(atlTraceUI, 0, _T("Failed to create rebar.\n"));
			return NULL;
		}

		// Initialize and send the REBARINFO structure
		REBARINFO rbi;
		rbi.cbSize = sizeof(REBARINFO);
		rbi.fMask  = 0;
		if(!::SendMessage(hWndReBar, RB_SETBARINFO, 0, (LPARAM)&rbi))
		{
			ATLTRACE2(atlTraceUI, 0, _T("Failed to initialize rebar.\n"));
			::DestroyWindow(hWndReBar);
			return NULL;
		}

		return hWndReBar;
	}
*/

	BEGIN_UPDATE_COMMAND_UI_MAP(CDonutFavoritesBarImpl)
		if(!m_bShow) return FALSE; 
		UPDATE_COMMAND_UI_SETCHECK_FLAG(ID_FAVTREE_BAR_SCRIPT, ETV_EX_SCRIPT, m_view.GetExplorerTreeViewExtendedStyle())
		UPDATE_COMMAND_UI_SETCHECK_FLAG(ID_FAVTREE_BAR_MYCOMPUTER, ETV_EX_MYCOMPUTER, m_view.GetExplorerTreeViewExtendedStyle())
		UPDATE_COMMAND_UI_SETCHECK_FLAG(ID_FAVTREE_BAR_STANDARD, ETV_EX_FAVORITES, m_view.GetExplorerTreeViewExtendedStyle())
		UPDATE_COMMAND_UI_SETCHECK_FLAG(ID_FAVTREE_BAR_GROUP, ETV_EX_FAVORITEGROUP, m_view.GetExplorerTreeViewExtendedStyle())
		UPDATE_COMMAND_UI_SETCHECK_FLAG(ID_FAVTREE_BAR_USER, ETV_EX_USERDEFINED, m_view.GetExplorerTreeViewExtendedStyle())
		UPDATE_COMMAND_UI_SETCHECK_FLAG(ID_FAVTREE_BAR_SHELLEXECUTE, ETV_EX_SHELLEXECUTE, m_view.GetExplorerTreeViewExtendedStyle())
		UPDATE_COMMAND_UI_SETCHECK_FLAG(ID_FAVTREE_BAR_LOADREMOTEICON, ETV_EX_LOADREMOTEICON, m_view.GetExplorerTreeViewExtendedStyle())
		UPDATE_COMMAND_UI_SETCHECK_FLAG(ID_FAVTREE_BAR_SINGLEEXPAND, ETV_EX_SINGLEEXPAND, m_view.GetExplorerTreeViewExtendedStyle())
		UPDATE_COMMAND_UI_SETCHECK_FLAG(ID_FAVTREE_BAR_HISTORY, ETV_EX_HISTORY, m_view.GetExplorerTreeViewExtendedStyle()) // UDT DGSTR ��ꂫ
		UPDATE_COMMAND_UI_SETCHECK_FLAG(ID_FAVTREE_BAR_HISTORY_TIME, ETV_EX_HISTORY_TIME, m_view.GetExplorerTreeViewExtendedStyle()) // U.H

	END_UPDATE_COMMAND_UI_MAP()
};

class CDonutFavoritesBar : public CDonutFavoritesBarImpl<CDonutFavoritesBar>
{
public:
	DECLARE_WND_CLASS_EX(_T("Donut_FavoritesBar"), 0, -1)


	struct _ThreadParam {
		CItemIDList idl;
		CString strWord;
		CFavoritesTreeViewCtrl* ptreeview;
		BOOL bContinue;
		BOOL bEnded;

		_ThreadParam() : ptreeview(NULL), bContinue(FALSE), bEnded(FALSE)
		{
		}
	};

	//Data Member
	_ThreadParam m_ThreadParam;
	HANDLE m_hThread;

	CDonutFavoritesBar();

	BEGIN_MSG_MAP(CDonutFavoriteBar)
	NOTIFY_CODE_HANDLER(TBN_DROPDOWN, OnTbnDropDown)
	MESSAGE_HANDLER(WM_DESTROY,OnDestroy)
	COMMAND_ID_HANDLER(ID_SEARCH_HISTORY,OnSearchHistory)
	COMMAND_ID_HANDLER(ID_SELECT_USERFOLDER,OnSelectUserFolder)
	COMMAND_ID_HANDLER(ID_VIEW_HISTORY_DAY, OnViewHistoryDay)
	COMMAND_ID_HANDLER(ID_VIEW_HISTORY_RECENT, OnViewHistoryRecent)
	CHAIN_MSG_MAP(CDonutFavoritesBarImpl<CDonutFavoritesBar>)
	END_MSG_MAP()


	BOOL OnToolbarReconstruct();
	void _AddNewButton(int nID, LPTSTR lpText, int nImage, int nStyleSpecial);
	void _InsertButton(int nID, int nStyleSpecial, int nImage);
	void _SetButtonText(int nID, LPTSTR lpstr);
	void ReloadSkin();

	void SplitKeyWord(CSimpleArray<CString>& arystr, CString strWord);
	void InsertItem(CString& strTitle, CString& strUrl);

	LRESULT OnSearchHistory(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/, BOOL& /*bHandled*/);
	LRESULT OnSelectUserFolder(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/, BOOL& /*bHandled*/);
	LRESULT OnTbnDropDown(int /*idCtrl*/, LPNMHDR pnmh, BOOL& bHandled);
	LRESULT OnViewHistoryDay(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/, BOOL& /*bHandled*/);
	LRESULT OnViewHistoryRecent(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/, BOOL& /*bHandled*/);
};
