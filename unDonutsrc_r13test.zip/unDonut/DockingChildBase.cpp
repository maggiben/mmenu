#include "stdafx.h"
#include "DockingChildBase.h"


////////////////////////////////////////////////////////////////////////////////
//CLayerFunctionManager�̒�`
////////////////////////////////////////////////////////////////////////////////

HMODULE CLayerFunctionManager::m_hLayerModule = NULL;
int CLayerFunctionManager::m_nCount = 0;

void CLayerFunctionManager::Inc()
{
	if(m_nCount==0) Init();
	m_nCount++;
}

void CLayerFunctionManager::Dec()
{
	m_nCount--;
	if(m_nCount==0) Term();
}

void CLayerFunctionManager::Init()
{
	if(m_hLayerModule) return;
	m_hLayerModule = ::LoadLibrary("user32.dll");
}

void CLayerFunctionManager::Term()
{
	if(m_hLayerModule){
		::FreeLibrary(m_hLayerModule);
		m_hLayerModule = NULL;
	}
}

bool CLayerFunctionManager::CanUseLayer()
{
	return m_hLayerModule?true:false;
}

BOOL CLayerFunctionManager::SetLayeredWindowAttributes(HWND hwnd, COLORREF crKey, BYTE bAlpha, DWORD dwFlags)
{
	if(!m_hLayerModule) return FALSE;
	FPSETLAYEREDWINDOWATTRIBUTES fpFunc = (FPSETLAYEREDWINDOWATTRIBUTES)::GetProcAddress(m_hLayerModule,"SetLayeredWindowAttributes");
	if(fpFunc){
		return fpFunc(hwnd,crKey,bAlpha,dwFlags);
	}else{
		return FALSE;
	}
}



