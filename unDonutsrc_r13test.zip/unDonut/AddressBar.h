#pragma once
////////////////////////////////////////////////////////////////////////////
// MTL Version 0.10
// Copyright (C) 2001 MB<mb2@geocities.co.jp>
// All rights unreserved.
//
// This file is a part of Mb Template Library.
// The code and information is *NOT* provided "as-is" without
// warranty of any kind, either expressed or implied.
//
// Mtlwin.h: Last updated: March 6, 2001
////////////////////////////////////////////////////////////////////////////
#include "HlinkDataObject.h"

#include <atlctrls.h>
#include "SearchBar.h"
#include "Donut.h"

namespace WTL
{

// Helper functions
struct __Mtl_Function_AddToComboBoxEx
{
	CComboBoxEx _comboBoxEx;
	__Mtl_Function_AddToComboBoxEx(HWND hWndComboBoxEx) : _comboBoxEx(hWndComboBoxEx) { }
	void operator()(const CString& str)
	{
		COMBOBOXEXITEM item;
		item.mask = CBEIF_TEXT;
		item.iItem = -1;
		item.pszText = (LPTSTR)(LPCTSTR)str;
		_comboBoxEx.InsertItem(&item);
	}
};

template <class _Function>
bool MtlLoadTypedURLs(HWND hWndComboBoxEx, _Function __f)
{
	CRegKey rk;
	LONG lRet = rk.Open(HKEY_CURRENT_USER,
		_T("Software\\Microsoft\\Internet Explorer\\TypedURLs"));
	if(lRet != ERROR_SUCCESS)
		return false;

	std::list<CString> urls;
	if (!MtlGetProfileString(rk, std::back_inserter(urls), _T("url"), 1, 25))// get only 25 items
		return false;
	
//	std::for_each(urls.begin(), urls.end(), __Mtl_Function_AddToComboBoxEx(hWndComboBoxEx));

	std::list<CString>::iterator it;
	for (it = urls.begin(); it != urls.end(); ++it) {
		CString strUrl = *it;
		COMBOBOXEXITEM item;
		__f(strUrl, item);
		CComboBoxEx(hWndComboBoxEx).InsertItem(&item);
	}

	return true;
}

template <class _OutputIterString>
bool __Mtl_AddFromComboBox(HWND hWndComboEx, _OutputIterString __result)
{
	CComboBoxEx combo(hWndComboEx);

	CString str;
	int nCount = combo.GetCount();
	if (nCount == 0)
		return false;

	for (int n = 0; n < nCount; ++n) {
		if (MtlGetLBTextFixed(combo, n, str) != CB_ERR)
			*__result++ = str;
	}

	return true;
}

inline bool MtlSaveTypedURLs(HWND hWndComboBoxEx)
{
	CRegKey rk;
	LONG lRet = rk.Open(HKEY_CURRENT_USER,
		_T("Software\\Microsoft\\Internet Explorer\\TypedURLs"));
	if(lRet != ERROR_SUCCESS)
		return false;

	std::list<CString> urls;
	__Mtl_AddFromComboBox(hWndComboBoxEx, std::back_inserter(urls));
	if (urls.size() == 0)
		return false;

	int nSize = 25;

	if (nSize > (int)urls.size())
		nSize = urls.size();

	std::list<CString>::iterator end = urls.begin();
	std::advance(end, nSize);
	MtlWriteProfileString(urls.begin(), end, rk, _T("url"), 1);
	return true;
}

// for debug
#ifdef _DEBUG
	const bool _Mtl_AddressBarCtrl_traceOn = false;
	#define abrTRACE if (_Mtl_AddressBarCtrl_traceOn) ATLTRACE
#else
	#define abrTRACE
#endif

////////////////////////////////////////////////////////////////////////////
// CAddressBarCtrl

#define ABR_EX_AUTOCOMPLETE		0x00000001L
#define ABR_EX_LOADTYPEDURLS	0x00000002L
#define ABR_EX_GOBTNVISIBLE		0x00000004L

//UH
#define ABR_EX_TEXTVISIBLE		0x00000008L
#define ABR_EX_ENTER_CTRL		0x00000010L
#define ABR_EX_ENTER_SHIFT		0x00000020L
//minit
#define ABR_EX_SEARCH_REPLACE	0x00000040L

#define ABR_EX_USER				0x00010000L

#define ABR_PANE_STYLE WS_CHILD | WS_VISIBLE | WS_CLIPCHILDREN /*| WS_OVERLAPPED | WS_MAXIMIZEBOX*/ | CCS_NODIVIDER | CCS_NOMOVEY

class CAddressBarCtrlBase : public CComboBoxEx
{
public:

};

template <class T, class TBase = CAddressBarCtrlBase, class TWinTraits = CControlWinTraits>
class ATL_NO_VTABLE CAddressBarCtrlImpl :
	public CWindowImpl< T, TBase, TWinTraits >,
	public IDropTargetImpl<T>,
	public IDropSourceImpl<T>
{
public:
	typedef CWindowImpl< T, TBase, TWinTraits > baseClass;
	DECLARE_WND_SUPERCLASS(NULL, TBase::GetWndClassName())

	struct CGoBtnInfo
	{
		CGoBtnInfo(UINT nImageBmpID, UINT nHotImageBmpID, int cx, int cy, COLORREF clrMask, UINT nFlags)
			: _nImageBmpID(nImageBmpID), _nHotImageBmpID(nHotImageBmpID), _cx(cx), _cy(cy), 
			  _clrMask(clrMask), _nFlags(nFlags) { }

		UINT _nImageBmpID;
		UINT _nHotImageBmpID;
		int _cx, _cy;
		COLORREF _clrMask;
		UINT _nFlags;
	};

// Constants
	enum { s_kcxGap = 2 };

// Data members
	CToolBarCtrl m_wndGo;
	DWORD m_dwAddressBarExtendedStyle;
	UINT m_nGoBtnCmdID;
	int m_cx;
	int m_cxGoBtn;
	SIZE m_szGoIcon;
	CGoBtnInfo* m_pGoBtnInfo;
	CContainedWindow m_wndCombo;
	CContainedWindowT<CEdit> m_wndEdit;
	CFlatComboBox m_comboFlat;
	CFont		m_font;

	bool m_bDragFromItself;

// Ctor/dtor
	CAddressBarCtrlImpl() : 
		m_dwAddressBarExtendedStyle(ABR_EX_TEXTVISIBLE|ABR_EX_ENTER_CTRL|ABR_EX_ENTER_SHIFT/*0*//*ABR_EX_AUTOCOMPLETE|ABR_EX_LOADTYPEDURLS|ABR_EX_GOBTNVISIBLE*/),
		m_nGoBtnCmdID(0), m_cxGoBtn(0),
		m_wndCombo(this, 1), m_wndEdit(this, 2),
		m_bDragFromItself(false)
	{
	}

	HWND Create(HWND hWndParent, UINT nID, UINT nGoBtnCmdID,
		UINT nImageBmpID, UINT nHotImageBmpID,
		int cx, int cy, COLORREF clrMask, UINT nFlags = ILC_COLOR24)
	{
		m_nGoBtnCmdID = nGoBtnCmdID;
		m_pGoBtnInfo = new CGoBtnInfo(nImageBmpID, nHotImageBmpID, cx, cy, clrMask, nFlags); 

		return baseClass::Create(hWndParent, CRect(0, 0, 500, 250),
			NULL, ABR_PANE_STYLE | CBS_DROPDOWN | CBS_AUTOHSCROLL , 0, nID);
	}
// Attributes
	bool GetDroppedStateEx() const
	{
		return (GetDroppedState() || _AutoCompleteWindowVisible());
	}

	void ModifyAddressBarExtendedStyle(DWORD dwRemove, DWORD dwAdd)
	{
		DWORD dwOldStyle = m_dwAddressBarExtendedStyle;
		bool bOldShow = _check_flag(dwOldStyle, ABR_EX_GOBTNVISIBLE);

		m_dwAddressBarExtendedStyle = (m_dwAddressBarExtendedStyle & ~dwRemove) | dwAdd;

		bool bNewShow = _check_flag(m_dwAddressBarExtendedStyle, ABR_EX_GOBTNVISIBLE);
		if (bNewShow != bOldShow)
			_ShowGoButton(bNewShow);
	}

	void SetAddressBarExtendedStyle(DWORD dwStyle)
	{
		DWORD dwOldStyle = m_dwAddressBarExtendedStyle;
		bool bOldShow = _check_flag(dwOldStyle, ABR_EX_GOBTNVISIBLE);
		bool bOldText = _check_flag(dwOldStyle, ABR_EX_TEXTVISIBLE);

		m_dwAddressBarExtendedStyle = dwStyle;

		bool bNewShow = _check_flag(m_dwAddressBarExtendedStyle, ABR_EX_GOBTNVISIBLE);
		bool bNewText = _check_flag(m_dwAddressBarExtendedStyle, ABR_EX_TEXTVISIBLE);
		if (bNewShow != bOldShow)
			_ShowGoButton(bNewShow);

		// U.H
		if (bNewText != bOldText)
		{
			CWindow wnd(GetParent());
			SendMessage(wnd.GetParent(), WM_USER_SHOW_TEXT_CHG, bNewText, 0);
		}
	}

	DWORD GetAddressBarExtendedStyle() const
	{
		return m_dwAddressBarExtendedStyle;
	}

/*	void SetWindowText(const CString& strText)
	{
		abrTRACE(_T("CAddressBarCtrlImpl::SetWindowText\n"));
		T* pT = static_cast<T*>(this);
		COMBOBOXEXITEM item;
		pT->OnGetItem(strText, item);
		item.iItem = -1;// on edit control
		item.pszText = (LPTSTR)(LPCTSTR)strText;

		MTLVERIFY(SetItem(&item));
	}*/

// Overridables
	void OnItemSelected(const CString& str)
	{
	}

	void OnItemSelectedEx(const CString& str)
	{
	}

	void OnInit()
	{
	}

	void OnTerm()
	{
	}

	void OnGetItem(const CString& str, COMBOBOXEXITEM& item)
	{
	}

	void OnGetDispInfo(COMBOBOXEXITEM& item)
	{
	}

// Methods
	BYTE PreTranslateMessage(MSG* pMsg)
	{
		UINT msg = pMsg->message;
		int vKey =  pMsg->wParam;
			
		if (msg == WM_SYSKEYDOWN || msg == WM_SYSKEYUP || msg == WM_KEYDOWN) {

			if (!IsWindowVisible() || !IsChild(pMsg->hwnd))	// ignore
				return _MTL_TRANSLATE_PASS;

/*			if (vKey == VK_F4) {
				if (::GetKeyState(VK_SHIFT) >= 0 && ::GetKeyState(VK_CONTROL) >= 0) // only F4 pressed
					return _MTL_TRANSLATE_WANT;					// I want!
			}
*/
			// left or right pressed, check shift and control key.
			if (vKey == VK_UP || vKey == VK_DOWN || vKey == VK_LEFT || vKey == VK_RIGHT || vKey == VK_HOME || vKey == VK_END
				|| vKey == (0x41+'C'-'A') || vKey == (0x41+'V'-'A') || vKey == (0x41+'X'-'A') || vKey == VK_INSERT)
			{
				if (::GetKeyState(VK_SHIFT) < 0 || ::GetKeyState(VK_CONTROL) < 0)
					return _MTL_TRANSLATE_WANT;// pass to edit control
			}

			// return key have to be passed
			if (vKey == VK_RETURN) {
				return _MTL_TRANSLATE_WANT;
			}

			// other key have to be passed
			if (VK_LBUTTON <= vKey && vKey <= VK_HELP) {
				BOOL bAlt = HIWORD(pMsg->lParam) & KF_ALTDOWN;
				if (!bAlt && ::GetKeyState(VK_SHIFT) >= 0 && ::GetKeyState(VK_CONTROL) >= 0)// not pressed
					return _MTL_TRANSLATE_WANT;// pass to edit control
			}
		}

		return _MTL_TRANSLATE_PASS;
	}

// Message map and handlers
	BEGIN_MSG_MAP(CAddressBarCtrlBaseImpl)
		MSG_WM_CREATE(OnCreate)
		MSG_WM_DESTROY(OnDestroy)
		MSG_WM_COMMAND(OnCommand)
		MSG_WM_SIZE(OnSize)
		MSG_WM_SETTEXT(OnSetText)
		MESSAGE_HANDLER(WM_ERASEBKGND, OnEraseBackground)
		MESSAGE_HANDLER(WM_WINDOWPOSCHANGING, OnWindowPosChanging)
		REFLECTED_COMMAND_CODE_HANDLER_EX(CBN_SELENDOK, OnCbnSelendok)
		NOTIFY_CODE_HANDLER(TTN_GETDISPINFO, OnToolTipText)
		REFLECTED_NOTIFY_CODE_HANDLER_EX(CBEN_GETDISPINFO, OnCbenGetDispInfo)
	ALT_MSG_MAP(1)
		MESSAGE_HANDLER(WM_WINDOWPOSCHANGING, OnComboWindowPosChanging)
		MESSAGE_HANDLER(WM_ERASEBKGND, OnComboEraseBackground)
		MESSAGE_HANDLER(WM_LBUTTONDOWN, OnLButtonDown)
		MESSAGE_HANDLER(WM_RBUTTONDOWN, OnRButtonDown)
		MESSAGE_HANDLER(WM_LBUTTONDBLCLK, OnLButtonDoubleClick) // UDT DGSTR
	ALT_MSG_MAP(2)
		MESSAGE_HANDLER(WM_ERASEBKGND, OnEditEraseBackground)
		MESSAGE_HANDLER(WM_LBUTTONDBLCLK, OnEditLButtonDblClk)
		MSG_WM_KEYDOWN(OnEditKeyDown)
	END_MSG_MAP()

	LRESULT OnSetText(LPCTSTR lpszText)
	{
		CString strText(lpszText);
		if (MtlGetWindowText(GetEditCtrl()) == strText)
			return TRUE;

		T* pT = static_cast<T*>(this);
		COMBOBOXEXITEM item;
//		if (strText.IsEmpty())
//			return TRUE;

//		if (strText.IsEmpty()) {
//			item.mask = CBEIF_IMAGE | CBEIF_IMAGE | CBEIF_SELECTEDIMAGE;
//			item.iImage = item.iSelectedImage = -1;
//			item.iItem = -1;// on edit control
//			item.pszText = _T("");
//			MTLVERIFY(SetItem(&item));
//			return TRUE;
//		}


//		item.mask = CBEIF_IMAGE | CBEIF_SELECTEDIMAGE | CBEIF_TEXT;
//		item.iImage = -1;
//		item.iSelectedImage = -1;
//		item.iItem = -1;
//		item.pszText = _T("");
//		MTLVERIFY(SetItem(&item));

		// Strangely, Icon on edit control never be changed... tell me why?
//		pT->OnGetItem(lpszText, item);
		item.mask = CBEIF_TEXT;
		item.iItem = -1;// on edit control
		item.pszText = (LPTSTR)(LPCTSTR)strText;
		MTLVERIFY(SetItem(&item));

		// insert it to tail and select
//		InsertItem(&item);
///		SetCurSel(GetCount()-1);
//		DeleteItem(GetCount()-1);
	
		return TRUE;
	}

	LRESULT OnCreate(LPCREATESTRUCT)
	{
		//vvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvv
		// �t�H���g
		CIniSection prFont;
		prFont.Open(_szIniFileName, _T("Main"));

		MTL::CLogFont lf;
		lf.InitDefault();
		if (lf.GetProfile(prFont))
		{
			CFontHandle font;
			MTLVERIFY(font.CreateFontIndirect(&lf));
			if (font.m_hFont) {
				if(m_font.m_hFont != NULL)
					m_font.DeleteObject();
				m_font.Attach(font.m_hFont);
				SetFont(m_font);
			}
		}
		prFont.Close();
		//^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

		_GetProfile();

		_CreateGoButton(m_pGoBtnInfo->_nImageBmpID, m_pGoBtnInfo->_nHotImageBmpID,
			m_pGoBtnInfo->_cx, m_pGoBtnInfo->_cy,
			m_pGoBtnInfo->_clrMask, m_pGoBtnInfo->_nFlags);
		delete m_pGoBtnInfo;

		LRESULT lRet = DefWindowProc();

		SetExtendedStyle(0, CBES_EX_NOSIZELIMIT);

		if (_check_flag(m_dwAddressBarExtendedStyle, ABR_EX_AUTOCOMPLETE))
			MtlAutoComplete(GetEditCtrl());

		if (_check_flag(m_dwAddressBarExtendedStyle, ABR_EX_LOADTYPEDURLS))
			_LoadTypedURLs();
		
		if (_check_flag(m_dwAddressBarExtendedStyle, ABR_EX_GOBTNVISIBLE))
			_ShowGoButton(true);
		else
			_ShowGoButton(false);

		m_wndCombo.SubclassWindow(GetComboCtrl());
		m_wndEdit.SubclassWindow(GetEditCtrl());
		m_comboFlat.FlatComboBox_Install(GetComboCtrl());

		T* pT = static_cast<T*>(this);
		pT->OnInit();

		return lRet;
	}

	void OnDestroy()
	{
		_WriteProfile();
		MtlDestroyImageLists(m_wndGo);

		if (_check_flag(m_dwAddressBarExtendedStyle, ABR_EX_LOADTYPEDURLS))
			MtlSaveTypedURLs(m_hWnd);

		m_wndCombo.UnsubclassWindow();
		m_wndEdit.UnsubclassWindow();

		T* pT = static_cast<T*>(this);
		pT->OnTerm();
	}

	void OnSize(UINT nFlags, CSize size)
	{
		abrTRACE(_T("CAddressBarCtrlImpl::OnSize\n"));

//		if (m_wndGo.IsWindowVisible()) {
			int cxGo = _GetGoBtnWidth();
			CRect rc; GetClientRect(rc);
			m_wndGo.MoveWindow(rc.right - cxGo + s_kcxGap, 0, cxGo, rc.Height());
			InvalidateRect(CRect(rc.right - cxGo, 0, rc.right - cxGo + s_kcxGap, rc.Height()));
//		}
	}

	LRESULT OnWindowPosChanging(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& /*bHandled*/)
	{
		LPWINDOWPOS lpWP = (LPWINDOWPOS)lParam;
		m_cx = lpWP->cx;

		LRESULT lRet = DefWindowProc(uMsg, wParam, lParam);

		if (m_wndGo.m_hWnd) {
			CSize size; m_wndGo.GetButtonSize(size);
			if(lpWP->cy < size.cy)
				lpWP->cy = size.cy;
		}

		return lRet;
	}

	void OnCommand(UINT, int nID, HWND hWndCtrl)
	{
		if (hWndCtrl == m_wndGo.m_hWnd) {
			ATLASSERT(nID == m_nGoBtnCmdID);
			CEdit edit = GetEditCtrl();
			CString str = MtlGetWindowText(edit);
			if (!str.IsEmpty()) {
				T* pT = static_cast<T*>(this);
				pT->OnItemSelected(str);
			}			
		}
		else {
			SetMsgHandled(FALSE);
		}
	}

	void OnCbnSelendok(UINT, int, HWND)
	{
		CString strLB;
		MtlGetLBTextFixed(m_hWnd, GetCurSel(), strLB);
		CEdit edit = GetEditCtrl();
		CString strText = MtlGetWindowText(edit);
		if (strText != strLB) {
			T* pT = static_cast<T*>(this);

			// change icon on edit control
//			COMBOBOXEXITEM item;
//			pT->OnGetItem(strLB, item);
//			item.mask = CBEIF_IMAGE|CBEIF_SELECTEDIMAGE;// only image
//			item.iItem = -1;
//			MTLVERIFY(SetItem(&item));
			pT->OnItemSelected(strLB);
			_MoveToTopAddressBox(strLB);
		}
	}

	LRESULT	OnCbenGetDispInfo(LPNMHDR lpnmhdr)
	{
		PNMCOMBOBOXEX pDispInfo = (PNMCOMBOBOXEX)lpnmhdr;
		T* pT = static_cast<T*>(this);
		pT->OnGetDispInfo(pDispInfo->ceItem);

		return 0;
	}

	LRESULT OnEraseBackground(UINT /*uMsg*/, WPARAM wParam, LPARAM /*lParam*/, BOOL& bHandled)
	{
		// UDT JOBBY
		HWND hWnd = GetParent();
		CPoint pt(0, 0);
		MapWindowPoints(hWnd, &pt, 1);
		pt = ::OffsetWindowOrgEx((HDC)wParam, pt.x, pt.y, NULL);
		LRESULT lResult = ::SendMessage(hWnd, WM_ERASEBKGND, wParam, 0L);
		::SetWindowOrgEx((HDC)wParam, pt.x, pt.y, NULL);
		return lResult;


		/*
		RECT rect;
		GetClientRect(&rect);
		::FillRect((HDC)wParam, &rect, (HBRUSH)LongToPtr(COLOR_3DFACE + 1));

		return 1;	// don't do the default erase
		*/
		//ENDE
	}

	LRESULT OnComboEraseBackground(UINT /*uMsg*/, WPARAM wParam, LPARAM /*lParam*/, BOOL& bHandled)
	{
		// fill only thumb
//		const int cxyBorder = 2;

//		CRect rc;
//		m_wndCombo.GetClientRect(&rc);
//		rc.left = rc.right - ::GetSystemMetrics(SM_CXHTHUMB) - cxyBorder;
//		rc.top += cxyBorder;
//		rc.bottom -= cxyBorder;

//		::FillRect((HDC)wParam, &rc, (HBRUSH)LongToPtr(COLOR_3DFACE + 1));

		return 1;	// don't do the default erase
	}

	LRESULT OnComboWindowPosChanging(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& /*bHandled*/)
	{
		abrTRACE(_T("CAddressBarCtrlImpl::OnComboWindowPosChanging\n"));

		LRESULT lRet = m_wndCombo.DefWindowProc(uMsg, wParam, lParam);
		LPWINDOWPOS lpWP = (LPWINDOWPOS)lParam;
		lpWP->cx = m_cx - _GetGoBtnWidth();

		
//		CRect rc; m_wndCombo.GetClientRect(&rc);
//		rc.right = lpWP->cx - ::GetSystemMetrics(SM_CXHTHUMB) - 2;
//		CEdit edit = GetEditCtrl();
//		m_wndCombo.ClientToScreen(&rc);
//		edit.ScreenToClient(&rc);
//		edit.ValidateRect(&rc);

		return lRet;
	}

	LRESULT OnEditEraseBackground(UINT /*uMsg*/, WPARAM wParam, LPARAM /*lParam*/, BOOL& bHandled)
	{
		return 1;	// don't do the default erase
	}

	LRESULT OnEditLButtonDblClk(UINT /*uMsg*/, WPARAM /*wParam*/, LPARAM /*lParam*/, BOOL& /*bHandled*/)
	{// fixed for Win2000 by DOGSTORE
		m_wndEdit.SetSel(0, -1);
		return 0;
	}

	void OnEditKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags)
	{
		// if not dropped, eat VK_DOWN	
		if (!GetDroppedState() && !_AutoCompleteWindowVisible() && (nChar == VK_DOWN || nChar == VK_UP)) {
			SetMsgHandled(TRUE);
		}
		else if (nChar == VK_RETURN) {
 			if(::GetKeyState(VK_CONTROL) <0 || ::GetKeyState(VK_SHIFT) <0)
 				_OnEnterKeyDownEx();
			else
 				_OnEnterKeyDown();
			SetMsgHandled(TRUE);
		}
		else {
			SetMsgHandled(FALSE);
		}
	}

	LRESULT OnToolTipText(int idCtrl, LPNMHDR pnmh, BOOL& /*bHandled*/)
	{
		LPNMTTDISPINFO pDispInfo = (LPNMTTDISPINFO)pnmh;
		pDispInfo->szText[0] = 0;

		if((idCtrl != 0) && !(pDispInfo->uFlags & TTF_IDISHWND))
		{
			CString strHeader = _T('\"');
			CString strHelp = _T("\" �ֈړ�");
			TCHAR szBuff[80];
			CString strSrc = MtlGetWindowText(GetEditCtrl());
			if (strSrc.IsEmpty())
				return 0;

			AtlCompactPathFixed(szBuff, strSrc, 80 - strHelp.GetLength() - strHeader.GetLength());
			strHeader += szBuff;
			strHeader += strHelp;
			::lstrcpyn(pDispInfo->szText, strHeader, 80);
		}

		return 0;
	}

// Implementation
	void _GetProfile()
	{
		CIniSection pr;
		CString strSection = _T("AddressBar#");
		strSection.Append(GetDlgCtrlID());

		pr.Open(_szIniFileName, strSection);
		pr.QueryValue(m_dwAddressBarExtendedStyle, _T("ExtendedStyle"));
		pr.Close();
	}

	void _WriteProfile()
	{
		CIniSection pr;
		CString strSection = _T("AddressBar#");
		strSection.Append(GetDlgCtrlID());

		pr.Open(_szIniFileName, strSection);
		pr.SetValue(m_dwAddressBarExtendedStyle, _T("ExtendedStyle"));
		pr.Close();
	}

	void _MoveToTopAddressBox(const CString& strURL)
	{
		T* pT = static_cast<T*>(this);
		COMBOBOXEXITEM item;
		pT->OnGetItem(strURL, item);
		item.iItem = 0;// add to top
		item.pszText = (LPTSTR)(LPCTSTR)strURL;
		
		// search the same string
		int nCount = GetCount();
		for (int n = 0; n < nCount; ++n) {
			CString str;
			MtlGetLBTextFixed(m_hWnd, n, str);
			if (strURL == str) {
				DeleteItem(n);
				InsertItem(&item);
				break;
			}
		}
	}

	void _OnEnterKeyDown()
	{
		CEdit edit = GetEditCtrl();
		CString str = MtlGetWindowText(edit);//some comboboxex control impl often not support GetWindowText
		if (!str.IsEmpty()) {
			if (_AutoCompleteWindowVisible())// I have to clean auto complete window, but escape means undo...
				::SendMessage(GetEditCtrl(), WM_KEYDOWN, (WPARAM)VK_ESCAPE, 0);
			T* pT = static_cast<T*>(this);
			pT->OnItemSelected(str);
			_AddToAddressBoxUnique(str);
		}
	}

 	void _OnEnterKeyDownEx()
 	{
 		CEdit edit = GetEditCtrl();
 		CString str = MtlGetWindowText(edit);//some comboboxex control impl often not support GetWindowText
 		if (str.IsEmpty()) 
 			return;
 
		if(_check_flag(ABR_EX_SEARCH_REPLACE, m_dwAddressBarExtendedStyle)) //minit
			str.Replace(_T("�@"),_T(" "));
		//str.Replace(' ', '+');
		//str.Replace(_T(" "), _T("%20")); //minit

		TCHAR cBuff[MAX_PATH];
		DWORD dwCount=MAX_PATH;

		CIniSection pr;
		pr.Open(_szIniFileName, _T("AddresBar"));
		pr.QueryValue(cBuff, _T("EnterCtrlEngin"), &dwCount);
		CString strEnterCtrl(cBuff);
		pr.QueryValue(cBuff, _T("EnterShiftEngin"), &dwCount);
		CString strEnterShift(cBuff);
		pr.Close();

 		if(::GetKeyState(VK_CONTROL) <0)
		{
			if (!_check_flag(ABR_EX_ENTER_CTRL, m_dwAddressBarExtendedStyle))
			{
				_OnEnterKeyDown();
				return;
			}

			// Ctrl��
			::SendMessage(GetTopLevelParent(),WM_SEARCH_WEB_SELTEXT,(WPARAM)(LPCTSTR)str,(LPARAM)(LPCTSTR)strEnterCtrl);
			return;
			//if (strEnterCtrl.IsEmpty())
			//	str.Insert(0, "http://www.google.com/search?lr=lang_ja&q=" );
			//else
			//	str.Insert(0, strEnterCtrl );
		}
		else if (::GetKeyState(VK_SHIFT) <0)
		{
			if (!_check_flag(ABR_EX_ENTER_SHIFT, m_dwAddressBarExtendedStyle))
			{
				_OnEnterKeyDown();
				return;
			}

			// Shift��
			::SendMessage(GetTopLevelParent(),WM_SEARCH_WEB_SELTEXT,(WPARAM)(LPCTSTR)str,(LPARAM)(LPCTSTR)strEnterShift);
			return;
			//if (strEnterShift.IsEmpty())
			//	str.Insert(0, "http://www.excite.co.jp/world/url/proceeding/?wb_url=" );
			//else
			//	str.Insert(0, strEnterShift );
		}

 		if (_AutoCompleteWindowVisible())// I have to clean auto complete window, but escape means undo...
 			::SendMessage(GetEditCtrl(), WM_KEYDOWN, (WPARAM)VK_ESCAPE, 0);
 
 		T* pT = static_cast<T*>(this);

		pT->OnItemSelectedEx(str);

 		_AddToAddressBoxUnique(str);
	}

	bool _AutoCompleteWindowVisible() const
	{
		CRect rc; m_wndEdit.GetWindowRect(&rc);
		CPoint pt(rc.left + 1, rc.bottom + 5);
		HWND hWndDropDown = ::WindowFromPoint(pt);
		if (MtlIsFamily(m_hWnd, hWndDropDown))
			return false;
		else
			return true;

//		HWND hWnd = ::FindWindow(_T("Auto-Suggest Dropdown"), NULL);
//		return ::IsWindowVisible(hWnd) == TRUE;
	}

	void _AddToAddressBoxUnique(const CString& strURL)
	{
		T* pT = static_cast<T*>(this);
		COMBOBOXEXITEM item;
		pT->OnGetItem(strURL, item);
		item.iItem = 0;// ado to top
		item.pszText = (LPTSTR)(LPCTSTR)strURL;

		// search the same string
		int nCount = GetCount();
		for (int n = 0; n < nCount; ++n) {
			CString str;
			MtlGetLBTextFixed(m_hWnd, n, str);
			if (strURL == str) {
				DeleteItem(n);
				break;
			}
		}

		InsertItem(&item);
	}

	void _ShowGoButton(bool bShow)
	{
		if (bShow)
			m_wndGo.ShowWindow(SW_SHOWNORMAL);
		else
			m_wndGo.ShowWindow(SW_HIDE);

//		SendMessage(WM_SIZE, 0, 0);// update layout of go button

		// generate WM_WINDOWPOSCHANGING, no other way
		CRect rect;
		GetWindowRect(rect);
		CWindow(GetParent()).ScreenToClient(rect);

		SetWindowPos(NULL, rect.left, rect.top,
				rect.right - rect.left - 1, rect.bottom - rect.top,
				SWP_NOZORDER|SWP_NOREDRAW);// | SWP_NOACTIVATE);

		SetWindowPos(NULL, rect.left, rect.top,
				rect.right - rect.left, rect.bottom - rect.top,
				SWP_NOZORDER);// | SWP_NOACTIVATE);
	}

	int _GetGoBtnWidth()
	{
		abrTRACE(_T("CAddressBarCtrlImpl::_GetGoBtnWidth\n"));
//		if (!m_wndGo.m_hWnd || !m_wndGo.IsWindowVisible())
//			return 0;

		if (!m_wndGo.m_hWnd || !_check_flag(m_dwAddressBarExtendedStyle, ABR_EX_GOBTNVISIBLE)) {
			abrTRACE(_T(" return 0\n"));
			return 0;
		}

/*		TBBUTTONINFO bi;
		memset(&bi, 0, sizeof(bi));
		bi.cbSize = sizeof(TBBUTTONINFO);
		bi.dwMask = TBIF_SIZE;
		if (m_wndGo.GetButtonInfo(m_nGoBtnCmdID, &bi) == -1) {
			abrTRACE(_T(" failed\n"));
			return 0;
		}

		abrTRACE(_T(" width(%d)\n"), bi.cx);*/
		return m_cxGoBtn + s_kcxGap;
	}

	// Strangly GetButtonInfo lies...
	int _CalcBtnWidth(int cxIcon, const CString& strText)
	{
		const int cxGap = 3;

		if (strText.IsEmpty())
			return cxGap*2 + cxIcon;

		int nWidth = 0;
		nWidth += cxGap*2;
		nWidth += cxIcon;
		nWidth += cxGap*2 - 1;
		nWidth += MtlComputeWidthOfText(strText, m_wndGo.GetFont());
//		nWidth += cxGap*2;

		return nWidth;
	}

	int _CalcBtnHeight(int cyIcon)
	{
		const int cyGap = 3;

		CLogFont lf; CFontHandle(m_wndGo.GetFont()).GetLogFont(&lf);
		int cy = lf.lfHeight;
		if(cy < 0)
			cy = -cy;

		return MtlMax(cy, cyIcon + cyGap*2);
	}

	bool _LoadTypedURLs()
	{
		CRegKey rk;
		LONG lRet = rk.Open(HKEY_CURRENT_USER,
			_T("Software\\Microsoft\\Internet Explorer\\TypedURLs"));
		if(lRet != ERROR_SUCCESS)
			return false;

		std::list<CString> urls;
		if (!MtlGetProfileString(rk, std::back_inserter(urls), _T("url"), 1, 25))// get only 25 items
			return false;
	
//	std::for_each(urls.begin(), urls.end(), __Mtl_Function_AddToComboBoxEx(hWndComboBoxEx));

		T* pT = static_cast<T*>(this);

		std::list<CString>::iterator it;
		for (it = urls.begin(); it != urls.end(); ++it) {
			CString strUrl = *it;
			COMBOBOXEXITEM item;
			pT->OnGetItem(strUrl, item);
			item.iItem = -1;// add to tail
			item.pszText = (LPTSTR)(LPCTSTR)strUrl;
			InsertItem(&item);
		}

		return true;
	}

	CString GetSkinGoBtnPath(BOOL bHot)
	{
		CString strBmp;
		if (bHot)	strBmp = _T("GoHot.bmp");
		else		strBmp = _T("Go.bmp");
		return _GetSkinDir()+strBmp;
	}

	HWND _CreateGoButton(UINT nImageBmpID, UINT nHotImageBmpID,
		int cx, int cy, COLORREF clrMask, UINT nFlags = ILC_COLOR24)
	{
		m_szGoIcon.cx = cx;
		m_szGoIcon.cy = cy;

		CImageList imgs;
		MTLVERIFY(imgs.Create(cx, cy, nFlags | ILC_MASK, 1, 1));

		CBitmap bmp;
		bmp.Attach(AtlLoadBitmapImage(GetSkinGoBtnPath(FALSE).GetBuffer(0), LR_LOADFROMFILE));
		if (bmp.m_hBitmap==NULL)
			bmp.LoadBitmap(nImageBmpID);
		imgs.Add(bmp, clrMask);


		CImageList imgsHot;
		MTLVERIFY(imgsHot.Create(cx, cy, nFlags | ILC_MASK, 1, 1));

		CBitmap bmpHot;
		bmpHot.Attach(AtlLoadBitmapImage(GetSkinGoBtnPath(TRUE).GetBuffer(0), LR_LOADFROMFILE));
		if (bmpHot.m_hBitmap==NULL)
			bmpHot.LoadBitmap(nHotImageBmpID);
		imgsHot.Add(bmpHot, clrMask);

		m_wndGo = ::CreateWindowEx(0, TOOLBARCLASSNAME, NULL,
			ATL_SIMPLE_TOOLBAR_PANE_STYLE | TBSTYLE_LIST | CCS_TOP, 0,0,100,100,
				m_hWnd, (HMENU)12, _Module.GetModuleInstance(), NULL);
		m_wndGo.SetButtonStructSize(sizeof(TBBUTTON));

		// �t�H���g
		if (m_font.m_hFont)
			m_wndGo.SetFont(m_font.m_hFont);

		// init button size
		if (_check_flag(m_dwAddressBarExtendedStyle, ABR_EX_TEXTVISIBLE))
			m_cxGoBtn = _CalcBtnWidth(cx, _T("�ړ�"));
		else
			m_cxGoBtn = _CalcBtnWidth(cx, _T(""));

		m_wndGo.SetButtonSize(CSize(m_cxGoBtn, _CalcBtnHeight(cy)));

		m_wndGo.SetImageList(imgs);
		m_wndGo.SetHotImageList(imgsHot);

		// one button
		TBBUTTON btn = { 0, m_nGoBtnCmdID, TBSTATE_ENABLED, TBSTYLE_BUTTON/* | TBSTYLE_AUTOSIZE*/, 0, 0 };
		MTLVERIFY(m_wndGo.InsertButton(-1, &btn));

		TBBUTTONINFO bi;
		memset(&bi, 0, sizeof(bi));
		bi.cbSize = sizeof(TBBUTTONINFO);
		bi.dwMask = TBIF_TEXT;
		bi.pszText = _T("�ړ�");
		MTLVERIFY(m_wndGo.SetButtonInfo(m_nGoBtnCmdID, &bi));

		m_wndGo.AddStrings(_T("NS\0"));	// for proper item height

		return m_wndGo.m_hWnd;
	}

	void ReloadSkin(int nCmbStyle)
	{
		m_comboFlat.SetDrawStyle(nCmbStyle);
		if(m_wndGo.m_hWnd){
			CImageList imgs, imgsHot;
			imgs = m_wndGo.GetImageList();
			imgsHot = m_wndGo.GetHotImageList();
			_ReplaceImageList(GetSkinGoBtnPath(FALSE),imgs);
			_ReplaceImageList(GetSkinGoBtnPath(TRUE),imgsHot);
			m_wndGo.InvalidateRect(NULL,TRUE);
		}
		InvalidateRect(NULL,TRUE);
	}

// IDropSource
	// Overridables
	HRESULT OnGetAddressBarCtrlDataObject(IDataObject** ppDataObject)
	{
		ATLASSERT(ppDataObject != NULL);
		*ppDataObject = NULL;
		return E_NOTIMPL;
	}

	LRESULT OnLButtonDown(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
	{
		POINT pt = { GET_X_LPARAM(lParam), GET_Y_LPARAM(lParam) };
		
		if (wParam & MK_CONTROL) {
			bHandled = FALSE;
			return 0;
		}

		if (_HitTest(pt)) {
			_DoDragDrop(pt, (UINT)wParam, true);
		}
		else
			bHandled = FALSE;

		return 0;
	}

	LRESULT OnRButtonDown(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
	{
		POINT pt = { GET_X_LPARAM(lParam), GET_Y_LPARAM(lParam) };

		if (wParam & MK_CONTROL) {
			bHandled = FALSE;
			return 0;
		}

		if (_HitTest(pt)) {
			_DoDragDrop(pt, (UINT)wParam, true);
		}
		else
			bHandled = FALSE;

		return 0;
	}

// UDT DGSTR
	LRESULT OnLButtonDoubleClick(UINT /*uMsg*/, WPARAM /*wParam*/, LPARAM /*lParam*/, BOOL& /*bHandled*/)
	{	
		CString str = MtlGetWindowText(m_wndEdit);
		if ( str.IsEmpty() )
			return 0;
		TCHAR szIEPath[MAX_PATH];
		DWORD dwCount = MAX_PATH * sizeof(TCHAR);
		CRegKey rk;
		LONG lRet = rk.Open(HKEY_LOCAL_MACHINE,
			_T("SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\App Paths\\IEXPLORE.EXE"), KEY_QUERY_VALUE);
		if (lRet == ERROR_SUCCESS )
		{
			rk.QueryStringValue(NULL,szIEPath,&dwCount);
			//rk.QueryValue(szIEPath, NULL, &dwCount);
			ShellExecute(NULL, _T("open"), szIEPath, str, NULL, SW_SHOW);
			rk.Close();
		}
		return 0;
	}
// ENDE

	bool _HitTest(CPoint pt)
	{
		CRect rc;
		m_wndCombo.GetClientRect(rc);

		CRect rcEdit;
		m_wndEdit.GetWindowRect(&rcEdit);
		m_wndCombo.ScreenToClient(&rcEdit);

//		CImageList imgs = GetImageList();
//		CSize size(0, 0); imgs.GetIconSize(size);

		rc.right = rcEdit.left;

		if (rc.PtInRect(pt))
			return true;
		else
			return false;
	}

	void _DoDragDrop(CPoint pt, UINT nFlags, bool bLeftButton)
	{
//		CRect rc; GetItemRect(nIndex, rc);
//		ClientToScreen(rc);
		if (PreDoDragDrop(m_hWnd, NULL, false)) {// now dragging
			CComPtr<IDataObject> spDataObject;
			T* pT = static_cast<T*>(this);

			HRESULT hr = pT->OnGetAddressBarCtrlDataObject(&spDataObject);
			if (SUCCEEDED(hr)) {
				m_bDragFromItself = true;
				DROPEFFECT dropEffect = DoDragDrop(spDataObject, DROPEFFECT_MOVE|DROPEFFECT_COPY|DROPEFFECT_LINK);
				m_bDragFromItself = false;
			}
		}
		else {// canceled
			if (bLeftButton) {

			}
			else {
				m_wndGo.SendMessage(WM_RBUTTONUP, (WPARAM)nFlags, MAKELPARAM(pt.x, pt.y));
			}
		}
	}
};

class CAddressBarCtrl : public CAddressBarCtrlImpl<CAddressBarCtrl>
{
public:
	DECLARE_WND_SUPERCLASS(_T("MTL_AddressBar"), GetWndClassName())
};

//////////////////////
// for Donut
#define ABR_EX_OPENNEWWIN	0x00010000L
#define ABR_EX_NOACTIVATE	0x00020000L

class CDonutAddressBar:
	public CAddressBarCtrlImpl<CDonutAddressBar>,
	public CCustomDraw<CDonutAddressBar>
{
public:
	DECLARE_WND_SUPERCLASS(_T("Donut_AddressBar"), GetWndClassName())

// Constants
	enum { s_kcxHeaderGap = 4 };

// Data members
	int m_cxDefaultHeader;
	CItemIDList m_idlHtml;	// used to draw .url icon faster


//	CContainedWindow m_wndReBar;

	CDonutAddressBar() : m_cxDefaultHeader(0)
	{
		m_idlHtml = MtlGetHtmlFileIDList();
	}

	~CDonutAddressBar()
	{
	}

// Methods
	void InitReBarBandInfo(CReBarCtrl rebar)
	{
		int nIndex = rebar.IdToIndex(GetDlgCtrlID());

		CVersional<REBARBANDINFO> rbBand;
		rbBand.fMask = RBBIM_HEADERSIZE;
		MTLVERIFY(rebar.GetBandInfo(nIndex, &rbBand));
		m_cxDefaultHeader = rbBand.cxHeader;

		// Calculate the header of the band
		HFONT hFont = m_font.m_hFont;
		if (hFont==NULL) hFont = rebar.GetFont();
		int nWidth = MtlComputeWidthOfText(_T("�A�h���X"), hFont); // UDT JOBBY (remove (&D))
		if (!(m_dwAddressBarExtendedStyle&ABR_EX_TEXTVISIBLE))
			nWidth = 0;

		rbBand.cxHeader = m_cxDefaultHeader + nWidth + s_kcxHeaderGap;
	}

	// U.H
	void ShowAddresText(CReBarCtrl rebar, BOOL bShow)
	{
		SIZE size;
		m_wndGo.GetButtonSize(size);
		if (bShow)
		{
			m_cxGoBtn = _CalcBtnWidth(m_szGoIcon.cx, _T("�ړ�"));
			m_wndGo.SetButtonSize(CSize(m_cxGoBtn, size.cy));
		}
		else
		{
			m_cxGoBtn = _CalcBtnWidth(m_szGoIcon.cx, _T(""));
			m_wndGo.SetButtonSize(CSize(m_cxGoBtn, size.cy));
		}

		CRect rect;
		GetWindowRect(rect);
		CWindow(GetParent()).ScreenToClient(rect);

		SetWindowPos(NULL, rect.left, rect.top,
				rect.right - rect.left - 1, rect.bottom - rect.top,
				SWP_NOZORDER|SWP_NOREDRAW);// | SWP_NOACTIVATE);

		SetWindowPos(NULL, rect.left, rect.top,
				rect.right - rect.left, rect.bottom - rect.top,
				SWP_NOZORDER);// | SWP_NOACTIVATE);
	}

	// required for stupid OnCustomDraw including pT->SetMsgHandled
	void SetMsgHandled(BOOL bHandled)
	{
		CAddressBarCtrlImpl<CDonutAddressBar>::SetMsgHandled(bHandled);
	}

	BOOL IsMsgHandled() const
	{
		return CAddressBarCtrlImpl<CDonutAddressBar>::IsMsgHandled();
	}

/*	BEGIN_MSG_MAP(CDonutAddressBar)
		CHAIN_MSG_MAP(CAddressBarCtrlImpl<CDonutAddressBar>)
	ALT_MSG_MAP(1)
		CHAIN_MSG_MAP_ALT(CAddressBarCtrlImpl<CDonutAddressBar>, 1)
	ALT_MSG_MAP(2)
		CHAIN_MSG_MAP_ALT(CAddressBarCtrlImpl<CDonutAddressBar>, 2)
	END_MSG_MAP()
*/

// Custom draw overrides
	DWORD OnPrePaint(int /*idCtrl*/, LPNMCUSTOMDRAW /*lpNMCustomDraw*/)
	{
		return CDRF_NOTIFYITEMDRAW;	// we need per-item notifications
	}

	// OnItemPostPaint not called
	DWORD OnItemPrePaint(int idCtrl, LPNMCUSTOMDRAW lpNMCustomDraw)
	{
		abrTRACE(_T("CDonutAddressBar::OnItemPrePaint : dwItemSpec(%d), uItemState(%d)\n"),
			lpNMCustomDraw->dwItemSpec, lpNMCustomDraw->uItemState);

		if (lpNMCustomDraw->dwItemSpec != GetDlgCtrlID())
			return CDRF_DODEFAULT;

		if (m_cxDefaultHeader == 0)// InitReBarBandInfo maybe not called, do nothing.
			return CDRF_DODEFAULT;

		CDCHandle dc = lpNMCustomDraw->hdc;
		RECT& rc = lpNMCustomDraw->rc;
		rc.left += m_cxDefaultHeader;

		return CDRF_DODEFAULT;	// continue with the default item painting
	}

// Methods

// Overrides
	void OnItemSelected(const CString& str)
	{
		DWORD dwOpenFlags = 0;
		if (!_check_flag(ABR_EX_OPENNEWWIN, GetAddressBarExtendedStyle()))
			dwOpenFlags |= D_OPENFILE_NOCREATE;
		if (!_check_flag(ABR_EX_NOACTIVATE, GetAddressBarExtendedStyle()))
			dwOpenFlags |= D_OPENFILE_ACTIVATE;

		DonutToggleOpenFlag(dwOpenFlags);
		HWND hWndNew = DonutOpenFile(m_hWnd, str, dwOpenFlags);
	}

	void OnItemSelectedEx(const CString& str)
	{
		DWORD dwOpenFlags = 0;
		if (!_check_flag(ABR_EX_OPENNEWWIN, GetAddressBarExtendedStyle()))
			dwOpenFlags |= D_OPENFILE_NOCREATE;
		if (!_check_flag(ABR_EX_NOACTIVATE, GetAddressBarExtendedStyle()))
			dwOpenFlags |= D_OPENFILE_ACTIVATE;

		if (!_check_flag(ABR_EX_ENTER_CTRL, GetAddressBarExtendedStyle()))
		{
			if (::GetAsyncKeyState(VK_CONTROL) < 0)
			{
				if (_check_flag(D_OPENFILE_NOCREATE, dwOpenFlags))
					dwOpenFlags &= ~D_OPENFILE_NOCREATE;
				else
					dwOpenFlags |= D_OPENFILE_NOCREATE;
			}
		}
			
		if (!_check_flag(ABR_EX_ENTER_SHIFT, GetAddressBarExtendedStyle()))
		{
			if (::GetAsyncKeyState(VK_SHIFT) < 0)
			{
				if (_check_flag(D_OPENFILE_NOCREATE, dwOpenFlags))
					dwOpenFlags &= ~D_OPENFILE_NOCREATE;
				else
					dwOpenFlags |= D_OPENFILE_NOCREATE;
			}
		}

		HWND hWndNew = DonutOpenFile(m_hWnd, str, dwOpenFlags);
	}

	void OnGetItem(const CString& str, COMBOBOXEXITEM& item)
	{
		item.mask = CBEIF_TEXT | CBEIF_IMAGE | CBEIF_SELECTEDIMAGE;// | CBEIF_OVERLAY;

		int nImage;// = 2;
/*		if (str.IsEmpty())
			nImage = -1;

		if (str.Find(_T(':')) == 1 || MtlIsProtocol(str, _T("file"))) {// maybe local directory
			if (str.ReverseFind('/') == str.GetLength() - 1 ||
				str.ReverseFind('\\') == str.GetLength() - 1)
			{
				nImage = 0;
			}
			else if (str.ReverseFind(_T('/')) > str.ReverseFind(_T('.')) ||
				str.ReverseFind(_T('\\')) > str.ReverseFind(_T('.')))
			{
				nImage = 0;
			}
		}
*/
		nImage = I_IMAGECALLBACK;
		item.iImage = nImage;
		item.iSelectedImage = nImage;
		item.iOverlay = nImage;
	}

	void OnGetDispInfo(COMBOBOXEXITEM& item)
	{
		abrTRACE(_T("OnGetDispInfo(%s)\n"), item.pszText);
		if (!_check_flag(CBEIF_IMAGE, item.mask) &&
			!_check_flag(CBEIF_SELECTEDIMAGE, item.mask))
			return;

		CString str;
		if (GetDroppedState()) {
			MtlGetLBTextFixed(GetComboCtrl(), item.iItem, str);
		}
		else {
			str = MtlGetWindowText(GetEditCtrl());
		}

		if (str.IsEmpty())
			return;

		CItemIDList idl = str;
		if (idl.IsNull()) {// invalid idl
			int iImage = MtlGetSystemIconIndex(m_idlHtml);
			item.iImage = iImage;
			item.iSelectedImage = iImage;
			return;
		}

		if (item.mask & CBEIF_IMAGE) {
			item.iImage = MtlGetNormalIconIndex(idl, m_idlHtml);
		}

		if (item.mask & CBEIF_SELECTEDIMAGE) {
			item.iSelectedImage = MtlGetSelectedIconIndex(idl, true, m_idlHtml);
		}

/*
		CItemIDlist idl = str;
		if (MtlGet

		if (str.IsEmpty())
			nImage = -1;

		if (str.Find(_T(':')) == 1 || MtlIsProtocol(str, _T("file"))) {// maybe local directory
			if (str.ReverseFind('/') == str.GetLength() - 1 ||
				str.ReverseFind('\\') == str.GetLength() - 1)
			{
				nImage = 0;
			}
			else if (str.ReverseFind(_T('/')) > str.ReverseFind(_T('.')) ||
				str.ReverseFind(_T('\\')) > str.ReverseFind(_T('.')))
			{
				nImage = 0;
			}
		}

//		item.mask = CBEIF_IMAGE | CBEIF_SELECTEDIMAGE;

		item.iImage = nImage;
		item.iSelectedImage = nImage;
	*/
	}

	void OnInit()
	{
//		MTLVERIFY(_LoadImages(IDB_LINKBAR, 16, 16, RGB(255, 0, 255)));
		_SetSystemImageList();

		COMBOBOXEXITEM item;
		item.mask = CBEIF_IMAGE | CBEIF_SELECTEDIMAGE;
		item.iItem = -1;// on edit control
		item.iImage = I_IMAGECALLBACK;
		item.iSelectedImage = I_IMAGECALLBACK;
		MTLVERIFY(SetItem(&item));

		RegisterDragDrop();
	}

	void OnTerm()
	{
		RevokeDragDrop();
	}

// Implementation

// IDropTargetImpl
	bool m_bDragAccept;


	DROPEFFECT OnDragEnter(IDataObject* pDataObject, DWORD dwKeyState, CPoint point)
	{
		if (m_bDragFromItself)
			return DROPEFFECT_NONE;

		_DrawDragEffect(false);

		m_bDragAccept = _MtlIsHlinkDataObject(pDataObject);
		return _MtlStandardDropEffect(dwKeyState);
	}

	DROPEFFECT OnDragOver(IDataObject* pDataObject, DWORD dwKeyState, CPoint point, DROPEFFECT dropOkEffect)
	{
		if (m_bDragFromItself || !m_bDragAccept)
			return DROPEFFECT_NONE;

		return _MtlStandardDropEffect(dwKeyState) | _MtlFollowDropEffect(dropOkEffect) | DROPEFFECT_COPY;
	}
	void OnDragLeave()
	{
		if (m_bDragFromItself)
			return;

		_DrawDragEffect(true);
	}

	void _DrawDragEffect(bool bRemove)
	{
		CClientDC dc(m_wndCombo.m_hWnd);

		CRect rect; m_wndCombo.GetClientRect(rect);

		if (bRemove)
			MtlDrawDragRectFixed(dc.m_hDC, &rect, CSize(0, 0), &rect, CSize(2, 2), NULL, NULL);
		else
			MtlDrawDragRectFixed(dc.m_hDC, &rect, CSize(2, 2), NULL, CSize(2, 2),	NULL, NULL);
	}

	DROPEFFECT OnDrop(IDataObject* pDataObject,	DROPEFFECT dropEffect,
		DROPEFFECT dropEffectList, CPoint point)
	{
		if (m_bDragFromItself)
			return DROPEFFECT_NONE;

		_DrawDragEffect(true);

		CSimpleArray<CString> arrFiles;
		if (MtlGetDropFileName(pDataObject, arrFiles)) {
			// one file
			if (arrFiles.GetSize() == 1) {
				OnItemSelected(arrFiles[0]);// allow to AddressBar style
				return DROPEFFECT_COPY;
			}

			// files
			for (int i = 0; i < arrFiles.GetSize(); ++i) {
				DonutOpenFile(m_hWnd, arrFiles[i]);
			}
			dropEffect = DROPEFFECT_COPY;
			return true;
		}

		CString strText;
		if ( MtlGetHGlobalText(pDataObject, strText) ||
			 MtlGetHGlobalText(pDataObject, strText, ::RegisterClipboardFormat(CFSTR_SHELLURL)) )
		{
			OnItemSelected(strText);
			return DROPEFFECT_COPY;
		}

		return DROPEFFECT_NONE;
	}

	HRESULT OnGetAddressBarCtrlDataObject(IDataObject** ppDataObject)
	{
		ATLASSERT(ppDataObject != NULL);

		HRESULT hr = CHlinkDataObject::_CreatorClass::CreateInstance(NULL, IID_IDataObject, (void**)ppDataObject);
		if (FAILED(hr)) {
			*ppDataObject = NULL;
			return E_NOTIMPL;
		}

#ifdef _ATL_DEBUG_INTERFACES
		ATLASSERT(FALSE && _T("_ATL_DEBUG_INTERFACES crashes the following\n"));
#endif
		CHlinkDataObject* pHlinkDataObject = NULL;// this is hack, no need to release
		hr = (*ppDataObject)->QueryInterface(IID_NULL, (void**)&pHlinkDataObject);
		if (SUCCEEDED(hr)) {
			HWND hWnd = DonutGetActiveWindow(GetTopLevelParent());
			if (hWnd == NULL)
				return E_NOTIMPL;

			ATLASSERT(::IsWindow(hWnd));
			CWebBrowser2 browser = DonutGetIWebBrowser2(hWnd);
			if (browser.IsBrowserNull())
				return E_NOTIMPL;

			CString strName = MtlGetWindowText(hWnd);
			CString strUrl = browser.GetLocationURL();
			if (strUrl.IsEmpty())
				return E_NOTIMPL;

			if (strUrl.Left(5) == _T("file:")) {// Donut, to be explorer or not
				strName.Empty();
				strUrl = strUrl.Right(strUrl.GetLength() - 8);
				strUrl.Replace(_T('/'), _T('\\'));
			}
			pHlinkDataObject->m_arrNameAndUrl.Add(std::make_pair(strName, strUrl));
		}

		return S_OK;
	}

	void _SetSystemImageList()
	{
		ATLASSERT(::IsWindow(m_hWnd));

		SHFILEINFO sfi;
		HIMAGELIST hImgs = (HIMAGELIST)::SHGetFileInfo(_T("C:\\"), 0, &sfi, sizeof(sfi),
			SHGFI_SYSICONINDEX | SHGFI_SMALLICON);
		
		ATLASSERT(hImgs != NULL);
		SetImageList(hImgs);
	}
};

class CDonutAddressBarPropertyPage : public CPropertyPageImpl<CDonutAddressBarPropertyPage>,
	public CWinDataExchange<CDonutAddressBarPropertyPage>
{
public:
// Constants
	enum { IDD = IDD_PROPPAGE_ADDRESSBAR };

// Data members
	int m_nAutoComplete, m_nNewWin, m_nNoActivate, m_nLoadTypedUrls, m_nGoBtnVisible;
	CDonutAddressBar& m_AddressBar;
	CDonutSearchBar& m_SearchBar; //minit

	// UH
	CString m_strEnterCtrl, m_strEnterShift;
	int m_nUseEnterCtrl, m_nUseEnterShift, m_nTextVisible;

	//minit
	int m_nReplaceSpace;
	BOOL m_bInit;
	BOOL m_bAddCtrl, m_bAddShift;

// DDX map
	BEGIN_DDX_MAP(CDonutAddressBarPropertyPage)
		DDX_CHECK(IDC_CHECK_ABR_AUTOCOMPLETE, m_nAutoComplete)
		DDX_CHECK(IDC_CHECK_ABR_NEWWIN, m_nNewWin)
		DDX_CHECK(IDC_CHECK_ADB_NOACTIVATE, m_nNoActivate)
		DDX_CHECK(IDC_CHECK_ABR_LOADTYPEDURLS, m_nLoadTypedUrls)
		DDX_CHECK(IDC_CHECK_ABR_GOBTNVISIBLE, m_nGoBtnVisible)
		DDX_CHECK(IDC_CHECK_ABR_TEXTVISIBLE, m_nTextVisible)

		// UH
		//DDX_TEXT(IDC_EDIT_CTRL_ENTER, m_strEnterCtrl)
		//DDX_TEXT(IDC_EDIT_SHIFT_ENTER, m_strEnterShift)
		DDX_CHECK(IDC_CHECK_CTRL_ENTER, m_nUseEnterCtrl)
		DDX_CHECK(IDC_CHECK_SHIFT_ENTER, m_nUseEnterShift)
		//minit
		DDX_CHECK(IDC_CHECK_REPLACE,m_nReplaceSpace)
	END_DDX_MAP()


// Constructor
	CDonutAddressBarPropertyPage(CDonutAddressBar& adBar, CDonutSearchBar& searchBar) 
		: m_AddressBar(adBar), m_SearchBar(searchBar), m_bInit(FALSE), m_bAddCtrl(FALSE), m_bAddShift(FALSE)
	{
		_SetData();
	}

// Overrides
	BOOL OnSetActive()
	{
		if(!m_bInit){
			InitComboBox();
			m_bInit = TRUE;
		}

		SetModified(TRUE);
		return DoDataExchange(FALSE);
	}
	BOOL OnKillActive()
	{
		return DoDataExchange(TRUE);
	}
	BOOL OnApply()
	{
		if (DoDataExchange(TRUE)) {
			_GetData();
			return TRUE;
		}
		else 
			return FALSE;
	}

// Implementation
protected:
	void _GetData()
	{
		// update  flags
		DWORD dwFlags = 0;
		if (m_nAutoComplete == 1) {
			dwFlags |= ABR_EX_AUTOCOMPLETE;
		}
		if (m_nNewWin == 1) {
			dwFlags |= ABR_EX_OPENNEWWIN;
		}
		if (m_nNoActivate == 1) {
			dwFlags |= ABR_EX_NOACTIVATE;
		}
		if (m_nNewWin == 1) {
			dwFlags |= ABR_EX_OPENNEWWIN;
		}
		if (m_nLoadTypedUrls == 1) {
			dwFlags |= ABR_EX_LOADTYPEDURLS;
		}
		if (m_nGoBtnVisible == 1) {
			dwFlags |= ABR_EX_GOBTNVISIBLE;
		}
		// U.H
		if (m_nTextVisible ==1){
			dwFlags |= ABR_EX_TEXTVISIBLE;
		}
		if (m_nUseEnterCtrl==1){
			dwFlags |= ABR_EX_ENTER_CTRL;
		}
		if (m_nUseEnterShift==1){
			dwFlags |= ABR_EX_ENTER_SHIFT;
		}
		if (m_nReplaceSpace==1){
			dwFlags |= ABR_EX_SEARCH_REPLACE;
		}

		m_AddressBar.SetAddressBarExtendedStyle(dwFlags);

		CIniSection pr;
		pr.Open(_szIniFileName, _T("AddresBar"));
		//pr.SetValue(m_strEnterCtrl, _T("EnterCtrl"));
		//pr.SetValue(m_strEnterShift, _T("EnterShift"));

		CComboBox cmbCtrl = GetDlgItem(IDC_COMBO_CTRL_ENTER);
		CComboBox cmbShift = GetDlgItem(IDC_COMBO_SHIFT_ENTER);
		CString strBufCtrl, strBufShift;
		int idx;
		idx = cmbCtrl.GetCurSel();
		if(idx != CB_ERR) cmbCtrl.GetLBText(idx,strBufCtrl);
		if(strBufCtrl.Find(_T("��")) != 0){
			if(m_bAddCtrl) idx = idx -1;
			pr.SetValue(idx,_T("EnterCtrlIndex"));
			pr.SetValue(strBufCtrl,_T("EnterCtrlEngin"));
			pr.SetValue(CDonutSearchBar::GetSearchIniPath(),_T("EnterCtrlPath"));
		}
		idx = cmbShift.GetCurSel();
		if(idx != CB_ERR) cmbShift.GetLBText(idx,strBufShift);
		if(strBufShift.Find(_T("��")) != 0){
			if(m_bAddShift) idx = idx -1;
			pr.SetValue(idx,_T("EnterShiftIndex"));
			pr.SetValue(strBufShift,_T("EnterShiftEngin"));
			pr.SetValue(CDonutSearchBar::GetSearchIniPath(),_T("EnterShiftPath"));
		}

		pr.Close();
	}

	void _SetData()
	{
		DWORD dwFlags = m_AddressBar.GetAddressBarExtendedStyle();

		m_nAutoComplete = _check_flag(ABR_EX_AUTOCOMPLETE, dwFlags) ? 1 : 0;
		m_nNewWin = _check_flag(ABR_EX_OPENNEWWIN, dwFlags) ? 1 : 0;
		m_nNoActivate = _check_flag(ABR_EX_NOACTIVATE, dwFlags) ? 1 : 0;
		m_nLoadTypedUrls = _check_flag(ABR_EX_LOADTYPEDURLS, dwFlags) ? 1 : 0;
		m_nGoBtnVisible = _check_flag(ABR_EX_GOBTNVISIBLE, dwFlags) ? 1 : 0;

		// vvv UH vvv
		m_nTextVisible = _check_flag(ABR_EX_TEXTVISIBLE, dwFlags) ? 1 : 0;
		m_nUseEnterCtrl = _check_flag(ABR_EX_ENTER_CTRL, dwFlags) ? 1 : 0;
		m_nUseEnterShift = _check_flag(ABR_EX_ENTER_SHIFT, dwFlags) ? 1 : 0;
		//minit
		m_nReplaceSpace = _check_flag(ABR_EX_SEARCH_REPLACE,dwFlags) ? 1 : 0;

		/*
		TCHAR cBuff[MAX_PATH];
		DWORD dwCount=MAX_PATH;

		CIniSection pr;
		pr.Open(_szIniFileName, _T("AddresBar"));
		pr.QueryValue(cBuff, _T("EnterCtrl"), &dwCount);

		
		CString strEnterCtrl(cBuff);
		if (strEnterCtrl.IsEmpty())
			m_strEnterCtrl = _T("http://www.google.com/search?lr=lang_ja&q=");
		else
			m_strEnterCtrl = strEnterCtrl;
			
		pr.QueryValue(cBuff, _T("EnterShift"), &dwCount);
		CString strEnterShift(cBuff);
		if (strEnterShift.IsEmpty())
			m_strEnterShift = _T("http://www.excite.co.jp/world/url/proceeding/?wb_url=");
		else
			m_strEnterShift = strEnterShift;
		//^^^ UH ^^^
	
		pr.Close();
		*/
	}

	void InitComboBox()
	{
		
		CComboBox cmbCtrl = GetDlgItem(IDC_COMBO_CTRL_ENTER);
		CComboBox cmbShift = GetDlgItem(IDC_COMBO_SHIFT_ENTER);
		CString strBuf;
		int nCount = m_SearchBar.m_cmbEngin.GetCount();
		for(int i=0; i<nCount; i++){
			m_SearchBar.m_cmbEngin.GetLBText(i,strBuf);
			cmbCtrl.AddString(strBuf);
			cmbShift.AddString(strBuf);
		}
	
		DWORD idxCtrl = 0 , idxShift = 0;
		CString strPathCtrl, strPathShift;
		CString strEnginCtrl, strEnginShift;
		CIniSection pr;

		pr.Open(_szIniFileName, _T("AddresBar"));
		pr.QueryValue(idxCtrl,_T("EnterCtrlIndex"));
		pr.QueryValue(idxShift,_T("EnterShiftIndex"));
		pr.QueryString(strPathCtrl,_T("EnterCtrlPath"),MAX_PATH);
		pr.QueryString(strPathShift,_T("EnterShiftPath"),MAX_PATH);
		pr.QueryString(strEnginCtrl,_T("EnterCtrlEngin"),MAX_PATH);
		pr.QueryString(strEnginShift,_T("EnterShiftEngin"),MAX_PATH);
		pr.Close();

		//�܂����d�l�̏ꍇ�iSearch.ini�I�����[�j
		if(strPathCtrl.IsEmpty()){
			//�����t�@�C�����ύX����Ă�����ȑO�̓o�^�G���W���ɂ́�������
			if(CDonutSearchBar::GetSearchIniPath() != _GetFilePath(_T("Search.ini"))){
				CString strText = _T("��") + strEnginCtrl;
				cmbCtrl.InsertString(0,strText);
				strText = _T("��") + strEnginShift;
				cmbShift.InsertString(0,strText);
				cmbCtrl.SetCurSel(0);
				cmbShift.SetCurSel(0);
				m_bAddCtrl = m_bAddShift = TRUE;
			}else{
				//���S�ɋ��d�l�ʂ�ɓ���
				cmbCtrl.SetCurSel(idxCtrl);
				cmbShift.SetCurSel(idxShift);
			}
		}else{
			//�ݒ莞�̌����t�@�C���ƍ��̃t�@�C�����قȂ�ꍇ�͈ȑO�̃G���W���Ɂ������Ēǉ�
			if(CDonutSearchBar::GetSearchIniPath() != strPathCtrl){
				CString strText = _T("��") + strEnginCtrl;
				cmbCtrl.InsertString(0,strText);
				cmbCtrl.SetCurSel(0);
				m_bAddCtrl = TRUE;
			}else{
				cmbCtrl.SetCurSel(idxCtrl);
			}

			if(CDonutSearchBar::GetSearchIniPath() != strPathShift){
				CString strText = _T("��") + strEnginShift;
				cmbShift.InsertString(0,strText);
				cmbShift.SetCurSel(0);
				m_bAddShift = TRUE;
			}else{
				cmbShift.SetCurSel(idxShift);
			}
		}
		
	}
};

////////////////////////////////////////////////////////////////////////////
} // namespace MTL;

#ifndef _MTL_NO_AUTOMATIC_NAMESPACE
using namespace MTL;
#endif //!_MTL_NO_AUTOMATIC_NAMESPACE