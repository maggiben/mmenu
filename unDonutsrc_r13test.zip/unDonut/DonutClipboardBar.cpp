#include "stdafx.h"
#include "DonutClipboardBar.h"
#include "Donut.h"
#include "DonutPFunc.h"
#include "option/MainOption.h"

// Ctor
CDonutClipboardBar::CDonutClipboardBar()
	: m_dwExStyle(0), m_box(this, 1)
{
}

// Methods
CString CDonutClipboardBar::GetExtsList()
{
	return MtlGetWindowText(m_edit);
}

void CDonutClipboardBar::OpenClipboardUrl()
{
	CString strText = MtlGetClipboardText();
	if (strText.IsEmpty())
		return;

	CSimpleArray<CString> arrExt;
	MtlBuildExtArray(arrExt, GetExtsList());

	CSimpleArray<CString> arrUrl;
	MtlBuildUrlArray(arrUrl, arrExt, strText);

	for (int i = 0; i < arrUrl.GetSize(); ++i) {
		DonutOpenFile(m_hWnd, arrUrl[i], 0);					
	}
}

// Overrides
void CDonutClipboardBar::OnUpdateClipboard()
{
	if (CMainOption::s_bIgnoreUpdateClipboard)
		return;

	clbTRACE(_T("OnUpdateClipboard\n"));
	CString strText = MtlGetClipboardText();
	if (strText.IsEmpty())
		return;

	CWebBrowser2 browser = DonutGetIWebBrowser2(GetTopLevelParent());
	if (!browser.IsBrowserNull()) {
		CString strUrl = browser.GetLocationURL();
		if (strUrl == strText)
			return;
	}

	if (_check_flag(CLPV_EX_FLUSH, m_dwExStyle))
		m_box.ResetContent();
		
	CSimpleArray<CString> arrExt;
	MtlBuildExtArray(arrExt, MtlGetWindowText(m_edit));

	CSimpleArray<CString> arrUrl;
	MtlBuildUrlArray(arrUrl, arrExt, strText);

	if (arrUrl.GetSize() == 0) {
		return;
	}
	else {
		if (_check_flag(CLPV_EX_FLUSH, m_dwExStyle))
			m_box.ResetContent();
	}

	for (int i = 0; i < arrUrl.GetSize(); ++i) {
		if (m_box.GetCount() == 0)
			m_box.AddString(arrUrl[i]);
		else
			m_box.InsertString(0, arrUrl[i]);
	}

	if (_check_flag(CLPV_EX_DIRECT, m_dwExStyle)) {
		for (int i = 0; i < arrUrl.GetSize(); ++i) {
			DonutOpenFile(m_hWnd, arrUrl[i], 0);					
		}
	}
}

// Methods	
BYTE CDonutClipboardBar::PreTranslateMessage(MSG* pMsg)
{
	UINT msg = pMsg->message;
	int vKey =  pMsg->wParam;
	HWND hWnd = pMsg->hwnd;

	if (m_hWnd==NULL)
		return _MTL_TRANSLATE_PASS;

	if (msg == WM_KEYDOWN) {
		if (hWnd != m_edit.m_hWnd && ::GetKeyState(VK_CONTROL) < 0)	// may be accelerator
			return _MTL_TRANSLATE_PASS;
	}
	else if (msg == WM_SYSKEYDOWN) {								// I gave up to add accesskeys to bar 
			return _MTL_TRANSLATE_PASS;
	}

	if (IsDialogMessage(pMsg))// is very smart.
		return _MTL_TRANSLATE_HANDLE;

	return _MTL_TRANSLATE_PASS;
}


LRESULT CDonutClipboardBar::OnInitDialog(UINT /*uMsg*/, WPARAM /*wParam*/, LPARAM /*lParam*/, BOOL& /*bHandled*/)
{
	DlgResize_Init(false, true, WS_CLIPCHILDREN);

	m_edit.Attach(GetDlgItem(IDC_EDIT_CB_EXT));
	m_box.SubclassWindow(GetDlgItem(IDC_LIST_CB_CONT));

	_GetProfile();
	_SetData();
	DoDataExchange(FALSE);
	
	return TRUE;
}

LRESULT CDonutClipboardBar::OnDestroy(UINT /*uMsg*/, WPARAM /*wParam*/, LPARAM /*lParam*/, BOOL& /*bHandled*/)
{
	DoDataExchange(TRUE);
	_GetData();
	_WriteProfile();

	return 0;
}

LRESULT CDonutClipboardBar::OnCheckCommand(WORD wNotifyCode, WORD wID, HWND /*hWndCtl*/, BOOL& /*bHandled*/)
{
	if (wNotifyCode == BN_CLICKED) {
		DoDataExchange(TRUE);
		_GetData();
	}

	return 0;
}

LRESULT CDonutClipboardBar::OnButtonDelete(WORD wNotifyCode, WORD wID, HWND /*hWndCtl*/, BOOL& /*bHandled*/)
{
	_MtlForEachListBoxSelectedItem(m_box.m_hWnd, _Function_DeleteString());

	return 0;
}

LRESULT CDonutClipboardBar::OnButtonOpen(WORD wNotifyCode, WORD wID, HWND /*hWndCtl*/, BOOL& /*bHandled*/)
{
	_MtlForEachListBoxSelectedItem(m_box.m_hWnd, _Function_Open());

	return 0;
}

LRESULT CDonutClipboardBar::OnButtonPaste(WORD wNotifyCode, WORD wID, HWND /*hWndCtl*/, BOOL& /*bHandled*/)
{
	OnUpdateClipboard();

	return 0;
}

LRESULT CDonutClipboardBar::OnButtonPasteDonut(WORD wNotifyCode, WORD wID, HWND /*hWndCtl*/, BOOL& /*bHandled*/)
{
	OpenClipboardUrl();

	return 0;
}

LRESULT CDonutClipboardBar::OnButtonDeleteAll(WORD wNotifyCode, WORD wID, HWND /*hWndCtl*/, BOOL& /*bHandled*/)
{
	m_box.ResetContent();

	return 0;
}

LRESULT CDonutClipboardBar::OnIdOk(WORD wNotifyCode, WORD wID, HWND /*hWndCtl*/, BOOL& /*bHandled*/)
{
	if (::GetFocus() == m_box.m_hWnd)
		_MtlForEachListBoxSelectedItem(m_box.m_hWnd, _Function_Open());

	return 0;
}

LRESULT CDonutClipboardBar::OnLBLButtonDblClk(UINT /*uMsg*/, WPARAM /*wParam*/, LPARAM lParam, BOOL& /*bHandled*/)
{
	CPoint pt(LOWORD(lParam), HIWORD(lParam));

	BOOL bOutside;
	UINT nIndex = m_box.ItemFromPoint(pt, bOutside);
	if (!bOutside)
		_OnItemOpen(nIndex);

	return 0;
}


// Implementation
void CDonutClipboardBar::_GetData()
{
	// update style
	m_dwExStyle = 0;

	if (m_nOn == 1)
		m_dwExStyle |= CLPV_EX_ON;
	if (m_nDirect == 1)
		m_dwExStyle |= CLPV_EX_DIRECT;
	if (m_nFlush == 1)
		m_dwExStyle |= CLPV_EX_FLUSH;

	if (_check_flag(CLPV_EX_ON, m_dwExStyle))
		InstallClipboardViewer();
	else
		UninstallClipboardViewer();
}

void CDonutClipboardBar::_SetData()
{
	m_nOn = _check_flag(CLPV_EX_ON, m_dwExStyle) ? 1 : 0;
	m_nDirect = _check_flag(CLPV_EX_DIRECT, m_dwExStyle) ? 1 : 0;
	m_nFlush = _check_flag(CLPV_EX_FLUSH, m_dwExStyle) ? 1 : 0;
}

void CDonutClipboardBar::_GetProfile()
{
	CIniSection pr;

	pr.Open(MtlGetChangedExtFromModuleName(_T(".ini")), _T("ClipboardBar"));
	pr.QueryValue(m_dwExStyle, _T("Extended_Style"));

	DWORD dwCount = 4096;
	TCHAR szExts[4096];
	if (pr.QueryValue(szExts, _T("Ext_List"), &dwCount) != ERROR_SUCCESS)
		::lstrcpyn(szExts, _T("/;html;htm;shtml;cgi;asp;com;net;jp;lnk;url;"), 4096);	

	m_strExts = szExts;

	if (_check_flag(CLPV_EX_ON, m_dwExStyle))
		InstallClipboardViewer();
}

void CDonutClipboardBar::_WriteProfile()
{
	CIniSection pr;

	pr.Open(MtlGetChangedExtFromModuleName(_T(".ini")), _T("ClipboardBar"));
	pr.SetValue(m_dwExStyle, _T("Extended_Style"));
	pr.SetValue(m_strExts,  _T("Ext_List"));

	UninstallClipboardViewer();
}



void CDonutClipboardBar::_OnItemOpen(int nIndex)
{
	clbTRACE(_T("_OnItemOpen\n"));
	CString str;
	MtlListBoxGetText(m_box.m_hWnd, nIndex, str);
	if (str.IsEmpty())
		return;

	DonutOpenFile(m_hWnd, str, 0);
}








CString CDonutClipBoardBarContainer::GetExtsList()
{
	return m_ClipBar.GetExtsList();
}

void CDonutClipBoardBarContainer::OpenClipboardUrl()
{
	m_ClipBar.OpenClipboard();
}

BYTE CDonutClipBoardBarContainer::PreTranslateMessage(MSG* pMsg)
{
	return m_ClipBar.PreTranslateMessage(pMsg);
}

LRESULT CDonutClipBoardBarContainer::OnCreate(UINT /*uMsg*/, WPARAM /*wParam*/, LPARAM /*lParam*/, BOOL& bHandled)
{
	bHandled = FALSE;
	m_ClipBar.Create(m_hWnd);
	return 0;
}

LRESULT CDonutClipBoardBarContainer::OnSize(UINT /*uMsg*/, WPARAM /*wParam*/, LPARAM /*lParam*/, BOOL& bHandled)
{
	bHandled = FALSE;
	CRect rc;
	GetClientRect(&rc);
	m_ClipBar.MoveWindow(&rc);
	return 0;
}