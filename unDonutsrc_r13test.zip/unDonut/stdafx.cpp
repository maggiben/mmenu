// stdafx.cpp : source file that includes just the standard includes
//	Donut.pch will be the pre-compiled header
//	stdafx.obj will contain the pre-compiled type information

#include "stdafx.h"

//#include <atlimpl.cpp> //obsolete
#ifdef _ATL_STATIC_REGISTRY

#include <DockImpl.cpp>

#include <statreg.h>
//#include <statreg.cpp>
#endif

#ifdef USE_MEMORYLOG
#ifdef _DEBUG
//http://www.sun-inet.or.jp/~yaneurao/rsp/rspD0toD7.html(D3��)���Q�l�ɂ��܂����B
//�L���ɂ���ƃ��O��f���̂�memcheck.pl���g���ĉ���R����m�F���Ă��������B
void* operator new (size_t t){
	if(t==0) t=1;
	void *p = ::malloc(t);
	FILE* fp = fopen("memory_log.txt","aw+");
	fprintf(fp,"new %.8x :%d\n",p,t);
	fclose(fp);

	return p;
}


void* operator new[](size_t t){
	if(t==0) t=1;
	void *p = ::malloc(t);
	FILE* fp = fopen("memory_log.txt","aw+");
	fprintf(fp,"new %.8x :%d\n",p,t);
	fclose(fp);

	return p;
}

void operator delete(void*p){
	if (p==NULL) return ;

	FILE* fp = fopen("debug_memory.txt","aw+");
	fprintf(fp,"del %.8x\n",p);
	fclose(fp);

	::free(p);
}

void operator delete[](void*p){
	if (p==NULL) return ;

	FILE* fp = fopen("debug_memory.txt","aw+");
	fprintf(fp,"del %.8x\n",p);
	fclose(fp);

	::free(p);
}
#endif //_DEBUG
#endif //USE_MEMORYLOG