#ifndef __DONUTPFUNC_H__
#define __DONUTPFUNC_H__

#pragma once

#include "MtlMisc.h"
#include "MtlPrivateProfile.h"



#define	PI						3.141592653589793238462643383279
#define ANGLE_TO_RADIAN( a )	( (a)*PI/180.0 )
#define RADIAN_TO_ANGLE( a )	( (a)/PI*180.0 )

double _GetAngle(CPoint pt1, CPoint pt2);


BOOL _CheckOsVersion_98Later();
BOOL _CheckOsVersion_MELater();
BOOL _CheckOsVersion_2000Later();
BOOL _CheckOsVersion_XPLater();



CString _GetFilePath(CString strFile);
CString _GetDonutPath();
CString _GetBtnSkinDir();
CString _GetSkinDir();
CString _GetRecentCloseFile();

bool _LoadToolTipText(int nCmdID, CString& strText);


BOOL IsSJISLeadByte(BYTE c);


// strText �� nFirst �����ڂ���AnCount ���������擾���ĕԂ��B�}���`�o�C�g�����Ή���
CString RtlMbbStrMid(CString strText, const int& nFirst = 0, const int& nCount = 1);

CString RtlGetSelectedText(const WTL::CEdit& edit);
//EM_GETSEL��VisualStyle�K�p����UNICODE�I���������(UNICODE���`���Ȃ��ꍇ�ł�)�̂łȂ�Ƃ�����֐�
CString _GetSelectTextWtoA(CEdit &edit);
CString _GetSelectText(CEdit &edit);

BOOL _AddSimpleReBarBandCtrl(HWND hWndReBar, HWND hWndBand, int nID = 0, LPTSTR lpstrTitle = NULL, BOOL bNewRow = FALSE, int cxWidth = 0, BOOL bFullWidthAlways = FALSE);
bool FileWriteString(CString strFile, std::list<CString>* pString);
bool FileReadString(CString strFile, std::list<CString>* pString);

BOOL _SetCombboxCategory(CComboBox &cmb, HMENU hMenu);
BOOL _DontUseID(UINT uID);
void _PickUpCommandSub(HMENU hMenuSub, CComboBox &cmbCmd);
void _PickUpCommand(HMENU hMenu, int nPopup, CComboBox &cmbCmd);


//minit
BOOL _ReplaceImageList(CString strBmpFile,CImageList& imgs);
int _Pack(int hi, int low);
BOOL _QueryColorString(MTL::CIniSection& pr, COLORREF& col, LPCTSTR lpstrKey);






#endif
