
#pragma once

// for debug
#ifdef _DEBUG
	const bool _Mtl_DialogKiller_traceOn = false;
	#define dgkTRACE if (_Mtl_DialogKiller_traceOn) ATLTRACE
#else
	#define dgkTRACE
#endif
/*
// I never trust IE's interfaces.
class CDialogKiller
{
public:
	static HHOOK s_hCreateHook;
	static bool s_bValid;

	static bool IsInstalled()
	{
		return (s_hCreateHook != NULL);
	}

	static void Validate(bool bValid = true)
	{
		s_bValid = bValid;
	}

	static void InstallDialogKiller()
	{
		if (s_hCreateHook == NULL) {
			s_hCreateHook = ::SetWindowsHookEx(WH_CBT, CreateHookProc, _Module.GetModuleInstance(), GetCurrentThreadId());
			ATLASSERT(s_hCreateHook != NULL);
		}
	}

	static void UninstallDialogKiller()
	{
		if (s_hCreateHook != NULL)
			::UnhookWindowsHookEx(s_hCreateHook);

		s_hCreateHook = NULL;
	}

	static void OnDialogCreate(HWND hWndDlg)
	{
		CString str = MtlGetWindowText(hWndDlg);
		dgkTRACE(_T("OnDialogCreate\n"));
		CWindow wndDlg(hWndDlg);

		wndDlg.ModifyStyle(WS_VISIBLE, 0, SWP_NOACTIVATE);
		wndDlg.PostMessage(WM_COMMAND, MAKEWPARAM(IDCANCEL, 0));
		wndDlg.PostMessage(WM_COMMAND, MAKEWPARAM(IDOK, 0));
	}

	static void OnTridentDlgFrameCreate(HWND hWndDlg)
	{	
		CWindow wndDlg(hWndDlg);
		dgkTRACE(_T("OnTridentDlgFrameCreate\n"));
		DWORD dwStyle = wndDlg.GetStyle();
		if (dwStyle & WS_POPUPWINDOW) {
			dgkTRACE(_T(" kill the IE trident dialog!\n"));
			wndDlg.ModifyStyle(WS_VISIBLE, 0, SWP_NOACTIVATE);
//			wndDlg.PostMessage(WM_KEYDOWN, VK_RETURN);
			wndDlg.PostMessage(WM_CLOSE);
		}

//		The window don't have text yet.
//		if (str.Find(_T("�X�N���v�g")) != -1 && str.Find(_T("�G���[")) != -1) {
//			dgkTRACE(_T(" kill the IE trident dialog!\n"));

//			wndDlg.ModifyStyle(WS_VISIBLE, 0, SWP_NOACTIVATE);
//			wndDlg.PostMessage(WM_KEYDOWN, VK_ESCAPE);
//			wndDlg.PostMessage(WM_CLOSE);
//		}
	}

// Implementation - Hook procs
	static LRESULT CALLBACK CreateHookProc(int nCode, WPARAM wParam, LPARAM lParam)
	{
		LRESULT lRet = 0;

		if (nCode == HCBT_CREATEWND)
		{
			if (!s_bValid)
				return lRet;

			HWND hWndDlg = (HWND)wParam;

			TCHAR szClassName[40];
			::GetClassName(hWndDlg, szClassName, 40);
			dgkTRACE(_T("DialogKiller - HCBT_CREATEWND (%s)\n"), szClassName);

			if(!lstrcmp(_T("#32770"), szClassName))
				OnDialogCreate(hWndDlg);
			else if (!lstrcmp(_T("Internet Explorer_TridentDlgFrame"), szClassName))
				OnTridentDlgFrameCreate(hWndDlg);
		}
		else if(nCode < 0)
		{
			lRet = ::CallNextHookEx(s_hCreateHook, nCode, wParam, lParam);
		}

		return lRet;
	}
};

class CDialogKillerLock
{
public:
	bool m_bInstallReally;

	CDialogKillerLock()
	{
		CDialogKiller::Validate(false);
	}

	~CDialogKillerLock()
	{
		CDialogKiller::Validate(true);
	}
};
*/

class CDialogKiller2
{
public:
	static void KillDialog()
	{
		dgkTRACE(_T("KillDialog\n"));

		// I guess this is not so slow.
		MtlForEachTopLevelWindow(_T("#32770"), NULL, _Function_DialogFilter());
		MtlForEachTopLevelWindow(_T("Internet Explorer_TridentDlgFrame"), NULL, _Function_TridentFrameDlgFilter());
	}

	struct _Function_DialogFilter
	{
		bool operator()(HWND hWnd)
		{
			if (MtlIsWindowCurrentProcess(hWnd)) {
				CString strCaption = MtlGetWindowText(hWnd);
				if (_Filter_ActiveXWarningDialog(hWnd, strCaption))
					return true;

				if (_Filter_SecurityWarningDialog(hWnd, strCaption))
					return true;

				_Filter_OfflineDialog(hWnd, strCaption);
			}

			return true;
		}
	};

	struct _Function_TridentFrameDlgFilter
	{
		bool operator()(HWND hWnd)
		{
			if (MtlIsWindowCurrentProcess(hWnd)) {
				CString strCaption = MtlGetWindowText(hWnd);
				_Filter_ScriptErrorTridentDlgFrame(hWnd, strCaption);
			}

			return true;
		}
	};

	static bool _Filter_ScriptErrorTridentDlgFrame(CWindow wnd, const CString& strCaption)
	{
		if (strCaption.Find(_T("�X�N���v�g")) != -1 && strCaption.Find(_T("�G���[")) != -1)	{
//			wnd.ModifyStyle(WS_VISIBLE, 0, SWP_NOACTIVATE);
			wnd.SendMessage(WM_CLOSE);
//			wnd.SendMessage(WM_KEYDOWN, VK_ESCAPE);
			return true;
		}

		return false;
	}

	static bool _Filter_OfflineDialog(CWindow wnd, const CString& strCaption)
	{
		if (strCaption.Find(_T("�I�t���C���ł�")) != -1) {
			wnd.SendMessage(WM_COMMAND, MAKEWPARAM(IDCANCEL, 0));
			wnd.SendMessage(WM_COMMAND, MAKEWPARAM(IDOK, 0));
//			wnd.SendMessage(WM_KEYDOWN, VK_ESCAPE);
			return true;
		}

		return false;
	}

	static bool _Filter_SecurityWarningDialog(CWindow wnd, const CString& strCaption)
	{
		if (strCaption != _T("�Z�L�����e�B���"))
			return false;

		CWindow wndInner = wnd.GetDlgItem(0x0000FFFF);
		if (wndInner.m_hWnd == NULL)
			return false;

		CString strOneStaticText = MtlGetWindowText(wndInner.m_hWnd);
		if (strOneStaticText.Find(_T("���̃y�[�W�ɂ�")) != -1 && strOneStaticText.Find(_T("�ی�")) != -1) {
			wnd.SendMessage(WM_COMMAND, MAKEWPARAM(IDCANCEL, 0));
			wnd.SendMessage(WM_COMMAND, MAKEWPARAM(IDOK, 0));
//			wnd.SendMessage(WM_KEYDOWN, VK_ESCAPE);
			return true;
		}
		return false;
	}

	static bool _Filter_ActiveXWarningDialog(CWindow wnd, const CString& strCaption)
	{
		if (strCaption != _T("Microsoft Internet Explorer"))
			return false;

		CWindow wndInner = wnd.GetDlgItem(0x0000FFFF);
		if (wndInner.m_hWnd == NULL)
			return false;

		CString strOneStaticText = MtlGetWindowText(wndInner.m_hWnd);
		if (strOneStaticText.Find(_T("ActiveX")) != -1 && strOneStaticText.Find(_T("���S")) != -1) {
			wnd.SendMessage(WM_COMMAND, MAKEWPARAM(IDCANCEL, 0));
			wnd.SendMessage(WM_COMMAND, MAKEWPARAM(IDOK, 0));
//			wnd.SendMessage(WM_KEYDOWN, VK_ESCAPE);
			return true;
		}
		else if (strOneStaticText.Find(_T("ActiveX")) != -1 && strOneStaticText.Find(_T("���s")) != -1) {
			wnd.SendMessage(WM_COMMAND, MAKEWPARAM(IDCANCEL, 0));
			wnd.SendMessage(WM_COMMAND, MAKEWPARAM(IDOK, 0));
//			wnd.SendMessage(WM_KEYDOWN, VK_ESCAPE);
			return true;
		}
		else if (strOneStaticText.Find(_T("�J���܂���")) != -1) {
			wnd.SendMessage(WM_COMMAND, MAKEWPARAM(IDCANCEL, 0));
			wnd.SendMessage(WM_COMMAND, MAKEWPARAM(IDOK, 0));
//			wnd.SendMessage(WM_KEYDOWN, VK_ESCAPE);
			return true;
		}

		return false;
	}
};

//__declspec(selectany) HHOOK CDialogKiller::s_hCreateHook = NULL;
//__declspec(selectany) bool CDialogKiller::s_bValid = true;


