// ChildFrm.h : interface of the CChildFrame class
//
/////////////////////////////////////////////////////////////////////////////
#pragma once


#include <vector>
#include "PluginManager.h"
#include "MtlBrowser.h"
#include "MDIChildUserMessenger.h"

#include "FavoriteMenu.h"
#include "DonutView.h"
#include "AddressBar.h"
#include "MDITabCtrl.h"

#include "option/DLControlOption.h"
#include "option/StartUpOption.h"
#include "option/DonutConfirmOption.h"
#include "option/IgnoreURLsOption.h"
#include "option/CloseTitleOption.h"

#include "FileNotification.h"

//#include "MDIChildUserMessenger.h"
#ifdef _DEBUG
	const bool _Donut_ChildFrame_traceOn = false;
	#define dcfTRACE if (_Donut_ChildFrame_traceOn) ATLTRACE
#else
	#define dcfTRACE
#endif

extern LPCTSTR g_lpszLight[];
extern int g_LIGHTMAX;

class CChildFrame :
	public CMDIChildWindowImplFixed<CChildFrame, 2>,
	public IWebBrowserEvents2Impl<CChildFrame, ID_DONUTVIEW>,
	public CWebBrowserCommandHandler<CChildFrame>,
	public CUpdateCmdUI<CChildFrame>,
	public CMDIChildUserMessenger<CChildFrame>,
	public CWebBrowser2
{
public:
// Declarations
	DECLARE_FRAME_WND_CLASS(NULL, IDR_MDICHILD)
	DECLARE_FRAME_WND_MENU(NULL)
	typedef CMDIChildWindowImplFixed<CChildFrame, 2> baseClass;

// Constants
	enum { _nPosFavoriteMenuOfTab = 8 };

// Data members
	CDonutView m_view;
	BOOL m_bNavigateBack, m_bNavigateForward;
	CMDITabCtrl& m_MDITab;
	CDonutAddressBar& m_AddressBar;
	bool m_bNewWindow2;
	bool m_bClosing;
	CContainedWindow m_wndBrowser;
	CChildFavoriteMenu<CChildFrame> m_FavMenu;

	CString m_strStatusBar;
	long m_nProgress, m_nProgressMax;

	bool m_bMozilla;

	bool m_bPageFocusInitialized;
	bool m_bWaitNavigateLock;
	HWND m_hWndFocus;
	HWND m_hWndF, m_hWndA;

	BOOL m_bNowHilight;
	BSTR m_strBookmark;
	int m_nPainBookmark;

	int m_nCmdType;
	CImageList m_imgList;

	int m_nSecureLockIcon;
	bool m_bPrivacyImpacted;

	BOOL m_bInitTravelLog; //minit
	CString m_strDfgFileName;
	CString m_strSection;
	std::vector<std::pair<CString, CString> > m_ArrayHistFore, m_ArrayHistBack;

	bool m_bOperateDrag;
	int m_nImgWidth, m_nImgHeight;
	bool m_bExPropLock;
	CString m_strSearchWord;

// Constructor/Destructor
	CChildFrame(CMDITabCtrl& MDITab, CDonutAddressBar& addressbar, bool bNewWindow2, DWORD dwDefaultDLControlFlags)
		:	m_bNavigateBack(FALSE), m_bNavigateForward(FALSE),
			m_MDITab(MDITab), m_AddressBar(addressbar),
			m_bNewWindow2(bNewWindow2),
			m_wndBrowser(this, 7), m_FavMenu(this, ID_INSERTPOINT_CHILDFAVORITEMENU),
			m_nProgress(-1), m_nProgressMax(0), m_bMozilla(false), m_bPageFocusInitialized(false),
			m_bClosing(false), m_bWaitNavigateLock(true), m_hWndFocus(NULL), m_view(dwDefaultDLControlFlags),
			m_bOperateDrag(false), m_bExPropLock(false)
	{
		m_bNowHilight = FALSE;
		m_hWndF = NULL;
		m_hWndA = NULL;

		m_strBookmark = NULL;
		m_nPainBookmark = 0;

		m_nSecureLockIcon = secureLockIconUnsecure;
		m_bPrivacyImpacted = TRUE;

		m_bInitTravelLog = TRUE;
		m_nImgWidth = m_nImgHeight = -1;
	}
	
	~CChildFrame()
	{
		dcfTRACE(_T("CChildFrame::~CChildFrame\n"));

		if (m_wndBrowser.IsWindow()) // scary
			m_wndBrowser.UnsubclassWindow();

		ATLASSERT(m_hMenu == NULL); // no menu
	}


	static CChildFrame* NewWindow(HWND hWndMDIClient, CMDITabCtrl& tabMDI,
		CDonutAddressBar& adBar, bool bNewWindow2 = false, DWORD dwDLFlags = CDLControlOption::s_dwDLControlFlags)
	{
		if (!CMainOption::IsQualify(tabMDI.GetItemCount()))
			return NULL;

		//ATLTRY(CChildFrame* pChild = new CChildFrame(tabMDI, adBar, bNewWindow2, dwDLFlags));
		CChildFrame* pChild = new CChildFrame(tabMDI, adBar, bNewWindow2, dwDLFlags); //��[?
		if (pChild != NULL){
			pChild->CreateEx(hWndMDIClient);
			CDonutSearchBar *pSearch = (CDonutSearchBar *)::SendMessage(pChild->GetTopLevelParent(),WM_GET_SEARCHBAR,0,0);
			if(pSearch){
				pChild->m_strSearchWord = pSearch->RemoveShortcutWord(MtlGetWindowText(pSearch->GetEditCtrl()));
			}
		}
		return pChild;
	}

// Overrides
	virtual void OnFinalMessage(HWND /*hWnd*/)
	{
		delete this;
	}

	void ActivateFrame(int nCmdShow = -1)
	{
		ATLASSERT(::IsWindow(m_hWnd));
		if(m_MDITab.GetTabIndex(m_hWnd)==-1) //�Ȃ񂾂�MDITab��MDIActivate�̕�����ɌĂяo����Ă��܂��̂�
			m_MDITab.OnMDIChildCreate(m_hWnd); //���낢��Ə��Ԃ������Ă���

		if (_check_flag(m_view.m_ViewOption.m_dwExStyle, DVS_EX_OPENNEWWIN)) {
			m_MDITab.NavigateLockTab(m_hWnd, true);
		}

		//Raise Plugin Event
		int nNewIndex = m_MDITab.GetTabIndex(m_hWnd);
		CPluginManager::ChainCast_PluginEvent(DEVT_TAB_OPENED,nNewIndex,0);

		baseClass::ActivateFrame(nCmdShow);
	}

	void ActivateFrameForNewWindowDelayed(int nCmdShow = -1)
	{
		dcfTRACE(_T("CChildFrame::ActivateFrameForNewWindowDelayed - now activating!\n"));
		if (MDIGetActive() != NULL && CMainOption::s_dwMainExtendedStyle & MAIN_EX_NOACTIVATE_NEWWIN)
			nCmdShow = SW_SHOWNOACTIVATE;

		ActivateFrame(nCmdShow);
	}

	BYTE GetTabItemState(HWND hTarWnd)
	{
		int nTabIndex = m_MDITab.GetTabIndex(hTarWnd);
		BYTE bytData=0;
		m_MDITab.GetItemState(nTabIndex, bytData);
		return bytData;
	}

// Message map and handlers
	BEGIN_MSG_MAP(CChildFrame)
		PASS_MSG_MAP_MDICHILD_TO_MDITAB(m_MDITab)
		PASS_MSG_MAP_MENUOWNER_TO_EXPMENU(m_FavMenu)

		MESSAGE_HANDLER(WM_SIZE, OnSize)
		MSG_WM_SYSCOMMAND(OnSysCommand)
		MSG_WM_CREATE(OnCreate)
		MSG_WM_CLOSE(OnClose)
		MSG_WM_DESTROY(OnDestroy)
		MSG_WM_MDIACTIVATE(OnMDIActivate)
		MSG_WM_FORWARDMSG(OnForwardMsg)
		HANDLE_MESSAGE(WM_SETFOCUS)			// baseClass handler is not effective

		MSG_WM_USER_GET_IWEBBROWSER()
		USER_MSG_WM_SAVE_OPTION(OnSaveOption)

		// UH
		USER_MSG_WM_MENU_GOBACK(OnMenuGoBack)					
		USER_MSG_WM_MENU_GOFORWARD(OnMenuGoForward)
		MSG_WM_USER_IS_SELECTED(OnIsSelectedTab)
		MSG_WM_USER_HILIGHT(OnHilight);			
		MSG_WM_USER_FIND_KEYWORD(OnFindKeyWord);
		COMMAND_ID_HANDLER(ID_WINDOW_TILE_HORZ, OnWindowTile)
		COMMAND_ID_HANDLER(ID_WINDOW_TILE_VERT, OnWindowTile)
		MESSAGE_HANDLER(WM_USER_SIZE_CHG_EX, OnSizeChgEx)
		MSG_WM_USER_USED_MOUSE_GESTURE(OnUsedMouseGesture)
		COMMAND_ID_HANDLER(ID_STYLESHEET_BASE, OnStyleSheet)
		COMMAND_ID_HANDLER(ID_STYLESHEET_OFF, OnStyleSheet)
		MSG_WM_USER_CHANGE_CSS(OnChangeCSS)
		//^^^
		
		//minit
		USER_MSG_WM_GET_EXTENDED_TABSTYLE(OnGetExtendedTabStyle)
		USER_MSG_WM_SET_EXTENDED_TABSTYLE(OnSetExtendedTabStyle)
		USER_MSG_WM_SET_CHILDFRAME(OnGetChildFrame)

		COMMAND_ID_HANDLER_EX(ID_FILE_CLOSE, OnFileClose)
		COMMAND_ID_HANDLER_EX(ID_WINDOW_CLOSE_ALL, OnWindowCloseAll)		// UH
		COMMAND_ID_HANDLER_EX(ID_EDIT_IGNORE, OnEditIgnore)
		COMMAND_ID_HANDLER_EX(ID_EDIT_OPEN_SELECTED_REF, OnEditOpenSelectedRef)
		COMMAND_ID_HANDLER_EX(ID_EDIT_OPEN_SELECTED_TEXT, OnEditOpenSelectedText)

		COMMAND_ID_HANDLER_EX(ID_EDIT_CLOSE_TITLE, OnEditCloseTitle) // UDT DGSTR
		COMMAND_ID_HANDLER_EX(ID_EDIT_FIND_MAX, OnEditFindMax)	//moved from CWebBrowserCommandHandler by minit

		COMMAND_ID_HANDLER_EX(ATL_IDS_SCPREVWINDOW, OnWindowPrev)
		COMMAND_ID_HANDLER_EX(ATL_IDS_SCNEXTWINDOW, OnWindowNext)

		COMMAND_ID_HANDLER_EX(ID_FAVORITE_GROUP_ADD, OnFavoriteGroupAdd)
		COMMAND_ID_HANDLER_EX(ID_FAVORITE_ADD, OnFavoriteAdd)

		COMMAND_ID_HANDLER_EX(ID_VIEW_SETFOCUS, OnViewSetFocus)
		COMMAND_ID_HANDLER_EX(ID_VIEW_REFRESH, OnViewRefresh)
		COMMAND_ID_HANDLER_EX(ID_VIEW_STOP, OnViewStop)
		COMMAND_ID_HANDLER_EX(ID_VIEW_OPTION, OnViewOption)
		COMMAND_ID_HANDLER_EX(ID_FILE_SAVE_AS, OnFileSaveAs)
		COMMAND_ID_HANDLER_EX(ID_FILE_PAGE_SETUP, OnFilePageSetup)
		COMMAND_ID_HANDLER_EX(ID_FILE_PRINT, OnFilePrint)
		COMMAND_ID_HANDLER_EX(ID_FILE_PROPERTIES, OnFileProperties)

		COMMAND_ID_HANDLER_EX(ID_EDIT_FIND, OnEditFind)

		COMMAND_ID_HANDLER(ID_WINDOW_CLOSE_EXCEPT, OnWindowCloseExcept)
		COMMAND_ID_HANDLER(ID_WINDOW_REFRESH_EXCEPT, OnWindowRefreshExcept)

		COMMAND_ID_HANDLER(ID_LEFT_CLOSE, OnLeftRightClose)
		COMMAND_ID_HANDLER(ID_RIGHT_CLOSE, OnLeftRightClose)

		COMMAND_ID_HANDLER(ID_VIEW_REFRESH_FAVBAR, OnViewRefreshFavBar)

		COMMAND_ID_HANDLER_EX(ID_DOCHOSTUI_OPENNEWWIN, OnDocHostUIOpenNewWin)
		COMMAND_ID_HANDLER_EX(ID_REGISTER_AS_BROWSER, OnRegisterAsBrowser)

		COMMAND_RANGE_HANDLER_EX(ID_VIEW_BACK1, ID_VIEW_BACK9, OnViewBackX)
		COMMAND_RANGE_HANDLER_EX(ID_VIEW_FORWARD1, ID_VIEW_FORWARD9, OnViewForwardX)

		COMMAND_ID_HANDLER_EX(ID_TITLE_COPY, OnTitleCopy)
		COMMAND_ID_HANDLER_EX(ID_URL_COPY, OnUrlCopy)
		COMMAND_ID_HANDLER_EX(ID_COPY_TITLEANDURL, OnTitleAndUrlCopy)

		COMMAND_ID_HANDLER_EX(ID_SAVE_FAVORITE_TO, OnSaveFavoriteTo)

		CHAIN_COMMANDS(CWebBrowserCommandHandler<CChildFrame>)
		CHAIN_MSG_MAP(CUpdateCmdUI<CChildFrame>)
		CHAIN_MSG_MAP(CMDIChildUserMessenger<CChildFrame>)

		CHAIN_COMMANDS_MEMBER(m_view)// CHAIN_CLIENT_COMMANDS() not send, why?
		CHAIN_MSG_MAP(baseClass)
	ALT_MSG_MAP(7)// to hook WM_CLOSE from Browser internal window (for script: "window.close()")
		MSG_WM_CLOSE(OnBrowserClose)
	END_MSG_MAP()

// Command overrides 

	LRESULT OnChangeCSS(LPCTSTR lpszStyleSheet)
	{
		CString strSheetPath(lpszStyleSheet);
		CString strSheetName = strSheetPath.Mid(strSheetPath.ReverseFind('\\')+1);

		StyleSheet(strSheetName, FALSE, strSheetPath);

		SetDefaultStyleSheet(strSheetPath);

		return 1;
	}

	LRESULT OnStyleSheet(WORD /*wNotifyCode*/, WORD wID, HWND /*hWndCtl*/, BOOL& /*bHandled*/)
	{
		CString strSheet;
		BOOL bOff=FALSE;
		switch(wID)
		{
		case ID_STYLESHEET_BASE:				break;
		case ID_STYLESHEET_OFF:		bOff=TRUE;	break;
		}

		StyleSheet(strSheet, bOff, _T(""));
		SetDefaultStyleSheet(_T(""));

		return 1;
	}

	void SetDefaultStyleSheet(CString strStyleSheet)
	{
		DWORD dwSetDefault=0;
		CIniSection pr;
		pr.Open(_szIniFileName,_T("StyleSheet"));
		pr.QueryValue(dwSetDefault,_T("SetDefault"));
		if(dwSetDefault){
			pr.SetValue(strStyleSheet,_T("Default"));
		}
		pr.Close();

	}

	LRESULT OnUsedMouseGesture()
	{
		return (m_view.m_ViewOption.m_dwExStyle&DVS_EX_MOUSE_GESTURE)? TRUE:FALSE;
	}

	LRESULT OnSizeChgEx(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
	{
		m_nCmdType=SC_RESTORE;
		return 0;
	}

	LRESULT OnWindowTile(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/, BOOL& /*bHandled*/)
	{
		m_nCmdType=SC_RESTORE;
		return 0;
	}

	BOOL OnIsSelectedTab(HWND hWnd)
	{
		BYTE bytData = 0;
		bytData = GetTabItemState(hWnd);

		BOOL bSts=FALSE;
		if (bytData&TCISTATE_MSELECTED)
			bSts = TRUE;
		return bSts;
	}

	LRESULT OnMenuGoBack(HMENU hMenu)
	{
		MenuChgGoBack(hMenu);
		return 0;
	}
	LRESULT OnMenuGoForward(HMENU hMenu)
	{
		MenuChgGoForward(hMenu);
		return 0;
	}

	void OnRegisterAsBrowser(WORD wNotifyCode, WORD /*wID*/, HWND /*hWndCtl*/)
	{
		SetRegisterAsBrowser(wNotifyCode == NM_ON);
	}

	void OnDocHostUIOpenNewWin(WORD wNotifyCode, WORD /*wID*/, HWND /*hWndCtl*/)
	{
		if (wNotifyCode == NM_ON) {
			m_view.m_ViewOption.m_dwExStyle |= DVS_EX_OPENNEWWIN;
			m_MDITab.NavigateLockTab(m_hWnd, true);
		}
		else if (wNotifyCode == NM_OFF) {
			m_view.m_ViewOption.m_dwExStyle &= ~DVS_EX_OPENNEWWIN;
			m_MDITab.NavigateLockTab(m_hWnd, false);
		}
		else if (m_view.m_ViewOption.m_dwExStyle & DVS_EX_OPENNEWWIN) {
			m_view.m_ViewOption.m_dwExStyle &= ~DVS_EX_OPENNEWWIN;
			m_MDITab.NavigateLockTab(m_hWnd, false);
		}
		else {
			m_view.m_ViewOption.m_dwExStyle |= DVS_EX_OPENNEWWIN;
			m_MDITab.NavigateLockTab(m_hWnd, true);
		}
	}

	void OnViewSetFocus(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/)
	{
		// NOTE. _SetPageFoucs would fail if document not completed.
		m_bPageFocusInitialized = false;// reset focus
		_SetPageFocus();
	}

	void OnViewRefresh(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/)
	{
		if (MDIGetActive() == m_hWnd)
		{
			m_hWndA = NULL;
			m_hWndF = NULL;
		}
		else
		{
			m_hWndA = ::GetActiveWindow();
			m_hWndF = ::GetFocus();
		}

		if (::GetAsyncKeyState(VK_CONTROL) < 0)// Inspired by DOGSTORE, Thanks
			Refresh2(REFRESH_COMPLETELY);
		else
			Refresh();
	}

	void OnViewStop(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/)
	{
		Stop();

		// make sure
		m_nDownloadCounter = 0;
		OnStateCompleted(); 
	}

	void OnFavoriteAdd(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/)
	{
		bool bOldShell = _check_flag(MAIN_EX_ADDFAVORITEOLDSHELL, CMainOption::s_dwMainExtendedStyle);
		MtlAddFavorite(GetLocationURL(), MtlGetWindowText(m_hWnd), bOldShell, DonutGetFavoritesFolder(), m_hWnd);

		::SendMessage(GetTopLevelParent(),WM_REFRESH_EXPBAR,0,0);
	}

	void OnFavoriteGroupAdd(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/)
	{
		TCHAR szOldPath[MAX_PATH];// save current directory
		::GetCurrentDirectory(MAX_PATH, szOldPath);

		const TCHAR szFilter[] = _T("Donut Favorite Group�t�@�C��(*.dfg)\0*.dfg\0\0");

		::SetCurrentDirectory(DonutGetFavoriteGroupFolder());

		CFileDialog fileDlg(FALSE, _T("dfg"), NULL, OFN_HIDEREADONLY, szFilter);
		fileDlg.m_ofn.lpstrInitialDir = DonutGetFavoriteGroupFolder();
		fileDlg.m_ofn.lpstrTitle = _T("���C�ɓ���O���[�v�ɒǉ�");
		if (fileDlg.DoModal() == IDOK) {
			_AddGroupOption(fileDlg.m_szFileName);
			::SendMessage(GetTopLevelParent(),WM_REFRESH_EXPBAR,1,0);
		}

		// restore current directory
		::SetCurrentDirectory(szOldPath);
	}

	int  _AddGroupOption(const CString& strFileName)
	{
		CIniSection pr;
		pr.Open(strFileName, _T("Header"));
		DWORD dwCount = 0;
		pr.QueryValue(dwCount, _T("count"));

		OnSaveOption(strFileName, dwCount);
		dwCount += 1;

		pr.SetValue(dwCount, _T("count"));
//		pr.SetValue(f._nActiveIndex, _T("active"));
		pr.Close();

		return dwCount;
	}

	void OnClose()
	{
		SetMsgHandled(FALSE);
		m_bClosing = true;

		int nIndex = m_MDITab.GetTabIndex(m_hWnd);

		// for mdi tab ctrl
		HWND hWndActiveNext = NULL;
		if (MDIGetActive() == m_hWnd) {
			int nIndex = m_MDITab.ManageClose(m_hWnd);
			if (nIndex != -1) {
				hWndActiveNext = m_MDITab.GetTabHwnd(nIndex);
				ATLASSERT(::IsWindow(hWndActiveNext));
			}
		}
		m_MDITab.OnMDIChildDestroy(m_hWnd);
		if (hWndActiveNext)
			MDIActivate(hWndActiveNext);

		if(!CMainOption::s_bAppClosing ||  !(CStartUpOption::s_dwFlags == STARTUP_LATEST)){ //minit
			CString strURL = GetLocationURL();
			CString strTitle = GetLocationName();
			std::vector<std::pair<CString,CString> > arrFore, arrBack;
			if (!strURL.IsEmpty() && CMainOption::s_bTravelLogClose){
				m_view.m_ViewOption._OutPut_TravelLog(arrFore,TRUE);
				m_view.m_ViewOption._OutPut_TravelLog(arrBack,FALSE);
			}
			if(!strURL.IsEmpty())
				CMainOption::s_pMru->AddToList(strURL,&arrFore,&arrBack,strTitle);
		}

		{
			//�v���O�C���C�x���g - �N���[�Y
			CPluginManager::BroadCast_PluginEvent(DEVT_TAB_CLOSE,nIndex,0);
		}
	}

	LRESULT OnSize(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
	{
		BOOL bMaxActive = FALSE;
		HWND hWndActive = MDIGetActive(&bMaxActive);
		if (bMaxActive==FALSE)
			bMaxActive = ::IsZoomed(hWndActive);

		int nCmdType=m_nCmdType;
		m_nCmdType=0;

		CString str;
		CheckImageAutoSize(str,FALSE);

		dcfTRACE(_T("CChildFrame::OnSize type(%d)\n"), wParam);
		if (CMainOption::s_bTabMode && (wParam == SIZE_RESTORED || wParam == SIZE_MINIMIZED))
		{

			dcfTRACE(_T(" restored\n"));
			bHandled = TRUE;// eat it!!
			return 0;
		}
		else if (bMaxActive && ((nCmdType!=SC_RESTORE&&nCmdType!=SC_MINIMIZE) && (wParam==SIZE_RESTORED||wParam==SIZE_MINIMIZED)))
		{
			dcfTRACE(_T(" restored\n"));
			bHandled = TRUE;// eat it!!
			return 0;
		}
		else {
			bHandled = FALSE;
			return -1;
		}
	}

	void OnSysCommand(UINT uCmdType, CPoint pt)
	{
		m_nCmdType=uCmdType;

		if (CMainOption::s_bTabMode && (uCmdType == SC_MINIMIZE || uCmdType == SC_RESTORE))
			SetMsgHandled(TRUE);
		else
			SetMsgHandled(FALSE);
	}

	void OnWindowPrev(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/)
	{
		MDINext(m_hWnd, TRUE);
	}

	void OnWindowNext(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/)
	{
		MDINext(m_hWnd, FALSE);
	}

	LRESULT OnWindowCloseExcept(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/, BOOL& /*bHandled*/)
	{
		if (!CDonutConfirmOption::OnCloseAllExcept(GetTopLevelParent()))
			return 0;

		CWaitCursor cur;
		CLockRedrawMDIClient lock(m_hWndMDIClient);
		CLockRedraw lock2(m_MDITab);
		MtlCloseAllMDIChildrenExcept(m_hWndMDIClient, m_hWnd);
		return 0;
	}

	LRESULT OnLeftRightClose(WORD /*wNotifyCode*/, WORD wID, HWND /*hWndCtl*/, BOOL& /*bHandled*/)
	{
		CWaitCursor cur;

		BOOL bLeft = TRUE;
		if (wID==ID_LEFT_CLOSE)
			bLeft = TRUE;
		else if (wID==ID_RIGHT_CLOSE)
			bLeft = FALSE;
		
		HWND hWndActive =(HWND)::SendMessage(m_hWndMDIClient, WM_MDIGETACTIVE, 0, (LPARAM)NULL);
		int nCurSel = m_MDITab.GetTabIndex(m_hWnd);
		int nCurSel2 = m_MDITab.GetTabIndex(hWndActive);
		int nCurSel3 = m_MDITab.GetTabIndex(m_hWndMDIClient);
		if (nCurSel==-1) return 0;

		::SendMessage(GetTopLevelParent(), WM_USER_WINDOWS_CLOSE_CMP, (WPARAM)nCurSel, (LPARAM)bLeft);
		return 0;
	}

	//vvvvvvvvvvvvvvvvvvvvvvvvvvvvv
	// U.H
	LRESULT OnWindowRefreshExcept(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/, BOOL& /*bHandled*/)
	{
		CWaitCursor cur;
		CLockRedrawMDIClient lock(m_hWndMDIClient);
		CLockRedraw lock2(m_MDITab);
		MtlRefreshAllMDIChildrenExcept(m_hWndMDIClient, m_hWnd);
		return 0;
	}
	//^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

	LRESULT OnForwardMsg(LPMSG pMsg, DWORD)
	{
		if(baseClass::PreTranslateMessage(pMsg))
			return TRUE;

		return m_view.PreTranslateMessage(pMsg);
	}

	LRESULT OnCreate(LPCREATESTRUCT lpcreatestruct)
	{
		dcfTRACE(_T("CChildFrame::OnCreate\n"));
		// Let me initialize itself
		LRESULT lRet = DefWindowProc();

		m_bMozilla = _bMozilla;// mozilla engine?

		//TODO: Replace with a URL of your choice
		CRect rc = rcDefault;
		__CalcDefaultRect(rc);
		m_hWndClient = m_view.Create(m_hWnd, rc, _T("about:blank"), 
			WS_CHILD | WS_VISIBLE/* | WS_CLIPSIBLINGS | WS_CLIPCHILDREN*/, WS_EX_CLIENTEDGE, ID_DONUTVIEW);

		//�h���b�O�h���b�v�̏�����ݒ�
		_InitDragDropSetting();

		m_view.QueryControl(IID_IWebBrowser2, (void**)&m_spBrowser);

		WebBrowserEvents2Advise();

		if (_check_flag(MAIN_EX_REGISTER_AS_BROWSER, CMainOption::s_dwMainExtendedStyle))
			SetRegisterAsBrowser(true);// for target name resolution

		_SetupWindowCloseHook();

		// set up for mdi tab ctrl
		CMenuHandle menu0 = m_MDITab.m_menuPopup.GetSubMenu(0);
		HMENU hMenu = menu0.GetSubMenu(_nPosFavoriteMenuOfTab);
		m_FavMenu.InstallExplorerMenu(hMenu);

		if (!m_bNewWindow2)
			SetVisible(true);

		CFavoritesMenuOption::Add(m_hWnd);

//		CMainFrame* pMainWnd = GetParent(m_hWnd);

		return lRet;
	}

	void _InitDragDropSetting()
	{
		DWORD dwCommand=0;
		CIniSection pr;
		pr.Open(_GetFilePath("MouseEdit.ini"),_T("MouseCtrl"));
		pr.QueryValue(dwCommand,_T("DragDrop"));
		m_bOperateDrag = dwCommand ? true : false;

		if(m_bOperateDrag){
			m_view.SetOperateDragDrop(TRUE,dwCommand);
		}
	}

	void __CalcDefaultRect(CRect& rc)
	{
		BOOL bMaximized = FALSE;
		HWND hWndActive = MDIGetActive(&bMaximized);
		if (hWndActive == NULL || bMaximized) {
			::GetClientRect(m_hWndMDIClient, &rc);
		}
	}

	void OnDestroy()
	{
		dcfTRACE(_T("CChildFrame::OnDestroy\n"));
		SetMsgHandled(FALSE);
		m_bClosing = true;

		if(m_bOperateDrag)
			m_view.SetOperateDragDrop(FALSE,0);

		SetRegisterAsBrowser(false);

		// m_view.DestroyWindow makes offline state reset, so
		// save global offline state
		bool bGlobalOffline = MtlIsGlobalOffline();

		// Before AtlAdviseSinkMap(this, false) destroy view,
		// cuz I wanna handle OnNewWindow2 event
		// And while destroying view, a meaningless WM_DRAWCLIPBOARD may be sent, so ignore it.

		CMainOption::s_bIgnoreUpdateClipboard = true;
		dcfTRACE(_T(" m_view.Destroy\n"));
		if (m_view.IsWindow())
			m_view.DestroyWindow();
		CMainOption::s_bIgnoreUpdateClipboard = false;

		dcfTRACE(_T(" DispEventUnadvise\n"));

		WebBrowserEvents2Unadvise();

		// restore global offline state
		MtlSetGlobalOffline(bGlobalOffline);
	}

	LRESULT OnViewRefreshFavBar(WORD /*wNotifyCode*/, WORD wID, HWND /*hWndCtl*/, BOOL& /*bHandled*/)
	{
		m_FavMenu.SetRootDirectoryPath(DonutGetFavoritesFolder());
		m_FavMenu.RefreshMenu();
		return 0;
	}

	void OnFileClose(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/)
	{
		m_bClosing = true;
		PostMessage(WM_CLOSE);
	}

	void OnWindowCloseAll(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/)
	{
		::SendMessage(::GetParent(::GetParent(m_hWnd)), WM_COMMAND, ID_WINDOW_CLOSE_ALL, 0);
	}

	void OnEditIgnore(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/)
	{
		dcfTRACE(_T("CChildFrame::OnEditIgnore\n"));
		CIgnoredURLsOption::Add(GetLocationURL());
		m_bClosing = true;
		PostMessage(WM_CLOSE);
	}

	// UDT DGSTR ( close Title , but don't post WM_CLOSE so far. )
	void OnEditCloseTitle(WORD , WORD , HWND )
	{
		ATLTRACE2(atlTraceGeneral, 4, _T("CChildFrame::OnEditCloseTitle\n"));
		CCloseTitlesOption::Add(MtlGetWindowText(m_hWnd));
		m_bClosing = true;
		PostMessage(WM_CLOSE);
	}
	// ENDE

	void OnEditOpenSelectedRef(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/)
	{
		dcfTRACE(_T("CChildFrame::OnEditOpenSelectedRef\n"));
		m_MDITab.SetLinkState(LINKSTATE_B_ON);
		MtlForEachHTMLDocument2(m_spBrowser, _Function_OpenSelectedRef(m_hWnd));
		m_MDITab.SetLinkState(LINKSTATE_OFF);
	}

	void OnEditOpenSelectedText(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/)
	{
		dcfTRACE(_T("CChildFrame::OnEditOpenSelectedTitle\n"));
		m_MDITab.SetLinkState(LINKSTATE_B_ON);
		MtlForEachHTMLDocument2( m_spBrowser, Mtl_bind_mem_fun_void(&CChildFrame::_OpenSelectedText, this) );
		m_MDITab.SetLinkState(LINKSTATE_OFF);
	}

	void  OnEditFindMax(WORD wNotifyCode, WORD wID, HWND hWndCtl)
	{
		_OnEditFindMax(wNotifyCode,wID,hWndCtl);
	}

	void searchEngines(const CString& strKeyWord )
	{
		CString strSearchWord = strKeyWord;
		if(m_AddressBar.GetAddressBarExtendedStyle()&ABR_EX_SEARCH_REPLACE)
			strSearchWord.Replace(_T("�@"),_T(" "));
		//_ReplaceCRLF(strSearchWord,CString(_T(" ")));
		//strSearchWord.Replace('\n',' ');
		//strSearchWord.Remove('\r');
		strSearchWord.Replace(_T("\r\n"),_T(""));
		

		CIniSection pr;
		CString strEngin;
		DWORD dwSize=256;
		pr.Open(_szIniFileName,_T("AddresBar")); //�X�y���~�X�͂킴��
		pr.QueryValue(strEngin.GetBuffer(dwSize),_T("EnterCtrlEngin"),&dwSize);
		strEngin.ReleaseBuffer();
		pr.Close();
		::SendMessage(GetTopLevelParent(),WM_SEARCH_WEB_SELTEXT,(WPARAM)(LPCTSTR)strSearchWord,(LPARAM)(LPCTSTR)strEngin);

		//CWebBrowserCommandHandler<CChildFrame>::searchEngines(strSearchWord);
	}

	CString _ReplaceCRLF(CString& str, CString& strRep)
	{
		CString strRet;
		TCHAR ch;
		int len = str.GetLength();
		for(int i=0; i<len; i++){
			ch = str.GetAt(i);
			if((ch&0xFF) == 0xa){
				strRet += strRep;
			}else if((ch&0xFF) == 0xd){

			}else{
				strRet += ch;
			}
		}
		return strRep;
	}

	//vvv
	// UH

	LRESULT OnHilight(LPCTSTR lpszKeyWord, BOOL bToggle = TRUE, BOOL bFlag = FALSE)
	{
		HWND hWndActive = MDIGetActive();
		if (hWndActive==NULL) return 0;

		if(!bToggle)
			m_bNowHilight = bFlag;
		MtlForEachHTMLDocument2(m_spBrowser, _Function_SelectEmpt());
		MtlForEachHTMLDocument2(m_spBrowser, _Function_Hilight(lpszKeyWord, m_bNowHilight));
		m_bNowHilight = !m_bNowHilight;
		return 1;
	}

	

	void StyleSheet(CString strSheet, BOOL bOff, CString strSheetPath)
	{
		CComPtr<IDispatch> spDisp;
		HRESULT hr = m_spBrowser->get_Document(&spDisp);
		if (FAILED(hr))	return;

		CComPtr<IHTMLDocument2> spDocument;
		hr = spDisp->QueryInterface(&spDocument);
		if (FAILED(hr)) return;

		StyleSheetRecursive(spDocument, strSheet, bOff, strSheetPath);
		/*

		CComPtr<IHTMLFramesCollection2> spFrames;
		hr = spDocument->get_frames(&spFrames);
		// cf. Even if no frame, get_frames would succeed.
		if (FAILED(hr)) return;

		LONG nCount = 0;
		hr = spFrames->get_length(&nCount);
		if (FAILED(hr)) return;

		//�t���[�������y�[�W���̂ɂ̓X�^�C���V�[�g��K�p���Ȃ�
		if(CheckFrameDefinePage(spDocument))
			StyleSheetSub(spDocument, strSheet, bOff, strSheetPath);

		for (LONG ii=0; ii<nCount; ii++)
		{
			CComVariant varItem(ii);
			CComVariant varResult;

			hr = spFrames->item(&varItem, &varResult);
			if (FAILED(hr)) continue;

			CComQIPtr<IHTMLWindow2> spWindow = varResult.pdispVal;
			if (!spWindow) continue;

			CComPtr<IHTMLDocument2> spDocumentFr;
			hr = spWindow->get_document(&spDocumentFr);
			if (FAILED(hr)) continue;
	
			StyleSheetSub(spDocumentFr, strSheet, bOff, strSheetPath);
		}*/
	}

	void StyleSheetRecursive(CComPtr<IHTMLDocument2> spDocument, CString strSheet, BOOL bOff, CString strSheetPath)
	{
		if(!CheckFrameDefinePage(spDocument))
			StyleSheetSub(spDocument, strSheet, bOff, strSheetPath);

		HRESULT hr;
		CComPtr<IHTMLFramesCollection2> spFrames;
		hr = spDocument->get_frames(&spFrames);
		// cf. Even if no frame, get_frames would succeed.
		if (FAILED(hr)) return;

		long nCount=0;
		hr = spFrames->get_length(&nCount);
		if (FAILED(hr)) return;

		for (LONG ii=0; ii<nCount; ii++)
		{
			CComVariant varItem(ii);
			CComVariant varResult;

			hr = spFrames->item(&varItem, &varResult);
			if (FAILED(hr)) continue;

			CComQIPtr<IHTMLWindow2> spWindow = varResult.pdispVal;
			if (!spWindow) continue;

			CComPtr<IHTMLDocument2> spDocumentFr;
			hr = spWindow->get_document(&spDocumentFr);
			if (FAILED(hr)) continue;
	
			StyleSheetRecursive(spDocumentFr, strSheet, bOff, strSheetPath);
		}
	}

	BOOL CheckFrameDefinePage(CComPtr<IHTMLDocument2> spDocument)
	{
		HRESULT hr;
		CComPtr<IHTMLElementCollection> spClct;
		hr = spDocument->get_all(&spClct);
		if(SUCCEEDED(hr)){
			CComVariant varStr(CComBSTR(_T("frameSet")));
			CComPtr<IDispatch> spDisp;
			hr = spClct->tags(varStr,&spDisp);
			if(SUCCEEDED(hr) && spDisp){
				CComQIPtr<IHTMLElementCollection> spFrameSetClct = spDisp;
				LONG lCount=0;
				hr = spFrameSetClct->get_length(&lCount);
				if(SUCCEEDED(hr) && lCount)
					return TRUE;
			}
		}
		return FALSE;
	}

	void StyleSheetSub(IHTMLDocument2* pDocument, CString strSheet, BOOL bOff, CString strSheetPath)
	{
		// �X�^�C���V�[�g�ꗗ���擾
		CComPtr<IHTMLStyleSheetsCollection> spSheetsColl;
		pDocument->get_styleSheets(&spSheetsColl);
		if (!spSheetsColl) return;

		bool bFindTarSheet = false;
		long lLength;
		spSheetsColl->get_length(&lLength);
		for (long i = 0; i < lLength; i++)
		{
			VARIANT varIdx, varSheet;
			varIdx.vt = VT_I4;
			varIdx.lVal = i;
			varSheet.vt = VT_DISPATCH;
			varSheet.pdispVal = NULL;
			spSheetsColl->item(&varIdx, &varSheet);
			if (varSheet.pdispVal)
			{
				CComPtr<IHTMLStyleSheet> spSheet2 = NULL;
				varSheet.pdispVal->QueryInterface(IID_IHTMLStyleSheet, (void**)&spSheet2);

				CComBSTR strTitle;
				spSheet2->get_title(&strTitle);

				CString strTarSheet(strTitle);
				if (strTarSheet==strSheet && !bOff)
				{
					spSheet2->put_disabled(VARIANT_FALSE);
					bFindTarSheet = true;
				}
				else
					spSheet2->put_disabled(VARIANT_TRUE);
			}
			varSheet.pdispVal->Release();
		}

		if (!bFindTarSheet && !bOff && !strSheetPath.IsEmpty())
		{
			CComPtr<IHTMLStyleSheet> spSheet;
			pDocument->createStyleSheet(NULL, -1, &spSheet);
			if (spSheet)
			{
				// ������ݒ�
				long lPos;
				spSheet->addImport((BSTR)CComBSTR(strSheetPath), -1, &lPos);
				spSheet->put_title((BSTR)CComBSTR(strSheet));
				spSheet->put_disabled(VARIANT_FALSE);
			}
		}
	}

	LRESULT OnFindKeyWord(LPCTSTR lpszKeyWord, BOOL bFindDown)
	{
		HWND hWndActive = MDIGetActive();
		if (hWndActive==NULL) return 0;

		if(!m_spBrowser) return 0;
	
		CComPtr<IDispatch> spDisp;
		HRESULT hr = m_spBrowser->get_Document(&spDisp);
		if (FAILED(hr))	return 0;

		CComQIPtr<IHTMLDocument2> spDocument = spDisp;
		if (!spDocument) return 0;

		BOOL bSts = _FindKeyWordOne(spDocument, lpszKeyWord, bFindDown);
		if (bSts) return 1;

		CComPtr<IHTMLFramesCollection2> spFrames;
		hr = spDocument->get_frames(&spFrames);
		// cf. Even if no frame, get_frames would succeed.
		if (FAILED(hr)) return 0;

		LONG nCount = 0;
		hr = spFrames->get_length(&nCount);
		if (FAILED(hr)) return 0;

		BOOL bFindIt=FALSE;
		if (bFindDown)
		{
			for (LONG ii=m_nPainBookmark; ii<nCount; ii++)
			{
				CComVariant varItem(ii);
				CComVariant varResult;

				hr = spFrames->item(&varItem, &varResult);
				if (FAILED(hr)) continue;

				CComQIPtr<IHTMLWindow2> spWindow = varResult.pdispVal;
				if (!spWindow) continue;

				CComPtr<IHTMLDocument2> spDocumentFr;
				hr = spWindow->get_document(&spDocumentFr);
				if (FAILED(hr)) continue;
		
				bFindIt = _FindKeyWordOne(spDocumentFr, lpszKeyWord, bFindDown);
				if (bFindIt)
				{
					m_nPainBookmark = ii;
					break;
				}
			}

			if (!bFindIt)
			{
				m_nPainBookmark=0;
				m_strBookmark=NULL;
			}
		}
		else
		{
			if (m_nPainBookmark==0 && m_strBookmark==NULL)
				m_nPainBookmark=nCount-1;
				
			for (LONG ii=m_nPainBookmark; ii>=0; ii--)
			{
				CComVariant varItem(ii);
				CComVariant varResult;

				hr = spFrames->item(&varItem, &varResult);
				if (FAILED(hr)) continue;

				CComQIPtr<IHTMLWindow2> spWindow = varResult.pdispVal;
				if (!spWindow) continue;

				CComPtr<IHTMLDocument2> spDocumentFr;
				hr = spWindow->get_document(&spDocumentFr);
				if (FAILED(hr)) continue;
		
				bFindIt = _FindKeyWordOne(spDocumentFr, lpszKeyWord, bFindDown);
				if (bFindIt)
				{
					m_nPainBookmark = ii;
					break;
				}
			}

			if (!bFindIt)
			{
				m_nPainBookmark=0;
				m_strBookmark=NULL;
			}
		}

		return 1;
	}

	BOOL _FindKeyWordOne(IHTMLDocument2* pDocument, CString strKeyWord, BOOL bFindDown)
	{
		if(!pDocument) return FALSE;

		strKeyWord = strtok((LPSTR)strKeyWord.GetBuffer(0), " ");
		CString strExcept = _T(" \t\"\n�@");
		strKeyWord.TrimLeft(strExcept); strKeyWord.TrimRight(strExcept);

		CComPtr<IHTMLElement> spHTMLElement;
		CComPtr<IHTMLBodyElement> spHTMLBody;
		pDocument->get_body(&spHTMLElement);
		if(!spHTMLElement) return FALSE;
		spHTMLElement->QueryInterface(IID_IHTMLBodyElement, (void**)&spHTMLBody);
		if (spHTMLBody==NULL) return FALSE;

		CComPtr<IHTMLTxtRange> spTxtRange;
		spHTMLBody->createTextRange(&spTxtRange);
		if(!spTxtRange) return FALSE;

		if(m_strBookmark!=NULL)
		{
			VARIANT_BOOL vMoveBookmark=VARIANT_FALSE;
			long nMove;
			spTxtRange->moveToBookmark(m_strBookmark, &vMoveBookmark);
			if (vMoveBookmark==VARIANT_FALSE)
			{
//				m_strBookmark=NULL;
//				spTxtRange->moveStart((BSTR)CComBSTR("Textedit"),1,&nMove);
//				spTxtRange->moveEnd((BSTR)CComBSTR("Textedit"),1,&nMove);
			}
			else
			{
				if (bFindDown)
				{
					CComBSTR bStrNow;
					spTxtRange->get_text(&bStrNow);

					CString strNow(bStrNow);
					if (strNow!=strKeyWord) spTxtRange->collapse(false);

					spTxtRange->moveStart((BSTR)CComBSTR("Character"),1,&nMove);
					spTxtRange->moveEnd((BSTR)CComBSTR("Textedit"),1,&nMove);
				}
				else
				{
					spTxtRange->moveStart((BSTR)CComBSTR("Textedit"),-2, &nMove);
					spTxtRange->moveEnd((BSTR)CComBSTR("Character"),-2, &nMove);
				}
			}
		}

		CComBSTR bstrText(strKeyWord);
		BOOL bSts=FALSE;
		VARIANT_BOOL vBool=VARIANT_FALSE;
		spTxtRange->findText(bstrText, (bFindDown)? 1:-1, 0, &vBool);

		if(vBool==VARIANT_FALSE)
		{
			CComPtr<IHTMLSelectionObject> spSelection;
			HRESULT hr = pDocument->get_selection(&spSelection);
			if (spSelection) spSelection->empty();
		}
		else
		{
			if(spTxtRange->getBookmark(&m_strBookmark)!=S_OK)
				m_strBookmark=NULL;

			spTxtRange->select();
			spTxtRange->scrollIntoView(VARIANT_TRUE);

			bSts=TRUE;

			DWORD dwStatus=0;
			CIniSection pr;
			pr.Open(_szIniFileName, _T("SEARCH"));
			pr.QueryValue(dwStatus, _T("Status"));
			pr.Close();
			if(dwStatus&STS_SCROLLCENTER)
				ScrollBy(pDocument);
		}

		return bSts;
	}
	//^^^

	void ScrollBy(IHTMLDocument2 *pDoc2)
	{
		HRESULT hr;
		long height, y, scy;

		CComPtr<IHTMLDocument3> pDoc3;
		hr = pDoc2->QueryInterface(&pDoc3);
		if(FAILED(hr)) return;

		CComPtr<IHTMLElement> pElem;
		hr = pDoc3->get_documentElement(&pElem);
		if(FAILED(hr)) return;

		hr = pElem->get_offsetHeight(&height);	// HTML�\���̈�̍���
		if(FAILED(hr)) return;

		CComPtr<IHTMLSelectionObject> pSel;
		hr = pDoc2->get_selection(&pSel);
		if(FAILED(hr)) return;

		CComPtr<IDispatch> pDisp;
		hr = pSel->createRange(&pDisp);
		if(FAILED(hr)) return;

		CComPtr<IHTMLTextRangeMetrics> pTxtRM;
		hr = pDisp->QueryInterface(&pTxtRM);
		if(FAILED(hr)) return;

		hr = pTxtRM->get_offsetTop(&y);	// �I�𕔕��̉�ʏォ���y���W
		if(FAILED(hr)) return;

		scy = y - height/2;	// ��ʒ����܂ł̋���

		// �������\��������1/4���傫����΃X�N���[��������
		if ((scy > height/4) || (scy < -height/4)){
			CComPtr<IHTMLWindow2> pWnd;
			hr = pDoc2->get_parentWindow(&pWnd);
			if(FAILED(hr)) return;

			pWnd->scrollBy(0,scy);
		}
	}

	void _OpenSelectedText(IHTMLDocument2* pDocument)
	{
		CComPtr<IHTMLSelectionObject> spSelection;
		HRESULT hr = pDocument->get_selection(&spSelection);
		if (FAILED(hr))
			return;

		CComPtr<IDispatch> spDisp;
		hr = spSelection->createRange(&spDisp);
		if (FAILED(hr))
			return;
		
		CComQIPtr<IHTMLTxtRange> spTxtRange = spDisp;
		if (!spTxtRange)
			return;

		CComBSTR bstrText;
		hr = spTxtRange->get_text(&bstrText);
		if (FAILED(hr) || !bstrText)
			return;
		
		CString strBuff(bstrText);
		CString strUrl;
		strUrl = strtok((LPSTR)strBuff.GetBuffer(0), _T("\n"));
		do
		{
			int nFind = strUrl.Find("p://");
			if (nFind!=-1)
			{
				CString strProt = strUrl.Left(nFind+4);
				if(strProt == _T("ttp://")) strProt = _T("h") + strProt;
				else if(strProt == _T("tp://")) strProt = _T("ht") + strProt;
				strUrl = strUrl.Mid(nFind+4);

				strUrl = strProt + strUrl;
			}

			DonutOpenFile(m_hWnd, strUrl);
			strUrl = strtok(NULL, _T("\n"));
		}while(strUrl.IsEmpty()==FALSE);
	}

	struct _Function_SelectEmpt
	{
		_Function_SelectEmpt(){}
		void operator()(IHTMLDocument2* pDocument)
		{
			CComPtr<IHTMLSelectionObject> spSelection;
			HRESULT hr = pDocument->get_selection(&spSelection);
			if (spSelection)
				spSelection->empty();
		}
	};

	struct _Function_Hilight
	{
		LPCTSTR m_lpszKeyWord;
		BOOL m_bNowHilight;
		_Function_Hilight(LPCTSTR lpszKeyWord, BOOL bNowHilight) : m_lpszKeyWord(lpszKeyWord), m_bNowHilight(bNowHilight){}

		void operator()(IHTMLDocument2* pDocument)
		{
			if (m_bNowHilight==FALSE)
				MakeHilight(pDocument);
			else
				RemoveHilight(pDocument);
		}

		void MakeHilight(IHTMLDocument2* pDocument)
		{
			CString strKeyWord(m_lpszKeyWord);
			strKeyWord = strtok((LPSTR)strKeyWord.GetBuffer(0), " ");
			CString strExcept = _T(" \t\"\n�@");
			strKeyWord.TrimLeft(strExcept); strKeyWord.TrimRight(strExcept);

			int nLightIndex=0;
			HRESULT hr;
			while(!strKeyWord.IsEmpty())
			{
				CComPtr<IHTMLElement> spHTMLElement;
				CComPtr<IHTMLBodyElement> spHTMLBody;
				hr = pDocument->get_body(&spHTMLElement);
				if(FAILED(hr) || spHTMLElement == NULL) break;
				spHTMLElement->QueryInterface(IID_IHTMLBodyElement, (void**)&spHTMLBody);
				if (spHTMLBody==NULL) break;

				CComPtr<IHTMLTxtRange> spHTMLTxtRange;
				spHTMLBody->createTextRange(&spHTMLTxtRange);

				CComBSTR bstrText(strKeyWord);

				VARIANT_BOOL vBool=VARIANT_FALSE;
				spHTMLTxtRange->findText(bstrText, 1, 0, &vBool);
				while(vBool==VARIANT_TRUE)
				{
					CComBSTR bstrTextNow;
					spHTMLTxtRange->get_text(&bstrTextNow);

					CComBSTR bstrTextNew;
					bstrTextNew.Append(g_lpszLight[nLightIndex]);
					bstrTextNew.Append(bstrTextNow);
					bstrTextNew.Append(_T("</span>"));

					CComPtr<IHTMLElement> spParentElement;
					CComBSTR bstrParentTag;
					spHTMLTxtRange->parentElement(&spParentElement);
					spParentElement->get_tagName(&bstrParentTag);
					if(bstrParentTag == "TEXTAREA")
						spHTMLTxtRange->collapse(VARIANT_FALSE);

					spHTMLTxtRange->pasteHTML(bstrTextNew);
					spHTMLTxtRange->findText(bstrText, 1, 0, &vBool);
				}
				nLightIndex++;
				if (nLightIndex>=g_LIGHTMAX)
					nLightIndex=0;

				CString strText(bstrText), strTextNew(bstrText);
				strKeyWord = strtok(NULL, " ");
				strKeyWord.TrimLeft(strExcept); strKeyWord.TrimRight(strExcept);
			}
		}

		void RemoveHilight(IHTMLDocument2* pDocument)
		{
			CComBSTR testid(7,"DonutP");
			CComBSTR testtag(5,"SPAN");

			CComPtr<IHTMLElementCollection> spAllElements;
			pDocument->get_all(&spAllElements);

			CComPtr<IUnknown> lpUnk;
			CComPtr<IEnumVARIANT> lpNewEnum;
			if (SUCCEEDED(spAllElements->get__newEnum(&lpUnk)) && lpUnk != NULL)
			{
				lpUnk->QueryInterface(IID_IEnumVARIANT,(void**)&lpNewEnum);
				CComVariant varElement;

				while (lpNewEnum->Next(1, &varElement, NULL) == S_OK)
				{
					CComQIPtr<IHTMLElement> spElement=varElement.pdispVal;
					if (spElement)
					{
						CComBSTR id;
						CComBSTR tag;
						spElement->get_id(&id);
						spElement->get_tagName(&tag);
						if((id==testid)&&(tag==testtag))
						{
							BSTR innerText;
							spElement->get_innerHTML(&innerText);
							spElement->put_outerHTML(innerText);
						}
					}
					varElement.Clear();
				}
			}
		}
	};


	struct _Function_OpenSelectedRef
	{
		HWND m_hWnd;
		_Function_OpenSelectedRef(HWND hWnd) : m_hWnd(hWnd) { }

		void operator()(IHTMLDocument2* pDocument)
		{
			CComPtr<IHTMLSelectionObject> spSelection;
			HRESULT hr = pDocument->get_selection(&spSelection);
			if (FAILED(hr))
				return;

			CComPtr<IDispatch> spDisp;
			hr = spSelection->createRange(&spDisp);
			if (FAILED(hr))
				return;
		
			CComQIPtr<IHTMLTxtRange> spTxtRange = spDisp;
			if (!spTxtRange)
				return;

			CComBSTR bstrText;
			hr = spTxtRange->get_htmlText(&bstrText);
			if (FAILED(hr) || !bstrText)
				return;

			CComBSTR bstrLocationUrl;
			hr = pDocument->get_URL(&bstrLocationUrl);
			if (FAILED(hr))
				return;

			//BASE�^�O�ɑΏ����� minit
			CComPtr<IHTMLElementCollection> spAllClct;
			hr = pDocument->get_all(&spAllClct);
			if (SUCCEEDED(hr)){
				CComPtr<IHTMLElementCollection> spBaseClct;
				CComVariant val = _T("BASE");
				hr = spAllClct->tags(val,(IDispatch**)&spBaseClct);
				if (SUCCEEDED(hr)){
					long length;
					spBaseClct->get_length(&length);
					if(length > 0){
						CComPtr<IHTMLElement> spElem;
						CComVariant val1((int)0),val2((int)0);
						hr = spBaseClct->item(val1,val2,(IDispatch**)&spElem);
						if (SUCCEEDED(hr)){
							CComPtr<IHTMLBaseElement> spBase;
							hr = spElem->QueryInterface(&spBase);
							if (SUCCEEDED(hr)){
								CComBSTR bstrBaseUrl;
								hr = spBase->get_href(&bstrBaseUrl);
								if (SUCCEEDED(hr) && !(!bstrBaseUrl))
									bstrLocationUrl = bstrBaseUrl;
							}
						}
					}
				}
			}

			dcfTRACE(_T(" Selected:%s\n"), CString(bstrText).Left(200));

			CSimpleArray<CString> arrUrl;
			MtlCreateHrefUrlArray(arrUrl, CString(bstrText), CString(bstrLocationUrl));

			//DWORD dwOpenFlags = DonutGetStdOpenFlag();
			DWORD dwOpenFlags = 0;

			for (int i = 0; i < arrUrl.GetSize(); ++i) {
				CString str(arrUrl[i]);
				DonutOpenFile(m_hWnd, arrUrl[i],dwOpenFlags);
			}
		}
	};

	void OnBrowserClose()
	{
		dcfTRACE(_T("CChildFrame::OnBrowserClose\n"));
		SetMsgHandled(FALSE);
		m_bClosing = true;
		PostMessage(WM_CLOSE);
	}

	void OnSaveOption(LPCTSTR lpszFileName, int nIndex)
	{
		m_view.m_ViewOption.WriteProfile(lpszFileName, nIndex);
	}

	void OnViewBackX(WORD /*wNotifyCode*/, WORD wID, HWND /*hWndCtl*/)
	{
		int nStep = (wID - ID_VIEW_BACK1) + 1;
		CLockRedraw lock(m_hWnd);
		for (int i = 0; i < nStep; ++i)
			GoBack();
	}

	void OnViewForwardX(WORD /*wNotifyCode*/, WORD wID, HWND /*hWndCtl*/)
	{
		int nStep = (wID - ID_VIEW_FORWARD1) + 1;
		CLockRedraw lock(m_hWnd);
		for (int i = 0; i < nStep; ++i)
			GoForward();
	}

	void OnTitleCopy(WORD /*wNotifyCode*/, WORD wID, HWND /*hWndCtl*/)
	{
		MtlSetClipboardText(MtlGetWindowText(m_hWnd), m_hWnd);
	}

	void OnUrlCopy(WORD /*wNotifyCode*/, WORD wID, HWND /*hWndCtl*/)
	{
		MtlSetClipboardText(GetLocationURL(), m_hWnd);
	}

	void OnTitleAndUrlCopy(WORD /*wNotifyCode*/, WORD wID, HWND /*hWndCtl*/)
	{
		CString strText = MtlGetWindowText(m_hWnd) + _T("\r\n");
		strText += GetLocationURL();
		MtlSetClipboardText(strText, m_hWnd);
	}

	void OnSaveFavoriteTo(WORD /*wNotifyCode*/, WORD wID, HWND /*hWndCtl*/)
	{
		
	}

	// It will be a template method.
	void OnMDIActivate(HWND hwndChildDeact, HWND hwndChildAct)
	{
		dcfTRACE(_T("CChildFrame::OnMDIActivate\n"));
		SetMsgHandled(FALSE);
			
		if (hwndChildAct == m_hWnd) {	// I'm activated
			m_AddressBar.SetWindowText(GetLocationURL());
			_SetPageFocus();
			_RestoreFocus();
			return;
		}
		
		if (hwndChildDeact == m_hWnd) {		// I'm deactivated
			_SaveFocus();
		}

		{
			//�v���O�C���C�x���g - �A�N�e�B�u�^�u�ύX
			int nIndexDeact = m_MDITab.GetTabIndex(hwndChildDeact);
			int nIndexAct = m_MDITab.GetTabIndex(hwndChildAct);
			CPluginManager::BroadCast_PluginEvent(DEVT_TAB_CHANGEACTIVE,nIndexDeact,nIndexAct);
		}
	}

// Event handlers
	void OnSetSecureLockIcon(long nSecureLockIcon)
	{
		m_nSecureLockIcon = nSecureLockIcon;
	}

	void OnPrivacyImpactedStateChange(bool bPrivacyImpacted)
	{
		m_bPrivacyImpacted = bPrivacyImpacted;
ATLTRACE(_T("[OnPrivacyImpactedStateChange]\n"));
	}

	void OnStatusTextChange(const CString& strText)
	{
		{
			//�v���O�C���C�x���g - �X�e�[�^�X�e�L�X�g�ύX
			int nRet = CPluginManager::ChainCast_PluginEvent(DEVT_CHANGESTATUSTEXT,(FPARAM)(LPCTSTR)strText,0);
			if(nRet < 0) return;
		}

		BOOL bFilter=FALSE;
		if (m_view.m_ViewOption.m_dwExStyle&DVS_EX_MESSAGE_FILTER)
		{
			if (strText.Find("http")!=-1) bFilter=TRUE;
			if (strText.Find("ftp")!=-1) bFilter=TRUE;
			if (strText.Find("�ڑ�")!=-1) bFilter=TRUE;
			if (strText.Find("mailto")!=-1) bFilter=TRUE;
			if (strText.Find("file")!=-1) bFilter=TRUE;
			if (strText.Find("java")!=-1) bFilter=TRUE;
			if (strText.IsEmpty()) bFilter=TRUE;
			if (strText.Compare("�y�[�W���\������܂���") == 0) bFilter=TRUE; //minit
			if (bFilter==FALSE) return;
		}

		m_strStatusBar = strText;
		if (MDIGetActive() == m_hWnd) {
			CWindow wndFrame = GetTopLevelParent();
			HWND hWndStatus = wndFrame.GetDlgItem(ATL_IDW_STATUS_BAR);
			int nMode = (int)::SendMessage(hWndStatus,WM_GET_OWNERDRAWMODE,0,0);
			if(nMode)
				MtlSetStatusText(hWndStatus, strText);
			else
				MtlSetWindowText(hWndStatus, strText);

			// UDT DGSTR ( update
			LPCTSTR lpszText = strText;
			SendMessage(GetTopLevelParent(), WM_UPDATE_TITLEBAR, (WPARAM)lpszText, (LPARAM)0);
			// ENDE
		}
	}

	void OnDocumentComplete(IDispatch* pDisp, const CString& strURL)
	{

		if (IsPageIWebBrowser(pDisp)) {	// it means a page complete downloading
			dcfTRACE(_T("CChildFrame::OnDocumentComplete\n"));
			m_bWaitNavigateLock = false;// you are allowed!
			m_bExPropLock = FALSE;

			if (MDIGetActive() == m_hWnd && DonutBrowserCanSetFocus(m_hWnd)) {
				_SetPageFocus();
			}
		}

		//��p�X�^�C���V�[�g��ݒ肷��
		ApplyDefaultStyleSheet();

		//�߂�E�i�ނ̗��������[�h����
		SetTravelLogData();

		//�摜�t�@�C���Ȃ�IE�̐ݒ�ɂ��������ăT�C�Y��������
		CheckImageAutoSize(strURL,TRUE);

		//�I�[�g�n�C���C�g�@�\�����s
		DWORD dwStatus = 0;
		CIniSection pr;
		pr.Open(_szIniFileName,_T("SEARCH"));
		pr.QueryValue(dwStatus,_T("Status"));
		pr.Close();
		if(dwStatus&STS_AUTOHILIGHT)
			OnHilight(m_strSearchWord,FALSE);

		{
			//�v���O�C���C�x���g - ���[�h����
			//if(IsPageIWebBrowser(pDisp)){
				CComQIPtr<IWebBrowser2> pWB2 = pDisp;
				if(pWB2){
					DEVTS_TAB_DOCUMENTCOMPLETE dc;
					dc.lpstrURL = (LPCTSTR)strURL;
					CComBSTR bstrTitle;
					pWB2->get_LocationName(&bstrTitle);
					CString strTitle = bstrTitle;
					dc.lpstrTitle = (LPCTSTR)strTitle;
					dc.nIndex = m_MDITab.GetTabIndex(m_hWnd);
					dc.bMainDoc = IsPageIWebBrowser(pDisp);
					CPluginManager::BroadCast_PluginEvent(DEVT_TAB_DOCUMENTCOMPLETE,dc.nIndex,(DWORD)&dc);
				}
			//}
		}
	}

	void ApplyDefaultStyleSheet()
	{
		CString strSheet;
		CIniSection pr;
		pr.Open(_szIniFileName,_T("StyleSheet"));
		pr.QueryString(strSheet,_T("Default"),1024);
		pr.Close();
		if(!strSheet.IsEmpty()){
			StyleSheet(MtlGetFileName(strSheet),FALSE,strSheet);
		}
	}
	
	void SetTravelLogData()
	{
		if(m_bInitTravelLog){
			if(m_ArrayHistBack.size() == 0 && m_ArrayHistFore.size() == 0){
				//ini����ǂݍ���
				std::vector<std::pair<CString, CString> > ArrFore, ArrBack;
				_Load_TravelData(ArrFore,ArrBack,m_strDfgFileName,m_strSection);
				_Load_TravelLog(ArrFore,m_spBrowser,TRUE);
				_Load_TravelLog(ArrBack,m_spBrowser,FALSE);
			}else{
				//�z��̃f�[�^���g��
				_Load_TravelLog(m_ArrayHistFore,m_spBrowser,TRUE);
				_Load_TravelLog(m_ArrayHistBack,m_spBrowser,FALSE);
				m_ArrayHistBack.clear();
				m_ArrayHistFore.clear();
			}
		}
		m_bInitTravelLog = FALSE;
	}

	BOOL _Load_TravelData(std::vector<std::pair<CString, CString> >& arrFore,
						  std::vector<std::pair<CString, CString> >& arrBack,
						  CString& strFileName, CString& strSection)
	{
		if(strFileName.IsEmpty()) return FALSE;
		if(strSection.IsEmpty())  return FALSE;
		
		CIniSection pr;
		pr.Open(strFileName, strSection);

		int nBufSize = 1024;
		int i = 0;
		CString strTmp, strTitle, strURL; 
		while(1){
			strTmp.Format(_T("Fore_URL%d"),i);
			if(_QueryString(pr,strURL,strTmp,MAX_PATH) != ERROR_SUCCESS) break;
			strTmp.Format(_T("Fore_Title%d"),i);
			if(_QueryString(pr,strTitle,strTmp,1024) != ERROR_SUCCESS) break;
			if(strURL.IsEmpty()) break;

			arrFore.push_back(std::make_pair(strTitle,strURL));
			i++;
		}

		i=0;
		while(1){
			strTmp.Format(_T("Back_URL%d"),i);
			if(_QueryString(pr,strURL,strTmp,MAX_PATH) != ERROR_SUCCESS) break;
			strTmp.Format(_T("Back_Title%d"),i);
			if(_QueryString(pr,strTitle,strTmp,1024) != ERROR_SUCCESS) break;
			if(strURL.IsEmpty()) break;

			arrBack.push_back(std::make_pair(strTitle,strURL));
			i++;
		}

		return TRUE;
	}

	BOOL _Load_TravelLog(std::vector<std::pair<CString, CString> >& arrLog,
						 CComPtr<IWebBrowser2> pWB2, BOOL bFore)
	{
		if(arrLog.size() == 0) return FALSE;

		CIniSection pr;
		HRESULT hr;
		CComPtr<IServiceProvider> pISP;
		CComPtr<ITravelLogStg>    pTLStg;
		CComPtr<IEnumTravelLogEntry> pTLEnum;
		CComPtr<ITravelLogEntry> pTLEntryBase = NULL;
		int nDir;

		nDir   = bFore ? TLEF_RELATIVE_FORE : TLEF_RELATIVE_BACK;

		if(pWB2 == NULL) return FALSE;
		hr = pWB2->QueryInterface(IID_IServiceProvider,(void**)&pISP);
		if(FAILED(hr) || pISP == NULL) return FALSE;
		hr = pISP->QueryService(SID_STravelLogCursor,IID_ITravelLogStg,(void**)&pTLStg);
		if(FAILED(hr) || pTLStg == NULL) return FALSE;
		hr = pTLStg->EnumEntries(nDir,&pTLEnum);
		if(FAILED(hr) || pTLEnum == NULL) return FALSE;

		int nLast = (10 > arrLog.size()) ? arrLog.size() : 10;
		for(int i=0; i<nLast; i++){
			CString strURL, strTitle;
			CComPtr<ITravelLogEntry> pTLEntry;

			strTitle = arrLog[i].first;
			strURL =   arrLog[i].second;

			LPOLESTR pszwURL = _ConvertString(strURL, strURL.GetLength() + 1);   //new
			LPOLESTR pszwTitle = _ConvertString(strTitle, strTitle.GetLength() + 1); //new

			hr = pTLStg->CreateEntry(pszwURL,pszwTitle,pTLEntryBase,!bFore,&pTLEntry);
			delete [] pszwURL;    //Don't forget!
			delete [] pszwTitle;
			if(FAILED(hr) || pTLEntry == NULL) return FALSE;

			if(pTLEntryBase) pTLEntryBase.Release();
			pTLEntryBase = pTLEntry;
		}

		return TRUE;
	}

	LONG _QueryString(CIniSection& pr, CString& strBuf, CString& strKey, int bufSize)
	{
		if(bufSize <= 0) return ERROR_CANTREAD;
		DWORD dwCount = bufSize;
		int lRet = pr.QueryValue(strBuf.GetBuffer(bufSize),strKey,&dwCount);
		strBuf.ReleaseBuffer();

		return lRet;
	}

	LPOLESTR _ConvertString(LPCTSTR lpstrBuffer, int nBufferSize)
	{
		LPOLESTR pszwDest = new OLECHAR[ nBufferSize ];
		::MultiByteToWideChar(CP_ACP,0,lpstrBuffer,nBufferSize,pszwDest,nBufferSize*sizeof(OLECHAR));
		return pszwDest;
	}

	void CheckImageAutoSize(const CString& strURL, BOOL bFirst)
	{
		if(CMainOption::s_bStretchImage){
			CString strExt = MtlGetExt(strURL,false);
			strExt.MakeLower();
			if( m_nImgWidth != -1 || strExt == _T("bmp") || strExt == _T("jpg") || strExt == _T("jpeg") || 
							strExt == _T("gif") || strExt == _T("png"))
			{
				CComPtr<IHTMLDocument2> pDoc;
				if(FAILED(m_spBrowser->get_Document((IDispatch**)&pDoc))) return;
				CComPtr<IHTMLElementCollection> pElemClct;
				if(FAILED(pDoc->get_images(&pElemClct))) return;

				long length=0;
				pElemClct->get_length(&length);

				CComPtr<IDispatch> pDisp;
				CComPtr<IHTMLImgElement> pImg;
				CComVariant varName((long)0) , varIndex((long)0);
				if(FAILED(pElemClct->item(varName,varIndex,&pDisp))) return;
				if(FAILED(pDisp->QueryInterface(&pImg))) return;
				
				long Width = 0, Height = 0;
				if(bFirst){
					if(FAILED(pImg->get_width(&Width))) return;
					if(FAILED(pImg->get_height(&Height))) return;
					m_nImgWidth = Width;
					m_nImgHeight = Height;
				}else{
					Width = m_nImgWidth;
					Height = m_nImgHeight;
				}

				long scWidth, scHeight;
				if(FAILED(m_spBrowser->get_Width(&scWidth))) return;
				if(FAILED(m_spBrowser->get_Height(&scHeight))) return;
				scWidth = (scWidth - 20 < 0) ? 1 : scWidth - 20; 
				scHeight = (scHeight - 32 < 0) ? 1 : scHeight - 32;

				if(scWidth < Width || scHeight < Height){
					if(((double)scWidth) / Width < ((double)scHeight) / Height){
						pImg->put_width(scWidth);
					}else{
						pImg->put_height(scHeight);
					}
				}
			}


		}
	}

	void OnBeforeNavigate2(IDispatch* pDisp, const CString& strURL, DWORD nFlags,
		const CString& strTargetFrameName, CSimpleArray<BYTE>& baPostedData, const CString& strHeaders, bool& bCancel)
	{
		dcfTRACE(_T("CChildFrame::BeforeNavigate2 url(%s) frame(%s)\n"), strURL.Left(100), strTargetFrameName);

		{
			//�v���O�C���C�x���g - �i�r�Q�[�g�O
			DEVTS_TAB_NAVIGATE stn;
			stn.nIndex = m_MDITab.GetTabIndex(m_hWnd);
			stn.lpstrURL = (LPCTSTR)strURL;
			stn.lpstrTargetFrame = (LPCTSTR)strTargetFrameName;
			int nRet = CPluginManager::ChainCast_PluginEvent(DEVT_TAB_BEFORENAVIGATE,stn.nIndex,(SPARAM)&stn);
			if(nRet == -1){
				//�i�r�Q�[�g�L�����Z��
				bCancel = true;
				return;
			}else if(nRet == -2){
				//�N���[�Y
				bCancel = true;
				m_bNewWindow2 = false;
				m_bClosing = true;
				PostMessage(WM_CLOSE);// It's possible to post twice, but don't care.
				return;
			}
		}

		if (m_view.m_ViewOption.m_dwExStyle&DVS_EX_BLOCK_MAILTO)
		{
			CString strMailto=strURL.Left(6);
			strMailto.MakeUpper();
			if (strMailto.Compare(_T("MAILTO"))==0)
			{
				bCancel = true;
				return;
			}
		}

		if (m_bClosing)
		{
			bCancel = true;
			return;
		}

		// deter popups
		if (m_bNewWindow2 && IsPageIWebBrowser(pDisp) && CIgnoredURLsOption::SearchString(strURL))
		{	// close ignored url
			bCancel = true;
			m_bNewWindow2 = false;
			m_bClosing = true;
			PostMessage(WM_CLOSE);// It's possible to post twice, but don't care.

			{
				//�v���O�C���C�x���g - �|�b�v�A�b�v�}�~
				CPluginManager::BroadCast_PluginEvent(DEVT_BLOCKPOPUP,(FPARAM)(LPCTSTR)strURL,0);
			}

			return;
		}

		// javascript����n�܂�NewWindow��close
		if (m_bNewWindow2)
		{
			CString strJava=strURL.Left(10);
			strJava.MakeUpper();
			if (strJava.Find("JAVASCRIPT")!=-1)
			{
				bCancel = true;
				m_bNewWindow2 = false;
				m_bClosing = true;
				PostMessage(WM_CLOSE);// It's possible to post twice, but don't care.

				DonutOpenFile(m_hWnd, strURL);
				return;
			}
		}

		// Navigate lock
		if (!m_bExPropLock &&
			_check_flag(DVS_EX_OPENNEWWIN, m_view.m_ViewOption.m_dwExStyle) &&
			m_bWaitNavigateLock == false &&	!IsRefreshBeforeNavigate2(pDisp))
		{
			m_bExPropLock = FALSE;
			dcfTRACE(_T(" Locked, open new window\n"));
			CChildFrame* pChild = CChildFrame::NewWindow(m_hWndMDIClient, m_MDITab, m_AddressBar,
														 false, _GetInheritedDLControlFlags());
			if (pChild) {
				pChild->ActivateFrameForNewWindowDelayed();
				pChild->Navigate2(strURL);
				pChild->m_strSearchWord = m_strSearchWord;
			}
			bCancel = true;
			
			return;
		}
		m_bExPropLock = FALSE;

		// Note: Some ActivateFrame would go mad, because MDI client window not setup yet.
		if (m_bNewWindow2) {// delayed activation if OnNewWindow2 called
			ActivateFrameForNewWindowDelayed();
			m_bNewWindow2 = false;
		}

		// UH
		// �n�C���C�g���H���
		m_bNowHilight=FALSE;
		m_nPainBookmark=0;
		m_strBookmark=NULL;

		{
			//�C�x���g���� - �i�r�Q�[�g
			DEVTS_TAB_NAVIGATE stn;
			stn.nIndex = m_MDITab.GetTabIndex(m_hWnd);
			stn.lpstrURL = (LPCTSTR)strURL;
			stn.lpstrTargetFrame = (LPCTSTR)strTargetFrameName;
			CPluginManager::BroadCast_PluginEvent(DEVT_TAB_NAVIGATE,stn.nIndex,(SPARAM)&stn);
		}

	}

	void OnProgressChange(long progress, long progressMax)
	{
		m_nProgress = progress;
		m_nProgressMax = progressMax;
	}

	void OnCommandStateChange(long Command, bool bEnable)
	{
		if (Command == CSC_NAVIGATEBACK) {
			m_bNavigateBack = bEnable ? TRUE : FALSE;
		}		
		else if (Command == CSC_NAVIGATEFORWARD) {
			m_bNavigateForward = bEnable ? TRUE : FALSE;
		}
		else if (Command == CSC_UPDATECOMMANDS) {
		}
	}

	void OnDownloadComplete()
	{
		dcfTRACE(_T("CChildFrame::OnDownloadComplete\n"));

		if (m_bMozilla) {
			m_MDITab.SetComplete(m_hWnd);
			// required for mozilla cuz OnTitleChange seems to be not supported yet
			m_nProgress = m_nProgressMax = 0;
			SetWindowText(GetLocationName());

			// change address bar
			if (MDIGetActive() == m_hWnd)
				m_AddressBar.SetWindowText(GetLocationURL());
		}
	}

	void OnTitleChange(const CString& strTitle)
	{
		CString strURL = GetLocationURL();

		if (CCloseTitlesOption::SearchString(strTitle)) {
			m_bClosing = true;
			PostMessage(WM_CLOSE);

			{
				//�v���O�C���C�x���g - �^�C�g���}�~
				CPluginManager::BroadCast_PluginEvent(DEVT_BLOCKTITLE,(FPARAM)(LPCTSTR)strTitle,0);
			}

			return;
		}

		dcfTRACE(_T("OnTitleChange : %s\n"), strTitle.Left(100));
		// change title
		SetWindowText(MtlCompactString(strTitle, 255));

		// change address bar
		if (MDIGetActive() == m_hWnd)
			m_AddressBar.SetWindowText(strURL);

		m_bPrivacyImpacted = TRUE;
	}

	void OnNewWindow2(IDispatch** ppDisp, bool& bCancel)
	{
		dcfTRACE(_T("OnNewWindow2\n"));
		if (CMainOption::s_bAppClosing)
		{
			dcfTRACE(_T(" application closing, ignore this event\n"));
			bCancel = true;
			return;
		}
		
		m_MDITab.SetLinkState(LINKSTATE_A_ON);
		CChildFrame* pChild = CChildFrame::NewWindow(m_hWndMDIClient, m_MDITab, m_AddressBar, true, _GetInheritedDLControlFlags());
		//m_MDITab.SetLinkState(LINKSTATE_OFF);
		// Note: In this case, must be activated in BeforeNavigate2 strangely
		// pChild->ActivateFrameForNewWindowDelayed();
		if (pChild == NULL)
		{
			bCancel = true;
			return;
		}

		//Raise Plugin Event
		//CComBSTR bstr;
		//pChild->m_spBrowser->get_LocationURL(&bstr);
		//CPluginManager::ChainCast_PluginEvent(DEVT_TAB_OPENED,(DWORD)(LPCTSTR)CString(bstr),0);

		pChild->m_strSearchWord = m_strSearchWord;

		pChild->m_spBrowser->QueryInterface(IID_IDispatch, (void**)ppDisp);
		ATLASSERT(ppDisp != NULL);
	}

	DWORD _GetInheritedDLControlFlags()
	{
		DWORD dwDLFlags;
		if (_check_flag(MAIN_EX_INHERIT_OPTIONS, CMainOption::s_dwMainExtendedStyle))
			dwDLFlags = m_view._GetDLControlFlags();
		else
			dwDLFlags = CDLControlOption::s_dwDLControlFlags;// default

		return dwDLFlags;
	}

	void OnStateConnecting()
	{
		m_nSecureLockIcon = secureLockIconUnsecure;

		m_MDITab.SetConnecting(m_hWnd);
	}
	void OnStateDownloading()
	{
		m_MDITab.SetDownloading(m_hWnd);
	}
	void OnStateCompleted()
	{
		m_MDITab.SetComplete(m_hWnd);

		HWND hWndA2 = ::GetActiveWindow();
		HWND hWndF2 = ::GetFocus();

		if (m_hWndA) ::SetActiveWindow(m_hWndA);
		if (m_hWndF) ::SetFocus(m_hWndF);
	}
// Implementation
private:
	void _SaveFocus()
	{
		m_hWndFocus = ::GetFocus();
	}

	void _RestoreFocus()
	{
		if (m_hWndFocus && IsChild(m_hWndFocus) && ::GetFocus() != m_hWndFocus) {
			::SetFocus(m_hWndFocus);
		}
	}

	void _SetPageFocus()
	{
		dcfTRACE(_T("CChildFrame::_SetPageFocus(src:%d)\n"), ::GetFocus());
		if (m_bPageFocusInitialized)
			return;

		if (!MtlIsApplicationActive(m_hWnd))
			return;

		if (IsBrowserNull())
			return;

		CComPtr<IDispatch> spDisp;
		HRESULT hr = m_spBrowser->get_Document(&spDisp);
		if (FAILED(hr))
			return;

		CComQIPtr<IHTMLDocument2> spDoc = spDisp;
		if (!spDoc) // document not initialized yet
			return;

		CComPtr<IHTMLWindow2> spWnd;
		hr = spDoc->get_parentWindow(&spWnd);
		if (!spWnd)
			return;

		m_bPageFocusInitialized = true;	// avoid the endless loop
		hr = spWnd->focus();		// makes mainframe active
	}

	void _SetupWindowCloseHook()
	{
		HWND hWndBrowser;
		::EnumChildWindows(m_view.m_hWnd, (WNDENUMPROC)_EnumProc, (LPARAM)&hWndBrowser);
		ATLASSERT(::IsWindow(hWndBrowser));
		m_wndBrowser.SubclassWindow(hWndBrowser);
	}

	static BOOL CALLBACK _EnumProc(HWND hWnd, LPARAM lParam)
	{
		HWND* phWnd = (HWND*)lParam;
		*phWnd = hWnd;
		return FALSE;
	}

public:
// Update Command UI Map
	BEGIN_UPDATE_COMMAND_UI_MAP(CChildFrame)
		CHAIN_UPDATE_COMMAND_UI_MEMBER(m_view)

		UPDATE_COMMAND_UI_ENABLE_IF_WITH_POPUP(ID_VIEW_BACK, m_bNavigateBack, true)	// with popup
		UPDATE_COMMAND_UI_ENABLE_IF(ID_VIEW_FORWARD, m_bNavigateForward)

//		UPDATE_COMMAND_UI_SETDEFAULT_PASS(ID_VIEW_BACK1)
//		UPDATE_COMMAND_UI_SETDEFAULT_PASS(ID_VIEW_FORWARD1)

		UPDATE_COMMAND_UI_POPUP_ENABLE_IF(ID_VIEW_BACK1, m_bNavigateBack)	
		UPDATE_COMMAND_UI_POPUP_ENABLE_IF(ID_VIEW_FORWARD1, m_bNavigateForward)
		
		UPDATE_COMMAND_UI(ID_VIEW_FONT_SMALLEST, OnUpdateFontSmallestUI)
		UPDATE_COMMAND_UI(ID_VIEW_FONT_SMALLER, OnUpdateFontSmallerUI)
		UPDATE_COMMAND_UI(ID_VIEW_FONT_MEDIUM, OnUpdateFontMediumUI)
		UPDATE_COMMAND_UI(ID_VIEW_FONT_LARGER, OnUpdateFontLargerUI)
		UPDATE_COMMAND_UI(ID_VIEW_FONT_LARGEST, OnUpdateFontLargestUI)				// with popup

		UPDATE_COMMAND_UI(ID_DEFAULT_PANE, OnUpdateStatusBarUI)
		UPDATE_COMMAND_UI(IDC_PROGRESS, OnUpdateProgressUI)
		UPDATE_COMMAND_UI(ID_SECURE_PANE, OnUpdateSecureUI)
		UPDATE_COMMAND_UI(ID_PRIVACY_PANE, OnUpdatePrivacyUI)
		
		UPDATE_COMMAND_UI_SETCHECK_IF_PASS(ID_SERACHBAR_HILIGHT, m_bNowHilight)

		UPDATE_COMMAND_UI_ENABLE_IF_WITH_POPUP(ID_WINDOW_RESTORE, _GetShowCmd() != SW_SHOWNORMAL && !CMainOption::s_bTabMode, true)	// with popup
		UPDATE_COMMAND_UI_ENABLE_IF(ID_WINDOW_MOVE, _GetShowCmd() != SW_SHOWMAXIMIZED && !CMainOption::s_bTabMode)
		UPDATE_COMMAND_UI_ENABLE_IF(ID_WINDOW_SIZE, _GetShowCmd() != SW_SHOWMAXIMIZED && _GetShowCmd() != SW_SHOWMINIMIZED && !CMainOption::s_bTabMode)
		UPDATE_COMMAND_UI_ENABLE_IF(ID_WINDOW_MINIMIZE, _GetShowCmd() != SW_SHOWMINIMIZED && !CMainOption::s_bTabMode)
		UPDATE_COMMAND_UI_ENABLE_IF(ID_WINDOW_MAXIMIZE, _GetShowCmd() != SW_SHOWMAXIMIZED && !CMainOption::s_bTabMode)

		UPDATE_COMMAND_UI(ID_STYLESHEET_BASE, OnStyleSheetBaseUI)
	END_UPDATE_COMMAND_UI_MAP()

// Update Command UI Handlers
	void OnStyleSheetBaseUI(CCmdUI* pCmdUI)
	{
		if (pCmdUI->m_menuSub.m_hMenu) {// popup menu
			pCmdUI->m_menu.EnableMenuItem(pCmdUI->m_nIndex, MF_BYPOSITION | MF_ENABLED);
		}
	}

	void OnUpdateFontSmallestUI(CCmdUI* pCmdUI)
	{
		CComVariant var;
		ExecWB(OLECMDID_ZOOM, OLECMDEXECOPT_DONTPROMPTUSER,
			NULL, &var);

		pCmdUI->SetRadio(var == CComVariant(0L) ? true : false);
	}

	void OnUpdateFontSmallerUI(CCmdUI* pCmdUI)
	{
		CComVariant var;
		ExecWB(OLECMDID_ZOOM, OLECMDEXECOPT_DONTPROMPTUSER,
			NULL, &var);

		pCmdUI->SetRadio(var == CComVariant(1L) ? true : false);
	}

	void OnUpdateFontMediumUI(CCmdUI* pCmdUI)
	{
		CComVariant var;
		ExecWB(OLECMDID_ZOOM, OLECMDEXECOPT_DONTPROMPTUSER,
			NULL, &var);

		pCmdUI->SetRadio(var == CComVariant(2L) ? true : false);
	}

	void OnUpdateFontLargerUI(CCmdUI* pCmdUI)
	{
		CComVariant var;
		ExecWB(OLECMDID_ZOOM, OLECMDEXECOPT_DONTPROMPTUSER,
			NULL, &var);

		pCmdUI->SetRadio(var == CComVariant(3L) ? true : false);
	}

	void OnUpdateFontLargestUI(CCmdUI* pCmdUI)
	{
		if (pCmdUI->m_menuSub.m_hMenu) {// popup menu
			pCmdUI->m_menu.EnableMenuItem(pCmdUI->m_nIndex, MF_BYPOSITION | MF_ENABLED);
		}
		else {
			CComVariant var;
			ExecWB(OLECMDID_ZOOM, OLECMDEXECOPT_DONTPROMPTUSER,
				NULL, &var);

			pCmdUI->SetRadio(var == CComVariant(4L) ? true : false);
		}
	}

	void OnUpdateStatusBarUI(CCmdUI* pCmdUI)
	{
		pCmdUI->SetText(m_strStatusBar);
	}

	void OnUpdateSecureUI(CCmdUI* pCmdUI)
	{
		CStatusBarCtrl wndStatus = pCmdUI->m_wndOther;
		if (m_nSecureLockIcon!=secureLockIconUnsecure)
			wndStatus.SendMessage(WM_STATUS_SETICON, MAKEWPARAM(ID_SECURE_PANE, 0), 0);
		else
			wndStatus.SendMessage(WM_STATUS_SETICON, MAKEWPARAM(ID_SECURE_PANE, -1), 0);
	}

	void OnUpdatePrivacyUI(CCmdUI* pCmdUI)
	{
		CStatusBarCtrl wndStatus = pCmdUI->m_wndOther;
		if (m_bPrivacyImpacted==FALSE)
			wndStatus.SendMessage(WM_STATUS_SETICON, MAKEWPARAM(ID_PRIVACY_PANE, 1), 0);
		else
			wndStatus.SendMessage(WM_STATUS_SETICON, MAKEWPARAM(ID_PRIVACY_PANE, -1), 0);
	}

	void OnUpdateProgressUI(CCmdUI* pCmdUI)
	{
		CProgressBarCtrl progressbar = pCmdUI->m_wndOther;
		CStatusBarCtrl statusbar = pCmdUI->m_wndOther.GetParent();

		if (m_nProgress == -1 ||
			(m_nProgress == 0 && m_nProgressMax == 0)) {
			progressbar.ShowWindow(SW_HIDE);
			return;
		}

		CRect rcProgressPart;
		if (_bSwapProxy==false)
			statusbar.GetRect(1, rcProgressPart);
		else
			statusbar.GetRect(4, rcProgressPart);

		rcProgressPart.DeflateRect(2, 2);
		progressbar.MoveWindow(rcProgressPart, TRUE);
		progressbar.SetRange32(0, m_nProgressMax);
		progressbar.SetPos(m_nProgress);
		progressbar.ShowWindow(SW_SHOWNORMAL);
	}

	int _GetShowCmd()
	{
		CWindowPlacement wndpl;
		if (m_hWnd && ::GetWindowPlacement(m_hWnd, &wndpl)) {
			return wndpl.showCmd;
		}

		return -1;
	}

#define FLAG_SE_DLIMAGES		0x00000001
#define FLAG_SE_VIDEOS			0x00000002
#define FLAG_SE_BGSOUNDS		0x00000004
#define FLAG_SE_RUNACTIVEXCTLS	0x00000008
#define FLAG_SE_DLACTIVEXCTLS	0x00000010
#define FLAG_SE_SCRIPTS			0x00000020
#define FLAG_SE_JAVA			0x00000040

#define FLAG_SE_NAVIGATELOCK	0x00000080
#define FLAG_SE_MSGFILTER		0x00000100
#define FLAG_SE_MOUSEGESTURE	0x00000200
#define FLAG_SE_BLOCKMAILTO		0x00000400

#define FLAG_SE_VIEWED			0x00001000

#define FLAG_SE_REFRESH_NONE	0x00010000
#define FLAG_SE_REFRESH_15		0x00020000
#define FLAG_SE_REFRESH_30		0x00040000
#define FLAG_SE_REFRESH_1M		0x00080000
#define FLAG_SE_REFRESH_2M		0x00100000
#define FLAG_SE_REFRESH_5M		0x00200000
#define FLAG_SE_REFRESH_USER	0x00400000

#define FLAG_SE_NOREFRESH		0x01000000

	LRESULT OnGetExtendedTabStyle()
	{
		DWORD dwFlags = 0;
		DWORD dwDLFlags = m_view.GetDLControlFlags();
		DWORD dwViewExStyle = m_view.m_ViewOption.m_dwExStyle;
		DWORD dwRefreshStyle = m_view.m_ViewOption.m_dwAutoRefreshStyle;

		if(dwDLFlags&DLCTL_DLIMAGES) dwFlags |= FLAG_SE_DLIMAGES;
		if(dwDLFlags&DLCTL_VIDEOS)   dwFlags |= FLAG_SE_VIDEOS;
		if(dwDLFlags&DLCTL_BGSOUNDS) dwFlags |= FLAG_SE_BGSOUNDS;
		if(!(dwDLFlags&DLCTL_NO_RUNACTIVEXCTLS)) dwFlags |= FLAG_SE_RUNACTIVEXCTLS;
		if(!(dwDLFlags&DLCTL_NO_DLACTIVEXCTLS))  dwFlags |= FLAG_SE_DLACTIVEXCTLS;
		if(!(dwDLFlags&DLCTL_NO_SCRIPTS))        dwFlags |= FLAG_SE_SCRIPTS;
		if(!(dwDLFlags&DLCTL_NO_JAVA))           dwFlags |= FLAG_SE_JAVA;
		if(dwViewExStyle&DVS_EX_OPENNEWWIN)     dwFlags |= FLAG_SE_NAVIGATELOCK;
		if(dwViewExStyle&DVS_EX_MESSAGE_FILTER) dwFlags |= FLAG_SE_MSGFILTER;
		if(dwViewExStyle&DVS_EX_MOUSE_GESTURE)  dwFlags |= FLAG_SE_MOUSEGESTURE;
		if(dwViewExStyle&DVS_EX_BLOCK_MAILTO)   dwFlags |= FLAG_SE_BLOCKMAILTO;

		BYTE bytState = GetTabItemState(m_hWnd);
		if(!(bytState&TCISTATE_INACTIVE)) dwFlags |= FLAG_SE_VIEWED;

		if(dwRefreshStyle == 0)
			dwFlags |= FLAG_SE_REFRESH_NONE;
		else
			dwFlags |= (dwRefreshStyle * ( FLAG_SE_REFRESH_15 / DVS_AUTOREFRESH_15SEC));

		return dwFlags;
	}

	void OnSetExtendedTabStyle(DWORD dwStyle)
	{
		DWORD dwDLFlags = m_view.GetDLControlFlags();
		DWORD dwViewExStyle = m_view.m_ViewOption.m_dwExStyle;
		DWORD dwRefreshStyle = (dwStyle /  ( FLAG_SE_REFRESH_15 / DVS_AUTOREFRESH_15SEC)) & DVS_AUTOREFRESH_OR;

		if(dwStyle&FLAG_SE_DLIMAGES) dwDLFlags |= DLCTL_DLIMAGES;
		else						 dwDLFlags &= ~DLCTL_DLIMAGES;
		if(dwStyle&FLAG_SE_VIDEOS)   dwDLFlags |= DLCTL_VIDEOS;
		else						 dwDLFlags &= ~DLCTL_VIDEOS;
		if(dwStyle&FLAG_SE_BGSOUNDS) dwDLFlags |= DLCTL_BGSOUNDS;
		else						 dwDLFlags &= ~DLCTL_BGSOUNDS;
		if(dwStyle&FLAG_SE_RUNACTIVEXCTLS) dwDLFlags &= ~DLCTL_NO_RUNACTIVEXCTLS;
		else							   dwDLFlags |= DLCTL_NO_RUNACTIVEXCTLS;
		if(dwStyle&FLAG_SE_DLACTIVEXCTLS)  dwDLFlags &= ~DLCTL_NO_DLACTIVEXCTLS;
		else							   dwDLFlags |= DLCTL_NO_DLACTIVEXCTLS;
		if(dwStyle&FLAG_SE_SCRIPTS)        dwDLFlags &= ~DLCTL_NO_SCRIPTS;
		else							   dwDLFlags |= DLCTL_NO_SCRIPTS;
		if(dwStyle&FLAG_SE_JAVA)           dwDLFlags &= ~DLCTL_NO_JAVA;
		else							   dwDLFlags |= DLCTL_NO_JAVA;
		if(dwStyle&FLAG_SE_NAVIGATELOCK) dwViewExStyle |= DVS_EX_OPENNEWWIN;
		else							 dwViewExStyle &= ~DVS_EX_OPENNEWWIN;
		if(dwStyle&FLAG_SE_MSGFILTER)    dwViewExStyle |= DVS_EX_MESSAGE_FILTER;
		else							 dwViewExStyle &= ~DVS_EX_MESSAGE_FILTER;
		if(dwStyle&FLAG_SE_MOUSEGESTURE) dwViewExStyle |= DVS_EX_MOUSE_GESTURE;
		else							 dwViewExStyle &= ~DVS_EX_MOUSE_GESTURE;
		if(dwStyle&FLAG_SE_BLOCKMAILTO)  dwViewExStyle |= DVS_EX_BLOCK_MAILTO;
		else							 dwViewExStyle &= ~DVS_EX_BLOCK_MAILTO;

		int nIndex = m_MDITab.GetTabIndex(m_hWndA);
		if(dwStyle&FLAG_SE_VIEWED)
			m_MDITab.SetItemActive(nIndex);
		else
			m_MDITab.SetItemInactive(nIndex);

		//�i�r�Q�[�g���b�N�̕ύX�𔽉f������
		if((m_view.m_ViewOption.m_dwExStyle & DVS_EX_OPENNEWWIN)
			 != (dwStyle&FLAG_SE_NAVIGATELOCK))
		{
			m_MDITab.NavigateLockTab(m_hWnd, (dwStyle&FLAG_SE_NAVIGATELOCK) ? true: false);
		}
		m_MDITab.InvalidateRect(NULL);

		//�t���O��ύX����
		m_view.PutDLControlFlags(dwDLFlags);
		m_view.m_ViewOption.m_dwExStyle = dwViewExStyle;
		m_view.m_ViewOption.SetAutoRefreshStyle(dwRefreshStyle);

		//�ύX��K�p���邽�߂Ƀ��t���b�V������
		//m_view.Navigate2(m_view.GetLocationURL());
		if(!(dwStyle&FLAG_SE_NOREFRESH))
			::SendMessage(m_hWnd, WM_COMMAND, (WPARAM)(ID_VIEW_REFRESH & 0xFFFF), 0); 
	}

	CChildFrame* OnGetChildFrame()
	{
		return this;
	}


	void SetViewExStyle(DWORD dwStyle, BOOL bExProp = FALSE)
	{
		bool bNavigateLock = dwStyle&DVS_EX_OPENNEWWIN ? true : false;
		m_MDITab.NavigateLockTab(m_hWnd, bNavigateLock);
		m_view.m_ViewOption.m_dwExStyle = dwStyle;
		m_bExPropLock = (bNavigateLock && bExProp) ? true : false;
	}

	virtual void PreDocumentComplete(/*[in]*/ IDispatch* pDisp, /*[in]*/ VARIANT* URL);

};

/////////////////////////////////////////////////////////////////////////////