// Donut.cpp : main source file for Donut.exe
//



#include "stdafx.h"
#include "resource.h"


#include "DonutDefine.h"
#include "ItemIDList.h"
#include "mtl.h"

#include "ExMenu.h"
#include "ToolTipManager.h"
#include "DonutPFunc.h"



#include "DonutFavoritesMenu.h"
#include "DonutOptions.h"
#include "DonutSecurityZone.h"
#include "DonutSimpleEventManager.h"

// drafts
#include "DialogKiller.h"
#include "ReBarVerticalBorder.h"
#include "FileNotification.h"
#include "FlatComboBox.h"
// ENDED

#include "Donut.h"
#include "MainFrameFileDropTarget.h"
#include "DonutView.h"
#include "DonutClipboardBar.h"
#include "DonutRebarCtrl.h"
#include "FavTreeViewCtrl.h"
#include "DonutPanelBar.h"
#include "PluginBar.h"

#include "DonutExplorerBar.h"
#include "DonutLinksBarCtrl.h"
#include "DonutToolBar.h"
#include "DonutStatusBarCtrl.h"

#include "AddressBar.h"
#include "SearchBar.h"
#include "MDITabCtrl.h"

#include "FavoriteMenu.h"

#include "initguid.h"
#include "DonutP.h"
#include "DonutP_i.c"

#include "FileCriticalSection.h"
#include "MDIChildUserMessenger.h"
#include "dialog/aboutdlg.h"
#include "ChildFrm.h"
#include "MainFrm.h"

#include "API.h"

// Ini file name
TCHAR _szIniFileName[MAX_PATH];
int g_LIGHTMAX = 5;
char _cSeparater[] = _T("��������������������������������������������������������");
LPCTSTR g_lpszLight[] = {"<span id='DonutP' style='color:black;background:FFFF00'>", 
						"<span id='DonutP' style='color:black;background:00FFFF'>",
						"<span id='DonutP' style='color:black;background:FF00FF'>",
						"<span id='DonutP' style='color:black;background:7FFF00'>",
						"<span id='DonutP' style='color:black;background:1F8FFF'>"};
UINT _uDropDownCommandID[] = {ID_FILE_NEW, ID_VIEW_BACK, ID_VIEW_FORWARD, ID_FILE_NEW_CLIPBOARD2, ID_DOUBLE_CLOSE, ID_DLCTL_CHG_MULTI, ID_DLCTL_CHG_SECU, ID_URLACTION_COOKIES_CHG, ID_RECENT_DOCUMENT};
UINT _uDropDownWholeCommandID[] = {ID_VIEW_FONT_SIZE, ID_FAVORITES_DROPDOWN,
						ID_AUTO_REFRESH, ID_TOOLBAR, ID_EXPLORERBAR, ID_MOVE, ID_OPTION, ID_COOKIE_IE6, ID_FAVORITES_GROUP_DROPDOWN, ID_CSS_DROPDOWN };

int _uDropDownCommandCount=sizeof(_uDropDownCommandID)/sizeof(UINT);
int _uDropDownWholeCommandCount=sizeof(_uDropDownWholeCommandID)/sizeof(UINT);

TCHAR CDLControlOption::s_szUserAgent[MAX_PATH]; // UDT DGSTR
TCHAR CStartUpOption::s_szDfgPath[MAX_PATH];
bool g_bNoReposition=FALSE;

CServerAppModule	_Module;
CMainFrame*			g_pMainWnd=NULL;
CAPI*				g_pAPI=NULL;

BEGIN_OBJECT_MAP(ObjectMap)
	OBJECT_ENTRY(CLSID_API, CAPI)
END_OBJECT_MAP()




bool _PrivateInit(const CString& strCmdLine)
{
	MtlIniFileNameInit(_szIniFileName, _MAX_PATH);

	CIniSection pr;
	pr.Open(_szIniFileName, _T("Main"));
	pr.QueryValue(CMainOption::s_dwMainExtendedStyle, _T("Extended_Style"));
	pr.Close();

	if (CMainOption::s_dwMainExtendedStyle & MAIN_EX_ONEINSTANCE) {// guarantee one instance 
		HWND hWnd = ::FindWindow(_T("WTL:Donut"), NULL);
		if (hWnd) {
			if (!strCmdLine.IsEmpty()) {
				ATOM nAtom = ::GlobalAddAtom(strCmdLine);
				::PostMessage(hWnd, WM_NEWINSTANCE, (WPARAM)nAtom, 0);
			}
			return false;
		}
	}

	CMainOption::GetProfile();
	CDLControlOption::GetProfile();
	CIgnoredURLsOption::GetProfile();
	CCloseTitlesOption::GetProfile();
	CFileNewOption::GetProfile();
	CStartUpOption::GetProfile();
	CDonutConfirmOption::GetProfile();
	CStyleSheetOption::GetProfile();

	CFavoritesMenuOption::Init();
	CFileCriticalSection::Init();

	CSkinOption::GetProfile();
	CThemeDLLLoader::LoadThemeDLL();
	CExMenuManager::Initialize();

	return true;
}

void _PrivateTerm()
{
	CMainOption::WriteProfile();
	CDLControlOption::WriteProfile();
	CIgnoredURLsOption::WriteProfile();
	CCloseTitlesOption::WriteProfile();
	CFileNewOption::WriteProfile();
	CStartUpOption::WriteProfile();
	CDonutConfirmOption::WriteProfile();
	CStyleSheetOption::WriteProfile();

	CFavoritesMenuOption::Term();
	CFileCriticalSection::Term();

	CThemeDLLLoader::UnLoadThemeDLL();
	CExMenuManager::Terminate();

	// don't forget
	CHlinkDataObject::Term();
}


int Run(LPTSTR lpstrCmdLine = NULL, int nCmdShow = SW_SHOWDEFAULT)
{
	CMessageLoop theLoop;
	_Module.AddMessageLoop(&theLoop);

	CMainFrame wndMain;

	if(wndMain.CreateEx() == NULL)
	{
		ATLTRACE(_T("Main window creation failed!\n"));
		return 0;
	}
	g_pMainWnd = &wndMain;
	wndMain.ShowWindow(SW_MAXIMIZE);

	// load windowplacement
	CIniSection pr;
	pr.Open(_szIniFileName, _T("Main"));
	//MessageBox(wndMain.m_hWnd,_T("������\���̐ݒ���s���܂�"),_T("test"),MB_OK);
	MtlGetProfileMainFrameState_Chance(pr, wndMain, nCmdShow, CMainFrame::_Function_FullScreen(wndMain));
	pr.Close();

	_Module.Lock();
//	wndMain.ShowWindow(nCmdShow);

	CString strCmdLine(lpstrCmdLine);

	if (strCmdLine.IsEmpty()) {// no command line param
		CStartUpOption::StartUp(wndMain);
	}
	else {
		if (CStartUpOption::s_dwParam) CStartUpOption::StartUp(wndMain); // UDT DGSTR�@( dai

		if (strCmdLine.CompareNoCase(_T("/dde")) != 0) {// it's not from dde. (if dde, do nothing.)
			ATLTRACE(_T("it's not from dde!(%s)\n"), strCmdLine);
			// UDT DGSTR ( Shell Open )
			// in dup running , check WM_NEWINSTANCE.
			// fixed by JOBBY . thx ( local check , remove quota.
			int nPos = 0;
			if (strCmdLine.Left(4).CompareNoCase(_T("http"))==0)
			{
				while (1)
				{
					nPos = strCmdLine.Find(_T(" "));
					if ( nPos == -1 )
					{
						wndMain.OnUserOpenFile(strCmdLine , 0);
						break;
					}
					else
						wndMain.OnUserOpenFile(strCmdLine.Left(nPos) , 0);
					strCmdLine = strCmdLine.Mid(nPos+1);
				}
			}
			else
			{
				// remove first & last double-quotation
				if(strCmdLine.GetAt(0)=='"')
					strCmdLine=strCmdLine.Mid(1, strCmdLine.GetLength()-2);
				wndMain.OnUserOpenFile(strCmdLine, DonutGetStdOpenFlag());
			}
		}
	}

	int nRet = theLoop.Run();

	_Module.RemoveMessageLoop();
	return nRet;
}

HRESULT CreateComponentCategory(CATID catid, WCHAR* catDescription)
{
    ICatRegister* pcr = NULL;
    HRESULT hr = S_OK ;

    hr = CoCreateInstance(CLSID_StdComponentCategoriesMgr,
                          NULL,
                          CLSCTX_INPROC_SERVER,
                          IID_ICatRegister,
                          (void**)&pcr);
    if (FAILED(hr))
        return hr;

    // Make sure the HKCR\Component Categories\{..catid...}
    // key is registered.
    CATEGORYINFO catinfo;
    catinfo.catid = catid;
    catinfo.lcid = 0x0409 ; // english

    // Make sure the provided description is not too long.
    // Only copy the first 127 characters if it is.
    int len = wcslen(catDescription);
    if (len>127)
        len = 127;
    wcsncpy(catinfo.szDescription, catDescription, len);

    // Make sure the description is null terminated.
    catinfo.szDescription[len] = '\0';

    hr = pcr->RegisterCategories(1, &catinfo);
    pcr->Release();

    return hr;
}

HRESULT RegisterCLSIDInCategory(REFCLSID clsid, CATID catid)
{
    // Register your component categories information.
    ICatRegister* pcr = NULL ;
    HRESULT hr = S_OK ;
    hr = CoCreateInstance(CLSID_StdComponentCategoriesMgr,
                          NULL,
                          CLSCTX_INPROC_SERVER,
                          IID_ICatRegister,
                          (void**)&pcr);

    if (SUCCEEDED(hr))
    {
        // Register this category as being "implemented" by the class.
        CATID rgcatid[1] ;
        rgcatid[0] = catid;
        hr = pcr->RegisterClassImplCategories(clsid, 1, rgcatid);
    }

    if (pcr != NULL)
        pcr->Release();

    return hr;
}

HRESULT UnRegisterCLSIDInCategory(REFCLSID clsid, CATID catid)
{
    ICatRegister* pcr = NULL ;
    HRESULT hr = S_OK ;

    hr = CoCreateInstance(CLSID_StdComponentCategoriesMgr,
                          NULL,
                          CLSCTX_INPROC_SERVER,
                          IID_ICatRegister,
                          (void**)&pcr);
    if (SUCCEEDED(hr))
    {
        // Unregister this category as being "implemented" by the class.
        CATID rgcatid[1] ;
        rgcatid[0] = catid;
        hr = pcr->UnRegisterClassImplCategories(clsid, 1, rgcatid);
    }

    if (pcr != NULL)
    pcr->Release();

    return hr;
}

int RegisterCOMServer(int &nRet,bool &bRun, bool &bAutomation)
{
	HRESULT hRes;
	TCHAR szTokens[] = _T("-/");
	

	LPCTSTR lpszToken = _Module.FindOneOf(::GetCommandLine(), szTokens);
	while(lpszToken != NULL)
	{
		if(lstrcmpi(lpszToken, _T("UnregServer")) == 0)
		{
			nRet = _Module.UnregisterServer();

			nRet = UnRegisterCLSIDInCategory(CLSID_API,
				CATID_SafeForInitializing);
			if (FAILED(nRet)) return nRet;

			nRet = UnRegisterCLSIDInCategory(CLSID_API,
				CATID_SafeForScripting);
			if (FAILED(nRet)) return nRet;

			::MessageBox(NULL, _T("COM�T�[�o�[�폜���܂����B"), _T("unDonut"), 0);
			bRun = false;
			break;
		}
		else if(lstrcmpi(lpszToken, _T("RegServer")) == 0)
		{
			nRet = _Module.RegisterServer(TRUE, &CLSID_API);
			if (nRet==S_OK)
			{
				// Mark the control as safe for initializing.
				hRes = CreateComponentCategory(CATID_SafeForInitializing,
					L"Controls safely initializable from persistent data");
				if (FAILED(hRes)) return hRes;

				hRes = RegisterCLSIDInCategory(CLSID_API,
					CATID_SafeForInitializing);
				if (FAILED(hRes)) return hRes;

				// Mark the control as safe for scripting.
				hRes = CreateComponentCategory(CATID_SafeForScripting,
					L"Controls that are safely scriptable");
				if (FAILED(hRes))	return hRes;

				hRes = RegisterCLSIDInCategory(CLSID_API,
					CATID_SafeForScripting);
				if (FAILED(hRes))	return hRes;

				::MessageBox(NULL, _T("COM�T�[�o�[�o�^���܂����B"), _T("unDonut"), 0);
			}
			else
				::MessageBox(NULL, _T("COM�T�[�o�[�o�^���s���܂����B"), _T("unDonut"), 0);

			bRun = false;
			break;
		}
		else if((lstrcmpi(lpszToken, _T("Automation")) == 0) ||
			(lstrcmpi(lpszToken, _T("Embedding")) == 0))
		{
			bAutomation = true;
			break;
		}
		lpszToken = _Module.FindOneOf(lpszToken, szTokens);
	}

	return S_OK;
}


int WINAPI _tWinMain(HINSTANCE hInstance, HINSTANCE /*hPrevInstance*/, LPTSTR lpstrCmdLine, int nCmdShow)
{
#if defined(_DEBUG)
	//���������[�N���o�p
	//::_CrtSetDbgFlag(_CRTDBG_ALLOC_MEM_DF | _CRTDBG_LEAK_CHECK_DF
	//          | _CRTDBG_CHECK_ALWAYS_DF
	// );
	//_CrtSetBreakAlloc(874);
#endif



	HRESULT hRes = ::CoInitialize(NULL);
	hRes = ::OleInitialize(NULL);
	g_pMainWnd = NULL;

// If you are running on NT 4.0 or higher you can use the following call instead to 
// make the EXE free threaded. This means that calls come in on a random RPC thread.
//	HRESULT hRes = ::CoInitializeEx(NULL, COINIT_MULTITHREADED);
	ATLASSERT(SUCCEEDED(hRes));

	ATLTRACE(_T("tWinMain : \n"), lpstrCmdLine);

#if (_WIN32_IE >= 0x0300)
	INITCOMMONCONTROLSEX iccx;
	iccx.dwSize = sizeof(iccx);
	iccx.dwICC = ICC_COOL_CLASSES | ICC_BAR_CLASSES | ICC_USEREX_CLASSES;
	BOOL bRet = ::InitCommonControlsEx(&iccx);
	bRet;
	ATLASSERT(bRet);
#else
	::InitCommonControls();
#endif

	hRes = _Module.Init(ObjectMap, hInstance, &LIBID_ATLLib);
	ATLASSERT(SUCCEEDED(hRes));

	int nRet = 0;
	bool bRun = true;
	bool bAutomation = false;

	if (!_PrivateInit(lpstrCmdLine))
		goto END_APP;

	AtlAxWinInit();

	//�R�}���h���C�����͂ɂ���Ă�COM�T�[�o�[�o�^�y�щ������s��
	nRet = RegisterCOMServer(nRet,bRun,bAutomation); 
	if(FAILED(nRet))
		goto END_APP;

	CDonutSimpleEventManager::RaiseEvent(EVENT_PROCESS_START);

	if(bRun)
	{
		_Module.StartMonitor();
		hRes = _Module.RegisterClassObjects(CLSCTX_LOCAL_SERVER, REGCLS_MULTIPLEUSE | REGCLS_SUSPENDED);
		ATLASSERT(SUCCEEDED(hRes));
		hRes = ::CoResumeClassObjects();
		ATLASSERT(SUCCEEDED(hRes));

		if(bAutomation)
		{
			CMessageLoop theLoop;
			nRet = theLoop.Run();
		}
		else
		{
			nRet = Run(lpstrCmdLine, nCmdShow);
		}

		_Module.RevokeClassObjects();
		::Sleep(_Module.m_dwPause);
	}


	_PrivateTerm();
END_APP:
	try {
		_Module.Term();
		::OleUninitialize();
		::CoUninitialize();
	}catch (...) {
		//MessageBox(NULL,"��O���������܂����B","��O",MB_OK);
	}

	CDonutSimpleEventManager::RaiseEvent(EVENT_PROCESS_END);

	return nRet;
}




// CChildFrame
void CChildFrame::PreDocumentComplete(/*[in]*/ IDispatch* pDisp, /*[in]*/ VARIANT* URL)
{
	if ( !g_pAPI ) return;

	int nTabIndex = m_MDITab.GetTabIndex(m_hWnd);
	g_pAPI->Fire_DocumentComplete( nTabIndex, pDisp, V_BSTR(URL) );
}

/////////////////////////////////////////////////////////////////////////////
// CAPI
HRESULT STDMETHODCALLTYPE CAPI::Advise(IUnknown* pUnk, DWORD* pdwCookie)
{
	HRESULT hr = CProxyIDonutPEvents<CAPI>::Advise(pUnk, pdwCookie);
	if (SUCCEEDED(hr)){
		g_pAPI = this;
		m_aryCookie.Add(pdwCookie);
	}

	//CString str;
	//str.Format("Advise pUnk=%p cookie=%u",pUnk,*pdwCookie);
	//::MessageBox(NULL,str,_T("check"),MB_OK);
	return hr;
}

HRESULT STDMETHODCALLTYPE CAPI::Unadvise(DWORD dwCookie)
{
	HRESULT hr = CProxyIDonutPEvents<CAPI>::Unadvise(dwCookie);
	if (SUCCEEDED(hr))
		g_pAPI = NULL;

	//CString str;
	//str.Format("Unadvise cookie=%u",dwCookie);
	//::MessageBox(NULL,_T("unadvise"),_T("check"),MB_OK);
	return hr;
}

