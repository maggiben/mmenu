
#pragma once


#define DEB_EX_FAVBAR	0x00000001L
#define DEB_EX_CLPBAR	0x00000002L

#include "DockingChildBase.h"
#include "WindowCloseChecker.h"
#include "option/ExplorerBarDialog.h"
#include "FavTreeViewCtrl.h"
#include "DonutPFunc.h"

class CDonutExplorerBar : public CDockingChildBaseT<CDonutExplorerBar>,
                          public CUpdateCmdUI<CDonutExplorerBar>
{
public:
	DECLARE_WND_CLASS_EX(_T("Donut_ExplorerBar"), 0, -1)
	typedef CDockingChildBaseT<CDonutExplorerBar> baseClass;

// Data members
	CDonutFavoritesBar m_FavBar;

	DWORD				m_dwExStyle;
	int					m_nBottomAria;
	int					m_nIndexAct;
	std::vector<int>	m_aryID;
	CImageList			m_imgs;

	BOOL				m_bHideTab;
	HWND				m_hWndClient;

	// Ctor
	CDonutExplorerBar::CDonutExplorerBar():
		m_dwExStyle(DEB_EX_FAVBAR)
	{
		m_nBottomAria = 16;
		m_nIndexAct = 0;
		m_bHideTab = FALSE;

		int nID[]={ ID_VIEW_FAVEXPBAR, ID_VIEW_FAVEXPBAR_GROUP, ID_VIEW_FAVEXPBAR_HIST, 
			ID_VIEW_FAVEXPBAR_SCRIPT };
		for ( int ii=0; ii<(sizeof(nID)/sizeof(int)); ii++ )
			m_aryID.push_back(nID[ii]);

		CBitmap bmp;
		bmp.Attach(AtlLoadBitmapImage(GetSkinPath().GetBuffer(0), LR_LOADFROMFILE));
		m_imgs.Create(m_nBottomAria, m_nBottomAria, ILC_COLOR24 | ILC_MASK, (sizeof(nID)/sizeof(int)), 1);
		m_imgs.Add(bmp, RGB(255, 0, 255));
	}

	CString CDonutExplorerBar::GetSkinPath()
	{
		return _GetSkinDir()+_T("ExpBar.bmp");
	}

	void CDonutExplorerBar::Init()
	{
		_GetProfile();
	}

	void CDonutExplorerBar::UpdateLayout()
	{
		RECT rcClient;
		GetClientRect(&rcClient);
		UpdateLayout(rcClient.right, rcClient.bottom);
	}

	void CDonutExplorerBar::UpdateLayout(int cxWidth, int cyHeight)
	{
		if(!m_bHideTab){
			cyHeight -= m_nBottomAria + 1;
			CDCHandle dc = ::GetDC(m_hWnd);
			DrawBottomTab(dc);
		}
		if(m_hWndClient)
			::SetWindowPos(m_hWndClient,NULL,0,0,cxWidth,cyHeight,SWP_NOZORDER);
	}

// Message map and handlers
	BEGIN_MSG_MAP(CDonutExplorerBar)
		MESSAGE_HANDLER(WM_CREATE, OnCreate)
		MESSAGE_HANDLER(WM_DESTROY, OnDestroy)
		MESSAGE_HANDLER(WM_PAINT, OnPaint)
		MESSAGE_HANDLER(WM_LBUTTONUP, OnLButtonUp)
		MESSAGE_HANDLER(WM_SIZE,OnSize)
		MESSAGE_HANDLER(WM_ERASEBKGND, OnEraseBackGround)

		COMMAND_ID_HANDLER(ID_VIEW_FAVEXPBAR, OnViewFavExpBar)
		COMMAND_ID_HANDLER(ID_VIEW_FAVEXPBAR_HIST, OnViewFavExpBarHist)
		COMMAND_ID_HANDLER(ID_VIEW_FAVEXPBAR_GROUP, OnViewFavExpBarGroup)
		COMMAND_ID_HANDLER(ID_VIEW_FAVEXPBAR_USER, OnViewFavExpBarUser)
		COMMAND_ID_HANDLER(ID_VIEW_EXPBAR_SETFOCUS, OnViewExpBarSetFocus)
		COMMAND_ID_HANDLER(ID_VIEW_FAVEXPBAR_SCRIPT, OnViewFavExpBarScript)
		COMMAND_ID_HANDLER(ID_PANE_CLOSE, OnIDPaneClose)
		COMMAND_ID_HANDLER(ID_VIEW_EXPLORERBAR_TAB, OnViewExpBarTabs)

		USER_MSG_WM_OPEN_EXPFAVMENU(OnOpenFavExpMenu)
		if(m_FavBar.IsWindow()){
			CHAIN_MSG_MAP_MEMBER(m_FavBar)
		}
		CHAIN_MSG_MAP(CUpdateCmdUI<CDonutExplorerBar>)
		CHAIN_MSG_MAP(baseClass)
	
	//CDockingChildBase hasn't FORWARD_NOTIFICATIONS, then I removed ALT_MSG_MAP. (minit) 
	//ALT_MSG_MAP(1) // As CPaneContainer has FORWARD_NOTIFICATIONS, you have to separate a map.
		
	END_MSG_MAP()

	void CDonutExplorerBar::ReloadSkin()
	{
		_ReplaceImageList(GetSkinPath(),m_imgs);
		m_FavBar.ReloadSkin();
		m_FavBar.m_view.ReloadSkin();

		InvalidateRect(NULL,TRUE);
	}

	void CDonutExplorerBar::DrawBottomTab(CDCHandle dc)
	{
		RECT rcClient;
		GetClientRect(&rcClient);

		rcClient.top = rcClient.bottom - m_nBottomAria-1;
		dc.FillSolidRect( &rcClient, RGB(255,255,255) );


		int nTabWidth = (int)(m_nBottomAria*1.5);
		CRect rcTab(rcClient);
		rcTab.top -= 2;
		rcTab.left += 2;
		rcTab.right = rcTab.left + nTabWidth;

		CPen penFace, penBlack;
		penFace.CreatePen(PS_SOLID, 0, ::GetSysColor(COLOR_3DSHADOW));
		penBlack.CreatePen(PS_SOLID, 0, RGB(0,0,0));
		dc.SelectPen(penFace);
		for ( int nIndex=0; nIndex<(int)m_aryID.size(); nIndex++)
		{
			if (nIndex==m_nIndexAct)
			{
				dc.FillRect(&rcTab, COLOR_3DFACE);

				dc.SelectPen(penBlack);
				dc.MoveTo(rcTab.left, rcTab.bottom-1);
				dc.LineTo(rcTab.right-1, rcTab.bottom-1);
				dc.LineTo(rcTab.right-1, rcTab.top);
				dc.SelectPen(penFace);
			}
			else
			{
				dc.FillSolidRect(&rcTab, RGB(255,255,255));

				dc.MoveTo(rcTab.right-1, rcTab.top+3);
				dc.LineTo(rcTab.right-1, rcTab.bottom-3);
			}
			::ImageList_Draw(m_imgs, nIndex, dc, rcTab.left+(rcTab.Width()-m_nBottomAria)/2, rcTab.top+2, ILD_TRANSPARENT);

			rcTab.left += nTabWidth;
			rcTab.right += nTabWidth;

		}
	}

	LRESULT CDonutExplorerBar::OnOpenFavExpMenu(int x, int y)
	{
		CMenu menu; menu.LoadMenu(IDR_MENU_FAVTREE_BAR);
		UINT uMenuFlags = TPM_LEFTBUTTON | TPM_RIGHTBUTTON | TPM_LEFTALIGN | TPM_TOPALIGN;
		::TrackPopupMenu(menu.GetSubMenu(0), uMenuFlags, x , y , 0, GetTopLevelParent(), NULL);
		return 0;
	}

	LRESULT CDonutExplorerBar::OnSize(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
	{
		bHandled = FALSE;
		UpdateLayout();
		return 0;
	}

	LRESULT CDonutExplorerBar::OnEraseBackGround(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
	{
		return 1;
	}

	LRESULT CDonutExplorerBar::OnLButtonUp(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
	{
		if(m_bHideTab) return 0;

		POINT pt = { GET_X_LPARAM(lParam), GET_Y_LPARAM(lParam) };

		RECT rcClient;
		GetClientRect(&rcClient);

		int nTabWidth = (int)(m_nBottomAria*1.5);
		CRect rcTab(rcClient);
		//rcTab.top -= 2;
		rcTab.top = rcClient.bottom -m_nBottomAria;
		rcTab.left += 2;
		rcTab.right = rcTab.left + nTabWidth;

		for (int nIndex=0; nIndex<(int)m_aryID.size(); nIndex++)
		{
			if (rcTab.PtInRect(pt))
			{
				if (m_nIndexAct != nIndex)
				{
					m_nIndexAct = nIndex;
					
					Invalidate(FALSE);
					PostMessage(WM_COMMAND, m_aryID[nIndex], 0);
				}
				return 0;
			}
			rcTab.left += nTabWidth;
			rcTab.right += nTabWidth;
		}

		return 0;
	}

	LRESULT CDonutExplorerBar::OnCreate(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
	{
		bHandled = FALSE;
		return 0;
	}

	LRESULT CDonutExplorerBar::OnPaint(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
	{
		if(!m_bHideTab){
			CPaintDC dc(m_hWnd);
			DrawBottomTab( dc.m_hDC );
		}
		bHandled = FALSE;
		return 0;
	}
	LRESULT CDonutExplorerBar::OnDestroy(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
	{
		bHandled = FALSE;
		_WriteProfile();
		return 0;
	}

	LRESULT CDonutExplorerBar::OnViewFavExpBar(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/, BOOL& /*bHandled*/)
	{
		if (!IsWindowVisible()){
			UpSendMessage(WM_COMMAND, ID_FAVTREE_BAR_STANDARD);
			ShowBar(DEB_EX_FAVBAR);
		}
		else if (!IsFavBarVisible())
		{
			if ((m_FavBar.m_view.m_dwExplorerTreeViewExtendedStyle&ETV_EX_FAVORITES)!=ETV_EX_FAVORITES)
				UpSendMessage(WM_COMMAND, ID_FAVTREE_BAR_STANDARD);
			ShowBar(DEB_EX_FAVBAR);
		}
		else
		{
			if (m_FavBar.m_view.m_dwExplorerTreeViewExtendedStyle&ETV_EX_FAVORITES)
				HideBar();
			else
				UpSendMessage(WM_COMMAND, ID_FAVTREE_BAR_STANDARD);
		}

		return 0;
	}

	LRESULT CDonutExplorerBar::OnViewFavExpBarHist(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/, BOOL& /*bHandled*/)
	{
		if (!IsWindowVisible())
		{
			UpSendMessage(WM_COMMAND, ID_FAVTREE_BAR_HISTORY);
			ShowBar(DEB_EX_FAVBAR);
		}
		else if (!IsFavBarVisible())
		{
			if ((m_FavBar.m_view.m_dwExplorerTreeViewExtendedStyle&ETV_EX_HISTORY)!=ETV_EX_HISTORY)
				UpSendMessage(WM_COMMAND, ID_FAVTREE_BAR_HISTORY);
			ShowBar(DEB_EX_FAVBAR);
		}
		else {
			if (m_FavBar.m_view.m_dwExplorerTreeViewExtendedStyle&ETV_EX_HISTORY)
				HideBar();
			else
				UpSendMessage(WM_COMMAND, ID_FAVTREE_BAR_HISTORY);
		}

		return 0;
	}

	LRESULT CDonutExplorerBar::OnViewFavExpBarGroup(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/, BOOL& /*bHandled*/)
	{
		if (!IsWindowVisible()) {
			UpSendMessage(WM_COMMAND, ID_FAVTREE_BAR_GROUP);
			ShowBar(DEB_EX_FAVBAR);
		}
		else if (!IsFavBarVisible())
		{
			if ((m_FavBar.m_view.m_dwExplorerTreeViewExtendedStyle&ETV_EX_FAVORITEGROUP)!=ETV_EX_FAVORITEGROUP)
				UpSendMessage(WM_COMMAND, ID_FAVTREE_BAR_GROUP);
			ShowBar(DEB_EX_FAVBAR);
		}
		else
		{
			if (m_FavBar.m_view.m_dwExplorerTreeViewExtendedStyle&ETV_EX_FAVORITEGROUP)
				HideBar();
			else
				UpSendMessage(WM_COMMAND, ID_FAVTREE_BAR_GROUP);
		}

		return 0;
	}

	LRESULT CDonutExplorerBar::OnViewFavExpBarUser(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/, BOOL& /*bHandled*/)
	{
		if (!IsWindowVisible())
		{
			UpSendMessage(WM_COMMAND, ID_FAVTREE_BAR_USER);
			ShowBar(DEB_EX_FAVBAR);
		}
		else if (!IsFavBarVisible())
		{
			if ((m_FavBar.m_view.m_dwExplorerTreeViewExtendedStyle&ETV_EX_USERDEFINED)!=ETV_EX_USERDEFINED)
				UpSendMessage(WM_COMMAND, ID_FAVTREE_BAR_USER);
			ShowBar(DEB_EX_FAVBAR);
		}
		else
		{
			if (m_FavBar.m_view.m_dwExplorerTreeViewExtendedStyle&ETV_EX_USERDEFINED)
				HideBar();
			else
				UpSendMessage(WM_COMMAND, ID_FAVTREE_BAR_USER);
		}

		return 0;
	}

	LRESULT CDonutExplorerBar::OnViewFavExpBarScript(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/, BOOL& /*bHandled*/)
	{
		if (!IsWindowVisible())
		{
			UpSendMessage(WM_COMMAND, ID_FAVTREE_BAR_SCRIPT);
			ShowBar(DEB_EX_FAVBAR);
		}
		else if (!IsFavBarVisible())
		{
			if ((m_FavBar.m_view.m_dwExplorerTreeViewExtendedStyle&ETV_EX_SCRIPT)!=ETV_EX_SCRIPT)
				UpSendMessage(WM_COMMAND, ID_FAVTREE_BAR_SCRIPT);
			ShowBar(DEB_EX_FAVBAR);
		}
		else
		{
			if (m_FavBar.m_view.m_dwExplorerTreeViewExtendedStyle&ETV_EX_SCRIPT)
				HideBar();
			else
				UpSendMessage(WM_COMMAND, ID_FAVTREE_BAR_SCRIPT);
		}

		return 0;
	}

	LRESULT CDonutExplorerBar::OnIDPaneClose(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/, BOOL& /*bHandled*/)
	{
		HideBar();
		return 0;
	}

	LRESULT CDonutExplorerBar::OnViewExpBarTabs(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/, BOOL& /*bHandled*/)
	{
		m_bHideTab = !m_bHideTab;
		BOOL bShow = m_bHideTab ? FALSE : TRUE;
		ShowTab(bShow);
		return 0;
	}

	LRESULT CDonutExplorerBar::OnViewExpBarSetFocus(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/, BOOL& /*bHandled*/)
	{
		SetFocus();
		return 0;
	}

	// Methods
	BYTE CDonutExplorerBar::PreTranslateMessage(MSG* pMsg)
	{
		if (IsFavBarVisible())
			return m_FavBar.PreTranslateMessage(pMsg);
		else
			return _MTL_TRANSLATE_PASS;
	}

	// Attributes
	bool CDonutExplorerBar::IsFavBarVisible()
	{
		return _check_flag(DEB_EX_FAVBAR, m_dwExStyle);
	}

	void CDonutExplorerBar::ShowBar(DWORD dwExStyle)
	{
		_CreateOnDemandBar(dwExStyle);

		_SwitchClient(dwExStyle);
		m_dwExStyle = dwExStyle;

		/*if (dwExStyle&DEB_EX_FAVBAR && !bNotSetTitle)
		{
			if (m_FavBar.m_view.m_dwExplorerTreeViewExtendedStyle&ETV_EX_FAVORITES)
				SetTitle(_T("���C�ɓ���"));
			else if (m_FavBar.m_view.m_dwExplorerTreeViewExtendedStyle&ETV_EX_HISTORY)
				SetTitle(_T("����"));
			else if (m_FavBar.m_view.m_dwExplorerTreeViewExtendedStyle&ETV_EX_FAVORITEGROUP)
				SetTitle(_T("���C�ɓ���O���[�v"));
			else if (m_FavBar.m_view.m_dwExplorerTreeViewExtendedStyle&ETV_EX_USERDEFINED)
				SetTitle(_T("���[�U�[��`"));
			else if (m_FavBar.m_view.m_dwExplorerTreeViewExtendedStyle&ETV_EX_MYCOMPUTER)
				SetTitle(_T("�f�X�N�g�b�v"));
			else if (m_FavBar.m_view.m_dwExplorerTreeViewExtendedStyle&ETV_EX_SCRIPT)
				SetTitle(_T("�X�N���v�g"));
		}*/

		if(!IsWindowVisible())
			baseClass::Show();
		UpdateLayout();
	}

	void CDonutExplorerBar::HideBar()
	{
		m_dwExStyle = 0;
		Hide();
	}

	void CDonutExplorerBar::ShowTab(BOOL bShow)
	{
		m_bHideTab = !bShow;
		UpdateLayout();
	}

	void CDonutExplorerBar::_SwitchClient(DWORD dwStyle)
	{
		if (_check_flag(DEB_EX_FAVBAR, dwStyle))
		{	// fav bar
			_HideOtherBars();
			m_FavBar.ShowWindow(SW_SHOW);
			SetClient(m_FavBar.m_hWnd);
			//SetTitle(MtlGetWindowText(m_FavBar.m_hWnd));
		}
	}

	void CDonutExplorerBar::_HideOtherBars()
	{
		if (m_FavBar.m_hWnd != NULL)
			m_FavBar.ShowWindow(SW_HIDE);
	}

	void CDonutExplorerBar::_CreateOnDemandBar(DWORD dwExStyle)
	{
		if (_check_flag(DEB_EX_FAVBAR, dwExStyle))
		{	// on demand
			if (!m_FavBar.m_hWnd)
			{
				m_FavBar.Create(m_hWnd, rcDefault, NULL, WS_CHILD | WS_VISIBLE | WS_CLIPSIBLINGS | WS_CLIPCHILDREN, 0);
				m_FavBar.InitToolBar(ID_FAVORITE_ADD, ID_FAVORITE_ORGANIZE, ID_FAVORITE_PLACEMENT, IDB_FAVBAR, IDB_FAVBAR_HOT, 16, 16, RGB(255, 0, 255));
				m_FavBar.SetWindowText(_T("���C�ɓ���"));
			}
		}
	}

	
// Update command UI and handlers
	BEGIN_UPDATE_COMMAND_UI_MAP(CDonutExplorerBar)
		for (int ii=0; ii<(int)m_aryID.size(); ii++)
		{
//			if (nID!=m_aryID[ii]) continue;
//
			int nIndexAct = m_nIndexAct;
			switch(m_aryID[ii])
			{
			case ID_VIEW_FAVEXPBAR:
				if (IsFavBarVisibleNormal())	m_nIndexAct = ii; break;
			case ID_VIEW_FAVEXPBAR_HIST:
				if (IsFavBarVisibleHist())		m_nIndexAct = ii; break;
			case ID_VIEW_FAVEXPBAR_GROUP:
				if (IsFavBarVisibleGroup())		m_nIndexAct = ii; break;
			case ID_VIEW_FAVEXPBAR_USER:
				if (IsFavBarVisibleUser())		m_nIndexAct = ii; break;
			case ID_VIEW_FAVEXPBAR_SCRIPT:
				if (IsFavBarVisibleScript())	m_nIndexAct = ii; break;
			}
				
			if ( nIndexAct!=m_nIndexAct )
			{
				Invalidate(FALSE);
				break;
			}
		}

		UPDATE_COMMAND_UI_SETCHECK_IF(ID_VIEW_FAVEXPBAR, IsFavBarVisibleNormal())
		UPDATE_COMMAND_UI_SETCHECK_IF(ID_VIEW_FAVEXPBAR_HIST, IsFavBarVisibleHist())
		UPDATE_COMMAND_UI_SETCHECK_IF(ID_VIEW_FAVEXPBAR_GROUP, IsFavBarVisibleGroup())
		UPDATE_COMMAND_UI_SETCHECK_IF(ID_VIEW_FAVEXPBAR_USER, IsFavBarVisibleUser())
		UPDATE_COMMAND_UI_SETCHECK_IF(ID_VIEW_FAVEXPBAR_SCRIPT, IsFavBarVisibleScript())
		UPDATE_COMMAND_UI_SETCHECK_IF(ID_EXPLORERBAR, IsFavBarVisible())
		UPDATE_COMMAND_UI_SETCHECK_IF_PASS(ID_VIEW_EXPLORERBAR_TAB, !m_bHideTab)
		CHAIN_UPDATE_COMMAND_UI_MEMBER(m_FavBar)
	END_UPDATE_COMMAND_UI_MAP()
		
	void CDonutExplorerBar::_WriteProfile()
	{
		CIniSection pr;
		pr.Open(_szIniFileName, _T("Explorer_Bar"));

		pr.SetValue(m_dwExStyle, _T("Extended_Style"));
		pr.SetValue((int)m_bHideTab, _T("TabState"));
	}

	void CDonutExplorerBar::_GetProfile()
	{
		CIniSection pr;
		pr.Open(_szIniFileName, _T("Explorer_Bar"));

		DWORD dwExStyle = DEB_EX_FAVBAR;
		pr.QueryValue(dwExStyle, _T("Extended_Style"));

		DWORD dwHideTab=0;
		pr.QueryValue(dwHideTab,_T("TabState"));
		m_bHideTab = dwHideTab ? TRUE : FALSE;
		
		ShowBar(dwExStyle);

		//minit P5.0��4�̋@�\�̖͕�
		if (m_bHideTab){
			ShowTab(FALSE);
		}else{
			ShowTab(TRUE);
		}
		SetWindowText(_T("�G�N�X�v���[���o�["));
	}

	bool CDonutExplorerBar::IsFavBarVisibleNormal()
	{
		if (!IsWindowVisible() || IsFavBarVisible()==false)
			return false;

		_CreateOnDemandBar(m_dwExStyle);
		if (m_FavBar.m_view.m_dwExplorerTreeViewExtendedStyle&ETV_EX_FAVORITES)
			return true;
		else
			return false;
	}

	bool CDonutExplorerBar::IsFavBarVisibleScript()
	{
		if (!IsWindowVisible() || IsFavBarVisible()==false)
			return false;

		_CreateOnDemandBar(m_dwExStyle);
		if (m_FavBar.m_view.m_dwExplorerTreeViewExtendedStyle&ETV_EX_SCRIPT)
			return true;
		else
			return false;
	}

	bool CDonutExplorerBar::IsFavBarVisibleHist()
	{
		if (!IsWindowVisible() || IsFavBarVisible()==false)
			return false;

		_CreateOnDemandBar(m_dwExStyle);
		if (m_FavBar.m_view.m_dwExplorerTreeViewExtendedStyle&ETV_EX_HISTORY)
			return true;
		else
			return false;
	}

	bool CDonutExplorerBar::IsFavBarVisibleGroup()
	{
		if (!IsWindowVisible() || IsFavBarVisible()==false)
			return false;

		_CreateOnDemandBar(m_dwExStyle);
		if (m_FavBar.m_view.m_dwExplorerTreeViewExtendedStyle&ETV_EX_FAVORITEGROUP)
			return true;
		else
			return false;
	}

	bool CDonutExplorerBar::IsFavBarVisibleUser()
	{
		if (!IsWindowVisible() || IsFavBarVisible()==false)
			return false;

		_CreateOnDemandBar(m_dwExStyle);
		if (m_FavBar.m_view.m_dwExplorerTreeViewExtendedStyle&ETV_EX_USERDEFINED)
			return true;
		else
			return false;
	}

	void CDonutExplorerBar::SetClient(HWND hWndClient)
	{
		m_hWndClient = hWndClient;
	}

	void CDonutExplorerBar::UpSendMessage(UINT message, WPARAM wParam = 0, LPARAM lParam = 0)
	{
		GetTopLevelParent().SendMessage(message,wParam,lParam);
	}

	bool CDonutExplorerBar::PinBtnPress()
	{
		return baseClass::PinBtnPress();
	}

	bool CDonutExplorerBar::Show()
	{
		ShowBar(m_dwExStyle);
		return true;
	}

};







