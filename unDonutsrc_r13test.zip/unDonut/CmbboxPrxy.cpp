#include "stdafx.h"
#include "CmbboxPrxy.h"
#include "DonutPFunc.h"
#include "MtlUser.h"
#include "option/ProxyDialog.h"

CComboBoxPrxyR::CComboBoxPrxyR()
{
	m_nIDEvent = 0;
	m_bUseIE = UseIE();
}

LRESULT CComboBoxPrxyR::OnCommand(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
{
	bHandled = FALSE;
	WORD wNotifyCode = HIWORD(wParam);
	if (wNotifyCode==CBN_SELCHANGE)
		OnSelectChange();
	return 1;
}

void CComboBoxPrxyR::OnSelectChange()
{	
	int nIndex = GetCurSel();
	ChangeProxy(nIndex);
}

void CComboBoxPrxyR::ChangeProxy(int nIndex)
{
	if (m_bUseIE) return;
		
	//TCHAR cBuff[MAX_PATH];
	//memset(cBuff, 0, MAX_PATH);

	//GetLBText(nIndex, cBuff);
	//CString str(cBuff);
	CString str;
	MtlGetLBTextFixed(m_hWnd,nIndex,str);

	CString strBypass;

	INTERNET_PROXY_INFO proxyinfo;
	if (!str.IsEmpty())
	{
		proxyinfo.dwAccessType = INTERNET_OPEN_TYPE_PROXY;
		proxyinfo.lpszProxy = str;
		
		strBypass = GetBypass();
		if (strBypass.IsEmpty())
			proxyinfo.lpszProxyBypass = NULL;
		else
			proxyinfo.lpszProxyBypass = strBypass;
	}
	else
	{
		proxyinfo.dwAccessType = INTERNET_OPEN_TYPE_DIRECT;
		proxyinfo.lpszProxy = NULL;
		proxyinfo.lpszProxyBypass = NULL;
	}

	UrlMkSetSessionOption(INTERNET_OPTION_PROXY, &proxyinfo, sizeof(proxyinfo), 0);

	// �v���L�V�t�@�C���p�X
	CString strFile;
	strFile = _GetFilePath(_T("Proxy.ini"));

	CIniSection pr;
	pr.Open(strFile, _T("PROXY"));
	pr.SetValue((DWORD)nIndex, _T("TARGET"));
	pr.Close();

	// �^�C�}�[�w��
	ResetTimer();
}

void CComboBoxPrxyR::OnTimer(UINT wTimerID, TIMERPROC)
{
	ATLTRACE2(atlTraceGeneral, 4, _T("CComboBoxPrxy::OnTimer\n"));
	if (wTimerID == m_nIDEvent)
	{
		int nCount = GetCount()-1;
		if (nCount==0) return;

		time_t nTime;
		::time(&nTime);

		int nRand = abs(::rand()) * abs(nTime);
		nRand = nRand%nCount;
		nRand = abs(nRand) + 1;

		SetCurSel(nRand);
		ChangeProxy(nRand);
	}
	else
		SetMsgHandled(FALSE);
}

LRESULT CComboBoxPrxyR::OnRButtonDown(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
{
	CCenterPropertySheet sheet( _T("�v���L�V�ݒ�") );
	CProxyPropertyPage pageProxy;
	
	sheet.AddPage(pageProxy);
	sheet.DoModal();
	ResetProxyList();
	return 0;
}

void CComboBoxPrxyR::SetProxy()
{
	// �v���L�V�t�@�C���p�X
	CString strFile;
	strFile = _GetFilePath(_T("Proxy.ini"));

	// �v���L�V�ԍ�
	DWORD dwIndex = 0;
	CIniSection pr;
	pr.Open(strFile, _T("PROXY"));
	pr.QueryValue(dwIndex, _T("TARGET"));
	pr.Close();

	// �w��ԍ��ɂ���
	int nIndex = SetCurSel((int)dwIndex);
	ChangeProxy(nIndex);
}

void CComboBoxPrxyR::ResetProxyList()
{
	if (m_bUseIE)
	{
		EnableWindow(FALSE);
		return;
	}

	ResetContent();
	AddString("");

	// �v���L�V�t�@�C���p�X
	CString strFile;
	strFile = _GetFilePath(_T("Proxy.ini"));

	CIniSection pr;
	pr.Open(strFile, _T("PROXY"));

	//vvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvv
	// �v���L�V
	DWORD dwLineCnt = 0;
	pr.QueryValue(dwLineCnt, _T("MAX"));
	for (int ii=0; ii<(int)dwLineCnt; ii++)
	{
		CString strKey;
		strKey.Format("%d", ii);

		TCHAR cBuff[MAX_PATH];
		DWORD dwCount=MAX_PATH;
		pr.QueryValue(cBuff, strKey, &dwCount);

		CString strProxy(cBuff);
		if (strProxy.IsEmpty()) continue;
		AddString(cBuff);
	}
	pr.Close();
	//^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

	// �v���L�V�ݒ�
	SetProxy();
}

void CComboBoxPrxyR::ResetTimer()
{
	// �v���L�V�t�@�C���p�X
	CString strFile;
	strFile = _GetFilePath(_T("Proxy.ini"));

	CIniSection pr;

	//vvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvv
	// �����_��
	pr.Open(strFile, _T("RAND"));

	DWORD dwRandChk=0;
	pr.QueryValue(dwRandChk, _T("Enabel"));

	DWORD dwRandTimeMin = 5;
	pr.QueryValue(dwRandTimeMin, _T("Min"));

	DWORD dwRandTimeSec = 0;
	pr.QueryValue(dwRandTimeSec, _T("Sec"));

	pr.Close();
	//^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

	// �����_���w��Ȃ�
	if (dwRandChk==0)
	{
		if (m_nIDEvent != 0)
		{
			MTLVERIFY(::KillTimer(m_hWnd, m_nIDEvent));
			m_nIDEvent = 0;
		}
		return;
	}

	// �^�C�}�[�ݒ�
	int nAutoChgTime = (dwRandTimeMin*60 + dwRandTimeSec)*1000;
	m_nIDEvent = ::SetTimer(m_hWnd, 1, nAutoChgTime, NULL);
}

// �h�d���g��
BOOL CComboBoxPrxyR::UseIE()
{
	// �v���L�V�t�@�C���p�X
	CString strFile;
	strFile = _GetFilePath(_T("Proxy.ini"));

	CIniSection pr;
	//vvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvv
	// ���[�J��
	pr.Open(strFile, _T("USE_IE"));
	DWORD dwUseIE=1;
	pr.QueryValue(dwUseIE, _T("Enabel"));
	pr.Close();
	//^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

	return (BOOL)dwUseIE;
}

// �o�C�p�X�𓾂�
CString CComboBoxPrxyR::GetBypass()
{
	// �v���L�V�t�@�C���p�X
	CString strFile;
	strFile = _GetFilePath(_T("Proxy.ini"));

	CIniSection pr;

	CString strBypass;

	//vvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvv
	// ��v���L�V
	pr.Open(strFile, _T("NOPROXY"));
	DWORD dwLineCnt = 0;
	pr.QueryValue(dwLineCnt, _T("MAX"));
	for (int ii=0; ii<(int)dwLineCnt; ii++)
	{
		CString strKey;
		strKey.Format("%d", ii);

		TCHAR cBuff[MAX_PATH];
		DWORD dwCount=MAX_PATH;
		pr.QueryValue(cBuff, strKey, &dwCount);

		CString strProxy(cBuff);
		if (strProxy.IsEmpty()) continue;

		if (strBypass.IsEmpty()==FALSE)
			strBypass = strBypass + _T(";");
		strBypass = strBypass + strProxy;
	}
	pr.Close();
	//^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

	//vvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvv
	// ���[�J��
	pr.Open(strFile, _T("LOCAL"));
	DWORD dwLocalChk=0;
	pr.QueryValue(dwLocalChk, _T("Enabel"));
	if (dwLocalChk==TRUE)
		strBypass = strBypass + _T(";<local>");
	pr.Close();
	//^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
	return strBypass;
}


