#pragma once


/*
	CCustomContextMenu
	atlhostEx.h����ړ������J�X�^���R���e�L�X�g���j���[�̏�������

	�����S���������������B�Ȃɂ���Ă���̂�������Ȃ��������B�������͎̂����ł���(minit)
*/

#include "MtlUser.h"
#include "ToolTipManager.h"
#include "DonutPFunc.h"


class CCustomContextMenu
{
public:
	HWND m_hWndTopLevel;

	HRESULT Show(DWORD dwId, DWORD x, DWORD y, IUnknown* pCommandTarget)
	{
		//�E�B���h�E�n���h�����~�����BpCommandTarget������Ȃ����낤��
		CComQIPtr<IOleWindow> pWindow = pCommandTarget;
		if(!pWindow) ATLASSERT(FALSE);
		HWND hWnd;
		HRESULT hr = pWindow->GetWindow(&hWnd);
		if(FAILED(hr)) ATLASSERT(FALSE);
		m_hWndTopLevel = CWindow(hWnd).GetTopLevelWindow();
		
		CPoint pt(x,y);
		return ShowContextMenu(dwId,&pt,pCommandTarget,NULL);
	}

protected:
	HRESULT ShowContextMenuEx(POINT* pptPosition)
	{
		//�܂����j���[�p�̃��\�[�X���g�p����Ă���΂�����J������
		::SendMessage(GetTopLevelWindow(),WM_RELEASE_CONTEXTMENU,0,0);

		CMenu menu;

		menu.CreatePopupMenu();

		MENUITEMINFO menuInfo;
		memset(&menuInfo, 0, sizeof(MENUITEMINFO));
		menuInfo.cbSize = sizeof(MENUITEMINFO);
		menuInfo.fMask = MIIM_ID|MIIM_TYPE;

		CSimpleArray<HMENU>			aryDestroyMenu;
		CString strPath = _GetFilePath(_T("Menu.ini"));
		DWORD dwCount=0;
		CString strKey;
		dwCount = ::GetPrivateProfileInt(_T("MenuEx"), _T("Count"), 0, strPath);
		for (DWORD ii=0; ii<dwCount; ii++)
		{
			strKey.Format("%02d", ii);
			DWORD dwCmd=0;
			dwCmd = ::GetPrivateProfileInt(_T("MenuEx"), strKey, 0, strPath);

			CString strCmd;
			CToolTipManager::LoadToolTipText(dwCmd, strCmd);
			if (strCmd.IsEmpty()==FALSE)
			{
				menuInfo.fType = MFT_STRING;
				menuInfo.wID = dwCmd;
				menuInfo.dwTypeData = strCmd.GetBuffer(0);
				menuInfo.cch = strCmd.GetLength();
			}
			else
			{
				menuInfo.fType = MFT_SEPARATOR;
			}

			::InsertMenuItem(menu.m_hMenu, ii, MF_BYPOSITION, &menuInfo);
			CstmContextMenuDropdown(menu.m_hMenu, dwCmd, aryDestroyMenu);

			//���ꃁ�j���[�̏����� minit
			_BeforeInitSpecialMenu(dwCmd);
		}

		// �ҏW���Ȃ����j���[�Ƃ���
		menuInfo.fType = MFT_SEPARATOR;
		::InsertMenuItem(menu.m_hMenu, 0, MF_BYPOSITION, &menuInfo);

		//�\�����̓��C�����j���[�̕��ɑ��郁�b�Z�[�W�𐧌����� minit
		::SendMessage(GetTopLevelWindow(),WM_MENU_RESTRICT_MESSAGE,(WPARAM)TRUE,0);

		// Show shortcut menu
		DWORD dwREqualL = 0;
		dwREqualL = ::GetPrivateProfileInt(_T("Option"), _T("REqualL"), 0, strPath);

		DWORD dwMenuStyle = TPM_LEFTALIGN | TPM_RETURNCMD;
		if (dwREqualL) dwMenuStyle |= TPM_RIGHTBUTTON;
		int iSelection = ::TrackPopupMenu(menu.m_hMenu,
									  dwMenuStyle,
									  pptPosition->x,
									  pptPosition->y,
									  0,
									  GetTopLevelWindow(),
									  (RECT*)NULL);
		for(int jj=0; jj<aryDestroyMenu.GetSize(); jj++)
			::DestroyMenu(aryDestroyMenu[jj]);

		HWND hWndTopLevelParent = GetTopLevelWindow();
		::SendMessage(hWndTopLevelParent, WM_COMMAND, iSelection, NULL);

		//���b�Z�[�W�̐������������� minit
		::PostMessage(hWndTopLevelParent,WM_MENU_RESTRICT_MESSAGE,(WPARAM)FALSE,0);

		return S_OK;
	}

	// MSHTML requests to display its context menu
	STDMETHOD(ShowContextMenu)(DWORD dwID, POINT* pptPosition, IUnknown* pCommandTarget, IDispatch* pDispatchObjectHit)
	{
		//�܂����j���[�p�̃��\�[�X���g�p����Ă���΂�����J������
		::SendMessage(GetTopLevelWindow(),WM_RELEASE_CONTEXTMENU,0,0);

		if (::GetKeyState(VK_LBUTTON)<0 || ::GetKeyState(VK_LBUTTON)<0)
			return ShowContextMenuEx(pptPosition);

		if ( dwID!=CONTEXT_MENU_DEFAULT && dwID!=CONTEXT_MENU_TEXTSELECT 
			&& dwID!=CONTEXT_MENU_ANCHOR )
			return S_FALSE;

		#define IDR_BROWSE_CONTEXT_MENU  24641
		#define IDR_FORM_CONTEXT_MENU    24640
		#define SHDVID_GETMIMECSETMENU   27
		#define SHDVID_ADDMENUEXTENSIONS 53

		HRESULT hr;
		HINSTANCE hinstSHDOCLC;
		HWND hwnd;
		HMENU hMenu, hMenuSub;
		CComPtr<IOleCommandTarget> spCT;
		CComPtr<IOleWindow> spWnd;
		CComVariant var, var1, var2;


		hr = pCommandTarget->QueryInterface(IID_IOleCommandTarget, (void**)&spCT);
		hr = pCommandTarget->QueryInterface(IID_IOleWindow, (void**)&spWnd);
		hr = spWnd->GetWindow(&hwnd);

		hinstSHDOCLC = LoadLibrary(TEXT("SHDOCLC.DLL"));

		hMenu = LoadMenu(hinstSHDOCLC, MAKEINTRESOURCE(IDR_BROWSE_CONTEXT_MENU));
		hMenuSub = GetSubMenu(hMenu, dwID);

		// Get the language submenu
		hr = spCT->Exec(&CGID_ShellDocView, SHDVID_GETMIMECSETMENU, 0, NULL, &var);
		MENUITEMINFO mii = {0};
		mii.cbSize = sizeof(mii);
		mii.fMask  = MIIM_SUBMENU;
		mii.hSubMenu = (HMENU) var.byref;
#define IDM_LANGUAGE 2292
		SetMenuItemInfo(hMenuSub, IDM_LANGUAGE, FALSE, &mii);

		// Insert Shortcut Menu Extensions from registry
		V_VT(&var1) = VT_INT_PTR;
		V_BYREF(&var1) = hMenuSub;

		V_VT(&var2) = VT_I4;
		V_I4(&var2) = dwID;

		hr = spCT->Exec(&CGID_ShellDocView, SHDVID_ADDMENUEXTENSIONS, 0, &var1, &var2);

		CSimpleMap<DWORD, DWORD>	mapCmd;
		CSimpleArray<HMENU>			aryDestroyMenu;
		CstmContextMenu(hMenuSub, dwID, mapCmd, aryDestroyMenu);

		//�������O���b�Z�[�W�𑗂�
		for (int ii=0; ii<mapCmd.GetSize(); ii++)
			_BeforeInitSpecialMenu(mapCmd.GetValueAt( ii ));

		//�\�����̓��C�����j���[�̕��ɑ��郁�b�Z�[�W�𐧌����� minit
		::SendMessage(GetTopLevelWindow(),WM_MENU_RESTRICT_MESSAGE,(WPARAM)TRUE,0);

		// Show shortcut menu
		CString strPath = _GetFilePath(_T("Menu.ini"));
		DWORD dwREqualL = 0;
		dwREqualL = ::GetPrivateProfileInt(_T("Option"), _T("REqualL"), 0, strPath);

		int nCmdAddFav = MtlGetCmdIDFromAccessKey(hMenuSub, _T("&F"));

		DWORD dwMenuStyle = TPM_LEFTALIGN | TPM_RETURNCMD;
		if (dwREqualL) dwMenuStyle |= TPM_RIGHTBUTTON;
		int iSelection = ::TrackPopupMenu(hMenuSub,
									  dwMenuStyle,
									  pptPosition->x,
									  pptPosition->y,
									  0,
									  GetTopLevelWindow(),
									  (RECT*)NULL);

		
		

		// Send selected shortcut menu item command to shell
		LRESULT lRes = S_OK;
		if ( iSelection != 0 )
			lRes = ::SendMessage(hwnd, WM_COMMAND, iSelection, NULL);
		BOOL bSendFrm = FALSE;
		// �R�}���h�͈�
		if (COMMAND_RANGE_START<=iSelection && iSelection<=COMMAND_RANGE_END)
			bSendFrm = TRUE;
		// ���C�ɓ���A�O���[�v
		else if ((FAVORITE_MENU_ID_MIN<=iSelection && iSelection<=FAVORITE_MENU_ID_MAX) ||
			     (FAVGROUP_MENU_ID_MIN<=iSelection && iSelection<=FAVGROUP_MENU_ID_MAX))
			bSendFrm = TRUE;
		// �X�N���v�g
		else if (ID_INSERTPOINT_SCRIPTMENU<=iSelection && iSelection<=ID_INSERTPOINT_SCRIPTMENU_END)
			bSendFrm = TRUE;

		if (bSendFrm==FALSE && mapCmd.Lookup((DWORD)iSelection))
			bSendFrm = TRUE;

		
		HWND hWndTopLevelParent = GetTopLevelWindow();
		
		if (bSendFrm)
			lRes = ::SendMessage(hWndTopLevelParent, WM_COMMAND, iSelection, NULL);
		//���̎��_�ŃE�B���h�E��������Ă��܂��\�������邯��ǂ��E�E

		if(iSelection == nCmdAddFav)
			::SendMessage(hWndTopLevelParent,WM_REFRESH_EXPBAR,0,0);

		//�����ł��ЂÂ�
		for( ii=0; ii<aryDestroyMenu.GetSize(); ii++ )
			::DestroyMenu(aryDestroyMenu[ii]);

		for ( ii=0; ii<mapCmd.GetSize(); ii++){
			::RemoveMenu( hMenuSub, mapCmd.GetKeyAt( ii ), MF_BYCOMMAND );
			_RestoreSpecialMenu(mapCmd.GetValueAt( ii ));
		}
		
		//���b�Z�[�W�̐������������� minit
		::PostMessage(hWndTopLevelParent,WM_MENU_RESTRICT_MESSAGE,(WPARAM)FALSE,0);

		::DestroyMenu(hMenu);
		FreeLibrary(hinstSHDOCLC);
		
		return S_OK;
	}

	void _RestoreSpecialMenu(DWORD dwCmd)
	{
		if(dwCmd == ID_FAVORITES_DROPDOWN)
			::SendMessage(GetTopLevelWindow(), WM_MENU_REFRESH_FAV, (WPARAM)FALSE, 0);
		else if(dwCmd == ID_FAVORITES_GROUP_DROPDOWN)
			::SendMessage(GetTopLevelWindow(), WM_MENU_REFRESH_FAV_GROUP, (WPARAM)FALSE, 0);
		else if(dwCmd == ID_SCRIPT)
			::SendMessage(GetTopLevelWindow(), WM_MENU_REFRESH_SCRIPT, (WPARAM)FALSE, 0);

	}

	void _BeforeInitSpecialMenu(DWORD dwCmd)
	{
		if(dwCmd == ID_FAVORITES_DROPDOWN)
			::SendMessage(GetTopLevelWindow(), WM_MENU_REFRESH_FAV, (WPARAM)TRUE, 0);
		else if(dwCmd == ID_FAVORITES_GROUP_DROPDOWN)
			::SendMessage(GetTopLevelWindow(), WM_MENU_REFRESH_FAV_GROUP, (WPARAM)TRUE, 0);
		else if(dwCmd == ID_SCRIPT)
			::SendMessage(GetTopLevelWindow(), WM_MENU_REFRESH_SCRIPT, (WPARAM)TRUE, 0);

	}

	void CstmContextMenu(HMENU hMenu, DWORD dwID, CSimpleMap<DWORD, DWORD> &mapCmd, CSimpleArray<HMENU> &aryDestroyMenu)
	{
		for (int ii=0; ii<8 && dwID==CONTEXT_MENU_DEFAULT; ii++)
			::DeleteMenu(hMenu, 0 ,MF_BYPOSITION);

		MENUITEMINFO menuInfo;
		memset(&menuInfo, 0, sizeof(MENUITEMINFO));
		menuInfo.cbSize = sizeof(MENUITEMINFO);
		menuInfo.fMask = MIIM_ID|MIIM_TYPE;

		CString strPath = _GetFilePath(_T("Menu.ini"));
		DWORD dwCount=0;
		CString strSection;		strSection.Format("Type%d", dwID);
		dwCount = ::GetPrivateProfileInt(strSection, _T("FrontCount"), 0, strPath);
		for (DWORD jj=0; jj<dwCount; jj++)
		{
			CString strKey;
			strKey.Format("Front%02d", jj);
			DWORD dwCmd = ::GetPrivateProfileInt(strSection, strKey, 0, strPath);

			CString strCmd;
			CToolTipManager::LoadToolTipText(dwCmd, strCmd);
			if (strCmd.IsEmpty()==FALSE)
			{
				menuInfo.fType = MFT_STRING;
				menuInfo.wID = dwCmd;
				menuInfo.dwTypeData = strCmd.GetBuffer(0);
				menuInfo.cch = strCmd.GetLength();

				// �R�}���h���o����
				DWORD value = 1;
				if(dwCmd == ID_FAVORITES_DROPDOWN)
					value = 2;
				else if(dwCmd == ID_FAVORITES_GROUP_DROPDOWN)
					value = 3;
				else if(dwCmd == ID_SCRIPT)
					value = 4;
				mapCmd.Add(dwCmd, value);
			}
			else
			{
				menuInfo.fType = MFT_SEPARATOR;
			}
			::InsertMenuItem(hMenu, jj, MF_BYPOSITION, &menuInfo);

			CstmContextMenuDropdown(hMenu, dwCmd, aryDestroyMenu);
		}

		dwCount = ::GetPrivateProfileInt(strSection, _T("BackCount"), 0, strPath);
		for (jj=0; jj<dwCount; jj++)
		{
			CString strKey;
			strKey.Format("Back%02d", jj);
			DWORD dwCmd = ::GetPrivateProfileInt(strSection, strKey, 0, strPath);

			CString strCmd;
			CToolTipManager::LoadToolTipText(dwCmd, strCmd);
			if (strCmd.IsEmpty()==FALSE)
			{
				menuInfo.fType = MFT_STRING;
				menuInfo.wID = dwCmd;
				menuInfo.dwTypeData = strCmd.GetBuffer(0);
				menuInfo.cch = strCmd.GetLength();

				// �R�}���h���o����
				mapCmd.Add(dwCmd, 1);
			}
			else
			{
				menuInfo.fType = MFT_SEPARATOR;
			}
			::InsertMenuItem(hMenu, ::GetMenuItemCount(hMenu), MF_BYPOSITION, &menuInfo);

			CstmContextMenuDropdown(hMenu, dwCmd, aryDestroyMenu);
		}

		// �ҏW���Ȃ����j���[�Ƃ���
		menuInfo.fType = MFT_SEPARATOR;
		::InsertMenuItem(hMenu, 0, MF_BYPOSITION, &menuInfo);
	}

	void CstmContextMenuDropdown(HMENU hMenu, DWORD dwCmd, CSimpleArray<HMENU> &aryDestroyMenu)
	{
		MENUITEMINFO mii = {0};
		mii.cbSize = sizeof(mii);
		mii.fMask  = MIIM_SUBMENU;

		CMenuHandle menu;
		DWORD dwID=0;
		switch(dwCmd)		
		{
		case ID_FAVORITES_DROPDOWN:
			mii.hSubMenu = (HMENU)::SendMessage(GetTopLevelWindow(), WM_MENU_GET_FAV, 0, 0);
			break;

		case ID_FAVORITES_GROUP_DROPDOWN:
			mii.hSubMenu = (HMENU)::SendMessage(GetTopLevelWindow(), WM_MENU_GET_FAV_GROUP, 0, 0);
			break;

		case ID_SCRIPT:
			mii.hSubMenu = (HMENU)::SendMessage(GetTopLevelWindow(), WM_MENU_GET_SCRIPT, 0, 0);
			break;

		case ID_DLCTL_CHG_MULTI:	dwID = IDR_MULTIMEDIA;		break;
		case ID_DLCTL_CHG_SECU: 	dwID = IDR_SECURITY;		break;
		case ID_VIEW_FONT_SIZE:		dwID = IDR_VIEW_FONT_SIZE;	break;
		case ID_COOKIE_IE6:			dwID = IDR_COOKIE_IE6;		break;
		default: return; break;
		}

		if (dwID!=0)
		{
			menu.LoadMenu(dwID);
			HMENU hMenuSub = menu.GetSubMenu(0);
			mii.hSubMenu = hMenuSub;
			aryDestroyMenu.Add(hMenuSub);
		}
		SetMenuItemInfo(hMenu, dwCmd, FALSE, &mii);
	}
	
	HWND GetTopLevelWindow()
	{
		return m_hWndTopLevel;
	}

};