#pragma once
#include <atlctrls.h>

#include "StringEncoder.h"
#include <winnls32.h>

#define STS_ENG_CHANGE_GO		0x00000001
#define STS_DROP_GO				0x00000002
#define STS_HISTORY_SAVE		0x00000004
#define STS_NO_REPOSITION		0x00000008
#define STS_KEY_CHANGE_GO		0x00000010
#define STS_HEIGHTCOUNT			0x00000020
#define STS_TEXT_FILTER			0x00000040
#define STS_LASTSEL				0x00000080
#define STS_SCROLLCENTER		0x00000100
#define STS_ACTIVEWINDOW		0x00000200
#define STS_AUTOHILIGHT			0x00000400

#define STB_SHOWTOOLBARICON		0x00000001

#define DEFAULT_HEIGHTCOUNT		25
#define MAXHEIGHTCOUNT			100

#define ENT_READ_ENG		1
#define ENT_READ_HIST		2

#define ENTER_KEYDOWN_RETURN		0
#define ENTER_KEYDOWN_SELCHANGE		1

#define ENCODE_NONE			0
#define ENCODE_SHIFT_JIS	1
#define ENCODE_EUC			2
#define ENCODE_UTF8			3

extern bool g_bNoReposition;
template <class T>
class CSearchBarCtrlImpl:
	public CDialogImpl<CSearchBarCtrlImpl>,
	public IDropTargetImpl<T>,
	public IDropSourceImpl<T>
{
public:
	typedef CSearchBarCtrlImpl<T> thisClass;

	enum { IDD = IDD_SEARCHBAR_FORM };
	CFlatComboBox m_cmbKeyword;
	CFlatComboBox m_cmbEngin;
	CToolBarCtrl m_wndToolBar;

	HANDLE m_hThreadEngin;
	HANDLE m_hThreadKeyword;
	HCURSOR m_hCursor;
	CPoint m_ptDragHist;
	CPoint m_ptDragStart;
	CPoint m_ptDragEnd;
	CContainedWindow m_wndKeyword;
	CContainedWindow m_wndEngin;

	enum {m_nBarCX = 2, m_nBmpCX=16, m_nBmpCY=16, s_kcxGap=2};

	enum {m_nDefEditT = 1, m_nDefDlgH = 22 };

	bool m_bDragAccept;
	bool m_bDragFromItself;
	int m_cxBtnsBtn;
	BOOL m_bShowToolBar;
	BOOL m_bLoadedToolBar;
	BOOL m_bFiltering;
	int m_clrMask;
	BOOL m_bActiveWindow;
	HWND m_hWndKeywordList;
	CContainedWindow m_wndKeywordCombo;

	//option
	BOOL m_bUseShortcut;

	struct _ThreadParam
	{
		thisClass* pSearchBar;
		HANDLE _hExitEvent;
	};

	_ThreadParam	m_ThreadParams;
	HANDLE			m_hThread;


	CSearchBarCtrlImpl():
		m_wndKeyword(this, 1),
		m_wndEngin(this, 2),
		m_wndKeywordCombo(this, 3)
	{
		m_hThreadEngin = NULL;
		m_hThreadKeyword = NULL;
		m_hCursor = NULL;

		m_bDragAccept = false;
		m_bDragFromItself = false;
		m_bShowToolBar = FALSE;
		m_bLoadedToolBar = FALSE;

		m_bFiltering = FALSE;

		m_bUseShortcut = FALSE;
		m_bActiveWindow = FALSE;
	}

// Message map and handlers
	BEGIN_MSG_MAP(CDonutSearchBarEx)
		MSG_WM_INITDIALOG(OnInitDialog)
		MSG_WM_DESTROY(OnDestroy)
		MSG_WM_MOUSEMOVE(OnMouseMove)
		MSG_WM_LBUTTONDOWN(OnLButtonDown)
		MSG_WM_LBUTTONUP(OnLButtonUp)
		MSG_WM_COMMAND(OnCommand)
		NOTIFY_CODE_HANDLER(TTN_GETDISPINFO, OnToolTipText)

		MESSAGE_HANDLER(WM_SIZE, OnSize)
		MESSAGE_HANDLER(WM_ERASEBKGND, OnEraseBkgnd)
		COMMAND_HANDLER_EX(IDC_CMB_ENGIN, CBN_SELCHANGE, OnSelChange)
		COMMAND_HANDLER_EX(IDC_CMB_KEYWORD, CBN_SELCHANGE, OnSelChange)
	ALT_MSG_MAP(1)
		MSG_WM_CHAR(OnChar)
		MSG_WM_KEYDOWN(OnKeywordKeyDown)
	ALT_MSG_MAP(2)
		MSG_WM_KEYDOWN(OnEnginKeyDown)
		MSG_WM_RBUTTONUP(OnEnginRButtonUp)
		MSG_WM_SETFOCUS(OnEnginSetFocus)
		MSG_WM_KILLFOCUS(OnEnginKillFocus)
		MESSAGE_HANDLER(WM_CTLCOLORLISTBOX, OnCtlColor) 
	ALT_MSG_MAP(3)
		MESSAGE_HANDLER(WM_CTLCOLORLISTBOX,OnCtlColorListBox)
	END_MSG_MAP()
	

	//�Ȃɂ��`�悪���������Ȃ�o�O��fix minit
	LRESULT OnEraseBkgnd(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
	{
		// CAddressBarCtrlImpl����R�s�y
		HWND hWnd = GetParent();
		CPoint pt(0, 0);
		MapWindowPoints(hWnd, &pt, 1);
		pt = ::OffsetWindowOrgEx((HDC)wParam, pt.x, pt.y, NULL);
		LRESULT lResult = ::SendMessage(hWnd, WM_ERASEBKGND, wParam, 0L);
		::SetWindowOrgEx((HDC)wParam, pt.x, pt.y, NULL);
		return lResult;

		//bHandled = TRUE;
		//::SendMessage(GetParent(), uMsg, wParam, lParam);
		//return 1;
	}


	LRESULT OnToolTipText(int idCtrl, LPNMHDR pnmh, BOOL& /*bHandled*/)
	{
		LPNMTTDISPINFO pDispInfo = (LPNMTTDISPINFO)pnmh;
		pDispInfo->szText[0] = 0;
		if (pDispInfo->uFlags & TTF_IDISHWND) return S_OK;

		CString strKeyword = MtlGetWindowText(m_wndKeyword);

		CString strHeader = _T('\"');
		CString strHelp = _T("\" ��");
		CString strEngin = MtlGetWindowText(m_wndEngin);
		TCHAR szBuff[80];
		AtlCompactPathFixed(szBuff, strKeyword, 80 - strHelp.GetLength() - strHeader.GetLength());
		strHeader += szBuff;
		strHeader += strHelp;
		switch (idCtrl)
		{
		case ID_SEARCH_WEB:
			strHeader += _T("\"") + strEngin + _T("\"�Ō�������");
			break;

		case ID_SEARCH_PAGE:
			strHeader += _T("���̃y�[�W�Ō�������(��:Shift+Enter ��:Ctrl+Enter)");
			break;

		case ID_SEARCH_HILIGHT:
			strHeader += _T("�n�C���C�g����");
			break;
		}

		::lstrcpyn(pDispInfo->szText, strHeader, 80);

		return S_OK;
	}

	void OnCommand(UINT uFlag, int nID, HWND hWndCtrl)
	{
		if (hWndCtrl == m_wndToolBar.m_hWnd)
		{
			CEdit edit = GetEditCtrl();
			CString str = MtlGetWindowText(edit);
			
			switch(nID){
			case ID_SEARCH_WEB:
				_OnCommand_SearchWeb(str);
				break;

			case ID_SEARCH_HILIGHT:
				_OnCommand_SearchHilight(str);
				break;

			case ID_SEARCH_PAGE:
				_OnCommand_SearchPage((::GetKeyState(VK_SHIFT)<0) ? FALSE : TRUE);
				break;
			}
		}
		SetMsgHandled(FALSE);
	}

	void _OnCommand_SearchWeb(CString& str)
	{
		if (!str.IsEmpty())
		{
			T* pT = static_cast<T*>(this);
			pT->OnItemSelected(str);
			_AddToSearchBoxUnique(str);
		}
	}

	void _OnCommand_SearchHilight(CString& str)
	{
		str = RemoveShortcutWord(str);
		if(m_bFiltering)
			FilterString(str);
		SendMessage(GetTopLevelParent(), WM_USER_HILIGHT, (WPARAM)str.GetBuffer(0), 0);
	}

	void _OnCommand_SearchPage(BOOL bForward)
	{
		CEdit edit = GetEditCtrl();
		CString str = _GetSelectText(edit);

		//���p���E�V���[�g�J�b�g���[�h�͏��O
		str = RemoveShortcutWord(str);
		CString strExcept = _T(" \t\"\n�@");
		str.TrimLeft(strExcept); str.TrimRight(strExcept);

		if(m_bFiltering)
			FilterString(str);
		SendMessage(GetTopLevelParent(), WM_USER_FIND_KEYWORD, (WPARAM)str.GetBuffer(0), (LPARAM)bForward);
	}

	CString RemoveShortcutWord(CString& str)
	{
		if(m_bUseShortcut){
			if(str.Find(_T("\\")) == 0 || str.Find(_T("/")) == 0){
				int nPos = str.Find(_T(" "));
				if(nPos != -1)
					return str.Mid(nPos+1);
			}
		}
		return str;
	}

	LRESULT OnSize(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
	{	
		//if (!m_wndToolBar.m_hWnd)
		//	return S_FALSE;
		if(!m_wndKeyword.m_hWnd)
			return S_FALSE;

		CRect rcDlg;
		GetClientRect(&rcDlg);

		CRect rcToolbar(rcDlg);
		CString str;
		
		if(rcDlg.right == 0) return S_FALSE;
		if(GetToolIconState()){
			rcToolbar.left = rcDlg.right - m_cxBtnsBtn-10;
			m_wndToolBar.SetWindowPos(NULL, rcToolbar, SWP_NOZORDER|SWP_NOSENDCHANGING);
		}else{
			//��\��
			rcToolbar.left = rcDlg.right;
		}

		CRect rcEngin;
		m_cmbEngin.GetWindowRect(&rcEngin);
		int nEnginCX = rcEngin.Width();
		int nEnginCY = rcEngin.Height();
		rcEngin = rcToolbar;
		rcEngin.right = rcToolbar.left - s_kcxGap;
		rcEngin.left = rcEngin.right - nEnginCX;
		rcEngin.top = m_nDefEditT; //minit
		rcEngin.bottom = rcEngin.top + nEnginCY;
		m_cmbEngin.SetWindowPos(NULL, rcEngin, SWP_NOZORDER|SWP_NOSENDCHANGING);

		CRect rcKeyword(rcEngin);
		rcKeyword.left = 0;
		rcKeyword.right = rcEngin.left - s_kcxGap;
		m_cmbKeyword.SetWindowPos(NULL, rcKeyword, SWP_NOZORDER|SWP_NOSENDCHANGING);


		return S_OK;
	}

	void InitToolBar(UINT nImageBmpID, UINT nHotImageBmpID, 
					 int cx, int cy, COLORREF clrMask, UINT nFlags = ILC_COLOR24)
	{
		m_clrMask = clrMask;

		CImageList imgs;
		MTLVERIFY(imgs.Create(cx, cy, nFlags | ILC_MASK, 1, 1));

		CBitmap bmp;
		bmp.Attach(AtlLoadBitmapImage(GetSkinSeachBarPath(FALSE).GetBuffer(0), LR_LOADFROMFILE));
		if (bmp.m_hBitmap==NULL)
			bmp.LoadBitmap(nImageBmpID);
		imgs.Add(bmp, clrMask);

		CImageList imgsHot;
		MTLVERIFY(imgsHot.Create(cx, cy, nFlags | ILC_MASK, 1, 1));

		CBitmap bmpHot;
		bmpHot.Attach(AtlLoadBitmapImage(GetSkinSeachBarPath(TRUE).GetBuffer(0), LR_LOADFROMFILE));
		if (bmpHot.m_hBitmap==NULL)
			bmpHot.LoadBitmap(nHotImageBmpID);
		imgsHot.Add(bmpHot, clrMask);

		m_wndToolBar = ::CreateWindowEx(0, TOOLBARCLASSNAME, NULL,
			ATL_SIMPLE_TOOLBAR_PANE_STYLE | CCS_TOP, 
			0, 0, 100, 100,	m_hWnd, (HMENU)NULL, _Module.GetModuleInstance(), NULL);
		m_wndToolBar.SetButtonStructSize(sizeof(TBBUTTON));

		m_wndToolBar.SetImageList(imgs);
		m_wndToolBar.SetHotImageList(imgsHot);

		// add Add and Organize button
		TBBUTTON btnWeb = { 0, ID_SEARCH_WEB, TBSTATE_ENABLED, TBSTYLE_BUTTON|TBSTYLE_AUTOSIZE, 0, 0 };
		MTLVERIFY(m_wndToolBar.InsertButton(-1, &btnWeb));
		TBBUTTON btnHilght = { 1, ID_SEARCH_HILIGHT, TBSTATE_ENABLED, TBSTYLE_BUTTON|TBSTYLE_AUTOSIZE, 0, 0 };
		MTLVERIFY(m_wndToolBar.InsertButton(-1, &btnHilght));
		TBBUTTON btnPage = { 2, ID_SEARCH_PAGE, TBSTATE_ENABLED, TBSTYLE_BUTTON|TBSTYLE_AUTOSIZE, 0, 0 };
		MTLVERIFY(m_wndToolBar.InsertButton(1, &btnPage));

		//m_wndToolBar.SetBitmapSize(14,14);
		m_cxBtnsBtn = (20)*3+1;

		m_bShowToolBar = TRUE;
		m_bLoadedToolBar = TRUE;
	}

	CString GetSkinSeachBarPath(BOOL bHot)
	{
		CString strBmp;
		if (bHot)	strBmp = _T("SearchBarHot.bmp");
		else		strBmp = _T("SearchBar.bmp");
		return _GetSkinDir()+strBmp;
	}

	LRESULT OnInitDialog(HWND hWnd, LPARAM lParam)
	{
		CRect rcDlg;
		GetWindowRect(&rcDlg);
		//SetWindowPos(NULL, 0, 0, 1, rcDlg.Height(), 0);
		SetWindowPos(NULL, 0, 0, 0, m_nDefDlgH , 0);

		DWORD dwEngWidth=0;
		DWORD dwUseShortCut=0;
		CIniSection pr;
		pr.Open(_szIniFileName, _T("SEARCH"));
		pr.QueryValue(dwEngWidth, _T("EngWidth"));
		pr.QueryValue(dwUseShortCut, _T("UseShortcut"));
		pr.Close();
		if(dwUseShortCut) m_bUseShortcut = TRUE;

		//�R���{�{�b�N�X������
		m_cmbKeyword.FlatComboBox_Install(GetDlgItem(IDC_CMB_KEYWORD));
		m_cmbEngin.FlatComboBox_Install(GetDlgItem(IDC_CMB_ENGIN));
		m_cmbEngin.SetDroppedWidth(150);
		_InitCombo();
		
		if (dwEngWidth!=0)
		{
			CRect rcEngin;
			m_cmbEngin.GetWindowRect(&rcEngin);
			rcEngin.right = rcEngin.left + dwEngWidth;
			m_cmbEngin.SetWindowPos(NULL, rcEngin, SWP_NOZORDER|SWP_NOSENDCHANGING);
		}

		m_wndKeyword.SubclassWindow(m_cmbKeyword.GetDlgItem(1001));
		m_wndEngin.SubclassWindow(m_cmbEngin.m_hWnd);
		m_wndKeywordCombo.SubclassWindow(m_cmbKeyword.m_hWnd); //minit

		//�c�[���o�[������
		DWORD dwShowToolBar = STB_SHOWTOOLBARICON;
		pr.Open(_szIniFileName, _T("SEARCH"));
		pr.QueryValue(dwShowToolBar,_T("Show_ToolBarIcon"));
		m_bShowToolBar = (dwShowToolBar&STB_SHOWTOOLBARICON) == STB_SHOWTOOLBARICON;
		if(m_bShowToolBar){
			InitToolBar(IDB_SEARCHBUTTON, IDB_SEARCHBUTTON_HOT, m_nBmpCX, m_nBmpCY, RGB(255,0,255));
		}

		//�h���b�O�h���b�v������
		RegisterDragDrop();

		//�X���b�h�𗘗p���ăR���{�{�b�N�X�Ƀf�[�^��o�^(INI����̓ǂݍ��݂Ɏ��Ԃ������邽��)
		// Thread Create
		m_ThreadParams._hExitEvent = ::CreateEvent(NULL, FALSE, FALSE, NULL);
		m_ThreadParams.pSearchBar = this;
		DWORD wThreadId=0;
		m_hThread = ::CreateThread(NULL, 0, _SearchThread,
			(LPVOID)&m_ThreadParams, 0, &wThreadId);
		::SetThreadPriority(m_hThread , THREAD_PRIORITY_IDLE);

		return S_OK;
	}

	static DWORD WINAPI _SearchThread(LPVOID lpParam)
	{
		_ThreadParam* pParam = (_ThreadParam*)lpParam;
		_InitialEngin((LPVOID)pParam->pSearchBar->m_cmbEngin.m_hWnd);
		_InitialKeyword((LPVOID)pParam->pSearchBar->m_cmbKeyword.m_hWnd);
		//_endthread(); //?
		::ExitThread(0);
		return 0;
	}

	void RefreshEngin()
	{
		_InitialEngin(m_cmbEngin.m_hWnd);
	}

	void OnDestroy()
	{
		// Thread Remove
		::SetEvent(m_ThreadParams._hExitEvent);
		DWORD dwResult = ::WaitForSingleObject(m_hThread, DONUT_THREADWAIT);
		::CloseHandle(m_ThreadParams._hExitEvent);
		::CloseHandle(m_hThread);

		CRect rcEngin;
		m_wndEngin.GetWindowRect(rcEngin);

		CIniSection pr;
		pr.Open(_szIniFileName, _T("SEARCH"));
		pr.SetValue((DWORD)rcEngin.Width(), _T("EngWidth"));
		DWORD dwShowToolBar = m_bShowToolBar ? STB_SHOWTOOLBARICON : 0;
		pr.SetValue(dwShowToolBar,_T("Show_ToolBarIcon"));
		
		DWORD dwStatus=0;
		pr.QueryValue(dwStatus,_T("Status"));
		if(dwStatus&STS_LASTSEL)
			pr.SetValue(m_cmbEngin.GetCurSel(),_T("SelIndex"));
		pr.Close();



		m_wndKeyword.UnsubclassWindow();
		m_wndEngin.UnsubclassWindow();
		m_wndKeywordCombo.UnsubclassWindow();
		RevokeDragDrop();
		SaveHistory();
	}

	void OnEnginKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags)
	{
		if (nChar == VK_RETURN) {
 			_OnEnterKeyDown(ENTER_KEYDOWN_RETURN);
			SetMsgHandled(TRUE);
		}
		else if(nChar == VK_TAB) {
			m_cmbKeyword.SetFocus();
			SetMsgHandled(TRUE);
		}
		else
			SetMsgHandled(FALSE);
	}

	void OnChar(UINT nChar, UINT nRepCnt, UINT nFlags)
	{
		if (nChar==VK_RETURN){
			SetMsgHandled(TRUE);
		}
		else
			SetMsgHandled(FALSE);
	}

	LRESULT OnCtlColorListBox(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
	{
		bHandled = FALSE;
		m_hWndKeywordList = (HWND)lParam;
		return 0;
	}

	void OnKeywordKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags)
	{
		// if not dropped, eat VK_DOWN	
		if (!m_cmbKeyword.GetDroppedState()
			&& (nChar == VK_DOWN || nChar == VK_UP))
		{
			int nIndexEngin = m_cmbEngin.GetCurSel();
			int nIndexKeyword = m_cmbKeyword.GetCurSel();

			SetMsgHandled(TRUE);
			if (nChar == VK_UP)
			{
				if (::GetKeyState(VK_CONTROL)<0)
				{
					if (0>nIndexEngin-1)
						m_cmbEngin.SetCurSel(m_cmbEngin.GetCount()-1);
					else
						m_cmbEngin.SetCurSel(nIndexEngin-1);
				}
				else
				{
					if (0>nIndexKeyword-1)
						m_cmbKeyword.SetCurSel(m_cmbKeyword.GetCount()-1);
					else
						m_cmbKeyword.SetCurSel(nIndexKeyword-1);
				}
			}
			else if (nChar == VK_DOWN)
			{
				if (::GetKeyState(VK_CONTROL)<0)
				{
					int nIndex = m_cmbEngin.GetCurSel();
					if (m_cmbEngin.GetCount()>nIndexEngin+1)
						m_cmbEngin.SetCurSel(nIndexEngin+1);
					else
						m_cmbEngin.SetCurSel(0);
				}
				else
				{
					if (m_cmbKeyword.GetCount()>nIndexKeyword+1)
						m_cmbKeyword.SetCurSel(nIndexKeyword+1);
					else
						m_cmbKeyword.SetCurSel(0);
				}
			}
		}
		else
		{
			if (nChar == VK_RETURN) {
 				_OnEnterKeyDown(ENTER_KEYDOWN_RETURN);
				SetMsgHandled(TRUE);
			}
			else if(nChar == VK_DELETE) {
				if(m_cmbKeyword.GetDroppedState()){
					if(DeleteKeywordHistory())
						SetMsgHandled(TRUE);
				}
				else
					SetMsgHandled(FALSE);
			}
			else if(nChar == VK_TAB){
				m_cmbEngin.SetFocus();
				SetMsgHandled(TRUE);
			}
			else
				SetMsgHandled(FALSE);
		}
	}

	BOOL DeleteKeywordHistory()
	{
		if(!::IsWindow(m_hWndKeywordList))
			return FALSE;
		CListBox List = m_hWndKeywordList;
		int nIndex = List.GetCurSel();
		if(nIndex == LB_ERR) 
			return FALSE;
		m_cmbKeyword.DeleteString(nIndex);
		return TRUE;
	}

	struct _Function_MakeSearchFileListMenu
	{
		CMenuHandle menu;
		int nIndex;

		_Function_MakeSearchFileListMenu()
		{
			menu.CreatePopupMenu();
			menu.AppendMenu(0,1,_T("�g���v���p�e�B"));
			menu.AppendMenu(MF_SEPARATOR);
			nIndex = 1;
		}

		void operator ()(CString strFile)
		{
			ATLTRACE(_T("%s\n"),strFile);

			nIndex++;
			menu.AppendMenu(0,nIndex,MtlGetFileName(strFile));
		}

	};

	void OnEnginRButtonUp(UINT nFlags, CPoint point)
	{
		_Function_MakeSearchFileListMenu __f;
		MtlForEachFileSortEx(_GetDonutPath() + _T("Search\\"),__f,_T("*.ini"));

		CPoint pos;
		
		//GetCursorPos(&pos);
		ATLTRACE("mouseposition1 : left=%4d top=%4d",point.x,point.y);
		::ClientToScreen(m_cmbEngin.m_hWnd,&point);
		ATLTRACE("mouseposition2 : left=%4d top=%4d",point.x,point.y);
		CMenu menu(__f.menu.m_hMenu);

		int nRet = menu.TrackPopupMenu(TPM_LEFTALIGN|TPM_TOPALIGN|TPM_LEFTBUTTON|TPM_RIGHTBUTTON|TPM_NONOTIFY|TPM_RETURNCMD,
			                point.x,point.y,m_cmbEngin.m_hWnd);

		if(nRet == 0) return;
		if(nRet == 1){
			if(!m_cmbEngin.IsWindow() || m_cmbEngin.GetCurSel() == CB_ERR) return;
			CString strText; MtlGetLBTextFixed(m_cmbEngin,m_cmbEngin.GetCurSel(),strText);
			CExPropertyDialog dlg(GetSearchIniPath(),strText);
			dlg.SetTitle(strText);
			dlg.DoModal();
			return;
		}

		CString strTitle;
		menu.GetMenuString(nRet,strTitle,MF_BYCOMMAND);
		CString strPath = _GetDonutPath() + _T("Search\\") + strTitle;

		CIniSection pr;
		pr.Open(_szIniFileName,_T("Search"));
		pr.SetValue(strPath,_T("Path"));
		pr.Close();

		RefreshEngin();
	}

	void OnEnginSetFocus(HWND hWndBefore)
	{
		SetMsgHandled(FALSE);
		::WINNLSEnableIME(m_cmbEngin,FALSE);
	}

	void OnEnginKillFocus(HWND hWndNew)
	{
		SetMsgHandled(FALSE);
		::WINNLSEnableIME(m_cmbEngin,TRUE);
	}

	void OnMouseMove(UINT nFlags, CPoint pt)
	{
		CRect rcKeyword;
		m_cmbKeyword.GetWindowRect(&rcKeyword);
		ScreenToClient(&rcKeyword);

		if (abs(rcKeyword.right-pt.x)>5 
			&& ::GetCapture()!=m_hWnd) return;
		if (m_hCursor==NULL)
			m_hCursor = ::LoadCursor(NULL, IDC_SIZEWE);

		::SetCursor(m_hCursor);

		if ((nFlags&MK_LBUTTON))
		{
			UpdateLayout(pt);
		}
	}

	void OnSelChange(UINT code, int id, HWND hWnd)
	{
		DWORD dwStatus=0;
		CIniSection pr;
		pr.Open(_szIniFileName, _T("SEARCH"));
		pr.QueryValue(dwStatus, _T("Status"));
		pr.Close();

		BOOL bSts = 0;
		if (id==IDC_CMB_ENGIN)
			bSts = dwStatus&STS_ENG_CHANGE_GO;
		else if (id==IDC_CMB_KEYWORD)
			bSts = dwStatus&STS_KEY_CHANGE_GO;
		
		if (::GetKeyState(VK_SHIFT)<0) bSts = !bSts;
		if (bSts)
			_OnEnterKeyDown(ENTER_KEYDOWN_SELCHANGE);
	}

	void OnLButtonDown(UINT nFlags, CPoint pt)
	{
		CRect rcKeyword;
		m_cmbKeyword.GetWindowRect(&rcKeyword);
		ScreenToClient(&rcKeyword);

		if (abs(rcKeyword.right-pt.x)>5) return;
		SetCapture();
		::SetCursor(m_hCursor);
		m_ptDragStart = pt;
		m_ptDragHist = pt;
	}

	void OnLButtonUp(UINT nFlags, CPoint pt)
	{
		if (::GetCapture()!=m_hWnd) return;
		::ReleaseCapture();

		UpdateLayout(pt);
	}

	void UpdateLayout(CPoint pt)
	{
		int nMoveX = m_ptDragStart.x-pt.x;

		CRect rcKeyword;
		m_cmbKeyword.GetWindowRect(&rcKeyword);
		ScreenToClient(&rcKeyword);
		rcKeyword.right -= nMoveX;

		CRect rcEngin;
		m_cmbEngin.GetWindowRect(&rcEngin);
		ScreenToClient(&rcEngin);
		rcEngin.left -= nMoveX;

		if (rcEngin.left>=rcEngin.right) return;
		if (rcKeyword.left>=rcKeyword.right) return;

		m_cmbKeyword.SetWindowPos(NULL, rcKeyword, SWP_NOZORDER);
		m_cmbEngin.SetWindowPos(NULL, rcEngin, SWP_NOZORDER);

		m_ptDragStart = pt;
		UpdateWindow();
	}

	void _AddToSearchBoxUnique(const CString& strURL)
	{
		// search the same string
		int nCount = m_cmbKeyword.GetCount();
		for (int n = 0; n < nCount; ++n) {
			CString str;
			MtlGetLBTextFixed(m_cmbKeyword, n, str);
			if (strURL == str) {
				m_cmbKeyword.DeleteString(n);
				break;
			}
		}

		m_cmbKeyword.InsertString(0, strURL);
		m_cmbKeyword.SetCurSel(0);
	}

	void _OnEnterKeyDown(int flag)
	{
		CString str;
		int nIndexCmb = m_cmbKeyword.GetCurSel();
		if (nIndexCmb==-1)
			str = MtlGetWindowText(m_cmbKeyword);
		else
			MtlGetLBTextFixed(m_cmbKeyword.m_hWnd,nIndexCmb,str);
			//	m_cmbKeyword.GetLBText(nIndexCmb, str);

		if (!str.IsEmpty())
		{
			SHORT sShift = ::GetKeyState(VK_SHIFT);
			SHORT sCtrl = ::GetKeyState(VK_CONTROL);

			if (sShift>=0 && sCtrl>=0)
			{
				OnItemSelected(str);
				_AddToSearchBoxUnique(str);
			}
			else
			{
				str = _GetSelectText(GetEditCtrl());

				if (sCtrl<0)
					SendMessage(GetTopLevelParent(), WM_USER_FIND_KEYWORD, (WPARAM)str.GetBuffer(0), TRUE);
				else if (sShift<0)
					SendMessage(GetTopLevelParent(), WM_USER_FIND_KEYWORD, (WPARAM)str.GetBuffer(0), FALSE);
			}
		}else{
			m_cmbEngin.ShowDropDown(FALSE); //minit
		}
	}

	LRESULT OnCtlColor(UINT /*uMsg*/, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
	{
		bHandled = FALSE;
		if (g_bNoReposition==true) return 0;

		CRect rcDesktop;
		::GetWindowRect(::GetDesktopWindow(), &rcDesktop);

		CRect rcWnd;
		::GetWindowRect((HWND)lParam, &rcWnd);

		if (rcDesktop.right<=rcWnd.right)
		{
			int nDiff = rcWnd.right-rcDesktop.right;
			rcWnd.left -= nDiff;	rcWnd.right -= nDiff;
			::SetWindowPos((HWND)lParam, NULL, rcWnd.left, rcWnd.top, 0, 0, SWP_NOSIZE);
		}

		return 0;
	}

	void OnItemSelected(const CString& str)
	{
		int nTarCate = m_cmbEngin.GetCurSel();
		if (nTarCate==-1) return;

		CString strSearchEng = MtlGetWindowText(m_cmbEngin);

		BOOL bFirst=TRUE;
		int nLoopCtn=0;
		OpenSearch(str, strSearchEng, nLoopCtn, bFirst);
	}

	static CString GetSearchIniPath()
	{
		CString strPath;
		CIniSection pr;
		pr.Open(_szIniFileName,_T("Search"));
		pr.QueryString(strPath,_T("Path"),MAX_PATH);
		pr.Close();

		if(strPath.IsEmpty()){
			strPath = _GetFilePath(_T("Search\\Search.ini"));
			if(::GetFileAttributes(strPath) == 0xFFFFFFFF)
				strPath = _GetFilePath(_T("Search.ini")); //�ȑO�̎d�l��Go
		}

		return strPath;
	}

	void OpenSearch(CString strWord, CString strSearchEng, int &nLoopCnt, BOOL &bFirst)
	{
		if(m_bUseShortcut)
			ShortcutSearch(strWord, strSearchEng);

		if(strSearchEng.IsEmpty()){
			CString strText;
			m_cmbEngin.GetLBText(0,strText);
			strSearchEng = strText;
		}

		CString strSearchPath = GetSearchIniPath();
		CIniSection pr;

		DWORD dwStatus=0;
		pr.Open(_szIniFileName,_T("Search"));
		pr.QueryValue(dwStatus,_T("Status"));
		pr.Close();
		m_bActiveWindow = dwStatus&STS_ACTIVEWINDOW;

		pr.Open(strSearchPath, strSearchEng);

		DWORD dwGroup=0;
		pr.QueryValue(dwGroup, _T("Group"));
		BOOL bGroup = (dwGroup!=0)? TRUE:FALSE;

		if (bGroup==TRUE)
			OpenSearchGroup(strWord, strSearchEng, nLoopCnt, bFirst);
		else
		{
			//����URL�̓ǂݍ���
			DWORD dwCount=MAX_PATH;
			TCHAR cBuff[MAX_PATH];
			memset(cBuff, 0, MAX_PATH);
			pr.QueryValue(cBuff, _T("FrontURL"), &dwCount);
			CString strFrontURL(cBuff);
			if (strFrontURL.IsEmpty()) return;

			memset(cBuff, 0, MAX_PATH);
			pr.QueryValue(cBuff, _T("BackURL"), &dwCount);
			CString strBackURL(cBuff);

			//�����t���L�[���[�h�̓ǂݍ���
			memset(cBuff, 0, MAX_PATH);
			pr.QueryValue(cBuff, _T("FrontKeyWord"), &dwCount);
			CString strFrontKeyWord(cBuff);

			memset(cBuff, 0, MAX_PATH);
			pr.QueryValue(cBuff, _T("BackKeyWord"), &dwCount);
			CString strBackKeyWord(cBuff);

			//������̍쐬
			strWord = strFrontKeyWord + strWord + strBackKeyWord;
			if(m_bFiltering) 
				FilterString(strWord); //�S�p�X�y�[�X�̒u��

			DWORD dwEncode=0; //�G���R�[�h
			pr.QueryValue(dwEncode, _T("Encode"));
			if (dwEncode!=0)
				EncodeString(strWord,dwEncode);

			CString strOpenURL;
			strOpenURL.Format("%s%s%s", strFrontURL, strWord, strBackURL);

			DWORD dwOpenFlags = 0;
			if (bFirst==TRUE)
			{
				dwOpenFlags |= D_OPENFILE_ACTIVATE;
				bFirst=FALSE;
			}
			if (m_bActiveWindow)
			{
				dwOpenFlags |= D_OPENFILE_NOCREATE;
			}
			//DonutOpenFile(m_hWnd, strOpenURL, dwOpenFlags);
			_EXPROP_ARGS args;
			args.strUrl = strOpenURL;
			args.dwOpenFlag = dwOpenFlags;
			args.strIniFile = strSearchPath;
			args.strSection = strSearchEng;
			args.strSearchWord = RemoveShortcutWord(MtlGetWindowText(GetEditCtrl()));
			::SendMessage(GetTopLevelParent(),WM_OPEN_WITHEXPROP,(WPARAM)&args,0);
		}

		pr.Close();
	}

	void OpenSearchGroup(CString strWord, CString strSearchEng, int &nLoopCnt, BOOL &bFirst)
	{
		nLoopCnt++;
		if (nLoopCnt>10) return;

		CString strSearchPath = GetSearchIniPath();
		CIniSection pr;
		pr.Open(strSearchPath, strSearchEng);

		DWORD dwListCnt = 0;
		pr.QueryValue(dwListCnt, _T("ListCount"));
		for (int ii=1; ii<=(int)dwListCnt; ii++)
		{
			CString strKey;
			strKey.Format("%02d", ii);
			TCHAR cBuff[MAX_PATH];
			DWORD dwCount=MAX_PATH;

			pr.QueryValue(cBuff, strKey, &dwCount);

			CString strSearchEng2(cBuff);
			if (strSearchEng2.IsEmpty()) continue;

			OpenSearch(strWord, strSearchEng2, nLoopCnt, bFirst);
		}
	}

	void EncodeString(CString &str, int dwEncode)	//minit
	{
		CURLEncoder enc;
		if(dwEncode == 0)
			return;
		else if(dwEncode == ENCODE_SHIFT_JIS)
			enc.URLEncode_SJIS(str);
		else if(dwEncode == ENCODE_EUC)
			enc.URLEncode_EUC(str);
		else if(dwEncode == ENCODE_UTF8)
			enc.URLEncode_UTF8(str);
		else
			return;
			//ATLASSERT(FALSE);

	}

	void ShortcutSearch(CString& strWord, CString& strSearchEng)
	{
		CIniSection pr;
		CString strSearchPath = GetSearchIniPath();
		
		if(strWord.Left(1) == _T("\\")){
			DWORD dwListCount=0;
			int nFind = strWord.Find(" ");
			CString strShort = strWord.Mid(1, nFind-1);
			pr.Open(strSearchPath,_T("Search-List"));
			pr.QueryValue(dwListCount,_T("ListCount"));
			pr.Close();

			if(strShort.IsEmpty()) return;
			strWord = strWord.Mid(nFind+1);

			CString strBuf;
			CString strKey;
			int nListCount = dwListCount;
			for(int i=1; i<=nListCount; i++){
				DWORD dwCount; 

				//�G���W�������擾
				strKey.Format("%02d",i);
				pr.Open(strSearchPath, _T("Search-List"));
				dwCount = MAX_PATH;
				pr.QueryValue(strBuf.GetBuffer(MAX_PATH), strKey, &dwCount);
				strBuf.ReleaseBuffer();
				pr.Close();
				CString strEngin = strBuf;

				//�V���[�g�J�b�g�R�[�h���擾
				CString strShortcutWord = GetShortcutWord(strEngin);

				//��r
				if(strShort == strShortcutWord){
					strSearchEng = strEngin;
					return;
				}
			}
		}

	}

	CString GetShortcutWord(CString& strSearchEng)
	{
		DWORD dwCount = MAX_PATH;
		CIniSection pr;
		CString strBuf;
		pr.Open(GetSearchIniPath(), strSearchEng);
		pr.QueryString(strBuf,  _T("ShortCutCode"));
		pr.Close();
		return strBuf;
	}

	static void _InitialEngin(LPVOID lpV) 
	{
		CComboBox cmb((HWND)lpV);
		cmb.ResetContent();		//minit
		//::WINNLSEnableIME(cmb,FALSE);

		CString strSearchPath = GetSearchIniPath();

		CIniSection pr;
		pr.Open(strSearchPath, _T("Search-List"));
		DWORD dwListCnt = 0;
		pr.QueryValue(dwListCnt, _T("ListCount"));

		CString strKey;
		DWORD dwCount=MAX_PATH;
		for (int ii=1; ii<=(int)dwListCnt; ii++)
		{
			strKey.Format("%02d", ii);
			TCHAR cBuff[MAX_PATH];

			pr.QueryValue(cBuff, strKey, &dwCount);

			CString strTitle(cBuff);
			if (strTitle.IsEmpty()) continue;

			cmb.AddString(strTitle);
		}
		pr.Close();
		
		DWORD dwStatus=0, dwIndex=0;
		pr.Open(_szIniFileName, _T("SEARCH"));
		pr.QueryValue(dwStatus, _T("Status"));
		pr.QueryValue(dwIndex, _T("SelIndex"));
		pr.Close();

		int nSelIndex=0;
		if(dwStatus&STS_LASTSEL)
			nSelIndex=dwIndex;

		cmb.SetCurSel(nSelIndex);
	}

	static void _InitialKeyword(LPVOID lpV) 
	{
		CComboBox cmb((HWND)lpV);

		DWORD dwHistoryCnt=0;
		CIniSection pr;
		DWORD dwStatus=0;
		pr.Open(_szIniFileName, _T("SEARCH"));
		pr.QueryValue(dwStatus, _T("Status"));
		pr.Close();

		if (dwStatus&STS_NO_REPOSITION)
			g_bNoReposition = true;
		if ((dwStatus&STS_HISTORY_SAVE)!=STS_HISTORY_SAVE)
			return;
		
		pr.Open(_GetFilePath(_T("WordHistory.ini")), _T("SEARCH_HISTORY"));
		pr.QueryValue(dwHistoryCnt, _T("HistorySaveCnt"));

		for (int ii=0; ii<(int)dwHistoryCnt; ii++)
		{
			CString strKey;
			strKey.Format("KEYWORD%d", ii);

			TCHAR cBuff[MAX_PATH];

			DWORD dwCount=MAX_PATH;
			pr.QueryValue(cBuff, strKey, &dwCount);

			CString strKeyWord(cBuff);
			if (strKeyWord.IsEmpty()) continue;

			cmb.AddString(strKeyWord);
		}
		pr.Close();
	}

	BYTE PreTranslateMessage(MSG* pMsg)
	{

		UINT msg = pMsg->message;
		int vKey =  pMsg->wParam;

		if (msg == WM_SYSKEYDOWN || msg == WM_SYSKEYUP || msg == WM_KEYDOWN) {

			if (!IsWindowVisible() || !IsChild(pMsg->hwnd))	// ignore
			return _MTL_TRANSLATE_PASS;

			// left or right pressed, check shift and control key.
			if (vKey == VK_UP || vKey == VK_DOWN || vKey == VK_LEFT || vKey == VK_RIGHT || vKey == VK_HOME || vKey == VK_END
				|| vKey == (0x41+'C'-'A') || vKey == (0x41+'V'-'A') || vKey == (0x41+'X'-'A') || vKey == VK_INSERT)
						{
				if (::GetKeyState(VK_SHIFT) < 0 || ::GetKeyState(VK_CONTROL) < 0)
					return _MTL_TRANSLATE_WANT;// pass to edit control
			}

			// return key have to be passed
			if (vKey == VK_RETURN) {
				return _MTL_TRANSLATE_WANT;
			}

			// other key have to be passed
			if (VK_LBUTTON <= vKey && vKey <= VK_HELP) {
				BOOL bAlt = HIWORD(pMsg->lParam) & KF_ALTDOWN;
				if (!bAlt && ::GetKeyState(VK_SHIFT) >= 0 && ::GetKeyState(VK_CONTROL) >= 0)// not pressed
					return _MTL_TRANSLATE_WANT;// pass to edit control
			}
		}

		return _MTL_TRANSLATE_PASS;
	}

	CEdit GetEditCtrl()
	{
		return CEdit(m_cmbKeyword.GetDlgItem(1001));
	}

	void SetFocusToEngine()
	{
		::SetFocus(m_cmbEngin.m_hWnd);
		m_cmbEngin.ShowDropDown(TRUE);
	}

	void SaveHistory()
	{
		DWORD dwStatus=0;
		CIniSection pr;
		pr.Open(_szIniFileName, _T("SEARCH"));
		pr.QueryValue(dwStatus, _T("Status"));
		pr.Close();

		DWORD dwHistoryMaxCnt=10;
		pr.Open(_szIniFileName, _T("SEARCH"));
		pr.QueryValue(dwHistoryMaxCnt, _T("HistoryCnt"));
		pr.Close();

		DWORD dwItemCount = m_cmbKeyword.GetCount();
		if (dwItemCount>dwHistoryMaxCnt)
			dwItemCount = dwHistoryMaxCnt;

		CString strFileName = _GetFilePath(_T("WordHistory.ini"));
		CString strSection = _T("SEARCH_HISTORY");
		MtlIniDeleteSection(strFileName,strSection);
		pr.Open(strFileName,strSection);
		pr.SetValue(dwItemCount, _T("HistorySaveCnt"));
		if (dwStatus&STS_HISTORY_SAVE)
		{
			for (int ii=0; ii<(int)dwItemCount; ii++)
			{
				CString strKeyWord;
				MtlGetLBTextFixed(m_cmbKeyword.m_hWnd, ii, strKeyWord);

				CString strKey;
				strKey.Format("KEYWORD%d", ii);
				pr.SetValue(strKeyWord, strKey);
			}
		}
		pr.Close();
	}

	DROPEFFECT OnDragEnter(IDataObject* pDataObject, DWORD dwKeyState, CPoint point)
	{
		if (m_bDragFromItself)
			return DROPEFFECT_NONE;

		_DrawDragEffect(false);

		m_bDragAccept = _MtlIsHlinkDataObject(pDataObject);
		return _MtlStandardDropEffect(dwKeyState);
	}

	DROPEFFECT OnDragOver(IDataObject* pDataObject, DWORD dwKeyState, CPoint point, DROPEFFECT dropOkEffect)
	{
		if (m_bDragFromItself || !m_bDragAccept)
			return DROPEFFECT_NONE;

		return _MtlStandardDropEffect(dwKeyState) | _MtlFollowDropEffect(dropOkEffect) | DROPEFFECT_COPY;
	}
	void OnDragLeave()
	{
		if (m_bDragFromItself)
			return;

		_DrawDragEffect(true);
	}

	void _DrawDragEffect(bool bRemove)
	{
		CClientDC dc(m_wndKeyword.m_hWnd);

		CRect rect;
		m_wndKeyword.GetClientRect(rect);

		if (bRemove)
			MtlDrawDragRectFixed(dc.m_hDC, &rect, CSize(0, 0), &rect, CSize(2, 2), NULL, NULL);
		else
			MtlDrawDragRectFixed(dc.m_hDC, &rect, CSize(2, 2), NULL, CSize(2, 2),	NULL, NULL);
	}

	DROPEFFECT OnDrop(IDataObject* pDataObject,	DROPEFFECT dropEffect,
		DROPEFFECT dropEffectList, CPoint point)
	{
		if (m_bDragFromItself)
			return DROPEFFECT_NONE;

		_DrawDragEffect(true);

		DWORD dwStatus=0;
		CIniSection pr;
		pr.Open(_szIniFileName, _T("SEARCH"));
		pr.QueryValue(dwStatus, _T("Status"));
		pr.Close();

		CString strText;
		if (MtlGetHGlobalText(pDataObject, strText) ||	MtlGetHGlobalText(pDataObject, strText, ::RegisterClipboardFormat(CFSTR_SHELLURL)))
		{
			CEdit edit = GetEditCtrl();
			edit.SendMessage(WM_CHAR,'P'); //m_cmbKeyword.GetCurSel() == -1�ɂ��邽�߂̋���̍� minit
			edit.SetWindowText(strText);
			

			BOOL bSts = dwStatus&STS_DROP_GO;
			if (::GetKeyState(VK_SHIFT)<0) bSts = !bSts;
			if (bSts)
			{
				OnItemSelected(strText);
				_AddToSearchBoxUnique(strText);
			}
			return DROPEFFECT_COPY;
		}

		return DROPEFFECT_NONE;
	}

	void SetFont(HFONT hFont, BOOL bRedraw=TRUE)
	{
		CDialogImpl<CSearchBarCtrlImpl>::SetFont(hFont, bRedraw);
		m_cmbEngin.SetFont(hFont, bRedraw);
		m_cmbKeyword.SetFont(hFont, bRedraw);
		m_wndKeyword.SetFont(hFont, bRedraw);
	}

	void _SetVerticalItemCount(CComboBox &cmb,int count)
	{
		CRect rc;
		cmb.AddString("dummy");
		int itemheight = cmb.GetItemHeight(0);
		cmb.DeleteString(0);
		cmb.GetClientRect(&rc);
		rc.bottom += itemheight * count + 2;
		cmb.MoveWindow(&rc);
	}

	void _InitCombo()	//minit
	{
		DWORD dwHeightCnt=DEFAULT_HEIGHTCOUNT;
		DWORD dwStatus=0;
		CIniSection pr;
		pr.Open(_szIniFileName,_T("SEARCH"));
		pr.QueryValue(dwStatus,_T("Status"));
		pr.QueryValue(dwHeightCnt,_T("HeightCnt"));
		pr.Close();

		int nret = m_cmbEngin.SetItemHeight(-1,21);
		m_cmbKeyword.SetItemHeight(-1,21);

		if(dwStatus&STS_HEIGHTCOUNT){
			int HeightCount = (int)dwHeightCnt;
			if(HeightCount < 1 || MAXHEIGHTCOUNT < HeightCount) HeightCount = DEFAULT_HEIGHTCOUNT;
			_SetVerticalItemCount(m_cmbEngin,HeightCount);
			_SetVerticalItemCount(m_cmbKeyword,HeightCount);
		}

		if(dwStatus&STS_TEXT_FILTER)
			m_bFiltering = TRUE;
	}	
	
	void ShowToolBarIcon(BOOL flag)
	{
		if(flag){
			if(m_bLoadedToolBar){
				if(::IsWindow(m_wndToolBar.m_hWnd)) m_wndToolBar.ShowWindow(SW_NORMAL);
			}else{
				InitToolBar(IDB_SEARCHBUTTON, IDB_SEARCHBUTTON_HOT, 
							m_nBmpCX, m_nBmpCY, RGB(255,0,255));
				 m_wndToolBar.ShowWindow(SW_NORMAL);
				//m_bShowToolBar = TRUE;
				//m_bLoadedToolBar = TRUE;
			}
		}else{
			if(m_bLoadedToolBar){
				m_wndToolBar.ShowWindow(SW_HIDE);
			}
		}
		m_bShowToolBar = flag;
		
		CRect rect;
		int width,height;

		//�T�C�Y�ύX
		GetWindowRect(rect);
		CWindow(GetParent()).ScreenToClient(rect);
		width = rect.right - rect.left - 1;
		height = rect.bottom - rect.top;
		SetWindowPos(NULL, rect.left, rect.top, width, height, SWP_NOZORDER|SWP_NOREDRAW);
		SetWindowPos(NULL, rect.left, rect.top, width +1, height, SWP_NOZORDER);
	}

	void SearchWeb()
	{
		CEdit edit = GetEditCtrl();
		CString str = MtlGetWindowText(edit);
		_OnCommand_SearchWeb(str);
	}

	void SearchHilight()
	{
		CEdit edit = GetEditCtrl();
		CString str = MtlGetWindowText(edit);
		str = RemoveShortcutWord(str);
		_OnCommand_SearchHilight(str);
	}

	void SearchPage(BOOL bForward)
	{
		_OnCommand_SearchPage(bForward);
	}

	BOOL GetToolIconState()
	{
		return m_bShowToolBar;
	}

	void FilterString(CString& str)
	{
		str.Replace(_T("�@"),_T(" "));
		/*int count = str.GetLength();
		BOOL bFlag = FALSE;
		int i = 0;
		while(i < count){
			int c = str.GetAt(i);
			if((c&0xFF) == 0x81L) {
				if(i+1 < count){
					int c2 = str.GetAt(i+1);
					if((c2&0xFF) == 0x40L){
						str.SetAt(i,0x20L);
						str.Delete(i+1);
						count--;
					}
				}
			}
			i++;
		}*/
	}

	void ReloadSkin(int nCmbStyle)
	{
		SetComboStyle(nCmbStyle);
		
		if(!m_wndToolBar.IsWindow()) return;
		CImageList imgs, imgsHot;
		imgs = m_wndToolBar.GetImageList();
		imgsHot = m_wndToolBar.GetHotImageList();

		_ReplaceImageList(GetSkinSeachBarPath(FALSE),imgs);
		_ReplaceImageList(GetSkinSeachBarPath(TRUE),imgsHot);

		InvalidateRect(NULL,TRUE);
		//m_wndToolBar.SetImageList(imgs);
		//m_wndToolBar.SetHotImageList(imgsHot);
		m_wndToolBar.InvalidateRect(NULL,TRUE);

		
	}

	void SetComboStyle(int nCmbStyle)
	{
		m_cmbEngin.SetDrawStyle(nCmbStyle);
		m_cmbKeyword.SetDrawStyle(nCmbStyle);
	}

};

class CDonutSearchBar:
	public CSearchBarCtrlImpl<CDonutSearchBar>
{
};

class CSearchPropertyPage : public CPropertyPageImpl<CSearchPropertyPage>,
public CWinDataExchange<CSearchPropertyPage>
{
public:
// Constants
	enum { IDD = IDD_PROPPAGE_SEARCHBAR};

// Data members
	int m_nEngChgGo, m_nDropGo, m_nHistorySave, m_nHistorySaveCnt;
	int m_nNoReposition, m_nKeyChgGo;
	DWORD m_dwStatus;
	int m_nHeightCount, m_nHeightCountCnt;
	int m_nFiltering;
	int m_nLastSel;
	int m_nScrollCenter;
	int m_nActiveWindow;
	int m_nAutoHilight;

// DDX map
	BEGIN_DDX_MAP(CSearchPropertyPage)
		DDX_CHECK(IDC_CHECK_ENG_CHG_GO, m_nEngChgGo)
		DDX_CHECK(IDC_CHECK_KEY_CHG_GO, m_nKeyChgGo)
		DDX_CHECK(IDC_CHECK_DROP_GO, m_nDropGo)
		DDX_CHECK(IDC_CHECK_HISTORY_SAVE, m_nHistorySave)
		DDX_CHECK(IDC_CHECK_NO_REPOSITION, m_nNoReposition)
		DDX_CHECK(IDC_CHECK_HEIGHTCOUNT, m_nHeightCount)
		DDX_CHECK(IDC_CHECK_FILTER, m_nFiltering)
		DDX_CHECK(IDC_CHECK_LASTSEL, m_nLastSel)
		DDX_CHECK(IDC_CHECK_SCROLLCENTER, m_nScrollCenter)
		DDX_CHECK(IDC_CHECK_ACTIVEWINDOW, m_nActiveWindow)
		DDX_CHECK(IDC_CHECK_AUTOHILIGHT, m_nAutoHilight)

		DDX_INT(IDC_ED_HISTORY_CNT, m_nHistorySaveCnt)
		DDX_INT_RANGE(IDC_EDIT_HEIGHTCOUNT, m_nHeightCountCnt, 1,MAXHEIGHTCOUNT)
	END_DDX_MAP()

	CSearchPropertyPage()
	{
		m_dwStatus =0;
		m_nEngChgGo = 0;
		m_nDropGo = 0;
		m_nHistorySave = 0;
		m_nHistorySaveCnt = 0;
		m_nNoReposition = 0;
		m_nKeyChgGo = 0;
		m_nHeightCount = 0;
		m_nFiltering = 0;
		m_nLastSel = 0;
		m_nScrollCenter = 1;
		m_nActiveWindow = 0;
		m_nAutoHilight = 0;

		_SetData();
	}

// Overrides
	BOOL OnSetActive()
	{
		SetModified(TRUE);

		return DoDataExchange(FALSE);
	}
	BOOL OnKillActive()
	{
		return DoDataExchange(TRUE);
	}
	BOOL OnApply()
	{
		if (DoDataExchange(TRUE)) {
			_GetData();
			return TRUE;
		}
		else 
			return FALSE;
	}

// Constructor
	// �f�[�^�𓾂�
	void _SetData()
	{
		DWORD dwEngWidth=100, dwHistoryCnt=10,dwHeightCnt = DEFAULT_HEIGHTCOUNT;
		CIniSection pr;
		pr.Open(_szIniFileName, _T("SEARCH"));
		pr.QueryValue(m_dwStatus, _T("Status"));
		pr.QueryValue(dwHistoryCnt, _T("HistoryCnt"));
		pr.QueryValue(dwHeightCnt, _T("HeightCnt"));
		pr.Close();

		m_nHistorySaveCnt = dwHistoryCnt;
		m_nHeightCountCnt = dwHeightCnt;
		m_nEngChgGo = (m_dwStatus&STS_ENG_CHANGE_GO)==STS_ENG_CHANGE_GO;
		m_nDropGo = (m_dwStatus&STS_DROP_GO)==STS_DROP_GO;
		m_nHistorySave = (m_dwStatus&STS_HISTORY_SAVE)==STS_HISTORY_SAVE;
		m_nNoReposition = (m_dwStatus&STS_NO_REPOSITION)==STS_NO_REPOSITION;
		m_nKeyChgGo = (m_dwStatus&STS_KEY_CHANGE_GO)==STS_KEY_CHANGE_GO;
		m_nHeightCount = (m_dwStatus&STS_HEIGHTCOUNT)==STS_HEIGHTCOUNT;
		m_nFiltering = (m_dwStatus&STS_TEXT_FILTER)==STS_TEXT_FILTER;
		m_nLastSel = (m_dwStatus&STS_LASTSEL)==STS_LASTSEL;
		m_nScrollCenter = (m_dwStatus&STS_SCROLLCENTER)==STS_SCROLLCENTER;
		m_nActiveWindow = (m_dwStatus&STS_ACTIVEWINDOW)==STS_ACTIVEWINDOW;
		m_nAutoHilight = (m_dwStatus&STS_AUTOHILIGHT)==STS_AUTOHILIGHT;
	}

	// �f�[�^��ۑ�
	void _GetData()
	{
		m_dwStatus = 0;
		if (m_nEngChgGo)
			m_dwStatus |= STS_ENG_CHANGE_GO;
		if (m_nDropGo)
			m_dwStatus |= STS_DROP_GO;
		if (m_nHistorySave)
			m_dwStatus |= STS_HISTORY_SAVE;
		if (m_nNoReposition)
			m_dwStatus |= STS_NO_REPOSITION;
		if (m_nKeyChgGo)
			m_dwStatus |= STS_KEY_CHANGE_GO;
		if (m_nHeightCount)
			m_dwStatus |= STS_HEIGHTCOUNT;
		if (m_nFiltering)
			m_dwStatus |= STS_TEXT_FILTER;
		if (m_nLastSel)
			m_dwStatus |= STS_LASTSEL;
		if (m_nScrollCenter)
			m_dwStatus |= STS_SCROLLCENTER;
		if (m_nActiveWindow)
			m_dwStatus |= STS_ACTIVEWINDOW;
		if (m_nAutoHilight)
			m_dwStatus |= STS_AUTOHILIGHT;

		CIniSection pr;
		pr.Open(_szIniFileName, _T("SEARCH"));
		pr.SetValue(m_dwStatus, _T("Status"));
		pr.SetValue((DWORD)m_nHistorySaveCnt, _T("HistoryCnt"));
		pr.SetValue((DWORD)m_nHeightCountCnt, _T("HeightCnt"));
		pr.Close();
	}

// Message map and handlers
	BEGIN_MSG_MAP(CSearchPropertyPage)
		CHAIN_MSG_MAP(CPropertyPageImpl<CSearchPropertyPage>)
	END_MSG_MAP()
};