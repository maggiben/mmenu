#include "stdafx.h"
#include "DonutPFunc.h"
#include "MtlBase.h"
#include "MtlWin.h"
#include "ToolTipManager.h"
#include "resource.h"

using namespace ATL;
using namespace WTL;
using namespace MTL;

extern TCHAR _szIniFileName[MAX_PATH];
extern char _cSeparater[];


double _GetAngle(CPoint pt1, CPoint pt2)
{
	double xlen = pt2.x - pt1.x;
	double ylen = pt1.y - pt2.y;

	if (fabs( xlen ) < 1)	xlen = 0.0;
	if (fabs( ylen ) < 1)	ylen = 0.0;

	if ((xlen == 0.0) && (ylen == 0.0))
		return ( 0.0 );

	if (xlen == 0.0)
	{
		if (pt1.y < pt2.y)	return ( 270.0 );
		else				return (  90.0 );
	}
	else if (ylen == 0.0)
	{
		if (pt1.x < pt2.x)	return (  0.0);
		else				return (180.0);
	}

	double angle = RADIAN_TO_ANGLE( atan2(ylen, xlen) );
	if (angle < 0.0)
		angle += 360.0;
	return ( angle );
}

BOOL _CheckOsVersion_98Later()
{
	OSVERSIONINFO osi = { sizeof(OSVERSIONINFO) };
	BOOL bRet = ::GetVersionEx(&osi);

	//windows98 == 4.10
	return ((osi.dwMajorVersion >= 5) || (osi.dwMajorVersion == 4 && osi.dwMinorVersion >= 10));
}

BOOL _CheckOsVersion_MELater()
{
	OSVERSIONINFO osi = { sizeof(OSVERSIONINFO) };
	BOOL bRet = ::GetVersionEx(&osi);

	//windowsME == 4.90
	return ((osi.dwMajorVersion >= 5) || (osi.dwMajorVersion == 4 && osi.dwMinorVersion >= 90));
}

BOOL _CheckOsVersion_2000Later()
{
	OSVERSIONINFO osi = { sizeof(OSVERSIONINFO) };
	BOOL bRet = ::GetVersionEx(&osi);

	//windows2000 5.0
	return ((osi.dwMajorVersion >= 5));
}

BOOL _CheckOsVersion_XPLater()
{
	OSVERSIONINFO osi = { sizeof(OSVERSIONINFO) };
	BOOL bRet = ::GetVersionEx(&osi);

	//windowsXP 5.1
	return ((osi.dwMajorVersion = 5) && (osi.dwMinorVersion >= 1) || (osi.dwMajorVersion > 5));
}


CString _GetFilePath(CString strFile)
{
	TCHAR cPathExe[MAX_PATH];
	::GetModuleFileName(_Module.GetModuleInstance(), cPathExe, MAX_PATH);

	CString strPath(cPathExe);

//#ifdef _DEBUG
//	strPath = strPath.Left(strPath.ReverseFind('\\'));
//#endif

	strPath = strPath.Left(strPath.ReverseFind('\\')+1) + strFile;
	return strPath;
}

CString _GetDonutPath()
{
	//vvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvv
	// �p�X
	TCHAR cPathExe[MAX_PATH];
	::GetModuleFileName(_Module.GetModuleInstance(), cPathExe, MAX_PATH);

	CString strFile(cPathExe);

//#ifdef _DEBUG
//	strFile = strFile.Left(strFile.ReverseFind('\\'));
//#endif

	
	strFile = strFile.Left(strFile.ReverseFind('\\')+1);
	//^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
	return strFile;
}

CString _GetBtnSkinDir()
{
	CString strPath = _GetFilePath(_T("DonutP.INI"));

	TCHAR szPath[MAX_PATH];		memset(szPath, 0, MAX_PATH);
	DWORD dwCount = MAX_PATH;

	CString strBtnDir;
	::GetPrivateProfileString(_T("Path"), _T("BtnSkinPath"), _T(""), szPath, MAX_PATH, strPath);
	strBtnDir.Format("%s", szPath);
	if (strBtnDir.IsEmpty())
	{
		strBtnDir = _GetDonutPath() + _T("BtnSkin");
	}

	return strBtnDir;
}

CString _GetSkinDir()
{

	CString strPath;
	strPath = MTL::MtlGetModuleFileName();
	strPath = strPath.Left(strPath.ReverseFind('\\')+1);
	strPath += _T("Skin\\");
	CString strDefPath = strPath + _T("default");
	
	CIniSection pr;
	char buff[MAX_PATH];
	DWORD dwCount = MAX_PATH;
	pr.Open(_szIniFileName,_T("Skin"));
	pr.QueryValue(buff,_T("SkinFolder"),&dwCount);
	pr.Close();

	CString strSkinPath;
	strSkinPath = buff;
	if(strSkinPath.IsEmpty())
		strSkinPath = strDefPath;
	else
		strSkinPath = strPath + buff;

	if(::GetFileAttributes(strSkinPath) == 0xFFFFFFFF){
		if(GetFileAttributes(strDefPath) == 0xFFFFFFFF){
			strSkinPath = strPath;
		}else{
			strSkinPath = strDefPath;
		}
	}

	if(!strSkinPath.IsEmpty() && strSkinPath.Right(1) != _T("\\"))
		strSkinPath += _T("\\");
	return strSkinPath;
}

CString _GetRecentCloseFile()
{
	return _GetFilePath("RecentClose.ini");
}

bool _LoadToolTipText(int nCmdID, CString& strText)
{
	TCHAR szBuff[256];
	TCHAR szText[256];

	szBuff[0] = 0;
	int nRet = ::LoadString(_Module.GetResourceInstance(), nCmdID, szBuff, 256);
	for (int i = 0; i < nRet; i++)
	{
		if (szBuff[i] == _T('\n'))
		{
			lstrcpyn(szText, &szBuff[i + 1], 256);
			strText = szText;
			return true;
		}
	}

	return false;
}

/*
CString GetJapanAt(CString str, int nIndex)
{
	//don't use
	int nlen=0;
	for (int ii=0;ii<str.GetLength();)
	{
		if (nlen==nIndex)
			break;
		if (_ismbblead(str[ii]))
			ii++;
		ii++;
		nlen++;
	}

	int nlenm=1;
	if (_ismbblead(str[ii]))
		nlenm=2;

	return str.Mid(ii,nlenm);
	
}
*/


#define SJIS1_S1 0x81
#define SJIS1_E1 0x9f
#define SJIS1_S2 0xe0
#define SJIS1_E2 0xf5
//SJIS����
BOOL IsSJISLeadByte(BYTE c)
{
#ifdef _UNICODE
	ATLASSERT(FALSE);
#endif

	//�œK���͖ʓ|�Ȃ̂ł��Ȃ�
	if((SJIS1_S1 <= c && c <= SJIS1_E1) || (SJIS1_S2 <= c && c <= SJIS1_E2))
		return TRUE;
	return FALSE;
}

// 1�����i�߁A�i�߂��o�C�g��Ԃ��B�A��NULL�̂Ƃ��̓|�C���^��i�߂��A0��Ԃ�
int RtlMbbNext(LPTSTR& r_lp)
{
	LPCTSTR lpBegin = r_lp;
	if (r_lp){
		++r_lp;
		if (_ismbblead(*(r_lp-1)) && _ismbbtrail(*r_lp)){
			// 2�o�C�g�����̎��͂���1�o�C�g�i�߂�
			++r_lp;
		}
	}
	return r_lp - lpBegin;
}


// strText �� nFirst �����ڂ���AnCount ���������擾���ĕԂ��B�}���`�o�C�g�����Ή���
CString RtlMbbStrMid(CString strText, const int& nFirst, const int& nCount)
{
	ATLASSERT( nFirst >= 0 );
	if (nCount < 1 || strText.GetLength() <= nFirst)
		return CString();

	LPTSTR lp = strText.GetBuffer(0);
	int i, p1 = 0, p2 = 0;
	for (i = 0; *lp && p1 < nFirst; ++i){
		p1 += RtlMbbNext(lp);
	}
	for (i = 0; *lp && p2 < nCount; ++i){
		p2 += RtlMbbNext(lp);
	}
	strText.ReleaseBuffer();
	return strText.Mid(p1, p2);
}


CString RtlGetSelectedText(const CEdit& edit)
{
	CString str = MtlGetWindowText(edit);
	if (str.IsEmpty())
		return CString();

	int nStart = -1, nEnd = -1;
	edit.GetSel(nStart, nEnd);	// �I��͈͂��u�������v�ŕԂ�

	if (nStart != nEnd && str.GetLength() != (nEnd - nStart) && !(nStart == 0 && nEnd == -1)){
		str = RtlMbbStrMid(str, nStart, nEnd - nStart);	// ���������o�C�g���ɕϊ�����K�v������
	}

	return str;
}

//EM_GETSEL��VisualStyle�K�p����UNICODE�I���������(UNICODE���`���Ȃ��ꍇ�ł�)�̂łȂ�Ƃ�����֐�
CString _GetSelectTextWtoA(CEdit &edit)
{
	int nStart, nEnd;
	edit.GetSel(nStart,nEnd); //�����UNICODE�ł̒l
	if(nStart == nEnd)
		return MtlGetWindowText(edit);

	int nTextLen = ::GetWindowTextLength(edit.m_hWnd);
	int nSelCount = nEnd-nStart;

	LPTSTR lpAll = new CHAR[nTextLen+1];
	LPWSTR lpwAll = new WCHAR[nTextLen+1];
	LPWSTR lpwSel = new WCHAR[nSelCount+1];
	::GetWindowText(edit.m_hWnd,(LPTSTR)lpAll,nTextLen+1); //�����ANSI�ȃe�L�X�g��Ԃ�
	::MultiByteToWideChar(CP_ACP, 0, lpAll, -1, lpwAll, nTextLen + 1);

	memset(lpwSel,0,(nSelCount+1)*sizeof(WCHAR));

	CopyMemory(lpwSel,lpwAll+nStart,nSelCount*sizeof(WCHAR));
	CString str = lpwSel;

	delete [] lpAll;
	delete [] lpwAll;
	delete [] lpwSel;
	return str;
}

CString _GetSelectText(CEdit &edit)
{
	//VisualStyle���K�p����Ă���ꍇ��EM_GETSEL��UNICODE�ŕԂ�
	CString str;
	if(CThemeDLLLoader::IsExistManifest() && _CheckOsVersion_XPLater()){
		//UNICODE����ANSI�֕ϊ�
		str = _GetSelectTextWtoA(edit);
	}else{ 
		//ANSI�̏ꍇ��RAPT���̃R�[�h�𗬗p
		str = RtlGetSelectedText(edit);
	}
	return str;
}



BOOL _AddSimpleReBarBandCtrl(HWND hWndReBar, HWND hWndBand, int nID, LPTSTR lpstrTitle, BOOL bNewRow, int cxWidth, BOOL bFullWidthAlways)
{
	ATLASSERT(::IsWindow(hWndReBar));	// must be already created
#ifdef _DEBUG
	// block - check if this is really a rebar
	{
		TCHAR lpszClassName[sizeof(REBARCLASSNAME)];
		::GetClassName(hWndReBar, lpszClassName, sizeof(REBARCLASSNAME));
		ATLASSERT(lstrcmp(lpszClassName, REBARCLASSNAME) == 0);
	}
#endif //_DEBUG
	ATLASSERT(::IsWindow(hWndBand));	// must be already created

	// Get number of buttons on the toolbar
	int nBtnCount = (int)::SendMessage(hWndBand, TB_BUTTONCOUNT, 0, 0L);
	// Set band info structure
	REBARBANDINFO rbBand;
	rbBand.cbSize = sizeof(REBARBANDINFO);
#if (_WIN32_IE >= 0x0400)
	rbBand.fMask = RBBIM_CHILD | RBBIM_CHILDSIZE | RBBIM_STYLE | RBBIM_ID | RBBIM_SIZE | RBBIM_IDEALSIZE;
#else
	rbBand.fMask = RBBIM_CHILD | RBBIM_CHILDSIZE | RBBIM_STYLE | RBBIM_ID | RBBIM_SIZE;
#endif //!(_WIN32_IE >= 0x0400)
	if(lpstrTitle != NULL)
		rbBand.fMask |= RBBIM_TEXT;
	rbBand.fStyle = 0;
#if (_WIN32_IE >= 0x0500)
	if(nBtnCount > 0)	// add chevron style for toolbar with buttons
		rbBand.fStyle |= RBBS_USECHEVRON;
#endif //(_WIN32_IE >= 0x0500)
	if(bNewRow)
		rbBand.fStyle |= RBBS_BREAK;

	rbBand.lpText = lpstrTitle;
	rbBand.hwndChild = hWndBand;
	if(nID == 0)	// calc band ID
		nID = ATL_IDW_BAND_FIRST + (int)::SendMessage(hWndReBar, RB_GETBANDCOUNT, 0, 0L);
	rbBand.wID = nID;

	// Calculate the size of the band
	BOOL bRet;
	RECT rcTmp;
	if(nBtnCount > 0)
	{
		bRet = (BOOL)::SendMessage(hWndBand, TB_GETITEMRECT, nBtnCount - 1, (LPARAM)&rcTmp);
		ATLASSERT(bRet);
		rbBand.cx = (cxWidth != 0) ? cxWidth : rcTmp.right;
		rbBand.cyMinChild = rcTmp.bottom - rcTmp.top;
		rbBand.cxMinChild = 0;
/*			if(bFullWidthAlways)
		{
			rbBand.cxMinChild = rbBand.cx;
		}
		else if(lpstrTitle == 0)
		{
			bRet = (BOOL)::SendMessage(hWndBand, TB_GETITEMRECT, 0, (LPARAM)&rcTmp);
			ATLASSERT(bRet);
			rbBand.cxMinChild = rcTmp.right;
		}
		else
		{
			rbBand.cxMinChild = 0;
		}
*/
	}
	else	// no buttons, either not a toolbar or really has no buttons
	{
		bRet = ::GetWindowRect(hWndBand, &rcTmp);
		ATLASSERT(bRet);
		rbBand.cx = (cxWidth != 0) ? cxWidth : (rcTmp.right - rcTmp.left);
		rbBand.cxMinChild = (bFullWidthAlways) ? rbBand.cx : 0;
		rbBand.cyMinChild = rcTmp.bottom - rcTmp.top;
	}

#if (_WIN32_IE >= 0x0400)
	rbBand.cxIdeal = rbBand.cx;
#endif //(_WIN32_IE >= 0x0400)

	// Add the band
	LRESULT lRes = ::SendMessage(hWndReBar, RB_INSERTBAND, (WPARAM)-1, (LPARAM)&rbBand);
	if(lRes == 0)
	{
		ATLTRACE2(atlTraceUI, 0, _T("Failed to add a band to the rebar.\n"));
		return FALSE;
	}

	return TRUE;
}

bool FileWriteString(CString strFile, std::list<CString>* pString)
{
	FILE *fp;
	
	if ((fp = fopen(strFile, "w")) == NULL) {
		return false;
	}

	std::list<CString>::iterator str;
	CString strOut;
    for (str=pString->begin(); str!= pString->end(); ++str){
		fprintf(fp, "%s\n", *str);
	}

	fclose(fp);

	return true;
}

bool FileReadString(CString strFile, std::list<CString>* pString)
{
	FILE *fp;
	if ((fp = fopen(strFile, "r")) == NULL) {
		return false;
	}
	
	char cBuff[4096];
	int nLen=0;
	CString strBuff;
	while (fgets(cBuff, 4096, fp) != NULL) {
		nLen=lstrlen(cBuff);
		if (nLen!=0 && cBuff[nLen-1]=='\n')
			cBuff[nLen-1] = '\0';

		pString->insert(pString->end(), cBuff);
	}
	fclose(fp);

	return true;
}

BOOL _SetCombboxCategory(CComboBox &cmb, HMENU hMenu)
{
	if (cmb.m_hWnd==NULL) return FALSE;
	if (cmb.GetCount()!=0) return FALSE;

	for (int ii=0; ii<::GetMenuItemCount(hMenu); ii++)
	{
		char cBuff[MAX_PATH];
		if (::GetMenuString(hMenu, ii, cBuff, MAX_PATH, MF_BYPOSITION)==0)
			continue;

		CString strMenu(cBuff);
		if (strMenu.Find("(")!=-1)
			strMenu = strMenu.Left(strMenu.Find("("));
		else if (strMenu.Find("\t")!=-1)
			strMenu = strMenu.Left(strMenu.Find("\t"));

		cmb.AddString(strMenu);
	}

	cmb.SetCurSel(0);
	return TRUE;
}

BOOL _DontUseID(UINT uID)
{
//	UINT uDontUseID[] = {ID_FILE_MRU_FILE1, ID_INSERTPOINT_GROUPMENU, ID_INSERTPOINT_FAVORITEMENU};
	UINT uDontUseID[] = {ID_INSERTPOINT_GROUPMENU, ID_INSERTPOINT_FAVORITEMENU};
	for (int ii=0; ii<sizeof(uDontUseID)/sizeof(UINT); ii++)
	{
		if (uID == uDontUseID[ii])
			return TRUE;
	}
	return FALSE;
}

void _PickUpCommandSub(HMENU hMenuSub, CComboBox &cmbCmd)
{
	CMenu menuSub(hMenuSub);
	int nPopStartIndex = cmbCmd.AddString(_cSeparater);

	int nAddCnt=0;
	for (int ii=0; ii<menuSub.GetMenuItemCount(); ii++)
	{
		HMENU hMenuSub2 = menuSub.GetSubMenu(ii);
		if (hMenuSub2)
			_PickUpCommandSub(hMenuSub2, cmbCmd);

		UINT nCmdID = menuSub.GetMenuItemID(ii);
		if (_DontUseID(nCmdID))
			break;

		CString strMenu;
		CToolTipManager::LoadToolTipText(nCmdID, strMenu);
		if (strMenu.IsEmpty()) continue;

		int nIndex = cmbCmd.AddString(strMenu);
		cmbCmd.SetItemData(nIndex, nCmdID);
		nAddCnt++;
	}

	if (nAddCnt!=0)
		cmbCmd.AddString(_cSeparater);
	else
		cmbCmd.DeleteString(nPopStartIndex);

	menuSub.Detach();
}

void _PickUpCommand(HMENU hMenu, int nPopup, CComboBox &cmbCmd)
{
	HMENU hMenuSub = ::GetSubMenu(hMenu, nPopup);
	CMenu menu(hMenuSub);

	cmbCmd.ResetContent();
	for (int ii=0; ii<::GetMenuItemCount(hMenuSub); ii++)
	{
		HMENU hMenuSub = menu.GetSubMenu(ii);
		if (hMenuSub)
			_PickUpCommandSub(hMenuSub, cmbCmd);

		UINT nCmdID = menu.GetMenuItemID(ii);
		if (_DontUseID(nCmdID))
			break;

		CString strMenu;
		CToolTipManager::LoadToolTipText(nCmdID, strMenu);
		if (strMenu.IsEmpty()) continue;

		int nIndex = cmbCmd.AddString(strMenu);
		cmbCmd.SetItemData(nIndex, nCmdID);
	}

	menu.Detach();

	//�s�v�ȃZ�p���[�^�̍폜
	int nCountSep=0;
	int nCountCmb = cmbCmd.GetCount();
	for(int i=0; i<nCountCmb-1; i++){
		if(cmbCmd.GetItemData(i) == 0){
			nCountSep++;
			if(cmbCmd.GetItemData(i+1) == 0){
				cmbCmd.DeleteString(i);
				nCountCmb--;
				i--;
			}
		}
	}
	if(nCountSep > 2){
		if(cmbCmd.GetItemData(0) == 0)
			cmbCmd.DeleteString(0);
		int nIndexLast = cmbCmd.GetCount()-1;
		if(cmbCmd.GetItemData(nIndexLast) == 0)
			cmbCmd.DeleteString(nIndexLast);
	}


}

//minit
BOOL _ReplaceImageList(CString strBmpFile,CImageList& imgs)
{
	CBitmap bmp;
	bmp.Attach(AtlLoadBitmapImage(strBmpFile.GetBuffer(0),LR_LOADFROMFILE));

	if(bmp.m_hBitmap){
		int nCount =imgs.GetImageCount();
		for(int i=0; i<nCount; i++){
			if(!imgs.Remove(0)) return FALSE;
		}
		imgs.Add(bmp,RGB(255,0,255));
		return TRUE;
	}

	return FALSE;
}

int _Pack(int hi, int low)
{
	if( !((('0' <= low && low <= '9') || ('A' <= low && low <= 'F') || ('a' <= low && low <= 'f')) &&
		  (('0' <= hi  && hi  <= '9') || ('A' <= hi  && hi  <= 'F') || ('a' <= hi  && hi  <= 'f')))    )
		return 0; //���l�ł͂Ȃ�

	int nlow = ('0' <= low && low <= '9') ? low - '0' : (('A' <= low && low <= 'F') ? low - 'A' + 0xA : low - 'a' + 0xA);
	int nhi  = ('0' <= hi  && hi  <= '9') ? hi  - '0' : (('A' <= hi  && hi  <= 'F') ? hi  - 'A' + 0xA : hi  - 'a' + 0xA);
	return (nhi << 4) + nlow; 
}

BOOL _QueryColorString(CIniSection& pr, COLORREF& col, LPCTSTR lpstrKey)
{
	CString strCol;
	DWORD dwBufferSize = 20;
	DWORD dwLen = dwBufferSize;
	
	LONG lRet = pr.QueryValue(strCol.GetBuffer(dwBufferSize),lpstrKey,&dwLen);
	strCol.ReleaseBuffer();
	if(lRet != ERROR_SUCCESS) return FALSE;

	if(strCol.IsEmpty()) return FALSE;
	strCol.TrimLeft('#');

	col = RGB( _Pack(strCol[0],strCol[1]) ,
			   _Pack(strCol[2],strCol[3]) ,
			   _Pack(strCol[4],strCol[5])
			 );

	return TRUE;
}












