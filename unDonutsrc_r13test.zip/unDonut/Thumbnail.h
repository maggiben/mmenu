
#ifndef __THUMBNAIL_H_
#define __THUMBNAIL_H_

class CThumbnailDlg : public CDialogImpl<CThumbnailDlg>//, public CMessageFilter

{
public:
	enum { IDD = IDD_DIALOG_THUMBNAIL,
			WIDTH = 200, HEIGHT = 200, SPACE = 2,
			m_nMinWidth = 20, m_nMinHeight = 50,
			m_nDefWidth = 550, m_nDefHeight = 520 
		};

	CListViewCtrl	m_List;
	CImageList		m_ImageList;
	HWND			m_hParent;
	BOOL			m_bCenter;
	BOOL			m_bSavePos;
	int				m_nPictWidth;
	int				m_nPictHeight;
	CRect			m_rcDialog;
	BOOL			m_bInit;

	CContainedWindow m_wndList;

	CThumbnailDlg() : m_wndList(this,1), m_bCenter(FALSE), m_bInit(FALSE)
	{
	}

	BEGIN_MSG_MAP(CThumbnailDlg)
		MESSAGE_HANDLER(WM_INITDIALOG, OnInitDialog)
		MESSAGE_HANDLER(WM_ACTIVATE, OnActivate)
		MESSAGE_HANDLER(WM_SIZE,OnSize)
		MESSAGE_HANDLER(WM_DESTROY,OnDestroy)
		NOTIFY_HANDLER(IDC_LIST_THUMBNAIL,NM_DBLCLK,OnDblClk)
		COMMAND_ID_HANDLER(IDOK, OnCloseCmd)
		COMMAND_ID_HANDLER(IDCANCEL, OnCloseCmd)
	ALT_MSG_MAP(1)
		MESSAGE_HANDLER(WM_KEYDOWN,OnKeyDown)
	END_MSG_MAP()

	int DoModal(HWND hWndParent, LPARAM dwInitParam = NULL)
	{
		m_hParent = (HWND)dwInitParam;
		return CDialogImpl<CThumbnailDlg>::DoModal(hWndParent,dwInitParam);
	}

	LRESULT OnInitDialog(UINT /*uMsg*/, WPARAM /*wParam*/, LPARAM /*lParam*/, BOOL& /*bHandled*/)
	{	
		GetDefaultSize(m_rcDialog);
		//::MoveWindow(m_hWnd, rc.left, rc.top, rc.Width(), rc.Height(), TRUE); 
		

		m_List = GetDlgItem(IDC_LIST_THUMBNAIL);
		m_ImageList.Create(m_nPictWidth,m_nPictHeight,ILC_COLOR24,8,8);
		
		MtlForEachMDIChild(m_hParent,_Function_EnumChild_MakeThumbnail(m_ImageList,m_nPictWidth,m_nPictHeight));
		m_List.SetImageList(m_ImageList.m_hImageList,LVSIL_NORMAL);
		MtlForEachMDIChild(m_hParent,_Function_EnumChild_MakeListView(m_List));

		MoveWindow(m_rcDialog, TRUE);

		m_wndList.SubclassWindow(m_List.m_hWnd);

		return TRUE;
	}

	void GetDefaultSize(CRect &rc)
	{
		CIniSection pr;
		DWORD dwSave, dwLeft, dwTop, dwRight, dwBottom;
		DWORD dwWidth, dwHeight;
		dwSave=dwLeft=dwTop=dwRight=dwBottom = 0;

		//�ʒu���擾
		pr.Open(_szIniFileName,_T("Thumbnail"));
		pr.QueryValue(dwSave,_T("SavePosition"));
		if(dwSave){
			pr.QueryValue(dwLeft,_T("Left"));
			pr.QueryValue(dwTop,_T("Top"));
			pr.QueryValue(dwRight,_T("Right"));
			pr.QueryValue(dwBottom,_T("Bottom"));
			if(dwRight == 0 || dwBottom == 0){
				dwRight = dwLeft + m_nDefWidth;
				dwBottom = dwTop + m_nDefHeight;
				m_bCenter = TRUE;
			}
			rc.SetRect(dwLeft,dwTop,dwRight,dwBottom);
		}else{
			m_bCenter = TRUE;
			rc.SetRect(0,0,m_nDefWidth,m_nDefHeight);
		}
		m_bSavePos = dwSave ? TRUE : FALSE;

		//�摜�T�C�Y�擾
		dwWidth = dwHeight = 0;
		pr.QueryValue(dwWidth,_T("PicWidth"));
		pr.QueryValue(dwHeight,_T("PicHeight"));
		if(dwWidth == 0)	m_nPictWidth = WIDTH;
		else				m_nPictWidth = dwWidth;
		if(dwHeight == 0)	m_nPictHeight = HEIGHT;
		else				m_nPictHeight = dwHeight;

		pr.Close();
	}

	LRESULT OnDestroy(UINT /*uMsg*/, WPARAM wParam, LPARAM /*lParam*/, BOOL& /*bHandled*/)
	{
		if(m_bSavePos){
			CRect rc;
			GetWindowRect(&rc);
			CIniSection pr;
			pr.Open(_szIniFileName, _T("Thumbnail"));
			pr.SetValue(rc.left , _T("Left"));
			pr.SetValue(rc.top,   _T("Top"));
			pr.SetValue(rc.right, _T("Right"));
			pr.SetValue(rc.bottom,_T("Bottom"));
			pr.Close();
		}
		return 0;
	}

	LRESULT OnActivate(UINT /*uMsg*/, WPARAM wParam, LPARAM /*lParam*/, BOOL& /*bHandled*/)
	{

		return 0;
	}

	LRESULT OnSize(UINT /*uMsg*/, WPARAM wParam, LPARAM /*lParam*/, BOOL& /*bHandled*/)
	{
		if(!m_bInit){
			MoveWindow(m_rcDialog,TRUE);
			if(m_bCenter) CenterWindow(GetParent());
			m_bInit = TRUE;
		}

		CRect rc;
		GetClientRect(&rc);
		rc.DeflateRect(SPACE,SPACE);
		m_List.MoveWindow(&rc,TRUE);

		return 0;
	}

	LRESULT OnKeyDown(UINT /*uMsg*/, WPARAM wParam, LPARAM /*lParam*/, BOOL& /*bHandled*/)
	{
		int nVirtKey = (int)wParam;

		if(nVirtKey == 'W' || nVirtKey == 'w'){
			if(::GetKeyState(VK_CONTROL)<0)
				EndDialog(0);
		}
		return 0;
	}

	LRESULT OnCloseCmd(WORD /*wNotifyCode*/, WORD wID, HWND /*hWndCtl*/, BOOL& /*bHandled*/)
	{
		//DestroyWindow();
		EndDialog(wID);
		return 0;
	}

	LRESULT OnDblClk(int idCtrl, LPNMHDR pnmh, BOOL& bHandled)
	{
		LPNMLISTVIEW plv = (LPNMLISTVIEW)pnmh;
		int index = plv->iItem;
		HWND hWnd = (HWND)m_List.GetItemData(index);

		::SendMessage(m_hParent,WM_MDIACTIVATE,(WPARAM)hWnd,0);
		EndDialog(index);

		return 0;
	}
	
	struct _Function_EnumChild_MakeListView
	{
		CListViewCtrl& m_ListView;
		_Function_EnumChild_MakeListView(CListViewCtrl& List) :
			m_ListView(List)
		{
		}

		void operator()(HWND hWnd)
		{
			CString strTitle = MtlGetWindowText(hWnd);
			int index = m_ListView.GetItemCount();
			m_ListView.InsertItem(LVIF_IMAGE | LVIF_TEXT, index, strTitle, 0, 0, index, 0);
			m_ListView.SetItemData(index,(LPARAM)hWnd);
		}

	};

	struct _Function_EnumChild_MakeThumbnail
	{
		CImageList& m_ImgList;
		int m_nWidth;
		int m_nHeight;

		_Function_EnumChild_MakeThumbnail(CImageList& ImgList, int PictWidth, int PictHeight) :
			m_ImgList(ImgList), m_nWidth(PictWidth), m_nHeight(PictHeight)
		{
		}

		void operator()(HWND hWnd)
		{
			CComPtr<IWebBrowser2> pWB2;
			CComPtr<IHTMLDocument2> pDoc;
			pWB2 = DonutGetIWebBrowser2(hWnd);
			pWB2->get_Document((IDispatch**)&pDoc);
			if(pDoc){
				HDC hTmp = ::GetDC(::GetDesktopWindow());
				HDC hdc = ::CreateCompatibleDC(hTmp);
				HBITMAP hBmp = ::CreateCompatibleBitmap(hTmp,m_nWidth,m_nHeight);
				::ReleaseDC(::GetDesktopWindow(),hTmp);
				HBITMAP hOldBmp = (HBITMAP)::SelectObject(hdc,hBmp);

				CRect rc;
				int Width,Height;
				::GetClientRect(hWnd,&rc);
				if(rc.Width() < rc.Height()){
					Width = m_nWidth;
					Height = (int)(m_nHeight * ((double)rc.Height() / rc.Width()));
				}else{
					Width = (int)(m_nWidth * ((double)rc.Width() / rc.Height()));
					Height = m_nHeight;
				}
				::OleDraw(pDoc,1,hdc,CRect(0,0,Width-1,Height-1));
				::SelectObject(hdc,hOldBmp);

				m_ImgList.Add(hBmp);

				::DeleteObject(hBmp);
				::DeleteDC(hdc);
			}
		}

		void SaveBitmap(HDC hDC, HBITMAP hBmp, int index)
		{
			LPBITMAPFILEHEADER pbf;
			LPBITMAPINFOHEADER pbi;
			char dat[54];
			char bits[200*200*3];
		
			CString str;
			str.Format("test%02d.bmp",index);
			FILE *fp,*fpdat;
			fp = fopen(str,"wb");
			fpdat = fopen("test.dat","rb");

			pbf = (BITMAPFILEHEADER*)dat;
			pbi = (BITMAPINFOHEADER*)(dat + sizeof(BITMAPFILEHEADER));

			fread(dat,1,54,fpdat);
			::GetDIBits(hDC,hBmp,0,200,bits,(BITMAPINFO*)pbi,DIB_RGB_COLORS);
			fwrite(dat,1,54,fp);
			fwrite(bits,1,200*200*3,fp);

			fclose(fpdat);
			fclose(fp);
		}
	};


	
};

























#endif //__THUMBNAIL_H_