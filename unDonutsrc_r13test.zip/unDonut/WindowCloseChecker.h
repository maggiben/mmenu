#pragma once 


class CWindowCloseChecker
{
protected:
	static bool s_bClose;

public:
	static void Close();
	static bool IsClosing();
};
