#pragma once

#include "../resource.h"

class CMenuPropertyPage : public CPropertyPageImpl<CMenuPropertyPage>,
	public CWinDataExchange<CMenuPropertyPage>
{
public:
// Constants
	enum { IDD = IDD_PROPPAGE_MENU};

// Data members
	HMENU	m_hMenu;
	CComboBox m_cmbTar;
	CComboBox m_cmbCategory;
	CComboBox m_cmbCommand;

	CComboBox m_cmbCategory2;
	CComboBox m_cmbCommand2;

	CListBox m_ltFront;
	CListBox m_ltBack;

	CSimpleMap<int, CSimpleArray<int>*>	m_mapFront;
	CSimpleMap<int, CSimpleArray<int>*>	m_mapBack;

	BOOL m_bFirst;
	CString m_strPath;

	int m_nNoCstmMenu, m_nNoCstmIeMenu;
	int m_nREqualL;
	int m_nNoButton;

// DDX map
	BEGIN_DDX_MAP(CMenuPropertyPage)
		DDX_CHECK(IDC_NO_CSTM_TXT_MENU,	m_nNoCstmMenu)
		DDX_CHECK(IDC_NO_CSTM_IE_MENU,	m_nNoCstmIeMenu)
		DDX_CHECK(IDC_CHECK_R_EQUAL_L,  m_nREqualL)
		DDX_CHECK(IDC_CHECK_NOBUTTON,   m_nNoButton)
	END_DDX_MAP()

	CMenuPropertyPage(HMENU hMenu);

	~CMenuPropertyPage();

// Overrides
	BOOL OnSetActive();
	BOOL OnKillActive();
	BOOL OnApply();

	// �f�[�^��ۑ�
	void _SaveData();
	void _SaveExData(CSimpleArray<int>* pAryEx);
	void InitialListbox();
	void _LoadExData(CSimpleArray<int> *pAryEx);
	void InitialCmbbox();

// Constructor

// Message map and handlers
	BEGIN_MSG_MAP(CMenuPropertyPage)
		CHAIN_MSG_MAP(CPropertyPageImpl<CMenuPropertyPage>)
		COMMAND_HANDLER_EX(IDC_CMB_CATEGORY, CBN_SELCHANGE, OnSelChangeCate)
		COMMAND_HANDLER_EX(IDC_CMB_COMMAND, CBN_SELCHANGE, OnSelChangeCmd)


		COMMAND_HANDLER_EX(IDC_CMB_TAR, CBN_SELCHANGE, OnSelChangeTarget)

		COMMAND_ID_HANDLER_EX(IDC_BTN_ADD1, OnBtnAdd)
		COMMAND_ID_HANDLER_EX(IDC_BTN_DEL1, OnBtnDel)

		COMMAND_ID_HANDLER_EX(IDC_BTN_ADD2, OnBtnAdd)
		COMMAND_ID_HANDLER_EX(IDC_BTN_DEL2, OnBtnDel)

		COMMAND_HANDLER_EX(IDC_LIST1, LBN_SELCHANGE, OnListChg)
		COMMAND_HANDLER_EX(IDC_LIST2, LBN_SELCHANGE, OnListChg)

		COMMAND_ID_HANDLER_EX(IDC_BTN_UP1, OnBtnUp)
		COMMAND_ID_HANDLER_EX(IDC_BTN_UP2, OnBtnUp)

		COMMAND_ID_HANDLER_EX(IDC_BTN_DOWN1, OnBtnDown)
		COMMAND_ID_HANDLER_EX(IDC_BTN_DOWN2, OnBtnDown)
	END_MSG_MAP()

	void OnSelChangeCate(UINT code, int id, HWND hWnd);

	// �g���R�}���h
	void PickUpCommandEx(CComboBox &cmbCmd);
	void OnSelChangeCmd(UINT code, int id, HWND hWnd);
	void OnBtnAdd(UINT /*wNotifyCode*/, int wID, HWND /*hWndCtl*/);
	void OnBtnDel(UINT /*wNotifyCode*/, int wID, HWND /*hWndCtl*/);
	void OnListChg(UINT code, int id, HWND hWnd);

	void OnSelChangeTarget(UINT code, int id, HWND hWnd);
	void SetAddMenu(int nType);
	void GetTargetMenuaryAndListbox(int nID, CSimpleArray<int>* &pAryMenu, CListBox* &pListBox);

	void OnBtnUp(UINT /*wNotifyCode*/, int wID, HWND /*hWndCtl*/);
	void OnBtnDown(UINT /*wNotifyCode*/, int wID, HWND /*hWndCtl*/);
	void ShowSecondObjects(BOOL bShow);
};
