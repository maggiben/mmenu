#include "stdafx.h"
#include "DeterrentDialog.h"
#error ThisHeader is obsolete.


// Constructor
CDeterrentPropertyPage::CDeterrentPropertyPage(const CString& strUrl, const CString& strTitle):
	m_urls(*CIgnoredURLsOption::s_pIgnoredURLs), m_strUrl(strUrl),
	m_titles(*CCloseTitlesOption::s_pCloseTitles), m_strTitle(strTitle)
{
	m_urls.sort();
	m_titles.sort();
	m_nChkUrl = CIgnoredURLsOption::s_bValid ? 1 : 0;
	m_nChkTitle = CCloseTitlesOption::s_bValid ? 1 : 0;
}

// Overrides
BOOL CDeterrentPropertyPage::OnSetActive()
{
	SetModified(TRUE);
	return _DoDataExchange(FALSE);
}

BOOL CDeterrentPropertyPage::OnKillActive()
{
	return _DoDataExchange(TRUE);
}

BOOL CDeterrentPropertyPage::OnApply()
{
	if (_DoDataExchange(TRUE)) {
		_GetData();
		return TRUE;
	}
	else 
		return FALSE;
}

// overrides
BOOL CDeterrentPropertyPage::_DoDataExchange(BOOL bSaveAndValidate)// get data from controls?
{
	if (!bSaveAndValidate)
	{
		// set data of control
		m_ltUrl.Attach	( GetDlgItem(IDC_LIST_URL) );
		m_ltTitle.Attach( GetDlgItem(IDC_LIST_TITLE) );

		m_ltUrl.ResetContent();
		m_ltTitle.ResetContent();

		std::for_each( m_urls.begin(), m_urls.end(), _AddToListBox(m_ltUrl) );
		std::for_each( m_titles.begin(), m_titles.end(), _AddToListBox(m_ltTitle) );

		m_edtUrl.Attach		( GetDlgItem(IDC_EDIT_URL) );
		m_edtTitle.Attach	( GetDlgItem(IDC_EDIT_TITLE) );

		m_edtUrl.SetWindowText( m_strUrl );
		m_edtTitle.SetWindowText( m_strTitle );
	}

	return DoDataExchange(bSaveAndValidate);
}

void CDeterrentPropertyPage::OnDelCmd(UINT /*wNotifyCode*/, int wID, HWND hWndCtl)
{
	CListBox ltBox;
	if ( wID == IDC_BTN_DEL_URL )
		ltBox = m_ltUrl;
	else
		ltBox = m_ltTitle;

	int nIndex = ltBox.GetCurSel();
	if (nIndex == LB_ERR) return;
	ltBox.DeleteString(nIndex);

	if ( wID == IDC_BTN_DEL_URL )
	{
		CIgnoredURLsOption::CStringList::iterator it = m_urls.begin();
		std::advance(it, nIndex);
		m_urls.erase(it);
	}
	else
	{
		CCloseTitlesOption::CStringList::iterator it = m_titles.begin();
		std::advance(it, nIndex);
		m_titles.erase(it);
	}
}

void CDeterrentPropertyPage::OnDelAllCmd(UINT /*wNotifyCode*/, int wID, HWND hWndCtl )
{
	switch ( wID )
	{
	case IDC_BTN_DELALL_URL:
		m_ltUrl.ResetContent();
		m_urls.clear();
		break;

	case IDC_BTN_DELALL_TITLE:
		m_ltTitle.ResetContent();
		m_titles.clear();
		break;
	}
}

void CDeterrentPropertyPage::OnAddCmd(UINT /*wNotifyCode*/, int wID, HWND hWndCtl)
{
	CEdit edtTarget = hWndCtl;
	switch ( wID )
	{
	case IDC_BTN_ADD_URL:		edtTarget = m_edtUrl;	break;
	case IDC_BTN_ADD_TITLE:		edtTarget = m_edtTitle; break;
	}

	TCHAR szEdit[MAX_PATH];
	if ( edtTarget.GetWindowText(szEdit, MAX_PATH) == 0 )
		return;

	if ( wID == IDC_BTN_ADD_URL )
	{
		CIgnoredURLsOption::CStringList::iterator it = std::find(m_urls.begin(), m_urls.end(), szEdit);
		if (it == m_urls.end())
		{
			m_ltUrl.AddString(szEdit);
			m_urls.push_back(szEdit);
		}
		else {
#ifdef __SGI_STL_INTERNAL_ITERATOR_BASE_H
			int n = 0;
			std::distance(m_urls.begin(), it, n);
			m_ltUrl.SetCurSel(n);
#else
			m_ltUrl.SetCurSel(std::distance(m_urls.begin(), it));
#endif
		}
	}
	else
	{
		CCloseTitlesOption::CStringList::iterator it = std::find(m_titles.begin(), m_titles.end(), szEdit);
		if (it == m_titles.end())
		{
			m_ltTitle.AddString(szEdit);
			m_titles.push_back(szEdit);
		}
		else {
#ifdef __SGI_STL_INTERNAL_ITERATOR_BASE_H
			int n = 0;
			std::distance(m_titles.begin(), it, n);
			m_ltTitle.SetCurSel(n);
#else
			m_ltTitle.SetCurSel(std::distance(m_titles.begin(), it));// is C++ standard.
#endif
		}
	}
}

void CDeterrentPropertyPage::OnSelChange(UINT code, int id, HWND hWnd)
{
	CListBox ltBox = hWnd;
	int nIndex = ltBox.GetCurSel();
	CString strBox;
	ltBox.GetText(nIndex, strBox);

	switch ( ltBox.GetDlgCtrlID() )
	{
	case IDC_LIST_URL:
		m_edtUrl.SetWindowText(strBox);
		break;

	case IDC_LIST_TITLE:
		m_edtTitle.SetWindowText(strBox);
		break;
	}
}

void CDeterrentPropertyPage::_GetData()
{
	// update ignored urls list
	*CIgnoredURLsOption::s_pIgnoredURLs = m_urls;
	CIgnoredURLsOption::s_bValid = m_nChkUrl == 1 ? true : false;

	*CCloseTitlesOption::s_pCloseTitles = m_titles;
	CCloseTitlesOption::s_bValid = m_nChkTitle == 1 ? true : false;
}
