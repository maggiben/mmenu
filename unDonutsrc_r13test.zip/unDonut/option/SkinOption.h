#pragma once

#include "../resource.h"
#include "../MtlPrivateProfile.h"

#define SKN_COMBO_STYLE_DEFAULT	0
#define SKN_COMBO_STYLE_CLASSIC 1
#define SKN_COMBO_STYLE_THEME	2

#define SKN_TAB_STYLE_DEFAULT	0
#define SKN_TAB_STYLE_CLASSIC	1
#define SKN_TAB_STYLE_THEME		2

#define SKN_REBAR_STYLE_TILE	0
#define SKN_REBAR_STYLE_STRETCH	1
#define SKN_REBAR_STYLE_THEME	2

#define SKN_STATUS_STYLE_TILE   0
#define SKN_STATUS_STYLE_STRETCH 1
#define SKN_STATUS_STYLE_THEME	2

#define SKN_CONST_DEFAULT		_T("DEFAULT")
#define SKN_CONST_DEFAULT_INT	0
#define SKN_CONST_CLASSIC		_T("CLASSIC")
#define SKN_CONST_CLASSIC_INT	1
#define SKN_CONST_THEME			_T("THEME")
#define SKN_CONST_THEME_INT		2
#define SKN_CONST_TILE			_T("TILE")
#define SKN_CONST_TILE_INT		0
#define SKN_CONST_STRETCH		_T("STRETCH")
#define SKN_CONST_STRETCH_INT	1
#define SKN_CONST_NO			_T("NO")
#define SKN_CONST_NO_INT		0
#define SKN_CONST_YES			_T("YES")
#define SKN_CONST_YES_INT		1


class CSkinOption
{
public:
	static int s_nComboStyle;
	static int s_nTabStyle;
	static int s_nRebarBGStyle;
	static int s_nRebarNoBoader;
	static int s_nStatusStyle;

	static int GetIntegerFromStringConst(CString &strConst);
	static void GetProfile();
	static int QueryValueCustom(MTL::CIniSection& pr,LPCTSTR lpKey);

};


class CSkinPropertyPage : public CPropertyPageImpl<CSkinPropertyPage>
{
public:

	enum { IDD = IDD_PROPPAGE_SKIN };
	BOOL m_bInit;
	HWND m_hTopWindow;
	BOOL *m_pbChanged;

	CSkinPropertyPage(HWND hTopWindow, BOOL *pbSkinChange);

	void _SetData();

	BEGIN_MSG_MAP(CSkinPropertyPage)
		MESSAGE_HANDLER(WM_DESTROY,OnDestroy)
		COMMAND_ID_HANDLER(IDC_BUTTON_APPLY,OnSkinApply)
		CHAIN_MSG_MAP(CPropertyPageImpl<CSkinPropertyPage>)
		COMMAND_HANDLER(IDC_LIST_SKIN,LBN_SELCHANGE,OnSelChanged)
	END_MSG_MAP()

	LRESULT OnSelChanged(WORD wNotifyCode, WORD wID, HWND hWndCtl, BOOL& bHandled);
	LRESULT OnDestroy(UINT /*uMsg*/, WPARAM /*wParam*/, LPARAM /*lParam*/, BOOL& /*bHandled*/);
	LRESULT OnSkinApply(WORD /*wNotifyCode*/, WORD wID, HWND /*hWndCtl*/, BOOL& /*bHandled*/);
	
	BOOL OnSetActive();

	LPTSTR _AllocString();
	void _FreeString(LPTSTR lpstr);

};