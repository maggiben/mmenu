#include "stdafx.h"
#include "MainOption.h"
#include "../MtlWeb.h"
#include "../DonutPFunc.h"


////////////////////////////////////////////////////////////////////////////////
//CMainOption�̒�`
////////////////////////////////////////////////////////////////////////////////

DWORD CMainOption::s_dwMainExtendedStyle = MAIN_EX_NEWWINDOW||MAIN_EX_KILLDIALOG;
DWORD CMainOption::s_dwMainExtendedStyle2 = 0;
DWORD CMainOption::s_dwExplorerBarStyle = 0;
DWORD CMainOption::s_dwMaxWindowCount = 0;
DWORD CMainOption::s_dwBackUpTime = 1;
DWORD CMainOption::s_dwAutoRefreshTime = 10; // UDT DGSTR ( dai
bool CMainOption::s_bTabMode = false;

bool CMainOption::s_bAppClosing = false;
bool CMainOption::s_bIgnoreUpdateClipboard = false;

CRecentDocumentListFixed* CMainOption::s_pMru = NULL;
bool CMainOption::s_bNoCstmMenu = false;

DWORD CMainOption::s_dwErrorBlock = 0;

CString *CMainOption::s_pstrExplorerUserDirectory = NULL;

bool CMainOption::s_bTravelLogGroup = false;
bool CMainOption::s_bTravelLogClose = false;

bool CMainOption::s_bStretchImage = false;

CMainOption::CMainOption()
{
} 

void CMainOption::GetProfile()
{
	CIniSection pr;

	DWORD dwTravelLogGroup = 0, dwTravelLogClose = 0;
	pr.Open(_szIniFileName, _T("Main"));
	pr.QueryValue(s_dwMainExtendedStyle, _T("Extended_Style"));
	pr.QueryValue(s_dwMainExtendedStyle2, _T("Extended_Style2"));
	pr.QueryValue(s_dwMaxWindowCount, _T("Max_Window_Count"));
	pr.QueryValue(s_dwBackUpTime, _T("BackUp_Time"));
	pr.QueryValue(s_dwAutoRefreshTime, _T("Auto_Refresh_Time")); // UDT DGSTR ( dai
	pr.QueryValue(s_dwExplorerBarStyle, _T("ExplorerBar_Style")); // UH
	pr.QueryValue(s_dwErrorBlock, _T("ErrorBlock")); //minit
	pr.QueryValue(dwTravelLogGroup, _T("TravelLogGroup"));
	pr.QueryValue(dwTravelLogClose, _T("TravelLogClose"));
	pr.Close();

	s_bTravelLogGroup = dwTravelLogGroup ? true : false;
	s_bTravelLogClose = dwTravelLogClose ? true : false;

	s_pMru = new CRecentDocumentListFixed;
	s_pMru->SetMaxEntries(9);
	s_pMru->ReadFromIniFile();

	if (s_dwMainExtendedStyle & MAIN_EX_NOMDI)
		s_bTabMode = true;
	else
		s_bTabMode = false;

	if (s_dwMainExtendedStyle2 & MAIN_EX2_NOCSTMMENU)
		s_bNoCstmMenu = true;
	else
		s_bNoCstmMenu = false;

	// NOTE. If all the Web Browser server on your desktop is unloaded, some OS automatically goes online.
	//       And if all the Web Browser server on you application is unloaded, some OS automatically goes online.
	if (_check_flag(MAIN_EX_LOADGLOBALOFFLINE, s_dwMainExtendedStyle)){
		MtlSetGlobalOffline(_check_flag(MAIN_EX_GLOBALOFFLINE, s_dwMainExtendedStyle));	
	}

	//�������m�ۂ����ł����Ə����悤��
	DWORD dwCount = MAX_PATH;
	s_pstrExplorerUserDirectory = new CString();
	pr.Open(_szIniFileName, _T("Explorer_Bar"));
	pr.QueryValue(s_pstrExplorerUserDirectory->GetBuffer(MAX_PATH), _T("UserDirectory"), &dwCount);
	s_pstrExplorerUserDirectory->ReleaseBuffer();
	pr.Close();

	/*CRegKey rk;
	LONG lRet = rk.Open(HKEY_CURRENT_USER, _T("Software\\Microsoft\\Internet Explorer\\Main"));
	if(lRet == ERROR_SUCCESS){
		TCHAR szValue[MAX_PATH]; DWORD dwSize=MAX_PATH;
		lRet = rk.QueryValue(szValue,_T("Enable AutoImageResize"),&dwSize);
		if(lRet == ERROR_SUCCESS){
			CString strValue = szValue;
			if(strValue == _T("yes"))
				s_bStretchImage = true;
		}
	}*/
	DWORD dwAutoResize=0;
	pr.Open(_szIniFileName,_T("Main"));
	pr.QueryValue(dwAutoResize,_T("AutoResize"));
	pr.Close();
}

void CMainOption::WriteProfile()
{
	CIniSection pr;

	if (MtlIsGlobalOffline())
		s_dwMainExtendedStyle |= MAIN_EX_GLOBALOFFLINE;
	else
		s_dwMainExtendedStyle &= ~MAIN_EX_GLOBALOFFLINE;

	DWORD dwTravelLogGroup, dwTravelLogClose;
	dwTravelLogGroup = s_bTravelLogGroup ? 1 : 0;
	dwTravelLogClose = s_bTravelLogClose ? 1 : 0;

	pr.Open(_szIniFileName, _T("Main"));
	pr.SetValue(s_dwMainExtendedStyle, _T("Extended_Style"));
	pr.SetValue(s_dwMainExtendedStyle2, _T("Extended_Style2"));
	pr.SetValue(s_dwExplorerBarStyle, _T("ExplorerBar_Style")); // UDT DGSTR ( dai
	pr.SetValue(s_dwMaxWindowCount, _T("Max_Window_Count"));
	pr.SetValue(s_dwBackUpTime, _T("BackUp_Time"));
	pr.SetValue(s_dwAutoRefreshTime, _T("Auto_Refresh_Time")); // UDT DGSTR ( dai
	pr.SetValue(dwTravelLogGroup, _T("TravelLogGroup"));
	pr.SetValue(dwTravelLogClose, _T("TravelLogClose"));
	pr.Close();

	s_pMru->WriteToIniFile();
	if (s_dwMainExtendedStyle2 & MAIN_EX2_DEL_RECENTCLOSE)
		s_pMru->DeleteIniKeys();
	delete s_pMru;

	//�m�ۂ������͂����Ə���
	pr.Open(_szIniFileName , _T("Explorer_Bar"));
	pr.SetValue(*s_pstrExplorerUserDirectory, _T("UserDirectory"));
	pr.Close();

	if(s_pstrExplorerUserDirectory)
		delete s_pstrExplorerUserDirectory;
}

void CMainOption::SetExplorerUserDirectory(CString& strPath)
{
	ATLASSERT(s_pstrExplorerUserDirectory != NULL);
	*s_pstrExplorerUserDirectory = strPath;
}

CString CMainOption::GetExplorerUserDirectory()
{
	ATLASSERT(s_pstrExplorerUserDirectory != NULL);
	return *s_pstrExplorerUserDirectory;
}

void CMainOption::SetMRUMenuHandle(HMENU hMenu, int nPos)
{
	HMENU hFileMenu = ::GetSubMenu(hMenu, 0);
#ifdef _DEBUG
	// absolute position, can change if menu changes
	TCHAR szMenuString[100];
	::GetMenuString(hFileMenu, nPos, szMenuString, sizeof(szMenuString), MF_BYPOSITION);
	ATLASSERT(lstrcmp(szMenuString, _T("�ŋߕ����t�@�C��(&F)")) == 0);
#endif //_DEBUG
	HMENU hMruMenu = ::GetSubMenu(hFileMenu, nPos);
	CMainOption::s_pMru->SetMenuHandle(hMruMenu);
	CMainOption::s_pMru->UpdateMenu();
}

bool CMainOption::IsQualify(int nWindowCount)
{
	if (!(s_dwMainExtendedStyle & MAIN_EX_WINDOWLIMIT))
		return true;

	if (nWindowCount < (int)s_dwMaxWindowCount)
		return true;
	else
		return false;
}

void CMainOption::OnMainExNewWindow(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/)
{
	if (s_dwMainExtendedStyle & MAIN_EX_NEWWINDOW)
		s_dwMainExtendedStyle &= ~MAIN_EX_NEWWINDOW;
	else
		s_dwMainExtendedStyle |= MAIN_EX_NEWWINDOW;
}

void CMainOption::OnMainExNoActivate(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/)
{
	if (s_dwMainExtendedStyle & MAIN_EX_NOACTIVATE)
		s_dwMainExtendedStyle &= ~MAIN_EX_NOACTIVATE;
	else
		s_dwMainExtendedStyle |= MAIN_EX_NOACTIVATE;
}

void CMainOption::OnMainExNoActivateNewWin(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/)
{
	if (s_dwMainExtendedStyle & MAIN_EX_NOACTIVATE_NEWWIN)
		s_dwMainExtendedStyle &= ~MAIN_EX_NOACTIVATE_NEWWIN;
	else
		s_dwMainExtendedStyle |= MAIN_EX_NOACTIVATE_NEWWIN;
}


////////////////////////////////////////////////////////////////////////////////
//CMainPropertyPage�̒�`
////////////////////////////////////////////////////////////////////////////////


void CMainPropertyPage::OnFont(WORD /*wNotifyCode*/, WORD /*wID*/, HWND hWndCtl)
{
	CFontDialog dlg(&m_lf);
	if (dlg.DoModal() == IDOK){
		m_lf = dlg.m_lf;
	}
}

// Constructor
CMainPropertyPage::CMainPropertyPage(HWND hWnd)
	: m_wnd(hWnd)
{
	_SetData();
}

// Overrides
BOOL CMainPropertyPage::OnSetActive()
{
	ATLTRACE(_T("CMainPropertyPage::OnSetActive()\n"));
	SetModified(TRUE);
	return DoDataExchange(FALSE);
}
BOOL CMainPropertyPage::OnKillActive()
{
	ATLTRACE(_T("CMainPropertyPage::OnKillActive()\n"));
	return DoDataExchange(TRUE);
}
BOOL CMainPropertyPage::OnApply()
{
	if (DoDataExchange(TRUE)) {
		_GetData();
		return TRUE;
	}
	else 
		return FALSE;
}

void CMainPropertyPage::_GetData()
{
	// Update main style
	CMainOption::s_dwMainExtendedStyle = 0;
	if (m_nNewWindow == 1)
		CMainOption::s_dwMainExtendedStyle |= MAIN_EX_NEWWINDOW;
	if (m_nNoActivate == 1)
		CMainOption::s_dwMainExtendedStyle |= MAIN_EX_NOACTIVATE;
	if (m_nNoActivateNewWin == 1)
		CMainOption::s_dwMainExtendedStyle |= MAIN_EX_NOACTIVATE_NEWWIN;
	if (m_nOneInstance == 1) 
		CMainOption::s_dwMainExtendedStyle |= MAIN_EX_ONEINSTANCE;
	if (m_nLimit == 1)
		CMainOption::s_dwMainExtendedStyle |= MAIN_EX_WINDOWLIMIT;
	if (m_nNoCloseDFG == 1)
		CMainOption::s_dwMainExtendedStyle |= MAIN_EX_NOCLOSEDFG;
	if (m_nNoMDI == 1)
		CMainOption::s_dwMainExtendedStyle |= MAIN_EX_NOMDI;
	if (m_nBackUp == 1)
		CMainOption::s_dwMainExtendedStyle |= MAIN_EX_BACKUP;
	if (m_nAddFavoriteOldShell == 1)
		CMainOption::s_dwMainExtendedStyle |= MAIN_EX_ADDFAVORITEOLDSHELL;
	if (m_nOrgFavoriteOldShell == 1)
		CMainOption::s_dwMainExtendedStyle |= MAIN_EX_ORGFAVORITEOLDSHELL;
	if (m_nRegisterAsBrowser == 1) {
		CMainOption::s_dwMainExtendedStyle |= MAIN_EX_REGISTER_AS_BROWSER;
		MtlSendOnCommand(m_wnd, ID_REGISTER_AS_BROWSER);
	}
	else {
		MtlSendOffCommand(m_wnd, ID_REGISTER_AS_BROWSER);
	}

	if (m_nLoadGlobalOffline == 1)
		CMainOption::s_dwMainExtendedStyle |= MAIN_EX_LOADGLOBALOFFLINE;
	if (m_nKillDialog == 1)
		CMainOption::s_dwMainExtendedStyle |= MAIN_EX_KILLDIALOG;

	if (m_nInheritOptions == 1)
		CMainOption::s_dwMainExtendedStyle |= MAIN_EX_INHERIT_OPTIONS;

	// update max window count
	CMainOption::s_dwMaxWindowCount = m_nMaxWindowCount;
	CMainOption::s_dwBackUpTime = m_nBackUpTime;
	// UDT DGSTR ( dai
	m_nAutoRefreshTime = m_nAutoRefTimeMin*60 + m_nAutoRefTimeSec; 
	CMainOption::s_dwAutoRefreshTime = m_nAutoRefreshTime;
	// ENDE
	m_wnd.PostMessage(WM_COMMAND, ID_BACKUPOPTION_CHANGED);

	CIniSection pr;
	pr.Open(_szIniFileName, _T("Main"));
	m_lf.WriteProfile(pr);
	pr.Close();
}

void CMainPropertyPage::_SetData()
{
	m_nNewWindow = CMainOption::s_dwMainExtendedStyle & MAIN_EX_NEWWINDOW ? 1 : 0;
	m_nNoActivate = CMainOption::s_dwMainExtendedStyle & MAIN_EX_NOACTIVATE ? 1 : 0;
	m_nNoActivateNewWin = CMainOption::s_dwMainExtendedStyle & MAIN_EX_NOACTIVATE_NEWWIN ? 1 : 0;
	m_nOneInstance = CMainOption::s_dwMainExtendedStyle & MAIN_EX_ONEINSTANCE ? 1 : 0;
	m_nLimit = CMainOption::s_dwMainExtendedStyle & MAIN_EX_WINDOWLIMIT ? 1 : 0;
	m_nNoCloseDFG = CMainOption::s_dwMainExtendedStyle & MAIN_EX_NOCLOSEDFG ? 1 : 0;
	m_nNoMDI = CMainOption::s_dwMainExtendedStyle & MAIN_EX_NOMDI ? 1 : 0;
	m_nBackUp = CMainOption::s_dwMainExtendedStyle & MAIN_EX_BACKUP ? 1 : 0;
	m_nMaxWindowCount = CMainOption::s_dwMaxWindowCount;
	m_nBackUpTime = CMainOption::s_dwBackUpTime;
	// UDT DGSTR ( dai
	m_nAutoRefreshTime = CMainOption::s_dwAutoRefreshTime;
	m_nAutoRefTimeMin = CMainOption::s_dwAutoRefreshTime/60; 
	m_nAutoRefTimeSec = CMainOption::s_dwAutoRefreshTime%60;
	// ENDE
	m_nAddFavoriteOldShell = CMainOption::s_dwMainExtendedStyle & MAIN_EX_ADDFAVORITEOLDSHELL ? 1 : 0;
	m_nOrgFavoriteOldShell = CMainOption::s_dwMainExtendedStyle & MAIN_EX_ORGFAVORITEOLDSHELL ? 1 : 0;
	m_nLoadGlobalOffline = CMainOption::s_dwMainExtendedStyle & MAIN_EX_LOADGLOBALOFFLINE ? 1 : 0;
	m_nKillDialog = CMainOption::s_dwMainExtendedStyle & MAIN_EX_KILLDIALOG ? 1 : 0;
	m_nRegisterAsBrowser = CMainOption::s_dwMainExtendedStyle & MAIN_EX_REGISTER_AS_BROWSER ? 1 : 0;
	m_nInheritOptions = CMainOption::s_dwMainExtendedStyle & MAIN_EX_INHERIT_OPTIONS ? 1 : 0;

	// refresh our font
	NONCLIENTMETRICS info;
	info.cbSize = sizeof(info);
	::SystemParametersInfo(SPI_GETNONCLIENTMETRICS, sizeof(info), &info, 0);
	m_lf = info.lfMenuFont;

	CIniSection pr;
	pr.Open(_szIniFileName, _T("Main"));
	MTL::CLogFont lf;
	if (lf.GetProfile(pr))
		m_lf = lf;
	pr.Close();
}


////////////////////////////////////////////////////////////////////////////////
//CMainPropertyPage2�̒�`
////////////////////////////////////////////////////////////////////////////////

int CALLBACK CMainPropertyPage2::BrowseCallbackProc(HWND hwnd,UINT uMsg,LPARAM lParam,LPARAM lpData)
{
	if(uMsg == BFFM_INITIALIZED)
	{
		if(lpData)
			SendMessage(hwnd, BFFM_SETSELECTION, TRUE, lpData);
	}
	return 0;
}

CString CMainPropertyPage2::BrowseForFolder(CString strTitle, CString strNowPath)
{
	TCHAR pszDisplayName[MAX_PATH];

	BROWSEINFO bi = { m_hWnd, NULL, pszDisplayName, strTitle.GetBuffer(0),
		BIF_RETURNONLYFSDIRS, &BrowseCallbackProc, (LPARAM)strNowPath.GetBuffer(0), 0 };
 
	CItemIDList idl;
	idl.Attach(::SHBrowseForFolder(&bi));
	return idl.GetPath();
}


// Constructor
CMainPropertyPage2::CMainPropertyPage2(HWND hWnd) : m_wnd(hWnd)
{
	m_bInit = FALSE;

	m_nSzPain1 = 150;
	m_nSzPain2 = 150;
	m_nChkSwapPain = FALSE;

	m_nShowMenu = FALSE;
	m_nShowToolBar = FALSE;
	m_nShowAdress = FALSE;
	m_nShowTab = FALSE;
	m_nShowLink = FALSE;
	m_nShowSearch = FALSE;
	m_nShowStatus = FALSE;

	m_nMRUCount = 9;
	m_nMRUCountMin = 2; m_nMRUCountMax = 64;
	m_nMRUMenuType = 0;
	_SetData();
}

// Overrides
BOOL CMainPropertyPage2::OnSetActive()
{
	if(!m_bInit){
		m_bInit = TRUE;
		InitCtrls();
	}
	SetModified(TRUE);
	return DoDataExchange(FALSE);
}

BOOL CMainPropertyPage2::OnKillActive()
{
	return DoDataExchange(TRUE);
}

BOOL CMainPropertyPage2::OnApply()
{
	if (DoDataExchange(TRUE)) {
		_GetData();
		return TRUE;
	}
	else 
		return FALSE;
}

void CMainPropertyPage2::_GetData()
{

	CIniSection pr;
	pr.Open(_szIniFileName, _T("StatusBar"));
	pr.SetValue(MAKELONG(m_nSzPain1, m_nSzPain2), _T("SizePain"));
	pr.SetValue(m_nChkSwapPain, _T("SwapPain"));
	pr.Close();

	pr.Open(_szIniFileName, _T("FullScreen"));
	pr.SetValue(m_nShowMenu, _T("ShowMenu"));
	pr.SetValue(m_nShowToolBar, _T("ShowToolBar"));
	pr.SetValue(m_nShowAdress, _T("ShowAdress"));
	pr.SetValue(m_nShowTab, _T("ShowTab"));
	pr.SetValue(m_nShowLink, _T("ShowLink"));
	pr.SetValue(m_nShowSearch, _T("ShowSearch"));
	pr.SetValue(m_nShowStatus, _T("ShowStatus"));
	pr.Close();

	CMainOption::s_bTravelLogGroup = m_nTravelLogGroup ? true : false;
	CMainOption::s_bTravelLogClose = m_nTravelLogClose ? true : false;

	CMainOption::s_pMru->ResetMenu();
	CMainOption::s_pMru->SetMaxEntries(m_nMRUCount);
	CMainOption::s_pMru->SetMenuType(m_nMRUMenuType);
	CMainOption::s_pMru->UpdateMenu();
}

void CMainPropertyPage2::_SetData()
{
	// UH
	m_nDelCash = CMainOption::s_dwMainExtendedStyle2 & MAIN_EX2_DEL_CASH ? 1:0;
	m_nDelCookie = CMainOption::s_dwMainExtendedStyle2 & MAIN_EX2_DEL_COOKIE ? 1:0;
	m_nDelHistory = CMainOption::s_dwMainExtendedStyle2 & MAIN_EX2_DEL_HISTORY ? 1:0;
	m_nMakeCash = CMainOption::s_dwMainExtendedStyle2 & MAIN_EX2_MAKECASH ? 1:0;
	
	DWORD dwVal=0;
	CIniSection pr;
	pr.Open(_szIniFileName, _T("StatusBar"));
	if (pr.QueryValue(dwVal, _T("SizePain"))==ERROR_SUCCESS)
	{
		m_nSzPain1 = LOWORD(dwVal);
		m_nSzPain2 = HIWORD(dwVal);
	}
	if (pr.QueryValue(dwVal, _T("SwapPain"))==ERROR_SUCCESS)
		m_nChkSwapPain = dwVal;
	pr.Close();

	pr.Open(_szIniFileName, _T("FullScreen"));
	if (pr.QueryValue(dwVal, _T("ShowMenu"))==ERROR_SUCCESS)
		m_nShowMenu = dwVal;
	if (pr.QueryValue(dwVal, _T("ShowToolBar"))==ERROR_SUCCESS)
		m_nShowToolBar = dwVal;
	if (pr.QueryValue(dwVal, _T("ShowAdress"))==ERROR_SUCCESS)
		m_nShowAdress = dwVal;
	if (pr.QueryValue(dwVal, _T("ShowTab"))==ERROR_SUCCESS)
		m_nShowTab = dwVal;
	if (pr.QueryValue(dwVal, _T("ShowLink"))==ERROR_SUCCESS)
		m_nShowLink = dwVal;
	if (pr.QueryValue(dwVal, _T("ShowSearch"))==ERROR_SUCCESS)
		m_nShowSearch = dwVal;
	if (pr.QueryValue(dwVal, _T("ShowStatus"))==ERROR_SUCCESS)
		m_nShowStatus = dwVal;
	pr.Close();

	m_nTravelLogGroup = CMainOption::s_bTravelLogGroup ? 1 : 0;
	m_nTravelLogClose = CMainOption::s_bTravelLogClose ? 1 : 0;

	m_nMRUCountMin = CMainOption::s_pMru->m_nMaxEntries_Min;
	m_nMRUCountMax = CMainOption::s_pMru->m_nMaxEntries_Max;
	m_nMRUCount = CMainOption::s_pMru->GetMaxEntries();
	m_nMRUMenuType = CMainOption::s_pMru->GetMenuType();
}

void CMainPropertyPage2::InitCtrls()
{
	CString strText; strText.Format("(%d-%d)",m_nMRUCountMin,m_nMRUCountMax);
	MtlSetWindowText(GetDlgItem(IDC_STATIC_MRU_MINMAX),strText);

	CComboBox cmbType(GetDlgItem(IDC_COMBO_MRU_MENUTYPE));
	cmbType.AddString(_T("0 - URL"));
	cmbType.AddString(_T("1 - �^�C�g��"));
	cmbType.AddString(_T("2 - �^�C�g�� - URL"));
	cmbType.SetCurSel(0);
}
