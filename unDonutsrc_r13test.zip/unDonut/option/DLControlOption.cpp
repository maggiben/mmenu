#include "stdafx.h"
#include "DLControlOption.h"
#include "../MtlPrivateProfile.h"

using namespace MTL;

void CDLControlOption::GetProfile()
{
	CIniSection pr;

	pr.Open(_szIniFileName, _T("Browser"));
	if (pr.QueryValue(s_dwDLControlFlags, _T("DLControl_Flags")) != ERROR_SUCCESS)
		s_dwDLControlFlags = DLCTL_DEFAULT;

	// UDT DGSTR
	DWORD dwCount = MAX_PATH;
	if (pr.QueryValue(s_szUserAgent, _T("UserAgent"), &dwCount) != ERROR_SUCCESS)
		::lstrcpy(s_szUserAgent, _T(""));
	// ENDE

	// UDT DGSTR ( dai
	DWORD dwFlatScrBar = 0;
	pr.QueryValue(dwFlatScrBar, _T("FlatScrBar"));
	_bFlatScrBar = (dwFlatScrBar == 1) ? true : false;
	//ENDE

	// UH
	pr.QueryValue(_dwViewStyle, _T("ViewStyle"));

	pr.Close();
}

void CDLControlOption::WriteProfile()
{
	CIniSection pr;

	pr.Open(_szIniFileName, _T("Browser"));
	pr.SetValue(s_dwDLControlFlags, _T("DLControl_Flags"));
	pr.SetValue(s_szUserAgent, _T("UserAgent")); // UDT DGSTR
	//pr.SetValue(_bMozilla ? 1 : 0, _T("Mozilla"));

	// UDT DGSTR ( dai
	pr.SetValue(_bFlatScrBar ? 1 : 0, _T("FlatScrBar"));
	
	// UH
	pr.SetValue(_dwViewStyle, _T("ViewStyle"));

	pr.Close();
}

DWORD CDLControlOption::s_dwDLControlFlags = 0;


/////////////////////////////////////////////////////////////////////////////
// CDLControlPropertyPage


// Constructor
CDLControlPropertyPage::CDLControlPropertyPage(HWND hMainWnd)
{
	m_hMainWnd = hMainWnd;
	_SetData();
}

// Overrides
BOOL CDLControlPropertyPage::OnSetActive()
{
	SetModified(TRUE);

	// UDT DGSTR
	if (m_edit.m_hWnd == NULL)
		m_edit.Attach(GetDlgItem(IDC_EDIT_USER_AGENT));
	// ENDE

	return DoDataExchange(FALSE);
}

BOOL CDLControlPropertyPage::OnKillActive()
{
	return DoDataExchange(TRUE);
}

BOOL CDLControlPropertyPage::OnApply()
{
	if (DoDataExchange(TRUE)) {
		_GetData();
		return TRUE;
	}
	else 
		return FALSE;
}

void CDLControlPropertyPage::_GetData()
{
	// update dl control flags
	CDLControlOption::s_dwDLControlFlags = 0;

	if (m_nBGSounds == 1)
		CDLControlOption::s_dwDLControlFlags |= DLCTL_BGSOUNDS;
	if (m_nVideos == 1)
		CDLControlOption::s_dwDLControlFlags |= DLCTL_VIDEOS;
	if (m_nDLImages == 1)
		CDLControlOption::s_dwDLControlFlags |= DLCTL_DLIMAGES;

	if (m_nRunActiveXCtls == 0)
		CDLControlOption::s_dwDLControlFlags |= DLCTL_NO_RUNACTIVEXCTLS;
	if (m_nDLActiveXCtls == 0)
		CDLControlOption::s_dwDLControlFlags |= DLCTL_NO_DLACTIVEXCTLS;
	if (m_nScripts == 0)
		CDLControlOption::s_dwDLControlFlags |= DLCTL_NO_SCRIPTS;
	if (m_nJava == 0)
		CDLControlOption::s_dwDLControlFlags |= DLCTL_NO_JAVA;

	//if (m_nMozilla == 1)
	//	_bMozilla = true;
	//else
	//	_bMozilla = false;


	// UDT DGSTR ( dai
	if (m_nFlatScrBar == 1)
		_bFlatScrBar = true;
	else
		_bFlatScrBar = false;
	// ENDE

	// UH
	_dwViewStyle = 0;
	if (m_nNaviLock==1)		_dwViewStyle |= DVS_EX_OPENNEWWIN;
	if (m_bMsgFilter==1)	_dwViewStyle |= DVS_EX_MESSAGE_FILTER;
	if (m_bMouseGesture==1)	_dwViewStyle |= DVS_EX_MOUSE_GESTURE;
	if (m_bBlockMailto==1)	_dwViewStyle |= DVS_EX_BLOCK_MAILTO;

	SendMessage(m_hMainWnd, WM_COMMAND, ID_RESIZED, 0);
	m_edit.GetWindowText(CDLControlOption::s_szUserAgent, MAX_PATH); // UDT DGSTR
}

void CDLControlPropertyPage::_SetData()
{
	m_nBGSounds = CDLControlOption::s_dwDLControlFlags & DLCTL_BGSOUNDS ? 1 : 0;
	m_nVideos = CDLControlOption::s_dwDLControlFlags & DLCTL_VIDEOS ? 1 : 0;
	m_nDLImages = CDLControlOption::s_dwDLControlFlags & DLCTL_DLIMAGES ? 1 : 0;

	m_nRunActiveXCtls = CDLControlOption::s_dwDLControlFlags & DLCTL_NO_RUNACTIVEXCTLS ? 0 : 1;
	m_nDLActiveXCtls = CDLControlOption::s_dwDLControlFlags & DLCTL_NO_DLACTIVEXCTLS ? 0 : 1;
	m_nScripts = CDLControlOption::s_dwDLControlFlags & DLCTL_NO_SCRIPTS ? 0 : 1;
	m_nJava = CDLControlOption::s_dwDLControlFlags & DLCTL_NO_JAVA ? 0 : 1;

	//m_nMozilla = _bMozilla ? 1 : 0;

	// UDT DGSTR ( dai
	m_nFlatScrBar = _bFlatScrBar? 1:0;

	// UH
	m_nNaviLock = (_dwViewStyle&DVS_EX_OPENNEWWIN)? 1:0;
	m_bMsgFilter = (_dwViewStyle&DVS_EX_MESSAGE_FILTER)? 1:0;
	m_bMouseGesture = (_dwViewStyle&DVS_EX_MOUSE_GESTURE)? 1:0;
	m_bBlockMailto = (_dwViewStyle&DVS_EX_BLOCK_MAILTO)? 1:0;

	// UDT DGSTR
	if ( lstrlen(CDLControlOption::s_szUserAgent) != 0 )
		m_strUserAgent = CDLControlOption::s_szUserAgent;
	else
	{
		TCHAR szDefUserAgent[MAX_PATH];
		DWORD size = MAX_PATH;
		::ObtainUserAgentString( 0 , szDefUserAgent ,&size);
		// NOTE: Here , the other way.
		/*
		DWORD nUnused;
		::UrlMkGetSessionOption(URLMON_OPTION_USERAGENT , (void *)szDefUserAgent , 
				lstrlen(szDefUserAgent) , &nUnused , 0);
		*/
		m_strUserAgent = szDefUserAgent;
	}
	// ENDE
}

