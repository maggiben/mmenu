#include "stdafx.h"
#include "DonutConfirmOption.h"
#include "../MtlPrivateProfile.h"


////////////////////////////////////////////////////////////////////////////////
//CDonutConfirmOption�̒�`
////////////////////////////////////////////////////////////////////////////////

//static�ϐ��̒�`
DWORD CDonutConfirmOption::s_dwFlags = DONUT_CONFIRM_CLOSEALLEXCEPT;
BOOL CDonutConfirmOption::s_bStopScript = TRUE;

//�����o�֐�
void CDonutConfirmOption::GetProfile()
{
	CIniSection pr;
	pr.Open(_szIniFileName, _T("Confirmation"));
	pr.QueryValue(s_dwFlags, _T("Confirmation_Flags"));
	pr.QueryValue((DWORD&)s_bStopScript,_T("Script"));
	pr.Close();
}

void CDonutConfirmOption::WriteProfile()
{
	CIniSection pr;
	pr.Open(_szIniFileName, _T("Confirmation"));
	pr.SetValue(s_dwFlags, _T("Confirmation_Flags"));
	pr.SetValue(s_bStopScript,_T("Script"));
	pr.Close();
}

bool CDonutConfirmOption::OnDonutExit(HWND hWnd)
{
	if (_SearchDownloadingDialog()) {
		if (IDYES == ::MessageBox(hWnd, _T("�_�E�����[�h���̃t�@�C��������܂����ADonut���I�����Ă���낵���ł����H"),
			_T("�m�F�_�C�A���O"), MB_YESNO|MB_ICONQUESTION))
			return true;
		else
			return false;
	}

	if (!_check_flag(DONUT_CONFIRM_EXIT, s_dwFlags))
		return true;

	// Note. On debug mode, If DONUT_CONFIRM_EXIT set, the process would be killed
	//       before Module::Run returns. What can I do?
	if (IDYES == ::MessageBox(hWnd, _T("Donut���I�����Ă���낵���ł����H"),
		_T("�m�F�_�C�A���O"), MB_YESNO|MB_ICONQUESTION)) {
		return true;
	}

	return false;
}

bool CDonutConfirmOption::OnCloseAll(HWND hWnd)
{
	if (!_check_flag(DONUT_CONFIRM_CLOSEALL, s_dwFlags))
		return true;

	if (IDYES == ::MessageBox(hWnd, _T("�E�B���h�E�����ׂĕ��Ă���낵���ł����H"),
		_T("�m�F�_�C�A���O"), MB_YESNO|MB_ICONQUESTION))
		return true;

	return false;
}

bool CDonutConfirmOption::OnCloseAllExcept(HWND hWnd)
{
	if (!_check_flag(DONUT_CONFIRM_CLOSEALLEXCEPT, s_dwFlags))
		return true;

	if (IDYES == ::MessageBox(hWnd, _T("����ȊO�̃E�B���h�E�����ׂĕ��Ă���낵���ł����H"),
		_T("�m�F�_�C�A���O"), MB_YESNO|MB_ICONQUESTION))
		return true;

	return false;
}

bool CDonutConfirmOption::_SearchDownloadingDialog()
{
	_Function_Searcher f;

	f = MtlForEachTopLevelWindow(_T("#32770"), NULL, f);

	return f._bFound;
}

BOOL CDonutConfirmOption::WhetherConfirmScript()
{
	if(s_bStopScript) return TRUE;
	return FALSE;
}



////////////////////////////////////////////////////////////////////////////////
//CDonutConfirmPropertyPage�̒�`
////////////////////////////////////////////////////////////////////////////////

//�R���X�g���N�^
CDonutConfirmPropertyPage::CDonutConfirmPropertyPage()
{
	_SetData();
}

//�v���p�e�B�y�[�W�̃I�[�o�[���C�h�֐�
BOOL CDonutConfirmPropertyPage::OnSetActive()
{
	SetModified(TRUE);
	return DoDataExchange(FALSE);
}

BOOL CDonutConfirmPropertyPage::OnKillActive()
{
	return DoDataExchange(TRUE);
}

BOOL CDonutConfirmPropertyPage::OnApply()
{
	if (DoDataExchange(TRUE)) {
		_GetData();
		return TRUE;
	}
	else 
		return FALSE;
}

//�����֐�
void CDonutConfirmPropertyPage::_GetData()
{
	DWORD dwFlags = 0;
	if (m_nExit == 1)
		dwFlags |= DONUT_CONFIRM_EXIT;
	if (m_nCloseAll == 1)
		dwFlags |= DONUT_CONFIRM_CLOSEALL;
	if (m_nCloseAllExcept == 1)
		dwFlags |= DONUT_CONFIRM_CLOSEALLEXCEPT;

	CDonutConfirmOption::s_bStopScript = (m_nStopScript == 1);
	CDonutConfirmOption::s_dwFlags = dwFlags;
}

void CDonutConfirmPropertyPage::_SetData()
{
	DWORD dwFlags = CDonutConfirmOption::s_dwFlags;
	m_nExit = _check_flag(DONUT_CONFIRM_EXIT, dwFlags) ? 1 : 0;
	m_nCloseAll = _check_flag(DONUT_CONFIRM_CLOSEALL, dwFlags) ? 1 : 0;
	m_nCloseAllExcept = _check_flag(DONUT_CONFIRM_CLOSEALLEXCEPT, dwFlags) ? 1 : 0;
	m_nStopScript = CDonutConfirmOption::s_bStopScript ? 1 : 0;
}
