#include "stdafx.h"
#include "FileNewOption.h"
#include "../MtlPrivateProfile.h"

using namespace MTL;

////////////////////////////////////////////////////////////////////////////////
//CFileNewOption�̒�`
////////////////////////////////////////////////////////////////////////////////

DWORD CFileNewOption::s_dwFlags = FILENEW_BLANK;

void CFileNewOption::GetProfile()
{
	CIniSection pr;

	pr.Open(_szIniFileName, _T("Main"));
	pr.QueryValue(s_dwFlags, _T("File_New_Option"));
	pr.Close();
}

void CFileNewOption::WriteProfile()
{
	CIniSection pr;

	pr.Open(_szIniFileName, _T("Main"));
	pr.SetValue(s_dwFlags, _T("File_New_Option"));
	pr.Close();
}


////////////////////////////////////////////////////////////////////////////////
//CFileNewPropertyPage�̒�`
////////////////////////////////////////////////////////////////////////////////

// Constructor
CFileNewPropertyPage::CFileNewPropertyPage()
{
	_SetData();
}

// Overrides
BOOL CFileNewPropertyPage::OnSetActive()
{
	SetModified(TRUE);
	return DoDataExchange(FALSE);
}

BOOL CFileNewPropertyPage::OnKillActive()
{
	return DoDataExchange(TRUE);
}

BOOL CFileNewPropertyPage::OnApply()
{
	if (DoDataExchange(TRUE)) {
		_GetData();
		return TRUE;
	}
	else 
		return FALSE;
}

// Implementation
void CFileNewPropertyPage::_GetData()
{
	// update dl control flags
	CFileNewOption::s_dwFlags = 0;

	switch (m_nRadio) {
	case 0:
		CFileNewOption::s_dwFlags = FILENEW_BLANK;
		break;
	case 1:
		CFileNewOption::s_dwFlags = FILENEW_COPY;
		break;
	case 2:
		CFileNewOption::s_dwFlags = FILENEW_HOME;
		break;
	default:
		ATLASSERT(FALSE);
		break;
	}
}

void CFileNewPropertyPage::_SetData()
{
	if (CFileNewOption::s_dwFlags == FILENEW_BLANK)
		m_nRadio = 0;
	else if (CFileNewOption::s_dwFlags == FILENEW_COPY)
		m_nRadio = 1;
	else if (CFileNewOption::s_dwFlags == FILENEW_HOME)
		m_nRadio = 2;
	else
		ATLASSERT(FALSE);
//		m_nRadio = CFileNewOption::s_dwFlags & FILENEW_BLANK ? TRUE : FALSE;
//		m_bCopy = CFileNewOption::s_dwFlags & FILENEW_COPY ? TRUE : FALSE;
//		m_bHome = CFileNewOption::s_dwFlags & FILENEW_HOME ? TRUE : FALSE;
}
