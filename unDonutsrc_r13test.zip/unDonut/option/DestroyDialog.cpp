#include "stdafx.h"
#include "DestroyDialog.h"
#include "MainOption.h"

CDestroyPropertyPage::CDestroyPropertyPage()
{
	_SetData();
}

// Overrides
BOOL CDestroyPropertyPage::OnSetActive()
{
	SetModified(TRUE);
	return DoDataExchange(FALSE);
}

BOOL CDestroyPropertyPage:: OnKillActive()
{
	return DoDataExchange(TRUE);
}

BOOL CDestroyPropertyPage::OnApply()
{
	if (DoDataExchange(TRUE)) {
		_GetData();
		return TRUE;
	}
	else 
		return FALSE;
}

void CDestroyPropertyPage::_GetData()
{
	// Update main style
	// UH
	CMainOption::s_dwMainExtendedStyle2 = 0;
	if (m_nDelCash == 1)
		CMainOption::s_dwMainExtendedStyle2 |= MAIN_EX2_DEL_CASH;
	if (m_nDelCookie == 1)
		CMainOption::s_dwMainExtendedStyle2 |= MAIN_EX2_DEL_COOKIE;
	if (m_nDelHistory == 1)
		CMainOption::s_dwMainExtendedStyle2 |= MAIN_EX2_DEL_HISTORY;
	if (m_nMakeCash == 1)
		CMainOption::s_dwMainExtendedStyle2 |= MAIN_EX2_MAKECASH;
	if (m_nDelRecentClose == 1)
		CMainOption::s_dwMainExtendedStyle2 |= MAIN_EX2_DEL_RECENTCLOSE;

}

void CDestroyPropertyPage::_SetData()
{
	// UH
	m_nDelCash = CMainOption::s_dwMainExtendedStyle2 & MAIN_EX2_DEL_CASH ? 1:0;
	m_nDelCookie = CMainOption::s_dwMainExtendedStyle2 & MAIN_EX2_DEL_COOKIE ? 1:0;
	m_nDelHistory = CMainOption::s_dwMainExtendedStyle2 & MAIN_EX2_DEL_HISTORY ? 1:0;
	m_nMakeCash = CMainOption::s_dwMainExtendedStyle2 & MAIN_EX2_MAKECASH ? 1:0;
	m_nDelRecentClose = CMainOption::s_dwMainExtendedStyle2 & MAIN_EX2_DEL_RECENTCLOSE ? 1:0;
}

