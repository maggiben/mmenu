#pragma once

#include "../resource.h"
#include "../DonutDefine.h"

// DL Control Flags
#define DLCTL_DEFAULT DLCTL_DLIMAGES | DLCTL_VIDEOS | DLCTL_BGSOUNDS

/////////////////////////////////////////////////////////////////////////////
// CDLControlOption

class CDLControlOption
{
public:
	static DWORD s_dwDLControlFlags;// default flags
	static TCHAR s_szUserAgent[MAX_PATH]; // UDT DGSTR

	static void GetProfile();
	static void WriteProfile();
};


/////////////////////////////////////////////////////////////////////////////
// CDLControlPropertyPage

class CDLControlPropertyPage : public CPropertyPageImpl<CDLControlPropertyPage>,
	public CWinDataExchange<CDLControlPropertyPage>
{
public:
// Constants
	enum { IDD = IDD_PROPPAGE_DLCONTROL };

// Data members
	int m_nBGSounds, m_nVideos, m_nDLImages;
	int m_nRunActiveXCtls, m_nDLActiveXCtls, m_nScripts, m_nJava;
	int m_nNaviLock;
	int m_nFlatScrBar;	// UDT DGSTR ( dai
	CString m_strUserAgent; // UDT DGSTR
	CEdit m_edit; // UDT DGSTR

	// UH
	HWND m_hMainWnd;
	BOOL m_bMsgFilter, m_bMouseGesture, m_bBlockMailto;

// DDX map
	BEGIN_DDX_MAP(CDLControlPropertyPage)
		DDX_CHECK(IDC_CHECK_DLCTL_BGSOUNDS, m_nBGSounds)
		DDX_CHECK(IDC_CHECK_DLCTL_VIDEOS, m_nVideos)
		DDX_CHECK(IDC_CHECK_DLCTL_DLIMAGES, m_nDLImages)
		DDX_CHECK(IDC_CHECK_DLCTL_RUNACTIVEXCTLS, m_nRunActiveXCtls)
		DDX_CHECK(IDC_CHECK_DLCTL_DLACTIVEXCTLS, m_nDLActiveXCtls)
		DDX_CHECK(IDC_CHECK_DLCTL_SCRIPTS, m_nScripts)
		DDX_CHECK(IDC_CHECK_DLCTL_JAVA, m_nJava)
		//DDX_CHECK(IDC_CHECK_MOZILLA, m_nMozilla)
		DDX_CHECK(IDC_CHECK_NAVILOCK, m_nNaviLock)
		DDX_CHECK(IDC_CHECK_SCROLLBAR, m_nFlatScrBar) // UDT DGSTR ( dai

		// UH
		DDX_CHECK(IDC_CHK_MSG_FILTER, m_bMsgFilter)
		DDX_CHECK(IDC_CHK_MOUSE_GESTURE, m_bMouseGesture)
		DDX_CHECK(IDC_CHK_BLOCK_MAILTO, m_bBlockMailto)
		
		DDX_TEXT_LEN(IDC_EDIT_USER_AGENT, m_strUserAgent, MAX_PATH) // UDT DGSTR
	END_DDX_MAP()

// Constructor
	CDLControlPropertyPage(HWND hMainWnd);

// Overrides
	BOOL OnSetActive();
	BOOL OnKillActive();
	BOOL OnApply();

// Message map and handlers
	BEGIN_MSG_MAP(CDLControlPropertyPage)
		CHAIN_MSG_MAP(CPropertyPageImpl<CDLControlPropertyPage>)
	END_MSG_MAP()

// Implementation
protected:
	void _GetData();
	void _SetData();
};
