#include "stdafx.h"
#include "ToolBarDialog.h"
#include "../MtlPrivateProfile.h"
#include "../DonutPFunc.h"

using namespace MTL;

extern UINT _uDropDownCommandID[];
extern UINT _uDropDownWholeCommandID[];
extern int _uDropDownCommandCount;
extern int _uDropDownWholeCommandCount;

CToolBarPropertyPage::CToolBarPropertyPage(HMENU hMenu,
	CSimpleArray<STD_TBBUTTON>* pAryStdBtn, BOOL *pbSkinChange)
{
	m_hMenu = hMenu;
	m_pAryStdBtnBase = pAryStdBtn;
	m_bExistSkin = FALSE;
	m_pbSkinChanged = pbSkinChange;

	// �R�s�[������(;^_^A �������
	//m_arrStdBtn.Copy(*pAryStdBtn);
	for (int ii=0; ii<pAryStdBtn->GetSize(); ii++)
		m_aryStdBtn.Add((*pAryStdBtn)[ii]);
}

// Overrides
BOOL CToolBarPropertyPage::OnSetActive()
{
	SetModified(TRUE);

	if (m_cmbCategory.m_hWnd == NULL)
		m_cmbCategory.Attach(GetDlgItem(IDC_CMB_CATEGORY));

	if (m_cmbCommand.m_hWnd == NULL)
		m_cmbCommand.Attach(GetDlgItem(IDC_CMB_COMMAND));

	if (m_ltIcon.m_hWnd == NULL)
		m_ltIcon.Attach(GetDlgItem(IDC_LIST_ICON));

	_SetData();
	return DoDataExchange(FALSE);
}

BOOL CToolBarPropertyPage::OnKillActive()
{
	return DoDataExchange(TRUE);
}

BOOL CToolBarPropertyPage::OnApply()
{
	if (DoDataExchange(TRUE)) {
		_GetData();
		return TRUE;
	}
	else 
		return FALSE;
}

// Constructor
// �f�[�^�𓾂�
void CToolBarPropertyPage::_SetData()
{
	// �R���{�{�b�N�̏�����
	InitialCombbox();
	// ���X�g�r���[�̏�����
	InitialListCtrl();
}

// �f�[�^��ۑ�
void CToolBarPropertyPage::_GetData()
{
	if(m_bExistSkin && m_pbSkinChanged){
		//vvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvv
		// �p�X
		CString strFile;
		strFile = CDonutToolBar::GetToolBarFilePath();

		CIniSection pr;

		//vvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvv
		// �c�[���o�[
		pr.Open(strFile, _T("TOOLBAR"));

		DWORD dwToolbarCnt = m_aryStdBtn.GetSize();
		pr.SetValue(dwToolbarCnt, _T("TOOLBAR_CNT"));

		for (int ii=0; ii<m_aryStdBtn.GetSize(); ii++)
		{
			CString strKeyID, strKeyStyle;
			strKeyID.Format("ID_%d", ii);
			strKeyStyle.Format("STYLE_%d", ii);
			
			pr.SetValue((DWORD)m_aryStdBtn[ii].idCommand, strKeyID);
			pr.SetValue((DWORD)m_aryStdBtn[ii].fsStyle, strKeyStyle);
		}
		pr.Close();
		//^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

		m_pAryStdBtnBase->RemoveAll();
		for (ii=0; ii<m_aryStdBtn.GetSize(); ii++)
			m_pAryStdBtnBase->Add(m_aryStdBtn[ii]);
	}

}

// �R���{�{�b�N�X�̏�����
void CToolBarPropertyPage::InitialCombbox()
{
	if (_SetCombboxCategory(m_cmbCategory, m_hMenu)==FALSE)
		return;

	m_cmbCategory.AddString(_T("�h���b�v�_�E���E�A�C�R��"));

	// ���z�I�ɁA�I��ύX
	OnSelChangeCate(0,0,0);
}

// �J�e�S���ύX��
void CToolBarPropertyPage::OnSelChangeCate(UINT code, int id, HWND hWnd)
{
	int nIndex = m_cmbCategory.GetCurSel();

	// �R�}���h�I��
	if ((nIndex+1)!=m_cmbCategory.GetCount())
		_PickUpCommand(m_hMenu, nIndex, m_cmbCommand);
	else
		PickUpCommandEx();
}

// �g���R�}���h
void CToolBarPropertyPage::PickUpCommandEx()
{
	m_cmbCommand.ResetContent();

	for (int ii=0; ii<_uDropDownCommandCount; ii++)
	{
		CString strMenu;
		strMenu.LoadString(_uDropDownCommandID[ii]);
		if (strMenu.Find("\n")!=-1)
			strMenu = strMenu.Left(strMenu.Find("\n"));

		int nIndex = m_cmbCommand.AddString(strMenu);
		m_cmbCommand.SetItemData(nIndex, _uDropDownCommandID[ii]);
	}
	for (ii=0; ii<_uDropDownWholeCommandCount; ii++)
	{
		CString strMenu;
		strMenu.LoadString(_uDropDownWholeCommandID[ii]);
		if (strMenu.Find("\n")!=-1)
			strMenu = strMenu.Left(strMenu.Find("\n"));

		int nIndex = m_cmbCommand.AddString(strMenu);
		m_cmbCommand.SetItemData(nIndex, _uDropDownWholeCommandID[ii]);
	}
}

CString CToolBarPropertyPage::GetBigFilePath()
{	
	CString strPath = _GetSkinDir();
	strPath += _T("BigHot.bmp");
	return strPath;
}

CString CToolBarPropertyPage::GetSmallFilePath()
{
	CString strPath = _GetSkinDir();
	strPath += _T("SmallHot.bmp");
	return strPath;
}

// ���X�g�r���[�̏�����
void CToolBarPropertyPage::InitialListCtrl()
{
	BOOL bBig = TRUE;

	if(m_pbSkinChanged && *m_pbSkinChanged || !m_pbSkinChanged){
		::MessageBox(m_hWnd,_T("�X�L�����ύX���ꂽ���߃c�[���o�[�̐ݒ肪�ł��Ȃ���Ԃł��B\n"
							   "��U���̃E�B���h�E����邱�ƂŐݒ�ł���悤�ɂȂ�܂��B"),_T("information"),MB_OK);
		DisableControls();
		m_pbSkinChanged = NULL;
		return;
	}

	if (m_ltIcon.m_hWnd==NULL) return;
	if (m_imgList.m_hImageList!=NULL) return;

	CBitmap bmp;
	bmp.Attach(AtlLoadBitmapImage(GetBigFilePath().GetBuffer(0), LR_LOADFROMFILE));
	if(bmp.m_hBitmap == NULL){
		bmp.Attach(AtlLoadBitmapImage(GetSmallFilePath().GetBuffer(0), LR_LOADFROMFILE));
		if(bmp.m_hBitmap == NULL){
			::MessageBox(m_hWnd,_T("�c�[���o�[�X�L���t�@�C����������܂���ł����B\n"
									"�J�X�^�}�C�Y�Ɏx�Ⴊ�o��̂ő��삪�ł��Ȃ��悤�ɂȂ��Ă��܂��B\n"
									"�X�L���t�H���_��BigHot.bmp�t�@�C�����������Ă��������B"),_T("information"),MB_OK);
			DisableControls();
			m_bExistSkin = FALSE;
			return;
		}
		bBig = FALSE;
	}

	CSize szImg;
	bmp.GetSize(szImg);
	int nCount = szImg.cx/szImg.cy;
	szImg.cx = szImg.cy;
	MTLVERIFY( m_imgList.Create(szImg.cx, szImg.cy, ILC_COLOR24 | ILC_MASK, nCount, 1) );
	MTLVERIFY( m_imgList.Add(bmp, RGB(255, 0, 255)) != -1 );

	int nFlag = (bBig) ? LVSIL_NORMAL : LVSIL_SMALL;
	m_ltIcon.SetImageList(m_imgList, nFlag);
	for (int ii=0; ii<m_aryStdBtn.GetSize(); ii++)
	{
		UINT nID = m_aryStdBtn[ii].idCommand;

		CString strCmd;
		CToolTipManager::LoadToolTipText(nID, strCmd);

		m_ltIcon.InsertItem(ii, strCmd, ii);
	}

	DisableButtons();
	m_bExistSkin = TRUE;
}

void CToolBarPropertyPage::DisableButtons()
{
	::EnableWindow(GetDlgItem(IDC_BTN01), FALSE);
	::EnableWindow(GetDlgItem(IDC_BTN02), FALSE);
	::EnableWindow(GetDlgItem(IDC_BTN03), FALSE);
	::EnableWindow(GetDlgItem(IDC_BTN04), FALSE);
	::EnableWindow(GetDlgItem(IDC_BTN05), FALSE);
}

void CToolBarPropertyPage::DisableControls()
{
	DisableButtons();
	m_cmbCategory.EnableWindow(FALSE);
	m_cmbCommand.EnableWindow(FALSE);
	m_ltIcon.EnableWindow(FALSE);
	::EnableWindow(GetDlgItem(IDC_CHKBTN_TXT),FALSE);
}

LRESULT CToolBarPropertyPage::OnChkBtnText(WORD /*wNotifyCode*/, WORD wID, HWND /*hWndCtl*/, BOOL& /*bHandled*/)
{
	DoDataExchange(TRUE);

	int nIndexLt = m_ltIcon.GetSelectedIndex();
	if (nIndexLt==-1) return 0;

	int nChk = ::SendMessage(GetDlgItem(IDC_CHKBTN_TXT), BM_GETCHECK, 0L, 0L);
	if (nChk == BST_CHECKED)
		m_aryStdBtn[nIndexLt].fsStyle |= BTNS_STD_LIST;
	else
		m_aryStdBtn[nIndexLt].fsStyle &= ~BTNS_STD_LIST;

	return 0;
}

LRESULT CToolBarPropertyPage::OnItemChgIcon(LPNMHDR pnmh)
{
	LPNMLISTVIEW pnmv = (LPNMLISTVIEW)pnmh; 
	if (pnmv->uNewState!=LBN_SELCANCEL) return 0;

	BOOL bEnableAdd=FALSE, bEnableDel=FALSE, bEnableIns=FALSE;

	int nIndexCmd = m_cmbCommand.GetCurSel();
	bEnableAdd=bEnableIns=CanAddCommand();

	long nIndex = pnmv->iItem;
	bEnableDel=TRUE;

	::EnableWindow(GetDlgItem(IDC_BTN03), bEnableAdd);
	::EnableWindow(GetDlgItem(IDC_BTN04), bEnableDel);
	::EnableWindow(GetDlgItem(IDC_BTN05), bEnableIns);

	UINT nID = m_aryStdBtn[nIndex].idCommand;
	UINT nStyle = m_aryStdBtn[nIndex].fsStyle;
	
	if (m_aryStdBtn[nIndex].fsStyle & BTNS_STD_LIST)
		::SendMessage(GetDlgItem(IDC_CHKBTN_TXT), BM_SETCHECK, BST_CHECKED, 0L);
	else
		::SendMessage(GetDlgItem(IDC_CHKBTN_TXT), BM_SETCHECK, BST_UNCHECKED, 0L);

	return 0;
}

void CToolBarPropertyPage::EnableMove(int nIndex)
{
	BOOL bEnableL=FALSE, bEnableR=FALSE;
	if (m_aryStdBtn.GetSize()<2)
	{
		bEnableL=FALSE;
		bEnableR=FALSE;
	}
	else if (nIndex==0)
	{
		bEnableL=FALSE;
		bEnableR=TRUE;
	}
	else if ((nIndex+1)==m_aryStdBtn.GetSize())
	{
		bEnableL=TRUE;
		bEnableR=FALSE;
	}
	else
	{
		bEnableL=TRUE;
		bEnableR=TRUE;
	}

	::EnableWindow(GetDlgItem(IDC_BTN01), bEnableL);
	::EnableWindow(GetDlgItem(IDC_BTN02), bEnableR);
}

// �R�}���h�ύX��
void CToolBarPropertyPage::OnSelChangeCmd(UINT code, int id, HWND hWnd)
{
	::EnableWindow(GetDlgItem(IDC_BTN03), CanAddCommand());

	int nIndexLt = m_ltIcon.GetSelectedIndex();
	if (nIndexLt!=-1)
		::EnableWindow(GetDlgItem(IDC_BTN05), CanAddCommand());
	else
		::EnableWindow(GetDlgItem(IDC_BTN05), FALSE);
}

// �ǉ��ł���H�H
BOOL CToolBarPropertyPage::CanAddCommand()
{
	int nIndex = m_cmbCommand.GetCurSel();
	if (nIndex==-1) return FALSE;

	UINT nTarID = m_cmbCommand.GetItemData(nIndex);
	if (nTarID==0) return FALSE;

	for (int ii=0; ii<m_aryStdBtn.GetSize(); ii++)
	{
		UINT nID = m_aryStdBtn[ii].idCommand;
		if (nID==nTarID) return FALSE;
	}

	return TRUE;
}

void CToolBarPropertyPage::OnBtnIns(UINT /*wNotifyCode*/, int /*wID*/, HWND /*hWndCtl*/)
{
	int nIndexLt = m_ltIcon.GetSelectedIndex();
	if (nIndexLt==-1) return;

	int nIndexCmb = m_cmbCommand.GetCurSel();
	if (nIndexCmb==-1) return;

	UINT nTarID = m_cmbCommand.GetItemData(nIndexCmb);
	if (nTarID==0) return;

	CString strCmd;
	CToolTipManager::LoadToolTipText(nTarID, strCmd);

	int nLtCnt = m_ltIcon.GetItemCount();
	m_ltIcon.InsertItem(nLtCnt, strCmd, nLtCnt);
	for (int ii=nLtCnt; ii>nIndexLt; ii--)
	{
		char cBuff[MAX_PATH];
		memset(cBuff, 0, sizeof(cBuff));
		m_ltIcon.GetItemText(ii-1, 0, cBuff, MAX_PATH);
		CString strText(cBuff);

		m_ltIcon.SetItemText(ii, 0, strText);
	}
	m_ltIcon.SetItemText(nIndexLt, 0, strCmd);


	STD_TBBUTTON stdBtn;
	stdBtn.idCommand = nTarID;
	stdBtn.fsStyle = GetToolButtonStyle(nTarID);

	int nAryCnt = m_aryStdBtn.GetSize();
	m_aryStdBtn.Add(stdBtn);
	for (ii=nLtCnt; ii>nIndexLt; ii--)
		m_aryStdBtn[ii] = m_aryStdBtn[ii-1];
	m_aryStdBtn[nIndexLt] = stdBtn;

	m_cmbCommand.SetCurSel(nIndexCmb+1);
	::EnableWindow(GetDlgItem(IDC_BTN03), CanAddCommand());
	::EnableWindow(GetDlgItem(IDC_BTN05), CanAddCommand());
	EnableMove(nIndexLt);
}

void CToolBarPropertyPage::OnBtnDel(UINT /*wNotifyCode*/, int /*wID*/, HWND /*hWndCtl*/)
{
	int nIndex = m_ltIcon.GetSelectedIndex();
	if (nIndex==-1) return;

	m_aryStdBtn.RemoveAt(nIndex);

	for (int ii=nIndex; ii<(m_ltIcon.GetItemCount()-1); ii++)
	{
		char cBuff[MAX_PATH];
		memset(cBuff, 0, sizeof(cBuff));
		m_ltIcon.GetItemText(ii+1, 0, cBuff, MAX_PATH);
		CString strText(cBuff);

		m_ltIcon.SetItemText(ii, 0, strText);
	}
	m_ltIcon.DeleteItem(ii);
	EnableMove(nIndex);
}

void CToolBarPropertyPage::OnBtnAdd(UINT /*wNotifyCode*/, int /*wID*/, HWND /*hWndCtl*/)
{
	int nIndex = m_cmbCommand.GetCurSel();
	if (nIndex==-1) return;

	UINT nTarID = m_cmbCommand.GetItemData(nIndex);
	if (nTarID==0) return;

	STD_TBBUTTON stdBtn;
	stdBtn.idCommand = nTarID;
	stdBtn.fsStyle = GetToolButtonStyle(nTarID);

	CString strCmd;
	CToolTipManager::LoadToolTipText(nTarID, strCmd);

	int nLtCnt = m_ltIcon.GetItemCount();
	nLtCnt = m_ltIcon.InsertItem(nLtCnt, strCmd, nLtCnt);

	// Redraw�����Ȃ��ƁA�X�N���[���o�[�̗̈悪�����Ȃ�
	m_ltIcon.RedrawWindow();

	int nMinPos=999, nMaxPos=-999, nCurPos=0;
	::GetScrollRange(m_ltIcon.m_hWnd, WS_HSCROLL, &nMinPos, &nMaxPos);
	nCurPos=::GetScrollPos(m_ltIcon.m_hWnd, WS_HSCROLL);
	m_ltIcon.Scroll(CSize(nMaxPos-nCurPos, 0));

	m_aryStdBtn.Add(stdBtn);
	m_cmbCommand.SetCurSel(nIndex+1);
	::EnableWindow(GetDlgItem(IDC_BTN03), CanAddCommand());
	::EnableWindow(GetDlgItem(IDC_BTN05), CanAddCommand());
}

DWORD CToolBarPropertyPage::GetToolButtonStyle(UINT nTarID)
{
	for (int ii=0; ii<_uDropDownCommandCount; ii++)
	{
		if (nTarID == _uDropDownCommandID[ii])
			return BTNS_BUTTON|BTNS_DROPDOWN;
	}
	for (ii=0; ii<_uDropDownWholeCommandCount; ii++)
	{
		if (nTarID == _uDropDownWholeCommandID[ii])
		{
			if (nTarID == ID_FAVORITES_DROPDOWN)
				return BTNS_BUTTON|BTNS_STD_LIST|BTNS_DROPDOWN|BTNS_WHOLEDROPDOWN;
			else
				return BTNS_BUTTON|BTNS_DROPDOWN|BTNS_WHOLEDROPDOWN;
		}
	}

	return BTNS_BUTTON;
}

void CToolBarPropertyPage::OnBtnMove(UINT /*wNotifyCode*/, int wID, HWND /*hWndCtl*/)
{
	int nIndex = m_ltIcon.GetSelectedIndex();
	if (nIndex==-1) return;

	int nAdd = 1;
	if (wID==IDC_BTN01)
		nAdd = -1;

	char cBuff[MAX_PATH];
	memset(cBuff, 0, sizeof(cBuff));
	m_ltIcon.GetItemText(nIndex, 0, cBuff, MAX_PATH);
	CString strTextNow(cBuff);

	memset(cBuff, 0, sizeof(cBuff));
	m_ltIcon.GetItemText(nIndex+nAdd, 0, cBuff, MAX_PATH);
	CString strTextTar(cBuff);

	m_ltIcon.SetItemText(nIndex, 0, strTextTar);
	m_ltIcon.SetItemText(nIndex+nAdd, 0, strTextNow);

	STD_TBBUTTON stdBtn = m_aryStdBtn[nIndex];
	STD_TBBUTTON stdBtnTar = m_aryStdBtn[nIndex+nAdd];

	m_aryStdBtn.SetAtIndex(nIndex, stdBtnTar);
	m_aryStdBtn.SetAtIndex(nIndex+nAdd, stdBtn);

	m_ltIcon.SelectItem(nIndex+nAdd);
	EnableMove(nIndex+nAdd);
}
