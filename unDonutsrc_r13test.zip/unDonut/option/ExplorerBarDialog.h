#pragma once

#include "../resource.h"

#define MAIN_EXPLORER_HSCROLL		0x00000001L
#define MAIN_EXPLORER_NOSPACE		0x00000002L
#define MAIN_EXPLORER_FAV_ORGIMG	0x00000008L

class CExplorerPropertyPage : public CPropertyPageImpl<CExplorerPropertyPage>,
	public CWinDataExchange<CExplorerPropertyPage>
{
public:
// Constants
	enum { IDD = IDD_PROPPAGE_EXPLORERBAR };

// Data members
	int m_nExplorerHScroll, m_nExplorerNoSpace;
	int m_nExplorerOrgImage;
	CString m_strUserFolder;

// DDX map
	BEGIN_DDX_MAP(CExplorerPropertyPage2)
		DDX_CHECK(IDC_CHECK_EXP_HSCROLL, m_nExplorerHScroll)
		DDX_CHECK(IDC_CHECK_EXP_SPACE, m_nExplorerNoSpace)
		DDX_CHECK(IDC_CHECK_EXP_ORGIMAGE, m_nExplorerOrgImage)
		DDX_TEXT(IDC_EDIT_USER, m_strUserFolder)
	END_DDX_MAP()

// Constructor
	CExplorerPropertyPage();

// Overrides
	BOOL OnSetActive();
	BOOL OnKillActive();
	BOOL OnApply();

// Message map and handlers
	BEGIN_MSG_MAP(CExplorerPropertyPage)
		COMMAND_ID_HANDLER_EX(IDC_BUTTON_FOLDER, OnUserFolder)
		CHAIN_MSG_MAP(CPropertyPageImpl<CExplorerPropertyPage>)
	END_MSG_MAP()

	void OnUserFolder(UINT wNotifyCode, int wID, HWND hWndCtl);

	CString _BrowseForFolder();

// Implementation
protected:
	void _GetData();
	void _SetData();
};