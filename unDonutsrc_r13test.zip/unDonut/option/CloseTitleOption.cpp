#include "stdafx.h"
#include "CloseTitleOption.h"


#include "../MtlMisc.h"
#include "../DonutPFunc.h"
#include "../MtlPrivateProfile.h"

extern TCHAR _szIniFileName[MAX_PATH];

using namespace MTL;

////////////////////////////////////////////////////////////////////////////////
//CCloseTitlesOption�̒�`
////////////////////////////////////////////////////////////////////////////////

//�X�^�e�B�b�N�ϐ��̒�`
CCloseTitlesOption::CStringList* CCloseTitlesOption::s_pCloseTitles = NULL;
bool CCloseTitlesOption::s_bValid = true;

void CCloseTitlesOption::GetProfile()
{
	CIniSection pr;
	pr.Open(_szIniFileName, _T("CloseTitles"));

	s_pCloseTitles = new CStringList;
	FileReadString(_GetFilePath(_T("CloseTitle.ini")), s_pCloseTitles);
	
	DWORD dwValid;
	LONG lRet = pr.QueryValue(dwValid, _T("IsValid"));
	if (lRet == ERROR_SUCCESS)
		s_bValid = (dwValid == 1);
}

void CCloseTitlesOption::WriteProfile()
{
	CIniSection pr;

	MtlIniDeleteSection(_szIniFileName, _T("CloseTitles"));// clean up
	pr.Open(_szIniFileName, _T("CloseTitles"));
	pr.SetValue(s_bValid == true ? 1 : 0, _T("IsValid"));

	FileWriteString(_GetFilePath(_T("CloseTitle.ini")), s_pCloseTitles);

	delete s_pCloseTitles;
}

bool CCloseTitlesOption::SearchString(const CString& strTitle)
{
	ATLASSERT(s_pCloseTitles != NULL);
	if (!s_bValid)// allways can't found
		return false;

	return MtlSearchStringWildCard(s_pCloseTitles->begin(), s_pCloseTitles->end(), strTitle);
}

void CCloseTitlesOption::Add(const CString& strTitle)
{
	if (!SearchString(strTitle))
		s_pCloseTitles->push_back(strTitle);
}



////////////////////////////////////////////////////////////////////////////////
//CCloseTitlesPropertyPage�̒�`
////////////////////////////////////////////////////////////////////////////////

//�R���X�g���N�^
CCloseTitlesPropertyPage::CCloseTitlesPropertyPage(const CString& strAddressBar)
	: m_urls(*CCloseTitlesOption::s_pCloseTitles), m_strAddressBar(strAddressBar),
		m_wndList(this,1)
{
	m_urls.sort();
	m_nValid = CCloseTitlesOption::s_bValid ? 1 : 0;
}

//���b�Z�[�W�n���h��
LRESULT CCloseTitlesPropertyPage::OnInitDialog(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
{	
	m_wndList.SubclassWindow(GetDlgItem(IDC_IGNORED_URL_LIST));
	return 0;
}

LRESULT CCloseTitlesPropertyPage::OnDestroy(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
{
	m_wndList.UnsubclassWindow();
	return 0;
}

//�R�}���h�n���h��
void CCloseTitlesPropertyPage::OnDelCmd(UINT /*wNotifyCode*/, int /*wID*/, HWND /*hWndCtl*/)
{
	std::list<int> sellist;
	int nSelCount = m_listbox.GetSelCount();
	int *pIdx = (int *)new int[nSelCount];
	if(m_listbox.GetSelItems(nSelCount,pIdx) != LB_ERR){

		for(int i=0; i<nSelCount; i++)
			sellist.push_back(pIdx[i]);
		sellist.sort(); sellist.reverse();
		for(std::list<int>::iterator it = sellist.begin(); it != sellist.end(); it++)
			m_listbox.DeleteString(*it);

	}
	delete [] pIdx;
}

void CCloseTitlesPropertyPage::OnDelAllCmd(UINT /*wNotifyCode*/, int /*wID*/, HWND /*hWndCtl*/)
{
	m_listbox.ResetContent();
}

void CCloseTitlesPropertyPage::OnAddCmd(UINT /*wNotifyCode*/, int /*wID*/, HWND /*hWndCtl*/)
{
	TCHAR szEdit[MAX_PATH];
	if (m_edit.GetWindowText(szEdit, MAX_PATH) == 0)
		return;

	int nIndex = m_listbox.FindStringExact(-1,szEdit);
	if(nIndex == LB_ERR){
		m_listbox.AddString(szEdit);
	} else {
		//m_listbox.SetCurSel(nIndex);
		m_listbox.SetSel(nIndex,TRUE);
	}
}

void CCloseTitlesPropertyPage::OnSelChange(UINT code, int id, HWND hWnd)
{
	//int nIndex = m_listbox.GetCurSel();
	int nIndex; 
	if(m_listbox.GetSelItems(1,&nIndex) == 0) return;
	CString strBox;
	m_listbox.GetText(nIndex, strBox);
	m_edit.SetWindowText(strBox);
}

void CCloseTitlesPropertyPage::OnListKeyUp(UINT nChar, UINT nRepCnt, UINT nFlags)
{
	if(nChar == VK_DELETE)
		OnDelCmd(0,0,NULL);
}

//�����֐�
void CCloseTitlesPropertyPage::GetData()
{
	// update close title list
	int nCount = m_listbox.GetCount();
	CString strbuf;
	m_urls.clear();
	for(int i=0; i<nCount; i++){
		m_listbox.GetText(i,strbuf);
		m_urls.push_back(strbuf);
	}
	*CCloseTitlesOption::s_pCloseTitles = m_urls;
	CCloseTitlesOption::s_bValid = m_nValid == 1 ? true : false;
}

BOOL CCloseTitlesPropertyPage::DataExchange(BOOL bSaveAndValidate)// get data from controls?
{
	if (!bSaveAndValidate) {// set data of control
		if(!m_listbox.m_hWnd)
			m_listbox.Attach(GetDlgItem(IDC_IGNORED_URL_LIST));
		m_listbox.ResetContent();
		std::for_each(m_urls.begin(), m_urls.end(), AddToListBox(m_listbox));

		if(!m_edit.m_hWnd)
			m_edit.Attach(GetDlgItem(IDC_URL_EDIT));
		m_edit.SetWindowText(m_strAddressBar);
	}

	return DoDataExchange(bSaveAndValidate);
}

//�I�[�o�[���C�h�֐�
BOOL CCloseTitlesPropertyPage::OnSetActive()
{
	SetModified(TRUE);
	return DataExchange(FALSE);
}

BOOL CCloseTitlesPropertyPage::OnKillActive()
{
	return DataExchange(TRUE);
}

BOOL CCloseTitlesPropertyPage::OnApply()
{
	if (DataExchange(TRUE)) {
		GetData();
		return TRUE;
	}
	else 
		return FALSE;
}
