#include "stdafx.h"
#include "PluginDialog.h"
#include "../MtlPrivateProfile.h"
#include "../DonutPFunc.h"

using namespace MTL;

// Constructor
CPluginPropertyPage::CPluginPropertyPage()
{
}

CPluginPropertyPage::~CPluginPropertyPage()
{
	m_listview.Detach();
	//memory leak bug fixed (release13)
	int nCount = m_mapPlaginInfo.GetSize();
	for(int i=0; i<nCount; i++){
		delete m_mapPlaginInfo.GetValueAt(i);
	}
}

// Overrides
BOOL CPluginPropertyPage::OnSetActive()
{
	if ( NULL==m_listview.m_hWnd )
	{
		m_listview.SubclassWindow(GetDlgItem(IDC_LIST_PLUGIN));
		_SetData();
	}
	return DoDataExchange(FALSE);
}
BOOL CPluginPropertyPage::OnKillActive()
{
	return DoDataExchange(TRUE);
}
BOOL CPluginPropertyPage::OnApply()
{
	if (DoDataExchange(TRUE)) {
		_GetData();
		return TRUE;
	}
	else 
		return FALSE;
}

void CPluginPropertyPage::OnBtnSetting(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/)
{
	int nIndex = m_listview.GetSelectedIndex();
	if ( nIndex < 0 )
		return;

	CString strFile;
	m_listview.GetItemText( nIndex, 0, strFile );

	HINSTANCE hLib = ::LoadLibrary( _T("Plugin\\") + strFile );
	if ( !hLib ) return;
	
	void (WINAPI *__PluginSetting)()=NULL;
	__PluginSetting=(void(WINAPI *)())GetProcAddress(hLib, _T("PluginSetting"));

	if ( __PluginSetting )
		__PluginSetting();
	::FreeLibrary( hLib );
}

void CPluginPropertyPage::_GetData()
{
	CSimpleMap<int , CSimpleArray<CString>*> map;
	for ( int nType=1; nType<=PLUGIN_TYPECNT; nType++ )
	{
		CSimpleArray<CString>* pAry = new CSimpleArray<CString>;
		map.Add( nType, pAry );
	}

	for (int nIndex=0; nIndex<m_listview.GetItemCount(); nIndex++)
	{
		CString strFile;
		m_listview.GetItemText( nIndex, 0, strFile );
		if ( FALSE==m_listview.GetCheckState( nIndex ) ) continue;
		int nType = m_listview.GetItemData( nIndex );

		CSimpleArray<CString>* pAry=NULL;
		pAry = map.Lookup( nType );
		if ( NULL==pAry ) continue;
		pAry->Add( strFile );
	}

	for ( nIndex=0; nIndex<map.GetSize(); nIndex++ )
	{
		CSimpleArray<CString>* pAry=NULL;
		pAry = map.GetValueAt( nIndex );
		int nType = map.GetKeyAt( nIndex );

		CString strKey;
		strKey.Format( _T("Plugin%02d"), nType );

		CIniSection pr;
		pr.Open( _szIniFileName, strKey );

		pr.SetValue( pAry->GetSize(), _T("Count") );
		for (int nNo=0; nNo<pAry->GetSize(); nNo++)
		{
			strKey.Format(_T("%02d"), nNo);
			pr.SetValue( (*pAry)[nNo], strKey);
		}
		delete pAry;
	}
}

void CPluginPropertyPage::_SetData()
{
	TCHAR titles[] = _T("�t�@�C����");
	LVCOLUMN col;
	col.mask = LVCF_TEXT | LVCF_WIDTH;
	col.pszText = titles;
	col.cx = 150;
	m_listview.InsertColumn(0, &col);

	// List Item
	InitListItem();
	DoCheckListItem();

	::EnableWindow( GetDlgItem( IDC_BTN_SETTING ), FALSE );
}

LRESULT CPluginPropertyPage::OnListPluginSelectchange(LPNMHDR)
{
	int nIndex = m_listview.GetSelectedIndex();
	if ( -1==nIndex )
	{
		::EnableWindow( GetDlgItem(IDC_BTN_SETTING), FALSE );
		m_strPluginName		= _T("");
		m_strPluginKind		= _T("");
		m_strPluginVer		= _T("");
		m_strPluginDate		= _T("");
		m_strPluginComment	= _T("");
		m_strAuthuorName	= _T("");
		m_strAuthuorURL		= _T("");
		m_strAuthuorEMail	= _T("");
	}
	else
	{
		::EnableWindow( GetDlgItem(IDC_BTN_SETTING), TRUE );
		CString strItemSelect;
		m_listview.GetItemText( nIndex, 0, strItemSelect );

		PLUGININFO* pstPluginInfo = m_mapPlaginInfo.Lookup( strItemSelect );
		if ( pstPluginInfo )
		{
			m_strPluginName			= pstPluginInfo->name;
			LPCTSTR PluginType[] = { _T("Toolbar"), _T("Explorerbar"), _T("Statusbar"),
									 _T("Operation"), _T("Docking")};
			m_strPluginKind         = PluginType[(pstPluginInfo->type&0xF)-1];
			m_strPluginVer			= pstPluginInfo->version;
			m_strPluginDate			= pstPluginInfo->versionDate;
			m_strPluginComment		= pstPluginInfo->comment;
			m_strAuthuorName		= pstPluginInfo->authorName;
			m_strAuthuorURL			= pstPluginInfo->authorUrl;
			m_strAuthuorEMail		= pstPluginInfo->authorEmail;
		}
	}

	DoDataExchange( FALSE );
	return S_OK;
}

void CPluginPropertyPage::InitListItem()
{
	CFindFile finder;
	CString strPathMatch = _GetDonutPath() + _T("Plugin\\*.dll");
	if ( finder.FindFile( strPathMatch ) )
	{
		do
		{
			PLUGININFO* pstPluginInfo = new PLUGININFO;
			memset( pstPluginInfo, 0, sizeof(PLUGININFO) );

			CString strFile = finder.GetFileName();
			HINSTANCE hLib = ::LoadLibrary( _T("Plugin\\") + strFile );
			if(!hLib){
				DWORD errNum = ::GetLastError();
			}
			
			void (WINAPI *__GetPluginInfo)(PLUGININFO* pstPlugin)=NULL;
			__GetPluginInfo=(void(WINAPI *)(PLUGININFO*))GetProcAddress(hLib, "GetPluginInfo");

			if ( __GetPluginInfo )
			{
				__GetPluginInfo( pstPluginInfo );
				m_mapPlaginInfo.Add( strFile, pstPluginInfo );

				// List Add
				int nIndex = m_listview.InsertItem( m_listview.GetItemCount(), strFile );
				m_listview.SetItemData( nIndex, pstPluginInfo->type );
			}
			else
			{
				delete pstPluginInfo;
			}
			::FreeLibrary( hLib );

		}while( finder.FindNextFile() );
	}
}

void CPluginPropertyPage::DoCheckListItem()
{
	for ( int nType=1; nType<=PLUGIN_TYPECNT; nType++ )
	{
		CString strKey;
		strKey.Format( _T("Plugin%02d"), PLT_TOOLBAR+nType );

		CIniSection pr;
		pr.Open( _szIniFileName, strKey );

		DWORD dwCount=0;
		pr.QueryValue( dwCount, _T("Count") );
		for (int nNo=0; nNo<(int)dwCount; nNo++)
		{
			TCHAR szFile[MAX_PATH];		memset(szFile, 0, sizeof(szFile));
			DWORD dwBuffSize = MAX_PATH;
			strKey.Format(_T("%02d"), nNo);
			pr.QueryValue(szFile, strKey, &dwBuffSize);

			for ( int nIndex=0; nIndex<m_listview.GetItemCount(); nIndex++ )
			{
				CString strItem;
				m_listview.GetItemText( nIndex, 0, strItem );
				if ( strItem != szFile ) continue;

				m_listview.SetCheckState( nIndex, TRUE );
				break;
			}

		}
	}
}
