#pragma once

#include "../resource.h"

class CDeterrentPropertyPage : 
	public CPropertyPageImpl<CDeterrentPropertyPage>,
	public CWinDataExchange<CDeterrentPropertyPage>
{
public:
// Declarations
	enum { IDD = IDD_PROPPAGE_DETERRENT };

// Data members
	CIgnoredURLsOption::CStringList	m_urls;
	CCloseTitlesOption::CStringList m_titles;
	CString							m_strUrl,	m_strTitle;
	CListBox						m_ltUrl,	m_ltTitle;
	CEdit							m_edtUrl,	m_edtTitle;
	int								m_nChkUrl,	m_nChkTitle;

// Constructor
	CDeterrentPropertyPage(const CString& strUrl, const CString& strTitle);
// DDX map
	BEGIN_DDX_MAP(CDeterrentPropertyPage)
		DDX_CHECK(IDC_CHK_URL,		m_nChkUrl)
		DDX_CHECK(IDC_CHK_TITLE,	m_nChkTitle)
	END_DDX_MAP()

// Overrides
	BOOL OnSetActive();
	BOOL OnKillActive();
	BOOL OnApply();

// overrides
	BOOL _DoDataExchange(BOOL bSaveAndValidate); // get data from controls?

// Message map and handlers
	BEGIN_MSG_MAP(CIgnoredURLsPropertyPage)
		COMMAND_ID_HANDLER_EX( IDC_BTN_ADD_URL,		OnAddCmd )
		COMMAND_ID_HANDLER_EX( IDC_BTN_ADD_TITLE,	OnAddCmd )

		COMMAND_ID_HANDLER_EX( IDC_BTN_DELALL_URL,	OnDelAllCmd )
		COMMAND_ID_HANDLER_EX( IDC_BTN_DELALL_TITLE,OnDelAllCmd )

		COMMAND_ID_HANDLER_EX( IDC_BTN_DEL_URL,		OnDelCmd )
		COMMAND_ID_HANDLER_EX( IDC_BTN_DEL_TITLE,	OnDelCmd )

		COMMAND_HANDLER_EX( IDC_LIST_URL,	LBN_SELCHANGE, OnSelChange )
		COMMAND_HANDLER_EX( IDC_LIST_TITLE, LBN_SELCHANGE, OnSelChange )

		CHAIN_MSG_MAP( CPropertyPageImpl<CDeterrentPropertyPage> )
	END_MSG_MAP()

	void OnDelCmd(UINT /*wNotifyCode*/, int wID, HWND hWndCtl);
	void OnDelAllCmd(UINT /*wNotifyCode*/, int wID, HWND hWndCtl );
	void OnAddCmd(UINT /*wNotifyCode*/, int wID, HWND hWndCtl);

	void OnSelChange(UINT code, int id, HWND hWnd);

// Implementation
private:
	// function objects
	struct _AddToListBox : public std::unary_function<const CString&, void>
	{
		CListBox& _box;
		_AddToListBox(CListBox& box) : _box(box) { }
		result_type operator()(argument_type src)
		{
			_box.AddString(src);
		}
	};

	void _GetData();
};
