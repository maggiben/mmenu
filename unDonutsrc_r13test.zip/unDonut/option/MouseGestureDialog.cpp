#include "stdafx.h"
#include "MouseGestureDialog.h"
#include "../MtlBase.h"
#include "../MtlPrivateProfile.h"
#include "../DonutPFunc.h"
#include "../ToolTipManager.h"

using namespace MTL;

CMouseGesturePropertyPage::CMouseGesturePropertyPage(HMENU hMenu)
{
	m_hMenu = hMenu;
	m_strPath = _GetFilePath(_T("MouseEdit.ini"));
}

// Overrides
BOOL CMouseGesturePropertyPage::OnSetActive()
{
	SetModified(TRUE);
	
	if(m_cmbCategory.m_hWnd == NULL){
		if (m_cmbCategory.m_hWnd == NULL)
			m_cmbCategory.Attach(GetDlgItem(IDC_CMB_CATEGORY));

		if (m_cmbCommand.m_hWnd == NULL)
			m_cmbCommand.Attach(GetDlgItem(IDC_CMB_COMMAND));

		OnInitCmb();
		OnInitList();

		m_stcMoveCmd.Attach(GetDlgItem(IDC_STC01));
	}

	_SetData();
	return DoDataExchange(FALSE);
}

BOOL CMouseGesturePropertyPage::OnKillActive()
{
	return DoDataExchange(TRUE);
}

BOOL CMouseGesturePropertyPage::OnApply()
{
	if (DoDataExchange(TRUE)) {
		_GetData();
		return TRUE;
	}
	else 
		return FALSE;
}

// Constructor
// �f�[�^�𓾂�
void CMouseGesturePropertyPage::_SetData()
{
}

// �f�[�^��ۑ�
void CMouseGesturePropertyPage::_GetData()
{
	CIniSection pr;
	pr.Open(m_strPath, _T("MouseCtrl"));

	for (int ii=0; ii<m_mapMouseCmd.GetSize(); ii++)
	{
		CString strKey = m_mapMouseCmd.GetKeyAt(ii);
		DWORD dwCommand = m_mapMouseCmd.GetValueAt(ii);

		pr.SetValue(dwCommand, strKey);
	}

	for (ii=0; ii<m_aryDelJst.GetSize(); ii++)
		pr.DeleteValue(m_aryDelJst[ii]);

	for (ii=0; ii<m_ltMoveCmd.GetItemCount(); ii++)
	{
		CString strMoveCmd;
		m_ltMoveCmd.GetItemText(ii, 0, strMoveCmd);
		DWORD dwCommand=0;
		dwCommand = m_ltMoveCmd.GetItemData(ii);

		pr.SetValue(dwCommand, strMoveCmd);
	}
	pr.Close();

	pr.Open(m_strPath, _T("MouseJst"));
	pr.SetValue(m_ltMoveCmd.GetItemCount(), _T("Count"));
	for (ii=0; ii<m_ltMoveCmd.GetItemCount(); ii++)
	{
		CString strMoveCmd;
		m_ltMoveCmd.GetItemText(ii, 0, strMoveCmd);

		CString strKey;
		strKey.Format("%d", ii);
		pr.SetValue(strMoveCmd, strKey);
	}
}

void CMouseGesturePropertyPage::OnInitCmb()
{
	// �J�e�S���Z�b�g
	_SetCombboxCategory(m_cmbCategory, m_hMenu);
	OnSelChangeCate(0,0,0);
}

void CMouseGesturePropertyPage::OnInitList()
{
	m_ltMoveCmd.Attach(GetDlgItem(IDC_LISTBOX));

	const TCHAR* titles[] = { _T("�W�F�X�`���["), _T("�R�}���h") };
	int widths[] = { 350, 150};

	LVCOLUMN col;
	col.mask = LVCF_TEXT | LVCF_WIDTH;

	for (int i = 0; i < _countof(titles); ++i) {
		col.pszText = (LPTSTR)titles[i];
		col.cx = widths[i];
		m_ltMoveCmd.InsertColumn(i, &col);
	}

	m_ltMoveCmd.SendMessage(LVM_SETEXTENDEDLISTVIEWSTYLE, 0, LVS_EX_FULLROWSELECT|LVS_EX_GRIDLINES);

	CIniSection pr;
	pr.Open(m_strPath, _T("MouseJst"));

	CIniSection pr2;
	pr2.Open(m_strPath, _T("MouseCtrl"));

	DWORD dwCount=0;
	pr.QueryValue(dwCount, _T("Count"));
	
	DWORD dwBuff=MAX_PATH;
	TCHAR cBuff[MAX_PATH];
	for (int ii=0; ii<(int)dwCount; ii++)
	{
		CString strMoveCmd;
		m_ltMoveCmd.GetItemText(ii, 0, strMoveCmd);

		CString strKey;
		strKey.Format("%d", ii);

		memset(cBuff, 0, MAX_PATH);
		pr.QueryValue(cBuff, strKey, &dwBuff);
		CString strJst(cBuff);

		DWORD dwCmdID=0;
		pr2.QueryValue(dwCmdID, strJst);

		CString strCmdName;
		CToolTipManager::LoadToolTipText(dwCmdID, strCmdName);

		m_ltMoveCmd.InsertItem(ii, strJst);
		m_ltMoveCmd.SetItemText(ii, 1, strCmdName);
		m_ltMoveCmd.SetItemData(ii, dwCmdID);
	}

	::EnableWindow(GetDlgItem(IDC_BTN_ADD), FALSE);
	::EnableWindow(GetDlgItem(IDC_BTN_DEL), FALSE);
}

void CMouseGesturePropertyPage::OnBtnAdd(UINT /*wNotifyCode*/, int /*wID*/, HWND /*hWndCtl*/)
{
	int nIndexCmd = m_cmbCommand.GetCurSel();
	UINT nCmdID = m_cmbCommand.GetItemData(nIndexCmd);
	if (nCmdID==0) return;

	TCHAR szText[255];
	CString strText;
	m_stcMoveCmd.GetWindowText(szText, 255);
	strText = szText;
	if (strText.IsEmpty()) return;

	CString strCmd;
	CToolTipManager::LoadToolTipText(nCmdID, strCmd);
	if (strCmd.IsEmpty()) return;
	
	int nCnt = m_ltMoveCmd.GetItemCount();
	nCnt = m_ltMoveCmd.InsertItem(nCnt, strText);
	m_ltMoveCmd.SetItemText(nCnt, 1, strCmd);
	m_ltMoveCmd.SetItemData(nCnt, nCmdID);

	m_stcMoveCmd.SetWindowText("");
	::EnableWindow(GetDlgItem(IDC_BTN_ADD), FALSE);
	::EnableWindow(GetDlgItem(IDC_BTN_DEL), FALSE);
}

void CMouseGesturePropertyPage::OnBtnDel(UINT /*wNotifyCode*/, int /*wID*/, HWND /*hWndCtl*/)
{
	int nIndex = m_ltMoveCmd.GetSelectedIndex();
	if (nIndex==-1) return;

	CString strJst;
	m_ltMoveCmd.GetItemText(nIndex, 0, strJst);
	m_aryDelJst.Add(strJst);

	m_ltMoveCmd.DeleteItem(nIndex);
	::EnableWindow(GetDlgItem(IDC_BTN_DEL), TRUE);
}

void CMouseGesturePropertyPage::OnBtn(UINT /*wNotifyCode*/, int wID, HWND /*hWndCtl*/)
{
	TCHAR szText[255];

	CString strText;
	m_stcMoveCmd.GetWindowText(szText, 255);
	strText = szText;

	switch(wID)
	{
	case IDC_BTN_UP:	strText += _T("��");	break;
	case IDC_BTN_DOWN:	strText += _T("��");	break;
	case IDC_BTN_LEFT:	strText += _T("��");	break;
	case IDC_BTN_RIGHT:	strText += _T("��");	break;
	case IDC_BTN_CLEAR:	strText = _T("");	break;
	}

	m_stcMoveCmd.SetWindowText(strText);
	EnableAddBtn();
}

void CMouseGesturePropertyPage::OnSelChangeCmd(UINT code, int id, HWND hWnd)
{
	EnableAddBtn();
}

void CMouseGesturePropertyPage::EnableAddBtn()
{
	TCHAR szText[255];
	CString strNowJst;
	m_stcMoveCmd.GetWindowText(szText, 255);
	strNowJst = szText;

	BOOL bEnable=TRUE;

	int nIndexCmd = m_cmbCommand.GetCurSel();
	UINT nCmdID = m_cmbCommand.GetItemData(nIndexCmd);
	if (nCmdID==0 || nIndexCmd==-1) bEnable=FALSE;

	for (int ii=0; ii<m_ltMoveCmd.GetItemCount() && bEnable; ii++)
	{
		CString strMoveJst;
		m_ltMoveCmd.GetItemText(ii, 0, strMoveJst);
		if (strNowJst!=strMoveJst) continue;

		bEnable=FALSE;
		break;
	}

	::EnableWindow(GetDlgItem(IDC_BTN_ADD), bEnable);
}

LRESULT CMouseGesturePropertyPage::OnItemChg(LPNMHDR pnmh)
{
	LPNMLISTVIEW pnmv = (LPNMLISTVIEW)pnmh; 
	if (pnmv->uNewState!=LBN_SELCANCEL) return 0;

	long nIndex = pnmv->iItem;
	::EnableWindow(GetDlgItem(IDC_BTN_DEL), TRUE);
	return 0;
}

// �J�e�S���ύX��
void CMouseGesturePropertyPage::OnSelChangeCate(UINT code, int id, HWND hWnd)
{
	int nIndex = m_cmbCategory.GetCurSel();
	
	// �R�}���h�I��
	_PickUpCommand(m_hMenu, nIndex, m_cmbCommand);
}
