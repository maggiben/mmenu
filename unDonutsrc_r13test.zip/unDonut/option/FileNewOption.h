#pragma once

#include "../resource.h"

#define FILENEW_BLANK	0x00000001L
#define FILENEW_COPY	0x00000002L
#define FILENEW_HOME	0x00000004L

class CFileNewOption
{
public:
	static DWORD s_dwFlags;

	static void GetProfile();
	static void WriteProfile();
};


class CFileNewPropertyPage : public CPropertyPageImpl<CFileNewPropertyPage>,
	public CWinDataExchange<CFileNewPropertyPage>
{
public:
// Constants
	enum { IDD = IDD_PROPPAGE_FILENEW };

// Data members
	int m_nRadio;

// DDX map
	BEGIN_DDX_MAP(CFileNewPropertyPage)
		DDX_RADIO(IDC_RADIO_BLANK, m_nRadio)
//		DDX_RADIO(IDC_RADIO_COPY, m_bCopy)
//		DDX_RADIO(IDC_RADIO_HOME, m_bHome)
	END_DDX_MAP()

// Constructor
	CFileNewPropertyPage();

// Overrides
	BOOL OnSetActive();
	BOOL OnKillActive();
	BOOL OnApply();

// Message map and handlers
	BEGIN_MSG_MAP(CFileNewPropertyPage)
		CHAIN_MSG_MAP(CPropertyPageImpl<CFileNewPropertyPage>)
	END_MSG_MAP()

// Implementation
protected:
	void _GetData();
	void _SetData();
};
