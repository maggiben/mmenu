#include "stdafx.h"
#include "MenuDialog.h"
#include "MainOption.h"
#include "../MtlPrivateProfile.h"
#include "../DonutPFunc.h"
#include "../ToolTipManager.h"

using namespace MTL;

extern char _cSeparater[];

CMenuPropertyPage::CMenuPropertyPage(HMENU hMenu)
{
	m_bFirst = TRUE;
	m_hMenu = hMenu;
	m_nNoButton = 0;
}

CMenuPropertyPage::~CMenuPropertyPage()
{
	for (int ii=0; ii<m_mapFront.GetSize(); ii++)
	{
		CSimpleArray<int>* pAry = m_mapFront.GetValueAt(ii);
		delete pAry;
	}

	for (ii=0; ii<m_mapBack.GetSize(); ii++)
	{
		CSimpleArray<int>* pAry = m_mapBack.GetValueAt(ii);
		delete pAry;
	}
}

// Overrides
BOOL CMenuPropertyPage::OnSetActive()
{
	SetModified(TRUE);

	if (m_cmbTar.m_hWnd==NULL)
	{
		m_strPath = _GetFilePath(_T("Menu.ini"));
		InitialCmbbox();
		InitialListbox();

		m_nNoCstmMenu = CMainOption::s_dwMainExtendedStyle2 & MAIN_EX2_NOCSTMMENU ? 1:0;

		DWORD dwVal=0;
		CIniSection pr;
		pr.Open(_szIniFileName, _T("ETC"));
		if (pr.QueryValue(dwVal, _T("IeMenuNoCstm"))==ERROR_SUCCESS)
			m_nNoCstmIeMenu = dwVal;
		pr.Close();

		SetAddMenu(m_cmbTar.GetItemData(0));

		DWORD dwFlag=0;
		pr.Open(m_strPath,_T("Option"));
		pr.QueryValue(dwFlag,_T("REqualL"));
		m_nREqualL = dwFlag;
		dwFlag = 0;
		pr.QueryValue(dwFlag,_T("NoButton"));
		m_nNoButton = dwFlag;
		pr.Close();

	}

	return DoDataExchange(FALSE);
}

BOOL CMenuPropertyPage::OnKillActive()
{
	return DoDataExchange(TRUE);
}
BOOL CMenuPropertyPage::OnApply()
{
	if (DoDataExchange(TRUE)) {
		_SaveData();
		return TRUE;
	}
	else 
		return FALSE;
}

// �f�[�^��ۑ�
void CMenuPropertyPage::_SaveData()
{
	// ���j���[�e�L�X�g�ҏW
	if (m_nNoCstmMenu==1)
		CMainOption::s_dwMainExtendedStyle2 |= MAIN_EX2_NOCSTMMENU;
	else if (CMainOption::s_dwMainExtendedStyle2&MAIN_EX2_NOCSTMMENU)
		CMainOption::s_dwMainExtendedStyle2&=~MAIN_EX2_NOCSTMMENU;

	// IE Menu �̃J�X�^��
	CIniSection pr;
	pr.Open(_szIniFileName, _T("ETC"));
	pr.SetValue(m_nNoCstmIeMenu, _T("IeMenuNoCstm"));
	pr.Close();

	CString strKey;

	// IE Menu �J�X�^��
	long nMenuType[] = {CONTEXT_MENU_DEFAULT, CONTEXT_MENU_TEXTSELECT, CONTEXT_MENU_ANCHOR,0xFFFFFFFF};
	for (int ii=0; ii<(sizeof(nMenuType)/sizeof(long)); ii++)
	{
		if(nMenuType[ii] == 0xFFFFFFFF){
			//���{�^���������Ȃ���E�N���b�N���j���[�����ʏ���
			_SaveExData(m_mapFront.Lookup(nMenuType[ii]));
			continue;
		}

		strKey.Format("Type%d", nMenuType[ii]);
		pr.Open(m_strPath, strKey);

		CSimpleArray<int>* pAryFront = m_mapFront.Lookup(nMenuType[ii]);
		pr.SetValue(pAryFront->GetSize(), _T("FrontCount"));
		for (int jj=0; jj<pAryFront->GetSize(); jj++)
		{
			strKey.Format("Front%02d", jj);
			pr.SetValue((*pAryFront)[jj], strKey);
		}

		CSimpleArray<int>* pAryBack = m_mapBack.Lookup(nMenuType[ii]);
		pr.SetValue(pAryBack->GetSize(), _T("BackCount"));
		for (jj=0; jj<pAryBack->GetSize(); jj++)
		{
			strKey.Format("Back%02d", jj);
			pr.SetValue((*pAryBack)[jj], strKey);
		}
		pr.Close();
	}

	/*pr.Open(m_strPath, _T("MenuEx"));
	pr.SetValue(m_aryMenuEx.GetSize(), _T("Count"));
	for (ii=0; ii<m_aryMenuEx.GetSize(); ii++)
	{
		strKey.Format("%02d", ii);
		pr.SetValue(m_aryMenuEx[ii], strKey);
	}*/

	pr.Open(m_strPath, _T("Option"));
	DWORD dwFlag = m_nREqualL ? 1 : 0;
	pr.SetValue(dwFlag,_T("REqualL"));
	dwFlag = m_nNoButton ? 1 : 0;
	pr.SetValue(dwFlag,_T("NoButton"));
	pr.Close();
}

void CMenuPropertyPage::_SaveExData(CSimpleArray<int>* pAryEx)
{
	CIniSection pr;
	pr.Open(m_strPath, _T("MenuEx"));
	pr.SetValue(pAryEx->GetSize(), _T("Count"));
	CString strKey;

	int nCount = pAryEx->GetSize();
	for (int ii=0; ii<nCount; ii++)
	{
		strKey.Format("%02d", ii);
		pr.SetValue((DWORD)(*pAryEx)[ii], strKey);
	}
	pr.Close();
}

void CMenuPropertyPage::InitialListbox()
{
	m_ltFront.Attach(GetDlgItem(IDC_LIST1));
	m_ltBack.Attach(GetDlgItem(IDC_LIST2));

	CIniSection pr;
	CString strKey;	
	DWORD dwCount=0;
	for (int ii=0; ii<m_cmbTar.GetCount(); ii++)
	{
		CSimpleArray<int>* pAryFront=new CSimpleArray<int>;
		CSimpleArray<int>* pAryBack=new CSimpleArray<int>;

		int nKind = m_cmbTar.GetItemData(ii);
		m_mapFront.Add(nKind, pAryFront);
		m_mapBack.Add(nKind, pAryBack);

		if(nKind == 0xFFFFFFFF){
			_LoadExData(pAryFront);
			continue;
		}

		strKey.Format("Type%d", nKind);
		pr.Open(m_strPath, strKey);
		pr.QueryValue(dwCount, _T("FrontCount"));
		for (int jj=0; jj<(int)dwCount; jj++)
		{
			strKey.Format("Front%02d", jj);
			DWORD dwCmd=0;
			pr.QueryValue(dwCmd, strKey);
			int nCmd = dwCmd;
			pAryFront->Add(nCmd);
		}

		pr.QueryValue(dwCount, _T("BackCount"));
		for (jj=0; jj<(int)dwCount; jj++)
		{
			strKey.Format("Back%02d", jj);
			DWORD dwCmd=0;
			pr.QueryValue(dwCmd, strKey);
			int nCmd = dwCmd;
			pAryBack->Add(nCmd);
		}
		pr.Close();
	}

}

void CMenuPropertyPage::_LoadExData(CSimpleArray<int> *pAryEx)
{
	DWORD dwCount=0;
	CIniSection pr;
	pr.Open(m_strPath, _T("MenuEx"));
	pr.QueryValue(dwCount, _T("Count"));
	CString strKey;

	for(int ii=0; ii<(int)dwCount; ii++){
		strKey.Format("%02d", ii);
		DWORD dwCmd=0;
		pr.QueryValue(dwCmd, strKey);
		int nCmd = dwCmd;
		pAryEx->Add(nCmd);
	}
	pr.Close();

}

void CMenuPropertyPage::InitialCmbbox()
{
	m_cmbTar.Attach(GetDlgItem(IDC_CMB_TAR));
	m_cmbCategory.Attach(GetDlgItem(IDC_CMB_CATEGORY));
	m_cmbCommand.Attach(GetDlgItem(IDC_CMB_COMMAND));

	m_cmbTar.AddString("�ʏ펞");
	m_cmbTar.AddString("�I����");
	m_cmbTar.AddString("�����N�㎞");
	m_cmbTar.AddString("���{�^�������Ȃ���");
	m_cmbTar.SetItemData(0, CONTEXT_MENU_DEFAULT);
	m_cmbTar.SetItemData(1, CONTEXT_MENU_TEXTSELECT);
	m_cmbTar.SetItemData(2, CONTEXT_MENU_ANCHOR);
	m_cmbTar.SetItemData(3, 0xFFFFFFFF); //minit ������Ɖ����ł���

	m_cmbTar.SetCurSel(0);

	// �J�e�S���Z�b�g
	_SetCombboxCategory(m_cmbCategory, m_hMenu);
	OnSelChangeCate(0,IDC_CMB_CATEGORY,0);
	m_cmbCategory.AddString(_T("�O���[�v�E���j���["));
}

void CMenuPropertyPage::OnSelChangeCate(UINT code, int id, HWND hWnd)
{
	if (id==IDC_CMB_CATEGORY)
	{
		int nIndex = m_cmbCategory.GetCurSel();

		// �R�}���h�I��
		if ((nIndex+1)!=m_cmbCategory.GetCount())
			_PickUpCommand(m_hMenu, nIndex, m_cmbCommand);
		else
			PickUpCommandEx(m_cmbCommand);

		::EnableWindow(GetDlgItem(IDC_BTN_ADD1), FALSE);
		::EnableWindow(GetDlgItem(IDC_BTN_ADD2), FALSE);
		::EnableWindow(GetDlgItem(IDC_BTN_DEL1), FALSE);
		::EnableWindow(GetDlgItem(IDC_BTN_DEL2), FALSE);
	}
	else if (id==IDC_CMB_CATEGORY2)
	{
		int nIndex = m_cmbCategory2.GetCurSel();

		// �R�}���h�I��
		if ((nIndex+1)!=m_cmbCategory2.GetCount())
			_PickUpCommand(m_hMenu, nIndex, m_cmbCommand2);
		else
			PickUpCommandEx(m_cmbCommand2);

		::EnableWindow(GetDlgItem(IDC_BTN_ADD3), FALSE);
		::EnableWindow(GetDlgItem(IDC_BTN_DEL3), FALSE);
	}
}

// �g���R�}���h
void CMenuPropertyPage::PickUpCommandEx(CComboBox &cmbCmd)
{
	UINT uCommandExID[] = {ID_FAVORITES_DROPDOWN, ID_FAVORITES_GROUP_DROPDOWN, ID_SCRIPT,
		ID_DLCTL_CHG_MULTI, ID_DLCTL_CHG_SECU, ID_VIEW_FONT_SIZE, ID_COOKIE_IE6};

	cmbCmd.ResetContent();

	for (int ii=0; ii<sizeof(uCommandExID)/sizeof(UINT); ii++)
	{
		CString strMenu;
		CToolTipManager::LoadToolTipText(uCommandExID[ii], strMenu);
		if (strMenu.IsEmpty()) continue;

		int nIndex = cmbCmd.AddString(strMenu);
		cmbCmd.SetItemData(nIndex, uCommandExID[ii]);
	}
}

void CMenuPropertyPage::OnSelChangeCmd(UINT code, int id, HWND hWnd)
{
	if (id==IDC_CMB_COMMAND)
	{
		::EnableWindow(GetDlgItem(IDC_BTN_ADD1), TRUE);
		::EnableWindow(GetDlgItem(IDC_BTN_ADD2), TRUE);
	}
	else if (id==IDC_CMB_COMMAND2)
	{
		::EnableWindow(GetDlgItem(IDC_BTN_ADD3), TRUE);
	}
}

void CMenuPropertyPage::OnBtnAdd(UINT /*wNotifyCode*/, int wID, HWND /*hWndCtl*/)
{
	int nIndexCmd = m_cmbCommand.GetCurSel();
	int nCmdID = m_cmbCommand.GetItemData(nIndexCmd);

	CString strCmd;
	m_cmbCommand.GetLBText(nIndexCmd, strCmd);
	
	CListBox* pListBox=NULL;
	switch(wID)
	{
	case IDC_BTN_ADD1:	pListBox = &m_ltFront;	break;
	case IDC_BTN_ADD2:	pListBox = &m_ltBack;	break;
	}

	int nIndex = pListBox->AddString(strCmd);

	int nType = m_cmbTar.GetItemData(m_cmbTar.GetCurSel());
	CSimpleArray<int>* pAryFrontMenu = m_mapFront.Lookup(nType);
	CSimpleArray<int>* pAryBackMenu = m_mapBack.Lookup(nType);
	switch(wID)
	{
	case IDC_BTN_ADD1:	pAryFrontMenu->Add(nCmdID);	break;
	case IDC_BTN_ADD2:	pAryBackMenu->Add(nCmdID);	break;
	}
}

void CMenuPropertyPage::OnBtnDel(UINT /*wNotifyCode*/, int wID, HWND /*hWndCtl*/)
{
	CListBox* pListBox=NULL;
	switch(wID)
	{
	case IDC_BTN_DEL1:	pListBox = &m_ltFront;	break;
	case IDC_BTN_DEL2:	pListBox = &m_ltBack;	break;
	}

	int nIndex = pListBox->GetCurSel();
	if (nIndex<0) return;
	pListBox->DeleteString(nIndex);

	int nType = m_cmbTar.GetItemData(m_cmbTar.GetCurSel());
	CSimpleArray<int>* pAryFrontMenu = m_mapFront.Lookup(nType);
	CSimpleArray<int>* pAryBackMenu = m_mapBack.Lookup(nType);
	switch(wID)
	{
	case IDC_BTN_DEL1:	pAryFrontMenu->RemoveAt(nIndex);	break;
	case IDC_BTN_DEL2:	pAryBackMenu->RemoveAt(nIndex);		break;
	}
}

void CMenuPropertyPage::OnListChg(UINT code, int id, HWND hWnd)
{
	int nEnableID=0;
	switch(id)
	{
	case IDC_LIST1:	nEnableID = IDC_BTN_DEL1;	break;
	case IDC_LIST2:	nEnableID = IDC_BTN_DEL2;	break;
	}

	::EnableWindow(GetDlgItem(nEnableID), TRUE);
}

void CMenuPropertyPage::OnSelChangeTarget(UINT code, int id, HWND hWnd)
{
	int nIndex = m_cmbTar.GetCurSel();

	if(nIndex == m_cmbTar.FindString(0,_T("���{�^�������Ȃ���")))
		ShowSecondObjects(FALSE);
	else
		ShowSecondObjects(TRUE);
	SetAddMenu(m_cmbTar.GetItemData(nIndex));
}

void CMenuPropertyPage::SetAddMenu(int nType)
{
	CSimpleArray<int>* pAryFrontMenu = m_mapFront.Lookup(nType);
	CSimpleArray<int>* pAryBackMenu = m_mapBack.Lookup(nType);

	m_ltFront.ResetContent();
	m_ltBack.ResetContent();

	CSimpleArray<int>* pAryMenu=NULL;
	CListBox* pListBox=NULL;
	for (int ii=0; ii<2; ii++)
	{
		if (ii==0)
		{
			pAryMenu = pAryFrontMenu;
			pListBox = &m_ltFront;
		}
		else
		{
			pAryMenu = pAryBackMenu;
			pListBox = &m_ltBack;
		}

		for (int jj=0; jj<pAryMenu->GetSize(); jj++)
		{
			int nCmdID = (*pAryMenu)[jj];
			CString strCmd;
			if (nCmdID==0)
				strCmd = _cSeparater;
			else
				CToolTipManager::LoadToolTipText(nCmdID, strCmd);

			int nIndex = pListBox->AddString(strCmd);
		}
	}
}

void CMenuPropertyPage::GetTargetMenuaryAndListbox(int nID, CSimpleArray<int>* &pAryMenu, CListBox* &pListBox)
{
	int nType = m_cmbTar.GetItemData(m_cmbTar.GetCurSel());
	switch(nID)
	{
	case IDC_BTN_UP1:
	case IDC_BTN_DOWN1:
		pAryMenu = m_mapFront.Lookup(nType);
		pListBox = &m_ltFront;
		break;

	case IDC_BTN_UP2:
	case IDC_BTN_DOWN2:
		pAryMenu = m_mapBack.Lookup(nType);
		pListBox = &m_ltBack;
		break;
	}
}

void CMenuPropertyPage::OnBtnUp(UINT /*wNotifyCode*/, int wID, HWND /*hWndCtl*/)
{
	CSimpleArray<int>* pAryMenu=NULL;
	CListBox* pListBox=NULL;
	GetTargetMenuaryAndListbox(wID, pAryMenu, pListBox);

	int nIndex = pListBox->GetCurSel();
	if (nIndex<1) return;

	CString strKeep;
	pListBox->GetText(nIndex-1, strKeep);
	pListBox->DeleteString(nIndex-1);
	pListBox->InsertString(nIndex, strKeep);

	int nTemp = (*pAryMenu)[nIndex-1];
	(*pAryMenu)[nIndex-1] = (*pAryMenu)[nIndex];
	(*pAryMenu)[nIndex] = nTemp;
}

void CMenuPropertyPage::OnBtnDown(UINT /*wNotifyCode*/, int wID, HWND /*hWndCtl*/)
{
	CSimpleArray<int>* pAryMenu=NULL;
	CListBox* pListBox=NULL;
	GetTargetMenuaryAndListbox(wID, pAryMenu, pListBox);

	int nIndex = pListBox->GetCurSel();
	if (nIndex<0) return;
	if (nIndex>=(pListBox->GetCount()-1)) return;

	CString strKeep;
	pListBox->GetText(nIndex+1, strKeep);
	pListBox->DeleteString(nIndex+1);
	pListBox->InsertString(nIndex, strKeep);

	int nTemp = (*pAryMenu)[nIndex+1];
	(*pAryMenu)[nIndex+1] = (*pAryMenu)[nIndex];
	(*pAryMenu)[nIndex] = nTemp;
}

void CMenuPropertyPage::ShowSecondObjects(BOOL bShow)
{
	m_ltBack.ShowWindow(bShow);
	CWindow(GetDlgItem(IDC_BTN_UP2)).ShowWindow(bShow);
	CWindow(GetDlgItem(IDC_BTN_DOWN2)).ShowWindow(bShow);
	CWindow(GetDlgItem(IDC_BTN_ADD2)).ShowWindow(bShow);
	CWindow(GetDlgItem(IDC_BTN_DEL2)).ShowWindow(bShow);
	CWindow(GetDlgItem(IDC_STATIC_SECOND)).ShowWindow(bShow);

	if(bShow){
		CWindow(GetDlgItem(IDC_STATIC_FIRST)).SetWindowText(_T("�O���ǉ��R�}���h"));
	}else{
		CWindow(GetDlgItem(IDC_STATIC_FIRST)).SetWindowText(_T("���j���[�R�}���h"));
	}
}
