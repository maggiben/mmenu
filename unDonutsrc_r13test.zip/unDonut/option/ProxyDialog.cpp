#include "stdafx.h"
#include "ProxyDialog.h"
#include "../MtlPrivateProfile.h"
#include "../DonutPFunc.h"

using namespace MTL;

// Constructor
CProxyPropertyPage::CProxyPropertyPage()
{
	m_nRandTimeMin = 5;
	m_nRandTimeSec = 0;
	m_nRandChk = 0;
	m_nLocalChk = 0;
	m_nUseIE = 1;
}

// Overrides
BOOL CProxyPropertyPage::OnSetActive()
{
	SetModified(TRUE);

	if (m_editPrx.m_hWnd == NULL)
	{
		m_editPrx.Attach(GetDlgItem(IDC_EDIT1));
	}

	if (m_editNoPrx.m_hWnd == NULL)
	{
		m_editNoPrx.Attach(GetDlgItem(IDC_EDIT2));
	}

	if (m_editPrx.m_hWnd && m_editNoPrx.m_hWnd)
		_SetData();

	return DoDataExchange(FALSE);
}
BOOL CProxyPropertyPage::OnKillActive()
{
	return DoDataExchange(TRUE);
}
BOOL CProxyPropertyPage::OnApply()
{
	if (DoDataExchange(TRUE)) {
		_GetData();
		return TRUE;
	}
	else 
		return FALSE;
}

void CProxyPropertyPage::_GetData()
{
	CString strFile;
	strFile = _GetFilePath(_T("Proxy.ini"));
	CIniSection pr;

	//vvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvv
	// �v���L�V
	pr.Open(strFile, _T("PROXY"));
	int nLineCnt = m_editPrx.GetLineCount();
	pr.SetValue((DWORD)nLineCnt, _T("MAX"));
	for (int ii=0; ii<nLineCnt; ii++)
	{
		CString strKey;
		strKey.Format("%d", ii);

		char cBuff[MAX_PATH];
		memset(cBuff, 0, MAX_PATH);
		int nTextSize = m_editPrx.GetLine(ii, cBuff, MAX_PATH);
		cBuff[nTextSize] = '\0';

		CString strBuff(cBuff);
		pr.SetValue(strBuff, strKey);
	}
	pr.Close();
	//^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

	//vvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvv
	// �����_��
	pr.Open(strFile, _T("RAND"));
	pr.SetValue((DWORD)m_nRandChk, _T("Enabel"));
	pr.SetValue((DWORD)m_nRandTimeMin, _T("Min"));
	pr.SetValue((DWORD)m_nRandTimeSec, _T("Sec"));
	pr.Close();
	//^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

	//vvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvv
	// ��v���L�V
	pr.Open(strFile, _T("NOPROXY"));
	nLineCnt = m_editNoPrx.GetLineCount();
	pr.SetValue((DWORD)nLineCnt, _T("MAX"));
	for (ii=0; ii<nLineCnt; ii++)
	{
		CString strKey;
		strKey.Format("%d", ii);

		char cBuff[MAX_PATH];
		memset(cBuff, 0, MAX_PATH);
		int nTextSize = m_editNoPrx.GetLine(ii, cBuff, MAX_PATH);
		cBuff[nTextSize] = '\0';

		CString strBuff(cBuff);
		strBuff += _T("\n");
		pr.SetValue(strBuff, strKey);
	}
	pr.Close();
	//^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

	//vvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvv
	// ���[�J��
	pr.Open(strFile, _T("LOCAL"));
	pr.SetValue((DWORD)m_nLocalChk, _T("Enabel"));
	pr.Close();
	//^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

	//vvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvv
	// �h�d
	pr.Open(strFile, _T("USE_IE"));
	pr.SetValue((DWORD)m_nUseIE, _T("Enabel"));
	pr.Close();
	//^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
}

void CProxyPropertyPage::_SetData()
{
	CString strFile;
	strFile = _GetFilePath(_T("Proxy.ini"));
	CIniSection pr;

	//vvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvv
	// �v���L�V
	pr.Open(strFile, _T("PROXY"));
	DWORD dwLineCnt = 0;
	pr.QueryValue(dwLineCnt, _T("MAX"));
	m_editPrx.SetSelAll();
	for (int ii=0; ii<(int)dwLineCnt; ii++)
	{
		CString strKey;
		strKey.Format("%d", ii);

		TCHAR cBuff[MAX_PATH];
		DWORD dwCount=MAX_PATH;
		pr.QueryValue(cBuff, strKey, &dwCount);

		CString strProxy(cBuff);
		if (strProxy.IsEmpty()) continue;

		m_editPrx.ReplaceSel(cBuff);
		m_editPrx.ReplaceSel(_T("\r\n"));
	}
	pr.Close();
	//^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

	//vvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvv
	// �����_��
	pr.Open(strFile, _T("RAND"));

	DWORD dwRandChk=0;
	pr.QueryValue(dwRandChk, _T("Enabel"));
	m_nRandChk = dwRandChk;

	DWORD dwRandTimeMin = 5;
	pr.QueryValue(dwRandTimeMin, _T("Min"));
	m_nRandTimeMin = dwRandTimeMin;

	DWORD dwRandTimeSec = 0;
	pr.QueryValue(dwRandTimeSec, _T("Sec"));
	m_nRandTimeSec = dwRandTimeSec;

	pr.Close();
	//^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

	//vvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvv
	// ��v���L�V
	pr.Open(strFile, _T("NOPROXY"));
	dwLineCnt = 0;
	pr.QueryValue(dwLineCnt, _T("MAX"));
	m_editNoPrx.SetSelAll();
	for (ii=0; ii<(int)dwLineCnt; ii++)
	{
		CString strKey;
		strKey.Format("%d", ii);

		TCHAR cBuff[MAX_PATH];
		DWORD dwCount=MAX_PATH;
		pr.QueryValue(cBuff, strKey, &dwCount);

		CString strProxy(cBuff);
		if (strProxy.IsEmpty()) continue;

		m_editNoPrx.ReplaceSel(cBuff);
		m_editNoPrx.ReplaceSel(_T("\r\n"));
	}
	pr.Close();
	//^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

	//vvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvv
	// ���[�J��
	pr.Open(strFile, _T("LOCAL"));
	DWORD dwLocalChk=0;
	pr.QueryValue(dwLocalChk, _T("Enabel"));
	m_nLocalChk = dwLocalChk;
	pr.Close();
	//^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

	//vvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvv
	// ���[�J��
	pr.Open(strFile, _T("USE_IE"));
	DWORD dwUseIE=1;
	pr.QueryValue(dwUseIE, _T("Enabel"));
	m_nUseIE = dwUseIE;
	pr.Close();
	//^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
}

