#include "stdafx.h"
#include "ExplorerBarDialog.h"
#include "MainOption.h"
#include "../ItemIDList.h"


// Constructor
CExplorerPropertyPage::CExplorerPropertyPage()
{
	_SetData();
}

// Overrides
BOOL CExplorerPropertyPage::OnSetActive()
{
	SetModified(TRUE);
	return DoDataExchange(FALSE);
}

BOOL CExplorerPropertyPage::OnKillActive()
{
	return DoDataExchange(TRUE);
}

BOOL CExplorerPropertyPage::OnApply()
{
	if (DoDataExchange(TRUE)) {
		_GetData();
		return TRUE;
	}
	else 
		return FALSE;
}

void CExplorerPropertyPage::OnUserFolder(UINT wNotifyCode, int wID, HWND hWndCtl)
{
	CString strPath = _BrowseForFolder();
	if(!strPath.IsEmpty()){
		m_strUserFolder = strPath;
		DoDataExchange(FALSE);
	}
}

CString CExplorerPropertyPage::_BrowseForFolder()
{
	TCHAR pszDisplayName[MAX_PATH];

	BROWSEINFO bi = { m_hWnd, NULL, pszDisplayName, _T("���[�U�[��`�̂��C�ɓ���t�H���_"),
		BIF_RETURNONLYFSDIRS, NULL, 0, 0 };
	
	CItemIDList idl;
	idl.Attach(::SHBrowseForFolder(&bi));
	return idl.GetPath();
}

void CExplorerPropertyPage::_GetData()
{
	CMainOption::s_dwExplorerBarStyle = 0;
	if (m_nExplorerHScroll==1)
		CMainOption::s_dwExplorerBarStyle |= MAIN_EXPLORER_HSCROLL;
	if (m_nExplorerNoSpace==1)
		CMainOption::s_dwExplorerBarStyle |= MAIN_EXPLORER_NOSPACE;
	if (m_nExplorerOrgImage==1)
		CMainOption::s_dwExplorerBarStyle |= MAIN_EXPLORER_FAV_ORGIMG;

	*CMainOption::s_pstrExplorerUserDirectory = m_strUserFolder;
}

void CExplorerPropertyPage::_SetData()
{
	m_nExplorerHScroll = CMainOption::s_dwExplorerBarStyle & MAIN_EXPLORER_HSCROLL ? 1:0;
	m_nExplorerNoSpace = CMainOption::s_dwExplorerBarStyle & MAIN_EXPLORER_NOSPACE ? 1:0;
	m_nExplorerOrgImage = CMainOption::s_dwExplorerBarStyle & MAIN_EXPLORER_FAV_ORGIMG ? 1:0;

	m_strUserFolder = *CMainOption::s_pstrExplorerUserDirectory;
}
