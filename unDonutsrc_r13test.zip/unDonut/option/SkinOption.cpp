#include "stdafx.h"
#include "SkinOption.h"
#include "../DonutPFunc.h"
#include "../DonutDefine.h"

using namespace MTL;

////////////////////////////////////////////////////////////////////////////////
//CSkinPropertyPage�̒�`
////////////////////////////////////////////////////////////////////////////////

int CSkinOption::s_nComboStyle = SKN_COMBO_STYLE_DEFAULT;
int CSkinOption::s_nTabStyle = SKN_TAB_STYLE_DEFAULT;
int CSkinOption::s_nRebarBGStyle = SKN_REBAR_STYLE_TILE;
int CSkinOption::s_nRebarNoBoader = SKN_CONST_NO_INT;
int CSkinOption::s_nStatusStyle = SKN_STATUS_STYLE_TILE;

int CSkinOption::GetIntegerFromStringConst(CString &strConst)
{
	if(strConst == SKN_CONST_DEFAULT)
		return SKN_CONST_DEFAULT_INT;
	else if(strConst == SKN_CONST_CLASSIC)
		return SKN_CONST_CLASSIC_INT;
	else if(strConst == SKN_CONST_THEME)
		return SKN_CONST_THEME_INT;
	else if(strConst == SKN_CONST_TILE)
		return SKN_CONST_TILE_INT;
	else if(strConst == SKN_CONST_STRETCH)
		return SKN_CONST_STRETCH_INT;
	else if(strConst == SKN_CONST_YES)
		return SKN_CONST_YES_INT;
	else if(strConst == SKN_CONST_NO)
		return SKN_CONST_NO_INT;
	else
		return 0;
}

void CSkinOption::GetProfile()
{	
	CIniSection pr;
	CString strSkinPath = _GetSkinDir() + "skin.ini";

	pr.Open(strSkinPath,_T("Interface"));
	s_nTabStyle = QueryValueCustom(pr,_T("TabStyle"));
	s_nComboStyle = QueryValueCustom(pr,_T("ComboStyle"));
	s_nRebarBGStyle = QueryValueCustom(pr,_T("RebarBGStyle"));
	s_nRebarNoBoader = QueryValueCustom(pr,_T("RebarNoBoader"));
	s_nStatusStyle = QueryValueCustom(pr,_T("StatusStyle"));
	pr.Close();

}

int CSkinOption::QueryValueCustom(CIniSection& pr,LPCTSTR lpKey)
{
	CString strValue;
	DWORD dwCount = MAX_PATH;
	pr.QueryValue(strValue.GetBuffer(MAX_PATH),lpKey,&dwCount);
	strValue.ReleaseBuffer();
	return GetIntegerFromStringConst(strValue);
}




////////////////////////////////////////////////////////////////////////////////
//CSkinPropertyPage�̒�`
////////////////////////////////////////////////////////////////////////////////

CSkinPropertyPage::CSkinPropertyPage(HWND hTopWindow, BOOL *pbSkinChange) : m_bInit(FALSE) , m_hTopWindow(hTopWindow) , m_pbChanged(pbSkinChange)
{
}

void CSkinPropertyPage::_SetData()
{

	CString strPath = _GetSkinDir();
	strPath.TrimRight(_T("\\"));
	strPath = strPath.Mid(strPath.ReverseFind('\\')+1);

	CStatic stName = GetDlgItem(IDC_STATIC_NAME);
	CStatic stDesc = GetDlgItem(IDC_STATIC_DESC);
	CListBox List = GetDlgItem(IDC_LIST_SKIN);
	
	stName.SetWindowText(strPath);

	//�t�H���_���
	CString strSkinPath = _GetDonutPath() + _T("Skin\\*");
	CFindFile find;
	if(find.FindFile(strSkinPath))
	{
		do {
			if(find.IsDirectory()){
				CString strTitle = find.GetFileTitle();
				if(strTitle != _T("") && strTitle != _T(".")){
					int nRet = List.AddString(find.GetFileTitle());
					LPTSTR lpstr = _AllocString(); //new�Ŋm�� �K��_FreeString���ĂԂ���
					CString strFilePath = find.GetFilePath();
					lstrcpy(lpstr,strFilePath.GetBuffer(0));
					List.SetItemData(nRet,(DWORD)lpstr);
				}
			}
		} while(find.FindNextFile());
		find.Close();
	}
	List.SetCurSel(0);
	BOOL bHandled=FALSE;
	OnSelChanged(0,0,NULL,bHandled); 

}

LRESULT CSkinPropertyPage::OnSelChanged(WORD wNotifyCode, WORD wID, HWND hWndCtl, BOOL& bHandled)
{
	CStatic label = GetDlgItem(IDC_STATIC_DESC);
	CListBox List = GetDlgItem(IDC_LIST_SKIN);
	int nIndex = List.GetCurSel();
	if(nIndex == LB_ERR) return 0;

	CIniSection pr;
	CString strSkinPath = (LPTSTR)List.GetItemData(nIndex);
	strSkinPath += _T("\\Skin.ini");
	pr.Open(strSkinPath,_T("Interface"));
	CString strBuf;
	DWORD dwSize=1024;
	pr.QueryValue(strBuf.GetBuffer(1024),_T("Description"),&dwSize);
	strBuf.ReleaseBuffer();
	pr.Close();
	strBuf.Replace(_T("\\n"),_T("\r\n"));

	label.SetWindowText(strBuf);

	return 0;
}


LRESULT CSkinPropertyPage::OnDestroy(UINT /*uMsg*/, WPARAM /*wParam*/, LPARAM /*lParam*/, BOOL& /*bHandled*/)
{
	CListBox List = GetDlgItem(IDC_LIST_SKIN);
	int nCount = List.GetCount();
	for(int i=0; i<nCount; i++){
		LPTSTR lpstr = (LPTSTR)List.GetItemData(i);
		_FreeString(lpstr);
	}
	return 1;
}

LRESULT CSkinPropertyPage::OnSkinApply(WORD /*wNotifyCode*/, WORD wID, HWND /*hWndCtl*/, BOOL& /*bHandled*/)
{
	CListBox List = GetDlgItem(IDC_LIST_SKIN);
	int index = List.GetCurSel();
	if(index == LB_ERR) return 0;
	CString strPath = (LPTSTR)List.GetItemData(index);
	
	CString strSkinPath = _GetDonutPath() + _T("Skin\\");
	if(strPath.Find(strSkinPath) == 0){
		CString strName = strPath.Mid(strSkinPath.GetLength());
		if(!strName.IsEmpty()){
			CIniSection pr;
			pr.Open(_szIniFileName,_T("Skin"));
			pr.SetValue(strName,_T("SkinFolder"));
			pr.Close();
			::SendMessage(m_hTopWindow,WM_CHANGE_SKIN,0,0);
			if(m_pbChanged)
				*m_pbChanged = TRUE;
		}
	}
	return 0;
}

BOOL CSkinPropertyPage::OnSetActive()
{
	if(!m_bInit){
		m_bInit = TRUE;
		_SetData();
	}
	SetModified(TRUE);
	return TRUE;
}

LPTSTR CSkinPropertyPage::_AllocString()
{
	return new TCHAR[MAX_PATH];
}

void CSkinPropertyPage::_FreeString(LPTSTR lpstr)
{
	delete [] lpstr;
}

