#pragma once

#include "../RecentDocumentListFixed.h"
#include "../MtlUpdateCmdUI.h"
#include "../MtlProfile.h"
#include "../MtlUser.h"

#define MAIN_EX_NEWWINDOW			0x00000001L
#define MAIN_EX_NOACTIVATE			0x00000002L
// #define MAIN_EX_NOINITWND	0x00000004L obsolete
#define MAIN_EX_ONEINSTANCE			0x00000008L
#define MAIN_EX_WINDOWLIMIT			0x00000010L
#define MAIN_EX_NOCLOSEDFG			0x00000020L
#define MAIN_EX_NOMDI				0x00000040L
// #define MAIN_EX_VIEWCLIPBOARD		0x00000080L
#define MAIN_EX_FULLSCREEN			0x00000100L
#define MAIN_EX_BACKUP				0x00000200L
#define MAIN_EX_NOACTIVATE_NEWWIN	0x00000400L
#define MAIN_EX_ADDFAVORITEOLDSHELL	0x00000800L
#define MAIN_EX_ORGFAVORITEOLDSHELL	0x00001000L
#define MAIN_EX_GLOBALOFFLINE		0x00002000L
#define MAIN_EX_LOADGLOBALOFFLINE	0x00004000L
#define MAIN_EX_KILLDIALOG			0x00008000L
#define MAIN_EX_REGISTER_AS_BROWSER	0x00010000L
#define MAIN_EX_INHERIT_OPTIONS		0x00020000L 
//#define MAIN_EX_OPTIONSTYLE			0x00040000L

#define MAIN_EX2_NOCSTMMENU			0x00000001L
#define MAIN_EX2_DEL_CASH			0x00000002L
#define MAIN_EX2_DEL_COOKIE			0x00000004L
#define MAIN_EX2_DEL_HISTORY		0x00000008L
#define MAIN_EX2_MAKECASH			0x00000010L
#define MAIN_EX2_DEL_RECENTCLOSE	0x00000020L


class CMainOption
{
public:
	static DWORD s_dwMainExtendedStyle;
	static DWORD s_dwMainExtendedStyle2;
	static DWORD s_dwExplorerBarStyle;
	static DWORD s_dwMaxWindowCount;
	static DWORD s_dwBackUpTime;
	static DWORD s_dwAutoRefreshTime; // UDT DGSTR ( dai
	static bool s_bTabMode;
	static bool s_bAppClosing;
	static bool s_bIgnoreUpdateClipboard;// for insane WM_DRAWCLIBOARD
	static CRecentDocumentListFixed* s_pMru;
	static bool s_bNoCstmMenu;
	static DWORD s_dwErrorBlock;
	static CString *s_pstrExplorerUserDirectory;
	static bool s_bTravelLogGroup;
	static bool s_bTravelLogClose;
	static bool s_bStretchImage;

	// Constructor
	CMainOption();

	static void GetProfile();
	static void WriteProfile();
	static void SetExplorerUserDirectory(CString& strPath);
	static CString GetExplorerUserDirectory();
	static void SetMRUMenuHandle(HMENU hMenu, int nPos);
	static bool IsQualify(int nWindowCount);

// Message map and handlers
	BEGIN_MSG_MAP(CMainFrame)
		COMMAND_ID_HANDLER_EX(ID_MAIN_EX_NEWWINDOW, OnMainExNewWindow)
		COMMAND_ID_HANDLER_EX(ID_MAIN_EX_NOACTIVATE, OnMainExNoActivate)
		COMMAND_ID_HANDLER_EX(ID_MAIN_EX_NOACTIVATE_NEWWIN, OnMainExNoActivateNewWin)
	END_MSG_MAP()

	void OnMainExNewWindow(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/);
	void OnMainExNoActivate(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/);
	void OnMainExNoActivateNewWin(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/);

// Update command UI and handlers
	BEGIN_UPDATE_COMMAND_UI_MAP(CMainOption)
		UPDATE_COMMAND_UI_SETCHECK_FLAG(ID_MAIN_EX_NEWWINDOW, MAIN_EX_NEWWINDOW, s_dwMainExtendedStyle)
		UPDATE_COMMAND_UI_SETCHECK_FLAG(ID_MAIN_EX_NOACTIVATE, MAIN_EX_NOACTIVATE, s_dwMainExtendedStyle)
		UPDATE_COMMAND_UI_SETCHECK_FLAG(ID_MAIN_EX_NOACTIVATE_NEWWIN, MAIN_EX_NOACTIVATE_NEWWIN, s_dwMainExtendedStyle)
		UPDATE_COMMAND_UI_SETCHECK_FLAG(ID_REGISTER_AS_BROWSER, MAIN_EX_REGISTER_AS_BROWSER, s_dwMainExtendedStyle)
	END_UPDATE_COMMAND_UI_MAP()
};



class CMainPropertyPage : public CPropertyPageImpl<CMainPropertyPage>,
	public CWinDataExchange<CMainPropertyPage>
{
public:
// Constants
	enum { IDD = IDD_PROPPAGE_MAIN };

// Data members
	int m_nNewWindow, m_nNoActivate, m_nNoActivateNewWin,
		m_nOneInstance, m_nLimit, m_nNoCloseDFG, m_nNoMDI, m_nBackUp,
		m_nAddFavoriteOldShell, m_nOrgFavoriteOldShell, m_nRegisterAsBrowser;
	int m_nMaxWindowCount, m_nBackUpTime;
	int m_nAutoRefreshTime, m_nAutoRefTimeMin, m_nAutoRefTimeSec; // UDT DGSTR ( dai
	int m_nLoadGlobalOffline, m_nKillDialog;
	int m_nInheritOptions;
	int m_nOptionStyle;
	CWindow m_wnd;
	MTL::CLogFont m_lf;

// DDX map
	BEGIN_DDX_MAP(CMainPropertyPage)
		DDX_CHECK(IDC_CHECK_MAIN_NEWWINDOW, m_nNewWindow)
		DDX_CHECK(IDC_CHECK_MAIN_NOACTIVATE, m_nNoActivate)
		DDX_CHECK(IDC_CHECK_MAIN_NOACTIVATE_NEWWIN, m_nNoActivateNewWin)
		DDX_CHECK(IDC_CHECK_MAIN_NOMDI, m_nNoMDI)
		DDX_CHECK(IDC_CHECK_MAIN_INHERIT_OPTIONS, m_nInheritOptions)
		DDX_CHECK(IDC_CHECK_ONEINSTANCE, m_nOneInstance)
		DDX_CHECK(IDC_CHECK_MAIN_LIMIT, m_nLimit)
		DDX_CHECK(IDC_CHECK_MAIN_BACKUP, m_nBackUp)
		DDX_CHECK(IDC_CHECK_MAIN_NOCLOSEDFG, m_nNoCloseDFG)
		DDX_CHECK(IDC_CHECK_MAIN_ADDFAVORITEOLDSHELL, m_nAddFavoriteOldShell)
		DDX_CHECK(IDC_CHECK_MAIN_ORGFAVORITEOLDSHELL, m_nOrgFavoriteOldShell)
		DDX_CHECK(IDC_CHECK_MAIN_LOADGLOBALOFFLINE, m_nLoadGlobalOffline)
		DDX_CHECK(IDC_CHECK_MAIN_KILLDIALOG, m_nKillDialog)
		DDX_CHECK(IDC_CHECK_MAIN_REGISTER_AS_BROWSER, m_nRegisterAsBrowser)
		DDX_INT_RANGE(IDC_EDIT_MAIN_LIMITEDCOUNT, m_nMaxWindowCount, 0, 255)
		DDX_INT_RANGE(IDC_EDIT_MAIN_BACKUPTIME, m_nBackUpTime, 1, 120)

		// UDT DGSTR ( dai
		DDX_INT_RANGE(IDC_EDIT_MAIN_AUTOREFRESHTIME_MIN, m_nAutoRefTimeMin, 0, 59) 
		DDX_INT_RANGE(IDC_EDIT_MAIN_AUTOREFRESHTIME_SEC, m_nAutoRefTimeSec, 0, 59) 
		// ENDE

END_DDX_MAP()

// Message map and handlers
	BEGIN_MSG_MAP(CMainPropertyPage)
		COMMAND_ID_HANDLER_EX(IDC_BUTTON_BAR_FONT, OnFont)
		CHAIN_MSG_MAP(CPropertyPageImpl<CMainPropertyPage>)
	END_MSG_MAP()

	void OnFont(WORD /*wNotifyCode*/, WORD /*wID*/, HWND hWndCtl);

// Constructor
	CMainPropertyPage(HWND hWnd);

// Overrides
	BOOL OnSetActive();
	BOOL OnKillActive();
	BOOL OnApply();

// Implementation
protected:
	void _GetData();
	void _SetData();
};



class CMainPropertyPage2 : public CInitPropertyPageImpl<CMainPropertyPage2>,//public CPropertyPageImpl<CMainPropertyPage2>,
	public CWinDataExchange<CMainPropertyPage2>
{
public:
// Constants
	enum { IDD = IDD_PROPPAGE_MAIN2 };
	CWindow m_wnd;

	// UH
	int m_nDelCash, m_nDelCookie, m_nDelHistory;
	int m_nMakeCash;
	WORD m_nSzPain1, m_nSzPain2;
	int m_nChkSwapPain;

	int m_nShowMenu, m_nShowToolBar, m_nShowAdress;
	int m_nShowTab, m_nShowLink, m_nShowSearch, m_nShowStatus;
	int m_nTravelLogGroup, m_nTravelLogClose;

	int m_nMRUMenuType;
	int m_nMRUCount, m_nMRUCountMin, m_nMRUCountMax;

	BOOL m_bInit;

// DDX map
	BEGIN_DDX_MAP(CMainPropertyPage2)
		DDX_CHECK(IDC_CHECK_MAIN_DEL_CASH, m_nDelCash)
		DDX_CHECK(IDC_CHECK_MAIN_DEL_COOKIE, m_nDelCookie)
		DDX_CHECK(IDC_CHECK_MAIN_DEL_HISTORY, m_nDelHistory)
		DDX_CHECK(IDC_CHECK_MAIN_MAKECASH, m_nMakeCash)

		DDX_UINT(IDC_EDIT_SZ_PAIN1, m_nSzPain1)
		DDX_UINT(IDC_EDIT_SZ_PAIN2, m_nSzPain2)
		DDX_CHECK(IDC_CHK_SWAP_PAIN, m_nChkSwapPain)

		DDX_CHECK(IDC_CHK_MENU, m_nShowMenu)
		DDX_CHECK(IDC_CHK_TOOLBAR, m_nShowToolBar)
		DDX_CHECK(IDC_CHK_ADRESS, m_nShowAdress)
		DDX_CHECK(IDC_CHK_TAB, m_nShowTab)
		DDX_CHECK(IDC_CHK_LINK, m_nShowLink)
		DDX_CHECK(IDC_CHK_SEARCH, m_nShowSearch)
		DDX_CHECK(IDC_CHK_STATUS, m_nShowStatus)

		DDX_CHECK(IDC_TRAVELLOG_GROUP, m_nTravelLogGroup)
		DDX_CHECK(IDC_TRAVELLOG_CLOSE, m_nTravelLogClose)

		DDX_INT_RANGE(IDC_EDIT_MRUCOUNT,m_nMRUCount,m_nMRUCountMin,m_nMRUCountMax)
		DDX_CBINDEX(IDC_COMBO_MRU_MENUTYPE, m_nMRUMenuType)
	END_DDX_MAP()

// Message map and handlers
	BEGIN_MSG_MAP(CMainPropertyPage2)
		CHAIN_MSG_MAP(CPropertyPageImpl<CMainPropertyPage2>)
	END_MSG_MAP()

	static int CALLBACK BrowseCallbackProc(HWND hwnd,UINT uMsg,LPARAM lParam,LPARAM lpData);

	CString BrowseForFolder(CString strTitle, CString strNowPath);

// Constructor
	CMainPropertyPage2(HWND hWnd);

// Overrides
	BOOL OnSetActive();
	BOOL OnKillActive();
	BOOL OnApply();
	
protected:
	void _GetData();
	void _SetData();
	void InitCtrls();
};
