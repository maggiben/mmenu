#ifndef __CMBBOXPRXY_H__
#define __CMBBOXPRXY_H__

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
#include <time.h>

/*
	CComboBoxPrxy

*/

#include "FlatComboBox.h"

//CComboBoxPrxy ReWrite ver
class CComboBoxPrxyR : public CFlatComboBox
{
public:
	UINT m_nIDEvent;
	BOOL m_bUseIE;


	CComboBoxPrxyR();

	BEGIN_MSG_MAP(CComboBoxPrxyR)
		MESSAGE_HANDLER(WM_RBUTTONDOWN, OnRButtonDown)
		MESSAGE_HANDLER(WM_COMMAND, OnCommand)

		MSG_WM_TIMER(OnTimer)
		CHAIN_MSG_MAP(CFlatComboBox)
	END_MSG_MAP()

	LRESULT OnCommand(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled);
	LRESULT OnRButtonDown(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled);
	void OnTimer(UINT wTimerID, TIMERPROC);
	void OnSelectChange();

	void ChangeProxy(int nIndex);
	void SetProxy();
	void ResetProxyList();
	void ResetTimer();

	// �h�d���g��
	BOOL UseIE();
	// �o�C�p�X�𓾂�
	CString GetBypass();
};



#endif
