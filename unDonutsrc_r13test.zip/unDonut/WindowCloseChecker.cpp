#include "stdafx.h"
#include "WindowCloseChecker.h"

bool CWindowCloseChecker::s_bClose = false;

void CWindowCloseChecker::Close()
{
	s_bClose = true;
}

bool CWindowCloseChecker::IsClosing()
{
	return s_bClose;
}