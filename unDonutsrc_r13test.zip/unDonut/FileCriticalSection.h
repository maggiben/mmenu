
#pragma once

class CFileCriticalSection
{

public:
	static CRITICAL_SECTION *m_pcs;

	static void Init()
	{
		m_pcs = new CRITICAL_SECTION;
		if(!m_pcs) return;
		::InitializeCriticalSection(m_pcs);
	}

	static void Term()
	{
		if(!m_pcs) return;
		::DeleteCriticalSection(m_pcs);
		delete m_pcs;
	}

};
_declspec(selectany) CRITICAL_SECTION *CFileCriticalSection::m_pcs = NULL;

class CLockFileOperation
{
	
public:
	CLockFileOperation()
	{
		if(CFileCriticalSection::m_pcs)
			::EnterCriticalSection(CFileCriticalSection::m_pcs);
	}

	~CLockFileOperation()
	{
		if(CFileCriticalSection::m_pcs)
			::LeaveCriticalSection(CFileCriticalSection::m_pcs);
	}

};