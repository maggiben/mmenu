#include "stdafx.h"
#include "DockingPluginManager.h"
#include "PluginManager.h"




CDockingPluginWindow::CDockingPluginWindow()
	: m_hWndPlugin(NULL)
{
}

LRESULT CDockingPluginWindow::OnSize(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
{
	bHandled = FALSE;
	Resize();
	return 0;
}

void CDockingPluginWindow::SetPluginWindow(HWND hWndPlugin)
{
	m_hWndPlugin = hWndPlugin;
	::SetParent(hWndPlugin,m_hWnd);
	::ShowWindow(hWndPlugin,SW_SHOW);
	Resize();
}

void CDockingPluginWindow::Resize()
{
	CRect rcClient;
	GetClientRect(&rcClient);
	::MoveWindow(m_hWndPlugin,0,0,rcClient.Width(),rcClient.Height(),TRUE);
}









CDockingPluginManager::CDockingPluginManager()
{
}

CDockingPluginManager::~CDockingPluginManager()
{
	Clear();
}

bool CDockingPluginManager::Init(HWND hWndFrame, CMenuHandle& menu)
{
	//�v���O�C�����ڂ�ǉ����邽�߂̃��j���[���擾
	CMenuHandle menuView; menuView = menu.GetSubMenu(cnt_menu_view_pos);
	if(!menuView.m_hMenu) return false;
	CMenuHandle menuDocking; menuDocking = menuView.GetSubMenu(cnt_menu_docking_pos);
	if(!menuDocking.m_hMenu) return false;

	//�h�b�L���O�v���O�C���̃��[�h�Ƒg�ݍ���
	CPluginManager::ReadPluginData(PLT_DOCKINGBAR,hWndFrame);
	CPluginManager::LoadAllPlugin(PLT_DOCKINGBAR,hWndFrame,true);
	int nCount = CPluginManager::GetCount(PLT_DOCKINGBAR);
	for(int i=0, j=0; i<nCount; i++){
		HWND hPluginWindow = CPluginManager::GetHWND(PLT_DOCKINGBAR,i);
		if(!hPluginWindow) continue;
		try{
			//�v���O�C���̑g�ݍ���
			CDockingPluginWindow *pWindow = new CDockingPluginWindow;

			/* �n���h�����T�u�N���X�����đg�ݍ��݂����������A�ǂ����Ă���肭�s���Ȃ�
			   �܂����Ԃ����B�c�O����������߁A���ԂɓK���ȃE�B���h�E��u�����Ƃɂ����B
			HWND hWndParent = ::GetParent(hPluginWindow);
			::InvalidateRect(hPluginWindow,NULL,TRUE);
			pWindow->AttachToDockingSystem(hWndFrame,hPluginWindow);
			::SetWindowPos(hPluginWindow,HWND_TOP,0,0,0,0,SWP_NOSIZE|SWP_NOMOVE);
			::SetWindowLong(hPluginWindow,GWL_STYLE,pWindow->GetWndStyle(0));
			::SetWindowLong(hPluginWindow,GWL_EXSTYLE,pWindow->GetWndExStyle(0));
			::SetParent(hPluginWindow,hWndParent);*/

			CRect rc; ::GetClientRect(hPluginWindow,&rc);
			pWindow->Create(hWndFrame,rc,CPluginManager::GetCaption(PLT_DOCKINGBAR,i));
			pWindow->ShowWindow(SW_SHOW);
			pWindow->SetPluginWindow(hPluginWindow);
			m_vecWindow.push_back(pWindow);
			//���j���[�ւ̑g�ݍ���
			BOOL bRet = menuDocking.AppendMenu(MF_STRING|MF_ENABLED,ID_DOCKINGPLUGIN_FIRST+j,
				CPluginManager::GetCaption(PLT_DOCKINGBAR,i));
			j++;
		}catch(...){
			return false;
		}
	}
	return true;
}

bool CDockingPluginManager::Clear()
{
	std::vector<CDockingPluginWindow*>::iterator it = m_vecWindow.begin();
	while(it!=m_vecWindow.end()){
		CDockingPluginWindow *pWindow = *it;
		pWindow->Detach();
		delete pWindow;
		it++;
	}
	return true;
}

BOOL CDockingPluginManager::PreTranslateMessage(MSG *pMsg)
{
	if ((WM_KEYFIRST <= pMsg->message) && (pMsg->message <= WM_KEYLAST)){
		int nCount = CPluginManager::GetCount(PLT_DOCKINGBAR);
		for(int i=0; i<nCount; i++){
			if(CPluginManager::Call_PreTranslateMessage(PLT_DOCKINGBAR,i,pMsg))
				return TRUE;
		}
	}
	return FALSE;
}

int CDockingPluginManager::GetCount()
{
	return (int)m_vecWindow.size();
}

CDockingPluginWindow* CDockingPluginManager::GetWindow(int nIndex)
{
	if(nIndex<0 || (int)m_vecWindow.size()<=nIndex)
		return NULL;
	return m_vecWindow[nIndex];
}

LRESULT CDockingPluginManager::OnDockingPluginMenu(WORD /*wNotifyCode*/, WORD wID, HWND /*hWndCtl*/, BOOL& /*bHandled*/)
{
	int nIndex = wID-ID_DOCKINGPLUGIN_FIRST;
	CDockingPluginWindow *pWindow = GetWindow(nIndex);
	if(!pWindow) return 0;
	pWindow->Toggle();
	return 0;
}

BOOL CDockingPluginManager::OnUpdateDockingMenuState(int nIndex, CCmdUI* pCmdUI)
{
	CDockingPluginWindow *pWindow = GetWindow(nIndex);
	if(!pWindow) return FALSE;
	pCmdUI->SetCheck(pWindow->IsWindowVisible()?1:0);
	return TRUE;
}









