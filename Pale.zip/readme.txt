PALE

Palette/Gradient editor for 256 colours.

Demonstrates custom controls,
& use of owner-drawn buttons

Can load/save several palette formats

Any comments/advice/improvments appreciated.

Luke

15/07/2003

lukehudson@mail.com