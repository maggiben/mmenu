#ifndef BMP_F_HEADER
#define BMP_F_HEADER

#include <windows.h>

typedef unsigned char byte;

typedef struct Bitmap_tag
{
	int		width;
	int		height;
	int		depth;
	PALETTEENTRY	*pal;
	byte	*bits;
} Bitmap, *BitmapPtr;



#ifndef DllExport
#define DllExport    extern __declspec( dllexport )
#endif

DllExport    BitmapPtr Create_Bmp(int cx, int cy, int iDepth);
DllExport    void Destroy_Bmp(BitmapPtr pbm);
DllExport    void Flip_Bmp(BitmapPtr hbm);
DllExport    BitmapPtr Load_Bmp(const char *pszName);
DllExport    int Save_Bmp(BitmapPtr hBmp, const char *pszName);
DllExport    int	Copy_Bmp(BitmapPtr bpDest, int x, int y, BitmapPtr bpSrc);

#endif

