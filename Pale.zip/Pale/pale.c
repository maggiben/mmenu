#include <windows.h>
#include <windowsx.h>
#include <dlgs.h>
#include <commctrl.h>
#include <string.h>
#include <stdio.h>
#include <math.h>
#include <assert.h>
#include "lhclib.h"
#include "skindll.h"
#include "paleres.h"
#include "grad.h"

#define qErr(msg)   {	\
	Error_Quit(NULL, 0, "%s\r\nLine %d in file %s\r\nSystem responded: %s",		\
			msg, __LINE__, __FILE__, Get_Error_Msg());							\
}



HINSTANCE hInst = NULL;
COLORREF colour=0;
HWND hwGrad = NULL;
HWND hwDlg = NULL;

// utility function
// draw a rectangle of specified colour
void ColorRect(HDC hdc, LPRECT r, COLORREF col)
{
	HBRUSH hBr;
	hBr = CreateSolidBrush(col);
	if(!hBr)	qErr("createsolidbrush failed");
	FillRect(hdc, r, hBr);
	DeleteObject(hBr);
}
// different palette types and descriptions for load dialog box
enum { PL_NORMAL, PL_EP63, PL_JASC, PL_MICROSOFT};
char *ptypeStrings[] = {"Pale raw 8bit", "Editpal 6bit values", "Paint shop pro", "Microsoft"};
// ditto for save
enum { PS_NORMAL, PS_EP63, PS_JASC, PS_C };
char *stypeStrings[] = {"Pale raw 8bit", "Editpal 6bit values", "Paint shop pro", "C code"};


int LoadPalType = PL_NORMAL;
int SavePalType = PS_NORMAL;

// load/save flag for custom dialog procedure
int PTLoad = 0;


// custom dialog box procedure
// see SDK for GetOpenFileName()
UINT_PTR CALLBACK myPromptHook(
  HWND hdlg,      // handle to child dialog box
  UINT uiMsg,     // message identifier
  WPARAM wParam,  // message parameter
  LPARAM lParam   // message parameter
){

	LPNMHDR pnh;
	static HWND hwCB;

	switch(uiMsg){
		case WM_INITDIALOG:
			// initialise our combobox
			hwCB = GetDlgItem(hdlg, IDC_PALTYPE);
			if(PTLoad){
				for(int i = 0; i <= PL_MICROSOFT; i++)
					SendMessage(hwCB, CB_ADDSTRING, 0, (LPARAM)ptypeStrings[i]);
				SendMessage(hwCB, CB_SELECTSTRING, -1, (LPARAM)ptypeStrings[LoadPalType]);
			}
			else {
				for(int i = 0; i <= PS_C; i++)
					SendMessage(hwCB, CB_ADDSTRING, 0, (LPARAM)stypeStrings[i]);
				SendMessage(hwCB, CB_SELECTSTRING, -1, (LPARAM)stypeStrings[SavePalType]);
			}
			return 1;
		case WM_COMMAND:
			if(LOWORD(wParam) != IDC_PALTYPE) break;
			switch(HIWORD(wParam)){
				case CBN_SELCHANGE:
					if(PTLoad)
						LoadPalType = SendMessage(hwCB, CB_GETCURSEL,0,0);
					else {
						SavePalType = SendMessage(hwCB, CB_GETCURSEL,0,0);
						// this is a bit of a fiddle
						// in order to change the file type when we change our palette
						// loading/saving format
						if(SavePalType == PS_C){
							SendMessage(GetParent(hdlg), CDM_SETDEFEXT, 0, (LPARAM)"h\0");
							SendMessage(GetDlgItem(GetParent(hdlg), cmb1), CB_SELECTSTRING, -1, (LPARAM)"C Source");
							SendMessage(GetParent(hdlg),
									WM_COMMAND, MAKEWPARAM(cmb1, CBN_SELENDOK),
									(LPARAM)GetDlgItem(GetParent(hdlg), cmb1)
								);
						}
						else {
							SendMessage(GetParent(hdlg), CDM_SETDEFEXT, 0, (LPARAM)"pal\0");
							SendMessage(GetDlgItem(GetParent(hdlg), cmb1), CB_SELECTSTRING, -1, (LPARAM)"Palette");
							SendMessage(GetParent(hdlg),
									WM_COMMAND, MAKEWPARAM(cmb1, CBN_SELENDOK),
									(LPARAM)GetDlgItem(GetParent(hdlg), cmb1)
								);
						}
					}
					break;
			}
			break;
	}
	return 0;
}

// quick defs of mode flag
enum {SAVEFILE, OPENFILE};

// prompt for a file name for load/save, using our custom dialog box procedure above
char *myPromptFile(int isOpen, HWND hwOwner, char *pszFilter, char *pszTitle){
	int i;
	static char szFileName[MAX_PATH];			// store selected file
	char szDefFilter[] = "All Files\0*.*\0\0";	// default filter
	OPENFILENAME ofn;

	ZeroMemory(&ofn, sizeof(ofn));
	ofn.lStructSize = sizeof(ofn);

	szFileName[0] = 0; // mark the file name buffer as empty;

	ofn.hwndOwner = hwOwner;
	// If a filter is supplied, use it.  Otherwise, use default.
	ofn.lpstrFilter = (pszFilter) ? pszFilter : szDefFilter;
	ofn.lpstrFile = szFileName;		// where to store filename
	ofn.nMaxFile = MAX_PATH;		// length of filename buffer
	ofn.lpstrTitle = pszTitle;		// title if supplied
	ofn.lpTemplateName = MAKEINTRESOURCE(IDD_OPNDLG);
	ofn.hInstance = hInst;
	ofn.lpfnHook = myPromptHook;
	if(!isOpen)
	{
		ofn.Flags = OFN_EXPLORER	// use new features
					| OFN_CREATEPROMPT	// create files if user wishes
					| OFN_ENABLETEMPLATE
					| OFN_ENABLEHOOK
					| OFN_OVERWRITEPROMPT
					| OFN_PATHMUSTEXIST // what it says
					| OFN_HIDEREADONLY; // hide the read-only option
		if(pszFilter)
		{
			for(i=0; pszFilter[i]!=0; i++)
				;
			i++;
			char *sp= strchr(&pszFilter[i], '.');
			if(sp)
				ofn.lpstrDefExt = sp+1;
		}
		PTLoad = 0;
		if(!GetSaveFileName(&ofn))
			return NULL;
		return szFileName;
	}
	else {
		ofn.Flags = OFN_EXPLORER	// use new features
					| OFN_FILEMUSTEXIST	// file names must be valid
					| OFN_PATHMUSTEXIST // and paths too.
					| OFN_ENABLETEMPLATE
					| OFN_ENABLEHOOK
					| OFN_HIDEREADONLY; // hide the read-only option
		PTLoad = 1;
		if(!GetOpenFileName(&ofn))
			return NULL;
	}
		return szFileName;
	/*	MSG msg;
	while (PeekMessage(&msg, hwOwner, WM_MOUSEFIRST, WM_MOUSELAST, PM_REMOVE));*/
}


// load raw 768 byte palette
// where each byte is only 0-63
// This format was used by a dos util I had called Editpal
// I think it's what allegro for djgpp was using
int loadEP63Pal(FILE *f, COLORREF *clut){
	for(int i = 0; i<256; i++){
		int r = fgetc(f), g = fgetc(f), b = fgetc(f);
		r<<=2; g<<=2; b<<=2;
		clut[i] = RGB(r,g,b);
	}
	return 1;
}
// load paint shop pro palettes
int loadJASCPal(FILE *f, COLORREF *clut){
	int i,c;
	for(i=1; i<=3; i++)
		for(c = fgetc(f); c!='\n';	c=fgetc(f))
			;
	for(i = 0; i<256; i++){
		int r,g,b;
		fscanf(f,"%d%d%d",&r,&g,&b);
		clut[i] = RGB(r,g,b);
	}
	return 1;
}
// load (apparent) microsoft palettes
// don't know about the use of this, but paintshoppro is able to
// save in this format
int loadMSPal(FILE *f, COLORREF *clut){
	fseek(f, 24, SEEK_SET);
	for(int i = 0; i<256; i++){
		int r = fgetc(f), g = fgetc(f), b = fgetc(f);
		clut[i] = RGB(r,g,b);
		fgetc(f);
	}
	return 0;
}

// try to discover what format the palette file is in
int idFile(FILE *f){
	char cBuf[16];

	fread(cBuf, 1,4,f);
	cBuf[4] = 0;
	fseek(f, 0, SEEK_SET);
	if(strcmp(cBuf, "RIFF") == 0) return PL_MICROSOFT;
	fread(cBuf, 1,8,f);
	cBuf[8] = 0;
	fseek(f,0,SEEK_SET);
	if(strcmp(cBuf, "JASC-PAL")==0) return PL_JASC;
	return PL_NORMAL;
}


// load a palette into the given color table
int loadPal(COLORREF *clut){
	char * spFile = myPromptFile(OPENFILE, hwDlg, "Palette files\0*.pal\0","Load palette...");
	if(spFile){
		FILE *f=fopen(spFile, "rb");
		if(f){
			int type = idFile(f);
			if(type != PL_NORMAL) LoadPalType = type;
			else {
				if(LoadPalType == PL_JASC || LoadPalType == PL_MICROSOFT)
					LoadPalType = type;

			}
			switch(LoadPalType){
				case PL_EP63:
					loadEP63Pal(f, clut);
					break;
				case PL_JASC:
					loadJASCPal(f, clut);
					break;
				case PL_MICROSOFT:
					loadMSPal(f, clut);
					break;
				default:
					for(int i = 0; i<256; i++){
						int r = fgetc(f), g = fgetc(f), b = fgetc(f);
						clut[i] = RGB(r,g,b);
					}
					break;
				}
			fclose(f);
			return 1;
		}
	}
	return 0;
}

// see the various load*Pal functions
void saveEP63Pal(FILE *f, COLORREF *clut){
	for(int i = 0; i<256; i++){
		fputc(GetRValue(clut[i]) >> 2,f);
		fputc(GetGValue(clut[i]) >> 2,f);
		fputc(GetBValue(clut[i]) >> 2,f);
	}
}
void saveJASCPal(FILE *f, COLORREF *clut){
	fprintf(f, "JASC-PAL\r\n0100\r\n256\r\n");
	for(int i = 0; i<256; i++){
		fprintf(f, "%d %d %d\r\n",
				GetRValue(clut[i]),
				GetGValue(clut[i]),
				GetBValue(clut[i]));
	}
}

// outputs simple C source
void saveCPal(FILE *f, COLORREF *clut){
	fprintf(f, "PALETTEENTRY\tpal[256] = {\n");
	for(int i=0; i<255; i++)
		fprintf(f, "\t{ %3d, %3d, %3d, 0},\n",
				GetRValue(clut[i]),
				GetGValue(clut[i]),
				GetBValue(clut[i]));
	fprintf(f, "\t{ %3d, %3d, %3d}\n",
			GetRValue(clut[255]),
			GetGValue(clut[255]),
			GetBValue(clut[255]));
	fprintf(f,"};\n");
}

void savePal(COLORREF *clut){
	char * spFile = myPromptFile(SAVEFILE, hwDlg, "Palette files\0*.pal\0C Source files\0*.h;*.c;*.cpp\0","Save palette...");
	if(spFile){
		FILE *f=fopen(spFile, "wb");
		if(f){
			switch(SavePalType){
				case PS_EP63:
					saveEP63Pal(f, clut);
					break;
				case PS_JASC:
					saveJASCPal(f, clut);
					break;
				case PS_C:
					saveCPal(f, clut);
					break;
				default:
					for(int i = 0; i<256; i++){
						fputc(GetRValue(clut[i]),f);
						fputc(GetGValue(clut[i]),f);
						fputc(GetBValue(clut[i]),f);
					}
					break;
			}
			fclose(f);
		}
	}
}





HBITMAP	hbNorm = NULL, hbPress = NULL;
HFONT hfTest = NULL;
HBRUSH	hbBlue = NULL, hbLite = NULL, hbDark = NULL;

void initTest(HWND hwnd){
	COLORREF col;
	hbNorm = LoadImage(hInst, MAKEINTRESOURCE(IDB_BNORM), IMAGE_BITMAP,0,0,
						0);// LR_LOADFROMFILE | LR_LOADTRANSPARENT | LR_LOADMAP3DCOLORS);
	if(!hbNorm)
		Error_Quit(NULL,0,"Failed to load resource: %s", Get_Error_Msg());
	HDC hdc = CreateCompatibleDC(NULL);
	SelectObject(hdc, hbNorm);
	col = GetPixel(hdc, 0,0);
	hbBlue = CreateSolidBrush(col);
	hbLite = CreateSolidBrush(col + 0x101010);
	hbDark = CreateSolidBrush(col - 0x202020);
	DeleteDC(hdc);
	hbPress = LoadImage(hInst, MAKEINTRESOURCE(IDB_BPRESSED), IMAGE_BITMAP,0,0,
						0); //LR_LOADFROMFILE | LR_LOADTRANSPARENT | LR_LOADMAP3DCOLORS);
	if(!hbPress)
		Error_Quit(NULL,0,"Failed to load resource: %s", Get_Error_Msg());
	HWND hwTmp = GetDlgItem(hwnd, IDB_TEST);
	hfTest = CreateFont(-10, 0, 0, 0, 800, 0, 0, 0, 1, 3,2, 1, 2, "Verdana");
	if(!hfTest)
		Error_Quit(NULL,0,"Failed to create font ::: %s", Get_Error_Msg());
}


void initControls(HWND hwnd){
	RECT r;
	HWND hw = GetDlgItem(hwnd, IDC_GRAD);
	GetWindowRect(hw, &r);
	ScreenToClient(hwnd, (LPPOINT)&r);
	ScreenToClient(hwnd, (LPPOINT)&r.right);
	hwGrad = createGradient(hwnd,&r, IDC_GRAD);
	SetWindowPos(GetDlgItem(hwnd, IDB_QUIT), NULL,0,0, 95, 25, SWP_NOMOVE | SWP_NOZORDER);
	SetWindowPos(GetDlgItem(hwnd, IDB_SAVE), NULL,0,0, 95, 25, SWP_NOMOVE | SWP_NOZORDER);
	SetWindowPos(GetDlgItem(hwnd, IDB_LOAD), NULL,0,0, 95, 25, SWP_NOMOVE | SWP_NOZORDER);
	SetWindowPos(GetDlgItem(hwnd, IDB_TEST), NULL,0,0, 95, 25, SWP_NOMOVE | SWP_NOZORDER);
	if(hwGrad)
		DestroyWindow(hw);
	initTest(hwnd);

}


void drawButton(HWND hwnd, LPDRAWITEMSTRUCT	pdis){

	HDC hdc;
	SIZE sz;
	HFONT hfTmp;
	RECT *pr;
	char szText[64] = {0};

	hdc = pdis->hDC;//GetDC(hwnd);
	if(hdc){
		HDC hdcb = CreateCompatibleDC(hdc);
		if(hdcb){
			pr = &pdis->rcItem;

			if(pdis->itemState & ODS_SELECTED)
				SelectObject(hdcb, hbPress);
			else
				SelectObject(hdcb, hbNorm);
			StretchBlt(hdc, pr->left, pr->top,pr->right - pr->left, pr->bottom - pr->top,
							hdcb,0,0,95,25,SRCCOPY);


			hfTmp = SelectObject(hdc, hfTest);
			SetTextColor(hdc, 0);
			SetBkMode(hdc,TRANSPARENT);
			SetTextAlign(hdc, TA_CENTER | TA_BOTTOM);
			GetWindowText(pdis->hwndItem, szText, 63);
			GetTextExtentPoint32(hdc, szText, strlen(szText), &sz);
			int x = (pr->right - pr->left)/2 + pr->left,
				y = (pr->bottom - pr->top)/2 + pr->top + sz.cy/2;
			if(pdis->itemState & ODS_SELECTED)
				x++, y++;
			TextOut(hdc, x,y, szText, strlen(szText));
			SelectObject(hdc, hfTmp);
			DeleteDC(hdcb);
		}
		ReleaseDC(hwnd, hdc);
	}
}

static LRESULT CALLBACK DialogFunc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
	COLORREF clut[256];
	RECT r;
	char sp[64];
	HDC hdc;
	LPDRAWITEMSTRUCT	pdis;
	CHOOSECOLOR cc;
	static COLORREF colData[16];
	static HBRUSH hbrBg = NULL;

	switch (msg) {
	case WM_INITDIALOG:
		hwDlg = hwnd;
		SetClassLong(hwnd, GCL_HICON, (LONG)LoadIcon(hInst, MAKEINTRESOURCE(IDIAPP)));
		SetClassLong(hwnd, GCL_HICONSM, (LONG)LoadImage(hInst, MAKEINTRESOURCE(IDIAPP+1), IMAGE_ICON, 0,0,0));
		InitSkin(hwnd);
		initControls(hwnd);
		hbrBg = CreateSolidBrush(RGB(69,121,214));
		return TRUE;
	case WM_DRAWITEM:
		pdis = (LPDRAWITEMSTRUCT)lParam;
		switch(wParam){
			case IDC_RCOL:
				ColorRect(pdis->hDC, &pdis->rcItem, colour);
				if(pdis->itemState & ODS_SELECTED)
					DrawEdge(pdis->hDC, &pdis->rcItem, EDGE_SUNKEN, BF_TOPLEFT | BF_BOTTOMRIGHT);
				else
					DrawEdge(pdis->hDC, &pdis->rcItem, EDGE_RAISED, BF_TOPLEFT | BF_BOTTOMRIGHT);
				break;
			case IDR_BLU:
				FillRect(pdis->hDC, &pdis->rcItem, hbBlue);
				SetRect(&r, pdis->rcItem.left, pdis->rcItem.top, pdis->rcItem.left+3,pdis->rcItem.bottom);
				FillRect(pdis->hDC, &r, hbDark);
				SetRect(&r, pdis->rcItem.left, pdis->rcItem.top, pdis->rcItem.right,pdis->rcItem.top + 3);
				FillRect(pdis->hDC, &r, hbDark);
				SetRect(&r, pdis->rcItem.right - 3, pdis->rcItem.top, pdis->rcItem.right,pdis->rcItem.bottom);
				FillRect(pdis->hDC, &r, hbLite);
				SetRect(&r, pdis->rcItem.left, pdis->rcItem.bottom - 3, pdis->rcItem.right,pdis->rcItem.bottom);
				FillRect(pdis->hDC, &r, hbLite);
				break;
			default:
				drawButton(hwnd, pdis);
				break;
		}
		break;
	case WM_COMMAND:
		switch (LOWORD(wParam)) {
			case IDB_TEST:
				{
					int i, k;
					SendMessage(hwGrad, GM_DEBUG,0,0);
					//printf("\n\n\n");
					k = SendMessage(hwGrad, GM_GETCTRLCOUNT,0,0);
					double d = 255.0 / (k-1);
					for(i=0; i<k; i++)
						SendMessage(hwGrad, GM_SETPOS, i, (LPARAM)(i * d));
					SendMessage(hwGrad, GM_DEBUG,0,0);
					/*int col = DialogBox(hInst,  MAKEINTRESOURCE(IDD_COLS), hwnd, wpColsDlg);
					if(col == -1) break;
					int wh = SendMessage(hwGrad, GM_GETSEL, 0,0);
					SendMessage(hwGrad, GM_SETCOLOR, wh, col);
					InvalidateRect(GetDlgItem(hwnd, IDC_RCOL), NULL, 0);*/
				}
				break;
			case IDC_RCOL:
				memset(&cc,0,sizeof(CHOOSECOLOR));
				cc.lStructSize = sizeof(CHOOSECOLOR);
				cc.hwndOwner = hwnd;
				cc.rgbResult = colour;
				cc.lpCustColors = colData;
				cc.Flags = CC_RGBINIT | CC_FULLOPEN	;
				if(ChooseColor(&cc)){
					colour = cc.rgbResult;
					int wh = SendMessage(hwGrad, GM_GETSEL, lParam,0);
					SendMessage(hwGrad, GM_SETCOLOR, wh, colour);
					InvalidateRect(GetDlgItem(hwnd, IDC_RCOL), NULL, 0);
				}
				break;
			case IDC_GRAD:
				if(HIWORD(wParam) == GRN_CHANGESEL){
					colour = SendMessage(hwGrad, GM_GETCOLOR, lParam,0);
					InvalidateRect(GetDlgItem(hwnd, IDC_RCOL), NULL, 0);
				}
				break;
			case IDB_SAVE:
				SendMessage(hwGrad, GM_GETCLUT,0,(LPARAM)clut);
				if(clut){
					savePal(clut);
				}
				return 1;
			case IDB_LOAD:
				if(loadPal(clut)){
					SendMessage(hwGrad, GM_SETCLUT,0,(LPARAM)clut);
				}
				break;
			case IDB_QUIT:
				EndDialog(hwnd,0);
				return 1;
		}
		break;
	case WM_CLOSE:
		EndDialog(hwnd,0);
		return TRUE;
	case WM_DESTROY:
		if(hbrBg) DeleteObject(hbrBg);
		break;
	}
	return FALSE;
}




int APIENTRY WinMain(HINSTANCE hinst, HINSTANCE hinstPrev, LPSTR lpCmdLine, int nCmdShow)
{
	INITCOMMONCONTROLSEX cc;
	memset(&cc,0,sizeof(cc));
	cc.dwSize = sizeof(cc);
	cc.dwICC = 0xffffffff;
	InitCommonControlsEx(&cc);

	hInst = hinst;
//	if(!Reg_Win_Class(0, DialogFunc, "PaleDlgboxClass", NULL, NULL))
//		qErr("Failed to register dialog class");

	return DialogBox(hinst, MAKEINTRESOURCE(IDD_MAINDIALOG), NULL, (DLGPROC) DialogFunc);

}
