#include <windows.h>
#include <assert.h>
#include <stdio.h>
//#include "pale.h"
#include "grad.h"
#include "paleres.h"
// all for the sake of clarity
#define MAX_CTRLS	256
#define MAX_COLS	256

// size of small triangle controls
#define CTRL_WIDTH		8
#define CTRL_HALFWID	4
#define CTRL_MINDIST	(CTRL_WIDTH+2)
// lazy typer macros
#define CTRL_POS(x) (gWnd.ctrl[(x)].pos)
#define CTRL_VAL(x) (gWnd.ctrl[(x)].val)
#define CTRL(x)		(gWnd.ctrl[(x)])
// more lazy typer macros
#define R(x) GetRValue(x)
#define G(x) GetGValue(x)
#define B(x) GetBValue(x)
// again....
#define UNSEL_PEN(dc)		SelectObject((dc), GetStockObject(NULL_PEN))
#define UNSEL_BRUSH(dc)		SelectObject((dc), GetStockObject(NULL_BRUSH))

// don't know why C never had these
typedef unsigned char byte;

// these are the little triangle controls
typedef struct {
	int pos;			//	virtual position	(0 to MAX_COLS-1)
	COLORREF val;		//	colour
	int	pxpos;			//	pixel position from 0
//	int start;
//	int end;
} ColTroller, *PColTroller;

// this structure stores lots of useful info
typedef struct {
//	WNDPROC 	wproc;
	HWND		hw;				// handle to gradient control window
	HBITMAP		hbm;			// off screen buffer
	HCURSOR		hCur;			// delete cursor
	DWORD		id;				//	control id (see createGradient)
	int			sel;			// currently selected triangle control
	double		cbx;			// increment - see initGrad
	//COLORREF	col;			// *** UNUSED
	COLORREF 	cols[MAX_COLS]; // the palette
	ColTroller	ctrl[MAX_CTRLS+1]; // all the triangle controls  +1 to save checking for overflows
	int			numCtrls;		// how many controls currently
	int			cx;				// width of gradient bar in pixels
	int			cyCtrl;			// height of triangle control
	RECT		rGrad, rCtrlArea; // the area rectangles
} GradWnd, * PGradWnd;

GradWnd gWnd = {0};


static HINSTANCE hInst = NULL;
static HWND hwPicker = NULL;



// quick helper function to register a window class in a one line call
// I hate having lots of structure filling done in a main function
static int Reg_Win_Class(UINT uiStyle, WNDPROC wnProc, const char *szClassName,
				const char *szMenuName, HICON hIcon)
{
	WNDCLASS wc;
	memset(&wc,0,sizeof(WNDCLASS));
	wc.style = uiStyle;

	wc.lpfnWndProc = wnProc;
	wc.hInstance = GetModuleHandle(NULL);
	wc.lpszClassName = szClassName;
	wc.lpszMenuName = szMenuName;
	wc.hIcon = (hIcon) ? hIcon : LoadIcon(NULL, MAKEINTRESOURCE(IDI_APPLICATION));

	wc.hbrBackground = (HBRUSH)(COLOR_WINDOW+1);
	wc.hCursor = LoadCursor(NULL,IDC_ARROW);

	if (!RegisterClass(&wc))
	   return 0;
   return 1;
} // end Reg_Win_Class


/*
* This calculates the colours between control c1 and control c2
*/
static void calcGradSection(int c1, int c2){
	double inc[3], diff;

	if(gWnd.ctrl[c2].pos == -1	|| gWnd.ctrl[c2].pos == -1) // check that both are valid controls
		return;

	int steps = gWnd.ctrl[c2].pos - gWnd.ctrl[c1].pos; // how many steps
// calculate increment values for red, green and blue separately
// simple formula : difference in colour / number of steps
	diff = R(gWnd.ctrl[c2].val) - R(gWnd.ctrl[c1].val);
	inc[0] = diff / steps;
	diff = G(gWnd.ctrl[c2].val) - G(gWnd.ctrl[c1].val);
	inc[1] = diff / steps;
	diff = B(gWnd.ctrl[c2].val) - B(gWnd.ctrl[c1].val);
	inc[2] = diff / steps;

	double r,g,b;
	r = R(gWnd.ctrl[c1].val); // starting red, green and blue values
	g = G(gWnd.ctrl[c1].val);
	b = B(gWnd.ctrl[c1].val);
	for(int i = gWnd.ctrl[c1].pos; i <= gWnd.ctrl[c2].pos; i++){ // loop thru and for each step
		gWnd.cols[i] = RGB((byte)r, (byte)g, (byte)b); // set the colour
		r+=inc[0];	g+=inc[1];	b+=inc[2]; // and add our increment value
	} // next i
} // end calcGradSection(int,int)

// essentially calcGradSection(0, number of controls)
// by looping through each pair of controls
static void calcGrad(){
	int i,j;
	i=0; j=1;
	while(j<gWnd.numCtrls){
		calcGradSection(i,j);
		i++;
		j++;
	} // wend j
}// end calcGrad()


// calculates a pixel position for a given virtual position
// virtual positions are from 0 - MAX_COLS-1  (generally 0-255)
// uses gWnd.cbx, precalculated increment value
// which is defined in initGrad as being (width in pixels of control) / (double)(MAX_COLS)
static int calcCtrlPxPos(int pos){
	double 	dpos = pos * gWnd.cbx;
	// add left edge of control before return
	return (int)dpos + gWnd.rCtrlArea.left;
} // end calcCtrlPxPos

// this makes a pixel value into a 'safe' value for further calculation
// basically binds x to being within our control rectangle
// then subtracts left edge so we have
// 0 <= x <= (control width in pixels)
static int bindXPos(int *x){
	if(*x < gWnd.rCtrlArea.left) *x = gWnd.rCtrlArea.left;
	if(*x >= gWnd.rCtrlArea.right) *x = gWnd.rCtrlArea.right-1;
	*x -= gWnd.rCtrlArea.left;
	return *x;
} // end bindXPos


// the complementary function to calcCtrlPxPos
// returns a virtual position from a pixel position
static int calcCtrlPosFromPx(int x){
	bindXPos(&x);
	double ppos = x / gWnd.cbx;
	return (int)ppos;
} // end calcCtrlPosFromPx

// sets the position of a given control (c)
// to the virtual position given (pos)
static void setCtrlPos(int c, int pos){
	if(c >= gWnd.numCtrls) return;
	gWnd.ctrl[c].pos = pos;
	gWnd.ctrl[c].pxpos = calcCtrlPxPos(pos); // work out pixel position for quick hit testing later
} // end setCtrlPos

// sets the colour of a given control
static void setCtrlVal(int c, COLORREF val){
	if(c >= gWnd.numCtrls) return;
	gWnd.ctrl[c].val = val;
} // end setCtrlVal

// draws a control on the given device context
// at virtual position (pos), coloured (col)
// fSel (bool) specifies whether the control is selected or not
// if it is, then draw a different coloured border
static void drawCtrl(HDC hdc, int pos, COLORREF col, int fSel){
	POINT pts[3];
	double 	dpos = pos * gWnd.cbx; // calculate pixel position
	RECT r, *pr = &gWnd.rCtrlArea;
	dpos += pr->left; // add left edge of control rect
// these points are for drawing a triangle using Polygon()
	pts[0].x = (int)(dpos - CTRL_HALFWID); pts[0].y = pr->top+4;
	pts[1].x = (int)(dpos + CTRL_HALFWID); pts[1].y = pr->top+4;
	pts[2].x = (int)dpos; pts[2].y = pr->top + 4 + gWnd.cyCtrl;
// create coloured brush and pen
	HBRUSH hbTmp = CreateSolidBrush(col);
	// if selected then make sure the border is opposite colour of control
	// otherwise border should be slightly darker
	HPEN hpTmp = CreatePen(PS_SOLID, 1, fSel ? RGB(255,255,255) - col : col - RGB(10,10,10));
	HBRUSH hbOld; // store old dc brush
	HPEN hpOld;		// and pen

	hbOld = SelectObject(hdc, hbTmp);
	hpOld = SelectObject(hdc, hpTmp);

	Polygon(hdc, pts, 3);

	SelectObject(hdc, hbOld);
	SelectObject(hdc, hpOld);
	DeleteObject(hpTmp);
	DeleteObject(hbTmp);
//	DrawIconEx(hdc, r.left, r.top, gWnd.hIco,0,0, 0, NULL, DI_NORMAL);
} // end drawCtrl


// simply calls drawCtrl for all the controls
// RECT argument is obsolete, but could be reinstated
static void drawControls(HDC hdc, RECT *pr){
	for(int i=0; i < gWnd.numCtrls; i++)
		drawCtrl(hdc, CTRL_POS(i), CTRL_VAL(i), gWnd.sel == i);
}


// deletes control number (c)
static void delCtrl(int c){
	if(!gWnd.numCtrls) return;
	int diff = gWnd.numCtrls - 1 - c;
	memmove(&CTRL(c), &CTRL(c+1), diff * sizeof(ColTroller));
	gWnd.ctrl[gWnd.numCtrls].pos = -1;
	if(--gWnd.numCtrls<0) gWnd.numCtrls = 0;
} // end delCtrl

// adds a new control
// determines a virtual position from the given pixel position (POINTS pt)
static int addCtrlPts(POINTS pt){
	int i, found = -1;

	int pos = calcCtrlPosFromPx(pt.x); // calculate virtual pos
	int x = pt.x; // POINTS is defined using short ints, here we convert x to an int
	bindXPos(&x); // make x 'safe'

	// this loop finds at which point in the controls array
	// the new control should be inserted
	// if there is already a control there, we return its index instead
	// of creating another
	for(i=0; i<gWnd.numCtrls; i++){
		if(gWnd.ctrl[i].pos == pos) return i;  // found a control in place already
		if(gWnd.ctrl[i].pos > pos){
			found = i; // found our position
			break;
		}
	}
	if(found == -1) found = 0; // insert at beginning
	int diff = gWnd.numCtrls - found; // how many items need to be moved down in array
	if(diff) // shift all the rest of the array down
		memmove(&gWnd.ctrl[found+1], &gWnd.ctrl[found], diff * sizeof(ColTroller));

	gWnd.ctrl[found].pos = pos;
	gWnd.ctrl[found].pxpos = x;
	gWnd.ctrl[found].val = gWnd.cols[pos];
	if(++gWnd.numCtrls >= MAX_CTRLS) gWnd.numCtrls = MAX_CTRLS-1;
	return found;
} // end addCtrlPts

// find a control, given a pixel position
static int ctrlFromPts(POINTS pt){
	DWORD	minDist = 1<<31; // set minimum to a really big number
	int		minIdx = -1; // and the index to -1 to detect found item
	DWORD	dst;
//	printf("ctrlFromPts( %d, %d )\n", pt.x, pt.y);
	pt.x -= gWnd.rCtrlArea.left; // set x so that it is relative to the control rectangle
//	printf(" x now == %d\n", pt.x);
	// loop thru all the controls
	// and find the smallest distance
	for(int i=0; i < gWnd.numCtrls; i++){
		dst = abs(pt.x - gWnd.ctrl[i].pxpos); // absolute distance - dont care + or -
		if(dst < minDist){
		   minDist = dst; // store smallest distance so far
		   minIdx = i; // and which control it was
//			printf(" min dist %d  min idx %d\n", minDist, minIdx);
		}
	}
// if the nearest control was more than (CTRL_WIDTH*2) pixels away
// we return -1 to say that we didn't find anything
//	printf("end cfp() :: minDist == %d, minIdx == %d\n", minDist, minIdx);
	return (minDist < (CTRL_MINDIST)) ? minIdx : -1;
} // end ctrlFromPts

// swap 2 controls
static void swapCtrls(int a, int b){
	ColTroller t;
	t = gWnd.ctrl[a];
	gWnd.ctrl[a] = gWnd.ctrl[b];
	gWnd.ctrl[b] = t;
} // end swapCtrls

// this is not used
static void sortCtrlsRecurse(int start, int end){
	int len = end - start;
	int mid = start + len / 2;
	if(len <= 0) return;
	if(len == 1){
		if(gWnd.ctrl[start].pos > gWnd.ctrl[end].pos)
			swapCtrls(start, end);
		return;
	}
	sortCtrlsRecurse(start, mid);
	sortCtrlsRecurse(mid, end);
}


// using a pixel position, set the control's virtual position
static void setCtrlPosFromPts(int c, POINTS pts){
	gWnd.ctrl[c].pos = calcCtrlPosFromPx(pts.x);
	int x = pts.x;
	gWnd.ctrl[c].pxpos = bindXPos(&x);
}// end setCtrlPosFromPts

// deletes all the controls
static void emptyCtrls(){
	for(int i=0; i<MAX_CTRLS; i++)
		gWnd.ctrl[i].pos = -1;
	gWnd.numCtrls = 0;
} // end emptyCtrls

// this draws a coloured rectangle
static void thickVLine(HDC hdc, int x1,int y1, int x2, int y2, COLORREF col){
	HBRUSH hbr;
	RECT r;
	hbr = CreateSolidBrush(col);
	SetRect(&r, x1,y1,x2,y2);
	FillRect(hdc, &r, hbr);
	DeleteObject(hbr);
}


// draw the gradient in the given rectangle
static void drawCols(HDC hdc, RECT *pr){
	HBRUSH hbOld, hbr;
	RECT r;
	double	pos, ppos, inc;

	int cy = pr->bottom - pr->top; // height and
	int cx = pr->right - pr->left; // width

	inc = cx / (double)MAX_COLS; //

	pos = pr->left; // start at left edge of given rectangle
	hbOld = UNSEL_BRUSH(hdc);// SelectObject(hdc, GetStockObject(NULL_BRUSH));

	// draw the first rectangle to ensure that there is no gap at the beginning
	// gaps could occur because of rounding in the scale equation (cx / (double) MAX_COLS)
	thickVLine(hdc, pr->left, pr->top, (int)pos, pr->bottom, gWnd.cols[0]);
	for(int i=0; i<MAX_COLS; i++){
		ppos = pos + gWnd.cbx;//inc;  add increment
		thickVLine(hdc, (int)pos, pr->top, (int)ppos, pr->bottom, gWnd.cols[i]);//
		pos = ppos;
	}
	// draw the last rectangle to avoid gaps (see above)
	thickVLine(hdc, (int)(pr->right - gWnd.cbx), pr->top, pr->right, pr->bottom, gWnd.cols[255]);
	SelectObject(hdc, hbOld);
} // end drawCols


// draws the entire gradient control
// gradient bar, triangle controls and sunken frame
//
// all our drawing is done to memory first
// then blitted to the screen afterward to reduce flicker.
static void drawGrad(HWND hwnd){
	HPEN hpOld, hpFrame;
	RECT r;
	HDC hdc, hdcWin;

	hdcWin = GetDC(hwnd); // get our window dc
	assert(hdcWin);
	hdc =  CreateCompatibleDC(hdcWin); // make a temporary memory dc
	assert(hdc);
// make sure the mem. dc is linked to our bitmap
	SelectObject(hdc, gWnd.hbm);

	GetClientRect(hwnd, &r);
//DrawEdge(hdc, &r,BDR_SUNKENOUTER, BF_MIDDLE);
// fill the rectangle with window color
	FillRect(hdc, &r, (HBRUSH)(COLOR_3DFACE+1));

	calcGrad(); // calculate the colours
	drawCols(hdc, &gWnd.rGrad); // draw the gradient
	drawControls(hdc, &gWnd.rCtrlArea); // draw the controls
	DrawEdge(hdc, &r,BDR_SUNKENOUTER, BF_TOPRIGHT | BF_BOTTOMLEFT); // 3d sunken outline
// then copy to screen
	BitBlt(hdcWin, 0,0, r.right-r.left, r.bottom-r.top, hdc, 0,0, SRCCOPY);
// delete the temporary memory dc
	DeleteDC(hdc);
// and release the shared one
	ReleaseDC(hwnd, hdc);//hdcWin);
} // end drawGrad

// unload anything allocated on initGrad
static void killGrad(HWND hwnd){
	if(gWnd.hbm){
		DeleteObject(gWnd.hbm);
		gWnd.hbm = NULL;
	}
} // end killGrad


// this takes a point and returns the colour
// from the picker window at that point
COLORREF getPickColor(int cx, int cy, POINTS pts){
	int x = pts.x, y = pts.y;
	int r,g,b;
	// bounds checking
	if(x < 0) x = 0;
	if(x >= cx) x = cx - 1;
	if(y < 0) y = 0;
	if(y >= cy) y = cy - 1;
	// the colours get darker as they go down - hence
	// the cy-y /cy stuff
/*	r = spectrum[x].peRed * (cy - y) / cy;
	g = spectrum[x].peGreen * (cy - y) / cy;
	b = spectrum[x].peBlue * (cy - y) / cy;
	return RGB(r,g,b);*/
	HDC hdc = GetDC(hwPicker);
	HBITMAP hbOld = SelectObject(hdc, gWnd.hbm);
	COLORREF col=GetPixel(hdc, x,y);
	SelectObject(hdc, hbOld);
	ReleaseDC(hwPicker, hdc);
	return col;
}

// the window procedure for the popup colour sampler
static BOOL CALLBACK wpPicker(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam){

HDC hdc, dcb;
static HBITMAP	hbm = NULL;
PAINTSTRUCT ps;
static int cx, cy;
RECT r;
POINTS pts;
POINT pt;

	switch(msg){
		// load a spectrum bitmap from disk
		case WM_CREATE:
			hdc = GetDC(hwnd);
			if(hdc){
				GetClientRect(hwnd, &r);
				cx = r.right;
				cy = r.bottom;
				hbm = LoadImage(hInst, MAKEINTRESOURCE(IDB_SPECTRUM), IMAGE_BITMAP, 0,0, 0);//CreateCompatibleBitmap(hdc, cx, cy);
				assert(hbm);
				ReleaseDC(hwnd, hdc);
			}
			break;
		case WM_DESTROY: // free bitmap created in WM_CREATE
			if(hbm) {
				DeleteObject(hbm);
				hbm = NULL;
			}
			break;
		// create a temporary memory dc, link it to our bitmap
		// and blit it to the screen
		case WM_PAINT:
			hdc = BeginPaint(hwnd, &ps);
			dcb = CreateCompatibleDC(NULL);
			if(dcb){
				SelectObject(dcb, hbm);
				BitBlt(hdc, 0,0, cx, cy, dcb, 0,0, SRCCOPY);
				DeleteDC(dcb);
			}
			EndPaint(hwnd, &ps);
			break;
		case WM_RBUTTONDOWN:
			pts = MAKEPOINTS(lParam);
			pt.x = pts.x;		pt.y = pts.y;
			// use parent window to calculate screen coordinates
			// as the WM_RBUTTONDOWN message is in fact passed to us only
			// from the handler in the parent window
			ClientToScreen(hwnd, &pt);
			SetWindowPos(hwnd, HWND_TOP, pt.x - cx/2, pt.y - cy + 1, 0,0, SWP_NOSIZE | SWP_SHOWWINDOW);
			SetCapture(hwnd);
			break;
		case WM_MOUSEMOVE:
			if(GetCapture() != hwnd) break;
			pts = MAKEPOINTS(lParam);
			SendMessage(gWnd.hw, GM_SETCOLOR, gWnd.sel, getPickColor(cx, cy, pts));
			break;
		case WM_RBUTTONUP:
			ReleaseCapture();
			ShowWindow(hwnd, SW_HIDE);
			break;
		default:
			return DefWindowProc(hwnd, msg,wParam, lParam);
	}
	return 0;
}

void initPicker(HWND hwnd){
	Reg_Win_Class(0, wpPicker, "spectrum.win.class", NULL, NULL);
	hwPicker = CreateWindow("spectrum.win.class","Spectrum",
							WS_POPUP | WS_BORDER,
							0,0, 256,64,
							hwnd, NULL, hInst, NULL);
	assert(hwPicker);
}

// initialise various stuff
static void initGrad(HWND hwnd){
	RECT r;
	srand(GetTickCount()); // this is for the random startup colours

	emptyCtrls();

	GetClientRect(hwnd, &r);

	int cy = r.bottom - r.top;

	int cyCtrl = (int)(cy * 0.333); // controls use 1/3 of space
	int cyGrad = cy - gWnd.cyCtrl; // gradient the remaining 2/3

// this is the rectangle for the gradient bar
	SetRect(&gWnd.rGrad, r.left + 8, r.top + cyCtrl, r.right - 8, r.bottom - 5);
// gradient width
	gWnd.cx = gWnd.rGrad.right - gWnd.rGrad.left;

// the control area rectangle
	SetRect(&gWnd.rCtrlArea, r.left + 8, r.top, r.right - 8, r.top + cyCtrl);
	gWnd.cyCtrl = cyCtrl - 4; // height of control triangle
	gWnd.numCtrls = 3; // start with 3 controls

// this incrememnt is used lots
// for all the scaling operations converting values from 0 - MAX_COLS
// into values between (control left edge) and (control right edge)
	gWnd.cbx = gWnd.cx / (double)MAX_COLS;

//	set three controls of
//	random colours at beginning, middle and end
	setCtrlPos(0, 0);
	setCtrlVal(0, rand() % RGB(255,255,255));
	setCtrlPos(1, MAX_COLS>>1);
	setCtrlVal(1, rand() % RGB(255,255,255));
	setCtrlPos(2, MAX_COLS-1);
	setCtrlVal(2, rand() % RGB(255,255,255));

	initPicker(hwnd);
} // end initGrad


// window proc
//	Note GM_xxx messages
//	these would be sent by the control parent window
//	in order to control the behaviour of the gradient control
//	nb. I am not a control freak!
LRESULT CALLBACK GradWndProc(HWND hwnd,	UINT msg,	WPARAM wParam,    LPARAM lParam){
HDC hdc;
PAINTSTRUCT ps;

	switch(msg){
		case GM_DEBUG:
			for(int i = 0; i<gWnd.numCtrls; i++){
				printf("Ctl %d ::: at vpos %d  color 0x%0X\n", i,
							CTRL_POS(i), CTRL_VAL(i)
						);
			}
			break;
		case GM_GETCTRLCOUNT:
			return gWnd.numCtrls;

		case GM_SETPOS:
			if(wParam < gWnd.numCtrls){
				setCtrlPos(wParam, lParam);
				drawGrad(hwnd);
			}
			break;
		case GM_GETPOS:
			if(wParam < gWnd.numCtrls){
				return CTRL_POS(wParam);
			}
			break;
		case GM_SETCOLOR: // set control number (wParam) to colour value (lParam)
			if(wParam >= gWnd.numCtrls) return 0;
			gWnd.ctrl[wParam].val = lParam;
			drawGrad(hwnd);
			return 1;
		case GM_GETCOLOR: // return colour of control number specified in wParam
			if(wParam >= gWnd.numCtrls) return 0;
			return gWnd.ctrl[wParam].val;
			break;
		case GM_GETCLUT: // copy the entire palette to memory pointer in lParam
			if(lParam != 0){
				memcpy((void*)lParam, gWnd.cols, sizeof(gWnd.cols));
			}
			break;
		case GM_SETCLUT: // copy entire palette from memory pointer in lParam
			if(lParam != 0){
				memcpy(gWnd.cols, (void*)lParam, sizeof(gWnd.cols));
				emptyCtrls();
				gWnd.sel = -1;
				drawGrad(hwnd);
			}
			break;
		case GM_GETSEL: // return selected control (-1 if none)
			return gWnd.sel;
		case GM_SETSEL:	// set selected control to number specified in lParam
			if(lParam < gWnd.numCtrls)
				gWnd.sel = lParam;
			break;

		case WM_CREATE:
			initGrad(hwnd);
			InvalidateRect(hwnd, NULL, 1);
			break;

		case WM_DESTROY:
			killGrad(hwnd);
			break;
		case WM_RBUTTONDOWN:
			gWnd.sel = ctrlFromPts(MAKEPOINTS(lParam));		// try to find clicked-on control
//			printf("RMBDown ::: CtlFromPts returned %d\n", gWnd.sel);
			if(gWnd.sel == -1)								// if none found then
				gWnd.sel = addCtrlPts(MAKEPOINTS(lParam));	// add a new control
			if(gWnd.sel != -1){	// if we managed to find or create a control then
				// adjust our coordinates, in order to pass them on
				// to the picker window
				POINT pt;
				pt.x = LOWORD(lParam);		pt.y = HIWORD(lParam);
				ClientToScreen(hwnd, &pt);
				ScreenToClient(hwPicker, &pt);
				SendMessage(hwPicker, WM_RBUTTONDOWN, wParam, MAKELPARAM(pt.x, pt.y));
			}
			break;
		case WM_LBUTTONDOWN:
			gWnd.sel = ctrlFromPts(MAKEPOINTS(lParam));		// try to find clicked-on control
//			printf("LMBDown ::: CtlFromPts returned %d\n", gWnd.sel);
			if(gWnd.sel == -1)								// if none found then
				gWnd.sel = addCtrlPts(MAKEPOINTS(lParam));	// add a new control
			if(gWnd.sel != -1)	// if we managed to find or create a control then
				SetCapture(hwnd); // capture the mouse
			// here we post a notification message to our parent window
			// letting the parent app know that the selection has changed
			PostMessage(GetParent(hwnd),
						WM_COMMAND,
						MAKEWPARAM(gWnd.id, GRN_CHANGESEL),
						gWnd.sel);
			drawGrad(hwnd);
			break;

		case WM_LBUTTONUP:
			// test if the mouse is captured and we have a selection
			if(GetCapture() == hwnd && gWnd.sel != -1){
				POINTS pt = MAKEPOINTS(lParam);
				if(pt.y < 0) { // if the control was dragged outside the rect
					delCtrl(gWnd.sel); // then delete it
					drawGrad(hwnd);
				}
			}
			ReleaseCapture();
			PostMessage(GetParent(hwnd),
						WM_COMMAND,
						MAKEWPARAM(gWnd.id, GRN_CHANGESEL),
						gWnd.sel);
			break;

		case WM_MOUSEMOVE:
//			printf("MM:  %d %d\n", LOWORD(lParam), HIWORD(lParam));
			if(GetCapture() != hwnd) break;
			if(gWnd.sel == -1) break;
			POINTS pt = MAKEPOINTS(lParam);
			if(pt.y < 0)
				SetCursor(gWnd.hCur); // show delete cursor if mouse is outside rect
			else
				SetCursor(LoadCursor(NULL, IDC_ARROW));

			int pos = calcCtrlPosFromPx(pt.x);
			// here we check to see if the control has been dragged past another
			// in which case we need to swap their places
			// to keep the control array in order
			if(gWnd.sel < (gWnd.numCtrls - 1) && CTRL_POS(gWnd.sel) > CTRL_POS(gWnd.sel+1)){
				swapCtrls(gWnd.sel, gWnd.sel+1);
				gWnd.sel++;
			}
			else if(gWnd.sel>0 && CTRL_POS(gWnd.sel) < CTRL_POS(gWnd.sel-1)){
				swapCtrls(gWnd.sel, gWnd.sel-1);
				gWnd.sel --;
			}
			setCtrlPosFromPts(gWnd.sel, pt);
			drawGrad(hwnd);
			break;

		case WM_PAINT:
			drawGrad(hwnd);
			ValidateRect(hwnd, NULL);
			break;
		default:
			return DefWindowProc(hwnd, msg, wParam, lParam);
	}
	return 0;
} // end GradWndProc




// primary initialisation function
// this would be called from the parent app
// return a handle to the newly created gradient control
//
// note argument dwID
// this is how the parent app will identify our control in notification messages
// and in calls like GetDlgItem etc.
HWND createGradient(HWND hwParent, RECT *pr, DWORD dwID){
	hInst = GetModuleHandle(NULL); // could be useful for LoadResource etc.

	memset(&gWnd, 0, sizeof(gWnd)); // clear our struct

	int err = Reg_Win_Class(0, GradWndProc, "gradient.win.class",
					NULL, NULL);
	assert(err);

	HWND hw = CreateWindow("gradient.win.class","Test",
				WS_CHILD|WS_VISIBLE,
				pr->left, pr->top, pr->right - pr->left, pr->bottom - pr->top,
				hwParent, (HMENU)dwID, hInst, 0);

	assert(hw);
	gWnd.hw = hw;
	gWnd.id = dwID;		// control identifier

	// create our offscreen buffer
	HDC hdc = GetDC(hw);
	assert(hdc);
	HBITMAP	hbm = CreateCompatibleBitmap(hdc, pr->right - pr->left, pr->bottom - pr->top);
	assert(hbm);
	gWnd.hbm = hbm;
	ReleaseDC(hw, hdc);
	// load the delete cursor
	gWnd.hCur = LoadCursor(hInst, MAKEINTRESOURCE(IDC_DELETE));
	return hw;
} // end createGradient

// this is an alternative method of creating the control
// I use this in dialogs
// create a dummy control, like a static rectangle
//	then call initGradient with a handle to the rectangle control
//	and it will replace that control with a gradient control
//	returning a handle to it
HWND initGradient(HWND hwnd, DWORD id){
	//gWnd.wproc = (WNDPROC)SetWindowLong(hwnd, GWL_WNDPROC, (long)GradWndProc);
	RECT r;
	HWND hw = NULL;
	GetWindowRect(hwnd, &r);
	ScreenToClient(GetParent(hwnd), (POINT*)&r);
	ScreenToClient(GetParent(hwnd), (POINT*)&r.right);
	hw = createGradient(GetParent(hwnd), &r, id);
	DestroyWindow(hwnd);
	return hw;
}
