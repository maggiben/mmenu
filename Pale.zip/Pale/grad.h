#ifndef grad_head
#define grad_head
#include <windows.h>


// notification messages - see GradWndProc
enum {
	GRN_CHANGESEL = WM_USER+25, // selection has changed
	GRN_RBDOWN
	};


// control messages
// these can be sent to the gradient control by parent app
enum {
	GM_SETCOLOR = WM_USER,
	GM_GETCOLOR,
	GM_GETSEL,
	GM_SETSEL,
	GM_GETPOS,
	GM_SETPOS,
	GM_GETCLUT,
	GM_SETCLUT,
	GM_GETCTRLCOUNT,
	GM_DEBUG
};

// exported functions
HWND initGradient(HWND hwnd, DWORD id);
HWND createGradient(HWND hwnd, RECT *pr, DWORD dwID);

#endif
