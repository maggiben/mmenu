/* lcc generated prototype file. Do not edit */
#ifndef __skinpro_h__
#define __skinpro_h__

long int SkinnedWindowProc(HANDLE, unsigned int, unsigned int, long int);
void InitSkin(HANDLE);
#endif
