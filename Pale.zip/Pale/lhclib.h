#ifndef LucAshLibFile_Header
#define LucAshLibFile_Header

#include <windows.h>
#include <ddraw.h>

#define DllExport    extern __declspec( dllexport )

#ifndef true
#define true (1)
#endif

#ifndef false
#define false (0)
#endif
#include "fplist.h"
#include "bmpf.h"


/****[ Constants ]**************************************************/

// Prompt_File_Name flags
enum {PFNF_OPEN = 1, PFNF_SAVE = 2};
// Prompt_Folder flags
enum {PFF_ALLOWNEW = 1};
// Load_Bitmap data
enum {BITMAP_ID = 0x4D42};
//#define BITMAP_ID            0x4D42 // universal id for a bitmap

#define		ERROR_TITLE		"Application alert"

#define LHERR_PARAMS		-6
#define LHERR_FILE_CREATE	-5
#define LHERR_FILE_WRITE	-4
#define LHERR_FILE_READ		-3
#define LHERR_DDERR			-2
#define LHERR_GENERIC		0
#define LH_OK				1


/****[ Macros ]*****************************************************/

#define INIT_DDSTRUCT(ddsd) { ZeroMemory(&ddsd, sizeof(ddsd));	ddsd.dwSize = sizeof(ddsd); }



/****[ Prototypes ]************************************************/
DllExport    int Get_LH_Version();

// Error routines

DllExport    void DbgPrintf(const char *szError,...);

DllExport    char * Get_Error_Msg();

DllExport    HRESULT	Error_Warn(HWND hwnd, HRESULT hRet, LPCTSTR szError,...);
DllExport    HRESULT	Warn(HWND hwnd, LPCTSTR szError,...);
DllExport    HRESULT Error_Quit(HWND hwnd, HRESULT hRet, LPCTSTR szError,...);

DllExport    FPNodePtr	Add_Exit_Func(CleanFPtr cfpFunc, DWORD dwData);
DllExport    void	Remove_Exit_Func(FPNodePtr	cfpNode);
DllExport    void	Run_Exit_Funcs();


// General WinUI routines
DllExport    int Reg_Win_Class(UINT uiStyle, WNDPROC wnProc, const char *szClassName,
				const char *szMenuName, HICON hIcon);

DllExport    char *Prompt_File_Name(int iFlags = PFNF_OPEN, HWND hwOwner = NULL, const char *pszFilter = NULL, const char *pszTitle = NULL);
DllExport    char *Prompt_Folder(int iFlags = 0, const char *pszTitle = NULL);

DllExport    int AddRem_TrayIcon(HICON hIcon, char *szTip, HWND hwnd, UINT uMsg, DWORD dwState, DWORD dwMode);

#define Add_TrayIcon(a,b,c,d,e) (AddRem_TrayIcon(a,b,c,d,e, NIM_ADD))
#define Del_TrayIcon(a,b,c,d,e) (AddRem_TrayIcon(a,b,c,d,e, NIM_DELETE))

DllExport    int Set_Scroll(HWND hwS, int iMin, int iMax, int iPos, UINT dwPage, UINT dwMask);

// Registry wrapper routines
DllExport    int Save_Reg_String(const char *pszKey, const char *pszValue, const char *pszString, DWORD dwFlags);
DllExport    int Save_Reg_Value(const char *pszKey, const char *pszValue, DWORD dwVal, DWORD dwFlags);
DllExport    int	Load_Reg_String(const char *pszKey, const char *pszValue, char *pszString, DWORD dwLength, DWORD dwFlags);
DllExport    int	Load_Reg_Value(const char *pszKey, const char *pszValue, DWORD *plVal, DWORD dwFlags);

// DirectDraw wrapper routines
DllExport    LPDIRECTDRAW4 Init_DD4(HWND hwnd);
DllExport    void Unload_DD4(DWORD dw=0);

DllExport    HRESULT Set_Full_Screen(HWND hwnd, int cx, int cy, int depth);
DllExport    HRESULT Create_Primary_Surface(LPDIRECTDRAWSURFACE4 *lpsMain);
DllExport    HRESULT Create_Flip_Surfaces(LPDIRECTDRAWSURFACE4 *lpsMain, LPDIRECTDRAWSURFACE4 *lpsBack);
DllExport    LPDIRECTDRAWSURFACE4 Create_Surface(int cx, int cy);

DllExport    HRESULT Clip_Surface(LPDIRECTDRAWSURFACE4 lps, LPDIRECTDRAWCLIPPER	*lpClip, int iNumRects, LPRECT	lpRects);

DllExport    HRESULT Copy_Bitmap_To_Surface(LPDIRECTDRAWSURFACE4	pDDs, HBITMAP	hBm, int x, int y, int cx, int cy);
DllExport    HRESULT Copy_Bmp_To_Surface(LPDIRECTDRAWSURFACE4	pDDs, BitmapPtr bpSrc, int x, int y);

DllExport    LPDIRECTDRAWPALETTE Load_Palette(const char *pszName);
DllExport    HRESULT	Save_Palette(const char *pszName, LPDIRECTDRAWPALETTE ppal);
DllExport    HRESULT Make_Win_Palette(LPDIRECTDRAWPALETTE	ppal);

//LPDIRECTDRAWSURFACE4	Load_Bitmap(const char *pszName);
DllExport    LPDIRECTDRAWSURFACE4	Load_Bitmap_DDPal(const char *pszName, LPDIRECTDRAWPALETTE *lpPal);
DllExport    LPDIRECTDRAWSURFACE4	Load_Bitmap(const char *pszName, PALETTEENTRY *ppal = NULL);

DllExport    void Fill_Surface(LPDIRECTDRAWSURFACE4 lps, int iCol);
DllExport    void Clip_Rect(LPRECT pRect, int iWidth, int iHeight);
DllExport    void Rect(LPDIRECTDRAWSURFACE4 lps, LPRECT pRect, int iCol);

DllExport    byte *Lock_Surface(LPDIRECTDRAWSURFACE4 lps, DWORD *pBytes, int *pWid = NULL, int *pHeight = NULL);
DllExport    void Unlock_Surface(LPDIRECTDRAWSURFACE4 lps);
DllExport    byte *Lock_Surface_Rect(LPDIRECTDRAWSURFACE4 lps, LPRECT pRect, DWORD *pBytes, int *pWid = NULL, int *pHeight = NULL);
DllExport    void Unlock_Surface_Rect(LPDIRECTDRAWSURFACE4 lps, LPRECT pRect);

// Path utility functions
DllExport    void Path_Append(char *path, const char *add);
DllExport    char *Path_Get_Path(char *path);
DllExport    void Path_Strip_Path(char *path);
DllExport    void Path_Strip_Ext(char *path);

#endif

