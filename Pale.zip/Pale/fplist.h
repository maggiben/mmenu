#ifndef LucAshLibFile_FPLIST_Header
#define LucAshLibFile_FPLIST_Header

/****[ Classes ]****************************************************/

#ifndef DllExport
#define DllExport    extern __declspec( dllexport )
#endif

#ifndef NULL
#define NULL (0L)
#endif

typedef void (*CleanFPtr)(DWORD dat);

typedef struct FPNode_tag {
	struct FPNode_tag	*next;
	CleanFPtr			func;
	DWORD				data;

} FPNode, *FPNodePtr;

inline FPNodePtr FPNode_New(FPNodePtr fp);
inline void FPNode_Delete(FPNodePtr fpl);
void	FPNode_Run(FPNodePtr fp);


typedef struct FPList_tag {
	FPNodePtr	head;
} FPList , *FPListPtr;


FPNodePtr	FPList_FindDup(FPListPtr fpl, CleanFPtr cfpFunc, DWORD dwData);
FPNodePtr	FPList_Push(FPListPtr fpl, CleanFPtr cfpFunc, DWORD dwData);
FPNodePtr	FPList_Pop(FPListPtr fpl);
void		FPList_Remove(FPListPtr fpl, FPNodePtr fpNode = NULL);
void		FPList_RemoveAll(FPListPtr fpl);
void		FPList_Run(FPListPtr fpl);

inline		FPListPtr FPList_New(FPListPtr fpl);
inline 		void FPList_Delete(FPListPtr fpl);
inline int	FPList_IsEmpty(FPListPtr fpl);

#endif

