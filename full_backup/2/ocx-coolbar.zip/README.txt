==================================================================

 CoolBar Controls

 1 October 2001

 You're free in using this software, as long as the
 orignal copyright/author information remains intact.
 In other words, respecting the person(s) who made it
 possible for you to view/learn something of this software.

 Copyright � 2001 - Diederik van der Boor
 http://www.codingdomain.com

==================================================================



Important Note: *NEVER* re-compile the source code in it's current state.
If you want to do that, please change the name of the project,
and give the DLL an other filename then used.
Actuallty, I would prefer you e-mail me the changes,
so I release a new version of the DLL.

Otherwise, some projects using the original DLL fail to run or crash at startup.