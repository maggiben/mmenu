DispHelper sample applications:

Coming soon to this directory will be small sample applications that make
use of DispHelper.





---------
DispHelper COM Helper Library:

DispHelper allows you to call COM objects with an extremely simple printf style syntax.
DispHelper can be used from C++ or even plain C. It works with most Windows compilers
including Dev-CPP, Visual C++ and LCC-WIN32. Including DispHelper in your project
couldn't be simpler as it is available in a compacted single file version.

Included with DispHelper are over 20 samples that demonstrate using COM objects
including ADO, CDO, Outlook, Eudora, Excel, Word, Internet Explorer, MSHTML,
PocketSoap, Word Perfect, MS Agent, SAPI, MSXML, WIA, dexplorer and WMI.

DispHelper is free open source software provided under the BSD license.

Find out more and download DispHelper at:
http://sourceforge.net/projects/disphelper/
http://disphelper.sourceforge.net/
