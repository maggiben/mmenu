/* Weditres generated include file. Do NOT edit */
#define	IDD_MAINDIALOG	100

#define	IDM_EXIT	113
#define	ID_LISTVIEW	130
#define	ID_MENU 	131
#define ID_LISTBOX  132
