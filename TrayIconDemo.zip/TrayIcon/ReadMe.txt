INSTALLATION & USER GUIDE FOR "TRAYICON" APPLICATION
----------------------------------------------------

This tiny program is used to minimize any window on your desktop to the system tray.
I write it for my use only, so I don't take any responsibiliy on damages this program may make on your system.
But if you find any usefulness from it, just use and distribute it as you want, because it's free.
If you have any idea to improve it or something else, just drop me a message.
----------------------------------------
 Author: Chau Nguyen
 Email: chaunguyen@psv.com.vn
---------------------------------------- 

A, INSTALLATION GUIDE:
   To install this program onto your system, do as following:
   1, Just copy only 2 files: "HookDLL.dll" and "TrayIcon.exe" to any the same folder on your system.
   2, Run the "TrayIcon.exe" program.
   3, Enjoy!!!

B, USER GUIDE:
   Whenever you run this program, it will hook into all system menu (menu on left corner of title bar) of all windows and append a new menu item "Tray Me" to it.
   If you choose this menu item, that window will be minized to the system tray. To restore to previous status of that window, just click on its icon on system tray.
   To Disable this program's function just right-click onto its icon on system tray, choose "Disable".
   To Exit this program just right-click onto its icon on system tray, choose "Exit".

NOTE:
   Because this version is a very early version, so it has some inconveniences that I didn't fix yet.
   But that will be fine, if you follow folowing guides:
   1, Restore (click the minized icon of windows in system tray) all windows before choosing Disable/Exit.

HAVE FUN, THANKS !!!

---------- END -------------