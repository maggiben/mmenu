//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by matrix.rc
//
#define IDS_DESCRIPTION                 1
#define IDD_CONFIG                      101
#define IDB_BITMAP1                     104
#define IDC_BLANKCURSOR                 105
#define IDI_ICON1                       106
#define IDB_BITMAP2                     110
#define IDB_BITMAP3                     111
#define IDC_COMBO1                      1003
#define IDC_REMOVE                      1004
#define IDC_ADD                         1005
#define IDC_PREVIEW                     1008
#define IDC_PREV                        1009
#define IDC_ENABLEPREV                  1013
#define IDC_RANDOM                      1014
#define IDC_SLIDER1                     1015
#define IDC_SLIDER2                     1016
#define IDC_SLIDER_DENSITY              1016
#define IDC_SLIDER3                     1017
#define IDC_SLIDER4                     1018
#define IDC_BOLD                        1019
#define IDC_COMBO2                      1020
#define IDC_MSGSPEEDGRP                 1021
#define IDC_ABOUT                       1022
#define IDC_SLIDER5                     1023
#define IDC_SLIDER_H                    1023
#define IDC_SLIDER6                     1024
#define IDC_SLIDER7                     1025
#define IDC_PREVIEW2                    1026
#define IDC_CYCLE                       1027

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        113
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1028
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
