// owner.h

#define ID_BUTSTART 100
#define ID_EXIT     100
#define ID_BMPUP    200
#define ID_BMPDOWN  201

LRESULT WINAPI MainWndProc(HWND, UINT, WPARAM, LPARAM);
void CreateOwnerdrawButtons(HWND);

