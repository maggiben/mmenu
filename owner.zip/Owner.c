/******************************************************************************
*                                                                             *
*  Example of OwnerDraw Buttons                                               *
*                                                                             *
*       John Findlay                                                          *
*                                                                             *
******************************************************************************/

#include <windows.h>
#include "owner.h"

HINSTANCE 	g_hInst;
HWND 		g_MainWnd;
HBITMAP 	g_hBmpUp;
HBITMAP 	g_hBmpDown;
int			g_BmpWidth;
int			g_BmpHeight;

int APIENTRY WinMain(HINSTANCE hInstance, HINSTANCE hPrev, LPSTR lpCmd, int nShow)
{
	WNDCLASS wc;
	MSG msg;

	g_hInst = hInstance;

	wc.style 			= 0;
	wc.lpfnWndProc 		= MainWndProc;
	wc.cbClsExtra 		= 0;
	wc.cbWndExtra 		= 0;
	wc.hInstance 		= g_hInst;
	wc.hCursor			= LoadCursor(NULL, IDC_ARROW);
	wc.hIcon 			= LoadIcon(NULL, IDI_APPLICATION);
	wc.hbrBackground	= (HBRUSH)(COLOR_BTNFACE + 1);
	wc.lpszMenuName		= NULL;
	wc.lpszClassName	= "OwnBut";

	if(!RegisterClass(&wc))
		return(FALSE);

	// Load images and change the colours to system colours
	g_hBmpUp= LoadImage(g_hInst, MAKEINTRESOURCE(ID_BMPUP), IMAGE_BITMAP,
												0, 0, LR_LOADMAP3DCOLORS);
	g_hBmpDown = LoadImage(g_hInst, MAKEINTRESOURCE(ID_BMPDOWN), IMAGE_BITMAP,
												0, 0, LR_LOADMAP3DCOLORS);

	BITMAP bm;

	// Get width & height
	GetObject(g_hBmpUp, sizeof(BITMAP), &bm);
	g_BmpWidth  = bm.bmWidth;
	g_BmpHeight = bm.bmHeight;


	g_MainWnd = CreateWindow("OwnBut", "OwnerDraw Buttons",
			WS_SYSMENU | WS_CAPTION | WS_POPUP | WS_THICKFRAME | WS_BORDER | WS_VISIBLE,
			20, 20, 260, 180,
			NULL, NULL, g_hInst, NULL);

	if(!g_MainWnd){
		return(FALSE);
	}

	ShowWindow(g_MainWnd, nShow);
	UpdateWindow(g_MainWnd);

	while(GetMessage(&msg, NULL, 0, 0))  //  Loop the loop
	{
		TranslateMessage(&msg);
		DispatchMessage(&msg);
	}

	//  cleanup bitmaps
	DeleteObject(g_hBmpUp);
	DeleteObject(g_hBmpDown);

	return(msg.wParam);
}

LRESULT WINAPI MainWndProc(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
	switch(msg)
	{
	case WM_CREATE:
		CreateOwnerdrawButtons(hWnd);
		return 0;

	case WM_COMMAND:
		if(wParam == ID_EXIT){
			PostQuitMessage(0);
			break;
		}
		break;

	case WM_DRAWITEM:{ //  Handles the ownerdraw button

		LPDRAWITEMSTRUCT lpDs = (LPDRAWITEMSTRUCT)lParam;
		HDC hDC;

		hDC = CreateCompatibleDC(lpDs->hDC);	// create a memory DC

		if(hDC){

			if(lpDs->itemState & ODS_SELECTED) //  if button is down
				SelectObject(hDC, g_hBmpDown);
			else
				SelectObject(hDC, g_hBmpUp);


				BitBlt(lpDs->hDC, 0, 0, g_BmpWidth, g_BmpHeight, hDC, 0, 0, SRCCOPY);
				DeleteDC(hDC);
		}

		// If an application processes this message, it should return TRUE.
		return(TRUE);
	}

	case WM_DESTROY:
		PostQuitMessage(0);
		break;

	default:
		return(DefWindowProc(hWnd, msg, wParam, lParam));
	}

	return(FALSE);

}

void CreateOwnerdrawButtons(HWND hWndParent)
{

	for (int i = 0; i<4; i++){

		CreateWindow("button", NULL, WS_CHILD | WS_VISIBLE | BS_OWNERDRAW,
					2, 10 + (i*(g_BmpHeight-1)) , g_BmpWidth, g_BmpHeight,
					hWndParent, (HMENU)(ID_BUTSTART + i), g_hInst, NULL);
	}

}


