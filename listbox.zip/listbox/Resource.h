
#define IDC_STATIC                      -1


#define IDC_DISPLAY                                    1007
#define IDC_LISTBOX                                    1008

#define IDD_PAGE1                                      2001
#define IDD_PAGE2                                      2002

#define IDC_STATIC1                                    3001
#define IDC_STATIC2                                    3002


