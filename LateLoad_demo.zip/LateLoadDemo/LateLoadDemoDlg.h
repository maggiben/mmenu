// LateLoadDemoDlg.h : header file
//

#if !defined(AFX_LATELOADDEMODLG_H__E1747153_87FE_4F46_AE5C_8EDFB317D57E__INCLUDED_)
#define AFX_LATELOADDEMODLG_H__E1747153_87FE_4F46_AE5C_8EDFB317D57E__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "LateLoad.h"

LATELOAD_BEGIN_CLASS(CMsImg32Wrapper,msimg32,FALSE,FALSE)
	LATELOAD_FUNC_6(FALSE,BOOL,STDAPICALLTYPE,GradientFill,HDC,PTRIVERTEX,ULONG,PVOID,ULONG,ULONG)
	LATELOAD_FUNC_0(FALSE,BOOL,STDAPICALLTYPE,BadFunctionName)
LATELOAD_END_CLASS()

/////////////////////////////////////////////////////////////////////////////
// CLateLoadDemoDlg dialog

class CLateLoadDemoDlg : public CDialog
{
// Construction
public:
	CLateLoadDemoDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	//{{AFX_DATA(CLateLoadDemoDlg)
	enum { IDD = IDD_LATELOADDEMO_DIALOG };
	CButton	m_grpGradient;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CLateLoadDemoDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;

	CMsImg32Wrapper m_msimg32;

	BOOL m_bHorizontal;
	CRect m_rcGradient;
	COLORREF m_clrStart;
	COLORREF m_clrEnd;

	// Generated message map functions
	//{{AFX_MSG(CLateLoadDemoDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnRadioHorz();
	afx_msg void OnRadioVert();
	afx_msg void OnBtnStart();
	afx_msg void OnBtnEnd();
	afx_msg BOOL OnHelpInfo(HELPINFO* pHelpInfo);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

	void UpdateButtonColorLabel(UINT nButtonID, COLORREF color);
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_LATELOADDEMODLG_H__E1747153_87FE_4F46_AE5C_8EDFB317D57E__INCLUDED_)
