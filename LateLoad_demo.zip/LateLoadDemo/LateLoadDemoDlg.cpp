// LateLoadDemoDlg.cpp : implementation file
//

#include "stdafx.h"
#include "LateLoadDemo.h"
#include "LateLoadDemoDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
		// No message handlers
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CLateLoadDemoDlg dialog

CLateLoadDemoDlg::CLateLoadDemoDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CLateLoadDemoDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CLateLoadDemoDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);

	m_bHorizontal = FALSE;
	m_clrStart    = RGB(255,255,0);
	m_clrEnd      = RGB(255,128,0);
}

void CLateLoadDemoDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CLateLoadDemoDlg)
	DDX_Control(pDX, IDC_GRP_GRADIENT, m_grpGradient);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CLateLoadDemoDlg, CDialog)
	//{{AFX_MSG_MAP(CLateLoadDemoDlg)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_RADIO_HORZ, OnRadioHorz)
	ON_BN_CLICKED(IDC_RADIO_VERT, OnRadioVert)
	ON_BN_CLICKED(IDC_BTN_START, OnBtnStart)
	ON_BN_CLICKED(IDC_BTN_END, OnBtnEnd)
	ON_WM_HELPINFO()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CLateLoadDemoDlg message handlers

BOOL CLateLoadDemoDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	// TODO: Add extra initialization here
	m_rcGradient.SetRectEmpty();
	UpdateButtonColorLabel(IDC_BTN_START,m_clrStart);
	UpdateButtonColorLabel(IDC_BTN_END,m_clrEnd);
	if( m_bHorizontal )
		CheckDlgButton(IDC_RADIO_HORZ,BST_CHECKED);
	else
		CheckDlgButton(IDC_RADIO_VERT,BST_CHECKED);

	// Attempt to call a non-existant function in MSIMG32.DLL
	if( m_msimg32.BadFunctionName() )
	{
		// This will never return true because the default return value in the 
		// LATELOAD_FUNC_ for this non-existant funct if FALSE
	}

	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CLateLoadDemoDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CLateLoadDemoDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		m_grpGradient.GetWindowRect(m_rcGradient);
		ScreenToClient(m_rcGradient);

		m_rcGradient.DeflateRect(10,20,10,10); // Arbitrary shrinkage values, just want to keep it from the edge

		CPaintDC dc(this);

		BOOL bPaintedGradient = FALSE;

		TRIVERTEX      vert[2];
		GRADIENT_RECT  gRect;
		vert[0].x      = m_rcGradient.left;
		vert[0].y      = m_rcGradient.top;
		vert[0].Red    = MAKEWORD(0,GetRValue(m_clrStart));
		vert[0].Green  = MAKEWORD(0,GetGValue(m_clrStart));
		vert[0].Blue   = MAKEWORD(0,GetBValue(m_clrStart));
		vert[0].Alpha  = 0x0000;

		vert[1].x      = m_rcGradient.right;
		vert[1].y      = m_rcGradient.bottom; 
		vert[1].Red    = MAKEWORD(0,GetRValue(m_clrEnd));
		vert[1].Green  = MAKEWORD(0,GetGValue(m_clrEnd));
		vert[1].Blue   = MAKEWORD(0,GetBValue(m_clrEnd));
		vert[1].Alpha  = 0x0000;

		gRect.UpperLeft  = 0;
		gRect.LowerRight = 1;
#if 0
		//Using this will require explicit linking to msimg32.lib
		bPaintedGradient = ::GradientFill(dc.GetSafeHdc(),vert,2,&gRect,1,m_bHorizontal?GRADIENT_FILL_RECT_H:GRADIENT_FILL_RECT_V);
#else
		bPaintedGradient = m_msimg32.GradientFill(dc.GetSafeHdc(),vert,2,&gRect,1,m_bHorizontal?GRADIENT_FILL_RECT_H:GRADIENT_FILL_RECT_V);
#endif

		if( !bPaintedGradient )
		{
			dc.SelectObject( GetFont() );
			dc.SetBkMode(TRANSPARENT);

			CString strMsg;
			CString strSettings;
			CString strWhy;

			if( !m_msimg32.Is_GradientFill() )
				strWhy.Format("\nReason:\n'%s', which should contain 'GradientFill', is not installed on this system",m_msimg32.dll_GetModuleName());
			else
				strWhy.Format("\nReason:\nThe API function 'GradientFill' failed\nLastError = 0x%08x", GetLastError());

			strSettings.Format("\n\nSettings\nOrientation: %s\nstart color: 0x%08x\nend color: 0x%08x",m_bHorizontal?"Horizontal":"Vertical",m_clrStart,m_clrEnd);

			strMsg.Format("Unable to draw gradient\n%s%s",strWhy,strSettings);

			dc.DrawText(strMsg,-1,m_rcGradient,DT_LEFT|DT_WORDBREAK);
		}
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CLateLoadDemoDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

void CLateLoadDemoDlg::OnRadioHorz() 
{
	m_bHorizontal = TRUE;
	InvalidateRect(m_rcGradient);
}

void CLateLoadDemoDlg::OnRadioVert() 
{
	m_bHorizontal = FALSE;
	InvalidateRect(m_rcGradient);
}

void CLateLoadDemoDlg::UpdateButtonColorLabel(UINT nButtonID, COLORREF color)
{
	CString strLabel;
	strLabel.Format("R:%02x G:%02x B:%02x", GetRValue(color), GetGValue(color), GetBValue(color) );

	SetDlgItemText(nButtonID,strLabel);
}

void CLateLoadDemoDlg::OnBtnStart() 
{
	// TODO: Add your control notification handler code here

	CColorDialog color(m_clrStart,CC_ANYCOLOR,this);
	if( IDOK == color.DoModal() )
	{
		m_clrStart = color.GetColor();
		UpdateButtonColorLabel(IDC_BTN_START,m_clrStart);
	}

	InvalidateRect(m_rcGradient);
}

void CLateLoadDemoDlg::OnBtnEnd() 
{
	// TODO: Add your control notification handler code here
	
	CColorDialog color(m_clrEnd,CC_ANYCOLOR,this);
	if( IDOK == color.DoModal() )
	{
		m_clrEnd = color.GetColor();
		UpdateButtonColorLabel(IDC_BTN_END,m_clrEnd);
	}

	InvalidateRect(m_rcGradient);
}

BOOL CLateLoadDemoDlg::OnHelpInfo(HELPINFO* /*pHelpInfo*/) 
{
	CAboutDlg dlgAbout;
	dlgAbout.DoModal();
	
	return FALSE;	

	//return CDialog::OnHelpInfo(pHelpInfo);
}
