// LateLoadDemo.h : main header file for the LATELOADDEMO application
//

#if !defined(AFX_LATELOADDEMO_H__E8B09957_785D_490F_9D6A_15962789EFD6__INCLUDED_)
#define AFX_LATELOADDEMO_H__E8B09957_785D_490F_9D6A_15962789EFD6__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols

/////////////////////////////////////////////////////////////////////////////
// CLateLoadDemoApp:
// See LateLoadDemo.cpp for the implementation of this class
//

class CLateLoadDemoApp : public CWinApp
{
public:
	CLateLoadDemoApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CLateLoadDemoApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation

	//{{AFX_MSG(CLateLoadDemoApp)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_LATELOADDEMO_H__E8B09957_785D_490F_9D6A_15962789EFD6__INCLUDED_)
