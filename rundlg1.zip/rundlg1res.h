/* Weditres generated include file. Do NOT edit */
#define	IDM_OPEN	210
#define	IDM_EXIT	300
#define	IDMAINMENU	600
#define IDSTAT		610
#define ID_ICON		1

