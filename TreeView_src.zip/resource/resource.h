//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by TreeControl.rsrc.rc
//
#define IDD_DIALOG1                     101
#define IDB_TREE                        134
#define IDB_FILE                        135
#define IDI_ICON1                       136
#define IDC_TREE1                       1059
#define IDC_DELETE                      1061
#define IDC_ADDROOT                     1062
#define IDC_CHILD                       1063
#define IDC_DELALL                      1065

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        137
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1066
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
