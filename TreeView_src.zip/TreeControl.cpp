#include <windows.h>
#include "resource\resource.h"
#include <commctrl.h>

//======================Handles================================================//
HINSTANCE hInst; // main function handler
#define WIN32_LEAN_AND_MEAN // this will assume smaller exe
TV_ITEM tvi;
HTREEITEM Selected;
TV_INSERTSTRUCT tvinsert;   // struct to config out tree control
HTREEITEM Parent;           // Tree item handle
HTREEITEM Before;           // .......
HTREEITEM Root;             // .......
HIMAGELIST hImageList;      // Image list array hadle
HBITMAP hBitMap;            // bitmap handler
bool flagSelected=false;

// for drag and drop
HWND hTree;
TVHITTESTINFO tvht; 
HTREEITEM hitTarget;
POINTS Pos;
bool Dragging;

// for lable editing
HWND hEdit;
//====================MAIN DIALOG==========================================//
BOOL CALLBACK DialogProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	switch (message) // what are we doing ?
	{ 	 
		// This Window Message is the heart of the dialog //
		//================================================//
		case WM_INITDIALOG: 
		{
			InitCommonControls();	    // make our tree control to work
			hTree=GetDlgItem(hWnd,IDC_TREE1);
			// creating image list and put it into the tree control
			//====================================================//
			hImageList=ImageList_Create(16,16,ILC_COLOR16,2,10);					  // Macro: 16x16:16bit with 2 pics [array]
			hBitMap=LoadBitmap(hInst,MAKEINTRESOURCE(IDB_TREE));					  // load the picture from the resource
			ImageList_Add(hImageList,hBitMap,NULL);								      // Macro: Attach the image, to the image list
			DeleteObject(hBitMap);													  // no need it after loading the bitmap
		    SendDlgItemMessage(hWnd,IDC_TREE1,TVM_SETIMAGELIST,0,(LPARAM)hImageList); // put it onto the tree control
			
			tvinsert.hParent=NULL;			// top most level no need handle
			tvinsert.hInsertAfter=TVI_ROOT; // work as root level
            tvinsert.item.mask=TVIF_TEXT|TVIF_IMAGE|TVIF_SELECTEDIMAGE;
	        tvinsert.item.pszText="Parent";
			tvinsert.item.iImage=0;
			tvinsert.item.iSelectedImage=1;
//	        [+]
//           | 
/*			 |--*/Parent=(HTREEITEM)SendDlgItemMessage(hWnd,IDC_TREE1,TVM_INSERTITEM,0,(LPARAM)&tvinsert);
/*			 |  */Root=Parent;
/*			 |  */Before=Parent;                   // handle of the before root
/*			 |  */tvinsert.hParent=Parent;         // handle of the above data
/*			 |  */tvinsert.hInsertAfter=TVI_LAST;  // below parent
/*			 |  */tvinsert.item.pszText="Child 1";
/*           |    |--[+] */
/*			 |    |   |  */
/*			 |    |   |*/ Parent=(HTREEITEM)SendDlgItemMessage(hWnd,IDC_TREE1,TVM_INSERTITEM,0,(LPARAM)&tvinsert);
/*			 |    |   |*/ tvinsert.hParent=Parent;
/*			 |    |   |*/ tvinsert.item.pszText="Child of Child1";
/*			 |    |   |*/ Parent=(HTREEITEM)SendDlgItemMessage(hWnd,IDC_TREE1,TVM_INSERTITEM,0,(LPARAM)&tvinsert);
/*           |    |   |-[+]*/
/*			 |    |	     | */ 
/*			 |    |	     | */
/*			 |    |	  */ tvinsert.hParent=Parent;
/*			 |    |	  */ tvinsert.hInsertAfter=TVI_LAST;
/*			 |    |	  */ tvinsert.item.pszText="Double Click Me!";
/*			 |    |	  */ tvinsert.item.mask=TVIF_TEXT;
/*			 |    |	  */ SendDlgItemMessage(hWnd,IDC_TREE1,TVM_INSERTITEM,0,(LPARAM)&tvinsert);			  
/*			 |	*/tvinsert.hParent=Before;         // handle of the above data
/*			 |	*/tvinsert.hInsertAfter=TVI_LAST;  // below parent
/*			 |	*/tvinsert.item.pszText="Child 2";
/*			 |	*/Parent=(HTREEITEM)SendDlgItemMessage(hWnd,IDC_TREE1,TVM_INSERTITEM,0,(LPARAM)&tvinsert);	   
/*			 |	*/
			 tvinsert.hParent=NULL;			// top most level no need handle
			 tvinsert.hInsertAfter=TVI_LAST; // work as root level
	         tvinsert.item.pszText="Parent2";
             Parent=(HTREEITEM)SendDlgItemMessage(hWnd,IDC_TREE1,TVM_INSERTITEM,0,(LPARAM)&tvinsert);
		
		}
		break;

		case WM_LBUTTONDOWN: 
		{
			ReleaseCapture(); 
			SendMessage(hWnd,WM_NCLBUTTONDOWN,HTCAPTION,0); 
		}
		break;

		case WM_NOTIFY:
		{
		    case IDC_TREE1:
            
			if(((LPNMHDR)lParam)->code == NM_DBLCLK) // if code == NM_CLICK - Single click on an item
			{
				char Text[255]="";
				memset(&tvi,0,sizeof(tvi));

				Selected=(HTREEITEM)SendDlgItemMessage(hWnd,IDC_TREE1,TVM_GETNEXTITEM,TVGN_CARET,(LPARAM)Selected);
				
				if(Selected==NULL)
				{
					MessageBox(hWnd,"No Items in TreeView","Error",MB_OK|MB_ICONINFORMATION);
					break;
				}
				TreeView_EnsureVisible(hWnd,Selected);
			    SendDlgItemMessage(hWnd,IDC_TREE1,TVM_SELECTITEM,TVGN_CARET,(LPARAM)Selected);
				flagSelected=true;
	            tvi.mask=TVIF_TEXT;
				tvi.pszText=Text;
				tvi.cchTextMax=256;
				tvi.hItem=Selected;
				
				if(SendDlgItemMessage(hWnd,IDC_TREE1,TVM_GETITEM,TVGN_CARET,(LPARAM)&tvi))
				{
					if(tvi.cChildren==0 && strcmp(tvi.pszText,"Double Click Me!")==0)
					{
					  MessageBox(hWnd,"Press OK to delete me!","Example",MB_OK|MB_ICONINFORMATION);
					  SendDlgItemMessage(hWnd,IDC_TREE1,TVM_DELETEITEM,TVGN_CARET,(LPARAM)tvi.hItem);
					  flagSelected=false;
					  break;
					}
				}
			}

			if(((LPNMHDR)lParam)->code == NM_RCLICK) // Right Click
			{
				Selected=(HTREEITEM)SendDlgItemMessage (hWnd,IDC_TREE1,TVM_GETNEXTITEM,TVGN_DROPHILITE,0);
				if(Selected==NULL)
				{
					MessageBox(hWnd,"No Items in TreeView","Error",MB_OK|MB_ICONINFORMATION);
					break;
				}
				
				SendDlgItemMessage(hWnd,IDC_TREE1,TVM_SELECTITEM,TVGN_CARET,(LPARAM)Selected);
				SendDlgItemMessage(hWnd,IDC_TREE1,TVM_SELECTITEM,TVGN_DROPHILITE,(LPARAM)Selected);
				TreeView_EnsureVisible(hTree,Selected);
			}

			if(((LPNMHDR)lParam)->code == TVN_BEGINDRAG)
			{
				HIMAGELIST hImg;
				LPNMTREEVIEW lpnmtv = (LPNMTREEVIEW) lParam;
				hImg=TreeView_CreateDragImage(hTree, lpnmtv->itemNew.hItem);
				ImageList_BeginDrag(hImg, 0, 0, 0);
				ImageList_DragEnter(hTree,lpnmtv->ptDrag.x,lpnmtv->ptDrag.y);
				ShowCursor(FALSE); 
				SetCapture(hWnd); 
				Dragging = TRUE;	
			}

			if(((LPNMHDR)lParam)->code == TVN_BEGINLABELEDIT)
			{
				hEdit=TreeView_GetEditControl(hTree);
			}

			if(((LPNMHDR)lParam)->code == TVN_ENDLABELEDIT)
			{
				char Text[256]="";
				tvi.hItem=Selected;
				SendDlgItemMessage(hWnd,IDC_TREE1,TVM_GETITEM,0,(WPARAM)&tvi);
				GetWindowText(hEdit, Text, sizeof(Text)); 
				tvi.pszText=Text;
				SendDlgItemMessage(hWnd,IDC_TREE1,TVM_SETITEM,0,(WPARAM)&tvi);
			}
		}
		break;

		case WM_MOUSEMOVE:
		{
			if (Dragging) 
			{ 
				Pos = MAKEPOINTS(lParam);
				ImageList_DragMove(Pos.x-32, Pos.y-25); // where to draw the drag from
				ImageList_DragShowNolock(FALSE);
				tvht.pt.x = Pos.x-20; // the highlight items should be as the same points as the drag
				tvht.pt.y = Pos.y-20; //
				if(hitTarget=(HTREEITEM)SendMessage(hTree,TVM_HITTEST,NULL,(LPARAM)&tvht)) // if there is a hit
					SendMessage(hTree,TVM_SELECTITEM,TVGN_DROPHILITE,(LPARAM)hitTarget);   // highlight it
			
			    ImageList_DragShowNolock(TRUE); 
			} 
		}
		break;

        case WM_LBUTTONUP:
        {
            if (Dragging) 
            {
                ImageList_DragLeave(hTree);
                ImageList_EndDrag();
                Selected=(HTREEITEM)SendDlgItemMessage(hWnd,IDC_TREE1,TVM_GETNEXTITEM,TVGN_DROPHILITE,0);
                SendDlgItemMessage(hWnd,IDC_TREE1,TVM_SELECTITEM,TVGN_CARET,(LPARAM)Selected);
                SendDlgItemMessage(hWnd,IDC_TREE1,TVM_SELECTITEM,TVGN_DROPHILITE,0);
                ReleaseCapture();
                ShowCursor(TRUE); 
                Dragging = FALSE;
            }
        }
        break;


		case WM_PAINT: // constantly painting the window
		{
			return 0;
		}
		break;
		
		case WM_COMMAND: // Controling the Buttons
		{
			switch (LOWORD(wParam)) // what we pressed on?
			{ 	 

				case IDC_DELETE: // Generage Button is pressed
				{
					
					if(flagSelected==true)
					{
					 if(tvi.cChildren==0)
					      SendDlgItemMessage(hWnd,IDC_TREE1,TVM_DELETEITEM,TVGN_CARET,(LPARAM)tvi.hItem);
					  flagSelected=false;
					}
					else{ 
						MessageBox(hWnd,"Double Click Item to Delete","Message",MB_OK|MB_ICONINFORMATION);
					}
				} 
				break;

				case IDC_ADDROOT:
				{
					tvinsert.hParent=NULL;			// top most level no need handle
					tvinsert.hInsertAfter=TVI_ROOT; // work as root level
					tvinsert.item.pszText="Parent Added";
					Parent=(HTREEITEM)SendDlgItemMessage(hWnd,IDC_TREE1,TVM_INSERTITEM,0,(LPARAM)&tvinsert);
					UpdateWindow(hWnd);
				}
				break;

				case IDC_CHILD:
				{
                    tvinsert.hParent=Selected;			// top most level no need handle
					tvinsert.hInsertAfter=TVI_LAST; // work as root level
					tvinsert.item.pszText="Child Added";
					Parent=(HTREEITEM)SendDlgItemMessage(hWnd,IDC_TREE1,TVM_INSERTITEM,0,(LPARAM)&tvinsert);
					TreeView_SelectDropTarget(GetDlgItem(hWnd,IDC_TREE1),Parent);
				}
				break;

				case IDC_DELALL:
				{
					int TreeCount=TreeView_GetCount(GetDlgItem(hWnd,IDC_TREE1));
					for(int i=0;i<TreeCount;i++)
						TreeView_DeleteAllItems(GetDlgItem(hWnd,IDC_TREE1));
				}
				break;	
			}
			break;

			case WM_CLOSE: // We colsing the Dialog
			{
				EndDialog(hWnd,0); 
			}
			break;
		}
		break;
	}
	return 0;
}

int WINAPI WinMain (HINSTANCE hInstance, HINSTANCE hPrevInstance, PSTR szCmdLine, int iCmdShow)
{
	hInst=hInstance;
	DialogBoxParam(hInstance, MAKEINTRESOURCE(IDD_DIALOG1), NULL, (DLGPROC)DialogProc,0);
	return 0;
}
