﻿namespace VS2005ToolBoxTest
{
  partial class Form1
  {
    /// <summary>
    /// Erforderliche Designervariable.
    /// </summary>
    private System.ComponentModel.IContainer components = null;

    /// <summary>
    /// Verwendete Ressourcen bereinigen.
    /// </summary>
    /// <param name="disposing">True, wenn verwaltete Ressourcen gelöscht werden sollen; andernfalls False.</param>
    protected override void Dispose(bool disposing)
    {
      if (disposing && (components != null))
      {
        components.Dispose();
      }
      base.Dispose(disposing);
    }

    #region Vom Windows Form-Designer generierter Code

    /// <summary>
    /// Erforderliche Methode für die Designerunterstützung.
    /// Der Inhalt der Methode darf nicht mit dem Code-Editor geändert werden.
    /// </summary>
    private void InitializeComponent()
    {
      this.components = new System.ComponentModel.Container();
      System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
      this.imageList1 = new System.Windows.Forms.ImageList(this.components);
      this.btnAddGroup = new System.Windows.Forms.Button();
      this.btnAddItem = new System.Windows.Forms.Button();
      this.groupBox1 = new System.Windows.Forms.GroupBox();
      this.cmsEdit = new System.Windows.Forms.ContextMenuStrip(this.components);
      this.mnuDeleteItem = new System.Windows.Forms.ToolStripMenuItem();
      this.toolBox1 = new VS2005ToolBox.ToolBox();
      this.renameItemToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
      this.cmsEdit.SuspendLayout();
      this.SuspendLayout();
      // 
      // imageList1
      // 
      this.imageList1.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageList1.ImageStream")));
      this.imageList1.TransparentColor = System.Drawing.Color.Transparent;
      this.imageList1.Images.SetKeyName(0, "ActualSizeHS.png");
      this.imageList1.Images.SetKeyName(1, "AddTableHS.png");
      this.imageList1.Images.SetKeyName(2, "AddToFavoritesHS.png");
      this.imageList1.Images.SetKeyName(3, "AlignObjectsBottomHS.png");
      this.imageList1.Images.SetKeyName(4, "AlignObjectsCenteredHorizontalHS.png");
      this.imageList1.Images.SetKeyName(5, "AlignObjectsCenteredVerticalHS.png");
      this.imageList1.Images.SetKeyName(6, "AlignObjectsLeftHS.png");
      this.imageList1.Images.SetKeyName(7, "AlignObjectsRightHS.png");
      this.imageList1.Images.SetKeyName(8, "AlignObjectsTopHS.png");
      this.imageList1.Images.SetKeyName(9, "AlignTableCellMiddleCenterHS.png");
      this.imageList1.Images.SetKeyName(10, "AlignTableCellMiddleLeftJustHS.png");
      this.imageList1.Images.SetKeyName(11, "AlignTableCellMiddleRightHS.png");
      this.imageList1.Images.SetKeyName(12, "AlignToGridHS.png");
      this.imageList1.Images.SetKeyName(13, "ArrangeSideBySideHS.png");
      this.imageList1.Images.SetKeyName(14, "ArrangeWindowsHS.png");
      // 
      // btnAddGroup
      // 
      this.btnAddGroup.Location = new System.Drawing.Point(316, 12);
      this.btnAddGroup.Name = "btnAddGroup";
      this.btnAddGroup.Size = new System.Drawing.Size(124, 23);
      this.btnAddGroup.TabIndex = 1;
      this.btnAddGroup.Text = "Add new Group";
      this.btnAddGroup.UseVisualStyleBackColor = true;
      this.btnAddGroup.Click += new System.EventHandler(this.btnAddGroup_Click);
      // 
      // btnAddItem
      // 
      this.btnAddItem.Enabled = false;
      this.btnAddItem.Location = new System.Drawing.Point(316, 42);
      this.btnAddItem.Name = "btnAddItem";
      this.btnAddItem.Size = new System.Drawing.Size(124, 23);
      this.btnAddItem.TabIndex = 2;
      this.btnAddItem.Text = "Add new Subitem";
      this.btnAddItem.UseVisualStyleBackColor = true;
      this.btnAddItem.Click += new System.EventHandler(this.btnAddItem_Click);
      // 
      // groupBox1
      // 
      this.groupBox1.Location = new System.Drawing.Point(219, 162);
      this.groupBox1.Name = "groupBox1";
      this.groupBox1.Size = new System.Drawing.Size(221, 161);
      this.groupBox1.TabIndex = 3;
      this.groupBox1.TabStop = false;
      this.groupBox1.Text = "Drop Area";
      this.groupBox1.DragDrop += new System.Windows.Forms.DragEventHandler(this.groupBox1_DragDrop);
      this.groupBox1.DragEnter += new System.Windows.Forms.DragEventHandler(this.groupBox1_DragEnter);
      // 
      // cmsEdit
      // 
      this.cmsEdit.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.renameItemToolStripMenuItem,
            this.mnuDeleteItem});
      this.cmsEdit.Name = "cmsEdit";
      this.cmsEdit.RenderMode = System.Windows.Forms.ToolStripRenderMode.Professional;
      this.cmsEdit.Size = new System.Drawing.Size(153, 70);
      // 
      // mnuDeleteItem
      // 
      this.mnuDeleteItem.Image = global::VS2005ToolBoxTest.Properties.Resources.DeleteHS;
      this.mnuDeleteItem.Name = "mnuDeleteItem";
      this.mnuDeleteItem.Size = new System.Drawing.Size(141, 22);
      this.mnuDeleteItem.Text = "&Delete Item";
      this.mnuDeleteItem.Click += new System.EventHandler(this.mnuDeleteItem_Click);
      // 
      // toolBox1
      // 
      this.toolBox1.BackColor = System.Drawing.SystemColors.Control;
      this.toolBox1.DrawMode = System.Windows.Forms.TreeViewDrawMode.OwnerDrawAll;
      this.toolBox1.FullRowSelect = true;
      this.toolBox1.HideSelection = false;
      this.toolBox1.HotTracking = true;
      this.toolBox1.ImageIndex = 0;
      this.toolBox1.ImageList = this.imageList1;
      this.toolBox1.ItemHeight = 20;
      this.toolBox1.Location = new System.Drawing.Point(12, 12);
      this.toolBox1.Name = "toolBox1";
      this.toolBox1.SelectedImageIndex = 0;
      this.toolBox1.ShowLines = false;
      this.toolBox1.ShowNodeToolTips = true;
      this.toolBox1.ShowPlusMinus = false;
      this.toolBox1.ShowRootLines = false;
      this.toolBox1.Size = new System.Drawing.Size(201, 311);
      this.toolBox1.TabIndex = 0;
      this.toolBox1.AfterSelect += new System.Windows.Forms.TreeViewEventHandler(this.toolBox1_AfterSelect);
      this.toolBox1.ItemDrag += new System.Windows.Forms.ItemDragEventHandler(this.toolBox1_ItemDrag);
      // 
      // renameItemToolStripMenuItem
      // 
      this.renameItemToolStripMenuItem.Name = "renameItemToolStripMenuItem";
      this.renameItemToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
      this.renameItemToolStripMenuItem.Text = "Rename Item";
      this.renameItemToolStripMenuItem.Click += new System.EventHandler(this.renameItemToolStripMenuItem_Click);
      // 
      // Form1
      // 
      this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
      this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
      this.ClientSize = new System.Drawing.Size(452, 335);
      this.Controls.Add(this.groupBox1);
      this.Controls.Add(this.btnAddItem);
      this.Controls.Add(this.btnAddGroup);
      this.Controls.Add(this.toolBox1);
      this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
      this.MaximizeBox = false;
      this.Name = "Form1";
      this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
      this.Text = "VS 2005 ToolBox Test";
      this.cmsEdit.ResumeLayout(false);
      this.ResumeLayout(false);

    }

    #endregion

    private VS2005ToolBox.ToolBox toolBox1;
    private System.Windows.Forms.Button btnAddGroup;
    private System.Windows.Forms.Button btnAddItem;
    private System.Windows.Forms.ImageList imageList1;
    private System.Windows.Forms.GroupBox groupBox1;
    private System.Windows.Forms.ContextMenuStrip cmsEdit;
    private System.Windows.Forms.ToolStripMenuItem mnuDeleteItem;
    private System.Windows.Forms.ToolStripMenuItem renameItemToolStripMenuItem;
  }
}

