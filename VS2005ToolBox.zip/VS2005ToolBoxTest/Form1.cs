using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using VS2005ToolBox;

namespace VS2005ToolBoxTest
{
  public partial class Form1 : Form
  {
    public Form1()
    {
      InitializeComponent();
      
      ProfessionalColorTable systemColorTable = new ProfessionalColorTable();
      systemColorTable.UseSystemColors        = true;

      cmsEdit.Renderer = new ToolStripProfessionalRenderer(systemColorTable);

      groupBox1.AllowDrop = true;
    }

    private void btnAddGroup_Click(object sender, EventArgs e)
    {
      ToolBox.VSTreeNode newGroup = new ToolBox.VSTreeNode();
      newGroup.Text = String.Format("Sample Node {0}", 
        toolBox1.Nodes.Count + 1);
      
      toolBox1.Nodes.Add(newGroup);

      if (toolBox1.SelectedNode == null)
      {
        toolBox1.SelectedNode = toolBox1.Nodes[0];
      }
    }

    private void toolBox1_AfterSelect(object sender, TreeViewEventArgs e)
    {
      btnAddItem.Enabled = toolBox1.SelectedNode.Level == 0;
    }

    private void btnAddItem_Click(object sender, EventArgs e)
    {
      Random rndImage = new Random();

      ToolBox.VSTreeNode newSubItem = new ToolBox.VSTreeNode();
      newSubItem.Text =  String.Format("Sample SubItem {0}",
        toolBox1.SelectedNode.Nodes.Count + 1);

      newSubItem.ImageIndex = rndImage.Next(imageList1.Images.Count);
      newSubItem.ToolTipCaption = newSubItem.Text;
      newSubItem.ToolTipText = "This is an example ToolTip for this SubItem.";

      newSubItem.ContextMenuStrip = this.cmsEdit;

      toolBox1.SelectedNode.Nodes.Add(newSubItem);

      toolBox1.SelectedNode.Expand();
    }

    private void toolBox1_ItemDrag(object sender, ItemDragEventArgs e)
    {
      if ((e.Item as ToolBox.VSTreeNode).Level != 0)
      {
        if (e.Button == MouseButtons.Left)
        {
          DoDragDrop(e.Item, DragDropEffects.Move);
        }

        else if (e.Button == MouseButtons.Right)
        {
          DoDragDrop(e.Item, DragDropEffects.Copy);
        }
      }
    }

    private void groupBox1_DragEnter(object sender, DragEventArgs e)
    {
      ToolBox.VSTreeNode draggedNode = (ToolBox.VSTreeNode)e.Data.GetData(typeof(ToolBox.VSTreeNode));

      if (draggedNode != null)
      {
        e.Effect = DragDropEffects.All;
      }
    }

    private void groupBox1_DragDrop(object sender, DragEventArgs e)
    {
      ToolBox.VSTreeNode draggedNode = (ToolBox.VSTreeNode)e.Data.GetData(typeof(ToolBox.VSTreeNode));

      if (draggedNode != null)
      {
        MessageBox.Show(String.Format("You dropped the Node {0}.",
          draggedNode.Text), "Dropped!", MessageBoxButtons.OK);
      }
    }

    private void mnuDeleteItem_Click(object sender, EventArgs e)
    {
      if (toolBox1.SelectedNode != null)
      {
        toolBox1.SelectedNode.Remove();
      }
    }

    private void renameItemToolStripMenuItem_Click(object sender, EventArgs e)
    {
      toolBox1.LabelEdit = true;
      toolBox1.SelectedNode.BeginEdit();
      toolBox1.LabelEdit = false;
    }
  }
}