// CntGdiObj.c

#include <windows.h>
#include <stdio.h>
#include <string.h>
#include "CntGdiObres.h"

/*
#define ID_PEN		1
#define ID_BRUSH	2
#define ID_DC		3
#define ID_METADC	4
#define ID_PAL		5
#define ID_FONT		6
#define ID_BITMAP	7
#define ID_REGION	8
#define ID_METAFILE	9
#define ID_MEMDC	10
#define ID_EXTPEN	11
#define ID_ENHMETADC	12
#define ID_ENHMETAFILE	13
*/

static BOOL CALLBACK DialogFunc(HWND hwndDlg, UINT msg, WPARAM wParam, LPARAM lParam);

int objects[14];

HBRUSH hBrush;

void CountGdiObjects(HWND hwnd)
{
	int i = 0, j = 0;
	for (i = 1; i<(ID_ENHMETAFILE+1); i++)
		objects[i] = 0;
	i = 0; // there are a posible 65k gdi objects on Win9x
	while(i <0xFFFF){
		i++;
		j = GetObjectType((void*)i);
		if (!j) continue;
		switch(j){
		case OBJ_PEN:
			objects[OBJ_PEN]++;
			break;
		case OBJ_BRUSH:
			objects[OBJ_BRUSH]++;
			break;
		case OBJ_DC:
			objects[OBJ_DC]++;
			break;
		case OBJ_METADC:
			objects[OBJ_METADC]++;
			break;
		case OBJ_PAL:
			objects[OBJ_PAL]++;
			break;
		case OBJ_FONT:
			objects[OBJ_FONT]++;
			break;
		case OBJ_BITMAP:
			objects[OBJ_BITMAP]++;
			break;
		case OBJ_REGION:
			objects[OBJ_REGION]++;
			break;
		case OBJ_METAFILE:
			objects[OBJ_METAFILE]++;
			break;
		case OBJ_MEMDC:
			objects[OBJ_MEMDC]++;
			break;
		case OBJ_EXTPEN:
			objects[OBJ_EXTPEN]++;
			break;
		case OBJ_ENHMETADC:
			objects[OBJ_ENHMETADC]++;
			break;
		case OBJ_ENHMETAFILE:
			objects[OBJ_ENHMETAFILE]++;
			break;
		} // end switch
	} // end while
}

int APIENTRY WinMain(HINSTANCE hinst, HINSTANCE hinstPrev, LPSTR lpCmdLine, int nCmdShow)
{
	WNDCLASS wc;

	hBrush = CreateSolidBrush(GetSysColor(COLOR_BTNFACE));

	memset(&wc,0,sizeof(wc));
	wc.lpfnWndProc 	 = DefDlgProc;
	wc.cbWndExtra 	 = DLGWINDOWEXTRA;
	wc.hInstance 	 = hinst;
	wc.hCursor 		 = LoadCursor(NULL, IDC_ARROW);
	wc.hIcon 		 = LoadIcon(hinst, MAKEINTRESOURCE(1));
	wc.hbrBackground = (HBRUSH) (COLOR_WINDOW + 1);
	wc.lpszClassName = "CntGdiObjs";
	RegisterClass(&wc);

	int ret = DialogBox(hinst, MAKEINTRESOURCE(IDD_MAINDIALOG), NULL, (DLGPROC) DialogFunc);
	DeleteObject(hBrush);
	return ret;
}

char buff[90];

static BOOL CALLBACK DialogFunc(HWND hwndDlg, UINT msg, WPARAM wParam, LPARAM lParam)
{
	switch (msg) {
	case WM_INITDIALOG:
		EnableWindow(GetDlgItem(hwndDlg, ID_SECOND),FALSE);
		EnableWindow(GetDlgItem(hwndDlg, ID_THIRD),FALSE);
		EnableWindow(GetDlgItem(hwndDlg, ID_RESET),FALSE);
		return TRUE;

	case WM_COMMAND:
		switch (LOWORD(wParam)) {
		case ID_FIRST:
			EnableWindow(GetDlgItem(hwndDlg, ID_FIRST),FALSE);
			EnableWindow(GetDlgItem(hwndDlg, ID_RESET),TRUE);
			CountGdiObjects(hwndDlg);
			for(int i = ID_PEN; i<(ID_ENHMETAFILE+1); i++){
				itoa(objects[i], buff, 10);
				SetDlgItemText(hwndDlg, i, buff);
			}
			EnableWindow(GetDlgItem(hwndDlg, ID_SECOND),TRUE);
			break;

		case ID_SECOND:
			EnableWindow(GetDlgItem(hwndDlg, ID_FIRST),FALSE);
			EnableWindow(GetDlgItem(hwndDlg, ID_SECOND),FALSE);
			CountGdiObjects(hwndDlg);
			for(int i = ID_PEN; i<(ID_ENHMETAFILE+1); i++){
				itoa(objects[i], buff, 10);
				SetDlgItemText(hwndDlg, 13+i, buff);
			}
			EnableWindow(GetDlgItem(hwndDlg, ID_THIRD),TRUE);
			break;

		case ID_THIRD:
			EnableWindow(GetDlgItem(hwndDlg, ID_FIRST),FALSE);
			EnableWindow(GetDlgItem(hwndDlg, ID_SECOND),FALSE);
			EnableWindow(GetDlgItem(hwndDlg, ID_THIRD),FALSE);
			CountGdiObjects(hwndDlg);
			for(int i = ID_PEN; i<(ID_ENHMETAFILE+1); i++){
				itoa(objects[i], buff, 10);
				SetDlgItemText(hwndDlg, 26+i, buff);
			}
			break;

		case ID_RESET:
			EnableWindow(GetDlgItem(hwndDlg, ID_FIRST),TRUE);
			EnableWindow(GetDlgItem(hwndDlg, ID_SECOND),FALSE);
			EnableWindow(GetDlgItem(hwndDlg, ID_THIRD),FALSE);
			EnableWindow(GetDlgItem(hwndDlg, ID_RESET),FALSE);
			for(int i = ID_PEN; i<(ID_ENHMETAFILE*3+1); i++)
				SetDlgItemText(hwndDlg, i, "");
			break;

		case ID_QUIT:
		case IDCANCEL:
			EndDialog(hwndDlg,0);
			return 1;
		}
		break;

	case WM_CTLCOLORSTATIC:{
		int ctrl = GetDlgCtrlID((HWND)lParam);
		if((ctrl > (ID_PEN-1)) && ctrl < (ID_ENHMETAFILE*3+1)){
			return (BOOL)GetStockObject(WHITE_BRUSH);
		}
		if((ctrl > ID_STATIC) && (ctrl < (ID_STATIC3+1))){
			SetTextColor((HDC)wParam, RGB(0,0,255));
			SetBkColor((HDC)wParam, GetSysColor(COLOR_BTNFACE));
			return (BOOL)hBrush;
		}
		if(ctrl == ID_STATIC){
			SetTextColor((HDC)wParam, RGB(255,0,0));
			SetBkColor((HDC)wParam, GetSysColor(COLOR_BTNFACE));
			return (BOOL)hBrush;
		}
		break;
		}

	case WM_CLOSE:
		EndDialog(hwndDlg,0);
		return TRUE;

	}
	return FALSE;

}
