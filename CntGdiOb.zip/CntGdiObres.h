//CntGdiObjres.h

#define	IDD_MAINDIALOG	100

#define ID_PEN		1
#define ID_BRUSH	2
#define ID_DC		3
#define ID_METADC	4
#define ID_PAL		5
#define ID_FONT		6
#define ID_BITMAP	7
#define ID_REGION	8
#define ID_METAFILE	9
#define ID_MEMDC	10
#define ID_EXTPEN	11
#define ID_ENHMETADC	12
#define ID_ENHMETAFILE	13

#define ID_PEN1		14
#define ID_BRUSH1	15
#define ID_DC1		16
#define ID_METADC1	17
#define ID_PAL1		18
#define ID_FONT1	19
#define ID_BITMAP1	20
#define ID_REGION1	21
#define ID_METAFILE1	22
#define ID_MEMDC1	23
#define ID_EXTPEN1	24
#define ID_ENHMETADC1	25
#define ID_ENHMETAFILE1	26

#define ID_PEN2		27
#define ID_BRUSH2	28
#define ID_DC2		29
#define ID_METADC2	30
#define ID_PAL2		31
#define ID_FONT2	32
#define ID_BITMAP2	33
#define ID_REGION2	34
#define ID_METAFILE2	35
#define ID_MEMDC2	36
#define ID_EXTPEN2	37
#define ID_ENHMETADC2	38
#define ID_ENHMETAFILE2	39

#define	ID_RESET	430
#define	ID_QUIT		431
#define	ID_FIRST	300
#define	ID_SECOND	301
#define	ID_THIRD	302

#define ID_STATIC	491
#define ID_STATIC1  492
#define ID_STATIC2  493
#define ID_STATIC3  494

