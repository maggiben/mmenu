// show.c

#include <windows.h>
#include <stdio.h>
#include <commctrl.h>
#include "helper.h"
#include "jcom.h"

char g_str[512];

/*--------------------------------------------------------------------
	Function	AddTreeItem()

	Purpose		Adds an item to a treeview.

	Input		hwndTV      -> TreeView handle
				hParentNode -> handle to a parent node. (Rarely used)
				pszItem     -> pointer to C string as item text
				nLevel      -> indent level, (if hParentNode is used
							   this parmeter is not)
				pObj        -> pointer to store in the TV lParam

	Return		handle of item just added

--------------------------------------------------------------------*/
HTREEITEM AddTreeItem( HWND hwndTV, HTREEITEM hParentNode, char * pszItem, int nLevel, void * pObj = NULL )
{
	TVITEM tvi;
	TVINSERTSTRUCT tvins;
	static HTREEITEM hPrev = (HTREEITEM) TVI_FIRST;
	static HTREEITEM hPrevRootItem[10] = {NULL};

	tvi.mask = TVIF_TEXT | TVIF_PARAM;

	// Set the text of the item.
	tvi.pszText 	= pszItem;
	tvi.cchTextMax  = strlen(pszItem);

	// item's application-defined data area.
	tvi.lParam = (LPARAM) pObj;

	tvins.item = tvi;
	tvins.hInsertAfter = hPrev;

	// Set the parent item based on the specified level
	// or hParentNode.
	if (hParentNode)
		tvins.hParent = hParentNode;
	else if ( nLevel == 1 )
		tvins.hParent = TVI_ROOT;
	else
		tvins.hParent = hPrevRootItem[nLevel-1];

	// Add the item to the tree-view control.
	hPrev = TreeView_InsertItem( hwndTV, &tvins );

	// Save the handle to the item.
	hPrevRootItem[nLevel] = hPrev;

	return hPrev;
}

void ShowVars( HWND hwndTV, GENERIC_VARS * p, int nLevel )
{
	VAR_LIST * pVars = p->pVars;

	while( pVars ){

		if ( (p->eTypeKind == TKIND_ENUM) || (p->eTypeKind == TKIND_MODULE) ){
			sprintf( g_str, "%s = %d",  pVars->pName, pVars->iValue);
		}else{
			if ( (pVars->iVarType == VT_USERDEFINED) || (pVars->iVarType == VT_PTR) || (pVars->iVarType == VT_SAFEARRAY ) || (pVars->iVarType == VT_CARRAY) ){
				sprintf( g_str, "%s %s", pVars->pCustomName, pVars->pName );
			}else{
				sprintf( g_str, "%s %s", ParamTypeToA( pVars->iVarType ), pVars->pName );
			}
		}
		AddTreeItem( hwndTV, NULL, g_str, nLevel, NULL );
		pVars = pVars->pNext;
	}

}

void ShowMethods( HWND hwndTV, METHOD_LIST * pMethod, int nLevel )
{
	while( pMethod ){
		AddTreeItem( hwndTV, NULL, pMethod->pName, nLevel, pMethod );
		pMethod = pMethod->pNext;
	}

}

void ShowProps( HWND hwndTV, PROPERTY_LIST * pProp, int nLevel )
{
	while( pProp ){
		AddTreeItem( hwndTV, NULL, pProp->pName, nLevel, pProp );
		pProp = pProp->pNext;
	}
}

void ShowDispInherited( HWND hwndTV, DISPATCH_LIST * pDisp, int offset )
{
	METHOD_LIST   	* pMethod  = pDisp->pMethod;
	PROPERTY_LIST 	* pProp    = pDisp->pProperty;

	if ( !pDisp->numMethods )
		return;

	AddTreeItem( hwndTV, NULL, "IDispatch", 3+offset, NULL );
	ShowMethods( hwndTV, pMethod, 4+offset );

	if (pDisp->pProperty){
		AddTreeItem( hwndTV, NULL, "Properties", 3+offset, NULL );
		if ( pDisp->numProperties ){
			ShowProps( hwndTV, pProp, 4+offset );
		}
	}
}

void ShowInherited( HWND hwndTV, INTERFACE * pInterface, int offset )
{
	METHOD_LIST   	* pMethod  = pInterface->pMethod;

	if ( !pInterface->numMethods )
		return;

	AddTreeItem( hwndTV, NULL, "IDispatch", 3+offset, NULL );
	ShowMethods( hwndTV, pMethod, 4+offset );

}

void ShowInterface( HWND hwndTV, TYPE_LIST * pTypeList )
{
	INTERFACE       * pInterface = pTypeList->pInterface;
	METHOD_LIST   	* pMethod    = pInterface->pMethod;

	if ( pInterface->fInherited ){
		sprintf( g_str, "Interface %s",  pInterface->pName );
		AddTreeItem( hwndTV, NULL, g_str, 1, pInterface );
		AddTreeItem( hwndTV, NULL, "Inherited Interface", 2, NULL );
		ShowInherited( hwndTV, pInterface, 0 );
		return;
	}

	if ( pInterface->numMethods ){
		sprintf( g_str, "Interface %s",  pInterface->pName );
		AddTreeItem( hwndTV, NULL, g_str, 1, NULL );
		AddTreeItem( hwndTV, NULL, "Methods", 2, NULL );
		if ( pInterface->numMethods )
			ShowMethods( hwndTV, pMethod, 3 );
	}

}

void ShowDisp( HWND hwndTV, TYPE_LIST * pTypeList )
{
	DISPATCH_LIST	* pDisp    = pTypeList->pDispInterface;
	METHOD_LIST   	* pMethod  = pDisp->pMethod;
	PROPERTY_LIST 	* pProp    = pDisp->pProperty;

	// dual interface allows for early binding
	if ( pDisp->pInterface )
		sprintf( g_str, "DispInterface (dual) %s",  pDisp->pName);
	else
		sprintf( g_str, "DispInterface %s",  pDisp->pName);

	AddTreeItem( hwndTV, NULL, g_str, 1, pDisp );

	AddTreeItem( hwndTV, NULL, "Methods", 2, NULL );
	if ( pDisp->numMethods )
		ShowMethods( hwndTV, pMethod, 3 );

	if ( pDisp->numProperties )
		AddTreeItem( hwndTV, NULL, "Properties", 2, NULL );
		ShowProps( hwndTV, pProp, 3 );

	if (pDisp->fInherited){
		AddTreeItem( hwndTV, NULL, g_str, 1, pDisp );
		AddTreeItem( hwndTV, NULL, "Inherited Interface", 2, NULL );
		ShowDispInherited( hwndTV, pDisp, 0 );
		return;
	}

	// this means that there is a dual interface
	// and can be used with early binding to the vtbl
	if (pDisp->pInterface){
		sprintf( g_str, "Interface %s",  pDisp->pName);
		AddTreeItem( hwndTV, NULL, g_str, 2, NULL );
		ShowMethods( hwndTV, pDisp->pInterface->pMethod, 3 );
	}
}

void ShowCoClass( HWND hwndTV, TYPE_LIST * pTypeList )
{
	COCLASS_LIST * pCoClass = pTypeList->pCoClass;
	DISPATCH_LIST * pDisp = pCoClass->pDispInterface;

	sprintf( g_str, "CoClass %s",  pCoClass->pName);
	AddTreeItem( hwndTV, NULL, g_str, 1, pCoClass );

	///////////////////////////////////////////////////////////
	// An Interface can attached to a CoClass.
	///////////////////////////////////////////////////////////
	if (pCoClass->pInterface){
		sprintf( g_str, "Interface %s",  pCoClass->pInterface->pName);
		AddTreeItem( hwndTV, NULL, g_str, 2, NULL );
		ShowMethods( hwndTV, pCoClass->pInterface->pMethod, 3 );
	}

	///////////////////////////////////////////////////////////
	// A DispatchInterface can have a linked list when
	// associated with a CoClass.
	///////////////////////////////////////////////////////////
	while ( pDisp ){
		if (pDisp->fInherited){
			sprintf ( g_str, "%s %s", "DispInterface", pDisp->pName );
			AddTreeItem( hwndTV, NULL, g_str, 2, pDisp );
			AddTreeItem( hwndTV, NULL, "Inherited Interface", 3, NULL );
			ShowDispInherited( hwndTV, pDisp, 1 );
			goto next;
		}

		METHOD_LIST	* pMethod   = pDisp->pMethod;

		if ( pDisp->pMethod ){
			if ( !pDisp->numMethods )
				break;

			sprintf ( g_str, "%s %s", "DispInterface", pDisp->pName );
			AddTreeItem( hwndTV, NULL, g_str, 2, pDisp );

			AddTreeItem( hwndTV, NULL, "Methods", 3, NULL );
			ShowMethods( hwndTV, pMethod, 4 );

			if ( pDisp->pProperty ){
				PROPERTY_LIST * pProp    = pDisp->pProperty;
				AddTreeItem( hwndTV, NULL, "Properties", 3, NULL );
				ShowProps( hwndTV, pProp, 4 );
			}

			if (pDisp->pInterface){

				METHOD_LIST   	* pMethod  = pDisp->pInterface->pMethod;
				sprintf( g_str, "Inherited Interface %s",  pDisp->pInterface->pName);
				AddTreeItem( hwndTV, NULL, g_str, 2, pDisp->pInterface );
				AddTreeItem( hwndTV, NULL, "Methods", 3, NULL );
				ShowMethods( hwndTV, pMethod, 4 );
			}
		}
		next:
		pDisp = pDisp->pNext;
	}

}

void ShowUnion( HWND hwndTV, TYPE_LIST * pTypeList )
{
	UNION    * pUnion = pTypeList->pUnion;

	sprintf( g_str, "typedef union %s",  pUnion->pName);
	AddTreeItem( hwndTV, NULL, g_str, 1, pUnion );

	ShowVars( hwndTV, (GENERIC_VARS*)pUnion, 2 );
}

void ShowEnum( HWND hwndTV, TYPE_LIST * pTypeList )
{
	ENUM     * pEnum = pTypeList->pEnum;

	sprintf( g_str, "typedef Enum %s",  pEnum->pName);
	AddTreeItem( hwndTV, NULL, g_str, 1, pEnum );

	ShowVars( hwndTV, (GENERIC_VARS*)pEnum, 2 );
}

void ShowStruct( HWND hwndTV, TYPE_LIST * pTypeList )
{
	STRUCT   * pStruct = pTypeList->pStruct;

	sprintf( g_str, "typedef struct %s",  pStruct->pName);
	AddTreeItem( hwndTV, NULL, g_str, 1, pStruct );

	ShowVars( hwndTV, (GENERIC_VARS*)pStruct, 2 );
}

void ShowAlias( HWND hwndTV, TYPE_LIST * pTypeList )
{
	sprintf( g_str, "typedef alias %s",  pTypeList->pAlias->pName);
	AddTreeItem( hwndTV, NULL, g_str, 1, NULL );
	strcpy( g_str, pTypeList->pAlias->pRealName);
	AddTreeItem( hwndTV, NULL, g_str, 2, pTypeList->pAlias );
}

void ShowModule( HWND hwndTV, TYPE_LIST * pTypeList )
{
	MODULE   * pMod = pTypeList->pModule;

	sprintf( g_str, "Module %s",  pMod->pName);
	AddTreeItem( hwndTV, NULL, g_str, 1, NULL );

	ShowVars( hwndTV, (GENERIC_VARS*)pMod, 2 );
}


