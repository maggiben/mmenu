// show.h

void ShowVars( HWND hwndTV, GENERIC_VARS * p, int nLevel );
void ShowMethods( HWND hwndTV, METHOD_LIST * pMethod, int nLevel );
void ShowProps( HWND hwndTV, PROPERTY_LIST * pProp, int nLevel );
void ShowDispInherited( HWND hwndTV, DISPATCH_LIST * pDisp, int offset );
void ShowInherited( HWND hwndTV, INTERFACE * pInterface, int offset );
void ShowInterface( HWND hwndTV, TYPE_LIST * pTypeList );
void ShowDisp( HWND hwndTV, TYPE_LIST * pTypeList );
void ShowCoClass( HWND hwndTV, TYPE_LIST * pTypeList );
void ShowUnion( HWND hwndTV, TYPE_LIST * pTypeList );
void ShowEnum( HWND hwndTV, TYPE_LIST * pTypeList );
void ShowStruct( HWND hwndTV, TYPE_LIST * pTypeList );
void ShowAlias( HWND hwndTV, TYPE_LIST * pTypeList );
void ShowModule( HWND hwndTV, TYPE_LIST * pTypeList );

