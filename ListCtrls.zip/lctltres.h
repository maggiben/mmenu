/* Weditres generated include file. Do NOT edit */
#define	ID_QUIT	1
#define	IDD_MAINDIALOG	100
#define	ID_LISTBOX	101
#define	ID_EDITBOX	102
#define	ID_HELP	103
#define	ID_ICON	104
#define	IDC_ICON	105
#define	ID_EDITBOX1	106
#define	IDM_EXIT	120
#define	ID_TREEVIEW	200
#define	ID_TREEVIEW1	201
#define	DLG_0300	300
