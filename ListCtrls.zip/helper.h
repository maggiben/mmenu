#include "jcom.h"

#define STRCONVERT_MAXLEN 512

void     ShowError( int hr );
REG_INTERFACE * CollectAllRegisteredInterfaces( void );
char    * GetFileNamePointer( char * pFilePath );
unsigned long GetVariantIntValue( VARIANT * v );
char    * GetPathOfRegTypeLib( CLSID * pclsid );
char 	* GetCustomType( HREFTYPE refType, ITypeInfo * pti );
int       AllocStoreStr( OLECHAR * strOle, char ** str );
char 	* UnicodeToAnsi( OLECHAR * szW );
char 	* EnumToA( ENUM * pEnum );
char 	* MethodToA( METHOD_LIST * pMethod );
char    * ModuleToA( MODULE * pMod );
char    * InterfaceToA( INTERFACE * pInterface );
char    * AliasToA( ALIAS * pAlias );
char 	* PropertyToA( PROPERTY_LIST * pProp );
char    * CoClassToA( COCLASS_LIST * pCoClass );
char 	* DispatchToA( DISPATCH_LIST * pDisp );
char 	* TypeLibraryToA( TYPELIBARAY * TypeLibrary );
char 	* ParamTypeToA( unsigned short vt );
char 	* TypeSysKindToA( int kind );
char 	* TypeKindToA(int kind);
char 	* InvokeKindToA( int inv );
char 	* FuncKindToA( int kind );
OLECHAR * AnsiToUnicode(char * strA);

