#define _OLEAUT32_
#include <windows.h>
#include <ole2.h>
#include <comcat.h>
#include <stdio.h>
#include <stdlib.h>
#include <shellapi.h>
#include <gc.h>
#include "jcom.h"
#include "helper.h"

int GetTypeLists( ITypeLib * pITypeLib, TYPE_LIST * pTypeList, int cTypeCount );


/*--------------------------------------------------------------------
	Function	GetDocumentationStrings()

	Purpose		Used to fill in most names for docstring, helpfile
				and name.

	Input		pRegClsid     -> CTRL_CLSDID struct of control selected.
				pTypeLibrary  -> pointer to the TYPELIBARAY struct

	Return		Zero on success

	Errors		ERR_MEMORY.
--------------------------------------------------------------------*/
int GetDocumentationStrings( ITypeInfo * pITypeInfo, void * p, int id )
{
	HRESULT	   hr;
	OLECHAR  * bstrName;
	OLECHAR  * bstrDocString;
	OLECHAR  * bstrHelpFile;
	DWORD 	   ulHelpContext;

	////////////////////////////////////////////////////////
	// This function relies on all structs having
	// ->pName ->pDocString ->pHelpFile & ->ulHelpContext
	// positioned in the same place.
	////////////////////////////////////////////////////////

	// This pointer (pGeneric) will be used to point to any of the TYPE structures
	// to access ->pName, ->pDocString, ->pHelpFile and ->ulHelpContext.
	GENERIC_LIST 	* pGeneric = p;

	hr = pITypeInfo->lpVtbl->GetDocumentation( pITypeInfo, id,
							&bstrName, &bstrDocString, &ulHelpContext, &bstrHelpFile);
	if ( SUCCEEDED(hr) ){
		// store the strings
		if (FAILED(AllocStoreStr( bstrName, &pGeneric->pName )))
			return ERR_MEMORY;
		if (FAILED(AllocStoreStr( bstrDocString, &pGeneric->pDocString )))
			return ERR_MEMORY;
		if (FAILED(AllocStoreStr( bstrHelpFile, &pGeneric->pHelpFile )))
			return ERR_MEMORY;

		SysFreeString( bstrName );
		SysFreeString( bstrDocString );
		SysFreeString( bstrHelpFile );
		pGeneric->ulHelpContext = ulHelpContext;
	}
	return 0;
}

/*--------------------------------------------------------------------
	Function	ExtractCtrlIcon()

	Purpose		Gets the icon (if possible) from the control

	Input		path  -> file name of control.

	Return		icon handle

	Errors		NULL
--------------------------------------------------------------------*/
HICON ExtractCtrlIcon(char * path)
{
	HICON hLargeIcon = NULL;
	HICON hSmallIcon = NULL;
	int hr = ExtractIconEx(path, 0, &hLargeIcon, &hSmallIcon, 1);
	if ( hSmallIcon ) DeleteObject( hSmallIcon );
	if (hr > 0)
		return hLargeIcon;
	else
		return NULL;
}

/*--------------------------------------------------------------------
	Function	GetTypeLibaray()

	Purpose		The TYPELIBARAY struct is the root struct. This function
				fills in various values for the TYPELIBARAY and then calls
				GetTypeLists() that starts filling in all other structs.

	Input		pRegClsid     -> CTRL_CLSDID of control selected.
				pTypeLibrary  -> pointer to the TYPELIBARAY struct

	Return		Zero on success

	Errors		various errors - ERR_NOLIBATTR etc.
--------------------------------------------------------------------*/
int GetTypeLibaray( CTRL_CLSID * pCtrlClsid, TYPELIBARAY * pTypeLibrary )
{
	ITypeLib * pITypeLib = NULL;
	OLECHAR  * bstrDocString;
	OLECHAR  * bstrHelpFile;
	OLECHAR  * bstrName;
	unsigned long ulHelpContext;
	HRESULT hr;

	// delete any previous icon before clearing struct
	if ( pTypeLibrary->hIcon )
		DeleteObject( pTypeLibrary->hIcon );

	memset( pTypeLibrary, 0, sizeof(TYPELIBARAY) ); // clear it

	memcpy( &pTypeLibrary->CtrlCLSID, &pCtrlClsid->regclsid, sizeof(CLSID));

	char * path = GetPathOfRegTypeLib( &pCtrlClsid->regclsid );
	if ( path == NULL )
		return ERR_NOFILEPATH;

	pTypeLibrary->hIcon = ExtractCtrlIcon( path );

	// store the path
	pTypeLibrary->pTypeLibFile = GC_malloc( strlen( path )+1 );
	if ( !pTypeLibrary->pTypeLibFile )
		return ERR_MEMORY;
	strcpy( pTypeLibrary->pTypeLibFile, path );

	// might need to use LoadTypeLibEx() with just the file name, not the path
	char * pFile = GetFileNamePointer( pTypeLibrary->pTypeLibFile );

	//////////////////////////////////////////////////////////////////////////
	// load it. if no path is given LoadTypeLib will not register the library
	//////////////////////////////////////////////////////////////////////////
	hr = LoadTypeLibEx( AnsiToUnicode( pTypeLibrary->pTypeLibFile ), REGKIND_NONE, &pITypeLib );
	if (FAILED(hr))
		return ERR_NOLOADLIB;

	int cTypeCount = pITypeLib->lpVtbl->GetTypeInfoCount( pITypeLib );
	if (cTypeCount < 1)
		return ERR_NOTYPES;

	hr = pITypeLib->lpVtbl->GetDocumentation( pITypeLib, MEMBERID_NIL, &bstrName, &bstrDocString,
             &ulHelpContext, &bstrHelpFile );
	// store the strings
	if (FAILED(AllocStoreStr( bstrName, &pTypeLibrary->pName )))
		return ERR_MEMORY;
	if (FAILED(AllocStoreStr( bstrDocString, &pTypeLibrary->pDocString )))
		return ERR_MEMORY;
	if (FAILED(AllocStoreStr( bstrHelpFile, &pTypeLibrary->pHelpFile )))
		return ERR_MEMORY;

	SysFreeString( bstrName );
	SysFreeString( bstrDocString );
	SysFreeString( bstrHelpFile );

	pTypeLibrary->ulHelpContext = ulHelpContext;

	// get Attributes - GUID, LCID, SYSKIND, MajorVerNum, MinorVerNum & LibFlags
    TLIBATTR * pLibAttr = NULL;
	hr = pITypeLib->lpVtbl->GetLibAttr( pITypeLib, &pLibAttr );
	if (FAILED(hr))
		return ERR_NOLIBATTR;

	// copy over the whole attr struct
	memcpy(&pTypeLibrary->tLibattr, pLibAttr, sizeof(TLIBATTR));

	pITypeLib->lpVtbl->ReleaseTLibAttr( pITypeLib, pLibAttr );

#ifdef LIBCOMP
	ITypeComp * pITypeComp;

	hr = pITypeLib->lpVtbl->GetTypeComp( pITypeLib, &pITypeComp );

	if (FAIED(hr))
	   return ERR_NOLIBCOMP;

	unsigned long hashVal;
	TYPE_LIST * pTInfo;
	DESCKIND descKind;
	BINDPTR bindPtr;

	hashVal = LHashValOfName(0, OLESTR("TYPE_MODULE"));
	hr = pITypeComp->lpVtbl->Bind( pITypeComp, OLESTR("TYPE_MODULE"), hashVal, 0,
					&pTInfo, &descKind, &bindPtr );

	RELEASE( pITypeComp );

	if (FAILED(hr))
		return hr;

	pTypeLibrary->pBindPtr = bindPtr;
#endif

	// get info lists
	if (cTypeCount){
		pTypeLibrary->numInfoLists = cTypeCount;

		// malloc first type list struct using calloc so
		// that all pointers are initialised to zero
		TYPE_LIST * pTypeList = GC_malloc( sizeof(TYPE_LIST) );
		if ( !pTypeList )
			return ERR_MEMORY;

		pTypeLibrary->pTypeLists = pTypeList;

		hr = GetTypeLists( pITypeLib, pTypeList, cTypeCount );
		if (FAILED(hr))
			return hr;

	}else
		return ERR_NOTYPES;

	RELEASE( pITypeLib );

	return 0;
}

/*--------------------------------------------------------------------
	Function	DoEnum()

	Purpose		Fills in a ENUM struct and enumerates the vars for this enum.

	Input		pEnum         -> pointer to an ENUM struct.
				pITypeInfo    -> pointer to a ITypeInfo interface
				nrOfVariables -> is the number of constants for this
				enum.

	Return		Zero on success

	Errors		various errors - ERR_MEMORY etc.
--------------------------------------------------------------------*/
int DoEnum( ENUM * pEnum, ITypeInfo * pITypeInfo, TYPEATTR * pTypeAttr )
{
	char * p;
	int hr;
	VARDESC  * pVarDesc;
	VAR_LIST * pTmpVars;

	pEnum->pVars = NULL;

	pEnum->nNumMembers = pTypeAttr->cVars;
	if (pTypeAttr->cVars <= 0)
		return 0;

	pEnum->eTypeKind = TKIND_ENUM;

	// store strings and HelpContext of enum
	GetDocumentationStrings( pITypeInfo, pEnum, MEMBERID_NIL );

	// allocate an VAR_LIST struct
	VAR_LIST * pVars = GC_malloc( sizeof(VAR_LIST) );
	if (!pVars)
		return ERR_MEMORY;

	pEnum->pVars = pVars;

	// do each enum member
	for ( int i = 0; i<pTypeAttr->cVars; i++ ) {

		pVars->pNext = NULL;   		// set to null at start
		pVars->eTypeKind = TKIND_VAR;

		hr = pITypeInfo->lpVtbl->GetVarDesc( pITypeInfo, i, &pVarDesc );
		if (FAILED(hr))
			return ERR_NOVARDESC;

		GetDocumentationStrings( pITypeInfo, pVars, pVarDesc->memid );

		if (pVarDesc->varkind == VAR_CONST) {
			VARIANT * v = pVarDesc->lpvarValue;
			if (v->vt == VT_INT || v->vt == VT_I4 || v->vt == VT_I2) {
				pVars->eTypeKind = VAR_CONST;
				pVars->iValue = pVarDesc->lpvarValue->iVal;
			}
		}
		pITypeInfo->lpVtbl->ReleaseVarDesc( pITypeInfo, pVarDesc );

		// do not allocate for the last iteration
		if (i <(pTypeAttr->cVars-1)){
			pTmpVars = GC_malloc( sizeof(VAR_LIST) );
			if ( !pTmpVars )
				return ERR_MEMORY;

			pVars->pNext = pTmpVars;
			pVars = pTmpVars;
		}
	}

	return 0;
}

/*--------------------------------------------------------------------
	Function	GetTypeDesc()

	Purpose		Gets the type as a string.

	Input		pTypeDesc  -> pointer to an TYPEDESC struct.
				pITypeInfo -> pointer to a ITypeInfo interface

	Return		pointer to array of chars

	Errors		?.
--------------------------------------------------------------------*/
char * GetTypeDesc( TYPEDESC * pTypeDesc, ITypeInfo * pITypeInfo )
{
	static char oss[300];
	oss[0] = 0;

	char tmp[90];
	int  dim;

	if( pTypeDesc->vt == VT_USERDEFINED ) {
		strcat( oss, GetCustomType( pTypeDesc->hreftype, pITypeInfo ));
		return oss;
	}

	// If the variable is VT_SAFEARRAY or VT_PTR, the union portion of the
	// TYPEDESC contains a pointer to a TYPEDESC that specifies the element type.
	if( (pTypeDesc->vt == VT_PTR) || ( pTypeDesc->vt == VT_SAFEARRAY ) ) {
		pTypeDesc = pTypeDesc->lptdesc;

		if (pTypeDesc->vt == VT_USERDEFINED){
			strcat( oss, GetCustomType( pTypeDesc->hreftype, pITypeInfo ));
		}else
			strcat( oss, ParamTypeToA( pTypeDesc->vt ));
		strcat(oss, "*");
		return oss;
	}

	if( pTypeDesc->vt == VT_CARRAY ) {

		strcpy( oss, GetTypeDesc( &pTypeDesc->lpadesc->tdescElem, pITypeInfo ));

		for( dim = 0; dim<pTypeDesc->lpadesc->cDims; ++dim ){
			strcat(oss, "[");
			sprintf(tmp, "%d %s", pTypeDesc->lpadesc->rgbounds[dim].lLbound, "...");
			strcat(oss, tmp);
			sprintf(tmp, "%d %s",
				pTypeDesc->lpadesc->rgbounds[dim].cElements +
				pTypeDesc->lpadesc->rgbounds[dim].lLbound - 1, "]");
			strcat(oss, tmp);
		}
		return oss;
	}

	char * p = ParamTypeToA( pTypeDesc->vt );
	return p;
}

/*--------------------------------------------------------------------
	Function	DoStruct()

	Purpose		Fills in a STRUCT struct and enumerates the vars.

	Input		pStruct     -> pointer to a STRUCT struct.
				pITypeInfo  -> pointer to a ITypeInfo interface
				pTypeAttr   -> pointer to a TYPEATTR struct.

	Return		Zero on success

	Errors		ERR_MEMORY.
--------------------------------------------------------------------*/
int DoStruct( STRUCT * pStruct, ITypeInfo * pITypeInfo, TYPEATTR * pTypeAttr )
{
	char * p;
	int hr;
	OLECHAR  * bstrName;
	VARDESC  * pVarDesc;
	VAR_LIST * pTmpVars;

	pStruct->pVars = NULL;

	pStruct->nNumMembers = pTypeAttr->cVars;
	if (pTypeAttr->cVars <= 0)
		return 0;

	pStruct->eTypeKind = TKIND_RECORD;

	// store strings and HelpContext
	GetDocumentationStrings( pITypeInfo, pStruct, MEMBERID_NIL );

	// allocate an VAR_LIST struct
	VAR_LIST * pVars = GC_malloc( sizeof(VAR_LIST) );
	if (!pVars)
		return ERR_MEMORY;

	pStruct->pVars = pVars;

	// do each struct member
	for ( int i = 0; i<pTypeAttr->cVars; i++ ) {

		pVars->pNext = NULL;   		// set to null at start
		pVars->eTypeKind = TKIND_VAR;

		hr = pITypeInfo->lpVtbl->GetVarDesc( pITypeInfo, i, &pVarDesc );
		if (FAILED(hr))
			return ERR_NOVARDESC;

		hr = pITypeInfo->lpVtbl->GetDocumentation( pITypeInfo, pVarDesc->memid,
									&bstrName, NULL, NULL, NULL);

		p = UnicodeToAnsi( bstrName );
		if (FAILED(AllocStoreStr( bstrName, &pVars->pName )))
			return ERR_MEMORY;
		SysFreeString( bstrName );

		pVars->iVarType = pVarDesc->elemdescVar.tdesc.vt;

		if ( (pVars->iVarType == VT_USERDEFINED) || (pVars->iVarType == VT_PTR) || (pVars->iVarType == VT_SAFEARRAY ) || (pVars->iVarType == VT_CARRAY) ){
			char * p = GetTypeDesc( &pVarDesc->elemdescVar.tdesc, pITypeInfo );
			pVars->pCustomName = GC_malloc( strlen(p) + 1);
			strcpy( pVars->pCustomName, p );
		}
		pITypeInfo->lpVtbl->ReleaseVarDesc( pITypeInfo, pVarDesc );

		// do not allocate for the last iteration
		if (i <(pTypeAttr->cVars-1)){
			pTmpVars = GC_malloc( sizeof(VAR_LIST) );
			if ( !pTmpVars )
				return ERR_MEMORY;

			pVars->pNext = pTmpVars;
			pVars = pTmpVars;
		}
	}

	return 0;
}

/*--------------------------------------------------------------------
	Function	DoParams()

	Purpose		Gets the parameters or vars associated with a function.

	Input		pVar       -> pointer to a VAR_LIST struct.
				pprgNames    -> pointer to pointer of UNICODE string array
				pITypeInfo -> pointer to a ITypeInfo interface
				pFuncDesc  -> pointer to a FUNCDESC struct

	Return		Zero on success

--------------------------------------------------------------------*/
int	DoParams( VAR_LIST * pVar, OLECHAR ** pprgNames, ITypeInfo * pITypeInfo, FUNCDESC * pFuncDesc )
{
	///////////////////////////////////////////////////////////////
	// do the parameters copying the user defined name if necessary
	///////////////////////////////////////////////////////////////

	VAR_LIST * pTmpVar = NULL;
	char * p;
	for(int curParam = 0; curParam<(pFuncDesc->cParams); curParam++) {
		TYPEDESC * pTypeDesc =	&pFuncDesc->lprgelemdescParam[curParam].tdesc;
		pVar->pNext = NULL;

		// store the var type
		pVar->iVarType = pTypeDesc->vt;

		if ( (pTypeDesc->vt == VT_USERDEFINED) || ( pTypeDesc->vt == VT_CARRAY) || (pTypeDesc->vt == VT_PTR) || (pTypeDesc->vt == VT_SAFEARRAY)){
			p = GetTypeDesc( pTypeDesc, pITypeInfo );
			int len = strlen( p );
			pVar->pCustomName = GC_malloc(len + 3);
			strcpy( pVar->pCustomName, p );
			strcat( pVar->pCustomName, " " );
		}

		if (FAILED(AllocStoreStr( pprgNames[curParam], &pVar->pName )))
			return ERR_MEMORY;

		// free the ole string
		SysFreeString( pprgNames[curParam] );

		// do not allocate for the last iteration
		if (curParam <(pFuncDesc->cParams-1)){
			pTmpVar = GC_malloc( sizeof(VAR_LIST) );
			if ( !pTmpVar )
				return ERR_MEMORY;

			pVar->pNext = pTmpVar;
			pVar = pTmpVar;
		}

	}
	return 0;
}

/*--------------------------------------------------------------------
	Function	DoProperties()

	Purpose		Gets the properties of an interface.

	Input		pProp      -> pointer to a PROPERTY_LIST struct.
				pITypeInfo -> pointer to a ITypeInfo interface
				pTypeAttr  -> pointer to a TYPEATTR struct

	Return		Zero on success

--------------------------------------------------------------------*/
int DoProperties( PROPERTY_LIST * pProp, ITypeInfo * pITypeInfo, TYPEATTR * pTypeAttr )
{
	HRESULT hr;
	char * p;
	PROPERTY_LIST * pTmpProp;
	VARDESC  * pVarDesc;

	for (int curVar = 0; curVar<(pTypeAttr->cVars); curVar++ ){
		pProp->pNext = NULL;   // set to null

		hr = pITypeInfo->lpVtbl->GetVarDesc( pITypeInfo, curVar, &pVarDesc );

		pProp->memid = pVarDesc->memid;

		// get the three strings, help, name and doc
		GetDocumentationStrings( pITypeInfo, pProp, pVarDesc->memid );

		if ( pVarDesc->varkind == VAR_CONST ){
			pProp->varValue = *pVarDesc->lpvarValue;
		}

		pProp->vtType = pVarDesc->elemdescVar.tdesc.vt;

		if ( (pProp->vtType == VT_USERDEFINED) || ( pProp->vtType == VT_CARRAY) || (pProp->vtType == VT_PTR) || (pProp->vtType == VT_SAFEARRAY)){
			p = GetTypeDesc( &pVarDesc->elemdescVar.tdesc, pITypeInfo );
			int len = strlen( p );
			pProp->pCustomName = GC_malloc(len + 3);
			strcpy( pProp->pCustomName, p );
			strcat( pProp->pCustomName, " " );
		}

		pProp->eTypeKind = TKIND_PROPERTY;
		pITypeInfo->lpVtbl->ReleaseVarDesc( pITypeInfo, pVarDesc );

		// do not allocate for the last iteration
		if (curVar <(pTypeAttr->cVars-1)){
			pTmpProp = GC_malloc( sizeof(PROPERTY_LIST) );
			if ( !pTmpProp )
				return ERR_MEMORY;

			pProp->pNext = pTmpProp;
			pProp = pTmpProp;
		}
	}
	return 0;
}

/*--------------------------------------------------------------------
	Function	DoUnion()

	Purpose		Gets a UNION type, fills in the vars.

	Input		pUnion     -> pointer to a UNION struct.
				pITypeInfo -> pointer to a ITypeInfo interface
				pTypeAttr  -> pointer to a TYPEATTR struct

	Return		Zero on success

	Errors      ERR_MEMORY
--------------------------------------------------------------------*/
int DoUnion( UNION * pUnion, ITypeInfo * pITypeInfo, TYPEATTR * pTypeAttr )
{
	HRESULT hr;
	VARDESC * pVarDesc;
	char * p;

	pUnion->eTypeKind    = TKIND_UNION;
	pUnion->uuid         = pTypeAttr->guid;
	GetDocumentationStrings( pITypeInfo, pUnion, MEMBERID_NIL );

	VAR_LIST * pTmpVar;
	VAR_LIST * pVar = GC_malloc( sizeof(VAR_LIST) );
	if (!pVar)
		return ERR_MEMORY;

	pUnion->pVars = pVar;

	///////////////////////////////////////////////////////////////
	// do the parameters copying the user defined name if necessary
	///////////////////////////////////////////////////////////////
	for(int curVar = 0; curVar<(pTypeAttr->cVars); curVar++) {
		pVar->pNext = NULL;

		hr = pITypeInfo->lpVtbl->GetVarDesc( pITypeInfo, curVar, &pVarDesc );

		// get the three strings, help, name and doc
		GetDocumentationStrings( pITypeInfo, pVar, pVarDesc->memid );

		if ( pVarDesc->varkind == VAR_CONST ){
			pVar->varValue = *pVarDesc->lpvarValue;
		}
		pVar->iValue = GetVariantIntValue( &pVar->varValue );

		pVar->iVarType = pVarDesc->elemdescVar.tdesc.vt;

		if ( (pVar->iVarType == VT_USERDEFINED) || ( pVar->iVarType == VT_CARRAY) || (pVar->iVarType == VT_PTR) || (pVar->iVarType == VT_SAFEARRAY)){
			p = GetTypeDesc( &pVarDesc->elemdescVar.tdesc, pITypeInfo );
			int len = strlen( p );
			pVar->pCustomName = GC_malloc(len + 3);
			strcpy( pVar->pCustomName, p );
			strcat( pVar->pCustomName, " " );
		}

		pVar->eTypeKind = TKIND_VAR;
		pITypeInfo->lpVtbl->ReleaseVarDesc( pITypeInfo, pVarDesc );

		// do not allocate for the last iteration
		if (curVar <(pTypeAttr->cVars-1)){
			pTmpVar = GC_malloc( sizeof(VAR_LIST) );
			if ( !pTmpVar )
				return ERR_MEMORY;

			pVar->pNext = pTmpVar;
			pVar = pTmpVar;
		}
	}

	return 0;
}

/*--------------------------------------------------------------------
	Function	DoModule()

	Purpose		Gets a MODULE type, fills in the vars.

	Input		pMod       -> pointer to a MODULE struct.
				pITypeInfo -> pointer to a ITypeInfo interface
				pTypeAttr  -> pointer to a TYPEATTR struct

	Return		Zero on success

	Errors      ERR_MEMORY
--------------------------------------------------------------------*/
int DoModule( MODULE * pMod, ITypeInfo * pITypeInfo, TYPEATTR * pTypeAttr )
{
	HRESULT hr;
	VARDESC * pVarDesc;
	char * p;

	///////////////////////////////////////////////////////
	// store documentation strings
	///////////////////////////////////////////////////////
	GetDocumentationStrings( pITypeInfo, pMod, MEMBERID_NIL );

	pMod->eTypeKind   = TKIND_MODULE;
	pMod->nNumMembers = pTypeAttr->cVars;

	VAR_LIST * pTmpVar;
	VAR_LIST * pVar = GC_malloc( sizeof(VAR_LIST) );
	if (!pVar)
		return ERR_MEMORY;

	pMod->pVars = pVar;

	///////////////////////////////////////////////////////////////
	// do the parameters copying the user defined name if necessary
	///////////////////////////////////////////////////////////////
	for(int curVar = 0; curVar<(pTypeAttr->cVars); curVar++) {
		pVar->pNext = NULL;

		hr = pITypeInfo->lpVtbl->GetVarDesc( pITypeInfo, curVar, &pVarDesc );

		// get the three strings, help, name and doc
		GetDocumentationStrings( pITypeInfo, pVar, pVarDesc->memid );

		if ( pVarDesc->varkind == VAR_CONST ){
			pVar->varValue = *pVarDesc->lpvarValue;
		}
		pVar->iValue = GetVariantIntValue( &pVar->varValue );

		pVar->iVarType = pVarDesc->elemdescVar.tdesc.vt;

		if ( (pVar->iVarType == VT_USERDEFINED) || ( pVar->iVarType == VT_CARRAY) || (pVar->iVarType == VT_PTR) || (pVar->iVarType == VT_SAFEARRAY)){
			p = GetTypeDesc( &pVarDesc->elemdescVar.tdesc, pITypeInfo );
			int len = strlen( p );
			pVar->pCustomName = GC_malloc(len + 3);
			strcpy( pVar->pCustomName, p );
			strcat( pVar->pCustomName, " " );
		}

		pVar->eTypeKind = TKIND_VAR;
		pITypeInfo->lpVtbl->ReleaseVarDesc( pITypeInfo, pVarDesc );

		// do not allocate for the last iteration
		if (curVar <(pTypeAttr->cVars-1)){
			pTmpVar = GC_malloc( sizeof(VAR_LIST) );
			if ( !pTmpVar )
				return ERR_MEMORY;

			pVar->pNext = pTmpVar;
			pVar = pTmpVar;
		}
	}

	return 0;
}

/*--------------------------------------------------------------------
	Function	DoDispInterface()

	Purpose		Gets a Dispatch Interface, fills in various vars. There
				can be properties, methods and also inhetirted interfaces.

	Input		pDisp      -> pointer to a DISPATCH_LIST struct.
				pITypeInfo -> pointer to a ITypeInfo interface
				pTypeAttr  -> pointer to a TYPEATTR struct

	Return		Zero on success

	Errors      ERR_MEMORY
--------------------------------------------------------------------*/
int DoDispInterface( DISPATCH_LIST * pDisp, ITypeInfo * pITypeInfo, TYPEATTR * pTypeAttr )
{
	char * p;
	int hr;
	FUNCDESC * pFuncDesc;
	METHOD_LIST * pTmpMethod;

	memcpy( &pDisp->uuid, &pTypeAttr->guid, sizeof(GUID) );

	pDisp->numMethods    = pTypeAttr->cFuncs;
	pDisp->numProperties = pTypeAttr->cVars;
	pDisp->numInterfaces = pTypeAttr->cImplTypes;
	pDisp->wTypeFlags    = pTypeAttr->wTypeFlags;
	pDisp->eTypeKind     = TKIND_DISPATCH;

	// save these and put back before return-ing if
	// if there is an inherited interface.
	ITypeInfo * pITmpRefTypeInfo;
	TYPEATTR  * pTmpTypeAttr;

	///////////////////////////////////////////////////////
	// store documentation strings
	///////////////////////////////////////////////////////
	GetDocumentationStrings( pITypeInfo, pDisp, MEMBERID_NIL );

	///////////////////////////////////////////////////////
	// check, if no methods but numInterfaces this is an
	// Inherited Interface, so get inherited TypeInfo etc.
	///////////////////////////////////////////////////////
	if ( !pDisp->numMethods && pDisp->numInterfaces ){
		HREFTYPE hRefType;
		hr = pITypeInfo->lpVtbl->GetRefTypeOfImplType( pITypeInfo, 0, &hRefType );

		// use a new typeinfo
		ITypeInfo * pIRefTypeInfo;
		hr = pITypeInfo->lpVtbl->GetRefTypeInfo( pITypeInfo, hRefType, &pIRefTypeInfo );

		hr =  pIRefTypeInfo->lpVtbl->GetTypeAttr( pIRefTypeInfo, &pTypeAttr );

		pDisp->numMethods    = pTypeAttr->cFuncs;
		pDisp->numProperties = pTypeAttr->cVars;
		pDisp->numInterfaces = pTypeAttr->cImplTypes;
		pDisp->wTypeFlags    = pTypeAttr->wTypeFlags;

		// save old params so they can be put back on exit
		pITmpRefTypeInfo = pITypeInfo;
		pTmpTypeAttr     = pTypeAttr;

		// assign new typeinfo interface
		pITypeInfo       = pIRefTypeInfo;
		pDisp->fInherited = TRUE;
	}

	// allocate a METHOD_LIST struct
	METHOD_LIST * pMethod = GC_malloc( sizeof(METHOD_LIST) );
	if (!pMethod)
		return ERR_MEMORY;

	pDisp->pMethod = pMethod;

	// pTypeAttr->cFuncs is number of METHODS for a DISPATCH_LIST
	for (int curFunc = 0; curFunc<(pDisp->numMethods); curFunc++ ) {

		pMethod->pNext = NULL;   // set to null at start

		pMethod->eTypeKind = TKIND_METHOD;

		hr = pITypeInfo->lpVtbl->GetFuncDesc( pITypeInfo, curFunc, &pFuncDesc );
		if (FAILED(hr))
			return ERR_NOFUNCDESC;
		// store funcdesc values
		pMethod->funckind   = pFuncDesc->funckind;
		pMethod->invkind    = pFuncDesc->invkind;
		pMethod->cParams    = pFuncDesc->cParams;
		pMethod->cParamsOpt = pFuncDesc->cParamsOpt;
		pMethod->memid      = pFuncDesc->memid;

		// get the three strings, help, name and doc
		GetDocumentationStrings( pITypeInfo, pMethod, pMethod->memid );

		// now fill in all parameters
		VAR_LIST * pTmpVar;
		VAR_LIST * pVar = GC_malloc( sizeof(VAR_LIST) );
		if (!pVar)
			return ERR_MEMORY;

		/////////////////////////////////////////////////
		// fill in the return type for this method
		/////////////////////////////////////////////////
		pMethod->cRetType = pFuncDesc->elemdescFunc.tdesc.vt;

		if ( (pMethod->cRetType == VT_USERDEFINED) || (pMethod->cRetType == VT_CARRAY) || (pMethod->cRetType == VT_PTR) || (pMethod->cRetType == VT_SAFEARRAY)){
			char * p = GetTypeDesc( &pFuncDesc->elemdescFunc.tdesc, pITypeInfo );
			int len = strlen( p );
			pMethod->pCustomName = GC_malloc(len + 3);
			strcpy( pMethod->pCustomName, p );
			strcat( pMethod->pCustomName, " " );
		}

		pMethod->pVars = pVar;
		PARAMDESC * pParamDesc;

		int cNames = 0;
		#define MAX_NAMES 20
		OLECHAR * prgNames[MAX_NAMES];

		// get the name of all the parameters
		pITypeInfo->lpVtbl->GetNames( pITypeInfo, pFuncDesc->memid, prgNames, MAX_NAMES, &cNames);

		// get the DISPID's
		pDisp->rgDispId = GC_malloc( cNames * sizeof(int*) );
		if ( !pDisp->rgDispId )
			return ERR_MEMORY;

		DispGetIDsOfNames( pITypeInfo, prgNames, cNames, pDisp->rgDispId);

		// first name is func name which we already have, so free it now.
		// SysFreeString( prgNames[0] );

		///////////////////////////////////////////////////////////////
		// do the parameters copying the user defined name if necessary
		///////////////////////////////////////////////////////////////
		DoParams( pVar, prgNames, pITypeInfo, pFuncDesc );

		pITypeInfo->lpVtbl->ReleaseFuncDesc( pITypeInfo, pFuncDesc );

		// do not allocate for the last iteration
		if (curFunc <(pTypeAttr->cFuncs-1)){
			pTmpMethod = GC_malloc( sizeof(METHOD_LIST) );
			if ( !pTmpMethod )
				return ERR_MEMORY;

			pMethod->pNext = pTmpMethod;
			pMethod = pTmpMethod;
		}
	}

	/////////////////////////////////////////////////////////////
	// nrOfVariables is number of PROPERTIES for a DISPINTERFACE
	/////////////////////////////////////////////////////////////
	if( pTypeAttr->cVars <= 0 ){
		pDisp->pProperty = NULL;  // no properties
		return 0;
	}

	// allocate a PROPERTY_LIST struct
	PROPERTY_LIST * pProp = GC_malloc( sizeof(PROPERTY_LIST) );
	if (!pProp)
		return ERR_MEMORY;

	pDisp->pProperty = pProp;

	// do each Property
	DoProperties( pProp, pITypeInfo, pTypeAttr );

	return 0;

}

/*--------------------------------------------------------------------
	Function	DoInterface()

	Purpose		Gets an Interface type, fills in various vars.

	Input		pDisp      -> pointer to a DISPATCH_LIST struct.
				pITypeInfo -> pointer to a ITypeInfo interface
				pTypeAttr  -> pointer to a TYPEATTR struct

	Return		Zero on success

	Errors      ERR_MEMORY
--------------------------------------------------------------------*/
int DoInterface( INTERFACE * pInterface, ITypeInfo * pITypeInfo, TYPEATTR * pTypeAttr )
{
	char * p;
	int hr;
	VARDESC  * pVarDesc;
	FUNCDESC * pFuncDesc;

	memcpy( &pInterface->uuid, &pTypeAttr->guid, sizeof(GUID) );

	METHOD_LIST   * pTmpMethod;
	PROPERTY_LIST * pTmpProp;

	// save these and put back before return-ing if
	// if there is an inherited interface.
	ITypeInfo * pITmpRefTypeInfo;
	TYPEATTR  * pTmpTypeAttr;

	///////////////////////////////////////////////////////
	// set to NULL now stating there are none at this stage
	///////////////////////////////////////////////////////
	pInterface->pMethod       = NULL;
	pInterface->numInterfaces = pTypeAttr->cImplTypes;
	pInterface->wTypeFlags    = pTypeAttr->wTypeFlags;

	pInterface->numMethods    = pTypeAttr->cFuncs;
	pInterface->eTypeKind     = TKIND_INTERFACE;

	///////////////////////////////////////////////////////
	// store documentation strings
	///////////////////////////////////////////////////////
	GetDocumentationStrings( pITypeInfo, pInterface, MEMBERID_NIL );

	///////////////////////////////////////////////////////
	// check, if no methods but numInterfaces this is an
	// Inherited Interface, so get inherited TypeInfo etc.
	///////////////////////////////////////////////////////
	if ( !pInterface->numMethods && pInterface->numInterfaces ){
		HREFTYPE hRefType;
		hr = pITypeInfo->lpVtbl->GetRefTypeOfImplType( pITypeInfo, 0, &hRefType );

		// use a new typeinfo
		ITypeInfo * pIRefTypeInfo;
		hr = pITypeInfo->lpVtbl->GetRefTypeInfo( pITypeInfo, hRefType, &pIRefTypeInfo );

		hr =  pIRefTypeInfo->lpVtbl->GetTypeAttr( pIRefTypeInfo, &pTypeAttr );

		pInterface->numMethods    = pTypeAttr->cFuncs;
		pInterface->numInterfaces = pTypeAttr->cImplTypes;
		pInterface->wTypeFlags    = pTypeAttr->wTypeFlags;

		// save old params so they can be put back on exit
		pITmpRefTypeInfo = pITypeInfo;
		pTmpTypeAttr     = pTypeAttr;

		// assign new typeinfo interface
		pITypeInfo       = pIRefTypeInfo;
		pInterface->fInherited = TRUE;
	}

	// allocate a METHOD_LIST struct
	METHOD_LIST * pMethod = GC_malloc( sizeof(METHOD_LIST) );
	if (!pMethod)
		return ERR_MEMORY;

	pInterface->pMethod = pMethod;

	// pTypeAttr->cFuncs is number of METHODS for a interface
	for (int curFunc = 0; curFunc<(pTypeAttr->cFuncs); curFunc++ ) {

		pMethod->pNext = NULL;   // set to null at start

		pMethod->eTypeKind = TKIND_METHOD;

		hr = pITypeInfo->lpVtbl->GetFuncDesc( pITypeInfo, curFunc, &pFuncDesc );

		if (FAILED(hr))
			return ERR_NOFUNCDESC;

		// store funcdesc values
		pMethod->funckind   = pFuncDesc->funckind;
		pMethod->invkind    = pFuncDesc->invkind;
		pMethod->cParams    = pFuncDesc->cParams;
		pMethod->cParamsOpt = pFuncDesc->cParamsOpt;
		pMethod->memid      = pFuncDesc->memid;

		// get the three strings, help, name and doc
		GetDocumentationStrings( pITypeInfo, pMethod, pMethod->memid );

		// now fill in all parameters
		VAR_LIST * pTmpVar;
		VAR_LIST * pVar = GC_malloc( sizeof(VAR_LIST) );
		if (!pVar)
			return ERR_MEMORY;

		/////////////////////////////////////////////////
		// fill in the return type for this method
		/////////////////////////////////////////////////
		pMethod->cRetType = pFuncDesc->elemdescFunc.tdesc.vt;

		if ( (pMethod->cRetType == VT_USERDEFINED) || (pMethod->cRetType == VT_CARRAY) || (pMethod->cRetType == VT_PTR) || (pMethod->cRetType == VT_SAFEARRAY)){
			char * p = GetTypeDesc( &pFuncDesc->elemdescFunc.tdesc, pITypeInfo );
			int len = strlen( p );
			pMethod->pCustomName = GC_malloc(len + 3);
			strcpy( pMethod->pCustomName, p );
			strcat( pMethod->pCustomName, " " );
		}

		pMethod->pVars = pVar;
		PARAMDESC * pParamDesc;

		int cNames = 0;
		#define MAX_NAMES 20
		OLECHAR * prgNames[MAX_NAMES];

		// get the name of all the parameters
		pITypeInfo->lpVtbl->GetNames( pITypeInfo, pFuncDesc->memid, prgNames, MAX_NAMES, &cNames);

		// get the DISPID's
		pInterface->rgDispId = GC_malloc( cNames * sizeof(int*) );
		if ( !pInterface->rgDispId )
			return ERR_MEMORY;

		DispGetIDsOfNames( pITypeInfo, prgNames, cNames, pInterface->rgDispId );

		// first name is func name which we already have, so free it now.
		SysFreeString( prgNames[0] );

		///////////////////////////////////////////////////////////////
		// do the parameters, copying the user defined name if necessary
		///////////////////////////////////////////////////////////////
		DoParams( pVar, prgNames, pITypeInfo, pFuncDesc );

		pITypeInfo->lpVtbl->ReleaseFuncDesc( pITypeInfo, pFuncDesc );

		// do not allocate for the last iteration
		if (curFunc <(pTypeAttr->cFuncs-1)){
			pTmpMethod = GC_malloc( sizeof(METHOD_LIST) );
			if ( !pTmpMethod )
				return ERR_MEMORY;

			pMethod->pNext = pTmpMethod;
			pMethod = pTmpMethod;
		}
	}

	return 0;
}

/*--------------------------------------------------------------------
	Function	DoCoClass()

	Purpose		Gets a COCLASS type, fills in various vars. A COCLASS
				type and have 'Dispatch Interfaces' or 'Interfaces'.

	Input		pCoClass   -> pointer to a COCLASS_LIST struct.
				pITypeInfo -> pointer to a ITypeInfo interface
				pTypeAttr  -> pointer to a TYPEATTR struct

	Return		Zero on success

	Errors      ERR_MEMORY
--------------------------------------------------------------------*/
int DoCoClass( COCLASS_LIST * pCoClass, ITypeInfo * pITypeInfo, TYPEATTR * pTypeAttr )
{
	char * p;
	int hr;
	VARDESC  * pVarDesc;
	FUNCDESC * pFuncDesc;
	OLECHAR  * bstrName;
	OLECHAR  * bstrDocString;
	OLECHAR  * bstrHelpFile;

	pCoClass->uuid = pTypeAttr->guid;

	int nrOfInterfaces;

	METHOD_LIST   * pTmpMethod;

	pCoClass->eTypeKind      = TKIND_COCLASS;

	///////////////////////////////////////////////////////
	// store documentation strings
	///////////////////////////////////////////////////////
	GetDocumentationStrings( pITypeInfo, pCoClass, MEMBERID_NIL );

	// number of implemeneted interfaces
	nrOfInterfaces = pTypeAttr->cImplTypes;

	HREFTYPE hRefType;

	//////////////////////////////////////////////////////////////////
	// CoClass may have more than one dispatch interfaces.
	// loop, assigning pCurDisp->pNext to the next structure.
	//////////////////////////////////////////////////////////////////
	DISPATCH_LIST * pCurDisp = NULL;

	for (int i = 0; i<nrOfInterfaces; i++){

		hr = pITypeInfo->lpVtbl->GetRefTypeOfImplType(pITypeInfo, i, &hRefType);

		// use a new typeinfo * typeattr
		ITypeInfo * pIRefTypeInfo;
		TYPEATTR  * pTmpTypeAttr;
		hr = pITypeInfo->lpVtbl->GetRefTypeInfo( pITypeInfo, hRefType, &pIRefTypeInfo );
		if (FAILED(hr))
			return 0;

		hr =  pIRefTypeInfo->lpVtbl->GetTypeAttr( pIRefTypeInfo, &pTmpTypeAttr );

		TYPEKIND eTypeKind = pTmpTypeAttr->typekind;
		DISPATCH_LIST * pTmpDisp = NULL;

		if (eTypeKind == TKIND_INTERFACE){
			INTERFACE * pInterface = GC_malloc( sizeof(INTERFACE) );
			if ( pInterface == NULL )
				return ERR_MEMORY;

			pCoClass->pInterface = pInterface;
			hr = DoInterface( pInterface, pIRefTypeInfo, pTmpTypeAttr );
		}

		if (eTypeKind == TKIND_DISPATCH){
			if ( pCurDisp == NULL ){ // do first dispatch interface
				pCurDisp = GC_malloc( sizeof(DISPATCH_LIST) );
				if ( pCurDisp == NULL )
					return ERR_MEMORY;

				pCoClass->pDispInterface = pCurDisp;
				pCurDisp->pNext = NULL;

			}else{ // do second or third dispatch interface
				pTmpDisp = GC_malloc( sizeof(DISPATCH_LIST) );
				if ( pTmpDisp == NULL )
					return ERR_MEMORY;
				pCurDisp->pNext = pTmpDisp;
				pCurDisp        = pTmpDisp;
			}
			pCurDisp->pInterface = NULL;

			hr = DoDispInterface( pCurDisp, pIRefTypeInfo, pTmpTypeAttr );
		}
		pIRefTypeInfo->lpVtbl->ReleaseTypeAttr( pIRefTypeInfo, pTmpTypeAttr );
		RELEASE(pIRefTypeInfo);
		if (FAILED(hr))
			return hr;
	}

	return 0;
}

/*--------------------------------------------------------------------
	Function	GetTypeLists()

	Purpose		Main loop for enumerating all other Types, Interfaces etc.
				Calls other function to enumerate the TYPE's.

	Input		pITypeLib  -> pointer to an LoadTypeLib interface. (freed in GetTypeLibaray())
				pTypeList  -> pointer to a TYPE_LIST struct which starts the lists
				cTypeCount -> how many TYPE's there are in this Library

	Return		Zero on success

	Errors		various errors - ERR_MEMORY etc.
--------------------------------------------------------------------*/
int GetTypeLists( ITypeLib * pITypeLib, TYPE_LIST * pTypeList, int cTypeCount )
{
	TYPE_LIST * pTmpTypeList = pTypeList;
	HRESULT     hr;
	TYPEKIND    eTypeKind;
	ITypeInfo * pITypeInfo;
	TYPEATTR  * pTypeAttr;

	// there are cTypeCount TYPE's in this Control
	// or for CoClasses number of interfaces
	for ( int n = 0; n<cTypeCount; n++ ) {

		pTypeList->pNext = NULL; // set to null at start

		hr = pITypeLib->lpVtbl->GetTypeInfo( pITypeLib, n, &pITypeInfo );
		if (FAILED(hr))
			return ERR_NOTYPEINFO;

		// get type kind
		hr = pITypeLib->lpVtbl->GetTypeInfoType( pITypeLib, n, &eTypeKind );
		if ( FAILED(hr) )
			return ERR_NOTYPEKIND;

		// set type kind. will be the reference for accessing the types
		pTypeList->eTypeKind = eTypeKind;

		// get attributes
		hr = pITypeInfo->lpVtbl->GetTypeAttr( pITypeInfo, &pTypeAttr );
		if (FAILED(hr))
			return ERR_NOLIBATTR;

		switch ( eTypeKind ){
		case TKIND_INTERFACE:{
			INTERFACE * pInterface = GC_malloc( sizeof(INTERFACE) );
			if ( pInterface == NULL )
				return ERR_MEMORY;

			pTypeList->pInterface = pInterface;

			hr = DoInterface( pInterface, pITypeInfo, pTypeAttr );
			}
			break;

		case TKIND_ENUM:{
			ENUM * pEnum = GC_malloc( sizeof(ENUM) );
			if ( pEnum == NULL )
				return ERR_MEMORY;

			pTypeList->pEnum = pEnum;
			hr = DoEnum( pEnum, pITypeInfo, pTypeAttr );
			if (FAILED(hr))
				return hr;
			}
			break;

		case TKIND_RECORD:{
			STRUCT * pStruct = GC_malloc( sizeof(STRUCT) );
			if ( pStruct == NULL )
				return ERR_MEMORY;

			pTypeList->pStruct = pStruct;

			hr = DoStruct( pStruct, pITypeInfo, pTypeAttr );
			}
			break;

		case TKIND_MODULE:{
			MODULE * pMod = GC_malloc( sizeof(MODULE) );
			if ( pMod == NULL )
				return ERR_MEMORY;

			pTypeList->pModule = pMod;

			hr = DoModule( pMod, pITypeInfo, pTypeAttr );
			if (FAILED(hr))
				return hr;
			}
			break;

		case TKIND_DISPATCH:{
			DISPATCH_LIST * pDisp = GC_malloc( sizeof(DISPATCH_LIST) );
			if ( pDisp == NULL )
				return ERR_MEMORY;

			pTypeList->pDispInterface = pDisp;

			pDisp->pInterface =	NULL;

			hr = DoDispInterface( pDisp, pITypeInfo, pTypeAttr );
			if (FAILED(hr))
				return hr;

			// get the dual interface if exists
			if ( pTypeAttr->wTypeFlags & TYPEFLAG_FDUAL ){
				INTERFACE * pInterface = GC_malloc( sizeof(INTERFACE) );
				if ( pInterface == NULL )
					return ERR_MEMORY;

				pDisp->pInterface = pInterface;

				hr = DoInterface( pInterface, pITypeInfo, pTypeAttr );
				if (FAILED(hr))
					return hr;

			}
			}
			break;

		case TKIND_COCLASS:{
			COCLASS_LIST * pCoClass = GC_malloc( sizeof(COCLASS_LIST) );
			if ( pCoClass == NULL )
				return ERR_MEMORY;

			pTypeList->pCoClass = pCoClass;

			hr = DoCoClass( pCoClass, pITypeInfo, pTypeAttr );
			if (FAILED(hr))
				return hr;
			}
			break;

		case TKIND_ALIAS:{
			ALIAS * pAlias = GC_malloc( sizeof(ALIAS) );
			if ( pAlias == NULL )
				return ERR_MEMORY;

			pTypeList->eTypeKind = TKIND_ALIAS;
			pTypeList->pAlias = pAlias;
			pAlias->eTypeKind = TKIND_ALIAS;
			pAlias->uuid      = pTypeAttr->guid;
			GetDocumentationStrings( pITypeInfo, pAlias, MEMBERID_NIL );

			// get alias name
			pAlias->pRealName = GC_malloc( strlen( GetTypeDesc( &pTypeAttr->tdescAlias, pITypeInfo ))+1 );
			strcpy( pAlias->pRealName, GetTypeDesc( &pTypeAttr->tdescAlias, pITypeInfo ) );
			}
			break;

		case TKIND_UNION:{
			UNION * pUnion = GC_malloc( sizeof(UNION) );
			if ( pUnion == NULL )
				return ERR_MEMORY;

			pTypeList->eTypeKind = TKIND_UNION;
			pTypeList->pUnion    = pUnion;

			hr = DoUnion( pUnion, pITypeInfo, pTypeAttr );
			if (FAILED(hr))
				return hr;
			}
			break;
		}

		pITypeInfo->lpVtbl->ReleaseTypeAttr( pITypeInfo, pTypeAttr );

		// DO NOT ALLOCATE FOR THE LAST TIME
		if (n <(cTypeCount-1)){
			pTmpTypeList = GC_malloc( sizeof(TYPE_LIST) );
			if ( !pTmpTypeList )
				return ERR_MEMORY;

			pTypeList->pNext = pTmpTypeList;
			pTypeList = pTmpTypeList;

		}
	}
	RELEASE( pITypeInfo ); // release the interface

	return 0;
}

char * UnicodeToAnsi1( OLECHAR * szW )
{
	static char szA[STRCONVERT_MAXLEN];
	szA[0] = 0;

	if (szW == NULL)
		return "<none>";

	WideCharToMultiByte(CP_ACP, 0, szW, -1, szA, STRCONVERT_MAXLEN, NULL, NULL);
	return szA;

}

/*--------------------------------------------------------------------
	Function	GetRegisteredControlsClsids()

	Purpose		Fill an array of CTRL_CLSID structs with all Registry
				CLSIDs and the name of ole controls.
				Memory is allocated for the name of the control.

				Also collect all registered Interfaces.

	Input		pCtrlCLSID -> pointer to an array of CTRL_CLSID structs.
				ppRegGUID -> [OUT] pointer to pointer to REG_INTERFACE
				max		  -> maximum number of structs allowed.

	Return		Numbers of CLSID structs filled.

	Errors		ERR_MEMORY			no more memory.
				ERR_OVERRUN			more clsids then allowed.
				ERR_NOCATMANAGER	The Component Categories Manager
									could not be found.
				ERR_NOENUM			EnumClassesOfCategories failed.
--------------------------------------------------------------------*/
int GetRegisteredControlsClsids( CTRL_CLSID * pCtrlCLSID, int max )
{
	OLECHAR * pOleStrClassName;
	char szName[MAX_PATH];
	int cnt = 0;

	ICatInformation * pICatInfo = NULL;

	// create an instance of the 'Component Category Manager'
	HRESULT res = CoCreateInstance( &CLSID_StdComponentCategoriesMgr,
				NULL, CLSCTX_INPROC_SERVER, &IID_ICatInformation, (void*)&pICatInfo );

	if ( res != S_OK )
		return ERR_NOCATMANAGER;

	// inc ref count on interface
	pICatInfo->lpVtbl->AddRef( pICatInfo );

	// IEnumGUID interface for enumerating the com objects
	IEnumGUID * pEnumGUID = NULL;

	// enumerating only controls so put in CATID_Control
	CATID pcatidImpl[1];
	CATID pcatidReqd[1];
	pcatidImpl[0] = CATID_Control;

	// (pEnumGUID) to enumerate the com objects of type CATID_Control
	res = pICatInfo->lpVtbl->EnumClassesOfCategories(pICatInfo, 1, pcatidImpl, 0, pcatidReqd, &pEnumGUID);

	if ( res != S_OK )
		return ERR_NOENUM;

	// enumerate the controls getting the next CLSID
	while( (res = pEnumGUID->lpVtbl->Next(pEnumGUID, 1, &pCtrlCLSID[cnt].regclsid, NULL ))== S_OK )
	{
		OleRegGetUserType( &pCtrlCLSID[cnt].regclsid, USERCLASSTYPE_FULL, &pOleStrClassName );

		// convert widechar of ClassName to char
		strcpy( szName, UnicodeToAnsi1( pOleStrClassName ) );

		int len = strlen( szName );
		pCtrlCLSID[cnt].pCtrlName = GC_malloc( len+1 );

		if ( !pCtrlCLSID[cnt].pCtrlName )
			return ERR_MEMORY;

		strcpy( pCtrlCLSID[cnt].pCtrlName, szName );
		cnt++;
		if (cnt >= max){
			RELEASE( pICatInfo );
			return ERR_OVERRUN;
		}
	}
	// release the interface
	RELEASE( pICatInfo );

	return cnt;
}
