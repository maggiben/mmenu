#include <gc.h>
#include "jcom.h"
#include "helper.h"

char str[2048];


/*--------------------------------------------------------------------
	Function	CollectAllRegisteredInterfaces()

	Purpose		Collect all registered interfaces from the registry.
				HKEY_CLASSES_ROOT\Interface\

	Input		None.

	Return		Pointer to array of REG_INTERFACE structs that have the GUID
				and name of interface.

	Errors		?.
--------------------------------------------------------------------*/
REG_INTERFACE * CollectAllRegisteredInterfaces( void )
{
	HANDLE  hKey, htmpKey;;
    char    achKey[MAX_PATH];
    DWORD 	i, j, retCode;
	char 	newKey[MAX_PATH];
	char 	szName[MAX_PATH];
	HRESULT hr;

	int type = REG_SZ;

	if (ERROR_SUCCESS != RegOpenKeyEx(HKEY_CLASSES_ROOT, "Interface", 0, KEY_READ, &hKey))
		return (REG_INTERFACE*)-1;

	int bufsize = MAX_PATH;

	OLECHAR * pOle;

	REG_INTERFACE * pGuid = GC_malloc( sizeof(REG_INTERFACE) );
	REG_INTERFACE * pTmpGuid;
	REG_INTERFACE * pGuidStore = pGuid;

	for (i = 0, retCode = ERROR_SUCCESS; retCode == ERROR_SUCCESS; i++) {

		achKey[0] = 0;
        retCode = RegEnumKey(hKey, i, achKey, MAX_PATH);
        if ( retCode == ERROR_SUCCESS ){

			sprintf( newKey, "Interface\\%s", achKey );
			hr = RegOpenKeyEx( HKEY_CLASSES_ROOT, newKey, 0, KEY_ALL_ACCESS, &htmpKey );

			szName[0] = 0;
			bufsize = MAX_PATH;
			hr = RegQueryValueEx( htmpKey, "", NULL, &type, szName, &bufsize);

			if (szName[0] != 0){
				CLSIDFromString( AnsiToUnicode( achKey ), &pGuid->regguid );
				pGuid->pIntFaceName = GC_malloc( strlen( szName ) +1 );
				strcpy( pGuid->pIntFaceName, szName );

				pTmpGuid = GC_malloc( sizeof(REG_INTERFACE) );

				pGuid->pNext = pTmpGuid;
				pGuid        = pTmpGuid;

			}

			RegCloseKey( htmpKey );
        }
    }

	RegCloseKey( hKey );

 	return pGuidStore;
}

/*--------------------------------------------------------------------
	Function	GetPathOfRegTypeLib()

	Purpose		Find the application name & path for the ole control.
				The string is retrieved from
					HKEY_CLASSES_ROOT\CLSID\{clsid string}\InprocServer32

	Input		pclsid -> CLSDID of control.

	Return		Pointer to array of chars that contains the string.

	Errors		NULL on failure.
--------------------------------------------------------------------*/
char * GetPathOfRegTypeLib( CLSID * pclsid )
{
	OLECHAR * bstrCLSID;
  	HKEY hKey = NULL;
	char szMainKey[MAX_PATH];
	static char szEntryName[MAX_PATH];
	szEntryName[0] = 0;

	StringFromCLSID( pclsid, &bstrCLSID);

	// make complete registry key
	sprintf( szMainKey, "%s%s%s", "CLSID\\", UnicodeToAnsi(bstrCLSID), "\\InprocServer32" );

	DWORD bufsize = MAX_PATH;

	SysFreeString( bstrCLSID ); // here

	// If not opened return error
	if (ERROR_SUCCESS != RegOpenKeyEx(HKEY_CLASSES_ROOT, szMainKey, 0, KEY_QUERY_VALUE, &hKey))
		return NULL;

	// Get the string from "Default"
	RegQueryValueEx(hKey, "", NULL, NULL, szEntryName, &bufsize);

	RegCloseKey(hKey);

	return szEntryName;
}

/*--------------------------------------------------------------------
	Function	GetCustomType()

	Purpose		Gets the custom name of a type

	Input		refType -> the reference for this type.
				pti     -> ITypeInfo

	Return		Pointer to array of chars that contains the string.

--------------------------------------------------------------------*/
char * GetCustomType( HREFTYPE refType, ITypeInfo * pti )
{

	ITypeInfo * pITypeInfo = pti;
	ITypeInfo * pICustTypeInfo;

	HRESULT hr = pITypeInfo->lpVtbl->GetRefTypeInfo( pITypeInfo, refType, &pICustTypeInfo );

	if(hr) return "UnknownCustomType";

	OLECHAR * bstrType;
	hr = pICustTypeInfo->lpVtbl->GetDocumentation( pICustTypeInfo, MEMBERID_NIL,
					&bstrType, 0, 0, 0 );

	RELEASE( pICustTypeInfo );
	if(hr) return "UnknownCustomType";

	static char * p;
	p = UnicodeToAnsi( bstrType );

	SysFreeString( bstrType );

	return p;
}

int AllocStoreStr( OLECHAR * strOle, char ** str )
{
	char * p = UnicodeToAnsi( strOle );

	// was malloc( strlen(p)+1 ) but suspect that
	// malloc( 1 ) could have caused problems when free-ing()
	*str = GC_malloc( strlen(p)+4 );
	if ( !str )
		return ERR_MEMORY;

	strcpy( *str, p );
	return 0;
}

OLECHAR * AnsiToUnicode(char * szA)
{
	static OLECHAR szW[STRCONVERT_MAXLEN];
	szW[0] = L'\0';

	MultiByteToWideChar(CP_ACP, 0, szA, -1, szW, STRCONVERT_MAXLEN);
	return szW;
}

char * UnicodeToAnsi( OLECHAR * szW )
{
	static char szA[STRCONVERT_MAXLEN];
	szA[0] = 0;

	if ( szW == NULL )
		return "<none>";

	WideCharToMultiByte(CP_ACP, 0, szW, -1, szA, STRCONVERT_MAXLEN, NULL, NULL);
	return szA;
}

char * GetFileNamePointer(char *pFilePath)
{
	// If pFilePath points to 'd:\myfolder\name.ext;'
	// GetFileNamePointer() returns a pointer to 'name.ext'
	// or to last '\' delimiter.

	LPTSTR	pFileName = NULL;
	TCHAR	FOLDER_DELIMITER = TEXT('\\');
	TCHAR	DRIVE_DELIMITER = TEXT(':');

	if (pFilePath){
		pFileName = pFilePath + lstrlen(pFilePath);

		while (*pFileName != FOLDER_DELIMITER && *pFileName != DRIVE_DELIMITER){
			if (pFileName == pFilePath){	// Done if no delimiters are found
				break;
			}
			pFileName--;
		}

		if (*pFileName == FOLDER_DELIMITER || *pFileName == DRIVE_DELIMITER){
			pFileName++;					// Folder delimiter found, point right after it
		}
	}
	return pFileName;
}

char * EnumToA( ENUM * pEnum )
{
	sprintf( str, "Enum -> %s\r\n"
				  "DocString -> %s\r\n"
				  "Help Context -> %d\r\n",
				   pEnum->pName,
				   pEnum->pDocString,
				   pEnum->ulHelpContext);

	return str;
}

char * AliasToA( ALIAS * pAlias )
{
	OLECHAR * bstrUuid;
	char * p;
	StringFromCLSID( &pAlias->uuid, &bstrUuid );
	p = UnicodeToAnsi( bstrUuid );

	sprintf( str, "Module -> %s\r\n"
				  "DocString -> %s\r\n"
				  "Help Context -> %d\r\n"
				  "UUID -> %s\r\n",
				   pAlias->pName,
				   pAlias->pDocString,
				   pAlias->ulHelpContext,
				   p);

	SysFreeString( bstrUuid ) ;

	return str;
}

char * ModuleToA( MODULE * pMod )
{
	sprintf( str, "Module -> %s\r\n"
				  "DocString -> %s\r\n"
				  "Help Context -> %d\r\n"
				  "Number of consts -> %d\r\n",
				   pMod->pName,
				   pMod->pDocString,
				   pMod->ulHelpContext,
				   pMod->nNumMembers);

	return str;
}

char * MethodToA( METHOD_LIST * pMethod )
{
	char * p;
	char tmp[512];
	tmp[0] = 0;
	char * rettype;

	if ( (pMethod->cRetType == VT_USERDEFINED) || (pMethod->cRetType == VT_PTR)	|| (pMethod->cRetType == VT_CARRAY) || (pMethod->cRetType == VT_SAFEARRAY))
		rettype = pMethod->pCustomName;
	else
		rettype = ParamTypeToA( pMethod->cRetType );

	char func[1024];
	strcpy( func, rettype );

	strcat( func, pMethod->pName );

	// last optional parameters
	int nLastParamsOptional = pMethod->cParamsOpt;

	VAR_LIST * pVar = pMethod->pVars;
	strcat( func, "( " );
	for (int i = 0; i<pMethod->cParams; i++){

		// optional parameters
		if ( (i >= (pMethod->cParams-2)) && nLastParamsOptional )
			strcat( func, "[optional] " );

		// these types will always have user define names (I think!)
		if ( (pVar->iVarType == VT_USERDEFINED) || (pVar->iVarType == VT_CARRAY) || (pVar->iVarType == VT_PTR) || (pVar->iVarType == VT_SAFEARRAY)){
			strcat( func, pVar->pCustomName );
			strcat ( func, " " );
		}else
			strcat( func, ParamTypeToA( pVar->iVarType ));

		strcat( func, pVar->pName );

		if (i<(pMethod->cParams-1))
			strcat( func, ", " );

		pVar = pVar->pNext;
	}
	strcat( func, ")" );

	sprintf( str, "Name -> %s\r\n"
				  "DocString -> %s\r\n"
				  "HelpFile -> %s\r\n"
				  "Function Kind -> %s\r\n"
				  "Invoke Kind -> %s\r\n"
				  "Total Params -> %d\r\n"
				  "Optional Params -> %d\r\n"
				  "Member ID -> %d\r\n"
				  "Help Context -> %d\r\n"
				  "%s"
				  " %s",
				   pMethod->pName,
				   pMethod->pDocString,
				   pMethod->pHelpFile,
				   FuncKindToA( pMethod->funckind ),
				   InvokeKindToA( pMethod->invkind ),
				   pMethod->cParams,
				   pMethod->cParamsOpt,
				   pMethod->memid,
				   pMethod->ulHelpContext,
				   func , InvokeKindToA(pMethod->invkind));
	return str;
}

char * InterfaceToA( INTERFACE * pInterface )
{
	sprintf( str, "%s\r\n"
				  "DocString -> %s\r\n"
				  "HelpFile -> %s\r\n",
				   pInterface->pName,
				   pInterface->pDocString,
				   pInterface->pHelpFile );

	return str;

}

char * PropertyToA( PROPERTY_LIST * pProp )
{
	char var[60];
	if ( (pProp->vtType == VT_USERDEFINED) || ( pProp->vtType == VT_CARRAY) || (pProp->vtType == VT_PTR) || (pProp->vtType == VT_SAFEARRAY))
		strcpy( var, pProp->pCustomName );
	else
		strcpy( var, ParamTypeToA( pProp->vtType) );

	sprintf( str, "%s "
				  "%s()\r\n"
				  "DocString -> %s\r\n"
				  "HelpFile -> %s\r\n",
				   var,
				   pProp->pName,
				   pProp->pDocString,
				   pProp->pHelpFile );

	return str;
}

char * DispatchToA( DISPATCH_LIST * pDisp )
{
	OLECHAR * bstrUuid;
	char * p;
	StringFromCLSID( &pDisp->uuid, &bstrUuid );
	p = UnicodeToAnsi( bstrUuid );
	sprintf( str, "Dispatch -> %s\r\n"
				  "DocString -> %s\r\n"
				  "HelpFile -> %s\r\n"
				  "Number of Interfaces -> %d\r\n"
				  "UUID -> %s\r\n",
				   pDisp->pName,
				   pDisp->pDocString,
				   pDisp->pHelpFile,
				   pDisp->numInterfaces,
				   p );

	SysFreeString( bstrUuid ) ;

	return str;
}

char * CoClassToA( COCLASS_LIST * pCoClass )
{
	OLECHAR * bstrUuid;
	char * p;
	StringFromCLSID( &pCoClass->uuid, &bstrUuid );
	p = UnicodeToAnsi( bstrUuid );
	sprintf( str, "CoClass -> %s\r\n"
				  "DocString -> %s\r\n"
				  "HelpFile -> %s\r\n"
				  "UUID -> %s\r\n",
				   pCoClass->pName,
				   pCoClass->pDocString,
				   pCoClass->pHelpFile,
				   p );

	SysFreeString( bstrUuid ) ;
	return str;
}

char * TypeLibraryToA( TYPELIBARAY * TypeLibrary )
{
	OLECHAR * pOle;
	StringFromCLSID(&TypeLibrary->CtrlCLSID, &pOle );
	char * pclsid = UnicodeToAnsi( pOle );
	sprintf( str,
			"TYPELIBARAY %s\r\n"
			"CLSID %s\r\n"
			"Documentation = %s\r\n"
			"File = %s\r\n"
			"Help File %s\r\n"
			"Help context %d\r\n"
			"Syskind = %s\r\n"
			"MajorVerNum = %d\r\n"
			"MinorVerNum = %d\r\n",
			TypeLibrary->pName,
			pclsid,
			TypeLibrary->pDocString,
		    TypeLibrary->pTypeLibFile,
			TypeLibrary->pHelpFile,
			TypeLibrary->ulHelpContext,
			TypeSysKindToA( TypeLibrary->tLibattr.syskind ),
		    TypeLibrary->tLibattr.wMajorVerNum,
			TypeLibrary->tLibattr.wMinorVerNum );
	SysFreeString( pOle );
	return str;
}

char * ParamTypeToA( unsigned short vt )
{
	char *p;
	switch( vt ){
	case (VT_EMPTY):
		p = "Empty ";
		break;

	case (VT_NULL):
		p = "Null ";
		break;

	case (VT_I1):
		p = "char ";
		break;

	case (VT_I2):
		p = "short ";
		break;

	case (VT_I4):
		p = "long ";
		break;

	case (VT_I8):
		p = "long long ";
		break;

	case (VT_R4):
		p = "float ";
		break;

	case (VT_R8):
		p = "double ";
		break;

	case (VT_CY):
		p = "currency ";
		break;

 	case (VT_DATE):
		p = "date ";
		break;

	case (VT_BSTR):
		p = "unicode string* ";
		break;

	case (VT_DISPATCH):
		p = "dispatch interface ";
		break;

	case (VT_ERROR):
		p = "error ";
		break;

	case (VT_BOOL):
		p = "boolean ";
		break;

	case (VT_VARIANT):
		p = "variant ";
		break;

 	case (VT_DECIMAL):
		p = "decimal ";
		break;

	case (VT_UI1):
		p = "unisgned char ";
		break;

	case (VT_UI2):
		p = "unsigned short ";
		break;

	case (VT_UI4):
		p = "unsigned int ";
		break;

	case (VT_UI8):
		p = "unsigned long long ";
		break;

	case (VT_INT):
		p = "int";
		break;

 	case (VT_UINT):
		p = "unsigned int ";
		break;

 	case (VT_VOID):
		p = "void ";
		break;

 	case (VT_HRESULT):
		p = "HRESULT ";
		break;

 	case (VT_PTR):
		p = "pointer ";
		break;

	case (VT_SAFEARRAY):
		p = "SAFEARRAY ";
		break;

 	case (VT_CARRAY):
		p = "c array ";
		break;

	case (VT_LPSTR):
		p = "char * ";
		break;

	case (VT_LPWSTR):
		p = "wchar * ";
		break;

	case (VT_RECORD):
		p = "record ";
		break;

	case (VT_FILETIME):
		p = "FILETIME ";
		break;

	case (VT_BLOB):
		p = "BLOB ";
		break;

	case (VT_STREAM):
		p = "stream ";
		break;

 	case (VT_STORAGE):
		p = "storage ";
		break;

	case (VT_STREAMED_OBJECT):
		p = "streamed object ";
		break;

	case (VT_STORED_OBJECT):
		p = "stored object ";
		break;

	case (VT_BLOB_OBJECT):
		p = "blob object ";
		break;

 	case (VT_CF):
		p = "CF ";
		break;

	case (VT_CLSID):
		p = "CLSID ";
		break;

#if 0
	case (VT_VERSIONED_STREAM):
		p = "versioned stream ";
		break;
#endif
	case (VT_BSTR_BLOB):
		p = "bstr blob ";
		break;

	case (VT_VECTOR):
		p = "vector ";
		break;

	case (VT_ARRAY):
		p = "array ";
		break;

	case (VT_BYREF):
		p = "by reference ";
		break;

	case (VT_RESERVED):
		p = "reserved ";
		break;

	case (VT_ILLEGAL):
		p = "illegal ";
		break;
#if 0
	case (VT_ILLEGALMASKED):
		p = "illegal masked ";
		break;

	case (VT_TYPEMASK):
		p = "type mask ";
		break;
#endif
	default:
		p = "";
	}
	return p;
}

unsigned long GetVariantIntValue( VARIANT * v )
{
	char *p;
	switch( v->vt ){
	case (VT_UI1):
		return v->bVal;

	case (VT_UI2):
		return v->uiVal;

//	case (VT_UI4):
//		return ulVal;

	case (VT_INT):
		return v->intVal;

 	case (VT_UINT):
		return v->uintVal;

	case (VT_I1):
		return v->cVal;

	case (VT_I2):
		return v->iVal;

	case (VT_I4):
		return v->lVal;

	default:
		return -1;
	}

}

char * TypeSysKindToA( int kind )
{
	char *p;
	switch( kind ){
	case SYS_WIN16:
		p = "SYS_WIN16";
		break;
	case SYS_WIN32:
		p = "SYS_WIN32";
		break;
#if WIN64
	case SYS_WIN64:
		p = "SYS_WIN64";
		break;
#endif
	default:
		p = "SYS_UNKNOWN";
	}
	return p;
}

char * TypeKindToA(int kind)
{
	char *p;
	switch (kind){
	case TKIND_INTERFACE:
		p = "INTERFACE";
		break;

	case TKIND_DISPATCH:
		p = "DISPATCH";
		break;

	case TKIND_MODULE:
		p = "MODULE";
		break;

	case TKIND_COCLASS:
		p = "COCLASS";
		break;

	case TKIND_ENUM:
		p = "ENUM";
		break;

	case TKIND_ALIAS:
		p = "ALIAS";
		break;

	case TKIND_RECORD:
		p = "RECORD";
		break;

	case TKIND_UNION:
		p = "UNION";
		break;

	default:
		break;
	}
	return p;
}

char * InvokeKindToA( int inv )
{
	static char * p;
	switch( inv ) {
	case INVOKE_FUNC:
		p = "normal function";
		break;

	case INVOKE_PROPERTYGET:
		p = "propget";
		break;

	case INVOKE_PROPERTYPUT:
		p = "propput";
		break;

	case INVOKE_PROPERTYPUTREF:
		p = "propputref";
		break;

	default:
		p = "<none>";
	}
	return p;
}

char * FuncKindToA( int kind )
{
	static char * p;
	switch( kind ) {
	case FUNC_VIRTUAL:
		p = "Virtual";
		break;

	case FUNC_PUREVIRTUAL:
		p = "Pure Virtual";
		break;

	case FUNC_NONVIRTUAL:
		p = "None Vitual";
		break;

	case FUNC_STATIC:
		p = "Static";
		break;

	case FUNC_DISPATCH:
		p = "Dispatch";
		break;

	default:
		p = "<None>";
	}
	return p;
}

void ShowError( int hr )
{
	char * p;
	switch( hr ){

	case ERR_MEMORY:
		p = "Memory allocation failed";
		break;

	case ERR_OVERRUN:
		p = "Too may libraries";
		break;

	case ERR_NOCATMANAGER:
		p = "Could not create 'Component Categories Manager'";
		break;

	case ERR_NOENUM:
		p = "Could not create EnumClassesOfCategories";
		break;

	case ERR_NOFILEPATH:
		p = "Could not retrieve control's filename [No InprocServer32?]";
		break;

	case ERR_NOLOADLIB:
		p = "Could not load library";
		break;

	case ERR_NOLIBATTR:
		p = "No Library Attributes";
		break;

	case ERR_NOLIBCOMP:
		p = "Could not get GetTypeComp Interface";
		break;

	case ERR_NOTYPEINFO:
		p = "No Library Type Info";
		break;

	case ERR_NOTYPEKIND:
		p = "No Library Type Kind";
		break;

	case ERR_NOTYPES:
		p = "No Types in Library";
		break;

	case ERR_NOVARDESC:
		p = "No VARDESC";
		break;

	case ERR_NOFUNCDESC:
		p = "No FUNCDESC";
		break;

	default:
		p = "Unknown error";
	}

	MessageBox(GetActiveWindow(), p , "Application Error", MB_OK);
}


