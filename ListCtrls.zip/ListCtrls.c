#include <windows.h>
#include <stdio.h>
#include <comcat.h>
#include <gc.h>
#include "lctltres.h"
#include "jcom.h"
#include "helper.h"
#include "show.h"

#define NUMCLSID 600			// maximum number of registry CLSID's

// Link with ole32.lib oleaut32.lib uuid.lib shell32.lib gc.lib

char g_str[512];

CTRL_CLSID CtrlCLSID[NUMCLSID];	// structs to hold CLSID and name

TYPELIBARAY TypeLibrary;		// main struct for type library

HINSTANCE hInst;

static BOOL CALLBACK DialogFunc(HWND hwndDlg, UINT msg, WPARAM wParam, LPARAM lParam);
HTREEITEM 	AddTreeItem(HWND hwndTV, HTREEITEM hParentNode, LPSTR lpszItem, int nLevel, void * pObj = NULL );

int APIENTRY WinMain(HINSTANCE hinst, HINSTANCE hinstPrev, LPSTR lpCmdLine, int nCmdShow)
{
	WNDCLASS wc;
	hInst = hinst;

	memset(&wc,0,sizeof(wc));
	wc.lpfnWndProc   = DefDlgProc;
	wc.cbWndExtra    = DLGWINDOWEXTRA;
	wc.hInstance     = hinst;
	wc.lpszMenuName  = "ID_MENU";
	wc.hCursor       = LoadCursor(NULL, IDC_ARROW);
	wc.hIcon         = LoadIcon(hinst, MAKEINTRESOURCE(ID_ICON));
	wc.hbrBackground = (HBRUSH) (COLOR_BTNFACE + 1);
	wc.lpszClassName = "listctrltree";

	if (!RegisterClass(&wc))
		return 0;

	// initialise com libraries
	if (S_OK != CoInitialize( NULL ))
		return 0;

	InitCommonControls();

	int hr = DialogBox(hinst, MAKEINTRESOURCE(IDD_MAINDIALOG), NULL, (DLGPROC) DialogFunc);

	CoUninitialize();

	return hr;

}

int Compare( CTRL_CLSID * pOne, CTRL_CLSID * pTwo )
{
	return strcmpi( pOne->pCtrlName, pTwo->pCtrlName );
}

void DisplayTypes( HWND hEdit1, long lParam )
{
	// cast it just to read as an int
	int * p = (int*)lParam;

	// cast lParam to any of the structs
	switch ( *p ){
	case TKIND_ENUM:
		SetWindowText( hEdit1, EnumToA((ENUM * )lParam ) );
		break;

	case TKIND_ALIAS:
		SetWindowText( hEdit1, AliasToA( (ALIAS * )lParam ) );
		break;

	case TKIND_DISPATCH:
		SetWindowText( hEdit1, DispatchToA( (DISPATCH_LIST * )lParam ) );
		break;

	case TKIND_INTERFACE:
		SetWindowText( hEdit1, InterfaceToA( (INTERFACE * )lParam ) );
		break;

	case TKIND_COCLASS:
		SetWindowText( hEdit1, CoClassToA( (COCLASS_LIST * )lParam ) );
		break;

	case TKIND_PROPERTY:
		SetWindowText( hEdit1, PropertyToA( (PROPERTY_LIST * )lParam ) );
		break;

	case TKIND_METHOD:
		SetWindowText( hEdit1, MethodToA( (METHOD_LIST * )lParam ) );
		break;

	case TKIND_MODULE:
		SetWindowText( hEdit1, ModuleToA( (MODULE * )lParam ) );
		break;
	}
}

void DisplayTypeLibrary( HWND hwndDlg, TYPELIBARAY * pTypeLibrary )
{
	SendMessage(GetDlgItem(hwndDlg, IDC_ICON), STM_SETICON, (WPARAM)TypeLibrary.hIcon, 0);

	TreeView_DeleteAllItems( GetDlgItem(hwndDlg, ID_TREEVIEW1 ) );

	// print info about the type lib
	HWND hEdit = GetDlgItem( hwndDlg, ID_EDITBOX );
	SetWindowText( hEdit, TypeLibraryToA( pTypeLibrary ) );

	// if there is a help file enable help button
	if (strstr(TypeLibrary.pHelpFile, "<none>"))
		EnableWindow( GetDlgItem(hwndDlg, ID_HELP), FALSE );
	else
		EnableWindow( GetDlgItem(hwndDlg, ID_HELP), TRUE );


	// display all types in treeview
	TYPE_LIST * pTypeList = pTypeLibrary->pTypeLists;

	while ( pTypeList ){
		switch ( pTypeList->eTypeKind ){
		case TKIND_RECORD:
			ShowStruct( GetDlgItem(hwndDlg, ID_TREEVIEW1 ), pTypeList );
			break;

		case TKIND_ENUM:
			ShowEnum( GetDlgItem(hwndDlg, ID_TREEVIEW1 ), pTypeList );
			break;

		case TKIND_UNION:
			ShowUnion( GetDlgItem(hwndDlg, ID_TREEVIEW1 ), pTypeList );
			break;

		case TKIND_DISPATCH:
			ShowDisp( GetDlgItem(hwndDlg, ID_TREEVIEW1 ), pTypeList );
			break;

		case TKIND_INTERFACE:
			ShowInterface( GetDlgItem(hwndDlg, ID_TREEVIEW1 ), pTypeList );
			break;

		case TKIND_COCLASS:
			ShowCoClass( GetDlgItem(hwndDlg, ID_TREEVIEW1 ), pTypeList );
			break;

		case TKIND_MODULE:
			ShowModule( GetDlgItem(hwndDlg, ID_TREEVIEW1 ), pTypeList );
			break;

		case TKIND_ALIAS:
			ShowAlias( GetDlgItem(hwndDlg, ID_TREEVIEW1 ), pTypeList );
			break;

		}
		pTypeList = pTypeList->pNext; // get next typelist
	}

}

void DisplayExtraInterface( HWND hwndDlg, REG_INTERFACE * pInterGUID )
{
	char tmp[200];
	OLECHAR * pOle;
	HWND hEdit1 = GetDlgItem( hwndDlg, ID_EDITBOX );
	StringFromCLSID( &pInterGUID->regguid, &pOle );

	sprintf(g_str, "%s %s", pInterGUID->pIntFaceName, UnicodeToAnsi( pOle ));
	SetWindowText( hEdit1, g_str );
	SysFreeString( pOle ); // here
}

/*--------------------------------------------------------------------
	Function	GetExtraInterfaces()

	Purpose		Each Control supports Interfaces that are not available
				from the typelibrary, these must be gained by doing
				a QueryInterface for all registered interfaces.
				This seems very ugly but apparently this is the only
				way to do it.

	Input		hwnd        -> dialog handle.
				hitem       -> the handle of the treeview item, parent node
				pCtrlCLSID  -> pointer to CRTL_CLSID struct for this control
				pAllRegInterfaces -> pointer to an array of all registered Interface GUIDs

	Return		No return value

--------------------------------------------------------------------*/
void GetExtraInterfaces( HWND hwnd, HTREEITEM hitem, CTRL_CLSID * pCtrlCLSID, REG_INTERFACE * pAllRegInterfaces )
{
	IUnknown  * IObject = NULL;
	IUnknown  * ITmp    = NULL;

	HWND hTV = GetDlgItem( hwnd, ID_TREEVIEW );

	// all the extra interfaces have been added to the
	// CTRL_CLSID struct therefore exit func.
	if ( pCtrlCLSID->pRegGUID ){
		return;
	}

	// to make the node with a [+] button there is a dummy child node, delete it
	HTREEITEM hFirstChild = TreeView_GetNextItem( hTV, hitem, TVGN_CHILD );
	TreeView_DeleteItem( hTV, hFirstChild );

	int len;

	if (SUCCEEDED(CoCreateInstance( &pCtrlCLSID->regclsid, NULL, CLSCTX_INPROC_SERVER, &IID_IUnknown, &IObject ))){

		IObject->lpVtbl->AddRef( IObject );

		// allocate a new start struct to hold all extra interfaces for this typelib
		pCtrlCLSID->pRegGUID  = GC_malloc( sizeof(REG_INTERFACE) );
		REG_INTERFACE * pRegTmpGUID = pCtrlCLSID->pRegGUID;

		while( pAllRegInterfaces->pNext ){
			if ( S_OK == IObject->lpVtbl->QueryInterface( IObject, &pAllRegInterfaces->regguid, &ITmp )){

				ITmp->lpVtbl->AddRef( ITmp );

				len = strlen ( pAllRegInterfaces->pIntFaceName );
				pRegTmpGUID->pIntFaceName = GC_malloc( len + 1 );
				strcpy( pRegTmpGUID->pIntFaceName, pAllRegInterfaces->pIntFaceName );
				pRegTmpGUID->regguid = pAllRegInterfaces->regguid;
				pRegTmpGUID->eTypeKind = TKIND_EXTRA;

				AddTreeItem( hTV, hitem, pAllRegInterfaces->pIntFaceName, 2, pRegTmpGUID );
				RELEASE( ITmp );

				// next struct
				if (pAllRegInterfaces->pNext){
					pRegTmpGUID->pNext = GC_malloc( sizeof(REG_INTERFACE) );
					pRegTmpGUID        = pRegTmpGUID->pNext;
				}
			}

			pAllRegInterfaces = pAllRegInterfaces->pNext;

		}
		RELEASE( IObject );
	}
	TreeView_SortChildren( hTV, hitem, FALSE );

}

int ActiveX( HWND hParent, HINSTANCE hInstance, CTRL_CLSID * pCtrlCLSID );

static BOOL CALLBACK DialogFunc(HWND hwndDlg, UINT msg, WPARAM wParam, LPARAM lParam)
{
	static REG_INTERFACE * pAllRegInterfaces;
	static CTRL_CLSID * pCtrlCLSID;

	switch (msg) {
	case WM_INITDIALOG:{
		// get all control CLSIDs and all registered Interface GUIDs
		// NUMCLSID is the max number of CTRL_CLSIDs to get, num is returned
		int num = GetRegisteredControlsClsids( CtrlCLSID, NUMCLSID );
		if ( num == ERR_OVERRUN )
			num = NUMCLSID;

		memset( &TypeLibrary, 0, sizeof( TYPELIBARAY ) );

		HWND hTV = GetDlgItem( hwndDlg, ID_TREEVIEW );

		qsort( CtrlCLSID, num, sizeof(CTRL_CLSID), Compare );

		for (int i =0; i<num; i++){
			AddTreeItem( hTV, NULL, CtrlCLSID[i].pCtrlName, 1, &CtrlCLSID[i] );
			AddTreeItem( hTV, NULL, "", 2, NULL ); // make a dummy child node, delete it later
		}
		// Send a message to do CollectAllRegisteredInterfaces() after
		// displaying window.
		PostMessage( hwndDlg, WM_APP+10, 0, 0);
		}
		return 1;

	case WM_APP+10:
		// get all registered interfaces from the Registry.
		pAllRegInterfaces = CollectAllRegisteredInterfaces();
		break;

	// WM_NOTIFY for both treeviews
	case WM_NOTIFY:{
		LPNMTREEVIEW pnmtv = (LPNMTREEVIEW) lParam;
		TVITEM tvi = pnmtv->itemNew;
		int idCtrl = (int) wParam;

		switch( ((LPNMHDR)lParam)->code ){

		case TVN_ITEMEXPANDING:
			switch( pnmtv->action ){
			case TVE_EXPAND:
				if ( idCtrl == ID_TREEVIEW )
					// get extra interfaces here
					GetExtraInterfaces( hwndDlg, tvi.hItem, (CTRL_CLSID*)tvi.lParam, pAllRegInterfaces );
			}
			return 0;

		case TVN_SELCHANGED:{
			LPNMTREEVIEW pnmtv = (LPNMTREEVIEW) lParam;
			TVITEM tvi = pnmtv->itemNew;
			int idCtrl = wParam;

			//There is a problem with the SELCHANGED notification
			//It can be sent when either a item is selected or
			//DELETED, since when an item deleted the selection moves
			//to a different selection.
			if( ( pnmtv->itemNew.state == TVIS_SELECTED && pnmtv->action ) || ( pnmtv->itemNew.state & TVIS_SELECTED && pnmtv->itemNew.state != TVIS_SELECTED ) ){

				// ID_TREEVIEW is top left panel
				if ( idCtrl == ID_TREEVIEW ){

					REG_INTERFACE * pInterGUID = (REG_INTERFACE *)pnmtv->itemNew.lParam;

					// this is for display of extra interfaces after the
					// Control node has been expanded
					if ( pInterGUID->eTypeKind == TKIND_EXTRA ){
						DisplayExtraInterface( hwndDlg, pInterGUID );
						return 0;
					}

					// this is to display the types of a control
					pCtrlCLSID = (CTRL_CLSID*)pnmtv->itemNew.lParam;

					// get the TypeLibrary and show icon
					int hr = GetTypeLibaray( pCtrlCLSID, &TypeLibrary );
					if ( hr < 0 ){
						ShowError( hr );
						// clear displays
						TreeView_DeleteAllItems( GetDlgItem(hwndDlg, ID_TREEVIEW1 ) );
						SetWindowText( GetDlgItem( hwndDlg, ID_EDITBOX ), "" );
						break;
					}

					DisplayTypeLibrary( hwndDlg, &TypeLibrary );
					SetWindowText( hwndDlg, TypeLibrary.pTypeLibFile );
				} // if ( idCtrl == ID_TREEVIEW )

				// ID_TREEVIEW1 is the bottom left panel
				if ( idCtrl == ID_TREEVIEW1 ){

					// cast it just to read the first member as an int
					int * p = (int*)pnmtv->itemNew.lParam;

					if ( p == NULL ){ // NULL if no info to print
						SetWindowText( GetDlgItem( hwndDlg, ID_EDITBOX1 ), "" );
						return 0;
					}

					HWND hEdit1 = GetDlgItem( hwndDlg, ID_EDITBOX1 );

					DisplayTypes( hEdit1, pnmtv->itemNew.lParam );

				} //if ( idCtrl == ID_TREEVIEW1 )
			} // if( ( pnmtv->itemNew.state == TVIS_SELECTED
			break;

			} // case TVN_SELCHANGED:

		} // switch( ((LPNMHDR)lParam)->code )
		} // case WM_NOTIFY
		break;

	case WM_COMMAND:

		switch (LOWORD(wParam)) {
		case ID_HELP:
			WinHelp( hwndDlg, TypeLibrary.pHelpFile, HELP_CONTENTS,  0);
			break;

		case ID_QUIT:
			PostMessage( hwndDlg, WM_CLOSE, 0, 0 );
			return 0;
		} // end switch (LOWORD(wParam))

		break;

	case WM_CLOSE:
		WinHelp( hwndDlg, TypeLibrary.pHelpFile, HELP_QUIT,  0 );
		EndDialog( hwndDlg, 0 );
		return 0;

	}

	return 0;
}

