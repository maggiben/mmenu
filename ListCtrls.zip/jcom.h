// jcom.h

#define _OLEAUT32_
#include <windows.h>
#include <ole2.h>
#include <oleauto.h>
#include <oaidl.h>
#include <stdarg.h>
#include <stdio.h>
#include <oaidl.h>

// macro for COM ->Release()
#ifndef RELEASE
	#define	RELEASE( pObj ) pObj->lpVtbl->Release( pObj )
#endif

// errors (mainly for debugging purposes)
#define ERR_MEMORY       -1
#define ERR_OVERRUN      -2
#define ERR_NOCATMANAGER -3
#define ERR_NOENUM       -4
#define ERR_NOFILEPATH   -5
#define ERR_NOLOADLIB    -6
#define ERR_NOLIBATTR    -7
#define ERR_NOLIBCOMP    -8
#define ERR_NOTYPEINFO   -9
#define ERR_NOTYPEKIND   -10
#define ERR_NOTYPES      -12
#define ERR_NOVARDESC    -14
#define ERR_NOFUNCDESC   -15

#define MAGIC 0x12345678

typedef struct RegInterfaceGUID REG_INTERFACE;

typedef struct RegInterfaceGUID{
	int		        eTypeKind;
	GUID            regguid;
	char     	  * pIntFaceName;
	REG_INTERFACE * pNext;
}REG_INTERFACE;

// For array of structs to hold all Registry
// COM control CLSID's and their names
typedef struct CtrlCLSID CTRL_CLSID;

typedef struct CtrlCLSID{
	CLSID    	    regclsid;
	char 	 	  * pCtrlName;
	REG_INTERFACE * pRegGUID;
}CTRL_CLSID;

// forward declarations of structures
typedef struct tagVarList    VAR_LIST;
typedef struct tagTypeList   TYPE_LIST;
typedef struct tagMethodList METHOD_LIST;
typedef struct tagProplist 	 PROPERTY_LIST;
typedef struct tagDispList   DISPATCH_LIST;
typedef struct tagTypeLib    TYPELIBARAY;
typedef struct tagInterface  INTERFACE;
typedef struct tagModule     MODULE;
typedef struct tagUnion      UNION;
typedef struct tagEnum		 ENUM;
typedef struct tagStruct	 STRUCT;

// available functions
int     GetRegisteredControlsClsids( CTRL_CLSID * pCtrlCLSID, int max );
void    FreeRegCtrlClsids( CTRL_CLSID * pCtrlCLSID, int num );
int     GetTypeLibaray( CTRL_CLSID * pCtrlClsid, TYPELIBARAY * pTypeLibrary );
void 	FreeTypeLibrary( TYPELIBARAY * pTypeLibrary );

// extend enum tagTYPEKIND for use with our structs
#define TKIND_METHOD       TKIND_MAX + 1
#define TKIND_PROPERTY     TKIND_METHOD + 1
#define TKIND_VAR          TKIND_PROPERTY + 1
#define TKIND_EXTRA        TKIND_VAR + 1

typedef INTERFACE GENERIC_LIST; // to enable reading the first few members of any list struct type.
typedef STRUCT   GENERIC_VARS; // ""    ""       "" of any var struct type.

typedef struct tagVarList {
	TYPEKIND       eTypeKind;
	char 		 * pName;
	char 		 * pDocString;
	char 		 * pHelpFile;
	DWORD		   ulHelpContext;
	int            iVarType;
	char         * pCustomName;
	DWORD  		   iValue;			// enums have values
	VARIANT        varValue;
	VAR_LIST 	 * pNext;
} VAR_LIST;

typedef struct tagModule {
	TYPEKIND   eTypeKind;
	char 	 * pName;
	char 	 * pDocString;
	char 	 * pHelpFile;
	DWORD	   ulHelpContext;
	int        nNumMembers;
	VAR_LIST * pVars;
} MODULE;

typedef struct tagUnion {
	TYPEKIND    eTypeKind;
	char 	  * pName;
	char 	  * pDocString;
	char 	  * pHelpFile;
	DWORD		ulHelpContext;
	int         nNumMembers;
	VAR_LIST  * pVars;
	GUID	    uuid;
} UNION;

typedef struct tagEnum {
	TYPEKIND   eTypeKind;
	char 	 * pName;
	char 	 * pDocString;
	char 	 * pHelpFile;
	DWORD 	   ulHelpContext;
	int        nNumMembers;
	VAR_LIST * pVars;
} ENUM;

typedef struct tagStruct {
	TYPEKIND   eTypeKind;
	char 	 * pName;
	char 	 * pDocString;
	char 	 * pHelpFile;
	DWORD	   ulHelpContext;
	int        nNumMembers;
	VAR_LIST * pVars;
} STRUCT;

typedef struct tagAlias {
	TYPEKIND   eTypeKind;
	char 	 * pName;
	char 	 * pDocString;
	char 	 * pHelpFile;
	DWORD      ulHelpContext;
	char 	 * pRealName;
	GUID	   uuid;
} ALIAS;

typedef struct tagProplist {
	TYPEKIND 	    eTypeKind;
	char	 	  * pName;
	char 		  * pDocString;
	char 		  * pHelpFile;
	DWORD		    ulHelpContext;
	char    	  * pCustomName;
	VARTYPE		    vtType;
	VARIANT			varValue;
	MEMBERID		memid;
	PROPERTY_LIST * pNext;
} PROPERTY_LIST;

typedef struct tagMethodList {
	TYPEKIND    	  eTypeKind;
	char 			* pName;
	char	 		* pDocString;
	char 			* pHelpFile;
	DWORD 			  ulHelpContext;
	GUID 			  guid;
	FUNCKIND		  funckind;
	INVOKEKIND		  invkind;
	short			  cParams;
	short			  cParamsOpt;
	MEMBERID		  memid;
	short 	  		  cRetType;
	int 			  iDispID;
	HREFTYPE		  hRefType;
	char 			* pCustomName;
	VAR_LIST        * pVars;
	METHOD_LIST		* pNext;
} METHOD_LIST;

typedef struct tagInterface {
	TYPEKIND 	  eTypeKind;
	char 		* pName;
	char 		* pDocString;
	char 		* pHelpFile;
	DWORD 		  ulHelpContext;
	int      	  numInterfaces;
	short		  wTypeFlags;
	int         * rgDispId;
	GUID		  uuid;
	DISPID		  dispid;
	int     	  numMethods;
	BOOL		  fInherited;	// Only used when there ius an inherited interface
	METHOD_LIST * pMethod;
	INTERFACE   * pInterface;    // can have early Binding (wTypeFlags & TYPEFLAG_FDUAL)
} INTERFACE;

typedef struct tagDispList {
	TYPEKIND 	    eTypeKind;
	char 		  * pName;
	char 		  * pDocString;
	char 		  * pHelpFile;
	DWORD 		    ulHelpContext;
	GUID	 	    uuid;
	int      	    numMethods;
	int      	    numInterfaces;
	int      	    numProperties;
	short			wTypeFlags;
	int            * rgDispId;
	METHOD_LIST    * pMethod;
	PROPERTY_LIST  * pProperty;
	INTERFACE 	   * pInterface;    // can have early Binding (wTypeFlags & TYPEFLAG_FDUAL)
	BOOL		 	 fInherited;	// Only used when there ius an inherited interface
	DISPATCH_LIST  * pNext; 		// Only used when associated with a CoClass
} DISPATCH_LIST;

typedef struct tagCoClassList {
	TYPEKIND        eTypeKind;
	char 	      * pName;
	char		  * pDocString;
	char 		  * pHelpFile;
	DWORD 		    ulHelpContext;
	CLSID 		    uuid;
	DISPATCH_LIST * pDispInterface;
	INTERFACE 	  * pInterface;
} COCLASS_LIST;

typedef struct tagTypeList {
	TYPEKIND          eTypeKind;
	ENUM		  	* pEnum;
	MODULE	   	    * pModule;
	STRUCT			* pStruct;
	UNION			* pUnion;
	ALIAS			* pAlias;
	INTERFACE		* pInterface;
	DISPATCH_LIST  	* pDispInterface;
	COCLASS_LIST	* pCoClass;
	TYPE_LIST		* pNext;
} TYPE_LIST;

typedef struct tagTypeLib {
	int    		    numInfoLists;
	char		  * pName;
	char		  * pDocString;
	char		  * pHelpFile;
	unsigned long   ulHelpContext;
	char 		  * pTypeLibFile;
	CLSID		    CtrlCLSID;		// CLSID this is used for the creation of the object
	HICON  		    hIcon;
	TLIBATTR   		tLibattr;
	BINDPTR    	  * pBindPtr;
	TYPE_LIST     * pTypeLists;
} TYPELIBARAY;


