/*--[ Info ]--------------------------------------------------------------
 Program....: Color Picker
 Version....: 1.0
 Author.....: Tuukka Lehtinen (TL) tuukka.lehtinen@koti.soon.fi
 Description: This litle tool help you selecting web page colors.

 Whe have cool looking color box and fade selected color for right.
 Litle edit box in show hex value of color. Selected color is actually
 button. There is also copy button that copy hex value to cliboard and
 exit button that quit application. ? only show MessageBox.

 When user press button down in color selection area we lock mouse
 region using ClipCursor(). When button is released mouse is released.
 This help select "pure" colors, like default common color dialog does.

------------------------------------------------------------------------*/

/*--[ Includes ]--------------------------------------------------------*/
#include <windows.h>	// base functions
#include <stdio.h>		// for sscanf
#include "cp.h"				// Resource ID:s
#include "fcp.h"			// Function prototypes

/*--[ Defines ]---------------------------------------------------------*/
#define ID_EDIT		101
#define ID_COLOR	102
#define ID_COPY		103
#define ID_EXIT   104
#define ID_HELP		105

/*--[ Global variables ]------------------------------------------------*/
const TCHAR szClassName[] = "CP Class";
const TCHAR szAppName[] = "Color Picker";
HINSTANCE hInst;

static HWND edit;
static HWND color;
static HDC wDC2;
HWND hwndMain;

/*--[ WinMain ]---------------------------------------------------------*/
int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance,
	LPSTR lpCmdLine, int nCmdShow)
{
	MSG Msg;
	WNDCLASSEX wc;

	// Attempt to create a mutex. If the mutex already existed,
  // GetLastError will return ERROR_ALREADY_EXISTS
  HANDLE hInstanceMutex = CreateMutex(NULL,TRUE, szAppName);
  if(GetLastError() == ERROR_ALREADY_EXISTS)
  {
			if(hInstanceMutex)
				CloseHandle(hInstanceMutex);
      return 0;
  }

	// Register window class
	wc.cbSize = sizeof(WNDCLASSEX);
	wc.style  = CS_HREDRAW | CS_VREDRAW;
	wc.lpfnWndProc = WndProc;
	wc.cbClsExtra = 0;
	wc.cbWndExtra = 0;
	wc.hInstance = hInstance;
	wc.hbrBackground = (HBRUSH)(COLOR_BTNFACE+1);
	wc.lpszMenuName = NULL;
	wc.lpszClassName = szClassName;
	wc.hIcon = LoadIcon(hInstance,MAKEINTRESOURCE(IDICON));
	wc.hCursor = LoadCursor(NULL, IDC_ARROW);
	wc.hIconSm = LoadIcon(hInstance,MAKEINTRESOURCE(IDICON));

	// Make global instance
	hInst = hInstance;

	if(!RegisterClassEx(&wc))
	{
		MessageBox(NULL, "Window Registration Failed!", "Error!", MB_ICONEXCLAMATION | MB_OK);
		return 0;
	}

	// Create Window
	hwndMain = CreateWindowEx(0, szClassName, szAppName,
		WS_VISIBLE | WS_SYSMENU | WS_MINIMIZEBOX,
		250,140,285,310,0,0,hInstance,0);

	// Cannot create window, bossible reason too meny open windows.
	// so we don't try to display msg box.
	if(!hwndMain)
	{
		return 0;
	}

	// ShowWindow return only previus state
	ShowWindow(hwndMain, SW_SHOWNORMAL);
	if(FALSE == UpdateWindow(hwndMain))
		return 0;

	// Start message loop
	while(GetMessage(&Msg, NULL, 0, 0))
	{
		TranslateMessage(&Msg);
		DispatchMessage(&Msg);
	}

	// Try to clean up litle bit before we quit.
	ReleaseMutex(hInstanceMutex);
  CloseHandle(hInstanceMutex);

	return Msg.wParam;
}

/*--[ WndProc ]---------------------------------------------------------*/
LRESULT CALLBACK WndProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
	static HDC wDC;
	static HDC cDC;
	static int r,g,b;
	static HWND copy;
	static HWND exit;
	static HWND help;
	static char buf[7];

	switch(msg)
	{
	case WM_CREATE:

		if(FALSE == CreateWindows(hwnd, &edit, &color, &copy, &exit, &help))
			ErrorExit();

		if(FALSE == DrawColorMap(hwnd, &wDC))
			ErrorExit();

		if(FALSE == InitColor(hwnd, &cDC))
			ErrorExit();

		if(FALSE == DrawColorFade(hwnd,&wDC2,RGB(0,0,0)))
			ErrorExit();

		r = g = b = 0;
		if(FALSE == SetWindowText(edit, "000000"))
			ErrorExit();

		if(NULL == lstrcpy(buf,"000000"))
			ErrorExit();
		break;

	case WM_COMMAND:
		// is edit box value is change
		if(HIWORD (wParam) == EN_CHANGE && LOWORD(wParam) == ID_EDIT)
		{
			INT r2, g2, b2;

			// If GetWindowText success then try to scan string
			if(GetWindowText(edit, buf, 7))
			if(EOF != sscanf(buf,"%02X%02X%02X",&r2,&g2,&b2))
			{
				r = r2;
				g = g2;
				b = b2;
				if(FALSE == InvalidateRect(color, NULL, TRUE))
					ErrorExit();

				if(SendMessage(edit,EM_GETMODIFY, 0,0))
				if(FALSE == DrawColorFade(hwnd,&wDC2,RGB(r,g,b)))
					ErrorExit();
			}
			break;
		}

		switch(LOWORD(wParam))
		{
		case ID_COPY:
			if(buf[0]) // Ensure that we have someting to copy
				if(FALSE == CopyTextToClipboard(hwnd, buf))
				  ErrorExit();
			break;

		case ID_EXIT:
			PostQuitMessage(0);
		break;

		case ID_HELP:
			MessageBox(hwnd, "Color Picker example 1.0", "About", MB_OK | MB_ICONINFORMATION);
		break;
		}
		break;

	case WM_DRAWITEM:
		{
			HDC dc;
			LOGBRUSH logbrush;
			HBRUSH brush;
			RECT rc;

			logbrush.lbStyle = BS_SOLID;
			logbrush.lbColor = RGB(r, g ,b);
			brush = CreateBrushIndirect(&logbrush);
			if(brush == NULL) ErrorExit();

			rc.left = 0;
			rc.top = 0;
			rc.bottom = 20;
			rc.right = 60;
			if(FALSE == FillRect(cDC, &rc, brush))
				ErrorExit();

			if(FALSE == ValidateRect(hwnd, &rc))
				ErrorExit();

			if(FALSE ==DeleteObject(brush))
				ErrorExit();

			dc = GetDC(hwnd);
			if(dc == NULL) ErrorExit();

			if(FALSE == BitBlt(dc, 65, 260, 60, 20, cDC, 0, 0, SRCCOPY))
				ErrorExit();

			if(FALSE == ReleaseDC(hwnd, dc))
				ErrorExit();
		}
	break;


	case WM_PAINT:
		{
			PAINTSTRUCT paint;
			HDC dc;
			RECT rc;

			dc = BeginPaint(hwnd, &paint);
			if(dc == NULL) ErrorExit();

			rc.left   = 0;
			rc.top    = 0;
			rc.right  = 255;
			rc.bottom = 255;
			if(FALSE == ValidateRect(hwnd, &rc))
				ErrorExit();

			rc.left   = 260;
			rc.top    = 0;
			rc.right  = 260+15;
			rc.bottom = 255;
			if(FALSE == ValidateRect(hwnd, &rc))
				ErrorExit();

			if(FALSE == BitBlt(dc, 0, 0, 255, 255, wDC, 0, 0, SRCCOPY))
				ErrorExit();
			if(FALSE == BitBlt(dc, 260, 0, 15, 255, wDC2, 0, 0, SRCCOPY))
				ErrorExit();

			// EndPaint return value is always nonzero
			EndPaint(hwnd, &paint);
		}
		break;

	case WM_LBUTTONUP:
		// Make cursor free to move anywhere.
		if(FALSE == ClipCursor(NULL))
			ErrorExit();
	break;

	case WM_LBUTTONDOWN:
	case WM_MOUSEMOVE:
		if(FALSE == ColorSelection(wParam, lParam, hwnd))
			ErrorExit();
	break;

	case WM_MOVING:
		return Magnet(&lParam);


	case WM_DESTROY:
		PostQuitMessage(0);
		break;

	default:
		return DefWindowProc(hwnd,msg,wParam,lParam);
	}
	return 0;
}

/*------------------------------------------------------------------------
Procedure:     Magnet ID:1
Purpose:       Make window to magnetic to desktop walls.
Input:         Pointer to lParam.
Output:        Change lParam pointed structure.
Errors:        Return FALSE if error.
------------------------------------------------------------------------*/
BOOL Magnet(LPARAM *lParam)
{
	RECT *pRect = (LPRECT) *lParam;	// Ikkunan koordinaatit
	static RECT rcOld = {
		0, 0, 0, 0 		};
	RECT rcDesktop;		// Ty�skentely alueen koko
	INT	 iPower = 16;	// Magneettisuuden herkkyys
	SIZE szSize;		// Ikkunan koko

	// Otetaan ikkuna alueen koko
	if(FALSE == SystemParametersInfo(SPI_GETWORKAREA, 0, &rcDesktop, 0))
		return FALSE;

	szSize.cx = pRect->right -  pRect->left;
	szSize.cy = pRect->bottom - pRect->top;


	if(pRect->top < iPower && rcOld.top > pRect->top)
	{
		pRect->top = 0;
		pRect->bottom = szSize.cy;
	}
	else
	    if(pRect->bottom > (rcDesktop.bottom - iPower) &&
		    rcOld.bottom  < pRect->bottom)
	{
		pRect->bottom = rcDesktop.bottom;
		pRect->top = rcDesktop.bottom - szSize.cy;
	}

	if(pRect->left < iPower && rcOld.left > pRect->left)
	{
		pRect->left = 0;
		pRect->right = szSize.cx;
	}
	else
	    if(pRect->right > (rcDesktop.right - iPower) &&
		    rcOld.right < pRect-> right)
	{
		pRect->right = rcDesktop.right;
		pRect->left =  rcDesktop.right - szSize.cx;
	}

	rcOld.top = pRect -> top;
	rcOld.bottom = pRect -> bottom;
	rcOld.left = pRect -> left;
	rcOld.right = pRect -> right;

	return TRUE;
}

/*------------------------------------------------------------------------
Procedure:     CopyTextToClipboard ID:1
Purpose:       Copy text to clipboard.
Input:         hwnd - Window handle, lpText - Text to copy.
Output:        Puts CF_TEXT ANSI type text to clipboard.
Errors:        Return FALSE if error or input data is bad. This
               function can false if some other program use cliboard
               same time. Return TRUE if success.
------------------------------------------------------------------------*/
BOOL CopyTextToClipboard(HWND hwnd,LPCTSTR lpText)
{
	HGLOBAL hGlobal;
	TCHAR   *pGlobal;

	// Check valid input data.
	if(hwnd == NULL) return FALSE;
	if(!lstrlen(lpText)) return FALSE;

	// Allocate memory to string including terminating null character(s).
	hGlobal = GlobalAlloc (GHND | GMEM_SHARE, lstrlen(lpText) * sizeof(TCHAR) + sizeof(TCHAR));
	if(hGlobal == NULL) return FALSE;

	// Lock memory to get pointer we can use it.
	pGlobal = GlobalLock (hGlobal);
	if(pGlobal == NULL) goto CopyTextToClipboardError;

	// Copy text to memory block
	if(NULL == lstrcpy(pGlobal, lpText))
		goto CopyTextToClipboardError;

	// Unlock memory, double error check becose GlobalUnlock() return FALSE some times.
	if(FALSE == GlobalUnlock(hGlobal))
	{
		if(NO_ERROR != GetLastError())
			goto CopyTextToClipboardError;
	}

	// Open clipboard
	if(FALSE == OpenClipboard (hwnd))
		goto CopyTextToClipboardError;

	// Lets become clipboard owner, to clearin it.
	if(FALSE ==EmptyClipboard())
		goto CopyTextToClipboardError;

	// When we have owner we can change data.
	if(NULL == SetClipboardData (CF_TEXT, hGlobal))
		goto CopyTextToClipboardError;

	// Close clipboard to allow other application get access
	if(FALSE == CloseClipboard())
		goto CopyTextToClipboardError;

	return TRUE;

	// We have error so free unnesesary memory and exit
	CopyTextToClipboardError:

	GlobalFree(hGlobal);
	return FALSE;
}


/*------------------------------------------------------------------------
Procedure:     CreateWindows ID:1
Purpose:       Create child windows. 1 edit box and 4 buttons.
Input:         Main and child windows handles.
Output:        Change child windows handles.
Errors:        Return false if window some window cannot create.
------------------------------------------------------------------------*/
BOOL CreateWindows(HWND hwnd, HWND *edit, HWND *color, HWND *copy, HWND *exit, HWND *help)
{
	*edit = CreateWindowEx(WS_EX_STATICEDGE, "EDIT",0, WS_CHILD | WS_VISIBLE | SS_LEFT,
		0, 260, 60, 20, hwnd, (VOID *)ID_EDIT, hInst,0);
	if(*edit == NULL) return FALSE;

	// Set limit to edit control, so user can only input six charter.
	SendMessage(*edit, EM_SETLIMITTEXT, 6, 0);

	*color = CreateWindowEx(WS_EX_STATICEDGE, "BUTTON", 0, WS_CHILD | WS_VISIBLE | BS_OWNERDRAW,
		65, 260, 60, 20, hwnd, (VOID *) ID_COLOR, hInst,0);
	if(*color == NULL) return FALSE;

	*copy = CreateWindowEx(WS_EX_STATICEDGE, "BUTTON", "Copy", WS_CHILD | WS_VISIBLE |
		    BS_PUSHBUTTON, 130, 260, 60, 20, hwnd, (VOID *)ID_COPY, hInst,0);
	if(*copy == NULL) return FALSE;

	*exit = CreateWindowEx(WS_EX_STATICEDGE, "BUTTON", "Exit", WS_CHILD | WS_VISIBLE |
		    BS_PUSHBUTTON, 195, 260, 60, 20, hwnd, (VOID *)ID_EXIT, hInst,0);
	if(*exit == NULL) return FALSE;

	*help = CreateWindowEx(WS_EX_STATICEDGE, "BUTTON", "?", WS_CHILD | WS_VISIBLE |
		    BS_PUSHBUTTON, 260, 260, 15, 20, hwnd, (VOID *)ID_HELP, hInst,0);
	if(*help == NULL) return FALSE;

	return TRUE;
}

/*------------------------------------------------------------------------
Procedure:     DrawColorMap ID:1
Purpose:       Draw color square. Square size is 215x215.
Input:         hwnd - mother window handle
hdc - device contect to store created picture.
Output:        Change hdc.
Errors:        Return FALSE if error, TRUE ok.
------------------------------------------------------------------------*/
BOOL DrawColorMap(HWND hwnd, HDC *wDC)
{
	HDC hDC;
	HBITMAP hBit;
	INT x, y, r, g, b;
	COLORREF crColor;

	hDC = GetDC(hwnd);
	if(hDC == NULL) return FALSE;

	*wDC = CreateCompatibleDC(hDC);
	if(*wDC == NULL) return FALSE;

	hBit = CreateCompatibleBitmap(hDC, 255,255);
	if(hBit == NULL) return FALSE;

	if(FALSE == DeleteObject(SelectObject(*wDC, hBit)))
		return FALSE;

	g = 255;
	r = 255;
	for(y=0; y<255; y++)
	{
		for(x=0; x<255; x++)
		{
			r--;
			b = 255 - r;
			crColor = RGB(r,g,b);
			if(-1 == SetPixel(*wDC, x,y, crColor))
			{
				ReleaseDC(hwnd, hDC);
				return FALSE;
			}
		}
		r = 255;
		g--;
	}

	ReleaseDC(hwnd, hDC);

	return TRUE;
}

/*------------------------------------------------------------------------
Procedure:     DrawColorFade ID:1
Purpose:       Create or update color fade.
Input:         hwnd - mother window handle
wDC - device context to draw
color - color to fade
Output:        Change wDC
Errors:        Return FALSE if error.
------------------------------------------------------------------------*/
BOOL DrawColorFade(HWND hwnd, HDC *wDC, COLORREF color)
{
	HBITMAP hBit;
	HDC hDC;
	INT x, y, r, g, b;
	INT R, G, B;
	COLORREF crColor;
	RECT rc;

	if(*wDC == NULL)
	{
		hDC = GetDC(hwnd);
		*wDC = CreateCompatibleDC(hDC);
		hBit = CreateCompatibleBitmap(hDC, 15,255);
		DeleteObject(SelectObject(*wDC, hBit));
	}

	R = GetRValue(color);
	G = GetGValue(color);
	B = GetBValue(color);

	for(y=0; y<127; y++)
	{
		r = 255 - (255 - R) * y / 127;
		g = 255 - (255 - G) * y / 127;
		b = 255 - (255 - B) * y / 127;

		crColor = RGB(r, g, b);
		for(x=0; x<16; x++)
			SetPixel(*wDC, x, y, crColor);
	}

	for(y=0; y<127; y++)
	{
		r = R - R * y / 127;
		g = G - G * y / 127;
		b = B - B * y / 127;

		crColor = RGB(r, g, b);
		for(x=0; x<16; x++)
			SetPixel(*wDC, x, y + 127, crColor);
	}


	rc.top    = 0;
	rc.left   = 260;
	rc.right  = 260+15;
	rc.bottom = 255;

	InvalidateRect(hwnd, &rc, FALSE);

	return TRUE;
}

/*------------------------------------------------------------------------
 Procedure:     LockMouse ID:1
 Purpose:       Lock mouse moving area, so cursor cannot move outside
                the specifid rectangle.
 Input:         Client coordinates. Use global hwndMain handle.
 Output:        Mouse.
 Errors:        None
------------------------------------------------------------------------*/
BOOL LockMouse(int x1,int y1,int x2,int y2)
{
	RECT 	rect;
	POINT pt;

	pt.x = x1;
	pt.y = y1;
	if(FALSE == ClientToScreen(hwndMain,&pt))
		return FALSE;
	rect.left = pt.x;
	rect.top = pt.y;
	pt.x = x2;
	pt.y = y2;
	if(FALSE == ClientToScreen(hwndMain,&pt))
		return FALSE;

	rect.right = pt.x;
	rect.bottom = pt.y;
	return ClipCursor(&rect);
}

/*------------------------------------------------------------------------
 Procedure:     ColorSelection ID:1
 Purpose:       Check mouse button and position. Select color.
 Input:         wParam, lParam and main hwnd.
 Output:        Update colors.
 Errors:        Return false.
------------------------------------------------------------------------*/
BOOL ColorSelection(WPARAM wParam, LPARAM lParam, HWND hwnd)
{
	COLORREF col;
	INT x,y;
	INT r,g,b;

	if(wParam == MK_LBUTTON)
	{
		// Check where mouse is..
		x = LOWORD(lParam);
		y = HIWORD(lParam);

		// It is in color box, show we confines the cursor position
		if(x < 256 && y < 257)
		{
			if(FALSE == LockMouse(0,0,255,255))
				return FALSE;

			r = 255 - x;
			b = 255 - r;
			g = 255 - y;
			ColorsUpdate(r, g, b, TRUE);
		}

		if(x > 260 && x < 260+15 && y < 255)
		{
			if(FALSE == LockMouse(260, 0, 260+15, 255))
				return FALSE;

			col = GetPixel(wDC2, x - 260, y);
			r = GetRValue(col);
			g = GetGValue(col);
			b = GetBValue(col);
			ColorsUpdate(r, g, b, FALSE);
		}
	}
	return TRUE;
}

/*------------------------------------------------------------------------
 Procedure:     ColorsUpdate ID:1
 Purpose:       Update selected color area and color fade.
 Input:         Color, and flag for updating fade.
 Output:        Put color value to edit control.
 Errors:        None
------------------------------------------------------------------------*/
void ColorsUpdate(INT r, INT g, INT b, BOOL Fade)
{
	char buf[7];

	if(Fade) DrawColorFade(hwndMain,&wDC2,RGB(r, g, b));
	wsprintf(buf,"%02X%02X%02X",r,g,b);
	SetWindowText(edit, buf);
	InvalidateRect (color, NULL, TRUE);
}

/*------------------------------------------------------------------------
 Procedure:     InitColor ID:1
 Purpose:       Create device context for selected color.
 Input:         hwnd - mother windows handle, wDC pointer to DC to
                sore value.
 Output:        Modify DC.
 Errors:        Return FALSE if error.
------------------------------------------------------------------------*/
BOOL InitColor(HWND hwnd, HDC *wDC)
{
	HDC hDC;
	HBITMAP hBit;

	hDC = GetDC(hwnd);
	if(hDC == NULL) return FALSE;

	*wDC = CreateCompatibleDC(hDC);
	if(*wDC == NULL) return FALSE;

	hBit = CreateCompatibleBitmap(hDC, 60,20);
	if(hBit == NULL) return FALSE;

	if(FALSE == DeleteObject(SelectObject(*wDC, hBit)))
		return FALSE;

	return TRUE;
}


/*------------------------------------------------------------------------
 Procedure:     ErrorExit ID:1
 Purpose:       Close program during WinApi error.
 Input:         None
 Output:        Return exit value to error number that
                GetLastError give.
 Errors:        None
------------------------------------------------------------------------*/
void ErrorExit(void)
{
	DWORD dw = GetLastError();

  MessageBeep(MB_ICONEXCLAMATION);
	MessageBox(hwndMain, "Unexpected error, application will be closed",
	szAppName, MB_OK | MB_ICONERROR);

	ExitProcess(dw);
}
