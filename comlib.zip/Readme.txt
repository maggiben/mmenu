Hello,

due to the tremendous number of requests (well at least 4) :-)
here is the code for a basic COM component in LCC-WIN32.

Nothing really complicated inside but a bunch of abstractions
and circuitry to glue together.

CONTENT:
 iobject.dll -- THE COM component
 tstiobject.exe -- Sample usage application
 iobject.h -- Component definitions
 iobject.c -- Component code
 tstiobject.c -- Sample application code

TO RUN: 
  Unzip in a dir
  cd 'this dir'
  tstiobject  == only errors !
  (c:\\windows\\system\\ || c:\\winnt\\system32\\)regsvr32 iobject.dll
  tstiobject  == the beauty of the beast ! (see co_debug.txt :)

Then, read the source and build your own...

WARNING:
This code is NAMEWARE
Never eard ? Not surprising... See inside iobject.c

CU,
-jpg (Jesse)
