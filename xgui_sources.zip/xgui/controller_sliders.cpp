// xgui 0.0.2 / 2002-03-31
//	controller_sliders.cpp
//
//	http://606u.dir.bg/
//	606u@dir.bg

#include "_p.h"

#include "controller.h"


namespace xgui {


LRESULT
controller::notification_message_as_sliders (
	IN LPNMHDR message)
{
	int	comps [4], i, j;
	COLORREF	c;

	switch (message->code & messages::mask)
	{
	case	messages::drag:
	case	messages::release:
		// there are always at least 3 sliders (4 for CMYK mode only)
		comps [0] = sliders [0].position ();
		comps [1] = sliders [1].position ();
		comps [2] = sliders [2].position ();
		if (sliders [3].attached ())
			comps [3] = sliders [3].position ();

		for (i=0; i<4; i++)
			// update OTHER sliders
			if (sliders [i].attached () &&
				sliders [i].window_handle () != message->hwndFrom)
				for (j=0; j<4; j++)
					// indexes of all components AFTER current one should be decreased
					sliders [i].component ((j > i ? j - 1 : j), comps [j]);

		c = color_as_sliders ();
		well.color (c);
		notify_parent (c);

		debug_state ("slider_move = %x", message->code);

		break;
	}
	return (0);
}


void
controller::layout_as_sliders (void)
{
	// initialize if neccessary
	sliders [0].detach ();
	sliders [1].detach ();
	sliders [2].detach ();
	sliders [3].detach ();

	layout_mode = layout_sliders;
}


void
controller::visual_as_sliders (
	IN int value)
{
	COLORREF	old_color;

	// skip first time - when visual_mode will not be updated yet
	old_color = (visual_mode != -1 ? color () : 0);
	visual_mode = value;
	switch (visual_mode & modes::mask)
	{
	case	modes::rgb_red:
	case	modes::rgb_green:
	case	modes::rgb_blue:
		sliders [0].visual (modes::rgb_red);
		sliders [1].visual (modes::rgb_green);
		sliders [2].visual (modes::rgb_blue);
		break;

	case	modes::hsv_hue:
	case	modes::hsv_sat:
	case	modes::hsv_value:
		sliders [0].visual (modes::hsv_hue);
		sliders [1].visual (modes::hsv_sat);
		sliders [2].visual (modes::hsv_value);
		break;
	
	default:
		ASSERT (FALSE);
	}
	color (old_color);
}


COLORREF
controller::color_as_sliders (void) const
{
	int	comps [4];
	COLORREF	c;

	// there are always at least 3 sliders (4 for CMYK mode only)
	comps [0] = sliders [0].position ();
	comps [1] = sliders [1].position ();
	comps [2] = sliders [2].position ();
	if (sliders [3].attached ())
		comps [3] = sliders [3].position ();

	switch (visual_mode & modes::mask)
	{
	case	modes::rgb_red:
	case	modes::rgb_green:
	case	modes::rgb_blue:
		c = RGB (comps [0], comps [1], comps [2]);
		break;

	case	modes::hsv_hue:
	case	modes::hsv_sat:
	case	modes::hsv_value:
		c = convert::hsv2rgb (
			(double) comps [0] / (double) scale::hsv_hue,
			(double) comps [1] / (double) max::hsv_sat,
			(double) comps [2] / (double) max::hsv_value);
		break;

	default:
		ASSERT (FALSE);
		c = 0;
	}

	return (c);
}


void
controller::color_as_sliders (
	IN COLORREF value)
{
	double	h, s, v;
	int		r, g, b;
	int		hh, ss, vv;

	// rgb decomposed
	r = GetRValue (value);
	g = GetGValue (value);
	b = GetBValue (value);

	switch (visual_mode & modes::mask)
	{
	case	modes::rgb_red:
	case	modes::rgb_green:
	case	modes::rgb_blue:
		sliders [0].position (r);
		sliders [0].component (0, g);
		sliders [0].component (1, b);

		sliders [1].position (g);
		sliders [1].component (0, r);
		sliders [1].component (1, b);

		sliders [2].position (b);
		sliders [2].component (0, r);
		sliders [2].component (1, g);
		break;

	case	modes::hsv_hue:
	case	modes::hsv_sat:
	case	modes::hsv_value:
		convert::rgb2hsv (
			(double) r / (double) max::rgb_red,
			(double) g / (double) max::rgb_green,
			(double) b / (double) max::rgb_blue,
			&h, &s, &v);
		hh = (int) (h * scale::hsv_hue);
		ss = (int) (s * max::hsv_sat);
		vv = (int) (v * max::hsv_value);
		sliders [0].position (hh);
		sliders [0].component (0, ss);
		sliders [0].component (1, vv);

		sliders [1].position (ss);
		sliders [1].component (0, hh);
		sliders [1].component (1, vv);

		sliders [2].position (vv);
		sliders [2].component (0, hh);
		sliders [2].component (1, ss);
		break;

	default:
		ASSERT (FALSE);
	}
}


void
controller::slave_as_sliders (
	IN int index,
	IN HWND window)
{
	if (index == 0)
	{
		well.attach (window);
		well.master_attach (hwnd);
	}
	else
	{
		sliders [index - 1].attach (window);
		sliders [index - 1].master_attach (hwnd);
	}
}


} // xgui namespace
