// xgui 0.0.2 / 2002-03-31
//	_p.cpp (for precompiled header)
//
//	http://606u.dir.bg/
//	606u@dir.bg

#include "_p.h"
