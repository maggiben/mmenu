// xgui 0.0.2 / 2002-03-31
//	_p.h (precompiled header)
//
//	http://606u.dir.bg/
//	606u@dir.bg

#if	defined (_MSC_VER) // Microsoft Visual C++
#	define	_CRTDBG_MAP_ALLOC
#endif

#if	defined (_MSC_VER)
#	pragma warning (disable: 4064)	// switch of incomplete enum
#	pragma warning (disable: 4127)	// conditional expression is constant
#	pragma warning (disable: 4710)	// 'xxx' : function not expanded
#endif

#include <windows.h>
#include <zmouse.h>

#include <assert.h>
#include <math.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#if	!defined (ASSERT)
#	define	ASSERT	assert
#endif

#if	!defined (MIN)
#	define	MIN	min
#endif

#if	!defined (MAX)
#	define	MAX	max
#endif
