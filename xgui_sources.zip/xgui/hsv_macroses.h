// xgui 0.0.2 / 2002-03-31
//	hsv_macroses.h
//
//	http://606u.dir.bg/
//	606u@dir.bg

#ifndef	_hsv_macroses_h
#define	_hsv_macroses_h


// calculate times a coefficient will be incremented for total width w;
//	-1, because coefficients are advanced after their use,
//	so their value is not important after last advance */
#define	HSV_LOOP_STEPS(w)	((w) - 1)


// return RGB color for HSV colorspace in HUE mode,
//	for HUE between 0 and 1 (0 and 60 deg)
#define	HSV_0()	\
	RGB (	\
		(BYTE) (coef1 >> int_extend),	\
		(BYTE) (coef3 >> int_extend),	\
		(BYTE) (val >> int_extend))

// advance for HSV colorspace in HUE mode, for HUE between 0 and 1 (0 and 60 deg)
#define	HSV_HUE_ADV_0()	\
	coef1 += coef1_adv,	\
	coef3 += coef3_adv


#define	HSV_1()	\
	RGB (	\
		(BYTE) (coef1 >> int_extend),	\
		(BYTE) (val >> int_extend),	\
		(BYTE) (coef2 >> int_extend))

#define	HSV_HUE_ADV_1()	\
	coef1 += coef1_adv,	\
	coef2 += coef2_adv


#define	HSV_2()	\
	RGB (	\
		(BYTE) (coef3 >> int_extend),	\
		(BYTE) (val >> int_extend),	\
		(BYTE) (coef1 >> int_extend))

#define	HSV_HUE_ADV_2()		HSV_HUE_ADV_0()


#define	HSV_3()	\
	RGB (	\
		(BYTE) (val >> int_extend),	\
		(BYTE) (coef2 >> int_extend),	\
		(BYTE) (coef1 >> int_extend))

#define	HSV_HUE_ADV_3()		HSV_HUE_ADV_1()


#define	HSV_4()	\
	RGB (	\
		(BYTE) (val >> int_extend),	\
		(BYTE) (coef1 >> int_extend),	\
		(BYTE) (coef3 >> int_extend))

#define	HSV_HUE_ADV_4()		HSV_HUE_ADV_0()


#define	HSV_5()	\
	RGB (	\
		(BYTE) (coef2 >> int_extend),	\
		(BYTE) (coef1 >> int_extend),	\
		(BYTE) (val >> int_extend))

#define	HSV_HUE_ADV_5()		HSV_HUE_ADV_1()



// initialize for HSV colorspace in SAT mode, for HUE between 0 and 1 (0 and 60 deg)
#define	HSV_SAT_INIT_0()	\
	coef3 = coef1,	\
	coef3_adv = (int) ((val - coef3) / HSV_LOOP_STEPS (j))

// advance for HSV colorspace in SAT mode, for HUE between 0 and 1 (0 and 60 deg)
#define	HSV_SAT_ADV_0()	\
	coef3 += coef3_adv


#define	HSV_SAT_INIT_1()	\
	coef2 = val,	\
	coef2_adv = (int) ((val * (1.0 - sat) - coef2) / HSV_LOOP_STEPS (j))

#define	HSV_SAT_ADV_1()	\
	coef2 += coef2_adv


#define	HSV_SAT_INIT_2()	HSV_SAT_INIT_0()
#define	HSV_SAT_ADV_2()		HSV_SAT_ADV_0()

#define	HSV_SAT_INIT_3()	HSV_SAT_INIT_1()
#define	HSV_SAT_ADV_3()		HSV_SAT_ADV_1()

#define	HSV_SAT_INIT_4()	HSV_SAT_INIT_0()
#define	HSV_SAT_ADV_4()		HSV_SAT_ADV_0()

#define	HSV_SAT_INIT_5()	HSV_SAT_INIT_1()
#define	HSV_SAT_ADV_5()		HSV_SAT_ADV_1()



// for HSV colorspace, VAL mode is calculate in a same manner as SAT mode
//	so all macroses simply maps over SAT mode macroses
#define	HSV_VAL_INIT_0()	HSV_SAT_INIT_0()
#define	HSV_VAL_ADV_0()		HSV_SAT_ADV_0()

#define	HSV_VAL_INIT_1()	HSV_SAT_INIT_1()
#define	HSV_VAL_ADV_1()		HSV_SAT_ADV_1()

#define	HSV_VAL_INIT_2()	HSV_SAT_INIT_2()
#define	HSV_VAL_ADV_2()		HSV_SAT_ADV_2()

#define	HSV_VAL_INIT_3()	HSV_SAT_INIT_3()
#define	HSV_VAL_ADV_3()		HSV_SAT_ADV_3()

#define	HSV_VAL_INIT_4()	HSV_SAT_INIT_4()
#define	HSV_VAL_ADV_4()		HSV_SAT_ADV_4()


#endif	// _hsv_macroses_h
