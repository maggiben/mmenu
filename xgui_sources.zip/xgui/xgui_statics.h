// xgui 0.0.2 / 2002-03-31
//	xgui_statics.h
//
//	http://606u.dir.bg/
//	606u@dir.bg

#ifndef	_xgui_statics_h
#define	_xgui_statics_h

#include "math.h"

namespace xgui {


namespace panel {

	// draw_panel flags bit mask
	enum flags
	{
		raised = 1,
		sunken = 2,
		blackbox = 4
	};

	void
	draw (
		IN HDC hdc,
		IN int left,
		IN int top,
		IN int right,
		IN int bottom,
		IN int flags);

	inline void
	draw (
		IN HDC hdc,
		IN LPRECT rc,
		IN int flags)
	{
		draw (hdc, rc->left, rc->top, rc->right, rc->bottom, flags);
	};

} // panel namespace


namespace triangle {

	enum types
	{
		left = 1,
		top = 2,
		right = 3,
		bottom = 4,
		left_top = 5,
		left_bottom = 6,
		right_top = 7,
		right_bottom = 8
	};

	void
	draw (
		IN HDC hdc,
		IN int x,
		IN int y,
		IN enum types type,
		IN int size,
		IN COLORREF line_color,
		IN COLORREF fill_color);

} // triangle namespace


namespace convert {

	int
	hsv2rgb (
		IN double hue,
		IN double sat,
		IN double value,
		OUT double *red,
		OUT double *green,
		OUT double *blue);

	int
	rgb2hsv (
		IN double red,
		IN double green,
		IN double blue,
		OUT double *hue,
		OUT double *sat,
		OUT double *value);

	inline COLORREF
	hsv2rgb (
		IN double hue,
		IN double sat,
		IN double value)
	{
		double	red, green, blue;

		// ceil (a - 0.5) = round (a) = floor (a + 0.5)
		if (hsv2rgb (hue, sat, value, &red, &green, &blue) == 0)
			return (RGB (
				ceil (red * 255 - 0.5),
				ceil (green * 255 - 0.5),
				ceil (blue * 255 - 0.5)));
		return (RGB (0, 0, 0));
	};

} // convert namespace


namespace blend {

	void
	rgb (
		OUT DWORD *buffer,
		IN int samples,
		IN COLORREF start,
		IN COLORREF end);

	void
	hsv_hue (
		OUT DWORD *buffer,
		IN int samples,
		IN double sat,
		IN double val);

	void
	hsv_sat (
		OUT DWORD *buffer,
		IN int samples,
		IN double hue,
		IN double val);

	void
	hsv_val (
		OUT DWORD *buffer,
		IN int samples,
		IN double hue,
		IN double sat);

} // blend namespace


/** 
 * Number of bits to extend with when using integer math
 * instead of floating-point math.
 */
const int	int_extend = 20;


namespace mem {

	inline void
	set (
		OUT unsigned long *buffer,
		IN unsigned long value,
		IN size_t count)
	{
		while (count--)
			*buffer++ = value;
	};


	inline void
	set (
		OUT unsigned long **buffer,
		IN unsigned long value,
		IN size_t count)
	{
		unsigned long	*p = *buffer;
		
		while (count--)
			*p++ = value;
		*buffer = p;
	};


	inline void
	copy (
		OUT unsigned long *target,
		IN const unsigned long *source,
		size_t count)
	{
		while (count--)
			*target++ = *source++;
	};


	inline void
	copy (
		OUT unsigned long **target,
		IN const unsigned long *source,
		IN size_t count)
	{
		unsigned long	*p = *target;

		while (count--)
			*p++ = *source++;
		*target = p;
	};


	inline void
	copy_reverse (
		OUT unsigned long *target,
		IN const unsigned long *source,
		IN size_t count)
	{
		source += (count - 1);
		while (count--)
			*target++ = *source--;
	};


	inline void
	reverse (
		IN OUT unsigned long *buffer,
		IN size_t count)
	{
		unsigned long	*p = buffer + count - 1;

		while (buffer < p)
		{
			*buffer ^= *p;
			*p ^= *buffer;
			*buffer++ ^= *p--;
		}
	};

} // mem namespace


inline int scaled_red (COLORREF c)
{
	return (GetRValue (c) << int_extend);
}


inline int scaled_green (COLORREF c)
{
	return (GetGValue (c) << int_extend);
}


inline int scaled_blue (COLORREF c)
{
	return (GetBValue (c) << int_extend);
}


namespace wndclass {

	bool reg (
		IN const char *class_name,
		IN WNDCLASS *window_class,
		IN ATOM *class_atom);

	bool unreg (
		IN HINSTANCE library_instance,
		IN const char *class_name);

};


} // xgui namespace

#endif	// _xgui_statics_h
