// xgui 0.0.2 / 2002-03-31
//	main.cpp
//
//	http://606u.dir.bg/
//	606u@dir.bg

#include "_p.h"

#include "xgui.h"
#include "slider.h"
#include "picker.h"
#include "well.h"
#include "controller.h"



/* initialized flag */
static bool	xgui_initialized = false;

/* total number of processed attached */
static int	attached_processes = 0;



BOOL APIENTRY
DllMain (
	IN HANDLE module_handle,
	IN DWORD reason_for_call,
	IN LPVOID /* reserved */)
{
	switch (reason_for_call)
	{
	case	DLL_PROCESS_ATTACH:
		xgui::debug_message ("DllMain: process attached.");
		if (!xgui_initialized)
		{
			/* register window class(es) */
			if (!xgui::well::register_class ((HINSTANCE) module_handle) ||
				!xgui::slider::register_class ((HINSTANCE) module_handle) ||
				!xgui::picker::register_class ((HINSTANCE) module_handle) ||
				!xgui::controller::register_class ((HINSTANCE) module_handle))
			{
				xgui::well::unregister_class ((HINSTANCE) module_handle);
				xgui::slider::unregister_class ((HINSTANCE) module_handle);
				xgui::picker::unregister_class ((HINSTANCE) module_handle);
				xgui::controller::unregister_class ((HINSTANCE) module_handle);
				xgui::debug_message ("DllMain: register_class failed; aborting.");
				return (FALSE);
			}
			xgui::debug_message ("DllMain: classes registered.");
			xgui_initialized = true;
		}
		attached_processes++;
		break;

	case	DLL_PROCESS_DETACH:
		xgui::debug_message ("DllMain: process detached.");
		attached_processes--;
		if (attached_processes == 0)
		{
			/* unregister window class(es) */
			xgui::well::unregister_class ((HINSTANCE) module_handle);
			xgui::slider::unregister_class ((HINSTANCE) module_handle);
			xgui::picker::unregister_class ((HINSTANCE) module_handle);
			xgui::controller::unregister_class ((HINSTANCE) module_handle);
			xgui::debug_message ("DllMain: classes unregistered.");
		}
		break;
	}
    return (TRUE);
}


BOOL
xgui_initialize (void)
{
	xgui::debug_message ("xgui_initialize: done.");
	return (TRUE);
}
