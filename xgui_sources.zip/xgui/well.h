// xgui 0.0.2 / 2002-03-31
//	well.h
//
//	http://606u.dir.bg/
//	606u@dir.bg

#ifndef	_well_h
#define	_well_h

#include "base.h"
#include "xgui.h"


namespace xgui {

class	well : public base
{
public:
	well (void);
	virtual	~well ();

	// register and unregister class methods
	static bool register_class (
		IN HINSTANCE library_instance);

	static bool unregister_class (
		IN HINSTANCE library_instance);

	// user interaction methods
	void mouse_move (
		IN short /* x */,
		IN short /* y */,
		IN int /* modifiers */) {};

	void mouse_left_down (
		IN short /* x */,
		IN short /* y */,
		IN int /* modifiers */) {};

	void mouse_left_up (
		IN short /* x */,
		IN short /* y */,
		IN int /* modifiers */) {};

	void mouse_wheel (
		IN short /* delta */) {};

	void key_down (
		IN int /* key_code */,
		IN int /* modifiers */) {};

	// painting methods
	void paint (
		IN LPPAINTSTRUCT pnt);

	// called, when window size has changed
	bool size_changed (
		IN int hsize,
		IN int vsize);

	// control messages
	LRESULT	control_message (
		IN enum control_codes message,
		IN WPARAM wparam,
		IN LPARAM lparam);

private:
	COLORREF	color;

public:
	virtual const char *window_class_name (void) { return (class_name); };

	// registered window class information
	static const char	*class_name;
	static WNDCLASS		window_class;
	static ATOM			class_atom;
};

} // xgui namespace


#endif	// _well_h
