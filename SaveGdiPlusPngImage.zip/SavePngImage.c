#define WIN32_LEAN_AND_MEAN  /* speed up compilations */
#include <windows.h>
#include <GdiPlus.h>
#include <stdio.h>

// The function calls GetImageEncoders to get an array of 
// IMAGECODECINFO objects. If one of the IMAGECODECINFO
// objects in that array represents the requested encoder, 
// the function returns the index of the IMAGECODECINFO 
// object and copies the CLSID into the variable pointed 
// to by pClsid. If the function fails, it returns �1. 

int GetEncoderClsid(const WCHAR * format, CLSID * pClsid)
{
	UINT num = 0;	// number of image encoders
	UINT size = 0;	// size of the image encoder array in bytes

	IMAGECODECINFO *pImageCodecInfo = NULL;

	GdipGetImageEncodersSize(&num, &size);
	if (size == 0)
		return -1;	// Failure

	pImageCodecInfo = malloc(size);
	if (pImageCodecInfo == NULL)
		return -1;	// Failure

	GdipGetImageEncoders(num, size, pImageCodecInfo);

	for (UINT j = 0; j < num; ++j)
	{
		if (wcscmp(pImageCodecInfo[j].MimeType, format) == 0)
		{
			*pClsid = pImageCodecInfo[j].Clsid;
			free(pImageCodecInfo);
			return j;	// Success
		}
	}

	free(pImageCodecInfo);
	return -1;	// Failure
}

int __cdecl main(void)
{
	// Initialize GDI+.
	ULONG_PTR gdiplusToken;
	GdiplusStartup(&gdiplusToken, &g_GdiplusStartupInput, NULL);

	CLSID encoderClsid;
	GpStatus stat;
	GP_IMAGE image = GpImage_FromFile(L"Ball.bmp", FALSE);
	if (image.lastResult != eOk)
	{
		printf("Could not load Bird.bmp\n");
		return 0;
	}

	// Get the CLSID of the PNG encoder.
	GetEncoderClsid(L"image/png", &encoderClsid);

	stat = GpImage_SaveFile(&image, L"Ball.png", &encoderClsid, NULL);

	if (stat == 0)
		printf("Ball.png was saved successfully\n");
	else
		printf("Failure: stat = %d\n", stat);

	GpImage_Delete(&image);
	GdiplusShutdown(gdiplusToken);
	return 0;
}
