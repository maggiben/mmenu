/*
    icotest - demonstration of IconDesign icon file management library
    Copyright (C) 2002 Ross Kendall Axe
*/



#include <stdio.h>
#include <stdlib.h>

#include "iconfile.h"



int main(int argc, char *argv[])
{
	icon_file icf;

	printf("Icotest (C) 2002 Ross Axe\n"
		"The program is protected by the GNU General Public Licence\n"
		"See http://www.gnu.org/\n");

	/*initialize the variable 'file' to reasonable values
	otherwise when open_icon tries to close it and free
	all associated resources prior to reopening, all hell
	will probably break loose (i.e. instant gpf)*/
	init_file(&icf, 0);	//the restype parameter is immaterial since that will be set when the file is opened

	/*read contents of file into memory*/
	if(argc<2) fprintf(stderr, "No file on command line\n");
	if(open_icon(&icf, argv[1]) != 0) {
		fprintf(stderr, "Could not open %s\n", argv[1]);
		return EXIT_FAILURE;
	}

	/*and dump them in human readable form to stdout*/
	dump_icon(&icf, stdout);
	/*see source of dump_icon for examples on how to
	access the data stored in 'file'*/

	/*close 'open' file to reclaim the memory used and reinitialise
	the 'file' vairable (nb. the file on disk was closed as soon as
	the file was read into memory)*/
	new_file(&icf, 0);	//the restype parameter is once again immaterial

	return 0;
}
