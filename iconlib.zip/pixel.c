/*
    IconDesign icon file management library - handles Microsoft Windows icon files
    Copyright (C) 2002 Ross Axe
*/



#include "debug.h"

#include <stdlib.h>
#include <string.h>

#include "palette.h"
#include "pixel.h"

const pixel_s NULL_Pixel={0};



/******************************************\
*Function: alloc_pixel                     *
*Purpose:  allocates memory for pixel grid *
*Input:    width:  number of columns       *
*          height: number of rows          *
*Returns:  pointer to new pixel grid       *
*Remarks:  should be freed with free_pixel *
\******************************************/
pixel_s alloc_pixel(int width, int height)
{
	int col;
	pixel_s pixel;

	if(width>UCHAR_MAX || height>UCHAR_MAX) return NULL_Pixel;
	pixel.width = width;
	pixel.height = height;
	if(width == 0 || height == 0) return NULL_Pixel;
	pixel.pixel = malloc(width * sizeof *pixel.pixel);
	if(pixel.pixel == NULL) return NULL_Pixel;
	pixel.pixel[0] = malloc(height * width * sizeof **pixel.pixel);
	if(pixel.pixel[0] == NULL) {
		free(pixel.pixel);
		return NULL_Pixel;
	}
	for(col=1; col<width; col++)
		pixel.pixel[col] = pixel.pixel[col-1] + height;
	return pixel;
}



/******************************************\
*Function: memset_pixel                    *
*Purpose:  sets all pixels of given pixel  *
*          grid to the specified value     *
*Input:    pix: grid to set                *
*          clr: new colour index to set to *
*Returns:  value of pix                    *
\******************************************/
pixel_s memset_pixel(pixel_s pix, pixel_t clr)
{
	int x,y;

	for(x=0; x<pix.width; x++)
		for(y=0; y<pix.height; y++)
			pix.pixel[x][y] = clr;

	return pix;
}



/************************************************\
*Function: free_pixel                            *
*Purpose:  frees memory allocated by alloc_pixel *
*Input:    pointer to pixel grid to free         *
*Returns:  none                                  *
\************************************************/
void free_pixel(pixel_s pixel)
{
	if(pixel.pixel == NULL) return;
	free(pixel.pixel[0]);
	free(pixel.pixel);
}



/*******************************************************\
*Function: dup_pixel                                    *
*Purpose:  creates a duplicate of a given pixel area    *
*Input:    pix: pixels to duplicate                     *
*Returns:  duplicated pixels                            *
*Remarks:  return value should be freed with free_pixel *
\*******************************************************/
pixel_s dup_pixel(pixel_s pix)
{
	pixel_s newpix = alloc_pixel(pix.width, pix.height);
	if(newpix.pixel == NULL) return NULL_Pixel;
	memcpy(newpix.pixel[0], pix.pixel[0],
		newpix.width * newpix.height * sizeof **newpix.pixel);
	return newpix;
}



/*****************************************************\
*Function: colourcount2bpp                            *
*Purpose:  Converts a colour count value to a bpp     *
*          i.e. find out how many bits req'd to store *
*          colourcount-1                              *
*Input:    colourcount: colour count value to convert *
*Returns:  bpp                                        *
\*****************************************************/
unsigned int colourcount2bpp(unsigned int colourcount)
{
	unsigned int i;
	if(colourcount == 0) return 0;
	colourcount--;
	for(i=0; colourcount>0; i++, colourcount>>=1);
	return i;
}



/*******************************************\
*Function: bpp2colourcount                  *
*Purpose:  Converts a bpp to a colour count *
*Input:    bpp                              *
*Returns:  colour count value of bpp        *
\*******************************************/
unsigned int bpp2colourcount(unsigned int bpp)
{
	return 1<<bpp;
}
