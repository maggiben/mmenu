/*
    IconDesign icon file management library - handles Microsoft Windows icon files
    Copyright (C) 2002 Ross Axe
*/



typedef struct _masher_s {
	int height;
	int width;
	palette_colour **clr;
	bool **mask;
} masher_s;

/***************************************\
*Function: alloc_masher                 *
*Purpose:  Allocates an intermediate    *
*          masher structure for mashing *
*Input:    width:  width of grid        *
*          height: height of grid       *
*Returns:  Masher struct                *
\***************************************/
masher_s alloc_masher(const int width, const int height);

/*************************************************\
*Function: masher2icon                            *
*Purpose:  Takes information in a masher struct   *
*          and converts it into pixel information *
*Input:    masher: Masher struct to convert       *
*          icon:   Icon to convert into           *
*Returns:  icon or NULL if failed                 *
\*************************************************/
icon_s *masher2icon(masher_s masher, icon_s *icon);

/***************************************\
*Function: stretch_masher               *
*Purpose:  Stretches a masher structure *
*Input:    masher: masher to stretch    *
*          width:  new width            *
*          height: new height           *
*Returns:  Stretched masher             *
*Remarks:  Frees masher                 *
\***************************************/
masher_s stretch_masher(masher_s masher, int width, int height);

/****************************************\
*Function: mash                          *
*Purpose:  stretches, squishes, squashes *
*          etc.. one icon into another   *
*Input:    dest: destination icon        *
*          src:  source icon             *
*Returns:  none                          *
\****************************************/
void mash(icon_s *dest, icon_s *src);

