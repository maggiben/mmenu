/*
    IconDesign icon file management library - handles Microsoft Windows icon files
    Copyright (C) 2002 Ross Axe
*/



#include "debug.h"

#include "types.h"

#include "pixel.h"
#include "palette.h"

#ifndef __ID3_ICON_H__
#define __ID3_ICON_H__

typedef struct _hotspot {
	word_ x;
	word_ y;
} hotspot;

typedef struct _icon_header {
	byte_	Width;
	byte_	Height;
	byte_	ColourCount;
	byte_	Reserved;		//must be 0x00
	union {
		hotspot		hs;
		struct {
			word_	Planes;
			word_	BitCount;
		};
	};
	dword_	BytesInRes;
	dword_	Location;
} icon_header;	//RESDIR

typedef struct _bitmap_info_header {
	dword_	biSize;
	int32	biWidth;
	int32	biHeight;
	word_	biPlanes;
	word_	biBitCount;
	dword_	biCompression;
		#ifndef BI_RGB
		#define BI_RGB 0
		#endif
	dword_	biSizeImage;
	int32	biXPelsPerMeter;
	int32	biYPelsPerMeter;
	dword_	biClrUsed;
	dword_	biClrImportant;
} bitmap_info_header;

typedef struct _icon_s {
	icon_header			ih;
	bitmap_info_header	bmih;
	int					invalid;
	palette_s			palette;
	pixel_s				pixel;
	struct _icon_s		*next;
	struct _icon_s		*prev;
	int					index;			//index in tab control
} icon_s;

/* Explanation of icon struct
doubly linked circular list with of icon_s with nh.ResCount
elements and a dummy element, root_icon
	.ih			//RESDIR
		.Width			//width of icon = .pixel.width
		.Height			//height of icon = .pixel.height
		.ColourCount	//indicates no.of colours in icon
		.Reserved		//reserved, must be 0

		.ih.Planes		//no.of planes, generally 0
		.ih.BitCount	//bits per pixel of icon, generally 0
	*or*
		.hs.x			//hotspot x
		.hs.y			//hotspot y

		.BytesInRes		//size of bmih + palette + colour_dib + mask_dib
		.Location		//location within file
	.bmih		//BITMAPINFOHEADER
		.biSize				//size of bmih structure, always 0x00000028
		.biWidth			//same as .ih.Width
		.biHeight			//same as .ih.Height * 2
		.biPlanes			//0x0001 always
		.biBitCount			//bits per pixel of icon
		.biCompression		//0x0000 (BI_RGB) for uncompressed
		.biSizeImage		//may be set to 0x00000000, but generally isn't
		.biXPelsPerMeter	//generally 0x00000000
		.biYPelsPerMeter	//generally 0x00000000
		.biClrUsed			//generally 0x00000000
		.biClrImportant		//generally 0x00000000
	.invalid		//set to an error code if there was an error in loading
	.palette
		.palette[1<<.bpp]		//1d dyn array of palette_colour (=RGBQUAD)
			.rgbBlue
			.rgbGreen
			.rgbRed
			.rgbReserved = 0
		.bpp
	.pixel
		.pixel[.width][.height]	//2d dynamic array of pixels
		.width
		.height
*/


typedef struct _point_s {
	int x;
	int y;
} point_s;


#endif //__ID3_ICON_H__

#ifndef __ID3_UNDO_H__
#include "undo.h"
#endif

#define IH_COLOURCOUNT(ih) ((ih).ColourCount == 0 ? 256 : (ih).ColourCount)

#define IsRoot(icon) ((icon) == NULL || (icon)->index == -1)

#define for_all_icons(root, counter) for(counter=(root).next; !IsRoot(counter); (counter)=(counter)->next)

icon_s *findroot(icon_s *icon);

/************************************\
*Function: init_root_icon            *
*Purpose:  initialises the root icon *
*          to be an empty file       *
*Input:    root: pointer to root     *
*Returns:  none                      *
\************************************/
void init_root_icon(icon_s *root);

/************************************\
*Function: alloc icon                *
*Purpose:  Allocates and initialises *
*          an icon_s structure       *
*Input:    height:  height of icon   *
*          width:   width of icon    *
*          colours: colour depth     *
*Returns:  Pointer to new icon       *
\************************************/
icon_s *alloc_icon(int width, int height, int colours);
void free_icon(icon_s *icon);

/*****************************************************\
*Function: copy_icon                                  *
*Purpose:  copies icon1 into icon2, allocating memory *
*          for pixels, palette etc...                 *
*Input:    icon1: icon to copy into.  Must already    *
*                 point to valid allocated memory     *
*          icon2: icon to copy                        *
*Returns:  pointer to new copy of icon, i.e. icon1    *
\*****************************************************/
icon_s *copy_icon(icon_s *icon1, icon_s *icon2);

/*****************************************\
*Function: dup_icon                       *
*Purpose:  Creates a duplicate of an icon *
*Input:    icon: icon to duplicate        *
*Returns:  pointer to duplicate           *
*Remarks:  returned icon should be freed  *
*          with free_icon                 *
\*****************************************/
icon_s *dup_icon(icon_s *icon);

/******************************************************************\
*Function: count_icons                                             *
*Purpose:  given an icon in the loop, it counts how many there are *
*Input:    icon: Any icon in the loop, preferably the root         *
*Returns:  number of icons (excluding the root)                    *
\******************************************************************/
int count_icons(icon_s *icon);

/******************************************************************\
*Function: count_icons                                             *
*Purpose:  given an icon in the loop, it counts how many there are *
*Input:    icon: Any icon in the loop, preferably the root         *
*Returns:  number of icons (excluding the root)                    *
\******************************************************************/
point_s icons_max_size(icon_s *icon);

/************************************************\
*Function: replace_icon                          *
*Purpose:  Replaces one icon with another        *
*Input:    oldicon:   icon to replace            *
*          newicon:   icon to replace  with      *
*          root_undo: root_undo                  *
*Returns:  Icon selected in file or NULL if      *
*          failed                                *
*Remarks:  Neither oldicon or newicon should be  *
*          used afterwards since either or both  *
*          icons could be freed. Both icons      *
*          should have been allocated with       *
*          alloc_icon for this reason. The       *
*          return value can be safely assumed to *
*          point to an icon that is identical to *
*          newicon but in oldicon's position in  *
*          the list.                             *
\************************************************/
icon_s *replace_icon(icon_s *oldicon, icon_s *newicon, undo_s *root_undo, const char *name);

/**********************************************\
*Function: add_icon                            *
*Purpose:  inserts an icon into linked list    *
*Input:    icon:  icon to insert               *
*          after: icon to insert after         *
*Returns:  true if successful, false otherwise *
\**********************************************/
bool add_icon(icon_s *icon, icon_s *after);

/****************************************\
*Function: remove_icon                   *
*Purpose:  removes an icon fron the list *
*Input:    icon: icon to remove          *
*Returns:  icon just removed             *
\****************************************/
icon_s *remove_icon(icon_s *icon);

/************************************************\
*Function: delete_icon                           *
*Purpose:  Removes 'icon' from file              *
*          storing undo information in root_undo *
*          if root_undo is NULL, the icon        *
*          removed is freed                      *
*Input:    icon:      icon to remove             *
*          root_undo: where to store undo info   *
*          name:      name in undo menu          *
*Returns:  true if successful                    *
\************************************************/
bool delete_icon(icon_s *icon, undo_s *root_undo, char *name);

/**************************************************\
*Function: fix_headers                             *
*Purpose:  Fills in correct values for ih and bmih *
*Input:    icon: icon to calculate for             *
*Returns:  none                                    *
\**************************************************/
void fix_headers(icon_s *icon, bool cursor);

/*************************************************\
*Function: set_pixel                              *
*Purpose:  Sets the gixen pixel of the given icon *
*          storing undo information in root_undo  *
*          (if non NULL)                          *
*Input:    root_undo: where to store undo info    *
*          icon:      icon to change colour of    *
*          x, y:      pixel to set                *
*          newcolour: colour to set it to         *
*Returns:  true if successful                     *
\*************************************************/
bool set_pixel(icon_s *icon, int x, int y, pixel_t newcolour, undo_s *root_undo);

/*************************************************\
*Function: flood                                  *
*Purpose:  floods a given area of same colour     *
*Input:    icon:      Pointer to icon to flood    *
*          x, y:      co-ordinates of start pixel *
*          colour:    new colour                  *
*          diagonals: go down diagonals?          *
*Returns:  none                                   *
\*************************************************/
void flood(icon_s *icon, int x, int y, pixel_t colour, bool diagonals, undo_s *root_undo);

/*************************************************************\
*Function: replace_colours                                    *
*Purpose:  finds all occurrences of a given colour in a given *
*          icons and replaces them with a specified colour    *
*Input:    icon: Pointer to icon to search                    *
*          clr1: colour to search for                         *
*          clr2: new colour                                   *
*          root_undo:
*Returns:  none                                               *
\*************************************************************/;
void replace_colours(icon_s *icon, pixel_t clr1, pixel_t clr2, undo_s *root_undo);

/********************************************************\
*Function: translate                                     *
*Purpose:  translates the given icon by the given vector *
*Input:    icon:      icon to tranlate                   *
*          x, y:      vector to translate by             *
*          hotspot:   move hotspot?                      *
*          root_undo: where to store undo info or NULL   *
*Returns:  true if successful                            *
\********************************************************/
bool translate(icon_s *icon, int x, int y, bool hotspot, undo_s *root_undo);

/******************************************************\
*Function: reflect                                     *
*Purpose:  reflects the given icon in the given axis   *
*Input:    icon:      icon to reflect                  *
*          axis:      axis to reflect in               *
*          hotspot:   move hotspot?                    *
*          root_undo: where to store undo info or NULL *
*Returns:  true if successful                          *
\******************************************************/
bool reflect(icon_s *icon, int axis, bool hotspot, undo_s *root_undo);

#define AXIS_NS 1
#define AXIS_EW 2
#define AXIS_NWSE 3
#define AXIS_NESW 4

/*********************************************************\
*Function: rotate                                         *
*Purpose:  rotates the given icon through the given angle *
*Input:    icon:      icon to rotate                      *
*          angle:     angle to rotate in right angles     *
*          hotspot:   move hotspot?                       *
*          root_undo: where to store undo info or NULL    *
*Returns:  true if successful                             *
\*********************************************************/
bool rotate(icon_s *icon, int angle, bool hotspot, undo_s *root_undo);

