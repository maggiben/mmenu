/*
This file replaces <stdbool.h> for the lcc-win32 system
using int instead of _Bool.  Changing the 0 in the 1st
#if changes the behaviour back to the standard
*/



#if 0 && LCC
	#include <stdbool.h>
#else
	#ifdef __bool_true_false_are_defined
		#undef bool
	#else
		#define __bool_true_false_are_defined 1
		#define true 1
		#define false 0
	#endif
	#define bool int
#endif
