/*
    IconDesign icon file management library - handles Microsoft Windows icon files
    Copyright (C) 2002 Ross Axe
*/



#include "debug.h"

#ifndef __ID3_TYPES_H__
#define __ID3_TYPES_H__

typedef unsigned char byte_;	//should be 8 bits wide
typedef unsigned short word_;	//should be 16 bits wide
typedef unsigned long dword_;	//should be 32 bits wide
typedef long int32;

#define byte_sizeof(var) (sizeof(var) / sizeof(byte_))

#endif //__ID3_TYPES_H__
