/*
    IconDesign icon file management library - handles Microsoft Windows icon files
    Copyright (C) 2002 Ross Axe
*/



#include "debug.h"

#include <stdlib.h>

#include "icon.h"
#include "undo.h"
#include "mash.h"



const undo_s blank_undo = {0};



/*********************************************************\
*Function: alloc_undo                                     *
*Purpose:  allocates and blanks out an undo struct        *
*Input:    none                                           *
*Returns:  pointer to new struct                          *
*Remarks:  Returned struct should be freed with free_undo *
*          or NULL if failed                              *
\*********************************************************/
undo_s *alloc_undo(void)
{
	undo_s *new_undo = malloc(sizeof *new_undo);
	if(new_undo == NULL) return NULL;
	*new_undo = blank_undo;
	return new_undo;
}

void free_undo(undo_s *undo)
{
	/*if(undo->type & UNDO_PALETTE)
		free_palette(undo->data.palette);
	else*/
		free_icon(undo->icondata);
	free(undo);
}



/*********************************************************\
*Function: store_undo_palette                             *
*Purpose:  store info for undo command where only the     *
*          palette changes                                *
*Input:    root_undo: root undo structure                 *
*          palette:   palette that is about to be changed *
*          undo_type: type of undo                        *
*          name:      name of change (eg "change palette")*
*Returns:  true if OK to proceed with change              *
\*********************************************************/
/*bool store_undo_palette(undo_s *root_undo, palette_s palette, int undo_type, const char *name)
{
	undo_s *undo = alloc_undo();

	if(undo == NULL) {
		return false;
	} else {
		/*undo->type = undo_type | UNDO_PALETTE;
		undo->name = name;
		undo->next = root_undo->next;
		root_undo->next = undo;
		switch(undo_type) {
		case UNDO_EDIT:
			undo->data.palette = dup_palette(palette);
			undo->changed.palette = palette;
			break;

		default:
			return false;
		}
		return true;*/
/*		return false;
	}
}*/



/*********************************************************\
*Function: store_undo                                     *
*Purpose:  store info for undo command                    *
*Input:    root_undo: root undo structure                 *
*          icon:      icon that is about to be changed    *
*          undo_type: type of undo                        *
*          name:      name of change (draw, flood, etc..) *
*Returns:  true if OK to proceed with change              *
\*********************************************************/
bool store_undo(undo_s *root_undo, icon_s *icon, int undo_type, const char *name)
{
//	if((undo_type & UNDO_PALETTE) == 0) {
		undo_s *undo = alloc_undo();

		if(undo == NULL) {
			return false;
		} else {
			int i;

			undo->type = undo_type | UNDO_ICON;
			undo->name = name;
			switch(undo_type) {
			case UNDO_ADD:
				undo->icondata = NULL;
				undo->iconchanged = icon;
				break;

			case UNDO_EDIT:
				undo->icondata = dup_icon(icon);
				undo->iconchanged = icon;
				break;

			case UNDO_DELETE:
				undo->icondata = icon;
				undo->iconchanged = icon->prev;
				break;

			default:
				free_undo(undo);
				return false;
			}
			undo->next = root_undo->next;
			root_undo->next = undo;
			undo = root_undo;
			for(i=0; i<MAX_UNDO_BACKLOG; i++) {
				undo = undo->next;
				if(undo==NULL) break;
			}
			remove_undo(undo, 0);
			return true;
		}
	//} else
	//	return store_undo_palette(root_undo, icon->palette, undo_type & (~UNDO_PALETTE), name);


}



/************************************************\
*Function: remove_undo                           *
*Purpose:  removes the undo command(s)           *
*          pointed to by root_undo               *
*Input:    root_undo: root undo node             *
*          number:    number of nodes to remove, *
*                     or 0 to remove all         *
*Returns:  number of undo's removed              *
\************************************************/
int remove_undo(undo_s *root_undo, int number)
{
	int i;
	undo_s *undo, *next;

	if(root_undo==NULL) return 0;
	for(i=0, undo=root_undo->next; (number==0 || i<number) && undo!=NULL;
								i++, undo=next) {
		next = undo->next;
		free_undo(undo);
	}
	root_undo->next = next;
	return i;
}



/*****************************************\
*Function: undo                           *
*Purpose:  undo the last n actions        *
*Input:    hwnd: handle of main window    *
*          n:    number of action to undo *
*Returns:  icon changed or restored or    *
*          icon before or after removed   *
*          icon or NULL if undo did       *
*          nothing.  Intended as a        *
*          suggestion of which icon to    *
*          select after completing undo.  *
\*****************************************/
icon_s *undo(undo_s *root_undo, unsigned int n)
{
	unsigned int i;
	undo_s *undo;
	icon_s *before, *icon;

	icon = NULL;

	undo = root_undo;
	for(i=0; i<n; i++) {
		//undo = root_undo->next;
		undo = undo->next;
		if(undo == NULL) break;

		/*if(undo->type & UNDO_PALETTE) {
			switch(undo->type & (~UNDO_PALETTE)) {
			case UNDO_EDIT:
				icon = NULL;
				copy_palette(undo->changed.palette, undo->data.palette);
				break;
			}
		} else {*/
			switch(undo->type) {
			case UNDO_DELETE:
				before = undo->iconchanged;
				icon = undo->icondata;
				if(add_icon(icon, before))
					undo->icondata = NULL;	//this prevents the restored icon being free'd by free_undo;
				break;

			case UNDO_EDIT:
				before = undo->icondata;
				icon = undo->iconchanged;
				copy_icon(icon, before);
				break;

			case UNDO_ADD:
				before = undo->iconchanged;
				icon = IsRoot(before->next) ? before->prev : before->next;
				delete_icon(before, NULL, NULL);
				break;
			}
		//}

//		remove_undo(root_undo, 1);
	}
	remove_undo(root_undo, n);

	return icon;
}



/*************************************************\
*Function: set_pixel_undo                         *
*Purpose:  Sets the gixen pixel of the given icon *
*          storing undo information in root_undo  *
*Input:    root_undo: where to store undo info    *
*          icon:      icon to change colour of    *
*          x, y:      pixel to set                *
*          newcolour: colour to set it to         *
*Returns:  true if successful                     *
\*************************************************/
bool set_pixel_undo(undo_s *root_undo, icon_s *icon, int x, int y, pixel_t newcolour)
{
	if(!store_undo(root_undo, icon, UNDO_EDIT, "freehand draw"))
		return false;
	icon->pixel.pixel[x][y] = newcolour;
	return true;
}



/*******************************************************\
*Function: set_colour_undo                              *
*Purpose:  Sets colour 'index' of palette to newcolour, *
*          storing undo information in root_undo        *
*Input:    root_undo: where to store undo info          *
*          palette:   icon to change colour of          *
*          index:     index of colour to set            *
*          newcolour: new value to set it to            *
*Returns:  true if successful                           *
\*******************************************************/
bool set_colour_undo(undo_s *root_undo, icon_s *icon, int index, palette_colour newcolour)
{
	if(!store_undo(root_undo, icon, UNDO_EDIT, "change palette colour")) return false;
	icon->palette.palette[index] = newcolour;
	return true;
}



/************************************************\
*Function: add_icon_undo                         *
*Purpose:  adds 'icon' from file                 *
*          storing undo information in root_undo *
*Input:    root_undo: where to store undo info   *
*          icon:      icon to add                *
*          after:     icon to add after          *
*Returns:  true if successful                    *
\************************************************/
bool add_icon_undo(undo_s *root_undo, icon_s *icon, icon_s *after)
{
	if(!add_icon(icon, after)) return false;
	if(!store_undo(root_undo, icon, UNDO_ADD, "add")) {
		remove_icon(icon);
		return false;
	}
	return true;
}



/**********************************************\
*Function: replicate_undo                      *
*Purpose:  does a replicate, storing undo info *
*Input:    root_undo:                          *
*          src:                                *
*          dest:                               *
*          name: name on undo menu             *
*Returns:  true if successful                  *
\**********************************************/
bool replicate_undo(undo_s *root_undo, icon_s *dest, icon_s *src, char *name)
{
	if(!store_undo(root_undo, dest, UNDO_EDIT, name)) return false;
	//replicate(dest, src);
	mash(dest, src);
	return true;
}
