#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>

#include "iconfile.h"


int main(void)
{
	int width, height;
	int colourcount;
	char filename[FILENAME_MAX]="";
	icon_file icf;
	icon_s *icon;
	bool grey;
	pixel_t blackindex;
	const static palette_colour black = {0,0,0};

	printf("Icotest (C) 2002 Ross Axe\n"
		"The program is protected by the GNU General Public Licence\n"
		"See http://www.gnu.org/\n");

	init_file(&icf, IMAGE_ICON);	//initialise icf

	while(1) {
		/*get size of icon to create*/
		printf("type width of required icon ");
		scanf("%d", &width);
		printf("type height of required icon ");
		scanf("%d", &height);

		/*get palette info*/
		printf("type filename of palette or #n for n-colour grayscale ");
		fgets(filename, sizeof filename, stdin);	//flush \n from buffer
		fgets(filename, sizeof filename, stdin);
		strchr(filename, '\n')[0] = '\0';		//strip off "\n"
		grey = (filename[0]=='#');
		if(grey)
			colourcount = atoi(filename+1);
		else
			colourcount = 0;

		/*allocate and initialize icon*/
		icon = alloc_icon(width, height, colourcount);	//here, colourcount will be 0 for loaded palette so no palette will be created
		if(grey) {
			grey_palette(icon->palette);
		} else {
			icon->palette = load_palette(filename);
			if(icon->palette.colourcount==0) {
				printf("%s not found\n", filename);
				continue;
			}
		}
    	blackindex = nearest_colour(icon->palette, black);  //since we don't know what this palette is, we cannot assume black is at index 0, so we must search for black (or closest available)
    	memset_pixel(icon->pixel, GetXORMask(blackindex));  //set all pixels to transparent (or closest available)
		printf("%dx%d, %d colour icon created\n", icon->pixel.width, icon->pixel.height, icon->palette.colourcount);

		/*add icon to the end of the file*/
		add_icon(icon, icf.root_icon.prev);

		/*prompt to go round again*/
		printf("do you want to add another icon (y/n)? ");
		fgets(filename, sizeof filename, stdin);
		if(filename[0]=='n' || filename[0]=='N')
			break;
	}

	/*get filename to save to*/
	printf("Save file as: ");
	fgets(filename, sizeof filename, stdin);
	strchr(filename, '\n')[0] = '\0';		//strip off "\n"

	/*save and close*/
	if(save_icon(&icf, filename) == 0)
		printf("%s saved sucessfully\n", filename);
	else
		printf("Could not save %s\n", filename);
	new_file(&icf, 0);

	return 0;
}
