/*
    IconDesign icon file management library - handles Microsoft Windows icon files
    Copyright (C) 2002 Ross Axe
*/



#include "debug.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "types.h"
#include "errorcodes.h"
#include "iconfile.h"
#include "pack.h"

const new_header blank_icon_nh = {0, IMAGE_ICON, 0};
const resid_s NULL_resid = {0};



/*******************************************************\
*Function: alloc_resid                                  *
*Purpose:  Allocates a resource name                    *
*Input:    size:   Number of characters (excluding NUL) *
*                  wanted in name. 0 means numeric id   *
*          cursor: true for cursor, false for icon      *
*Returns:  New name                                     *
\*******************************************************/
resid_s alloc_resid(size_t size, bool cursor)
{
	resid_s rval;

	rval.cursor = cursor;
	if(rval.numeric = (size==0))
		rval.name = NULL;
	else {
		rval.name = malloc(size + 1);
		if(!rval.name) return NULL_resid;
	}

	return rval;
}



/********************************************************\
*Function: free_resid                                    *
*Purpose:  Frees a resid_s name allocated by alloc_resid *
*Input:    resid: resid_s to free                        *
\********************************************************/
void free_resid(resid_s resid)
{
	if(!resid.numeric) free(resid.name);
}



/**********************************************\
*Function: realloc_resid                       *
*Purpose:  Changes the size of a resid string  *
*Input:    resid:  resid to resize             *
*          size:   new size                    *
*          cursor: true for cursor             *
*Returns:  new resid (may differ from old one) *
\**********************************************/
resid_s realloc_resid(resid_s resid, size_t size, bool cursor)
{
	resid.cursor = cursor;
	if(size==0) {
		free_resid(resid);
		resid.numeric = true;
		resid.name = NULL;
	} else {
		resid.name = realloc(resid.numeric ? NULL : resid.name, size + 1);
		resid.numeric = false;
		if(!resid.name) return NULL_resid;
	}

	return resid;
}



/********************************************************\
*Function: dumpptr                                       *
*Purpose:  Dumps a given memory block to a text stream   *
*Input:    file: text stream to dump to                  *
*          ptr:  block to dump                           *
*          size: size of block in bytes                  *
*          cols: number of columns (in bytes) to wrap to *
*                0 means no wrapping                     *
\********************************************************/
void dumpptr(FILE *file, void *ptr, size_t size, size_t cols)
{
	int i;

	for(i = 0; i < size; i++)
		fprintf(file, "%c%.2x", ((cols!=0)&&(i%cols==0))?'\n':' ', ((unsigned char *)ptr)[i]);
}



/*******************************************\
*Function: dump_icon                        *
*Purpose:  dumps icon data to a text stream *
*Input:    icf:  pointer to icon to dump    *
*          file: open file stream to dump   *
*                into.  Must be open for    *
*                writing text               *
*Returns:  none                             *
\*******************************************/
void dump_icon(icon_file *icf, FILE *file)
{
	int i;
	icon_s *icon;
	int x, y;
	int blackindex;
	const palette_colour black = {0, 0, 0, 0};

	fputs("nh dump", file);
	dumpptr(file, &(icf->nh), sizeof icf->nh, 8);
	fprintf(file, "\nnh.Reserved = %d\nnh.ResType = %d\nnh.ResCount = %d\n", icf->nh.Reserved, icf->nh.ResType, icf->nh.ResCount);

	for_all_icons(icf->root_icon, icon) {
		fprintf(file, "\n\ndump of icons[%d].ih", icon->index);
		dumpptr(file, &icon->ih, sizeof icon->ih, 8);
		fprintf(file, "\n\nicons[%d].ih.Width = %d\n", icon->index, icon->ih.Width);
		fprintf(file, "icons[%d].ih.Height = %d\n", icon->index, icon->ih.Height);
		fprintf(file, "icons[%d].ih.ColourCount = %d\n", icon->index, icon->ih.ColourCount);
		fprintf(file, "icons[%d].ih.Reserved = %d\n", icon->index, icon->ih.Reserved);
		fprintf(file, "icons[%d].ih.hs.x = %d\n", icon->index, icon->ih.hs.x);
		fprintf(file, "icons[%d].ih.hs.y = %d\n", icon->index, icon->ih.hs.y);
		fprintf(file, "icons[%d].ih.BytesInRes = %d\n", icon->index, icon->ih.BytesInRes);
		fprintf(file, "icons[%d].ih.Location = %d\n", icon->index, icon->ih.Location);

		fprintf(file, "\ndump of icons[%d].bmih" ,icon->index);
		dumpptr(file, &icon->bmih, sizeof icon->bmih, 8);
		fprintf(file, "\n\nicons[%d].bmih.biSize = %d\n", icon->index, icon->bmih.biSize);
		fprintf(file, "icons[%d].bmih.biWidth = %d\n", icon->index, icon->bmih.biWidth);
		fprintf(file, "icons[%d].bmih.biHeight = %d\n", icon->index, icon->bmih.biHeight);
		fprintf(file, "icons[%d].bmih.biPlanes = %d\n", icon->index, icon->bmih.biPlanes);
		fprintf(file, "icons[%d].bmih.biBitCount = %d\n", icon->index, icon->bmih.biBitCount);
		fprintf(file, "icons[%d].bmih.biCompresssion = %d\n", icon->index, icon->bmih.biCompression);
		fprintf(file, "icons[%d].bmih.biSizeImage = %d\n", icon->index, icon->bmih.biSizeImage);
		fprintf(file, "icons[%d].bmih.biXPelsPerMeter = %d\n", icon->index, icon->bmih.biXPelsPerMeter);
		fprintf(file, "icons[%d].bmih.biYPelsPerMeter = %d\n", icon->index, icon->bmih.biYPelsPerMeter);
		fprintf(file, "icons[%d].bmih.biClrUsed = %d\n", icon->index, icon->bmih.biClrUsed);
		fprintf(file, "icons[%d].bmih.biClrImportant = %d\n", icon->index, icon->bmih.biClrImportant);

		fprintf(file, "\ndump of icons[%d].palette", icon->index);
		for(i = 0; i < icon->palette.colourcount; i++) {
			fprintf(file, "\nicons[%d].palette[%d]\t", icon->index, i);
			dumpptr(file, &(icon->palette.palette[i]), sizeof icon->palette.palette[i], 0);
			fprintf(file, "\tRGB = (%d, %d, %d)",
				icon->palette.palette[i].rgbRed,
				icon->palette.palette[i].rgbGreen,
				icon->palette.palette[i].rgbBlue);
		}

		blackindex = GetXORMask(nearest_colour(icon->palette, black));
		fprintf(file, "\n\ndump of icons[%d].pixel", icon->index);
		for(y = icon->ih.Height - 1; y >= 0; y--) {
			fputc('\n', file);
			for(x = 0; x < icon->ih.Width; x++) {
				if(IsXORMask(icon->pixel.pixel[x][y]))
					if(icon->pixel.pixel[x][y] = blackindex)
						fputs("   .", file);
					else
						fprintf(file, " ~%2x", GetXORMask(icon->pixel.pixel[x][y]));
				else
					fprintf(file, "  %2x", icon->pixel.pixel[x][y]);
			}
		}
	}
}



/*********************************************\
*Function: clean_up_file                      *
*Purpose:  clears up old icon_file data       *
*Input:    icf: pointer to structure to clear *
*Returns:  none                               *
\*********************************************/
void clean_up_file(icon_file *icf)
{
	icon_s *icon, *next;

	for(icon=icf->root_icon.next; !IsRoot(icon); icon=next) {
		next = icon->next;
		free_icon(icon);
	}
	remove_undo(&icf->root_undo, 0);
}



/**************************************************\
*Function: init_file                               *
*Purpose:  initialises icon_file                   *
*Input:    icf: pointer to structure to initialize *
*Returns:  none                                    *
\**************************************************/
void init_file(icon_file *icf, int restype)
{
	icf->filename[0] = '\0';
	icf->changed = false;
	icf->nh.ResType = restype;

	init_root_icon(&icf->root_icon);
	icf->root_undo = blank_undo;
}



/********************************************************\
*Function: new_file                                      *
*Purpose:  closes old file and creates a new, blank file *
*Input:    icf: file to close and new                    *
*Returns:  true if successful                            *
\********************************************************/
bool new_file(icon_file *icf, int restype)
{
	clean_up_file(icf);
	init_file(icf, restype);
	return true;
}



/**********************************************\
*Function: read_pixel                          *
*Purpose:  reads pixel data from given stream  *
*Input:    file:  binary stream to read from   *
*          pixel: pixel_s struct to write into *
*          bpp:   bpp of bitamp being read     *
*          mask:  true if reading transparency *
*Returns:  0 if successful or an error code    *
\**********************************************/
static int read_pixel(FILE *file, pixel_s pixel, int bpp, bool mask)
{
	int		dword_width;	//no of dwords per scan line
	dword_	*dib_bits;		//pointer to bits

	if(mask) bpp=1;
	dword_width = DWORDS_PER_LINE(pixel.width, bpp);
	if(pixel.height * dword_width == 0) {
		memset_pixel(pixel, 0);
		return 0;		//successfully read nothing
	}

	dib_bits = calloc(pixel.height, dword_width * sizeof *dib_bits);
	if(dib_bits == NULL)
		return MYERR_MEM;

	//read dib bits from disk
	if(fread(dib_bits, dword_width * sizeof *dib_bits, pixel.height, file)
			< pixel.height) {
		free(dib_bits);
		return MYERR_READ;
	}

	if(mask)
		unpackmask(dib_bits, pixel);
	else
		unpackbits(dib_bits, pixel, bpp);

	//clean up
	free(dib_bits);
	return 0;
}



/**********************************************\
*Function: write_pixel                         *
*Purpose:  writes pixel data to given stream   *
*Input:    file:  binary stream to write to    *
*          pixel: pixel_s struct to read from  *
*          bpp:   bpp of bitmap being read     *
*                 (ignored when mask == true)  *
*          mask:  true if writing transparency *
*Returns:  0 if successful or an error code    *
\**********************************************/
static int write_pixel(FILE *file, pixel_s pixel, int bpp, bool mask)
{
	int		dword_width;	//no of dwords per scan line
	dword_	*dib_bits;		//pointer to bits

	if(mask) bpp=1;
	dword_width = DWORDS_PER_LINE(pixel.width, bpp);

	if((pixel.height * dword_width * sizeof *dib_bits) == 0)
		return 0;	//successfully wrote nothing

	//alocate packed bits
	dib_bits = calloc(pixel.height, dword_width * sizeof *dib_bits);
	if(dib_bits == NULL)
		return MYERR_MEM;

	//pack bits
	if(mask)
		packmask(dib_bits, pixel);
	else
		packbits(dib_bits, pixel, bpp, NULL_Palette);

	//write dib bits to disk
	if(fwrite(dib_bits, dword_width * sizeof *dib_bits, pixel.height, file)
			< pixel.height) {
		free(dib_bits);
		return MYERR_WRITE;
	}

	//clean up
	free(dib_bits);

	return 0;
}



/*********************************************************\
*Function: read_icon                                      *
*Purpose:  reads a single icon from an open stream, based *
*          on an icon_header structure provided           *
*Input:    ih:   structure with read information          *
*          file: stream to read from                      *
*Returns:  new icon read in from file (possibly invalid)  *
*Remarks:  DOES NOT add the new icon to a loaded file.    *
*          Use add_icon for that. The returned icon       *
*          should be freed with free_icon                 *
\*********************************************************/
static icon_s *read_icon(icon_header *ih, FILE *file)
{
	icon_s *icon;
	int i;
	bitmap_info_header bmih;

	/*read bmih*/
	if(fseek(file, ih->Location, SEEK_SET)) goto err_read;
	if(fread(&bmih, sizeof bmih, 1, file) < 1) goto err_read;

	icon = alloc_icon(ih->Height, ih->Width,
		bpp2colourcount(bmih.biBitCount));
	if(icon == NULL) return NULL;

	icon->invalid = 0;
	icon->ih = *ih;		//copy ih info into new icon
	icon->bmih = bmih;	//copy newly read bmih into new icon

	/*read palette*/
	if(fread(icon->palette.palette, sizeof *icon->palette.palette,
			icon->palette.colourcount, file) < icon->palette.colourcount) {
		goto err_read;
	}

	/*validate bmih header*/
	if(icon->bmih.biSize != sizeof icon->bmih) icon->invalid = MYERR_BADBMIH;
	if(icon->bmih.biPlanes != 1) icon->invalid = MYERR_BADBMIH;
	if(icon->bmih.biCompression != BI_RGB) icon->invalid = MYERR_BADBMIH;

	/*compare bmih to ih for validation*/
	if(icon->palette.colourcount != bpp2colourcount(icon->bmih.biBitCount))
		icon->invalid = MYERR_BADBMIH;
	if(icon->bmih.biWidth != icon->ih.Width || icon->bmih.biHeight != icon->ih.Height * 2)
		icon->invalid = MYERR_BADBMIH;

	/*validate palette*/
	for(i=0; i<icon->palette.colourcount; i++) {
		if(icon->palette.palette[i].rgbReserved != 0) {
			icon->invalid = MYERR_BADPALETTE;
			break;
		}
	}


	switch(read_pixel(file, icon->pixel, icon->bmih.biBitCount, false)) {
	case 0:
		break;
	case MYERR_READ:
		goto err_read;
	case MYERR_MEM:
		goto err_mem;
	default:
		icon->invalid = MYERR_INVAL;
	}
	switch(read_pixel(file, icon->pixel, 1, true)) {
	case 0:
		break;
	case MYERR_READ:
		goto err_read;
	case MYERR_MEM:
		goto err_mem;
	default:
		icon->invalid = MYERR_INVAL;
	}

	return icon;

	err_read:
	icon->invalid = MYERR_READ;
	return icon;

	err_mem:
	icon->invalid = MYERR_MEM;
	return icon;
}



/*********************************************************\
*Function: write_icon                                     *
*Purpose:  writes a single icon to an open stream, based  *
*          on an icon structure provided                  *
*Input:    icon:   structure with read information        *
*          file: stream to read from                      *
*Returns:  0 or error code                                *
*Remarks:  DOES NOT add the new icon to a loaded file.    *
*          Use add_icon for that. The returned icon       *
*          should be freed with free_icon                 *
\*********************************************************/
static int write_icon(icon_s *icon, FILE *file)
{
	int rval;

	//get file pointer
	icon->ih.Location = ftell(file);
	if(icon->ih.Location == 1L) goto err_write;

	//write bmih header
	if(fwrite(&icon->bmih, icon->bmih.biSize, 1, file) < 1)
		goto err_write;

	//write palette
	if(fwrite(icon->palette.palette, sizeof *(icon->palette.palette), icon->palette.colourcount, file)
		< icon->palette.colourcount) goto err_write;

	rval = write_pixel(file, icon->pixel, icon->bmih.biBitCount, false);
	if(rval != 0) return rval;

	return write_pixel(file, icon->pixel, 1, true);

	err_write:
	return MYERR_WRITE;
}



/****************************************************************\
*Function: open_icon                                             *
*Purpose:  Erm, ah, it, well, opens a, well, an icon, I guess... *
*Input:    hwnd:      main window                                *
*          file_name: pointer to the file name                   *
*Returns:  0 if successful, an error code otherwise              *
*Remarks:  Hopefully C99 compliant                               *
\****************************************************************/
int open_icon(icon_file *icf, const char *file_name)
{
	FILE *file;
	int i;
	icon_s *icon;
	icon_header *new_ih = NULL;
	char exeheader[2];

	//open file
	if(strlen((char *)file_name) > MY_MAXFILE) goto err_open;
	file = fopen(file_name, "rb");
	if(file == NULL) goto err_open;

	/*check if file is an executable by looking for 'MZ' as the first 2 bytes*/
	fread(exeheader, sizeof exeheader[0], 2, file);
	if(exeheader[0]=='M' && exeheader[1]=='Z') {
		fclose(file);
		return MYERR_EXE;
	}
	fseek(file, 0, SEEK_SET);

	new_file(icf, 0);

	strcpy(icf->filename, file_name);

	//read and validate nh
	if(fread(&icf->nh, sizeof icf->nh, 1, file) < 1) goto err_read;
	if(icf->nh.Reserved != 0) goto err_inval;
	switch(icf->nh.ResType) {
	case IMAGE_ICON:
	case IMAGE_CURSOR:
		break;
	default:
		goto err_inval;
	}

	//read icon headers
	new_ih = malloc(icf->nh.ResCount * sizeof *new_ih);
	if(new_ih == NULL) goto err_mem;
	if(fread(new_ih, sizeof *new_ih, icf->nh.ResCount, file) < icf->nh.ResCount) {
		goto err_read;
	}

	//read icons
	for(i=0; i<icf->nh.ResCount; i++) {
		icon = read_icon(&new_ih[i], file);
		if(icon == NULL) break;
		if(!add_icon(icon, icf->root_icon.prev)) goto err_inval;
	}
	if(i < icf->nh.ResCount) goto err_mem;

	//close file and tidy up
	fclose(file);
	free(new_ih);
	return 0;

	//failures
	err_open:
	init_file(icf, IMAGE_ICON);
	return MYERR_FILEOPEN;

	err_read:
	fclose(file);
	free(new_ih);
	new_file(icf, IMAGE_ICON);
	return MYERR_READ;

	err_inval:
	fclose(file);
	free(new_ih);
	new_file(icf, IMAGE_ICON);
	return MYERR_INVAL;

	err_mem:
	fclose(file);
	free(new_ih);
	new_file(icf, IMAGE_ICON);
	return MYERR_MEM;
}



/**********************************************\
*Function: save_icon                           *
*Purpose:  saves an icon                       *
*Input:    icon:      icon_file structure      *
*          file_name: pointer to the file name *
*Returns:  0 if successful                     *
*Remarks:  ANSI C99 compliant (i hope...)      *
\**********************************************/
int save_icon(icon_file *icon_f, const char *file_name)
{
	FILE *file;
	icon_s *icon;

	//open file
	if(strlen((char *)file_name) > MY_MAXFILE) return MYERR_FILEOPEN;
	file = fopen(file_name, "wb");
	if(file == NULL) return MYERR_FILEOPEN;
	strcpy(icon_f->filename, file_name);

	icon_f->nh.Reserved = 0;
	icon_f->nh.ResCount = count_icons(&icon_f->root_icon);
	if(fwrite(&icon_f->nh, sizeof icon_f->nh, 1, file) < 1) goto err_write;

	//write icon headers
	for_all_icons(icon_f->root_icon, icon) {
		fix_headers(icon, icon_f->nh.ResType == IMAGE_CURSOR);
		if(fwrite(&(icon->ih), sizeof icon->ih, 1, file) < 1)
			goto err_write;
	}

	for_all_icons(icon_f->root_icon, icon) {
		switch(write_icon(icon, file)) {
		case MYERR_MEM:
			goto err_mem;
		case MYERR_WRITE:
			goto err_write;
		}
	}

	//rewind
	if(fseek(file, 0, SEEK_SET)) goto err_write;

	//rewrite nh
	if(fwrite(&icon_f->nh, sizeof icon_f->nh, 1, file) < 1) goto err_write;

	//rewrite icon headers
	for_all_icons(icon_f->root_icon, icon) {
		if(fwrite(&(icon->ih), sizeof icon->ih, 1, file) < 1)
			goto err_write;
	}

	fclose(file);
	icon_f->changed = false;

	return MYERR_SUCCESS;

	//failures
	err_write:
	fclose(file);
	return MYERR_WRITE;

	err_mem:
	fclose(file);
	return MYERR_MEM;
}

