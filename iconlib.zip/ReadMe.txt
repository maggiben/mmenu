Icondesign icon library

These file are copyright 2002 Ross Axe and are protected by the GNU General Public Licence.


Contents
	Overview
	Basic Steps for opening and saving a file
	Simple access and editing
	The undo mechanism





	Overview

These files are actually part of a larger program, IconDesign3, which is an icon editing application that I wrote.  As a result, this 'library' contains various bits n bobs that arn't really generally useful.  The undo.c module for example is clearly not really useful outside of an interactive editor, but is inextricably tied to the icon.c module, which is used for manipulating the individual images contained in the file.

The modules contained here are as follows:

icon.c:     Functions dealing with individual images in the icon
iconfile.c: Functions dealing with the whole file & disk I/O
mash.c:     Functions dealing with stretching/recolouring icons
pack.c:     Functions dealing with encoding/decoding the packed bitmaps
palette.c:  Functions dealing with the icons palettes
pixel.c:    Functions dealing with the actual pixels of the icon
undo.c:     A built-in undo mechanism

Also included are:
icotest.c:  Short demo program demonstrating how to open and dump an icon
newicon.c:  A demo program on creating and saving icon files
To compile these samples, link them with the 7 files above (but not with each other)
Note on compilation: These files are designed to be fairly portable, but if char != 8bits, short != 16bits and long != 32bits then you may need to edit types.h.  If integers of those sizes do not exist on your system, the program will not create valid icon files.  These files have been tested using lcc-win32, available at http://www.cs.virginia.edu/~lcc-win32/

The basic structures used are as follows (all struct's):
icon_file:   This contains file-level info; 1 of these needed for each opened icon file.  This should be initialised with init_file before being used.
icon_s:      One of these for each image in the icon.  open_icon creates a circular, doubley linked list of these.  In addition, there is one the is a member of icon_file and contains no image data but just functions as a root node. It is identified by having the index -1 (beware - the indices of the other icons are not maintained by the library - if you want to use them, you must maintain them, but -1 is reserved)
pixel_s:     A member of icon_s.  This is the height and width of the icon and a pixel_t** (where pixel_t is an integer type big enough to hold 0 to max_colours-1 and -max_colours to -1).  Positive values represent palette indices to be looked up in the icon's palette.  Negative values represent 'transparent' values, which should be converted to palette indices using the GetXORMask macro then the resulting RGB value XOR'd with the background colour to get the correct display colour.  Normally, transparancy is indicated by -1, wich maps to black (palette index 0) which when XOR'd with the background does not change it.
palette_s:   This contains the colour count of the icon and an array of colours for use when interpreting the values in the pixel_s struct.

Additionally, there are also new_header, hotspot, icon_header and bitmap_info_header structs which refer to the structure of the file on disk.

Also, we have:
resid_s:      A structure containing an EXE file resource identifier - useful when using the additional code that handles EXE files
masher_s:     An RGB equivalent of the pixel_s - used when stretching/recolouring etc...
undo_s:       Stores undo information in a linked list


	Basic steps for opening and saving a file

1)  Allocate an icon_file struct (on the stack, or however you like)
2)  Initialize it with init_file (you can just use)
3)  Call open_icon to open the file (note that the disk file is actually closed on exiting open_icon - all the data is in memory)
4)  Do any editing
5)  Call save_icon
6)  Call new_icon to close it

To create a new icon
1)  Allocate an icon_file struct (on the stack, or however you like)
2)  Initialize it with init_file (you can just use)
3)  Call new_icon.  Now we have a file with no images in
4)  Create and add some images and do any editing
5)  Call save_icon
6)  Call new_icon to close it

	Simple access and editing

The icons are stored in a linked list, so to access them, use something like:
icf.root_icon.next
to access the first icon, where icf is an icon_file struct (this will be a pointer to an icon_s struct).  Then use the next member of this icon the get the second etc... until you get back to the root icon (with index -1; test for this with the IsRoot macro).
Alternatively, you can use for_all_icon, a macro defined in icon.h.  Use icf.root_icon as the first parameter and a icon_s* as the second. e.g.

icon_s *icon;
.
.
.
for_all_icons(icf.root_icon, icon) {
	//stuff here - use the icon variable to access the data
}

To access the image data, use the icon_s structure.  For example:   (icon as an icon_s* as above)
icon->pixel.pixel[x][y]
icon->palette.palette[c]

The get the RGB value of a non-transparent point, use
icon->palette.palette[icon->pixel.pixel[x][y]]

For transparent points use
icon->palette.palette[GetXORMask(icon->pixel.pixel[x][y])]
and XOR with the background colour

To determine whether it is transparent or not, use
IsXORMask(icon->pixel.pixel[x][y])


To change the pixels, just assign to them, e.g.
icon->pixel.pixel[x][y]=0
This changes pixel (x,y) to black (assuming icon->pixel.pixel[0] is RGB(0,0,0))
Same for the palette, just assign to it (bear in mind that this recolours all the pixels with that index).
You may also use set_pixel if undo information is required (you should only use it for the first pixel of a series if a large number are changed, e.g. during a freehand draw by the user)

Some other functions are also provided for image manipulation, they are:
flood
replace_colours
translate
reflect
rotate
They are documented in the header file icon.h.  Just use NULL for root_undo.  See later for undo usage

To make one icon look similar to another (creating a 16x16 version of a 32x32 icon for eample), the function 'mash' does what you want


Adding and deleting icons are achieved with the add_icon and remove_icon (note that these are not compatible with the undo module and undo's should not be attempted after these are used.  To use undo information use add_icon_undo and delete_icon - more on undo later)
To create the icon to add to the file, use alloc_icon.  When removing an icon with remove_icon, you should free the removed icon with free_icon (this should NOT be done if you are using delete_icon).

When allocating an icon, the palette and pixels will be uninitialised, so it will look very pretty indeed.  To initialise the pixels, use memset_pixel.  The palette is harder since it would be good for it to contain sensible coulours, rather than just all black.  One way is to use grey_palette to initialise the palette to grey.  Another way would be to allocate the icon with no palette (set colourcount to 0) and then load a palette from disk using load_palette and assigning the returned palette the the icon's palette member.  A sample palette file is included.
Examples:

{
    icon_s *icon;

    icon = alloc_icon(32, 32, 2);              //allocate 32x32 monochrome
    if(icon==NULL) return;
    grey_palette(icon->palette);               //set palette to black/white
    memset_pixel(icon->pixel, GetXORMask(0));  //set all pixels to transparent
    /*btw, we know that palette index 0 here is black, since grey_palette always does that*/
    /*now we have a new 32x32 monochrome (blakc and white) icon*/
}

Example 2:

{
    icon_s *icon;
    static const palette_colour black = {0,0,0};
    pixel_t blackindex;

    icon = alloc_icon(32, 32, 0);              //allocate 32x32 without palette
    if(icon==NULL) return;
    icon->palette = load_palette("16colour.idp");  //load palette from disk
    if(icon->palette.palette == NULL) {
        free_icon(icon);
        return;
    }
    blackindex = nearest_colour(icon->palette, black);  //since we don't know what this palette is, we cannot assume black is at index 0, so we must search for black (or closest available)
    memset_pixel(icon->pixel, GetXORMask(blackindex));  //set all pixels to transparent (or closest available)
    /*now we have a 32x32 icon with the palette loaded from disk*/
    /*note that the colour depth is determined by the disk file*/
}



	The undo mechanism

Since these file were designed as the backend of an icon editing program, they incorporate an undo feature.  To use this, simply pass the root_undo member of the icon_file structure to all of the editing functions, ESPECIALLY add_icon_undo and delete_icon.  Failute to do so will crash your program when trying to undo beyond that point.  Also, when setting a number of pixels that should be undone in one operation, use set_pixel for the first one and just assign the rest.  Also, set_colour_undo should be used for changing the palette.
To perform an undo operation, just call the undo function (usually with n set to 1).  If you cannot undo any further, the return value will be less than n (usually 0).  icf.root_undo.next will be NULL if the undo stack is empty.
When not using undo, just pass NULL as the root_undo parameter, except add_icon_undo and delete_icon, use add_icon and remove_icon (followed by free_icon instead)


Simple eh?


Thats all folks!


Ross Axe 13/2/202

note:  some example code snippets above are untested
also, the library may contain several redundant/obsolete functions.  Ignore them.

Since this is GPL stuff, you may copy/redistribute as you want.  However, the interface is in places a little poorly designed (issues like namespaces spring to mind) so it may be wise to wait till such time as a proper library is available.  At such time, the library will probably be released as a DLL and the new interface, although similar, will be incompatible.