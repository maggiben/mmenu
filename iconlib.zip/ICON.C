/*
    IconDesign icon file management library - handles Microsoft Windows icon files
    Copyright (C) 2002 Ross Axe
*/



#include "debug.h"

#include <stdlib.h>
#include <math.h>

#include "errorcodes.h"
#include "icon.h"
#include "pack.h"


const icon_s zero_icon = {0};

#define IsBetween(x, a, b) (((x)>=(a)) && ((x)<=(b)))	//test if x is between a & b, INCLUSIVE (a >= b)


typedef struct _rgb_int {
	int rgbRed;
	int rgbGreen;
	int rgbBlue;
} rgb_int;



icon_s *findroot(icon_s *icon)
{
	while(!IsRoot(icon)) icon = icon->next;
	return icon;
}



/************************************\
*Function: init_root_icon            *
*Purpose:  initialises the root icon *
*          to be an empty file       *
*Input:    root: pointer to root     *
*Returns:  none                      *
\************************************/
void init_root_icon(icon_s *root)
{
	root->ih.Width = 32;
	root->ih.Height = 32;
	root->ih.ColourCount = 16;
	root->ih.Reserved = 0;
	root->ih.hs.x = 0;
	root->ih.hs.y = 0;
	root->ih.BytesInRes = 0;
	root->ih.Location = 0;

	root->bmih.biSize = sizeof root->bmih;
	root->bmih.biWidth = 32;
	root->bmih.biHeight = 64;
	root->bmih.biPlanes = 1;
	root->bmih.biBitCount = 4;
	root->bmih.biCompression = BI_RGB;
	root->bmih.biSizeImage = 0;
	root->bmih.biXPelsPerMeter = 0;
	root->bmih.biYPelsPerMeter = 0;
	root->bmih.biClrUsed = 0;
	root->bmih.biClrImportant = 0;

	root->invalid = MYERR_ROOT;
	root->palette = NULL_Palette;
	root->pixel = NULL_Pixel;
	root->next = root;
	root->prev = root;
	root->index = -1;
}



/************************************\
*Function: alloc icon                *
*Purpose:  Allocates and initialises *
*          a new icon_s structure    *
*Input:    height:  height of icon   *
*          width:   width of icon    *
*          colours: colour depth     *
*Returns:  Pointer to new icon       *
\************************************/
icon_s *alloc_icon(int width, int height, int colours)
{
	icon_s *icon = malloc(sizeof *icon);

	if(icon == NULL) return NULL;
	*icon = zero_icon;
	icon->pixel = alloc_pixel(width, height);
	if(icon->pixel.height < height || icon->pixel.width < width) {
		free(icon);
		return NULL;
	}
	icon->palette = alloc_palette(colours);
	if(icon->palette.colourcount < colours) {
		free_pixel(icon->pixel);
		free(icon);
		return NULL;
	}
	return icon;
}



/**************************************************\
*Function: free_icon                               *
*Purpose:  Frees an icon allocated with alloc_icon *
*Input:    icon: pointer to icon to free           *
*Returns:  none                                    *
\**************************************************/
void free_icon(icon_s *icon)
{
	if(icon == NULL) return;
	free_pixel(icon->pixel);
	free_palette(icon->palette);
	free(icon);
}



/*****************************************************\
*Function: copy_icon                                  *
*Purpose:  copies icon1 into icon2, allocating memory *
*          for pixels, palette etc...                 *
*Input:    icon1: icon to copy into.  Must already    *
*                 point to valid allocated memory     *
*          icon2: icon to copy                        *
*Returns:  pointer to new copy of icon, i.e. icon1    *
\*****************************************************/
icon_s *copy_icon(icon_s *icon1, icon_s *icon2)
{
	free_pixel(icon1->pixel);
	free_palette(icon1->palette);
	*icon1=*icon2;
	icon1->palette = dup_palette(icon2->palette);
	icon1->pixel = dup_pixel(icon2->pixel);
	return icon1;
}



/*****************************************\
*Function: dup_icon                       *
*Purpose:  Creates a duplicate of an icon *
*Input:    icon: icon to duplicate        *
*Returns:  pointer to duplicate           *
*Remarks:  returned icon should be freed  *
*          with free_icon                 *
\*****************************************/
icon_s *dup_icon(icon_s *icon)
{
	icon_s *new_icon = alloc_icon(0, 0, 0);
	if(new_icon == NULL) return NULL;
	return copy_icon(new_icon, icon);
}



/******************************************************************\
*Function: count_icons                                             *
*Purpose:  given an icon in the loop, it counts how many there are *
*Input:    icon: Any icon in the loop, preferably the root         *
*Returns:  number of icons (excluding the root)                    *
\******************************************************************/
int count_icons(icon_s *icon)
{
	int i;
	i=0;
	for(icon=findroot(icon)->next; !IsRoot(icon); icon=icon->next)
		i++;

	return i;
}



/******************************************************************\
*Function: count_icons                                             *
*Purpose:  given an icon in the loop, it counts how many there are *
*Input:    icon: Any icon in the loop, preferably the root         *
*Returns:  number of icons (excluding the root)                    *
\******************************************************************/
point_s icons_max_size(icon_s *icon)
{
	point_s pt = {0,0};

	for_all_icons(*findroot(icon), icon) {
		if(pt.x<icon->pixel.width) pt.x=icon->pixel.width;
		if(pt.y<icon->pixel.height) pt.y=icon->pixel.height;
	}

	return pt;
}



/************************************************\
*Function: replace_icon                          *
*Purpose:  Replaces one icon with another        *
*Input:    oldicon:   icon to replace            *
*          newicon:   icon to replace  with      *
*          root_undo: root_undo                  *
*Returns:  Icon selected in file or NULL if      *
*          failed                                *
*Remarks:  Neither oldicon or newicon should be  *
*          used afterwards since either or both  *
*          icons could be freed. Both icons      *
*          should have been allocated with       *
*          alloc_icon for this reason. The       *
*          return value can be safely assumed to *
*          point to an icon that is identical to *
*          newicon but in oldicon's position in  *
*          the list.                             *
\************************************************/
icon_s *replace_icon(icon_s *oldicon, icon_s *newicon, undo_s *root_undo, const char *name)
{
	if(root_undo && !store_undo(root_undo, oldicon, UNDO_EDIT, name))
		return NULL;
	newicon->next = oldicon->next;
	newicon->prev = oldicon->prev;
	newicon->index = oldicon->index;
	*oldicon = *newicon;
	newicon->pixel = NULL_Pixel;
	newicon->palette = NULL_Palette;
	free_icon(newicon);

	return oldicon;
}



/**********************************************\
*Function: add_icon                            *
*Purpose:  inserts an icon into linked list    *
*Input:    icon:  icon to insert               *
*          after: icon to insert after         *
*Returns:  true if successful, false otherwise *
\**********************************************/
bool add_icon(icon_s *icon, icon_s *after)
{
	if(count_icons(after)+1 >= CHAR_MAX) return false;
	icon->next = after->next;
	icon->prev = after;
	icon->prev->next = icon;
	icon->next->prev = icon;
	return true;
}



/****************************************\
*Function: remove_icon                   *
*Purpose:  removes an icon fron the list *
*Input:    icon: icon to remove          *
*Returns:  icon just removed             *
\****************************************/
icon_s *remove_icon(icon_s *icon)
{
	if(IsRoot(icon)) return NULL;
	icon->prev->next = icon->next;
	icon->next->prev = icon->prev;
	return icon;
}




/************************************************\
*Function: delete_icon                           *
*Purpose:  Removes 'icon' from file              *
*          storing undo information in root_undo *
*          if root_undo is NULL, the icon        *
*          removed is freed                      *
*Input:    icon:      icon to remove             *
*          root_undo: where to store undo info   *
*          name:      name in undo menu          *
*Returns:  true if successful                    *
\************************************************/
bool delete_icon(icon_s *icon, undo_s *root_undo, char *name)
{
	if(root_undo) {
		if(!store_undo(root_undo, icon, UNDO_DELETE, name)) return false;
		if(remove_icon(icon) == NULL) {
			remove_undo(root_undo, 1);
			return false;
		}
	} else {
		if(remove_icon(icon) == NULL) return false;
		free_icon(icon);
	}
	return true;
}



/**************************************************\
*Function: fix_headers                             *
*Purpose:  Fills in correct values for ih and bmih *
*Input:    icon: icon to calculate for             *
*Returns:  none                                    *
\**************************************************/
void fix_headers(icon_s *icon, bool cursor)
{
	int width = icon->pixel.width;
	int height = icon->pixel.height;
	int colourcount = icon->palette.colourcount;
	int bpp = colourcount2bpp(colourcount);

	icon->ih.Width = width;
	icon->ih.Height = height;
	icon->ih.ColourCount = icon->palette.colourcount;
	if(!cursor) {
		icon->ih.hs.x = 0;
		icon->ih.hs.y = 0;
	}
	icon->ih.BytesInRes =
			sizeof icon->bmih +								//bmih
			(sizeof **(icon->pixel.pixel) * colourcount) +	//palette
			(BYTES_PER_LINE(width, bpp) * height) +			//colour pixels
			(BYTES_PER_LINE(width, 1) * height);			//transparency mask
	//icon->ih.Location is calculated in save routine

	icon->bmih.biSize = sizeof icon->bmih;
	icon->bmih.biWidth = width;
	icon->bmih.biHeight = height * 2;
	icon->bmih.biPlanes = 1;
	icon->bmih.biBitCount = bpp;
	icon->bmih.biCompression = BI_RGB;
}


#if 0
/***************************************************\
*Function: colour_increment                         *
*Purpose:  performs colour totting up 'n' stuff     *
*Input:    lots                                     *
*Returns:  value to add on to the transparent count *
*Notes:    only called by the replicate routine     *
\***************************************************/
static float colour_increment(icon_s *icon, int x, int y, float width, float height,
	rgb_int *oldcolour)
	//int *redval, int *greenval, int *blueval)
{
	pixel_t colour;

	if(height <= 0 || width <= 0)
		return 0;

	if(!IsTransparent(colour = icon->pixel.pixel[x][y])) {
		oldcolour->rgbRed += icon->palette.palette[colour].rgbRed * width*height;
		oldcolour->rgbGreen += icon->palette.palette[colour].rgbGreen * width*height;
		oldcolour->rgbBlue += icon->palette.palette[colour].rgbBlue * width*height;
		/**redval += icon->palette.palette[colour].rgbRed * height * width;
		*greenval += icon->palette.palette[colour].rgbGreen * height * width;
		*blueval += icon->palette.palette[colour].rgbBlue * height * width;*/
		return 0;
	} else
		return width*height;
}



/****************************************\
*Function: replicate                     *
*Purpose:  stretches, squishes, squashes *
*          etc.. one icon into another   *
*Input:    dest: destination icon        *
*          src:  source icon             *
*Returns:  none                          *
\****************************************/
void replicate(icon_s *dest, icon_s *src)
{
	int x, y, x2, y2;
	float area;
	float x_factor = ((float)src->pixel.width) / dest->pixel.width;
	float y_factor = ((float)src->pixel.height) / dest->pixel.height;
	palette_colour oldrgb;
	rgb_int oldcolour;
	float lmargin, rmargin, tmargin, bmargin;	// fractional margins (all < 1) of box
	int intleft, intright, inttop, intbottom;
	float floatleft, floatright, floattop, floatbottom;
	float trans_count;	//no of transparent squares
	//int redval, greenval, blueval;

	for(x = 0; x < dest->pixel.width; x++) {
		for(y = 0; y < dest->pixel.height; y++) {
			floatleft = x * x_factor;
			floatright = (x + 1) * x_factor;
			floattop = y * y_factor;
			floatbottom = (y + 1) * y_factor;

			intleft = ceil(floatleft);
			inttop = ceil(floattop);

			if(intleft == (int)ceil(floatright)) {
				intleft--;
				floatright -= (floatleft - intleft);
				floatleft = intleft;
			}
			if(inttop == (int)ceil(floatbottom)) {
				inttop--;
				floatbottom -= (floattop - inttop);
				floattop = inttop;
			}


			intright = floor(floatright);
			intbottom = floor(floatbottom);
			lmargin = intleft - floatleft;
			rmargin = floatright - intright;
			tmargin = inttop - floattop;
			bmargin = floatbottom - intbottom;

			trans_count = oldcolour.rgbRed = oldcolour.rgbGreen = oldcolour.rgbBlue = 0;

			for(x2 = intleft; x2 < intright; x2++) {
				for(y2 = inttop; y2 < intbottom; y2++) {
					/*whole squares*/
					trans_count += colour_increment(src, x2, y2, 1, 1, &oldcolour);
				}
				/*top part rectangles*/
				trans_count += colour_increment(src, x2, inttop - 1, 1, tmargin, &oldcolour);
				/*bottom part rectangles*/
				trans_count += colour_increment(src, x2, intbottom, 1, bmargin, &oldcolour);
			}

			for(y2 = inttop; y2 < intbottom; y2++) {
				/*left part squares*/
				trans_count += colour_increment(src, intleft - 1, y2, lmargin, 1, &oldcolour);
				/*right part squares*/
				trans_count += colour_increment(src, intright, y2, rmargin, 1, &oldcolour);
			}

			/*the 4 corners*/
			trans_count += colour_increment(src, intleft - 1, inttop - 1, lmargin, tmargin, &oldcolour);
			trans_count += colour_increment(src, intleft - 1, intbottom, lmargin, bmargin, &oldcolour);
			trans_count += colour_increment(src, intright, inttop - 1, rmargin, tmargin, &oldcolour);
			trans_count += colour_increment(src, intright, intbottom, rmargin, bmargin, &oldcolour);

			area = (floatright - floatleft) * (floatbottom - floattop);

			if(trans_count >= (area * 3 / 4))
				dest->pixel.pixel[x][y] = MY_TRANSPARENT;
			else {
				area -= trans_count;
				oldrgb.rgbRed = oldcolour.rgbRed / area;
				oldrgb.rgbGreen = oldcolour.rgbGreen / area;
				oldrgb.rgbBlue = oldcolour.rgbBlue / area;
				oldrgb.rgbReserved = 0;

				dest->pixel.pixel[x][y] = nearest_colour(dest->palette, oldrgb);
			}
		}
	}
}
#endif



/*************************************************\
*Function: set_pixel                              *
*Purpose:  Sets the gixen pixel of the given icon *
*          storing undo information in root_undo  *
*          (if non NULL)                          *
*Input:    root_undo: where to store undo info    *
*          icon:      icon to change colour of    *
*          x, y:      pixel to set                *
*          newcolour: colour to set it to         *
*Returns:  true if successful                     *
\*************************************************/
bool set_pixel(icon_s *icon, int x, int y, pixel_t newcolour, undo_s *root_undo)
{
	if(root_undo)
		if(!store_undo(root_undo, icon, UNDO_EDIT, "freehand draw"))
			return false;
	icon->pixel.pixel[x][y] = newcolour;
	return true;
}



/*************************************************\
*Function: flood                                  *
*Purpose:  floods a given area of same colour     *
*Input:    icon:      Pointer to icon to flood    *
*          x, y:      co-ordinates of start pixel *
*          colour:    new colour                  *
*          diagonals: go down diagonals?          *
*          root_undo: pointer to root undo        *
*Returns:  none                                   *
\*************************************************/
void flood(icon_s *icon, int x, int y, pixel_t colour, bool diagonals, undo_s *root_undo)
{
	const pixel_t oldcolour = icon->pixel.pixel[x][y];
	int i;
	int numabout=1;	//number of pixels about to be flooded
	int numjust;	//number of pixels just flooded
	int dir;		//current direction under consideration
	point_s pt;		//current point under consideration

	const point_s dirs[8] = {{0,-1},{1,0},{0,1},{-1,0},{-1,-1},{1,-1},{1,1},{-1,1}};	//the 8 different directions, with the 4 diagonals last
	point_s *about = malloc(1 * sizeof *about);	//about to be flooded pixels
	point_s *just = NULL;						//just flooded pixels

	if(!store_undo(root_undo, icon, UNDO_EDIT, "flood")) return;

	if(colour == oldcolour) return;	//nothing to do if the 2 colours match

	about[0].x = x;
	about[0].y = y;
	icon->pixel.pixel[x][y] = colour;

	do {
		free(just);
		just = about;
		numjust=numabout;
		about = NULL;
		numabout = 0;
		for(i=0; i<numjust; i++) {
			for(dir=0; dir<(diagonals ? 8:4); dir++) {
				pt.x=just[i].x + dirs[dir].x;
				pt.y=just[i].y + dirs[dir].y;
				if(IsBetween(pt.x, 0, icon->pixel.width-1)
					&& IsBetween(pt.y, 0, icon->pixel.height-1)		//check if on grid
					&& (icon->pixel.pixel[pt.x][pt.y] == oldcolour)) {	//and colours match
					about = realloc(about, (++numabout) * sizeof *about);	//increase size of array by 1
					about[numabout-1] = pt;
					icon->pixel.pixel[pt.x][pt.y] = colour;
				}
			}
		}
	} while(numabout>0);

	free(just);		//should always happen
	free(about);	//should never happen
}




/*************************************************************\
*Function: replace_colours                                    *
*Purpose:  finds all occurrences of a given colour in a given *
*          icons and replaces them with a specified colour    *
*Input:    icon: Pointer to icon to search                    *
*          clr1: colour to search for                         *
*          clr2: new colour                                   *
*          root_undo:
*Returns:  none                                               *
\*************************************************************/
void replace_colours(icon_s *icon, pixel_t clr1, pixel_t clr2, undo_s *root_undo)
{
	int x, y;

	store_undo(root_undo, icon, UNDO_EDIT, "replace");

	for(x=0; x<icon->pixel.width; x++) {
		for(y=0; y<icon->pixel.height; y++) {
			if(icon->pixel.pixel[x][y] == clr1)
				icon->pixel.pixel[x][y] = clr2;
		}
	}
}



/********************************************************\
*Function: translate                                     *
*Purpose:  translates the given icon by the given vector *
*Input:    icon:      icon to tranlate                   *
*          x, y:      vector to translate by             *
*          hotspot:   move hotspot?                      *
*          root_undo: where to store undo info or NULL   *
*Returns:  true if successful                            *
\********************************************************/
bool translate(icon_s *icon, int x, int y, bool hotspot, undo_s *root_undo)
{
	int w=icon->pixel.width , h=icon->pixel.height;
	int X, Y;
	pixel_s newpixel;

	if(IsRoot(icon)) return false;

	//make x and y positive
	while(x<0) x += w;
	while(y<0) y += h;

	if(root_undo && !store_undo(root_undo, icon, UNDO_EDIT, "translate"))
		return false;

	newpixel = alloc_pixel(w, h);
	if(newpixel.pixel == NULL) return false;

	//move hotspot
	if(hotspot) {
		icon->ih.hs.x = (icon->ih.hs.x+x)%w;
		icon->ih.hs.y = (icon->ih.hs.y+y)%h;
	}

	for(X=0; X<w; X++)
		for(Y=0; Y<h; Y++)
			newpixel.pixel[(X+x)%w][(Y+y)%h] = icon->pixel.pixel[X][Y];

	icon->pixel = (free_pixel(icon->pixel), newpixel);	//replace pixel grid

	return true;
}



/******************************************************\
*Function: reflect                                     *
*Purpose:  reflects the given icon in the given axis   *
*Input:    icon:      icon to reflect                  *
*          axis:      axis to reflect in               *
*          hotspot:   move hotspot?                    *
*          root_undo: where to store undo info or NULL *
*Returns:  true if successful                          *
\******************************************************/
bool reflect(icon_s *icon, int axis, bool hotspot, undo_s *root_undo)
{
	int w=icon->pixel.width , h=icon->pixel.height;
	int X, Y;
	pixel_s newpixel;

	if(IsRoot(icon)) return false;

	if(root_undo && !store_undo(root_undo, icon, UNDO_EDIT, "reflect"))
		return false;

	newpixel = alloc_pixel(w, h);
	if(newpixel.pixel == NULL) return false;

	switch(axis) {
	case AXIS_NS:	//vertical axis
		//move hotspot
		if(hotspot)
			icon->ih.hs.x = w-1 - icon->ih.hs.x;

		for(X=0; X<w; X++)
			for(Y=0; Y<h; Y++)
				newpixel.pixel[w-1 - X][Y] = icon->pixel.pixel[X][Y];
		break;

	case AXIS_EW:	//horizontal axis
		//move hotspot
		if(hotspot)
			icon->ih.hs.y = h-1 - icon->ih.hs.y;

		for(X=0; X<w; X++)
			for(Y=0; Y<h; Y++)
				newpixel.pixel[X][h-1 - Y] = icon->pixel.pixel[X][Y];
		break;

	case AXIS_NWSE:	//diagonal axis (top left to bottom right)
		if(h!=w) goto fail;

		//move hotspot
		if(hotspot) {
			int y = icon->ih.hs.y;
			icon->ih.hs.y = icon->ih.hs.x;
			icon->ih.hs.x = y;
		}

		for(X=0; X<w; X++)
			for(Y=0; Y<h; Y++)
				newpixel.pixel[Y][X] = icon->pixel.pixel[X][Y];
		break;
	case AXIS_NESW:	//diagonal axis (top left to bottom right)
		if(h!=w) goto fail;
		//move hotspot
		if(hotspot) {
			int y = icon->ih.hs.y;
			icon->ih.hs.y = w-1 - icon->ih.hs.x;
			icon->ih.hs.x = h-1 - y;
		}

		for(X=0; X<w; X++)
			for(Y=0; Y<h; Y++)
				newpixel.pixel[h-1 - Y][w-1 - X] = icon->pixel.pixel[X][Y];
		break;

	default:
		goto fail;
	}

	icon->pixel = (free_pixel(icon->pixel), newpixel);	//replace pixel grid

	return true;

fail:
	free_pixel(newpixel);
	return false;
}



/*********************************************************\
*Function: rotate                                         *
*Purpose:  rotates the given icon through the given angle *
*Input:    icon:      icon to rotate                      *
*          angle:     angle to rotate in right angles     *
*          hotspot:   move hotspot?                       *
*          root_undo: where to store undo info or NULL    *
*Returns:  true if successful                             *
\*********************************************************/
bool rotate(icon_s *icon, int angle, bool hotspot, undo_s *root_undo)
{
	int w=icon->pixel.width , h=icon->pixel.height;
	int X, Y;
	pixel_s newpixel;

	if(IsRoot(icon)) return false;

	while(angle<0) angle+=4;
	angle = angle%4;

	if(angle%2==1 && w!=h) return false;

	newpixel = alloc_pixel(w, h);
	if(newpixel.pixel == NULL) return false;

	switch(angle) {
	case 0:	//nowt to do.
		free_pixel(newpixel);
		if(root_undo && !store_undo(root_undo, icon, UNDO_EDIT, "rotate"))
			return false;
		else
			return true;

	case 1:	//90 c'wise
		//move hotspot
		if(hotspot) {
			int y = icon->ih.hs.y;
			icon->ih.hs.y = icon->ih.hs.x;
			icon->ih.hs.x = h-1 - y;
		}

		for(X=0; X<w; X++)
			for(Y=0; Y<h; Y++)
				newpixel.pixel[h-1-Y][X] = icon->pixel.pixel[X][Y];
		break;

	case 2:	//180
		//move hotspot
		if(hotspot) {
			icon->ih.hs.y = h-1 - icon->ih.hs.y;
			icon->ih.hs.x = w-1 - icon->ih.hs.x;
		}

		for(X=0; X<w; X++)
			for(Y=0; Y<h; Y++)
				newpixel.pixel[w-1-X][h-1-Y] = icon->pixel.pixel[X][Y];
		break;
	case 3:	//90 a'c'wise
		//move hotspot
		if(hotspot) {
			int y = icon->ih.hs.y;
			icon->ih.hs.y = w-1 - icon->ih.hs.x;
			icon->ih.hs.x = y;
		}

		for(X=0; X<w; X++)
			for(Y=0; Y<h; Y++)
				newpixel.pixel[Y][w-1 - X] = icon->pixel.pixel[X][Y];
		break;

	default:
		goto fail;
	}

	if(root_undo && !store_undo(root_undo, icon, UNDO_EDIT, "rotate")) {
		free_pixel(newpixel);
		return false;
	}

	icon->pixel = (free_pixel(icon->pixel), newpixel);	//replace pixel grid

	return true;

fail:
	free_pixel(newpixel);
	return false;
}
