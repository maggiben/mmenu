/*
    IconDesign icon file management library - handles Microsoft Windows icon files
    Copyright (C) 2002 Ross Axe
*/



#include "debug.h"

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <limits.h>

#include "types.h"
#include "palette.h"

#define PALETTE_HEADER		"Icondesign Palette File"
#define PALETTE_HEADER_LEN	(sizeof PALETTE_HEADER)	//length of above (including NUL terminator)

const palette_s NULL_Palette = {0};



/**************************************************\
*Function: alloc_palette                           *
*Purpose:  allocates a palette                     *
*Input:    colourcount: number of colours required *
*Returns:  new palette                             *
\**************************************************/
palette_s alloc_palette(int colourcount)
{
	palette_s newpal = {0};

	if(colourcount>256) return NULL_Palette;

	newpal.colourcount = colourcount;
	if(colourcount == 0) return newpal;
	newpal.palette = malloc(colourcount * sizeof *newpal.palette);
	if(newpal.palette == NULL) return NULL_Palette;
	return newpal;
}



/**************************************************\
*Function: realloc_palette                         *
*Purpose:  reallocates a palette                   *
*Input:    pal:         palette to reallocate      *
*          colourcount: number of colours required *
*Returns:  new palette                             *
\**************************************************/
palette_s realloc_palette(palette_s pal, int colourcount)
{
	pal.palette = realloc(pal.palette, colourcount * sizeof *pal.palette);
	if(pal.palette == NULL)
		pal.colourcount = 0;
	else
		pal.colourcount = colourcount;
	return pal;
}



void free_palette(palette_s pal)
{
	free(pal.palette);
}



/*******************************************\
*Function: load_palette                     *
*Purpose:  loads a palette from a file      *
*Input:    filename: file to load           *
*Returns:  loaded palette                   *
*Remarks:  returned palette should be freed *
\*******************************************/
palette_s load_palette(const char *filename)
{
	palette_s new_pal;
	dword_ colourcount;
	FILE *file;
	char header_input[PALETTE_HEADER_LEN];

	file = fopen(filename, "rb");
	if(file == NULL) return NULL_Palette;

	if(fread(header_input, PALETTE_HEADER_LEN, 1, file) < 1) goto err_inval;

	if(0 != memcmp(header_input, PALETTE_HEADER, PALETTE_HEADER_LEN))
		goto err_inval;

	if(fread(&colourcount, sizeof colourcount, 1, file)
		< 1) goto err_inval;

	new_pal = alloc_palette(colourcount);

	if(fread(new_pal.palette, sizeof *new_pal.palette, new_pal.colourcount, file)
			< new_pal.colourcount) {
		free_palette(new_pal);
		goto err_inval;
	}

	return new_pal;

err_inval:
	fclose(file);
	return NULL_Palette;
}



/*************************************************\
*Function: save_palette                           *
*Purpose:  Saves the given palette as a disk file *
*Input:    filename: name of file                 *
*          pal:      palette to save to disk      *
*Returns:  true if successful, false otherwise    *
\*************************************************/
bool save_palette(char *filename, palette_s pal)
{
	FILE *file;

	file = fopen(filename, "wb");
	if(file == NULL) return false;

	if(fwrite(PALETTE_HEADER, PALETTE_HEADER_LEN, 1, file) < 1)
		goto err;
	if(fwrite(&pal.colourcount, sizeof pal.colourcount, 1, file) < 1)
		goto err;
	if(fwrite(pal.palette, sizeof *pal.palette, pal.colourcount, file)
			< pal.colourcount)
		goto err;

	fclose(file);
	return true;

err:
	fclose(file);
	return false;
}



/****************************************************\
*Function: grey_palette                              *
*Purpose:  fills the given palette with greys        *
*Input:    palette: colourcount of new palette       *
*Returns:  pointer to palette                        *
\****************************************************/
palette_s grey_palette(palette_s pal)
{
	int i;

	if(pal.colourcount < 1) return pal;

	for(i = 0; i < pal.colourcount; i++) {
		pal.palette[i].rgbReserved = 0;
		pal.palette[i].rgbBlue =
		pal.palette[i].rgbGreen =
		pal.palette[i].rgbRed = (pal.colourcount > 1) ?
			((i * UCHAR_MAX) / (pal.colourcount - 1)) : 0;
	}
	return pal;
}



/*************************************************\
*Function: copy_palette                           *
*Purpose:  makes a copy of another icon's palette *
*Input:    pal1: palette to copy into             *
*          pal2: palette to duplicate             *
*Returns:  pal1 or NULL if failed                 *
\*************************************************/
palette_s copy_palette(palette_s pal1, palette_s pal2)
{
	pal1 = realloc_palette(pal1, pal2.colourcount);

	memcpy(pal1.palette, pal2.palette,
		sizeof *pal1.palette * pal1.colourcount);
	return pal1;
}



/*************************************************\
*Function: dup_palette                            *
*Purpose:  makes a copy of another icon's palette *
*Input:    pal: palette to duplicate              *
*Returns:  new palette or NULL if failed          *
*Remarks:  The returned palette should be freed   *
*          with free_palette                      *
\*************************************************/
palette_s dup_palette(palette_s pal)
{
	palette_s newpal;

	newpal = alloc_palette(pal.colourcount);
	if(newpal.palette == NULL) return NULL_Palette;
	copy_palette(newpal, pal);
	return newpal;
}



/*
*Function: get_xor_mask
*Purpose:
*/
/*int get_xor_mask(int clr)
{
	return -(1 + clr);
}*/



/***************************************\
*Function: nearest_colour               *
*Purpose:  Finds closest match in given *
*          palette to rgb value given   *
*Input:    palette: palette to search   *
*          colour:  colour sought       *
*Returns:  index of best match          *
\***************************************/
int nearest_colour(palette_s palette, palette_colour colour)
{
	#define SQUARE(x) ((x)*(x))
	#define DIFFSQUARES(clr1, clr2)						\
			SQUARE((clr1).rgbRed - (clr2).rgbRed)		\
			+ SQUARE((clr1).rgbGreen - (clr2).rgbGreen)	\
			+ SQUARE((clr1).rgbBlue - (clr2).rgbBlue);
	int currcolour, bestmatch;
	palette_colour testcolour;
	int leastsquares, squares;

	bestmatch = 0;

	testcolour = palette.palette[bestmatch];
	leastsquares = DIFFSQUARES(colour, testcolour);
	for(currcolour=1; currcolour<palette.colourcount; currcolour++) {
		testcolour = palette.palette[currcolour];
		squares = DIFFSQUARES(colour, testcolour);

		if(squares < leastsquares) {
			leastsquares = squares;
			bestmatch = currcolour;
			if(leastsquares == 0) break;
		}
	}

	return bestmatch;

	#undef DIFFSQUARES
	#undef SQUARE
}
