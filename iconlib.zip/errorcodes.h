/*
    IconDesign icon file management library - handles Microsoft Windows icon files
    Copyright (C) 2002 Ross Axe
*/



//error codes for portable backend

#define MYERR_SUCCESS		0
#define MYERR_FILEOPEN		1
#define MYERR_WRITE			2
#define MYERR_READ			3
#define MYERR_INVAL			4
#define MYERR_MEM			5
#define MYERR_ROOT			6
#define MYERR_BADBMIH		7
#define MYERR_BADPALETTE	8
#define MYERR_EXE			9

