/*
    IconDesign icon file management library - handles Microsoft Windows icon files
    Copyright (C) 2002 Ross Axe
*/



#ifndef DEBUG
	#ifdef LCC
		#if __LCCDEBUGLEVEL == 0
			#define DEBUG 0
		#else
			#define DEBUG 1
		#endif
	#endif
#endif
