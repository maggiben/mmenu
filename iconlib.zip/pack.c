/*
    IconDesign icon file management library - handles Microsoft Windows icon files
    Copyright (C) 2002 Ross Axe
*/



#include "pixel.h"
#include "palette.h"
#include "pack.h"



/******************************************************\
*Function: multi_rshift                                *
*Purpose:  Performs a bit + bytewise right shift on a  *
*          block of memory, handling all carries       *
*Input:    ptr:     pointer to block to shift          *
*          size:    size of block to shift (in dwords) *
*          numbits: number of bits to shift (1 - 8)    *
*          bits_in: bits to put in at left hand end    *
*Returns:  none                                        *
\******************************************************/
static dword_ multi_rshift(dword_ *dword_ptr, size_t size, int numbits, dword_ dword_bitsin)
{
	#define RCARRY(byte, bits) (byte) << (bit_sizeof(byte)-bits)
	#define ptr ((byte_ *)dword_ptr)

	byte_ bitsout, bitsin = dword_bitsin;
	int i;

	bitsin = RCARRY(bitsin, numbits);
	for(i=0; i<size*byte_sizeof(*dword_ptr); i++) {
		bitsout = RCARRY(ptr[i], numbits);
		ptr[i] >>= numbits;
		ptr[i] |= bitsin;
		bitsin = bitsout;
	}

	return bitsout;

	#undef ptr
	#undef RCARRY
}



/********************************************************\
*Function: multi_lshift                                  *
*Purpose:  Performs a bit + bytewise left shift on a     *
*          block of memory, handling all carries         *
*Input:    ptr:          pointer to block to shift       *
*          size:         size of block to shift          *
*          numbits:      number of bits to shift (1 - 8) *
*          dword_bitsin: bits to shift in                *
*Returns:  Overflow from leftmost byte                   *
\********************************************************/
dword_ multi_lshift(dword_ *dword_ptr, size_t size, int numbits, dword_ dword_bitsin = 0)
{
	#define LCARRY(byte, bits) (byte) >> (bit_sizeof(byte)-bits)
	#define ptr ((byte_ *)dword_ptr)
	byte_ bitsout, bitsin = dword_bitsin;
	int i;

	bitsin = LCARRY(bitsin, numbits);
	for(i = (size*byte_sizeof(*dword_ptr))-1; i>=0; i--) {
		bitsout = LCARRY(ptr[i], numbits);
		ptr[i] <<= numbits;
		ptr[i] |= bitsin;
		bitsin = bitsout;
	}

	return bitsout;

	#undef ptr
	#undef LCARRY
}



/**********************************************************\
*Function: packbits                                        *
*Purpose:  packs pixel data tightly for saving and copying *
*Input:    dib_bits: memory block to recieve packed bits   *
*          pixel:    pixel grid to pack                    *
*          bpp:      bits per pixel to pack to             *
*          trans:    colour to assign to transparent       *
*                    -1 means complement index (for icons) *
*                    -2 means complement rgb               *
*                    >=0 means literal palette index       *
*          pal:      palette to get complements from       *
*                    (only required if trans == -2)        *
*Returns:  dib_bits                                        *
\**********************************************************/
dword_ *packbits(dword_ *dib_bits, pixel_s pixel, int bpp, palette_s pal)
{
	int x, y;
	dword_ *curr_row;
	int dword_width = DWORDS_PER_LINE(pixel.width, bpp);
	palette_colour clr;

	//write bits to left end of block by multi byte shifting
	curr_row = dib_bits;
	for(y=pixel.height-1; y>=0; y--) {
		for(x=pixel.width - 1; x>=0; x--) {
			if(IsXORMask(pixel.pixel[x][y])) {
				if(pal.palette) {
					clr = pal.palette[GetXORMask(pixel.pixel[x][y])];
					clr.rgbRed = ~clr.rgbRed;
					clr.rgbGreen = ~clr.rgbGreen;
					clr.rgbBlue = ~clr.rgbBlue;
					multi_rshift(curr_row, dword_width, bpp, nearest_colour(pal, clr));
				} else {
					multi_rshift(curr_row, dword_width, bpp, GetXORMask(pixel.pixel[x][y]));
				}
			} else {
				multi_rshift(curr_row, dword_width, bpp, pixel.pixel[x][y]);
			}
		}
		curr_row += dword_width;
	}

	return dib_bits;
}



/*************************************************\
*Function: packmask                               *
*Purpose:  Packs mask bits for saving and copying *
*Input:    dib_bits: memory to pack into          *
*          pixel:    pixels to pack               *
*Returns:  dib_bits                               *
\*************************************************/
dword_ *packmask(dword_ *dib_bits, pixel_s pixel)
{
	int x, y;
	int dword_width = DWORDS_PER_LINE(pixel.width, 1);
	dword_ *curr_row = dib_bits;

	for(y=pixel.height-1; y>=0; y--) {
		for(x=pixel.width - 1; x>=0; x--) {
			multi_rshift(curr_row,
				dword_width, 1,
				IsXORMask(pixel.pixel[x][y]));
		}
		curr_row += dword_width;
	}
	return dib_bits;
}



/****************************************************\
*Function: unpackbits                                *
*Purpose:  unpacks pixel data for loaing and pasting *
*Input:    dib_bits: memory block to unpack          *
*          pixel:    pixel grid to pack into         *
*          bpp:      bits per pixel to pack to       *
*Returns:  pixel                                     *
\****************************************************/
pixel_s unpackbits(dword_ *dib_bits, pixel_s pixel, int bpp)
{
	int x, y;
	int dword_width = DWORDS_PER_LINE(pixel.width, bpp);
	int r,g,b;
	dword_ *curr_row = dib_bits;

	//read bits from left end of string by multi byte shifting
	for(y=pixel.height-1; y>=0; y--) {
		for(x=0; x<pixel.width; x++) {
			if(bpp<=8) {
				pixel.pixel[x][y] =
					multi_lshift(curr_row,
					dword_width, bpp);
			} else if(bpp==24) {
				b = multi_lshift(curr_row, dword_width, 8);
				g = multi_lshift(curr_row, dword_width, 8);
				r = multi_lshift(curr_row, dword_width, 8);
				pixel.pixel[x][y] = //RGB(r, g, b);
					b << 16 | g << 8 | r;
			} else if(bpp==16) {
				multi_lshift(curr_row, dword_width, 1);
				b = multi_lshift(curr_row, dword_width, 5);
				g = multi_lshift(curr_row, dword_width, 5);
				r = multi_lshift(curr_row, dword_width, 5);
			} else {
				pixel.pixel[x][y] = 0;
			}
		}
		curr_row += dword_width;
	}

	return pixel;
}



/*****************************************************\
*Function: unpackmask                                 *
*Purpose:  unpacks pixel data for loading and pasting *
*Input:    dib_bits: memory block to unpack           *
*          pixel:    pixel grid to pack into          *
*Returns:  pixel                                      *
*Remarks:  only changes transparent pixels - opaque   *
*          are left alone                             *
\*****************************************************/
pixel_s unpackmask(dword_ *dib_bits, pixel_s pixel)
{
	int x, y;
	int dword_width = DWORDS_PER_LINE(pixel.width, 1);
	dword_ *curr_row = dib_bits;

	//read bits from left end of string by multi byte shifting
	for(y=pixel.height-1; y>=0; y--) {
		for(x=0; x<pixel.width; x++) {
			if(multi_lshift(curr_row,
					dword_width, 1))
				pixel.pixel[x][y] = GetXORMask(pixel.pixel[x][y]);
		}
		curr_row += dword_width;
	}
	return pixel;
}



size_t sizeofBits(pixel_s pixel, int bpp)
{
	return BYTES_PER_LINE(pixel.width, bpp) * pixel.height;
}

