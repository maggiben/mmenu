/*
    IconDesign icon file management library - handles Microsoft Windows icon files
    Copyright (C) 2002 Ross Axe
*/



#include "debug.h"

#include <limits.h>
#include "types.h"

#ifndef __ID3_PIXEL_H__
#define __ID3_PIXEL_H__

typedef long pixel_t;
typedef struct _pixel_s {
	pixel_t	**pixel;
	int		height;
	int		width;
} pixel_s;

#endif //__ID3_PIXEL_H__

extern const pixel_s NULL_Pixel;

/******************************************\
*Function: alloc_pixel                     *
*Purpose:  allocates memory for pixel grid *
*Input:    width:  number of columns       *
*          height: number of rows          *
*Returns:  pointer to new pixel grid       *
*Remarks:  should be freed with free_pixel *
\******************************************/
pixel_s alloc_pixel(int width, int height);

/************************************************\
*Function: free_pixel                            *
*Purpose:  frees memory allocated by alloc_pixel *
*Input:    pointer to pixel grid to free         *
*Returns:  none                                  *
\************************************************/
void free_pixel(pixel_s pixel);

/******************************************\
*Function: memset_pixel                    *
*Purpose:  sets all pixels of given pixel  *
*          grid to the specified value     *
*Input:    pix: grid to set                *
*          clr: new colour index to set to *
*Returns:  value of pix                    *
\******************************************/
pixel_s memset_pixel(pixel_s pix, pixel_t clr);

/*******************************************************\
*Function: dup_pixel                                    *
*Purpose:  creates a duplicate of a given pixel area    *
*Input:    pix: pixels to duplicate                     *
*Returns:  duplicated pixels                            *
*Remarks:  return value should be freed with free_pixel *
\*******************************************************/
pixel_s dup_pixel(pixel_s pix);

/*******************************************************\
*Function: colourcount2bpp                              *
*Purpose:  Converts a colour count value to a bpp       *
*          i.e. find out which the most significant bit *
*Input:    colourcount: colour count value to convert   *
*Returns:  index of MSB of colourcount                  *
\*******************************************************/
unsigned int colourcount2bpp(unsigned int colourcount);

/*******************************************\
*Function: bpp2colourcount                  *
*Purpose:  Converts a bpp to a colour count *
*Input:    bpp                              *
*Returns:  colour count value of bpp        *
\*******************************************/
unsigned int bpp2colourcount(unsigned int bpp);
