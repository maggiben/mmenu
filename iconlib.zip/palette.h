/*
    IconDesign icon file management library - handles Microsoft Windows icon files
    Copyright (C) 2002 Ross Axe
*/



#include "debug.h"

#include "mystdbool.h"

#ifndef __ID3_PALETTE_H__
#define __ID3_PALETTE_H__

typedef struct _palette_colour {
	unsigned char rgbBlue;
	unsigned char rgbGreen;
	unsigned char rgbRed;
	unsigned char rgbReserved;
} palette_colour;

typedef struct _palette_s {
	palette_colour	*palette;
	int	colourcount;
} palette_s;

#endif //__ID3_PALETTE_H__

//#define MY_TRANSPARENT -1
//#define IsTransparent(colour) ((colour) < 0)	//true if given colour is transparent (-1)
//#define IsXORMask(colour) IsTransparent(colour)
#define IsXORMask(colour) ((colour) < 0)	//true if given colour is XOR (negative)
#define GetXORMask(colour) (-(1+(colour)))
#define IsPaletteNULL(pal) (pal.palette==NULL)

extern const palette_s NULL_Palette;

palette_s alloc_palette(int colourcount);

/**************************************************\
*Function: realloc_palette                         *
*Purpose:  reallocates a palette                   *
*Input:    pal:         palette to reallocate      *
*          colourcount: number of colours required *
*Returns:  new palette                             *
\**************************************************/
palette_s realloc_palette(palette_s pal, int colourcount);

void free_palette(palette_s pal);

/*************************************************\
*Function: copy_palette                           *
*Purpose:  makes a copy of another icon's palette *
*Input:    pal1: palette to copy into             *
*          pal2: palette to duplicate             *
*Returns:  pal1 or NULL if failed                 *
\*************************************************/
palette_s copy_palette(palette_s pal1, palette_s pal2);

/*************************************************\
*Function: dup_palette                            *
*Purpose:  makes a copy of another icon's palette *
*Input:    pal: palette to duplicate              *
*Returns:  new palette or NULL if failed          *
*Remarks:  The returned palette should be freed   *
*          with free_palette                      *
\*************************************************/
palette_s dup_palette(palette_s pal);

/****************************************************\
*Function: grey_palette                              *
*Purpose:  fills the given palette with greys        *
*Input:    palette: colourcount of new palette       *
*Returns:  pointer to palette                        *
\****************************************************/
palette_s grey_palette(palette_s pal);

/*******************************************\
*Function: load_palette                     *
*Purpose:  loads a palette from a file      *
*Input:    filename: file to load           *
*Returns:  loaded palette                   *
*Remarks:  returned palette should be freed *
\*******************************************/
palette_s load_palette(const char *filename);

/*************************************************\
*Function: save_palette                           *
*Purpose:  Saves the given palette as a disk file *
*Input:    filename: name of file                 *
*          pal:      palette to save to disk      *
*Returns:  true if successful, false otherwise    *
\*************************************************/
bool save_palette(char *filename, palette_s pal);

/***************************************\
*Function: nearest_colour               *
*Purpose:  Finds closest match in given *
*          palette to rgb value given   *
*Input:    palette: palette to search   *
*          colour:  colour sought       *
*Returns:  index of best match          *
\***************************************/
int nearest_colour(palette_s palette, palette_colour colour);

