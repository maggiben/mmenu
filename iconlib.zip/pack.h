/*
    IconDesign icon file management library - handles Microsoft Windows icon files
    Copyright (C) 2002 Ross Axe
*/



#include "stdlib.h"

#include "pixel.h"
#include "palette.h"

#define bit_sizeof(var) (CHAR_BIT * sizeof(var))
#define BPDW bit_sizeof(dword_)	//bits per dword_
/*Calculation of no. of bytes per line.  End of line is aligned on a dword_
bits per line = bits per pixel (biBitCount) * width (Width)
bits per dword_ (BPDW) = bits per char (CHAR_BIT) * bytes per dword_ (sizeof dword_)
bytes per line = floor((bits per line + BPDW - 1) / BPDW) * bytes per dword_	*/
#define DWORDS_PER_LINE(width, bpp) ((((bpp) * (width)) + BPDW - 1) / BPDW)
#define BYTES_PER_LINE(width, bpp) (DWORDS_PER_LINE(width, bpp) * sizeof(dword_))

/**********************************************************\
*Function: packbits                                        *
*Purpose:  packs pixel data tightly for saving and copying *
*Input:    dib_bits: memory block to recieve packed bits   *
*          pixel:    pixel grid to pack                    *
*          bpp:      bits per pixel to pack to             *
*          trans:    colour to assign to transparent       *
*                    -1 means complement index (for icons) *
*                    -2 means complement rgb               *
*                    >=0 means literal palette index       *
*          pal:      palette to get complements from       *
*                    (only required if trans == -2)        *
*Returns:  dib_bits                                        *
\**********************************************************/
dword_ *packbits(dword_ *dib_bits, pixel_s pixel, int bpp, palette_s pal);

/*************************************************\
*Function: packmask                               *
*Purpose:  Packs mask bits for saving and copying *
*Input:    dib_bits: memory to pack into          *
*          pixel:    pixels to pack               *
*Returns:  dib_bits                               *
\*************************************************/
dword_ *packmask(dword_ *dib_bits, pixel_s pixel);

/****************************************************\
*Function: unpackbits                                *
*Purpose:  unpacks pixel data for loaing and pasting *
*Input:    dib_bits: memory block to unpack          *
*          pixel:    pixel grid to pack into         *
*          bpp:      bits per pixel to pack to       *
*Returns:  pixel                                     *
\****************************************************/
pixel_s unpackbits(dword_ *dib_bits, pixel_s pixel, int bpp);

/*****************************************************\
*Function: unpackmask                                 *
*Purpose:  unpacks pixel data for loading and pasting *
*Input:    dib_bits: memory block to unpack           *
*          pixel:    pixel grid to pack into          *
*Returns:  pixel                                      *
*Remarks:  only changes transparent pixels - opaque   *
*          are left alone                             *
\*****************************************************/
pixel_s unpackmask(dword_ *dib_bits, pixel_s pixel);

size_t sizeofBits(pixel_s pixel, int bpp);
