/*
    IconDesign icon file management library - handles Microsoft Windows icon files
    Copyright (C) 2002 Ross Axe
*/



#include <stdlib.h>
#include <math.h>

#include "icon.h"
#include "mash.h"


typedef struct _rgb_int {
	int rgbRed;
	int rgbGreen;
	int rgbBlue;
} rgb_int;



/***************************************\
*Function: alloc_masher                 *
*Purpose:  Allocates an intermediate    *
*          masher structure for mashing *
*Input:    width:  width of grid        *
*          height: height of grid       *
*Returns:  Masher struct                *
\***************************************/
masher_s alloc_masher(const int width, const int height)
{
	masher_s rval;

	rval.width = width;
	rval.height = height;
	rval.clr = malloc(sizeof rval.clr[0] * width);
	rval.clr[0] = malloc(sizeof rval.clr[0][0] * height * width);
	rval.mask = malloc(sizeof rval.mask[0] * width);
	rval.mask[0] = malloc(sizeof rval.mask[0][0] * height * width);
	for(int i=1; i<width; i++) {
		rval.clr[i] = rval.clr[i-1] + height;
		rval.mask[i] = rval.mask[i-1] + height;
	}

	return rval;
}

void free_masher(masher_s mash)
{
	if(mash.clr) free(mash.clr[0]);
	free(mash.clr);
	if(mash.mask) free(mash.mask[0]);
	free(mash.mask);
}



/********************************************\
*Function: icon2masher                       *
*Purpose:  Converts an icon to a masher      *
*Input:    icon: Icon to convert to a masher *
*Returns:  Masher based on icon              *
\********************************************/
masher_s icon2masher(const icon_s *icon)
{
	masher_s masher;
	int x,y;
	pixel_t colour;

	masher = alloc_masher(icon->pixel.width, icon->pixel.height);

	for(x=0; x<icon->pixel.width; x++) {
		for(y=0; y<icon->pixel.height; y++) {
			colour = icon->pixel.pixel[x][y];
			if(IsXORMask(colour)) {
				masher.clr[x][y] = icon->palette.palette[GetXORMask(colour)];
				masher.clr[x][y].rgbRed = ~masher.clr[x][y].rgbRed;
				masher.clr[x][y].rgbGreen = ~masher.clr[x][y].rgbGreen;
				masher.clr[x][y].rgbBlue = ~masher.clr[x][y].rgbBlue;
				masher.mask[x][y] = true;
			} else {
				masher.clr[x][y] = icon->palette.palette[colour];
				masher.mask[x][y] = false;
			}
		}
	}

	return masher;
}



/*************************************************\
*Function: masher2icon                            *
*Purpose:  Takes information in a masher struct   *
*          and converts it into pixel information *
*Input:    masher: Masher struct to convert       *
*          icon:   Icon to convert into           *
*Returns:  icon or NULL if failed                 *
\*************************************************/
icon_s *masher2icon(masher_s masher, icon_s *icon)
{
	int x,y;
	palette_colour clr;

	if(!icon) return NULL;
	if(masher.width!=icon->pixel.width || masher.height!=icon->pixel.height)
		return NULL;

	for(x=0; x<masher.width; x++) {
		for(y=0; y<masher.height; y++) {
			clr = masher.clr[x][y];
			if(masher.mask[x][y]) {
				clr.rgbRed = ~clr.rgbRed;
				clr.rgbGreen = ~clr.rgbGreen;
				clr.rgbBlue = ~clr.rgbBlue;
				icon->pixel.pixel[x][y] = GetXORMask(nearest_colour(icon->palette, clr));
			} else
				icon->pixel.pixel[x][y] = nearest_colour(icon->palette, clr);
		}
	}

	free_masher(masher);

	return icon;
}



/****************************************************\
*Function: colour_increment                          *
*Purpose:  performs colour totting up 'n' stuff      *
*Input:    lots                                      *
*Returns:  value to add on to the transparent count  *
*Remarks:  only called by the stretch_masher routine *
\****************************************************/
static float colour_increment(masher_s mash, int x, int y, float width, float height, rgb_int *oldcolour)
{
	palette_colour clr;
	float area = width*height;

	if(height <= 0 || width <= 0)
		return 0;

	clr = mash.clr[x][y];
	oldcolour->rgbRed += clr.rgbRed * area;
	oldcolour->rgbGreen += clr.rgbGreen * area;
	oldcolour->rgbBlue += clr.rgbBlue * area;
	if(mash.mask[x][y])
		return area;
	else
		return 0;
}



/***************************************\
*Function: stretch_masher               *
*Purpose:  Stretches a masher structure *
*Input:    masher: masher to stretch    *
*          width:  new width            *
*          height: new height           *
*Returns:  Stretched masher             *
*Remarks:  Frees masher                 *
\***************************************/
masher_s stretch_masher(masher_s masher, int width, int height)
{
	masher_s mashout;

	int x, y, x2, y2;
	float area;
	float x_factor;
	float y_factor;
	rgb_int oldcolour;
	float lmargin, rmargin, tmargin, bmargin;	// fractional margins (all < 1) of box
	int intleft, intright, inttop, intbottom;
	float floatleft, floatright, floattop, floatbottom;
	float trans_count;	//no. of XOR squares


	if(masher.width==width && masher.height==height) return masher;

	mashout = alloc_masher(width, height);

	x_factor = (float)masher.width / mashout.width;
	y_factor = (float)masher.height / mashout.height;

	//for each target pixel
	for(x=0; x<mashout.width; x++) {
		for(y=0; y<mashout.height; y++) {
			floatleft = x * x_factor;
			floatright = (x + 1) * x_factor;
			floattop = y * y_factor;
			floatbottom = (y + 1) * y_factor;

			intleft = ceil(floatleft);
			inttop = ceil(floattop);

			if(intleft == (int)ceil(floatright)) {
				intleft--;
				floatright -= (floatleft - intleft);
				floatleft = intleft;
			}
			if(inttop == (int)ceil(floatbottom)) {
				inttop--;
				floatbottom -= (floattop - inttop);
				floattop = inttop;
			}


			intright = floor(floatright);
			intbottom = floor(floatbottom);
			lmargin = intleft - floatleft;
			rmargin = floatright - intright;
			tmargin = inttop - floattop;
			bmargin = floatbottom - intbottom;

			trans_count = oldcolour.rgbRed = oldcolour.rgbGreen = oldcolour.rgbBlue = 0;

			for(x2 = intleft; x2 < intright; x2++) {
				for(y2 = inttop; y2 < intbottom; y2++) {
					/*whole squares*/
					trans_count += colour_increment(masher, x2, y2, 1, 1, &oldcolour);
				}
				/*top part rectangles*/
				trans_count += colour_increment(masher, x2, inttop - 1, 1, tmargin, &oldcolour);
				/*bottom part rectangles*/
				trans_count += colour_increment(masher, x2, intbottom, 1, bmargin, &oldcolour);
			}

			for(y2 = inttop; y2 < intbottom; y2++) {
				/*left part squares*/
				trans_count += colour_increment(masher, intleft - 1, y2, lmargin, 1, &oldcolour);
				/*right part squares*/
				trans_count += colour_increment(masher, intright, y2, rmargin, 1, &oldcolour);
			}

			/*the 4 corners*/
			trans_count += colour_increment(masher, intleft - 1, inttop - 1, lmargin, tmargin, &oldcolour);
			trans_count += colour_increment(masher, intleft - 1, intbottom, lmargin, bmargin, &oldcolour);
			trans_count += colour_increment(masher, intright, inttop - 1, rmargin, tmargin, &oldcolour);
			trans_count += colour_increment(masher, intright, intbottom, rmargin, bmargin, &oldcolour);

			area = (floatright - floatleft) * (floatbottom - floattop);
			mashout.clr[x][y].rgbRed = oldcolour.rgbRed / area;
			mashout.clr[x][y].rgbGreen = oldcolour.rgbGreen / area;
			mashout.clr[x][y].rgbBlue = oldcolour.rgbBlue / area;
			mashout.clr[x][y].rgbReserved = 0;
			mashout.mask[x][y] = (trans_count/area > 0.5);
		}
	}

	free_masher(masher);

	return mashout;
}



/****************************************\
*Function: mash                          *
*Purpose:  stretches, squishes, squashes *
*          etc.. one icon into another   *
*Input:    dest: destination icon        *
*          src:  source icon             *
*Returns:  none                          *
\****************************************/
void mash(icon_s *dest, icon_s *src)
{
	masher_s mash;

	mash = icon2masher(src);
	mash = stretch_masher(mash, dest->pixel.width, dest->pixel.height);
	masher2icon(mash, dest);
}
