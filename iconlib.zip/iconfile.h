/*
    IconDesign icon file management library - handles Microsoft Windows icon files
    Copyright (C) 2002 Ross Axe
*/



#include "debug.h"

#include <stdio.h>
#include <limits.h>
#include "mystdbool.h"

#include "types.h"
#include "icon.h"
#include "undo.h"

#define MY_MAXFILE 1024	//generous - do not use outside for checking validity

#define IMAGE_ICON		1
#define IMAGE_CURSOR	2

#ifndef __ID3_ICONFILE_H__
#define __ID3_ICONFILE_H__

typedef struct _new_header {
    word_ Reserved;		//always 0
    word_ ResType;		//IMAGE_ICON or IMAGE_CURSOR
    word_ ResCount; 	//count of images
} new_header;

typedef struct resid_s_ {
	bool		cursor;		//true for cursor
	bool		numeric;	//true to use id, false to use name (false when none)
	union {
		int		id;
		char	*name;	//NULL for ico & cur files, resource identifier for others
	};
} resid_s;

typedef struct _icon_file {
	char		filename[MY_MAXFILE];
	resid_s		resname;
	bool		changed;
	new_header	nh;
	icon_s		root_icon;
	undo_s		root_undo;
} icon_file;

#endif //__ID3_ICONFILE_H__

extern const new_header	blank_nh;
extern const resid_s	NULL_resid;

#define Is_resid_NULL(resid) (!(resid).numeric && (resid).name==NULL)

/*******************************************************\
*Function: alloc_resid                                  *
*Purpose:  Allocates a resource name                    *
*Input:    size:   Number of characters (including NUL) *
*                  wanted in name. 0 means numeric id   *
*          cursor: true for cursor, false for icon      *
*Returns:  New name                                     *
\*******************************************************/
resid_s alloc_resid(size_t size, bool cursor);

/********************************************************\
*Function: free_resid                                    *
*Purpose:  Frees a resid_s name allocated by alloc_resid *
*Input:    resid: resid_s to free                        *
\********************************************************/
void free_resid(resid_s resid);

/**********************************************\
*Function: realloc_resid                       *
*Purpose:  Changes the size of a resid string  *
*Input:    resid:  resid to resize             *
*          size:   new size                    *
*          cursor: true for cursor             *
*Returns:  new resid (may differ from old one) *
\**********************************************/
resid_s realloc_resid(resid_s resid, size_t size, bool cursor);

/********************************************************\
*Function: dumpptr                                       *
*Purpose:  Dumps a given memory block to a text stream   *
*Input:    file: text stream to dump to                  *
*          ptr:  block to dump                           *
*          size: size of block in bytes                  *
*          cols: number of columns (in bytes) to wrap to *
\********************************************************/
void dumpptr(FILE *file, void *ptr, size_t size, size_t cols);

/*****************************************\
*Function: dump_icon                      *
*Purpose:  dumps icon data to a text file *
*Input:    icf:  pointer to icon to dump  *
*          file: open file stream to dump *
*                into.  Must be open for  *
*                writing text             *
*Returns:  none                           *
\*****************************************/
void dump_icon(icon_file *icf, FILE *file);

/**************************************************\
*Function: init_file                               *
*Purpose:  initialises icon_file                   *
*Input:    icf: pointer to structure to initialize *
*Returns:  none                                    *
\**************************************************/
void init_file(icon_file *icf, int restype);

/********************************************************\
*Function: new_file                                      *
*Purpose:  closes old file and creates a new, blank file *
*Input:    icf: file to close and new                    *
*Returns:  true if successful                            *
\********************************************************/
bool new_file(icon_file *icf, int restype);

/***************************************************\
*Function: open_icon                                *
*Purpose:  Opens an icon file                       *
*Input:    hwnd:      main window                   *
*          file_name: pointer to the file name      *
*Returns:  0 if successful, an error code otherwise *
\***************************************************/
int open_icon(icon_file *icf, const char *file_name);

/**********************************************\
*Function: save_icon                           *
*Purpose:  saves an icon                       *
*Input:    icon:      icon_file structure      *
*          file_name: pointer to the file name *
*Returns:  0 if successful                     *
*Remarks:  ANSI C99 compliant (i hope...)      *
\**********************************************/
int save_icon(icon_file *icon_f, const char *file_name);
