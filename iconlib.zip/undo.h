/*
    IconDesign icon file management library - handles Microsoft Windows icon files
    Copyright (C) 2002 Ross Axe
*/



#include "debug.h"

#ifndef __ID3_UNDO_H__
#define __ID3_UNDO_H__

typedef struct _undo_s {
	union {
		icon_s *iconchanged;	//pointer to the icon that changed for edit
								//pointer to icon before for delete
								//pointer to new icon for an add
		//palette_s palettechanged;
	};
	int type;				//type of action, (see #defines below)
		#define UNDO_ADD 1
		#define UNDO_EDIT 2
		#define UNDO_DELETE 3
		#define UNDO_ICON 0		//mask indicating whole icon change
	//	#define UNDO_PALETTE 4	//mask indicating just pixel change
	//	#define UNDO_PALETTE_EDIT (UNDO_EDIT | UNDO_PALETTE)
	const char *name;		//name of action (draw, flood etc...)
	union {
		icon_s *icondata;	//copy of old icon (not used for add, set to NULL)
							//pointer to copy of icon data for edit
							//pointer to original when deleted
		//palette_s palettedata;
	};
	struct _undo_s *next;	//pointer to next element in linked list
} undo_s;

#define MAX_UNDO_BACKLOG 100

#endif //__ID3_UNDO_H__

#ifndef __ID3_ICON_H__
#include "icon.h"
#endif

extern const undo_s blank_undo;

/*********************************************************\
*Function: store_undo                                     *
*Purpose:  store info for undo command                    *
*Input:    root_undo: root undo structure                 *
*          icon:      icon that is about to be changed    *
*          undo_type: type of undo                        *
*          name:      name of change (draw, flood, etc..) *
*Returns:  true if OK to proceed with change              *
\*********************************************************/
bool store_undo(undo_s *root_undo, icon_s *icon, int undo_type, const char *name);

/************************************************\
*Function: remove_undo                           *
*Purpose:  removes the undo command(s)           *
*          pointed to by root_undo               *
*Input:    root_undo: root undo node             *
*          number:    number of nodes to remove, *
*                     or 0 to remove all         *
*Returns:  number of undo's removed              *
\************************************************/
int remove_undo(undo_s *root_undo, int number);

/******************************************\
*Function: undo                            *
*Purpose:  undo the last n actions         *
*Input:    hwnd: handle of main window     *
*          n:    number of actions to undo *
*Returns:  none                            *
\******************************************/
icon_s *undo(undo_s *root_undo, unsigned int n);

/*******************************************************\
*Function: set_colour_undo                              *
*Purpose:  Sets colour 'index' of palette to newcolour, *
*          storing undo information in root_undo        *
*Input:    root_undo: where to store undo info          *
*          palette:   icon to change colour of          *
*          index:     index of colour to set            *
*          newcolour: new value to set it to            *
*Returns:  true if successful                           *
\*******************************************************/
bool set_colour_undo(undo_s *root_undo, icon_s *icon, int index, palette_colour newcolour);

/************************************************\
*Function: add_icon_undo                         *
*Purpose:  adds 'icon' from file                 *
*          storing undo information in root_undo *
*Input:    root_undo: where to store undo info   *
*          icon:      icon to add                *
*          after:     icon to add after          *
*Returns:  true if successful                    *
\************************************************/
bool add_icon_undo(undo_s *root_undo, icon_s *icon, icon_s *after);

/**********************************************\
*Function: replicate_undo                      *
*Purpose:  does a replicate, storing undo info *
*Input:    root_undo:                          *
*          src:                                *
*          dest:                               *
*          name: name on undo menu             *
*Returns:  true if successful                  *
\**********************************************/
bool replicate_undo(undo_s *root_undo, icon_s *dest, icon_s *src, char *name);

