/* Weditres generated include file. Do NOT edit */
#define	IDD_MAINDIALOG	100
#define	IDSTANDARD	101
#define	IDWALLPAPER1	102
#define	IDWALLPAPER2	103
#define	IDBMP1	104
#define	IDBMP2	105
