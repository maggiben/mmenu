
#include <windows.h>
#include <windowsx.h>
#include <commctrl.h>
#include <string.h>
#include "nicedlgres.h"

HWND hwnddlg;
int idbmp;

static BOOL CALLBACK DialogFunc(HWND hwndDlg, UINT msg, WPARAM wParam, LPARAM lParam);
void wallpaper(HDC hdc,RECT *lprc,int idbitmap);
void paint(void);

int APIENTRY WinMain(HINSTANCE hinst, HINSTANCE hinstPrev, LPSTR lpCmdLine, int nCmdShow)
{
	WNDCLASS wc;

	memset(&wc,0,sizeof(wc));
	wc.lpfnWndProc = DefDlgProc;
	wc.cbWndExtra = DLGWINDOWEXTRA;
	wc.hInstance = hinst;
	wc.hCursor = LoadCursor(NULL, IDC_ARROW);
	wc.hbrBackground = (HBRUSH) (COLOR_WINDOW + 1);
	wc.lpszClassName = "nicedlg";
	RegisterClass(&wc);

	return DialogBox(hinst, MAKEINTRESOURCE(IDD_MAINDIALOG), NULL, (DLGPROC) DialogFunc);

}


static BOOL CALLBACK DialogFunc(HWND hwndDlg, UINT msg, WPARAM wParam, LPARAM lParam)
{
	hwnddlg=hwndDlg;

	switch (msg) {
	case WM_PAINT:
		paint();
		return 1;
	case WM_INITDIALOG:

		return TRUE;

	case WM_COMMAND:
		switch (LOWORD(wParam)) {

		case IDWALLPAPER1:
			idbmp=IDBMP1;
			InvalidateRect(hwnddlg,NULL,TRUE);
			UpdateWindow(hwnddlg);
			return 1;
		case IDWALLPAPER2:
			idbmp=IDBMP2;
			InvalidateRect(hwnddlg,NULL,TRUE);
			UpdateWindow(hwnddlg);
			return 1;
		case IDSTANDARD:
			idbmp=0;
			InvalidateRect(hwnddlg,NULL,TRUE);
			UpdateWindow(hwnddlg);
			return 1;

		case IDOK:
			EndDialog(hwndDlg,1);
			return 1;
		case IDCANCEL:
			EndDialog(hwndDlg,0);
			return 1;
		}
		break;
		/* By default, WM_CLOSE is equivalent to CANCEL */
	case WM_CLOSE:
		EndDialog(hwndDlg,0);
		return TRUE;

	}
	return FALSE;
}

void wallpaper(HDC hdc,RECT *lprc,int idbitmap){
	HDC shdc;
	HINSTANCE hinst;
	BITMAP bmp;
	HBITMAP hbmp;

	long bmx, bmy;

	if (idbitmap >0){
		hinst=GetModuleHandle(NULL);
		hbmp = LoadBitmap(hinst, MAKEINTRESOURCE(idbitmap));
		shdc = CreateCompatibleDC(hdc);
		SelectObject(shdc, hbmp);
		GetObject(hbmp, sizeof(BITMAP), &bmp);
		bmx =bmp.bmWidth;
		bmy =bmp.bmHeight;

		long r=lprc->right;
		long l=lprc->left;
		long b=lprc->bottom;
		long t=lprc->top;

		long x,y;
		for(x=l; x<r;   x+=bmx){
			for(y=t; y<b;  y+=bmy){
				BitBlt(hdc, x,y, r-x,b-y, shdc, 0, 0, SRCCOPY);
			}
		}

		DeleteObject(hbmp);
		DeleteDC(shdc);
	}
}

void paint(void){
	PAINTSTRUCT ps;
	HDC hdc ;
	RECT rc;

	GetUpdateRect(hwnddlg,&rc,0);
	hdc= BeginPaint(hwnddlg,&ps);
        wallpaper(hdc,&rc,idbmp);
	EndPaint(hwnddlg,&ps);
}

