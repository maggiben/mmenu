#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

class CApp : public CWinApp
{
public:
	CApp();

	//{{AFX_VIRTUAL(CApp)
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

	//{{AFX_MSG(CApp)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

