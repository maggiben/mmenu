#include "stdafx.h"
#include "app.h"
#include "mfccddb.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

BEGIN_MESSAGE_MAP(CApp, CWinApp)
	//{{AFX_MSG_MAP(CApp)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

CApp::CApp()
{
}

CApp theApp;

BOOL CApp::InitInstance()
{
#ifdef _AFXDLL
	Enable3dControls();
#else
	Enable3dControlsStatic();
#endif

  //Initialise the Winsock stack
  if (!AfxSocketInit())
    return FALSE;

  //Create the CDDB instance
  CCDDB cddb;  

  //Test out getting all the CDROM drive letters
  CStringArray drives;
  cddb.GetCDROMDrives(drives);

  CString sMsg;
  sMsg = _T("CDROM Drives on this machine are: ");
  for (int i=0; i<drives.GetSize(); i++)
  {
    sMsg += drives.ElementAt(i);
    if (i != drives.GetUpperBound())
      sMsg += _T(',');
  }
  AfxMessageBox(sMsg);

  //Test out the DISCID function
  DWORD dwDiscID;
  int nID = AfxMessageBox(_T("Please insert an Audio CD into the first CD-ROM drive, Cancel quits the app"), MB_OKCANCEL);
  while (nID == IDOK) 
  {
    if (cddb.ComputeDiscID(dwDiscID))
    {
      CString sMsg;
      sMsg.Format(_T("The CDDB DISCID for this Audio CD is %08x"), dwDiscID);
      AfxMessageBox(sMsg);
    }
    else
    { 
      CString sMsg;
      sMsg.Format(_T("An error occurred while retrieving the DISC ID, Error:%d, Text:%s"), cddb.GetLastError(), cddb.GetErrorMessage());
      AfxMessageBox(sMsg);
    }

    nID = AfxMessageBox(_T("Please insert an audio CD into the first CD-ROM drive, Cancel quits the app"), MB_OKCANCEL);
  }  
  while (nID == IDOK);

  //Uncomment this line and change the details if you want to try out the MfcCDDB support for proxies and proxy authentication
  //cddb.SetProxyDetails(_T("your_proxys_address"), 8080, _T("a_user"), _T("some_password")); //use if you require authenticated proxy connections
  //cddb.SetProxyDetails(_T("your_proxys_address"), 8080, _T(""), _T(""));                    //use if you require a proxy without authentication

  //Test out the Sites command
  CArray<CCDDBSite, CCDDBSite&> sites;
  //cddb.SetCDDBProtocolVersion(3);                             //Uncomment this line and the following and comment out the line after
  //BOOL bSuccess = cddb.Sites(sites, _T("freedb.freedb.org")); //to use the open source CDDB server at "freedb.freedb.org" instead 
                                                                //of the default "cddb.cddb.com"
  BOOL bSuccess = cddb.Sites(sites);
  if (!bSuccess)
  {
    TRACE(_T("Error: %d, Response:%s\n"), cddb.GetLastError(), cddb.GetLastCommandResponse());
    return FALSE;
  }

  TRACE(_T("Retrieved the following CDDB sites from the CDDB server\n"));
  for (i=0; i<sites.GetSize(); i++)
  {
    CCDDBSite s = sites.ElementAt(i);
    CString sLat;
    sLat.Format(_T("%c%03d.%02d"), s.m_bNorthing ? _T('N') : _T('S'), s.m_nLatitudeMinutes / 60, s.m_nLatitudeMinutes % 60);
    CString sLong;
    sLong.Format(_T("%c%03d.%02d"), s.m_bEasting ? _T('E') : _T('W'), s.m_nLongitudeMinutes / 60, s.m_nLongitudeMinutes % 60);
    TRACE(_T("%s, %d, %s, %s, %s, %s\n"), s.m_sSite, s.m_nPort, s.m_sAddress, sLat, sLong, s.m_sDescription);
  }

  if (!sites.GetSize())
    return FALSE;

  //Try the other version of the site function
  CCDDBSite site2 = sites.ElementAt(0);
  bSuccess = cddb.Sites(sites, site2);
  if (!bSuccess)
    return FALSE;

  TRACE(_T("Retrieved the following CDDB sites from %s\n"), site2.m_sSite);
  for (i=0; i<sites.GetSize(); i++)
  {
    CCDDBSite s = sites.ElementAt(i);
    CString sLat;
    sLat.Format(_T("%c%03d.%02d"), s.m_bNorthing ? _T('N') : _T('S'), s.m_nLatitudeMinutes / 60, s.m_nLatitudeMinutes % 60);
    CString sLong;
    sLong.Format(_T("%c%03d.%02d"), s.m_bEasting ? _T('E') : _T('W'), s.m_nLongitudeMinutes / 60, s.m_nLongitudeMinutes % 60);
    TRACE(_T("%s, %d, %s, %s, %s, %s\n"), s.m_sSite, s.m_nPort, s.m_sAddress, sLat, sLong, s.m_sDescription);
  }

  //Try out the message of the day function
  CString sMessage;
  bSuccess = cddb.MessageOfTheDay(site2, sMessage);
  if (bSuccess)
  {
    TRACE(_T("Message of the day was:"));
    #ifdef _DEBUG
    OutputDebugString(sMessage);
    #endif
    TRACE(_T("\n"));
  }

  //Try the Categories function
  CStringArray sCategories;
  CCDDBSite site5;
  site5.m_sSite = _T("cddb.cddb.com");
  bSuccess =  cddb.Categories(site5, sCategories);
  if (!bSuccess)
    return FALSE;

  TRACE(_T("Retrieved the following CDDB categories from %s\n"), site5.m_sSite);
  for (i=0; i<sCategories.GetSize(); i++)
    TRACE(_T("%s\n"), sCategories.ElementAt(i));

  //Try out the Status function
  CCDDBSite site3(TRUE);
  site3.m_sSite = _T("cddb.cddb.com");
  CCDDBStatus status;
  bSuccess = cddb.Status(site3, status);
  if (!bSuccess)
    return FALSE;

  //Display the results
  TRACE(_T("\nStatus of the site %s is as follows\n"), site3.m_sSite);
  TRACE(_T("Current protocol: %d\n"), status.m_nCurrentProtocol);
  TRACE(_T("Max protocol: %d\n"), status.m_nMaxProtocol);
  TRACE(_T("Gets allowed: %d\n"), status.m_bGetsAllowed);
  TRACE(_T("Updates allowed: %d\n"), status.m_bUpdatesAllowed);
  TRACE(_T("Posting: %d\n"), status.m_bPostingAllowed);
  TRACE(_T("Quotes: %d\n"), status.m_bQuotes);
  TRACE(_T("Current Users: %d\n"), status.m_nCurrentUsers);
  TRACE(_T("Max Users: %d\n"), status.m_nMaxUsers);
  TRACE(_T("Strip Extended: %d\n"), status.m_bStripExtended);
  TRACE(_T("Database Entries: %d\n"), status.m_nDatabaseEntries);
  for (i=0; i<status.m_Categories.GetSize(); i++)
    TRACE(_T("%s has %d entries\n"), status.m_Categories.ElementAt(i),  status.m_CategoryEntries.ElementAt(i));
  for (i=0; i<status.m_PendingSites.GetSize(); i++)
    TRACE(_T("%s has %d pending entries\n"), status.m_PendingSites.ElementAt(i),  status.m_PendingEntries.ElementAt(i));

  //Test out the GetTrackPositions function
  CArray<CCDDBTrackPosition, CCDDBTrackPosition&> tracks;
  bSuccess = cddb.GetTrackPositions(tracks);
  if (!bSuccess)
    return FALSE;

  //Test out the ComputeDiscID function
  bSuccess = cddb.ComputeDiscID(dwDiscID);
  if (!bSuccess)
    return FALSE;

  //Test out the query function
  CArray<CCDDBQueryResult, CCDDBQueryResult&> results;
  bSuccess = cddb.Query(site3, dwDiscID, tracks, results);
  if (!bSuccess)
    return FALSE;

  TRACE(_T("Retrieved the following matches for the inserted audio CD\n"));
  for (i=0; i<results.GetSize(); i++)
  {
    CCDDBQueryResult& result = results.ElementAt(i);
    TRACE(_T("%08x, %s / %s\n"), result.m_dwDiscID, result.m_sArtist, result.m_sTitle);
  }
  if (results.GetSize() == 0)
    return FALSE;

  //Try out the read function
  CCDDBQueryResult& result = results.ElementAt(0);
  CCDDBRecord record;
  bSuccess = cddb.Read(site3, result.m_dwDiscID, result.m_sCategory, record);
  if (!bSuccess)
    return FALSE;

  //Display all the album details
  TRACE(_T("\nRetrieved the following album details\n"));
  TRACE(_T("Album Title: %s\n"), record.m_sTitle);
  TRACE(_T("Album Artist: %s\n"), record.m_sArtist);
  TRACE(_T("Disc Length (seconds): %d\n"), record.m_nDiskLength);
  TRACE(_T("Submitted via: %s %s %s\n"), record.m_sClientName, record.m_sClientVersion, record.m_sClientComments);
  TRACE(_T("Database Revision: %d\n"), record.m_nDatabaseRevision);
  TRACE(_T("DISCID: %x\n"), record.m_dwDiscID);

  //Display the track names 
  TRACE(_T("\nTrack Names are:\n"));
  for (i=0; i<record.m_TrackTitles.GetSize(); i++)
    TRACE(_T("Track %d: %s\n"), i+1, record.m_TrackTitles.ElementAt(i));

  //Display the Extended track data 
  TRACE(_T("\nExtended Track Data:\n"));
  for (i=0; i<record.m_ExtendedTrackData.GetSize(); i++)
    TRACE(_T("Track %d: %s\n"), i+1, record.m_ExtendedTrackData.ElementAt(i));

  //Display the Extended data 
  TRACE(_T("\nExtended Data:\n"));
  for (i=0; i<record.m_ExtendedData.GetSize(); i++)
    TRACE(_T("%s\n"), record.m_ExtendedData.ElementAt(i));

  //Display the track offsets 
  TRACE(_T("\nTrack Offsets:\n"));
  for (i=0; i<record.m_TrackOffsets.GetSize(); i++)
    TRACE(_T("%d\n"), record.m_TrackOffsets.ElementAt(i));

  //Display the Playorder
  TRACE(_T("Playorder :\n"));
  for (i=0; i<record.m_PlayOrder.GetSize(); i++)
    TRACE(_T("%d\n"), record.m_PlayOrder.ElementAt(i));

  //Try out the Submit function using the test mode
  VERIFY(FALSE); //please change the email address below to your own to send
                 //any rejection emails to you rather than me. 
  CCDDBSite site6(FALSE);
  site6.m_sSite = _T("cddb.cddb.com");
  bSuccess = cddb.Submit(site6, result.m_sCategory, _T("pjn@indigo.ie"), record,
                         _T("Test submission by MfcCDDB code"), FALSE);

  
  return FALSE;
}


