/*
Module : MfcCDDB.CPP
Purpose: Defines the implementation for an MFC class to wrap access to CDDB
Created: PJN / 24-02-1999
History: PJN / 19-05-1999 1. Added support for MOTD (Message of the Day)
                          2. Added support for submit
                          3. Fixed a number of places where calling the TRACE
                          function was causing an access violation
                          4. Fixed a bug in GetErrorMessage which was causing
                          SDK errors to return the string "The operation completed successfully"
         PJN / 14-07-1999 1. Fixed two potential access violations in the CCDDB::ReadResponse function.
         PJN / 29-11-1999 Fixed a number of bugs when compiled with VC 6.0
         PJN / 17-01-2000 Fixed a nmber of compiler errors which seem to have crept into v1.12
         PJN / 23-01-2000 1. The code has now been fully tested with the open source alternative to CDDB namely 
                          freedb.freedb.org. CDDB has become more commercialized of late, since its introduction 
                          of a binary SDK with closed validation and new licensening rules. I also believe that 
                          CDDB will stop access sometime in 2000 to its databases via non CDDB originated code.
                          Therefore I would suggest that developers using MfcCDDB should provide users with a 
                          configuation dialog to allow the CDDB server to be specified, that way you will not 
                          have irate customers ringing you when CDDB stops allowing access to it. You can use 
                          this open source server instead of the CDDB one in the MfcCDDB code by using 
                          "freedb.freedb.org" instead of "cddb.cddb.com" in the call to CCDDB::Sites and by 
                          specifying CDDB protocol version 3 in the function SetCDDBProtocolVersion.
         PJN / 13-02-2000 1. Now fully supports access when behind a HTTP proxy.
                          2. Also now includes support for proxy authentication


Copyright (c) 1999-2000 by PJ Naughter.  
All rights reserved.

*/



/////////////////////////////////  Includes  //////////////////////////////////

#include "stdafx.h"
#include <afxpriv.h>
#include <mmsystem.h>
#include "MfcCDDB.h"




//////////////////////////////// Statics / Macros /////////////////////////////

const DWORD READ_RESPONSE_QUERY = 1;
const DWORD READ_RESPONSE_SUBMIT = 2;


char CCDDB::m_base64tab[] = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
                                      "abcdefghijklmnopqrstuvwxyz0123456789+/";
#define EOL "\r\n"
const int BASE64_MAXLINE = 76;


#ifdef _DEBUG
#undef THIS_FILE
static char BASED_CODE THIS_FILE[] = __FILE__;
#define new DEBUG_NEW
#endif




////////////////////////////////// Implementation /////////////////////////////

CCDDBSite::CCDDBSite(BOOL bRetrieve)
{
  m_nPort = 80;
  m_bNorthing = TRUE;
  m_nLatitudeMinutes = 0;
  m_bEasting = TRUE;
  m_nLongitudeMinutes = 0;
  if (bRetrieve)
    m_sAddress = _T("/~cddb/cddb.cgi");
  else
    m_sAddress = _T("/~cddb/submit.cgi");
}

CCDDBSite::CCDDBSite(const CCDDBSite& site)
{
  *this = site;
}

CCDDBSite& CCDDBSite::operator=(const CCDDBSite& site)
{
  m_sSite = site.m_sSite;
  m_nPort = site.m_nPort;
  m_sAddress = site.m_sAddress;
  m_bNorthing = site.m_bNorthing;
  m_nLatitudeMinutes = site.m_nLatitudeMinutes;
  m_bEasting = site.m_bEasting;
  m_nLongitudeMinutes = site.m_nLongitudeMinutes;
  m_sDescription = site.m_sDescription;
  return *this;
}

BOOL CCDDBSite::Parse(LPSTR pszLine)
{
  LPSTR pszField = pszLine;

  //Get the site name
  LPSTR pszEnd = pszField;
  while (pszEnd[0] != ' ' && pszEnd[0] != '\0')
    ++pszEnd;
  if (pszEnd[0] == '\0')
    return FALSE;
  pszEnd[0] = '\0';
  m_sSite = pszField;
  
  //skip over the whitespace
  pszField = ++pszEnd;
  while (pszField[0] == ' ' && pszField[0] != '\0')
    ++pszField;
  if (pszField[0] == '\0')
    return FALSE;

  //Get the protocol
  pszEnd = pszField;
  while (pszEnd[0] != ' ' && pszEnd[0] != '\0')
    ++pszEnd;
  if (pszEnd[0] == '\0')
    return FALSE;
  pszEnd[0] = '\0';
  CString sProtocol = pszField;
    
  //If the protocol is not http, then ignore it
  if (sProtocol.CompareNoCase(_T("http")) != 0)
    return FALSE;

  //skip over the whitespace
  pszField = ++pszEnd;
  while (pszField[0] == ' ' && pszField[0] != '\0')
    ++pszField;
  if (pszField[0] == '\0')
    return FALSE;

  //Get the port number
  pszEnd = pszField;
  while (pszEnd[0] != ' ' && pszEnd[0] != '\0')
    ++pszEnd;
  if (pszEnd[0] == '\0')
    return FALSE;
  pszEnd[0] = '\0';
  m_nPort = ::atoi(pszField);

  //skip over the whitespace
  pszField = ++pszEnd;
  while (pszField[0] == ' ' && pszField[0] != '\0')
    ++pszField;
  if (pszField[0] == '\0')
    return FALSE;

  //Get the address
  pszEnd = pszField;
  while (pszEnd[0] != ' ' && pszEnd[0] != '\0')
    ++pszEnd;
  if (pszEnd[0] == '\0')
    return FALSE;
  pszEnd[0] = '\0';
  m_sAddress = pszField;
  
  //skip over the whitespace
  pszField = ++pszEnd;
  while (pszField[0] == ' ' && pszField[0] != '\0')
    ++pszField;
  if (pszField[0] == '\0')
    return FALSE;

  //Get the latitude  
  pszEnd = pszField;
  while (pszEnd[0] != ' ' && pszEnd[0] != '\0')
    ++pszEnd;
  if (pszEnd[0] == '\0')
    return FALSE;
  pszEnd[0] = '\0';
  
  //Latitude field must be 7 characters long
  if (strlen(pszField) != 7)
    return FALSE;

  //Parse out the northing field
  if (pszField[0] == 'N')
    m_bNorthing = TRUE;
  else if (pszField[0] == 'S')
    m_bNorthing = FALSE;
  else
    return FALSE;

  //Parse out the Latitude degrees
  char sNum[4];
  sNum[0] = pszField[1];
  sNum[1] = pszField[2];
  sNum[2] = pszField[3];
  sNum[3] = '\0';
  int nLatDeg = ::atoi(sNum);

  //Parse out the Latitude minutes
  sNum[0] = pszField[5];
  sNum[1] = pszField[6];
  sNum[2] = '\0';
  int nLatMin = ::atoi(sNum);
  m_nLatitudeMinutes = nLatMin + 60*nLatDeg;
  
  //skip over the whitespace
  pszField = ++pszEnd;
  while (pszField[0] == ' ' && pszField[0] != '\0')
    ++pszField;
  if (pszField[0] == '\0')
    return FALSE;

  //Get the longitude  
  pszEnd = pszField;
  while (pszEnd[0] != ' ' && pszEnd[0] != '\0')
    ++pszEnd;
  if (pszEnd[0] == '\0')
    return FALSE;
  pszEnd[0] = '\0';
  
  //Longitude field must be 7 characters long
  if (strlen(pszField) != 7)
    return FALSE;

  //Parse out the easting field
  if (pszField[0] == 'E')
    m_bEasting = TRUE;
  else if (pszField[0] == 'W')
    m_bEasting = FALSE;
  else
    return FALSE;

  //Parse out the Longitude degrees
  sNum[0] = pszField[1];
  sNum[1] = pszField[2];
  sNum[2] = pszField[3];
  sNum[3] = '\0';
  int nLongDeg = ::atoi(sNum);

  //Parse out the Longitude minutes
  sNum[0] = pszField[5];
  sNum[1] = pszField[6];
  sNum[2] = '\0';
  int nLongMin = ::atoi(sNum);
  m_nLongitudeMinutes = nLongMin + 60*nLongDeg;

  //skip over the whitespace
  pszField = ++pszEnd;
  while (pszField[0] == ' ' && pszField[0] != '\0')
    ++pszField;
  if (pszField[0] == '\0')
    return FALSE;

  //Whats left is put into the description field
  m_sDescription = pszField;

  //Everything has been parsed correctly
  return TRUE;
}





CCDDBQueryResult::CCDDBQueryResult()
{
  m_dwDiscID = 0;
}

CCDDBQueryResult::CCDDBQueryResult(const CCDDBQueryResult& result)
{
  *this = result;
}

CCDDBQueryResult& CCDDBQueryResult::operator=(const CCDDBQueryResult& result)
{
  m_sCategory = result.m_sCategory;
  m_dwDiscID  = result.m_dwDiscID;
  m_sArtist   = result.m_sArtist;
  m_sTitle    = result.m_sTitle;

  return *this;
}

BOOL CCDDBQueryResult::Parse(LPSTR pszLine)
{
  LPSTR pszField = pszLine;

  //Get the category
  LPSTR pszEnd = pszField;
  while (pszEnd[0] != ' ' && pszEnd[0] != '\0')
    ++pszEnd;
  if (pszEnd[0] == '\0')
    return FALSE;
  pszEnd[0] = '\0';
  m_sCategory = pszField;

  //skip over the whitespace
  pszField = ++pszEnd;
  while (pszField[0] == ' ' && pszField[0] != '\0')
    ++pszField;
  if (pszField[0] == '\0')
    return FALSE;

  //Get over the CDDB DISCID
  while (pszEnd[0] != ' ' && pszEnd[0] != '\0')
    ++pszEnd;
  if (pszEnd[0] == '\0')
    return FALSE;
  pszEnd[0] = '\0';
  sscanf(pszField, "%x", &m_dwDiscID);

  //skip over the whitespace
  pszField = ++pszEnd;
  while (pszField[0] == ' ' && pszField[0] != '\0')
    ++pszField;
  if (pszField[0] == '\0')
    return FALSE;

  //Get the Artist and Title  
  m_sTitle = pszField;

  //Remove any EOL if it is on the end
  int nEOLPos = m_sTitle.Find(_T("\r\n"));
  if (nEOLPos == -1)
    nEOLPos = m_sTitle.Find(_T("\n"));
  if (nEOLPos != -1)
    m_sTitle = m_sTitle.Left(nEOLPos);
  
  //Split into the artist and title
  int nSlashPos = m_sTitle.Find(_T('/'));
  if (nSlashPos != -1)
  {
    m_sArtist = m_sTitle.Left(nSlashPos);
    m_sTitle = m_sTitle.Right(m_sTitle.GetLength() - nSlashPos - 1);

    //Remove any trailing or leading spaces
    m_sArtist.TrimLeft();
    m_sArtist.TrimRight();
    m_sTitle.TrimLeft();
    m_sTitle.TrimRight();
  }

  return TRUE;
}





CCDDBTrackPosition::CCDDBTrackPosition()
{
  m_nMinute = 0;
  m_nSecond = 0;
  m_nFrame  = 0;
}

CCDDBTrackPosition::CCDDBTrackPosition(const CCDDBTrackPosition& position)
{
  *this = position;
}

CCDDBTrackPosition& CCDDBTrackPosition::operator=(const CCDDBTrackPosition& position)
{
  m_nMinute = position.m_nMinute;
  m_nSecond = position.m_nSecond;
  m_nFrame  = position.m_nFrame;

  return *this;
}





CHTTPSocket::CHTTPSocket()
{
  m_hSocket = INVALID_SOCKET; //default to an invalid scoket descriptor
}

CHTTPSocket::~CHTTPSocket()
{
  Close();
}

BOOL CHTTPSocket::Create()
{
  m_hSocket = socket(AF_INET, SOCK_STREAM, 0);
  return (m_hSocket != INVALID_SOCKET);
}

BOOL CHTTPSocket::Connect(LPCTSTR pszHostAddress, int nPort)
{
	//For correct operation of the T2A macro, see MFC Tech Note 59
	USES_CONVERSION;

  //must have been created first
  ASSERT(m_hSocket != INVALID_SOCKET);
  
	LPSTR lpszAscii = T2A((LPTSTR) pszHostAddress);

	//Determine if the address is in dotted notation
	SOCKADDR_IN sockAddr;
	ZeroMemory(&sockAddr, sizeof(sockAddr));
	sockAddr.sin_family = AF_INET;
	sockAddr.sin_port = htons((u_short)nPort);
	sockAddr.sin_addr.s_addr = inet_addr(lpszAscii);

	//If the address is not dotted notation, then do a DNS 
	//lookup of it.
	if (sockAddr.sin_addr.s_addr == INADDR_NONE)
	{
		LPHOSTENT lphost;
		lphost = gethostbyname(lpszAscii);
		if (lphost != NULL)
			sockAddr.sin_addr.s_addr = ((LPIN_ADDR)lphost->h_addr)->s_addr;
		else
		{
      WSASetLastError(WSAEINVAL); 
			return FALSE;
		}
	}

	//Call the protected version which takes an address 
	//in the form of a standard C style struct.
	return Connect((SOCKADDR*)&sockAddr, sizeof(sockAddr));
}

BOOL CHTTPSocket::Connect(const SOCKADDR* lpSockAddr, int nSockAddrLen)
{
	return (connect(m_hSocket, lpSockAddr, nSockAddrLen) != SOCKET_ERROR);
}

BOOL CHTTPSocket::Send(LPCSTR pszBuf, int nBuf)
{
  //must have been created first
  ASSERT(m_hSocket != INVALID_SOCKET);

  return (send(m_hSocket, pszBuf, nBuf, 0) != SOCKET_ERROR);
}

int CHTTPSocket::Receive(LPSTR pszBuf, int nBuf)
{
  //must have been created first
  ASSERT(m_hSocket != INVALID_SOCKET);

  return recv(m_hSocket, pszBuf, nBuf, 0); 
}

void CHTTPSocket::Close()
{
	if (m_hSocket != INVALID_SOCKET)
	{
		VERIFY(SOCKET_ERROR != closesocket(m_hSocket));
		m_hSocket = INVALID_SOCKET;
	}
}

BOOL CHTTPSocket::IsReadible(BOOL& bReadible)
{
  timeval timeout = {0, 0};
  fd_set fds;
  FD_ZERO(&fds);
  FD_SET(m_hSocket, &fds);
  int nStatus = select(0, &fds, NULL, NULL, &timeout);
  if (nStatus == SOCKET_ERROR)
  {
    return FALSE;
  }
  else
  {
    bReadible = !(nStatus == 0);
    return TRUE;
  }
}



CCDDBRecord::CCDDBRecord()
{
  m_nDiskLength = 0;
  m_nDatabaseRevision = 0;
  m_dwDiscID = 0;
}

CCDDBRecord::CCDDBRecord(const CCDDBRecord& record)
{
  *this = record;
}

CCDDBRecord& CCDDBRecord::operator=(const CCDDBRecord& result)
{
  m_TrackOffsets.Copy(result.m_TrackOffsets);
  m_nDiskLength = result.m_nDiskLength;
  m_nDatabaseRevision = result.m_nDatabaseRevision;
  m_sClientName = result.m_sClientName;
  m_sClientVersion = result.m_sClientVersion;
  m_sClientComments = result.m_sClientComments;
  m_dwDiscID = result.m_dwDiscID;
  m_sArtist = result.m_sArtist;
  m_sTitle = result.m_sTitle;
  m_TrackTitles.Copy(result.m_TrackTitles);
  m_ExtendedData.Copy(result.m_ExtendedData);
  m_ExtendedTrackData.Copy(result.m_ExtendedTrackData);
  m_PlayOrder.Copy(result.m_PlayOrder);

  return *this;
}




CCDDB::CCDDB() : m_sProductName(_T("MfcCDDB")), m_sProductVersion(_T("1.15"))
{
  m_dwLastError = 0;
#ifdef _DEBUG
  m_dwTimeout = 60000; //timeout is set to 60 seconds for debug
#else
  m_dwTimeout = 2000; //2 seconds for release builds
#endif
  m_nProtocolVersion = 4;
  m_nProxyPort = 80;
}

CCDDB::~CCDDB()
{
}

DWORD CCDDB::GetLastError() const 
{ 
  if (m_dwLastError)
    return m_dwLastError; 
  else
    return ::GetLastError();
}

void CCDDB::SetCDDBProtocolVersion(int nProtocolVersion) 
{
  ASSERT(nProtocolVersion == 3 || nProtocolVersion == 4); //MfcCDDB source code only supports v3 and v4.
  m_nProtocolVersion = nProtocolVersion; 
}

CString CCDDB::GetErrorMessage() const
{
  CString sError;
  if (m_dwLastError)
  {
    TCHAR sMessage[129];
    mciGetErrorString(m_dwLastError, sMessage, 128);
    sError = sMessage;
  }
  else
  {
    //Use the SDK function ::FormatMessage to create a string for us
	  LPTSTR lpBuffer = NULL;
    DWORD dwLastError = ::GetLastError();
    BOOL bSuccess = ::FormatMessage(FORMAT_MESSAGE_ALLOCATE_BUFFER | FORMAT_MESSAGE_FROM_SYSTEM | FORMAT_MESSAGE_FROM_HMODULE, 
			                              NULL, dwLastError, MAKELANGID(LANG_NEUTRAL, SUBLANG_SYS_DEFAULT), (LPTSTR) &lpBuffer, 0, NULL);
	  if (bSuccess)
	  {
		  sError = lpBuffer;

      //Don't forget to free the memory ::FormatMessage allocated for us
		  LocalFree(lpBuffer);
	  }
    else
    {
      //Restore the error if FormatMessage failed
      SetLastError(dwLastError);
    }
  }

  return sError;
}

DWORD CCDDB::ComputeDiscID(const CArray<CCDDBTrackPosition, CCDDBTrackPosition&>& tracks)
{
  int nTracks = tracks.GetSize() - 1; //Number of tracks is 1 less than the size
                                      //of the array as it also contains the lead 
                                      //out position
  //Validate our parameters
  ASSERT(nTracks > 0);

  //Iterate across all the tracks
  int n=0;
  for (int i=0; i<nTracks; i++)
  {
    int sum = 0;
    int j = tracks[i].m_nMinute*60 + tracks[i].m_nSecond;
    while (j > 0)
    {
      sum += j%10;
      j /=10;
    }
    n += sum;
  }

  //Compute total track length in seconds
  int t = tracks[nTracks].m_nMinute*60 + tracks[nTracks].m_nSecond - tracks[0].m_nMinute - tracks[0].m_nSecond;

  //Compute DISC ID
  DWORD dwDiscID = ((n % 0xFF) << 24 | t << 8 | nTracks);
  return dwDiscID;
}

BOOL CCDDB::GetTrackPositions(CArray<CCDDBTrackPosition, CCDDBTrackPosition&>& tracks, LPCTSTR pszDrive)
{
  //Remove any tracks already in the array
  tracks.RemoveAll();

  //Open the specified "cdaudio" MCI device
  MCI_OPEN_PARMS mciOpenParms;
  mciOpenParms.lpstrDeviceType = _T("cdaudio");
  mciOpenParms.lpstrElementName = pszDrive;
  m_dwLastError = ::mciSendCommand(0, MCI_OPEN, MCI_OPEN_SHAREABLE | MCI_OPEN_TYPE | (pszDrive ? MCI_OPEN_ELEMENT : 0), (DWORD) &mciOpenParms);
  if (m_dwLastError)
  {
    TRACE(_T("Failed to open the cdaudio MCI device, GetLastError:%d, %s\n"), GetLastError(), GetErrorMessage());
    return FALSE;
  }

  //Set the time format to Minute/Second/Frame (MSF) format
  MCI_SET_PARMS mciSetParms;
  mciSetParms.dwTimeFormat = MCI_FORMAT_MSF;
  m_dwLastError = ::mciSendCommand(mciOpenParms.wDeviceID, MCI_SET, MCI_SET_TIME_FORMAT, (DWORD) &mciSetParms);
  if (m_dwLastError)
  {
    //Dont forget to close the MCI device
    ::mciSendCommand(mciOpenParms.wDeviceID, MCI_CLOSE, 0, 0);

    TRACE(_T("Failed to set cdaudio MCI device to MSF format, GetLastError:%d, %s\n"), GetLastError(), GetErrorMessage());
    return FALSE;
  }

  //Get the total track count
  MCI_STATUS_PARMS mciStatusParms;
  mciStatusParms.dwItem = MCI_STATUS_NUMBER_OF_TRACKS;
  m_dwLastError = ::mciSendCommand(mciOpenParms.wDeviceID, MCI_STATUS, MCI_STATUS_ITEM, (DWORD) &mciStatusParms);
  if (m_dwLastError)
  {
    //Dont forget to close the MCI device
    ::mciSendCommand(mciOpenParms.wDeviceID, MCI_CLOSE, 0, 0);

    TRACE(_T("Failed to get number of cdaudio tracks, GetLastError:%d, %s\n"), GetLastError(), GetErrorMessage());
    return FALSE;
  }

  //Iterate through all the tracks getting their starting position
  int nTotalTracks = (int) mciStatusParms.dwReturn;
  tracks.SetSize(nTotalTracks + 1);
  for (int i=1; i<=nTotalTracks; i++)
  {                      
    mciStatusParms.dwItem = MCI_STATUS_POSITION;
    mciStatusParms.dwTrack = i;
    m_dwLastError = mciSendCommand(mciOpenParms.wDeviceID, MCI_STATUS, MCI_STATUS_ITEM | MCI_TRACK, (DWORD) &mciStatusParms);
    if (m_dwLastError)
    {
      //Dont forget to close the MCI device
      ::mciSendCommand(mciOpenParms.wDeviceID, MCI_CLOSE, 0, 0);

      //Remove all the fields if we have an error getting any of the tracks
      tracks.RemoveAll();

      TRACE(_T("Failed to get track %d's starting position, GetLastError:%d, %s\n"), GetLastError(), GetErrorMessage());
      return FALSE;
    }

    //Save the track position in MSF format
    CCDDBTrackPosition trackPosition;
    trackPosition.m_nMinute = MCI_MSF_MINUTE(mciStatusParms.dwReturn);
    trackPosition.m_nSecond = MCI_MSF_SECOND(mciStatusParms.dwReturn);
    trackPosition.m_nFrame  = MCI_MSF_FRAME(mciStatusParms.dwReturn);

    //Store the value in the array
    tracks.SetAt(i-1, trackPosition);
  }

  //Get the last track's length
  mciStatusParms.dwItem = MCI_STATUS_LENGTH;
  mciStatusParms.dwTrack = nTotalTracks;
  m_dwLastError = mciSendCommand(mciOpenParms.wDeviceID, MCI_STATUS, MCI_STATUS_ITEM | MCI_TRACK, (DWORD) &mciStatusParms);
  if (m_dwLastError)
  {
    //Dont forget to close the MCI device
    ::mciSendCommand(mciOpenParms.wDeviceID, MCI_CLOSE, 0, 0);

    //Remove all the fields if we have an error getting any of the tracks
    tracks.RemoveAll();

    TRACE(_T("Failed to get track %d's length, GetLastError:%d, %s\n"), GetLastError(), GetErrorMessage());
    return FALSE;
  }


  //Compute lead-out track position

  DWORD dwLenM = MCI_MSF_MINUTE(mciStatusParms.dwReturn);
  DWORD dwLenS = MCI_MSF_SECOND(mciStatusParms.dwReturn);
  DWORD dwLenF = MCI_MSF_FRAME(mciStatusParms.dwReturn) + 1; //Fix MCI Windows bug according to CDDB Howto doc
  DWORD dwPosM = tracks[nTotalTracks-1].m_nMinute;
  DWORD dwPosS = tracks[nTotalTracks-1].m_nSecond;
  DWORD dwPosF = tracks[nTotalTracks-1].m_nFrame;

  //Compute lead out track position (in frame format)
  DWORD dwPos = (dwPosM*60*75) + (dwPosS*75) + dwPosF + (dwLenM*60*75) + (dwLenS*75) + dwLenF;

  //Convert dwPos back to MSF format
  CCDDBTrackPosition trackPosition;
  trackPosition.m_nFrame = dwPos % 75;
  dwPos /= 75;
  trackPosition.m_nSecond = dwPos % 60;
  dwPos /= 60;
  trackPosition.m_nMinute = dwPos;

  //And store in the array
  tracks.SetAt(nTotalTracks, trackPosition);

  //Dont forget to close the MCI device
  ::mciSendCommand(mciOpenParms.wDeviceID, MCI_CLOSE, 0, 0);

  return TRUE;
}

BOOL CCDDB::ComputeDiscID(DWORD& dwDiscID, LPCTSTR pszDrive)
{
  //Get the track details
  CArray<CCDDBTrackPosition, CCDDBTrackPosition&> tracks;
  if (!GetTrackPositions(tracks, pszDrive))
    return FALSE;
  
  //Compute the DISC ID now that we have got all the track information
  dwDiscID = ComputeDiscID(tracks);
  
  return TRUE;    
}
    
void CCDDB::GetCDROMDrives(CStringArray& drives)
{
  //empty out the array
  drives.RemoveAll();

  //Iterate across all the drive letters to find out which ones are CDROMs
  for (int i=1; i<=26; i++)
  {
    CString sDrive;
    sDrive.Format(_T("%c:"), i-1+'A');
    if (GetDriveType(sDrive) == DRIVE_CDROM)
      drives.Add(sDrive);
  }
}

BOOL CCDDB::ReadResponse(CHTTPSocket& socket, LPSTR pszBuffer, int nInitialBufSize, LPSTR pszTerminator, LPSTR* ppszOverFlowBuffer, int nGrowBy, DWORD dwHint)
{
  ASSERT(ppszOverFlowBuffer);          //Must have a valid string pointer
  ASSERT(*ppszOverFlowBuffer == NULL); //Initially it must point to a NULL string

  //The local variables which will receive the data
  LPSTR pszRecvBuffer = pszBuffer;
  int nBufSize = nInitialBufSize;
  
  //Retrieve the reponse using until we
	//get the terminator or a timeout occurs
	BOOL bFoundTerminator = FALSE;
  BOOL bContinue = TRUE;
	int nReceived = 0;
	DWORD dwStartTicks = ::GetTickCount();
	while (!bFoundTerminator && bContinue)
	{
		//Has the timeout occured
		if ((::GetTickCount() - dwStartTicks) >	m_dwTimeout)
		{
      if (pszRecvBuffer && nReceived)
      {
		    pszRecvBuffer[nReceived] = '\0';
        m_sLastCommandResponse = pszRecvBuffer; //Hive away the last command reponse
      }
      SetLastError(WSAETIMEDOUT);
      m_dwLastError = 0;
			return FALSE;
		}

    //check the socket for readability
    BOOL bReadible;
    if (!socket.IsReadible(bReadible))
    {
      if (pszRecvBuffer && nReceived)
      {
	      pszRecvBuffer[nReceived] = '\0';
        m_sLastCommandResponse = pszRecvBuffer; //Hive away the last command reponse
      }
      m_dwLastError = 0;
			return FALSE;
    }
    else if (!bReadible) //no data to receive, just loop around
    {
      Sleep(250); //Sleep for a while before we loop around again
      continue;
    }

		//receive the data from the socket
    int nBufRemaining = nBufSize-nReceived-1; //Allows allow one space for the NULL terminator
    if (nBufRemaining<0)
      nBufRemaining = 0;
	  int nData = socket.Receive(pszRecvBuffer+nReceived, nBufRemaining);

    if (nData)
    {
      //Reset the idle timeout if data was received
			dwStartTicks = ::GetTickCount();

      //Increment the count of data received
		  nReceived += nData;							   
    }

    //If an error occurred receiving the data
		if (nData == SOCKET_ERROR)
		{
      //NULL terminate the data received
      if (pszRecvBuffer)
		    pszBuffer[nReceived] = '\0';

      m_dwLastError = 0;
      m_sLastCommandResponse = pszRecvBuffer; //Hive away the last command reponse
		  return FALSE; 
		}
		else
		{
      //NULL terminate the data received
      if (pszRecvBuffer)
		    pszRecvBuffer[nReceived] = '\0';

      if (nBufRemaining-nData == 0) //No space left in the current buffer
      {
        //Allocate the new receive buffer
        nBufSize += nGrowBy; //Grow the buffer by the specified amount
        LPSTR pszNewBuf = new char[nBufSize];   
        pszNewBuf[0] = '\0'; //Initially NULL terminate the data

        //copy the old contents over to the new buffer and assign 
        //the new buffer to the local variable used for Retrieveing 
        //from the socket
        if (pszRecvBuffer)
          strcpy(pszNewBuf, pszRecvBuffer);
        pszRecvBuffer = pszNewBuf;

        //delete the old buffer if it was allocated
        if (*ppszOverFlowBuffer)
          delete [] *ppszOverFlowBuffer;
        
        //Remember the overflow buffer for the next time around
        *ppszOverFlowBuffer = pszNewBuf;        
      }
		}

    //Special case code for reading a Query response
    if (dwHint == READ_RESPONSE_QUERY)
    {
      if (pszRecvBuffer && strlen(pszRecvBuffer))
      {
        //Extract the HTTP body from the response;
        LPSTR pszBody = FindHTTPBody(pszRecvBuffer);

        //From the HTTP body get the CDDB response code
        int nResponseCode = GetCDDBReponseCode(pszBody);

        //Only continue to receive data if the response code indicates more data is to be received
        if ((nResponseCode < 210 || nResponseCode > 219))
          bContinue = FALSE;          
      }
    }
    else if (dwHint == READ_RESPONSE_SUBMIT)    //Special case code for reading a submit response
    {
      if (pszRecvBuffer && strlen(pszRecvBuffer))
      {
        //Extract the HTTP body from the response;
        LPSTR pszBody = FindHTTPBody(pszRecvBuffer);

        //From the HTTP body get the CDDB response code
        int nResponseCode = GetCDDBReponseCode(pszBody);

        //Only continue to receive data if the response code indicates more data is to be received
        if ((nResponseCode < 210 || nResponseCode > 219))
          bContinue = FALSE;          
      }
    }


    //Check to see if the terminator character(s) have been found
		bFoundTerminator = (strstr(pszRecvBuffer, pszTerminator) != NULL);
	}

	//Remove the terminator from the response data
  if (bFoundTerminator)
    pszRecvBuffer[nReceived - strlen(pszTerminator)] = '\0';

  return TRUE;
}

CString CCDDB::GetUserName()
{
  //Get the user name 
  TCHAR sComputerName[_MAX_PATH];
  DWORD dwSize = _MAX_PATH;
  ::GetUserName(sComputerName, &dwSize);

  return sComputerName;
}

CString CCDDB::GetHostName()
{
  CString sHost;
  char pszHost[_MAX_PATH];
  if (gethostname(pszHost, _MAX_PATH) == 0)
    sHost = pszHost;
  return sHost;
}

CString CCDDB::GetHelloCommand()
{
  CString sCommand;
  sCommand.Format(_T("hello=%s+%s+%s+%s&proto=%d"), GetUserName(), GetHostName(), m_sProductName, m_sProductVersion, m_nProtocolVersion);
  return sCommand;
}

LPSTR CCDDB::FindHTTPBody(LPCSTR pszResponse)
{
  //Validate our parameters
  ASSERT(pszResponse);
  ASSERT(strlen(pszResponse));

  //Find the HTTP body
  LPSTR pszData = strstr(pszResponse, "\r\n\r\n");
  
  //If found, skip over the 2 lines
  if (pszData)
    pszData += 4;

  return pszData;  
}

LPSTR CCDDB::SkipToNextLine(LPSTR pszLine)
{
  //Validate our parameters
  ASSERT(pszLine);

  //Find the next line. Both Dos (\r\n) 
  //and Unix (\n) terminators are valid. First try to
  //find a DOS EOL
  LPSTR lpszData = strstr(pszLine, "\r\n");
  if (lpszData)
    lpszData += 2;
  else
  {
    lpszData = strstr(pszLine, "\n");
    if (lpszData)
      lpszData++;
  }

  return lpszData;  
}

LPSTR CCDDB::GetNextLine(LPSTR pszLine)
{
  //validate our parameters
  ASSERT(pszLine);
  ASSERT(strlen(pszLine));

  //Find the start of the next line. Both Dos (\r\n) 
  //and Unix (\n) terminators are valid. First try to
  //find a DOS EOL
  LPSTR pszNextLine = strstr(pszLine, "\r\n");
  if (pszNextLine)
  {
    LPSTR pszEnd = pszNextLine;  
    pszNextLine = pszNextLine + 2;
    pszEnd[0] = '\0';
  }
  else
  {
    //Failed to get a DOS EOL, try to get a Unix EOL
    pszNextLine = strstr(pszLine, "\n");
    if (pszNextLine)
    {
      LPSTR pszEnd = pszNextLine;  
      pszNextLine = pszNextLine + 1;
      pszEnd[0] = '\0';
    }
  }

  return pszNextLine;
}

int CCDDB::GetCDDBReponseCode(LPSTR pszBody)
{
  //Validate out parameters
  ASSERT(pszBody);
  ASSERT(strlen(pszBody));

  int nResponse = -1;
  int nLength = strlen(pszBody);
  if (nLength >= 3)
  {
    char sNum[4];
    strncpy(sNum, pszBody, 3);
    sNum[3] = '\0';
    nResponse = atoi(sNum);
  }
  return nResponse;
}

BOOL CCDDB::ParseCommentLine(LPCSTR pszLine, CString& sValue)
{
  //Validate out parameters
  ASSERT(pszLine);

  //Duplicate the string into a local variable 
  int nLength = strlen(pszLine);
  LPSTR pszData = new char[nLength + 1];
  strcpy(pszData, pszLine);
  
  //Do the actual parsing
  BOOL bSuccess = FALSE;
  if (pszData[0] == '#')
  {
    sValue.Empty();
    bSuccess = TRUE;

    char* pszValue = pszData+1;
    if (strlen(pszValue) > 1)
    {
      sValue = pszValue;

      //Remove unwanted spaces 
      sValue.TrimLeft();
      sValue.TrimRight();
    }
  }

  //Dont forget to delete our local string
  delete [] pszData;

  return bSuccess;
}

BOOL CCDDB::SplitSemiColonLine(LPCSTR pszLine, CString& sField, CString& sValue)
{
  //Validate out parameters
  ASSERT(pszLine);
  
  //Duplicate the string into a local variable 
  int nLength = strlen(pszLine);
  LPSTR pszData = new char[nLength + 1];
  strcpy(pszData, pszLine);

  //Do the actual parsing
  BOOL bSuccess = FALSE;
  LPSTR pszColon = strstr(pszData, ":");
  if (pszColon)
  {
    pszColon[0] = '\0';
    if (strlen(pszData) && strlen(pszColon+1) > 1)
    {
      sField = pszData;
      sValue = pszColon+1;

      //Remove unwanted spaces 
      sField.TrimLeft();
      sField.TrimRight();
      sValue.TrimLeft();
      sValue.TrimRight();
      bSuccess = TRUE;
    }
  }

  //Dont forget to delete our local string
  delete [] pszData;

  return bSuccess;
}

BOOL CCDDB::Sites(CArray<CCDDBSite, CCDDBSite&>& sites, const CCDDBSite& server)
{
	//For correct operation of the T2A macro, see MFC Tech Note 59
	USES_CONVERSION;

  BOOL bSuccess = FALSE;

  //Create the socket
  CHTTPSocket socket;
  if (!socket.Create())
  {
    m_dwLastError = 0;
    TRACE(_T("Failed to create client socket for sites command, GetLastError:%d, %s\n"), GetLastError(), GetErrorMessage());
    return FALSE;
  }

  //Connect to the host on the specified port
  BOOL bUseProxy = !m_sProxyHost.IsEmpty();
  if (!socket.Connect(bUseProxy ? m_sProxyHost : server.m_sSite, bUseProxy ? m_nProxyPort : server.m_nPort))
  {
    m_dwLastError = 0;
    TRACE(_T("Could not connect to the CDDB HTTP server %s, GetLastError:%d, %s\n"), server.m_sSite, GetLastError(), GetErrorMessage());
    return FALSE;
  }
  else
  {
    //Form the specialized HTTP request to retrieve the sites data
    CString sRequest;
    if (!bUseProxy)
      sRequest.Format(_T("GET %s?cmd=sites&%s HTTP/1.0\r\n\r\n"), server.m_sAddress, GetHelloCommand());
    else
      sRequest.Format(_T("GET http://%s?cmd=sites&%s HTTP/1.0\r\n%s\r\n\r\n"), server.m_sSite+server.m_sAddress, GetHelloCommand(), GetProxyHeader(server.m_sSite));

    //Send the request through the socket
    LPCSTR pszRequest = T2A((LPTSTR) (LPCTSTR) sRequest);
    int nCmdLength = strlen(pszRequest);
    if (!socket.Send(pszRequest, nCmdLength))
    {
      m_dwLastError = 0;
      TRACE(_T("An unexpected error occurred while sending the HTTP sites request, GetLastError:%d, %s\n"), GetLastError(), GetErrorMessage());
      return FALSE;
    }
    
    //Read the response back through the socket
    LPSTR pszOverFlowBuffer = NULL;
    if (ReadResponse(socket, NULL, 0, "\r\n.\r\n", &pszOverFlowBuffer))
    {
      ASSERT(pszOverFlowBuffer);

      //Extract the HTTP body from the response;
      LPSTR pszBody = FindHTTPBody(pszOverFlowBuffer);

      //Parse the sites info from the response
      bSuccess = ParseSitesBody(pszBody, sites);
    }
    else
    {
      //Reponse could not be retrieved
      m_dwLastError = 0;
      SetLastError(WSAEPROTONOSUPPORT);
    	TRACE(_T("CDDB server did not respond correctly to the sites command\n"));
    }

    //Don't forget to delete the allocated buffer
    if (pszOverFlowBuffer)
      delete [] pszOverFlowBuffer;

    return bSuccess;
  }
}

BOOL CCDDB::ParseSitesBody(LPSTR pszBody, CArray<CCDDBSite, CCDDBSite&>& sites)
{
  //setup return value
  BOOL bSuccess = FALSE;

  //Hive away the last reponse until everything is ok
  m_sLastCommandResponse = pszBody;

  //From the HTTP body get the CDDB response code
  int nResponseCode = GetCDDBReponseCode(pszBody);

  //If the response is in the expected range (21x) then parse the site data line by line
  if (nResponseCode >= 210 && nResponseCode <= 219)
  {
    //Remove any entries which are in the sites array
    sites.RemoveAll();

    //Get the site data and then iterate through all the lines
    LPSTR pszLine = SkipToNextLine(pszBody);
    while (pszLine)
    {
      //Get the next line before we parse the current line
      LPSTR pszNextLine = GetNextLine(pszLine);

      //If we can parse the current line then add it 
      //to the sites array
      CCDDBSite site;
      if (site.Parse(pszLine))
        sites.Add(site);
    
      //Move on to the next line  
      pszLine = pszNextLine;
    }

    //Everything is successful, empty out the last command reponse string
    m_sLastCommandResponse.Empty();
    bSuccess = TRUE;
  }
  else
  {
    //An unexpected response was retrieved
    m_dwLastError = 0;
    SetLastError(WSAEPROTONOSUPPORT);
    TRACE(_T("CDDB server failed to return a valid sites response code\n"));
  }

  return bSuccess;
}

BOOL CCDDB::Sites(CArray<CCDDBSite, CCDDBSite&>& sites, const CString& sServer, const CString& sAddress, int nPort)
{
  //Form the site which we will be querying
  CCDDBSite server;
  server.m_sSite = sServer;
  server.m_nPort = nPort;
  server.m_sAddress = sAddress;
  
  //Let the other version 
  return Sites(sites, server);
}

BOOL CCDDB::Categories(const CCDDBSite& server, CStringArray& categories)
{
	//For correct operation of the T2A macro, see MFC Tech Note 59
	USES_CONVERSION;

  BOOL bSuccess = FALSE;

  //Create the socket
  CHTTPSocket socket;
  if (!socket.Create())
  {
    m_dwLastError = 0;
    TRACE(_T("Failed to create client socket for categories command, GetLastError:%d, %s\n"), GetLastError(), GetErrorMessage());
    return FALSE;
  }

  //Connect to the host on the specified port
  BOOL bUseProxy = !m_sProxyHost.IsEmpty();
  if (!socket.Connect(bUseProxy ? m_sProxyHost : server.m_sSite, bUseProxy ? m_nProxyPort : server.m_nPort))
  {
    m_dwLastError = 0;
    TRACE(_T("Could not connect to the CDDB HTTP server %s, GetLastError:%d, %s\n"), server.m_sSite, GetLastError(), GetErrorMessage());
    return FALSE;
  }
  else
  {
    //Form the specialized HTTP request to retreive the sites data
    CString sRequest;
    if (!bUseProxy)
      sRequest.Format(_T("GET %s?cmd=cddb+lscat&%s HTTP/1.0\r\n\r\n"), server.m_sAddress, GetHelloCommand());
    else
      sRequest.Format(_T("GET http://%s?cmd=cddb+lscat&%s HTTP/1.0\r\n%s\r\n\r\n"), server.m_sSite+server.m_sAddress, GetHelloCommand(), GetProxyHeader(server.m_sSite));

    //Send the request through the socket
    LPCSTR pszRequest = T2A((LPTSTR) (LPCTSTR) sRequest);
    int nCmdLength = strlen(pszRequest);
    if (!socket.Send(pszRequest, nCmdLength))
    {
      m_dwLastError = 0;
      TRACE(_T("An unexpected error occurred while sending the HTTP categories request, GetLastError:%d, %s\n"), GetLastError(), GetErrorMessage());
      return FALSE;
    }
    
    //Read the response back through the socket
    LPSTR pszOverFlowBuffer = NULL;
    if (ReadResponse(socket, NULL, 0, "\r\n.\r\n", &pszOverFlowBuffer))
    {
      ASSERT(pszOverFlowBuffer);

      //Extract the HTTP body from the response;
      LPSTR pszBody = FindHTTPBody(pszOverFlowBuffer);

      //Parse the categories info from the response
      bSuccess = ParseCategoriesBody(pszBody, categories);
    }
    else
    {
      //Reponse could not be Retrieved
      m_dwLastError = 0;
      SetLastError(WSAEPROTONOSUPPORT);
    	TRACE(_T("CDDB server did not respond correctly to the categories command\n"));
    }

    //Don't forget to delete the allocated buffer
    if (pszOverFlowBuffer)
      delete [] pszOverFlowBuffer;

    return bSuccess;
  }
}

BOOL CCDDB::ParseCategoriesBody(LPSTR pszBody, CStringArray& categories)
{
  //setup return value
  BOOL bSuccess = FALSE;

  //Hive away the last reponse until everything is ok
  m_sLastCommandResponse = pszBody;

  //From the HTTP body get the CDDB response code
  int nResponseCode = GetCDDBReponseCode(pszBody);

  //If the response is in the expected range (21x) then parse the categories data line by line
  if (nResponseCode >= 210 && nResponseCode <= 219)
  {
    //Remove any entries which are in the sites array
    categories.RemoveAll();

    //Get the category data and then iterate through all the lines
    LPSTR pszLine = SkipToNextLine(pszBody);
    while (pszLine)
    {
      //Get the next line before we parse the current line
      LPSTR pszNextLine = GetNextLine(pszLine);

      //Add the current line to the categories array
      CString sCategory(pszLine);
      categories.Add(sCategory);
      
      //Move on to the next line  
      pszLine = pszNextLine;
    }

    //Everything is successful, empty out the last command reponse string
    m_sLastCommandResponse.Empty();
    bSuccess = TRUE;
  }
  else
  {
    //An unexpected response was Retrieved
    m_dwLastError = 0;
    SetLastError(WSAEPROTONOSUPPORT);
    TRACE(_T("CDDB server failed to return a valid response code to the categories command\n"));
  }

  return bSuccess;
}

BOOL CCDDB::Status(const CCDDBSite& server, CCDDBStatus& status)
{
	//For correct operation of the T2A macro, see MFC Tech Note 59
	USES_CONVERSION;

  BOOL bSuccess = FALSE;

  //Create the socket
  CHTTPSocket socket;
  if (!socket.Create())
  {
    m_dwLastError = 0;
    TRACE(_T("Failed to create client socket for status command, GetLastError:%d, %s\n"), GetLastError(), GetErrorMessage());
    return FALSE;
  }

  //Connect to the host on the specified port
  BOOL bUseProxy = !m_sProxyHost.IsEmpty();
  if (!socket.Connect(bUseProxy ? m_sProxyHost : server.m_sSite, bUseProxy ? m_nProxyPort : server.m_nPort))
  {
    m_dwLastError = 0;
    TRACE(_T("Could not connect to the CDDB HTTP server %s, GetLastError:%d, %s\n"), server.m_sSite, GetLastError(), GetErrorMessage());
    return FALSE;
  }
  else
  {
    //Form the specialized HTTP request to retreive the status data
    CString sRequest;
    if (!bUseProxy)
      sRequest.Format(_T("GET %s?cmd=stat&%s HTTP/1.0\r\n\r\n"), server.m_sAddress, GetHelloCommand());
    else
      sRequest.Format(_T("GET http://%s?cmd=stat&%s HTTP/1.0\r\n%s\r\n\r\n"), server.m_sSite+server.m_sAddress, GetHelloCommand(), GetProxyHeader(server.m_sSite));

    //Send the request through the socket
    LPCSTR pszRequest = T2A((LPTSTR) (LPCTSTR) sRequest);
    int nCmdLength = strlen(pszRequest);
    if (!socket.Send(pszRequest, nCmdLength))
    {
      m_dwLastError = 0;
      TRACE(_T("An unexpected error occurred while sending the HTTP stat request, GetLastError:%d, %s\n"), GetLastError(), GetErrorMessage());
      return FALSE;
    }

    //Read the response back through the socket
    LPSTR pszOverFlowBuffer = NULL;
    if (ReadResponse(socket, NULL, 0, "\r\n.\r\n", &pszOverFlowBuffer))
    {
      ASSERT(pszOverFlowBuffer);

      //Extract the HTTP body from the response;
      LPSTR pszBody = FindHTTPBody(pszOverFlowBuffer);

      //Parse out the status from the body
      bSuccess = ParseStatusBody(pszBody, status);
    }
    else
    {
      //Reponse could not be Retrieved
      m_dwLastError = 0;
      SetLastError(WSAEPROTONOSUPPORT);
    	TRACE(_T("CDDB server did not respond correctly to the stat command\n"));
    }

    //Don't forget to delete the allocated buffer
    if (pszOverFlowBuffer)
      delete [] pszOverFlowBuffer;

    return bSuccess;
  }
}

BOOL CCDDB::ParseStatusBody(LPSTR pszBody, CCDDBStatus& status)
{
  //setup return value
  BOOL bSuccess = FALSE;

  //Hive away the last reponse until everything is ok
  m_sLastCommandResponse = pszBody;

  //From the HTTP body get the CDDB response code
  int nResponseCode = GetCDDBReponseCode(pszBody);

  //If the response is in the expected range (21x) then parse the status info line by line
  if (nResponseCode >= 210 && nResponseCode <= 219)
  {
    //Empty out all the arrays in case they already have something in them
    status.m_Categories.RemoveAll();
    status.m_CategoryEntries.RemoveAll();
    status.m_PendingSites.RemoveAll();
    status.m_PendingEntries.RemoveAll();

    //Get ready for parsing all the fields
    LPSTR pszNextLine;

    //Skip over the first two status lines
    LPSTR pszCurLine = SkipToNextLine(pszBody);
    if (pszCurLine)
      pszCurLine = SkipToNextLine(pszCurLine);

    //iterate through all the data  
    BOOL bContinue = TRUE;
    while (pszCurLine && bContinue)
    {
      //Get the next line before we parse the current one
      pszNextLine = GetNextLine(pszCurLine);
      if (pszNextLine == NULL)
        bContinue = FALSE;

      //Parse each line
      CString sField;
      CString sValue;

      if (strcmp(pszCurLine, "Database entries by category:") == 0)
      {
        //Skip over the heading line  
        pszCurLine = pszNextLine;

        //Handle the database entries
        BOOL bMoreEntries = (pszCurLine != NULL);
        while (bMoreEntries)
        {
          //Get the next line before we parse the current one
          pszNextLine = GetNextLine(pszCurLine);
          if (pszNextLine == NULL)
            bMoreEntries = FALSE;

          //Parse the category info
          if (pszCurLine[0] == ' ')
          {
            if (SplitSemiColonLine(pszCurLine, sField, sValue))
            {
              status.m_Categories.Add(sField);
              int nValue = _ttoi(sValue);
              status.m_CategoryEntries.Add(nValue);
            }
          }
          else
            bMoreEntries = FALSE;

          pszCurLine = pszNextLine;
        }
      }
      else if (strcmp(pszCurLine, "Pending File transmissions:") == 0)
      {
        //Skip over the heading line  
        pszCurLine = pszNextLine;

        //Handle the database entries
        BOOL bMoreSites = (pszCurLine != NULL);
        while (bMoreSites)
        {
          //Get the next line before we parse the current one
          pszNextLine = GetNextLine(pszCurLine);
          if (pszNextLine == NULL)
            bMoreSites = FALSE;

          //Parse the pending sites info
          if (pszCurLine[0] == ' ')
          {
            if (SplitSemiColonLine(pszCurLine, sField, sValue))
            {
              status.m_PendingSites.Add(sField);
              int nValue = _ttoi(sValue);
              status.m_PendingEntries.Add(nValue);
            }
          }
          else
            bMoreSites = FALSE;

          pszCurLine = pszNextLine;
        }
      }

      //Parse out the other types of field
      if (pszCurLine)
      {
        if (SplitSemiColonLine(pszCurLine, sField, sValue))
        {
          if (sField == _T("current proto"))
            status.m_nCurrentProtocol = _ttoi(sValue);  
          else if (sField == _T("max proto"))
            status.m_nMaxProtocol = _ttoi(sValue);
          else if (sField == _T("gets"))
          {
            if (sValue == _T("yes"))
              status.m_bGetsAllowed = TRUE;
            else if (sValue == _T("no"))
              status.m_bGetsAllowed = FALSE;
            else
            {
              bContinue = FALSE;
              m_dwLastError = 0;
              SetLastError(WSAEPROTONOSUPPORT);
    		      TRACE(_T("CDDB server failed to return a valid gets response to the stat command\n"));
            }
          }
          else if (sField == _T("updates"))
          {
            if (sValue == _T("yes"))
              status.m_bUpdatesAllowed = TRUE;
            else if (sValue == _T("no"))
              status.m_bUpdatesAllowed = FALSE;
            else
            {
              bContinue = FALSE;
              m_dwLastError = 0;
              SetLastError(WSAEPROTONOSUPPORT);
    		      TRACE(_T("CDDB server failed to return a valid updates response to the stat command\n"));
            }
          }
          else if (sField == _T("posting"))
          {
            if (sValue == _T("yes"))
              status.m_bPostingAllowed = TRUE;
            else if (sValue == _T("no"))
              status.m_bPostingAllowed = FALSE;
            else
            {
              bContinue = FALSE;
              m_dwLastError = 0;
              SetLastError(WSAEPROTONOSUPPORT);
    		      TRACE(_T("CDDB server failed to return a valid posting response to the stat command\n"));
            }
          }
          else if (sField == _T("quotes"))
          {
            if (sValue == _T("yes"))
              status.m_bQuotes = TRUE;
            else if (sValue == _T("no"))
              status.m_bQuotes = FALSE;
            else
            {
              bContinue = FALSE;
              m_dwLastError = 0;
              SetLastError(WSAEPROTONOSUPPORT);
    		      TRACE(_T("CDDB server failed to return a valid quotes response to the stat command\n"));
            }
          }
          else if (sField == _T("current users"))
            status.m_nCurrentUsers = _ttoi(sValue);  
          else if (sField == _T("max users"))
            status.m_nMaxUsers = _ttoi(sValue);  
          else if (sField == _T("strip ext"))
          {
            if (sValue == _T("yes"))
              status.m_bStripExtended = TRUE;
            else if (sValue == _T("no"))
              status.m_bStripExtended = FALSE;
            else
            {
              bContinue = FALSE;
              m_dwLastError = 0;
              SetLastError(WSAEPROTONOSUPPORT);
    		      TRACE(_T("CDDB server failed to return a valid strip extended response to the stat command\n"));
            }
          }
          else if (sField == _T("Database entries"))
            status.m_nDatabaseEntries = _ttoi(sValue);  

          //Move to the next line 
          pszCurLine = pszNextLine;
        }
        else
          bContinue = FALSE;
      }
    }

    //Everything went ok ??
    bSuccess = TRUE;
    m_sLastCommandResponse.Empty();
  }

  return bSuccess;
}

BOOL CCDDB::Query(const CCDDBSite& server, DWORD dwDiscID, const CArray<CCDDBTrackPosition, CCDDBTrackPosition&>& tracks, 
                  CArray<CCDDBQueryResult, CCDDBQueryResult&>& results)
{
	//For correct operation of the T2A macro, see MFC Tech Note 59
	USES_CONVERSION;

  BOOL bSuccess = FALSE;

  //Create the socket
  CHTTPSocket socket;
  if (!socket.Create())
  {
    m_dwLastError = 0;
    TRACE(_T("Failed to create client socket for query command, GetLastError:%d, %s\n"), GetLastError(), GetErrorMessage());
    return FALSE;
  }

  //Connect to the host on the specified port
  BOOL bUseProxy = !m_sProxyHost.IsEmpty();
  if (!socket.Connect(bUseProxy ? m_sProxyHost : server.m_sSite, bUseProxy ? m_nProxyPort : server.m_nPort))
  {
    m_dwLastError = 0;
    TRACE(_T("Could not connect to the CDDB HTTP server %s, GetLastError:%d, %s\n"), server.m_sSite, GetLastError(), GetErrorMessage());
    return FALSE;
  }
  else
  {
    //Form the specialized HTTP request to retrieve the query data
    CString sDiscID;
    sDiscID.Format(_T("%08x"), dwDiscID);

    int nTracks = tracks.GetSize() - 1; //Number of tracks is 1 less than the size
                                        //of the array as it also contains the lead 
                                        //out position

    CString sTracks;
    sTracks.Format(_T("%d"), nTracks);

    CString sOffsets;
    for (int i=0; i<nTracks; i++)
    {
      //Form the frame number
      CString sFrame;
      sFrame.Format(_T("%d"), tracks[i].m_nMinute*60*75 + tracks[i].m_nSecond*75 + tracks[i].m_nFrame);

      //Accumulate the frame number into the string
      sOffsets += sFrame;

      //Add a space between each offset
      if (i<(nTracks-1))
       sOffsets += _T("+");
    }

    //Compute the playing length in seconds by using the lead out position
    int nCDlength = tracks[nTracks].m_nMinute*60 + tracks[nTracks].m_nSecond - tracks[0].m_nMinute - tracks[0].m_nSecond;
    CString sLength;
    sLength.Format(_T("%d"), nCDlength);

    //Form the full request string
    CString sRequest;
    if (m_sProxyHost.IsEmpty())
      sRequest.Format(_T("GET %s?cmd=cddb+query+%s+%s+%s+%s&%s HTTP/1.0\r\n\r\n"), server.m_sAddress, sDiscID, sTracks, sOffsets, sLength, GetHelloCommand());
    else
      sRequest.Format(_T("GET http://%s?cmd=cddb+query+%s+%s+%s+%s&%s HTTP/1.0\r\n%s\r\n\r\n"), server.m_sSite+server.m_sAddress, sDiscID, sTracks, sOffsets, sLength, GetHelloCommand(), GetProxyHeader(server.m_sSite));

    //Send the request through the socket
    LPCSTR pszRequest = T2A((LPTSTR) (LPCTSTR) sRequest);
    int nCmdLength = strlen(pszRequest);
    if (!socket.Send(pszRequest, nCmdLength))
    {
      m_dwLastError = 0;
      TRACE(_T("An unexpected error occurred while sending the HTTP query request, GetLastError:%d, %s\n"), GetLastError(), GetErrorMessage());
      return FALSE;
    }
    
    //Read the response back through the socket
    LPSTR pszOverFlowBuffer = NULL;
    if (ReadResponse(socket, NULL, 0, "\r\n.\r\n", &pszOverFlowBuffer, 4096, READ_RESPONSE_QUERY))
    {
      ASSERT(pszOverFlowBuffer);

      //Extract the HTTP body from the response;
      LPSTR pszBody = FindHTTPBody(pszOverFlowBuffer);

      //Parse out the query info from the body
      bSuccess = ParseQueryBody(pszBody, sDiscID, results);
    }
    else
    {
      //Reponse could not be retrieved
      m_dwLastError = 0;
      SetLastError(WSAEPROTONOSUPPORT);
    	TRACE(_T("CDDB server did not respond correctly to the query command\n"));
    }

    //Don't forget to delete the allocated buffer
    if (pszOverFlowBuffer)
      delete [] pszOverFlowBuffer;

    return bSuccess;
  }
}

BOOL CCDDB::ParseQueryBody(LPSTR pszBody, const CString& sDiscID, CArray<CCDDBQueryResult, CCDDBQueryResult&>& results)
{
  //setup return value
  BOOL bSuccess = FALSE;

  //Hive away the last reponse until everything is ok
  m_sLastCommandResponse = pszBody;

  //From the HTTP body get the CDDB response code
  int nResponseCode = GetCDDBReponseCode(pszBody);

  //Remove any entries which are in the query array
  results.RemoveAll();

  //If the response is in the expected range (21x) then parse the query data line by line
  if (nResponseCode >= 210 && nResponseCode <= 219)
  {
    //Get the query data and then iterate through all the lines
    LPSTR pszLine = SkipToNextLine(pszBody);
    while (pszLine)
    {
      //Get the next line before we parse the current line
      LPSTR pszNextLine = GetNextLine(pszLine);

      //If we can parse the current line then add it 
      //to the query array
      CCDDBQueryResult result;
      if (result.Parse(pszLine))
      {
        results.Add(result);
        bSuccess = TRUE;
      }
      
      //Move on to the next line  
      pszLine = pszNextLine;
    }

    //Everything is successful, empty out the last command reponse string
    m_sLastCommandResponse.Empty();
  }
  else if (nResponseCode == 200 && strlen(pszBody) > 5)
  {
    //found an exact match, If we can parse the 
    //current line then add it to the query array
    CCDDBQueryResult result;
    if (result.Parse(pszBody+4))
    {
      results.Add(result);
      bSuccess = TRUE;
    }

    //Everything is successful, empty out the last command reponse string
    m_sLastCommandResponse.Empty();
  }
  else if (nResponseCode == 202)
  {
    //Deliberately do nothing other than a trace
    TRACE(_T("CDDB server does not contain the specifed album with DISCID:%s in its database\n"), sDiscID);
  }
  else
  {
    //An unexpected response was retrieved
    m_dwLastError = 0;
    SetLastError(WSAEPROTONOSUPPORT);
    TRACE(_T("CDDB server failed to return a valid query response code\n"));
  }

  return bSuccess;
}

BOOL CCDDB::Read(const CCDDBSite& server, DWORD dwDiscID, const CString& sCategory, CCDDBRecord& record)
{
	//For correct operation of the T2A macro, see MFC Tech Note 59
	USES_CONVERSION;

  BOOL bSuccess = FALSE;

  //Create the socket
  CHTTPSocket socket;
  if (!socket.Create())
  {
    m_dwLastError = 0;
    TRACE(_T("Failed to create client socket for read command, GetLastError:%d, %s\n"), GetLastError(), GetErrorMessage());
    return FALSE;
  }

  //Connect to the host on the specified port
  BOOL bUseProxy = !m_sProxyHost.IsEmpty();
  if (!socket.Connect(bUseProxy ? m_sProxyHost : server.m_sSite, bUseProxy ? m_nProxyPort : server.m_nPort))
  {
    m_dwLastError = 0;
    TRACE(_T("Could not connect to the CDDB HTTP server %s, GetLastError:%d, %s\n"), server.m_sSite, GetLastError(), GetErrorMessage());
    return FALSE;
  }
  else
  {
    //Form the full request string
    CString sDiscID;
    sDiscID.Format(_T("%08x"), dwDiscID);

    CString sRequest;
    if (!bUseProxy)
      sRequest.Format(_T("GET %s?cmd=cddb+read+%s+%s&%s HTTP/1.0\r\n\r\n"), server.m_sAddress, sCategory, sDiscID, GetHelloCommand());
    else
      sRequest.Format(_T("GET http://%s?cmd=cddb+read+%s+%s&%s HTTP/1.0\r\n%s\r\n\r\n"), server.m_sSite+server.m_sAddress, sCategory, sDiscID, GetHelloCommand(), GetProxyHeader(server.m_sSite));  

    //Send the request through the socket
    LPCSTR pszRequest = T2A((LPTSTR) (LPCTSTR) sRequest);
    int nCmdLength = strlen(pszRequest);
    if (!socket.Send(pszRequest, nCmdLength))
    {
      m_dwLastError = 0;
      TRACE(_T("An unexpected error occurred while sending the HTTP stat request, GetLastError:%d, %s\n"), GetLastError(), GetErrorMessage());
      return FALSE;
    }

    //Read the response back through the socket
    LPSTR pszOverFlowBuffer = NULL;
    if (ReadResponse(socket, NULL, 0, "\r\n.\r\n", &pszOverFlowBuffer))
    {
      ASSERT(pszOverFlowBuffer);

      //Hive away the last reponse until everything is ok
      m_sLastCommandResponse = pszOverFlowBuffer;

      //Extract the HTTP body from the response;
      LPSTR pszBody = FindHTTPBody(pszOverFlowBuffer);

      //Parse the CDDB record
      bSuccess = ParseRecordBody(pszBody, record);

      if (record.m_dwDiscID != dwDiscID)
      {
        TRACE(_T("Returned DiscID from CDDB read (%x) is different than the computed value (%x), using the computed value\n"), record.m_dwDiscID, dwDiscID);
        record.m_dwDiscID = dwDiscID;      
      }
    }
    else
    {
      //Reponse could not be Retrieved
      m_dwLastError = 0;
      SetLastError(WSAEPROTONOSUPPORT);
    	TRACE(_T("CDDB server did not respond correctly to the stat command\n"));
    }

    //Don't forget to delete the allocated buffer
    if (pszOverFlowBuffer)
      delete [] pszOverFlowBuffer;

    return bSuccess;
  }
}

void CCDDB::ReplaceSubString(CString& sText, const CString& sFind, const CString& sReplacement)
{
  int nFindLength = sFind.GetLength();
  int nFind = sText.Find(sFind);
  while (nFind != -1)
  {
    CString sTemp = sText.Left(nFind);
    sTemp += sReplacement;
    sTemp += sText.Right(sText.GetLength() - nFind - nFindLength);
    sText = sTemp;

    //Look for any more strings to replace prior to looping around
    nFind = sText.Find(sFind);
  }
}

BOOL CCDDB::ParseKeywordLine(LPCSTR pszLine, CString& sKeyword, CString& sValue)
{
  //Validate out parameters
  ASSERT(pszLine);
  
  //Duplicate the string into a local variable 
  int nLength = strlen(pszLine);
  LPSTR pszData = new char[nLength + 1];
  strcpy(pszData, pszLine);

  //Do the actual parsing
  BOOL bSuccess = FALSE;
  char* pszToken = strstr(pszData, "=");
  if (pszData)
  {
    pszToken[0] = '\0';
    sKeyword = pszData;
    sValue = pszToken+1;

    //Replace all strings as specified in the cddb document
    ReplaceSubString(sValue, _T("\\n"), _T("\n"));
    ReplaceSubString(sValue, _T("\\t"), _T("\t"));
    ReplaceSubString(sValue, _T("\\\\"), _T("\\"));

    bSuccess = TRUE;
  }

  //Dont forget to delete our local string
  delete [] pszData;

  return bSuccess;
}

BOOL CCDDB::ParseRecordBody(LPSTR pszBody, CCDDBRecord& record)
{
  //setup return value
  BOOL bSuccess = FALSE;

  //Hive away the last reponse until everything is ok
  m_sLastCommandResponse = pszBody;

  //From the HTTP body get the CDDB response code
  int nResponseCode = GetCDDBReponseCode(pszBody);

  //If the response is in the expected range (21x) then parse the query data line by line
  if (nResponseCode >= 210 && nResponseCode <= 219)
  {
    //Get the query data and then iterate through all the lines
    LPSTR pszCurLine = SkipToNextLine(pszBody);
    if (pszCurLine == NULL)
    {
      m_dwLastError = 0;
      SetLastError(WSAEPROTONOSUPPORT);
      TRACE(_T("CDDB server failed to return a valid xmcd record\n"));
      return FALSE;
    }

    //Get the next line before we parse the current one
    LPSTR pszNextLine = GetNextLine(pszCurLine);

    //Parse the "# xmcd" line  
    CString sValue;
    if ((!ParseCommentLine(pszCurLine, sValue)) || (sValue.Find(_T("xmcd")) == -1))
    {
      m_dwLastError = 0;
      SetLastError(WSAEPROTONOSUPPORT);
      TRACE(_T("CDDB server failed to return a valid xmcd record\n"));
      return FALSE;
    }

    //Skip over any other comment lines until we reach the "# Track frame offsets:" line
    pszCurLine = pszNextLine;
    BOOL bFound = FALSE;
    BOOL bContinue;
    do
    {
      //Get the next line prior to parsing the current one
      pszNextLine = GetNextLine(pszCurLine);

      //Continue skipping lines until we reach the "# Track frame offsets:" line
      bContinue = pszCurLine && ParseCommentLine(pszCurLine, sValue);
      if (bContinue)
      {
        bFound = (sValue.Find(_T("Track frame offsets:")) != -1);
        bContinue = !bFound;
      }

      //Get ready for the next loop around
      if (bContinue)
        pszCurLine = pszNextLine;
    }
    while (bContinue);

    //If we could not find the "# Track frame offsets:" line
    if (!bFound)
    {
      m_dwLastError = 0;
      SetLastError(WSAEPROTONOSUPPORT);
      TRACE(_T("CDDB server failed to return a record with a Track frame offset line\n"));
      return FALSE;
    }

    //Next should come the track offsets
    pszCurLine = pszNextLine;
    do
    {
      //Get the next line prior to parsing the current one
      pszNextLine = GetNextLine(pszCurLine);

      //Continue skipping lines until we reach the "# Track frame offsets:" line
      bContinue = pszCurLine && ParseCommentLine(pszCurLine, sValue) && (!sValue.IsEmpty());

      //Get ready for the next loop around
      if (bContinue)
      {
        //Add the track offsets to the array in the record
        int nTrackOffset = ::_ttoi(sValue);
        record.m_TrackOffsets.Add(nTrackOffset);
        pszCurLine = pszNextLine;
      }
    }
    while (bContinue);

    //Skip over any other comment lines until we reach the "# Disc length:" line
    pszCurLine = pszNextLine;
    do
    {
      //Get the next line prior to parsing the current one
      pszNextLine = GetNextLine(pszCurLine);

      //Continue skipping lines until we reach the "# Track frame offsets:" line
      bContinue = pszCurLine && ParseCommentLine(pszCurLine, sValue);
      if (bContinue)
      {
        bFound = (sValue.Find(_T("Disc length:")) != -1);
        bContinue = !bFound;
      }

      //Get ready for the next loop around
      if (bContinue)
        pszCurLine = pszNextLine;
    }
    while (bContinue);

    int nLength = sValue.GetLength();
    if (!bFound || nLength < 13)
    {
      m_dwLastError = 0;
      SetLastError(WSAEPROTONOSUPPORT);
      TRACE(_T("CDDB server failed to return a record with a Disc Length line\n"));
      return FALSE;
    }
  
    //Parse out the "# Disc length" value
    sValue = sValue.Right(nLength - 13);
    record.m_nDiskLength = ::_ttoi(sValue);

    //Skip over any other comment lines until we reach the "# Revision:" line
    pszCurLine = pszNextLine;
    BOOL bFoundRevision = FALSE;
    BOOL bFoundSubmitted = FALSE;
    do
    {
      //Get the next line prior to parsing the current one
      pszNextLine = GetNextLine(pszCurLine);

      //Continue skipping lines until we reach the "# Revision:" line
      bContinue = pszCurLine && ParseCommentLine(pszCurLine, sValue);
      if (bContinue)
      {
        bFoundRevision = (sValue.Find(_T("Revision:")) != -1);
        bFoundSubmitted = (sValue.Find(_T("Submitted via:")) != -1);
        bContinue = !bFoundRevision && !bFoundSubmitted;
      }

      //Get ready for the next loop around
      if (bContinue)
        pszCurLine = pszNextLine;
    }
    while (bContinue);

    //Handle revision not being found
    nLength = sValue.GetLength();
    if (!bFoundRevision || (bFoundRevision && nLength < 11))
    {
      TRACE(_T("CDDB server failed to return a record with a Revision line, assuming revision level zero\n"));
      record.m_nDatabaseRevision = 0;
    }
    else
    {
      //Parse out the "# Revision" value
      sValue = sValue.Right(nLength - 9);
      record.m_nDatabaseRevision = ::_ttoi(sValue);
    }

    //Handle case where revision was not found neither was submitted
    if (!bFoundRevision && !bFoundSubmitted)
    {
      m_dwLastError = 0;
      SetLastError(WSAEPROTONOSUPPORT);
      TRACE(_T("CDDB server failed to return a record with a revision or a submitted line\n"));
      return FALSE;
    }

    //Skip over any other comment lines until we reach the "# Submitted via:" line
    if (!bFoundSubmitted)
    {
      pszCurLine = pszNextLine;
      do
      {
        //Get the next line prior to parsing the current one
        pszNextLine = GetNextLine(pszCurLine);

        //Continue skipping lines until we reach the "# Submitted via:" line
        bContinue = pszCurLine && ParseCommentLine(pszCurLine, sValue);
        if (bContinue)
        {
          bFoundSubmitted = (sValue.Find(_T("Submitted via:")) != -1);
          bContinue = !bFoundSubmitted;
        }

        //Get ready for the next loop around
        if (bContinue)
          pszCurLine = pszNextLine;
      }
      while (bContinue);
    }

    //Handle case of no submitted line
    nLength = sValue.GetLength();
    if (!bFoundSubmitted || nLength < 14)
    {
      m_dwLastError = 0;
      SetLastError(WSAEPROTONOSUPPORT);
      TRACE(_T("CDDB server failed to return a record with a valid submitted line\n"));
      return FALSE;
    }

    //Parse out the "Submitted via:" line
    //Pull out the client name
    TCHAR pszSeparators[] = _T(" ");
    sValue = sValue.Right(nLength - 14);
    TCHAR* pszValue = sValue.GetBuffer(sValue.GetLength());
    TCHAR* pszToken = _tcstok(pszValue, pszSeparators);
    if (pszToken)
      record.m_sClientName = pszToken;
    else
    {
      sValue.ReleaseBuffer();
      m_dwLastError = 0;
      SetLastError(WSAEPROTONOSUPPORT);
      TRACE(_T("CDDB server failed to return a record with a valid Submitted via: line\n"));
      return FALSE;
    }

    //Pull out the client version
    pszToken = _tcstok(NULL, pszSeparators);
    if (pszToken)
      record.m_sClientVersion = pszToken;
    else
    {
      sValue.ReleaseBuffer();
      m_dwLastError = 0;
      SetLastError(WSAEPROTONOSUPPORT);
      TRACE(_T("CDDB server failed to return a record with a valid Submitted via: line\n"));
      return FALSE;
    }

    //Pull out the client comments
    pszToken = _tcstok(NULL, pszSeparators);
    if (pszToken)
      record.m_sClientComments = pszToken;
    else
      record.m_sClientComments.Empty();

    sValue.ReleaseBuffer();

    //Skip over any other comment lines until we reach the "DISCID=" line
    pszCurLine = pszNextLine;
    BOOL bFoundDiscID = FALSE;
    do
    {
      //Get the next line prior to parsing the current one
      pszNextLine = GetNextLine(pszCurLine);

      //Continue skipping lines until we reach the "DISCID=" line
      bContinue = (pszCurLine != NULL);
      if (bContinue)
      {
        CString sLine(pszCurLine);
        bFoundDiscID = (sLine.Find(_T("DISCID=")) != -1);
        bContinue = !bFoundDiscID;
      }

      //Get ready for the next loop around
      if (bContinue)
        pszCurLine = pszNextLine;
    }
    while (bContinue);

    //Handle the DISCID line
    CString sKeyword;
    bFound = bFound && ParseKeywordLine(pszCurLine, sKeyword, sValue);
    if (!bFound || sKeyword != _T("DISCID") || sValue.GetLength() < 8)
    {
      //Handle the DISCID line not being found
      m_dwLastError = 0;
      SetLastError(WSAEPROTONOSUPPORT);
      TRACE(_T("CDDB server failed to return a record with a DISCID line\n"));
      return FALSE;
    }
  
    //Parse out the "# Disc length" value
    _stscanf(sValue, _T("%x"), &record.m_dwDiscID);

    //Handle the DTITLE line
    pszCurLine = pszNextLine;
    pszNextLine = GetNextLine(pszCurLine);
    bFound = ParseKeywordLine(pszCurLine, sKeyword, sValue);
    if (!bFound || sKeyword != _T("DTITLE"))
    {
      //Handle the DTITLE line not being found
      m_dwLastError = 0;
      SetLastError(WSAEPROTONOSUPPORT);
      TRACE(_T("CDDB server failed to return a record with a DTITLE line\n"));
      return FALSE;
    }
    int nFind = sValue.Find(_T('/'));
    if (nFind != -1)
    {
      record.m_sArtist = sValue.Left(nFind);
      record.m_sTitle = sValue.Right(sValue.GetLength() - nFind - 1);
    }
    else
    {
      record.m_sTitle = sValue;
      record.m_sArtist.Empty();
    }
    //Remove any leading and trailing spaces
    record.m_sArtist.TrimLeft();
    record.m_sArtist.TrimRight();
    record.m_sTitle.TrimLeft();
    record.m_sTitle.TrimRight();

    //Handle the TTITLE lines
    record.m_TrackTitles.RemoveAll();
    pszCurLine = pszNextLine;
    pszNextLine = GetNextLine(pszCurLine);
    bContinue = FALSE;  
    BOOL bError = FALSE;
    do
    {
      bContinue = (pszCurLine != NULL);
      if (bContinue)
      {
        CString sLine(pszCurLine);
        bContinue = (sLine.Find(_T("TTITLE")) != -1);
        if (bContinue)
        {
          bError = !ParseKeywordLine(pszCurLine, sKeyword, sValue);
          if (!bError)
            record.m_TrackTitles.Add(sValue);
          else
            bContinue = FALSE;
        }
      }

      //Get ready for the next loop around
      if (bContinue)
      {
        pszCurLine = pszNextLine;
        pszNextLine = GetNextLine(pszCurLine);
      }
    }
    while (bContinue);

    //Handle any TTITLE errors
    if (bError)
    {
      m_dwLastError = 0;
      SetLastError(WSAEPROTONOSUPPORT);
      TRACE(_T("CDDB server failed to return a record with some valid DTITLE lines\n"));
      return FALSE;
    }

    //Handle any EXTD lines
    bContinue = FALSE;  
    bError = FALSE;
    CString sExtd;
    do
    {
      bContinue = (pszCurLine != NULL);
      if (bContinue)
      {
        CString sLine(pszCurLine);
        bContinue = (sLine.Find(_T("EXTD=")) != -1);
        if (bContinue)
        {
          bError = !ParseKeywordLine(pszCurLine, sKeyword, sValue);
          if (!bError)
          {
            if (sValue.GetLength())
              sExtd += sValue;
          }
          else
            bContinue = FALSE;
        }
      }

      //Get ready for the next loop around
      if (bContinue)
      {
        pszCurLine = pszNextLine;
        pszNextLine = GetNextLine(pszCurLine);
      }
    }
    while (bContinue);

    //Handle any EXTD errors
    if (bError)
    {
      m_dwLastError = 0;
      SetLastError(WSAEPROTONOSUPPORT);
      TRACE(_T("CDDB server failed to return a record with some valid EXTD lines\n"));
      return FALSE;
    }
    else
    {
      //Process the EXTD string into the two string arrays in the record instance
      record.m_ExtendedData.RemoveAll();
      do
      {
        int nFind = sExtd.Find(_T("\n"));
        if (nFind != -1)
        {
          CString sValue(sExtd.Left(nFind));
          record.m_ExtendedData.Add(sValue);
          sExtd = sExtd.Right(sExtd.GetLength() - nFind - 1);
          bContinue = TRUE;
        }
        else
        {
          if (sExtd.GetLength())
            record.m_ExtendedData.Add(sExtd);
          bContinue = FALSE;
        }
      }
      while (bContinue);
    }

    //Handle the EXTTN lines
    bContinue = FALSE;  
    bError = FALSE;
    CString sPrevKeyword;
    do
    {
      bContinue = (pszCurLine != NULL);
      if (bContinue)
      {
        CString sLine(pszCurLine);
        bContinue = (sLine.Find(_T("EXTT")) != -1);
        if (bContinue)
        {
          bError = !ParseKeywordLine(pszCurLine, sKeyword, sValue);
          if (!bError)
          {
            if (sPrevKeyword != sKeyword)
            {
              //Create a new entry in the array and add the string into it.
              record.m_ExtendedTrackData.Add(sValue);
            }
            else
            {
              //Add to the last tracks data
              CString& sData = record.m_ExtendedTrackData.ElementAt(record.m_ExtendedTrackData.GetUpperBound());
              sData += sValue;
            }

            sPrevKeyword = sKeyword;
          }
          else
            bContinue = FALSE;
        }
      }

      //Get ready for the next loop around
      if (bContinue)
      {
        pszCurLine = pszNextLine;
        pszNextLine = GetNextLine(pszCurLine);
      }
    }
    while (bContinue);

    //Handle any EXTT errors
    if (bError)
    {
      m_dwLastError = 0;
      SetLastError(WSAEPROTONOSUPPORT);
      TRACE(_T("CDDB server failed to return a record with some valid EXTT lines\n"));
      return FALSE;
    }

    //Handle the PLAYORDER line if it exists
    record.m_PlayOrder.RemoveAll();
    bFound = ParseKeywordLine(pszCurLine, sKeyword, sValue);
    if (bFound && sKeyword == _T("PLAYORDER"))
    {
      do 
      {
        int nFind = sValue.Find(_T(","));
        if (nFind != -1)
        {
          CString sNum = sValue.Left(nFind);
          int nNum = ::_ttoi(sNum);
          record.m_PlayOrder.Add(nNum);
          sValue = sValue.Right(sValue.GetLength() - nFind - 1);
          bContinue = TRUE;
        }
        else 
        {
          if (sValue.GetLength())
          {
            int nNum = ::_ttoi(sValue);
            record.m_PlayOrder.Add(nNum);
          }
          bContinue = FALSE;
        }
      }
      while (bContinue);
    }

    //Everything is successful, empty out the last command reponse string
    m_sLastCommandResponse.Empty();

    bSuccess = TRUE;
  }

  //Return the status code
  return bSuccess;
}

void CCDDB::PrepareTextForSubmit(CString& sText)
{
  ReplaceSubString(sText, _T("\\"), _T("\\\\"));
  ReplaceSubString(sText, _T("\n"), _T("\\n"));
  ReplaceSubString(sText, _T("\t"), _T("\\t"));
}

BOOL CCDDB::Submit(const CCDDBSite& server, const CString& sCategory, const CString& sEmailAddress, 
                   CCDDBRecord& record, const CString& sRejectionNotice, BOOL bReallySubmit)
{
	//For correct operation of the T2A macro, see MFC Tech Note 59
	USES_CONVERSION;

  BOOL bSuccess = FALSE;

  //Create the socket
  CHTTPSocket socket;
  if (!socket.Create())
  {
    m_dwLastError = 0;
    TRACE(_T("Failed to create client socket for submit command, GetLastError:%d, %s\n"), GetLastError(), GetErrorMessage());
    return FALSE;
  }

  //Connect to the host on the specified port
  BOOL bUseProxy = !m_sProxyHost.IsEmpty();
  if (!socket.Connect(bUseProxy ? m_sProxyHost : server.m_sSite, bUseProxy ? m_nProxyPort : server.m_nPort))
  {
    m_dwLastError = 0;
    TRACE(_T("Could not connect to the CDDB HTTP server %s, GetLastError:%d, %s\n"), server.m_sSite, GetLastError(), GetErrorMessage());
    return FALSE;
  }
  else
  {
    //Form the specialized HTTP request to submit the album

    //Form the body
    
    //First the first few intro lines
    CString sBody = _T("# xmcd\r\n# Copyright (C) 1999 CDDB Inc.\r\n#\r\n# Track frame offsets:\r\n");  

    //Then the track offsets
    CString sBuf;
    for (int i=0; i<record.m_TrackOffsets.GetSize(); i++) 
    {
      sBuf.Format(_T("# %d\r\n"), record.m_TrackOffsets.GetAt(i));
      sBody += sBuf;
    }

    //Then the disc length
    sBuf.Format(_T("#\r\n# Disc length: %d seconds\r\n#\r\n"), record.m_nDiskLength); 
    sBody += sBuf;

    //Then the database revision
    sBuf.Format(_T("#\r\n# Revision: %d\r\n"), record.m_nDatabaseRevision); 
    sBody += sBuf;

    //Then the client details
    sBuf.Format(_T("# Submitted via: %s %s %s"), record.m_sClientName, record.m_sClientVersion, record.m_sClientComments);
    PrepareTextForSubmit(sBuf);
    ASSERT(sBuf.GetLength() <= 80); //Only 80 chars per line supported for the "# Submitted via:" line
    sBody += sBuf; 

    sBody += _T("\r\n#\r\n");

    sBuf.Format(_T("DISCID=%x\r\n"), record.m_dwDiscID);  
    sBody += sBuf; //Then the discid

    //Then the DTITLE
    if (record.m_sArtist.GetLength())
      sBuf.Format(_T("DTITLE=%s / %s"), record.m_sArtist, record.m_sTitle);
    else
      sBuf.Format(_T("DTITLE=%s"), record.m_sTitle);
    PrepareTextForSubmit(sBuf);
    ASSERT(sBuf.GetLength() <= 80); //Only 80 chars supported for the DTITLE line
    sBody += sBuf;  

    sBody += _T("\r\n");

    //Then the track titles
    for (i=0; i<record.m_TrackTitles.GetSize(); i++)  
    {
      sBuf.Format(_T("TTITLE%d=%s"), i, record.m_TrackTitles.ElementAt(i));
      ASSERT(sBuf.GetLength() <= 80); //Only 80 chars per line supported for TTITLE lines
      PrepareTextForSubmit(sBuf);
      sBody += sBuf;
      sBody += _T("\r\n");
    }

    //Then the extended data
    int nData = record.m_ExtendedData.GetSize();
    if (nData)
    {
      for (i=0; i<nData; i++) 
      {
        CString sLine;
        CString& sData = record.m_ExtendedData.ElementAt(i);
        do 
        {
          sBuf.Format(_T("EXTD=%s"), sData);
          int nBufLength = sBuf.GetLength();
          int nMaxLength = min(78, nBufLength);
          sLine = sBuf.Left(nMaxLength);
          PrepareTextForSubmit(sLine);
          if (nBufLength > 78)
            sData = sBuf.Right(nBufLength - 78);
          else
            sData.Empty();
          sLine += _T("\\n\r\n");
          sBody += sLine;
        }
        while (sData.GetLength());
      }
    }
    else
      sBody += _T("EXTD=\r\n"); 

    //Then the extended track data
    for (i=0; i<record.m_ExtendedTrackData.GetSize(); i++) 
    {
      CString sLine;
      CString& sData = record.m_ExtendedTrackData.ElementAt(i);
      do 
      {
        sBuf.Format(_T("EXTT%d=%s"), i, sData);
        int nBufLength = sBuf.GetLength();
        int nMaxLength = min(80, nBufLength);
        sLine = sBuf.Left(nMaxLength);
        PrepareTextForSubmit(sLine);
        if (nBufLength > 80)
          sData = sBuf.Right(nBufLength - 80);
        else
          sData.Empty();
        sLine += _T("\r\n");
        sBody += sLine;
      }
      while (sData.GetLength());
    }

    //Finally the PLAYORDER line (which is deliberately empty)
    sBody += _T("PLAYORDER="); 

    //Form the header into "sRequest"
    CString sRequest;
    if (m_sProxyHost.IsEmpty())
      sRequest.Format(_T("POST %s HTTP/1.0\r\nCategory: "), server.m_sAddress); //First the request line
    else
      sRequest.Format(_T("POST http://%s HTTP/1.0\r\n%s\r\nCategory: "), server.m_sSite+server.m_sAddress, GetProxyHeader(server.m_sSite)); //First the request line

    sRequest += sCategory; //Then the category
    sRequest += _T("\r\n");

    sBuf.Format(_T("Discid: %x\r\n"), record.m_dwDiscID); //Then the DISCID
    sRequest += sBuf;

    sBuf.Format(_T("User-Email: %s\r\n"), sEmailAddress);
    sRequest += sBuf; //Then the User's email address

    if (bReallySubmit) //Then the submit mode
      sRequest += _T("Submit-Mode: submit\r\n");
    else
      sRequest += _T("Submit-Mode: test\r\n");                        

    sBuf.Format(_T("X-Cddbd-Note: %s\r\n"), sRejectionNotice); //Then the rejection notice
    sRequest += sBuf;

    sBuf.Format(_T("Content-Length: %d\r\n\r\n"), sBody.GetLength()); 
    sRequest += sBuf; //Then the Content-Length

    //Add the body to the end of the request
    sRequest += sBody;   

    //Send the request through the socket
    LPCSTR pszRequest = T2A((LPTSTR) (LPCTSTR) sRequest);
    int nCmdLength = strlen(pszRequest);
    if (!socket.Send(pszRequest, nCmdLength))
    {
      m_dwLastError = 0;
      TRACE(_T("An unexpected error occurred while sending the HTTP stat request, GetLastError:%d, %s\n"), GetLastError(), GetErrorMessage());
      return FALSE;
    }

    //Read the response back through the socket
    LPSTR pszOverFlowBuffer = NULL;
    if (ReadResponse(socket, NULL, 0, "\r\n.\r\n", &pszOverFlowBuffer, 4096, READ_RESPONSE_SUBMIT)) 
    {
      ASSERT(pszOverFlowBuffer);

      //Extract the HTTP body from the response;
      LPSTR pszBody = FindHTTPBody(pszOverFlowBuffer);

      //Parse out the response
      bSuccess = ParseSubmitBody(pszBody);
    }
    else
    {
      //Reponse could not be Retrieved
      m_dwLastError = 0;
      SetLastError(WSAEPROTONOSUPPORT);
    	TRACE(_T("CDDB server did not respond correctly to the submit command\n"));
    }

    //Don't forget to delete the allocated buffer
    if (pszOverFlowBuffer)
      delete [] pszOverFlowBuffer;

    return bSuccess;
  }
}

BOOL CCDDB::ParseSubmitBody(LPSTR pszBody)
{
  //setup return value
  BOOL bSuccess = FALSE;

  //Hive away the last reponse until everything is ok
  m_sLastCommandResponse = pszBody;

  //From the HTTP body get the CDDB response code
  int nResponseCode = GetCDDBReponseCode(pszBody);

  //If the response is in the expected range (20x) then return success
  if (nResponseCode >= 200 && nResponseCode <= 209)
  {
    bSuccess = TRUE;
    m_sLastCommandResponse.Empty();
  }

  return bSuccess;
}

BOOL CCDDB::MessageOfTheDay(CString& sMessage, const CString& sServer, const CString& sAddress, int nPort)
{
  //Form the site which we will be getting the message from
  CCDDBSite server;
  server.m_sSite = sServer;
  server.m_nPort = nPort;
  server.m_sAddress = sAddress;
  
  //Let the other version 
  return MessageOfTheDay(server, sMessage);
}

BOOL CCDDB::MessageOfTheDay(const CCDDBSite& server, CString& sMessage)
{
	//For correct operation of the T2A macro, see MFC Tech Note 59
	USES_CONVERSION;

  BOOL bSuccess = FALSE;

  //Create the socket
  CHTTPSocket socket;
  if (!socket.Create())
  {
    m_dwLastError = 0;
    TRACE(_T("Failed to create client socket for motd command, GetLastError:%d, %s\n"), GetLastError(), GetErrorMessage());
    return FALSE;
  }

  //Connect to the host on the specified port
  BOOL bUseProxy = !m_sProxyHost.IsEmpty();
  if (!socket.Connect(bUseProxy ? m_sProxyHost : server.m_sSite, bUseProxy ? m_nProxyPort : server.m_nPort))
  {
    m_dwLastError = 0;
    TRACE(_T("Could not connect to the CDDB HTTP server %s, GetLastError:%d, %s\n"), server.m_sSite, GetLastError(), GetErrorMessage());
    return FALSE;
  }
  else
  {
    //Form the specialized HTTP request to retrieve the status data
    CString sRequest;
    if (m_sProxyHost.IsEmpty())
      sRequest.Format(_T("GET %s?cmd=motd&%s HTTP/1.0\r\n\r\n"), server.m_sAddress, GetHelloCommand());
    else
      sRequest.Format(_T("GET http://%s?cmd=motd&%s HTTP/1.0\r\n%s\r\n\r\n"), server.m_sSite+server.m_sAddress, GetHelloCommand(), GetProxyHeader(server.m_sSite));

    //Send the request through the socket
    LPCSTR pszRequest = T2A((LPTSTR) (LPCTSTR) sRequest);
    int nCmdLength = strlen(pszRequest);
    if (!socket.Send(pszRequest, nCmdLength))
    {
      m_dwLastError = 0;
      TRACE(_T("An unexpected error occurred while sending the HTTP stat request, GetLastError:%d, %s\n"), GetLastError(), GetErrorMessage());
      return FALSE;
    }

    //Read the response back through the socket
    LPSTR pszOverFlowBuffer = NULL;
    if (ReadResponse(socket, NULL, 0, "\r\n.\r\n", &pszOverFlowBuffer))
    {
      ASSERT(pszOverFlowBuffer);

      //Extract the HTTP body from the response;
      LPSTR pszBody = FindHTTPBody(pszOverFlowBuffer);

      //Parse out the message from the body
      bSuccess = ParseMessageBody(pszBody, sMessage);
    }
    else
    {
      //Reponse could not be Retrieved
      m_dwLastError = 0;
      SetLastError(WSAEPROTONOSUPPORT);
    	TRACE(_T("CDDB server did not respond correctly to the stat command\n"));
    }

    //Don't forget to delete the allocated buffer
    if (pszOverFlowBuffer)
      delete [] pszOverFlowBuffer;

    return bSuccess;
  }
}

BOOL CCDDB::ParseMessageBody(LPSTR pszBody, CString& sMessage)
{
  //setup return value
  BOOL bSuccess = FALSE;

  //Hive away the last reponse until everything is ok
  m_sLastCommandResponse = pszBody;

  //From the HTTP body get the CDDB response code
  int nResponseCode = GetCDDBReponseCode(pszBody);

  //If the response is in the expected range (21x) then copy the message into "sMessage"
  if (nResponseCode >= 210 && nResponseCode <= 219)
  {
    //Get the query data and then iterate through all the lines
    LPSTR pszLine = SkipToNextLine(pszBody);

    if (pszLine)
    {
      sMessage = pszLine;
      bSuccess = TRUE;
      m_sLastCommandResponse.Empty();
    }
  }

  return bSuccess;
}

void CCDDB::SetProxyDetails(const CString& sHost, int nPort, const CString& sUser, const CString& sPassword)
{
  m_sProxyHost = sHost;
  m_nProxyPort = nPort;
  m_sProxyUser = sUser;
  m_sProxyPassword = sPassword;
}

int CCDDB::Base64BufferSize(int nInputSize)
{
  int nOutSize = (nInputSize+2)/3*4;                    // 3:4 conversion ratio
  nOutSize += strlen(EOL)*nOutSize/BASE64_MAXLINE + 3;  // Space for newlines and NUL
  return nOutSize;
}

BOOL CCDDB::EncodeBase64(const char* pszIn, int nInLen, char* pszOut, int nOutSize, int* nOutLen)
{
  //Input Parameter validation
  ASSERT(pszIn);
  ASSERT(pszOut);
  ASSERT(nOutSize);
  ASSERT(nOutSize >= Base64BufferSize(nInLen));

#ifndef _DEBUG
  //justs get rid of "unreferenced formal parameter"
  //compiler warning when doing a release build
  nOutSize;
#endif

  //Set up the parameters prior to the main encoding loop
  int nInPos  = 0;
  int nOutPos = 0;
  int nLineLen = 0;

  // Get three characters at a time from the input buffer and encode them
  for (int i=0; i<nInLen/3; ++i) 
  {
    //Get the next 2 characters
    int c1 = pszIn[nInPos++] & 0xFF;
    int c2 = pszIn[nInPos++] & 0xFF;
    int c3 = pszIn[nInPos++] & 0xFF;

    //Encode into the 4 6 bit characters
    pszOut[nOutPos++] = m_base64tab[(c1 & 0xFC) >> 2];
    pszOut[nOutPos++] = m_base64tab[((c1 & 0x03) << 4) | ((c2 & 0xF0) >> 4)];
    pszOut[nOutPos++] = m_base64tab[((c2 & 0x0F) << 2) | ((c3 & 0xC0) >> 6)];
    pszOut[nOutPos++] = m_base64tab[c3 & 0x3F];
    nLineLen += 4;

    //Handle the case where we have gone over the max line boundary
    if (nLineLen >= BASE64_MAXLINE-3) 
    {
      char* cp = EOL;
      pszOut[nOutPos++] = *cp++;
      if (*cp) 
        pszOut[nOutPos++] = *cp;
      nLineLen = 0;
    }
  }

  // Encode the remaining one or two characters in the input buffer
  char* cp;
  switch (nInLen % 3) 
  {
    case 0:
    {
      cp = EOL;
      pszOut[nOutPos++] = *cp++;
      if (*cp) 
        pszOut[nOutPos++] = *cp;
      break;
    }
    case 1:
    {
      int c1 = pszIn[nInPos] & 0xFF;
      pszOut[nOutPos++] = m_base64tab[(c1 & 0xFC) >> 2];
      pszOut[nOutPos++] = m_base64tab[((c1 & 0x03) << 4)];
      pszOut[nOutPos++] = '=';
      pszOut[nOutPos++] = '=';
      cp = EOL;
      pszOut[nOutPos++] = *cp++;
      if (*cp) 
        pszOut[nOutPos++] = *cp;
      break;
    }
    case 2:
    {
      int c1 = pszIn[nInPos++] & 0xFF;
      int c2 = pszIn[nInPos] & 0xFF;
      pszOut[nOutPos++] = m_base64tab[(c1 & 0xFC) >> 2];
      pszOut[nOutPos++] = m_base64tab[((c1 & 0x03) << 4) | ((c2 & 0xF0) >> 4)];
      pszOut[nOutPos++] = m_base64tab[((c2 & 0x0F) << 2)];
      pszOut[nOutPos++] = '=';
      cp = EOL;
      pszOut[nOutPos++] = *cp++;
      if (*cp) 
        pszOut[nOutPos++] = *cp;
      break;
    }
    default: 
    {
      ASSERT(FALSE); 
      break;
    }
  }
  pszOut[nOutPos] = 0;
  *nOutLen = nOutPos;
  return TRUE;
}

CString CCDDB::GetProxyHeader(const CString& sHost)
{
  //Validate the parameters
  ASSERT(m_sProxyHost.GetLength());

	//For correct operation of the T2A macro, see MFC Tech Note 59
	USES_CONVERSION;

  CString sLine;

  //If we need authentication
  if (m_sProxyUser.GetLength())
  {
    CString sCombinedUserAndPassword;
    sCombinedUserAndPassword.Format(_T("%s:%s"),m_sProxyUser, m_sProxyPassword);
	  LPSTR lpszAsciiCombinedUserAndPassword = T2A((LPTSTR) (LPCTSTR) sCombinedUserAndPassword);
    int nSize = strlen(lpszAsciiCombinedUserAndPassword);

    //allocate the encoded buffer
    int nOutSize = Base64BufferSize(nSize);
    char* pszEncoded = new char[nOutSize];

    //Do the encoding
    int nEncodedSize=0;
    EncodeBase64(lpszAsciiCombinedUserAndPassword, nSize, pszEncoded, nOutSize, &nEncodedSize);

    //Form the header 
    sLine.Format(_T("Proxy-Authorization: Basic %s\r\nHost: %s"), A2T(pszEncoded), sHost);

    //delete the encoded temp buffer
    delete [] pszEncoded;
  }
  else
  {
    //Just add the Host header
    sLine.Format(_T("Host: %s"), sHost);
  }

  //Return the formed string
  return sLine;
}