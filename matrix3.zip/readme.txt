Matrix ScreenSaver 3.0
www.catch22.net

Freeware written by J Brown 2003
------------------------------------

The Matrix ScreenSaver is a small, fast and elegant Windows
version of the green "Matrix" cypher-code seen in the films.

With this version you can even add messages which are
decoded displayed in realtime. Colour matrix fields are also
supported

Features
------------------------------------

+ Colour Matrix Field
+ Small and FAST
+ All 32bit versions of Windows (Win95,98,ME,NT,2000,XP,NET)
+ Multimonitor support (new in version 2)
+ Custom matrix messages
+ Highly configurable
+ Full sourcecode available!

Installation and use
------------------------------------
Simply copy "matrix.scr" to your windows directory,
or right-click this file in explorer and click "Install".

Other than that, it's just a standard Windows screensaver so it
works just like any other screensaver



