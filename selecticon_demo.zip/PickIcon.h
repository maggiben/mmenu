// PickIcon.h : main header file for the PICKICON application
//

#if !defined(AFX_PICKICON_H__91E0834A_95B6_11D3_BD60_00A0C9A341EC__INCLUDED_)
#define AFX_PICKICON_H__91E0834A_95B6_11D3_BD60_00A0C9A341EC__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols

/////////////////////////////////////////////////////////////////////////////
// CPickIconApp:
// See PickIcon.cpp for the implementation of this class
//

class CPickIconApp : public CWinApp
{
public:
	CPickIconApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CPickIconApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation

	//{{AFX_MSG(CPickIconApp)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_PICKICON_H__91E0834A_95B6_11D3_BD60_00A0C9A341EC__INCLUDED_)
