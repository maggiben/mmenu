//webapp.h

#define TD_BACK     0
#define TD_FORWARD  1
#define TD_STOP     2
#define TD_REFRESH 	3
#define TD_HOME 	4
#define TD_SEARCH 	5
#define TD_PASTE 	6
#define TD_UNDO		7



#define TD_HELP		10
#define TD_FIND		11


